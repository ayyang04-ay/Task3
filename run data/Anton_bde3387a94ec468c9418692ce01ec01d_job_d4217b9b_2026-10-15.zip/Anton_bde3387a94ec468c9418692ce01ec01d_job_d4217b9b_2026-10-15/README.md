# Anton_bde3387a94ec468c9418692ce01ec01d_job_d4217b9b_2026-10-15

- **Task ID**: `task_bde3387a94ec468c9418692ce01ec01d`
- **Taiga job**: `d4217b9b-104e-40d0-b564-fc47beb7c004` — `Studio - task_bde3387a94ec468c9418692ce01ec01d`
- **Status**: `completed`
- **Environment**: vert_bio_v001_MER (`2e3eb299-7d22-4082-be2e-180e73ccf90d`)
- **Model**: claude-opus-5-5
- **Created**: 2026-10-15T00:27:26.730548Z
- **Grader**: agentic_grader (claude-opus-5-5)
- **Attempts**: 16 completed / 16 total — 16 scored
- **Score**: mean **0.313** over 16 SCORED attempt(s)  ·  0 refused (Trust & Safety)  ·  16 of 16 rollouts reached the model
- **Pass counts**: pass@0.8 0/16  ·  pass@0.5 0/16
- **Submit gate (Avg Score Under 55%)**: **CLEARED** — mean 0.313 ≤ 0.55.

## How to read the score

Anton grading is **agentic**: an external grader container reads the run's
transcript against the writer's grading guidance and returns ONE normalized
score in `[0,1]`. There is no partial-credit arithmetic to re-derive by hand —
the number is the grader's judgement, and its reasoning is in the grading record.

**The submit gate is inverted.** A task ships only if the model does **NOT**
solve it: the bar is *Avg Score Under 55%*
(mean ≤ 0.55). A HIGH mean is a FAILING task, not a good one —
it means the model handled the problem and the task needs to be made harder.

A Trust & Safety refusal is a third outcome, neither a pass nor a fail. The
classifier blocks the turn before the model answers, so the rollout produces no
function call and no work: it is a void. Refused attempts appear as `T&S` in the
table below, carry `refused: true` in `all_runs.json` / `all_runs.csv`, and are
excluded from the mean and from every pass count.

## Export selection

All clusters included (full export).

Only the selected clusters are present in this bundle (the always-on metadata —
README, job_info, all_runs, task_prompt, grading_config, and the manifests — is
always included; the manifests keep the gs:// references for excluded clusters).

## Layout (selected clusters only)

```
Anton_bde3387a94ec468c9418692ce01ec01d_job_d4217b9b_2026-10-15/
├── README.md                   this file
├── job_info.json               job metadata + score stats + submit-gate verdict
├── all_runs.json               per-attempt summary (score, refused, status, file pointers)
├── all_runs.csv                same, flat — one row per attempt, one sub_* column per subscore
├── task_prompt.md              the task prompt the model received
├── grading_config.json         grader type/model + grader guidance + rubric (input grader info)
├── input_files_manifest.json   task_files/ summary + original gs:// references
├── output_files_manifest.json  per-run outputs/ summary + original gs:// references
├── grader_files_manifest.json  grader_files/ summary + original gs:// references
├── task_files/                 the WHOLE task data room — every input file +
│                               reference the writer submitted (extracted from the
│                               /tmp/world volume; original archive in task_files/_source/)
├── grader_files/               the writer's GRADING artifacts (grader-only, NOT
│                               model-facing): golden / reference solution, answer
│                               key & answer spec, grading prompt / spec, verifier
│                               script, and ground-truth values
├── outputs/                    per-attempt model output files (the out_dir),
│                               one folder per attempt: outputs/attempt_NN_<run>/
├── grading/                    full grading record per attempt (score, subscores,
│                               rubric evaluations, the grader's own transcript)
└── transcripts/                Taiga Conversation JSON — ALL 16 attempts
```

## Per-attempt scores

`T&S` = the rollout was blocked by the client's Trust & Safety classifier: void,
not zero.

| att | run | status | score |
| :-: | :-- | :-- | --: |
| 01 | `17ecb7c9` | completed | 0.35 |
| 02 | `f95e6d3d` | completed | 0.35 |
| 03 | `11aee1a4` | completed | 0.28 |
| 04 | `c52981fd` | completed | 0.30 |
| 05 | `b607ea21` | completed | 0.30 |
| 06 | `fd226df5` | completed | 0.30 |
| 07 | `b1bf2f97` | completed | 0.40 |
| 08 | `1587461a` | completed | 0.22 |
| 09 | `a9302945` | completed | 0.38 |
| 10 | `1d405542` | completed | 0.30 |
| 11 | `5bda2349` | completed | 0.38 |
| 12 | `a9687bd9` | completed | 0.30 |
| 13 | `67de5235` | completed | 0.30 |
| 14 | `67f6cb1e` | completed | 0.20 |
| 15 | `de6c6985` | completed | 0.35 |
| 16 | `11109643` | completed | 0.30 |

## Notes

- Anton grading is **agentic** (`agentic_grader`): a single
  normalized score in `[0,1]` with the grader's reasoning. The full record per attempt is
  in `grading/attempt_NN_*.json` (subscores, `metadata.rubric_evaluations`, and
  `metadata.grading_transcript` — the grader's own run). Refused attempts have no record.
- Raw file BYTES are now included. task_files/ holds the full input data room the writer submitted (mounted at /tmp/world for the model); outputs/attempt_NN_*/ holds each run's produced files (the out_dir). The original gs:// references are still listed for provenance. Transcripts (all attempts) and the full grading record (incl. the grader's own transcript and rubric evaluations) are also included.
- grader_files/ holds the writer-authored grading artifacts the grader sees but the model never does — the golden / reference solution, answer key & answer spec, the grading prompt / spec, the verifier script (checker.py / grader.py / verify.py), and ground-truth values. Pulled from the problem version's grader volume (mounted at /tmp/grader_files for the grader). Reuse these to re-derive and audit each run. When a job spans multiple problem versions, files are namespaced by the short version id.
