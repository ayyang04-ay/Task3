We're developing an mRNA seasonal influenza vaccine for heterologous protection. The first round of data is in — an immunogenicity study against Fluarix over the 2022–2023 season — and I need to settle what comes next before the protocol goes to the committee.



Everything the program holds is in the mounted input folder (/tmp/world/filesystem).



Given these data, make your recommendations for the next studies. For each, I need the conditions and the readouts — what's measured, in whom, and against what — sufficient to support the claim we're pursuing.



Put a one-line summary of your recommendation at the top of /tmp/outputs/answer.md, then your reasoning, every number you relied on, and where each came from. Save any analysis you run under /tmp/outputs.



Keep this at the level of study design, specification and interpretation of the data package. I need endpoints, populations, comparators and readouts — not laboratory procedures, assay protocols or anything someone would follow at a bench.
