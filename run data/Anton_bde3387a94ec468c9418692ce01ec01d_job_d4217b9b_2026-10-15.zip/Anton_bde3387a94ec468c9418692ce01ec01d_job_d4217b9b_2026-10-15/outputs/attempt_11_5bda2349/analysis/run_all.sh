#!/usr/bin/env bash
# Re-runs every analysis in order. Inputs: /tmp/world/filesystem (read-only). Outputs: this folder, ../key_numbers.csv, ../wu397_key_findings.png
set -euo pipefail
cd "$(dirname "$0")"
for s in 00_virus_classification.py 01_seqneut_analysis.py 02_hai_mn_analysis.py 03_seqneut_adjusted.py 04_elisa_igm_analysis.py \
         05_late_rises_infection_screen.py 06_durability.py 07_variance_and_sample_size.py 08_binding_vs_function.py \
         09_egg_vs_wildtype_pairs.py 10_seqneut_sensitivity.py 11_baseline_balance_and_integrity.py 12_cellular_descriptive.py \
         14_forward_vaccine_strains.py 13_figure.py; do
  echo "== $s"; micromamba run -n core python "$s" > "logs/${s%.py}.log" 2>&1
done
micromamba run -n core python 15_efficacy_sizing.py > efficacy_sizing.txt
micromamba run -n core python 16_build_number_ledger.py > logs/16.log
micromamba run -n core python 17_ledger_extras.py > logs/17.log
echo done
