"""Append remaining cited numbers (cohort structure, integrity counts, cellular medians, sizing) to key_numbers.csv."""
import pandas as pd, numpy as np
from scipy import stats
F = '/tmp/world/filesystem/'; A = '/tmp/outputs/analysis/'
k = pd.read_csv('/tmp/outputs/key_numbers.csv')
L = []
def add(i, q, v, s, d): L.append(dict(id=i, quantity=q, value=v, source_data=s, derivation=d))
e = pd.read_csv(F + 'elisa_igg_titers.csv'); ids = e[['arm', 'participant']].drop_duplicates()
add('COH-ELISA-IDS', 'ELISA cohort: Fluarix IDs 33-59 / mRNA IDs 64-102 (arm-segregated enrolment blocks)',
    f"Fluarix {int(((ids.arm=='Fluarix')&(ids.participant.between(33,59))).sum())} of 37 in 33-59; mRNA {int(((ids.arm=='mRNA-1010')&(ids.participant>=64)).sum())} of 38 in 64-102; interleaved IDs <=32: 15 F / 14 M",
    'elisa_igg_titers.csv', '04_elisa_igm_analysis.py')
s = pd.read_csv(A + 'seqneut_participant_virus_log2.csv')
r = stats.spearmanr(s.d0, s.log2fc, nan_policy='omit')
add('SEQ-RHO', 'Spearman rho, log2 baseline titre vs log2 fold-rise (all participant x virus pairs)', f"{r.correlation:.3f} (p={r.pvalue:.1e})", 'neutralization_seqbased.csv', '03_seqneut_adjusted.py')
sn = pd.read_csv(F + 'neutralization_seqbased.csv')
add('SEQ-DIM', 'SeqNeut: sera, viruses, rows; censored upper (<=LOD) / lower (>=ULOQ)', f"{sn.serum.nunique()} sera, {sn.virus.nunique()} viruses, {len(sn)} rows; {int((sn.titer_bound=='upper').sum())} / {int((sn.titer_bound=='lower').sum())}", 'neutralization_seqbased.csv', 'direct count')
cls = pd.read_csv(A + 'virus_classification.csv')
add('SEQ-PANEL', 'SeqNeut panel composition: H1 2023-24 / H3 2023-24 / H3 2022 / historical H1 / historical H3 / egg reassortants / vaccine strains-analogs',
    f"{int(((cls.subtype=='H1N1')&(cls.role=='contemporary_2023_24')).sum())} / {int(((cls.subtype=='H3N2')&(cls.role=='contemporary_2023_24')).sum())} / {int((cls.role=='recent_2022').sum())} / {int(((cls.subtype=='H1N1')&(cls.role=='historical_pre2022')).sum())} / {int(((cls.subtype=='H3N2')&(cls.role=='historical_pre2022')).sum())} / {int((cls.role=='egg_reassortant').sum())} / 4; B viruses: 0",
    'neutralization_seqbased.csv', '00_virus_classification.py')
gc = pd.read_csv(F + 'gc_frequencies.csv', dtype={'participant': str}); gc['block'] = np.where(gc.index < len(gc) // 2, 1, 2)
g2 = gc[(gc.block == 1) & (gc.timepoint == 'wk2')].groupby('arm').pct_ha_specific_igg_gc.agg(['median', 'count'])
add('GC-WK2', 'GC HA-specific % at "wk2" (file block 1), median (n) Fluarix vs mRNA', f"{g2.loc['Fluarix','median']:.1f} ({int(g2.loc['Fluarix','count'])}) vs {g2.loc['mRNA-1010','median']:.1f} ({int(g2.loc['mRNA-1010','count'])})", 'gc_frequencies.csv', '12_cellular_descriptive.py')
add('GC-DUP', 'GC file rows sharing an identical (timepoint, arm, participant) key', f"{int(gc.duplicated(['timepoint','arm','participant'], keep=False).sum())} of {len(gc)}", 'gc_frequencies.csv', '11_baseline_balance_and_integrity.py')
pb = pd.read_csv(F + 'plasmablast_frequencies.csv', dtype={'participant': str})
p2 = pb[pb.timepoint == 'wk2'].groupby('arm').pct_plasmablast.agg(['median', 'count'])
add('PB-WK2', 'Plasmablast % at "wk2", median (n) Fluarix vs mRNA', f"{p2.loc['Fluarix','median']:.3f} ({int(p2.loc['Fluarix','count'])}) vs {p2.loc['mRNA-1010','median']:.3f} ({int(p2.loc['mRNA-1010','count'])})", 'plasmablast_frequencies.csv', '12_cellular_descriptive.py')
rc = pd.read_csv(F + 'repertoire_clonotype_counts.csv'); v = rc[rc.metric == 'n_vaccine_elicited_clonotypes']
add('REP-VAX', 'Vaccine-elicited serum IgG clonotypes, median Fluarix vs mRNA (n=8/arm), MWU p',
    f"{v[v.arm=='Fluarix'].value.median():.1f} vs {v[v.arm=='mRNA-1010'].value.median():.1f}, p={stats.mannwhitneyu(v[v.arm=='mRNA-1010'].value, v[v.arm=='Fluarix'].value).pvalue:.3f}", 'repertoire_clonotype_counts.csv', '12_cellular_descriptive.py')
mb = pd.read_csv(F + 'mab_binding_panels.csv'); mb['donor'] = mb.mab_id.str.split('.').str[1]
cnt = mb.drop_duplicates('mab_id').groupby(['arm', 'donor']).size()
add('MAB-N', 'mAbs per arm (donors); largest single-donor share in Fluarix arm',
    f"Fluarix {int(cnt['Fluarix'].sum())} ({len(cnt['Fluarix'])} donors), mRNA {int(cnt['mRNA-1010'].sum())} ({len(cnt['mRNA-1010'])} donors); donor 05 = {int(cnt['Fluarix']['05'])}/{int(cnt['Fluarix'].sum())}", 'mab_binding_panels.csv', '12_cellular_descriptive.py')
im = pd.read_csv(F + 'igm_fold_change.csv', dtype={'participant': str})
add('IGM-N', 'IgM file participants Fluarix / mRNA (summary table states 37 / 38)', f"{im[im.arm=='Fluarix'].participant.nunique()} / {im[im.arm=='mRNA-1010'].participant.nunique()}", 'igm_fold_change.csv', '04_elisa_igm_analysis.py')
med = im.groupby(['antigen', 'arm']).fold_change.median().unstack()
add('IGM-MED', 'IgM fold change median by antigen, Fluarix vs mRNA', '; '.join(f"{a}: {r['Fluarix']:.2f} vs {r['mRNA-1010']:.2f}" for a, r in med.iterrows()), 'igm_fold_change.csv', '04_elisa_igm_analysis.py')
add('IGM-005', 'Fluarix participant 397-005 IgM fold change, 4 antigens', ', '.join(f"{x:.0f}" for x in im[im.participant == '005'].fold_change), 'igm_fold_change.csv', 'direct')
m = pd.read_csv(F + 'microneutralization.csv')
x = m[(m.participant == '397-014') & (m.measure == 'titer')]
add('MN-014', 'Participant 397-014 MN titres (homologous wk0/wk4/wk26; heterologous wk0/wk4/wk26)',
    ' / '.join(str(int(v)) for v in x[x.panel=='homologous'].sort_values('timepoint').value) + ' ; ' + ' / '.join(str(int(v)) for v in x[x.panel=='heterologous'].sort_values('timepoint').value),
    'microneutralization.csv', 'direct (order wk0, wk26, wk4 sorted alphabetically)')
h = pd.read_csv(F + 'hai_titers.csv', dtype={'participant': str})
y = h[h.participant == '014']
add('HAI-014', 'Participant 397-014 HAI wk0 -> wk4: H1N1, H3N2', f"{int(y[(y.antigen=='A/H1N1')&(y.timepoint=='wk0')].hai_titer.iloc[0])} -> {int(y[(y.antigen=='A/H1N1')&(y.timepoint=='wk4')].hai_titer.iloc[0])}; {int(y[(y.antigen=='A/H3N2')&(y.timepoint=='wk0')].hai_titer.iloc[0])} -> {int(y[(y.antigen=='A/H3N2')&(y.timepoint=='wk4')].hai_titer.iloc[0])}", 'hai_titers.csv', 'direct')
add('HAI-BVIC-SWAP', 'Participants whose HAI late-visit label for B/Vic differs from the other 3 antigens', '8 (007, 008, 009, 010, 016, 018, 021, 023)', 'hai_titers.csv', '11_baseline_balance_and_integrity.py')
# minimum detectable ratio
ss = pd.read_csv(A + 'sample_size_inputs.csv')
za = stats.norm.ppf(0.975); zb = stats.norm.ppf(0.8)
mdr = ss.assign(mdr=lambda d: 2 ** ((za + zb) * d.resid_sd_log2 * np.sqrt(2 / 14)))
for _, r in mdr.iterrows():
    add(f'MDR-{r.readout}', f'WU397 minimum detectable GMT ratio (80% power, n=14/arm): {r.readout}', f"{r.mdr:.2f}", 'various', '07_variance_and_sample_size.py')
for p in [0.15, 0.3, 0.4, 0.5]:
    n = int(np.ceil((za + stats.norm.ppf(0.9)) ** 2 * 2 * p * (1 - p) / 0.10 ** 2))
    add(f'SS-SCR-{p}', f'n/arm for HAI seroconversion NI (margin -10 pts, true SCR {p:.0%}, 90% power)', str(n), 'formula', '07_variance_and_sample_size.py')
for line in open(A + 'efficacy_sizing.txt'):
    add('EFF-' + line.split(':')[0].strip(), 'design arithmetic', line.strip(), 'formula', '15_efficacy_sizing.py')
k = pd.concat([k, pd.DataFrame(L)])
k.to_csv('/tmp/outputs/key_numbers.csv', index=False)
pd.set_option('display.width', 300); pd.set_option('display.max_colwidth', 160)
print(pd.DataFrame(L)[['id', 'value']].to_string())

# Study 1 sizing extras (mirrors 07_variance_and_sample_size.py)
k = pd.read_csv('/tmp/outputs/key_numbers.csv')
sd = ss.loc[ss.readout == 'SeqNeut H3N2 contemporary panel mean, d29', 'resid_sd_log2'].iloc[0] * 1.2
n_infl = int(np.ceil(2 * (za + stats.norm.ppf(0.9)) ** 2 * sd ** 2 / np.log2(1.3) ** 2))
bba = pd.read_csv(A + 'binding_breadth_arm_comparison.csv')
h3 = bba[bba.subtype == 'H3'].fold_diff; h1 = bba[bba.subtype == 'H1'].fold_diff
rng = '%.2f-%.2f; %.2f-%.2f' % (h3.min(), h3.max(), h1.min(), h1.max())
extra = pd.DataFrame([
    dict(id='SS-INFL', quantity='n/arm, 1.3x superiority on H3 panel, 90% power, residual SD inflated 20%', value=str(n_infl), source_data='neutralization_seqbased.csv', derivation='07_variance_and_sample_size.py'),
    dict(id='SS-RAND', quantity='randomised per arm per stratum for 200 evaluable with 15% attrition', value=str(int(round(200 / 0.85))), source_data='design assumption', derivation='200/0.85'),
    dict(id='BEAD-RANGE', quantity='Bead-array mean fold difference mRNA/Fluarix, range across strains: H3; H1', value=rng, source_data='binding_breadth_h1.csv, binding_breadth_h3.csv', derivation='08_binding_vs_function.py')])
k = pd.concat([k[~k.id.isin(extra.id)], extra])
k.to_csv('/tmp/outputs/key_numbers.csv', index=False)
print(extra.to_string())
