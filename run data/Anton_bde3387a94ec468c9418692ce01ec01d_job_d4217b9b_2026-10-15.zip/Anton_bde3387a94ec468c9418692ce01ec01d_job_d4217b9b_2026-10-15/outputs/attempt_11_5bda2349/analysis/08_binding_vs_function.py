"""Binding breadth (bead array, log2 fold change MFI) vs functional neutralisation (seq-neut log2 fold change d29/d0)
for the same strains and participants.  Sources: binding_breadth_h1.csv, binding_breadth_h3.csv, neutralization_seqbased.csv
"""
import pandas as pd, numpy as np
from scipy import stats
import statsmodels.formula.api as smf
pd.set_option('display.width', 250); pd.set_option('display.max_columns', 60); pd.set_option('display.max_rows', 200)
b1 = pd.read_csv('/tmp/world/filesystem/binding_breadth_h1.csv'); b1['subtype'] = 'H1'
b3 = pd.read_csv('/tmp/world/filesystem/binding_breadth_h3.csv'); b3['subtype'] = 'H3'
b = pd.concat([b1, b3])
# per-strain arm comparison
rows = []
for (st, strain), g in b.groupby(['subtype', 'strain']):
    F = g[g.arm == 'Fluarix'].log2_fold_change_mfi; M = g[g.arm == 'mRNA-1010'].log2_fold_change_mfi
    rows.append(dict(subtype=st, strain=strain, median_F=F.median(), median_M=M.median(), mean_diff_log2=M.mean() - F.mean(),
                     fold_diff=2 ** (M.mean() - F.mean()), MWU_p=stats.mannwhitneyu(M, F).pvalue))
bs = pd.DataFrame(rows)
bs['year'] = bs.strain.str.extract(r'/(\d{4})$').astype(int)
bs = bs.sort_values(['subtype', 'year'])
bs.to_csv('/tmp/outputs/analysis/binding_breadth_arm_comparison.csv', index=False)
print(bs.round(3).to_string())

# binding vs neutralisation, matched strains
s = pd.read_csv('/tmp/outputs/analysis/seqneut_participant_virus_log2.csv')
pairs = {'A/Darwin/6/2021': 'A/Darwin/6/2021_H3N2', 'A/Thailand/8/2022': 'A/Thailand/8/2022_H3N2',
         'A/Cambodia/e0826360/2020': 'A/Cambodia/e0826360/2020_H3N2', 'A/Hong Kong/2671/2019': 'A/HongKong/2671/2019_H3N2',
         'A/Texas/50/2012': 'A/Texas/50/2012_H3N2', 'A/Singapore/INFIMH-16-0019/2016': 'A/Singapore/INFIMH-16-0019/2016_H3N2',
         'A/Wisconsin/67/2022': 'A/Wisconsin/67/2022_H1N1', 'A/Wisconsin/588/2019': 'A/Wisconsin/588/2019_H1N1',
         'A/Michigan/45/2015': 'A/Michigan/45/2015_H1N1', 'A/Brisbane/2/2018': 'A/Brisbane/02/2018_H1N1', 'A/Hawaii/70/2019': 'A/Hawaii/70/2019_H1N1'}
rows = []
for bstrain, nvirus in pairs.items():
    bb = b[b.strain == bstrain][['arm', 'participant', 'log2_fold_change_mfi']].rename(columns={'participant': 'pid'})
    nn = s[s.virus == nvirus][['arm', 'pid', 'log2fc']]
    j = bb.merge(nn, on=['arm', 'pid']).dropna()
    j['mrna'] = (j.arm == 'mRNA-1010').astype(int)
    # functional yield: neut fold-change per unit binding fold-change -> difference (neut - binding) on log2 scale
    j['neut_minus_bind'] = j.log2fc - j.log2_fold_change_mfi
    F = j[j.mrna == 0]; M = j[j.mrna == 1]
    rows.append(dict(strain=bstrain, n=len(j),
                     bind_diff_M_minus_F=M.log2_fold_change_mfi.mean() - F.log2_fold_change_mfi.mean(),
                     neut_diff_M_minus_F=M.log2fc.mean() - F.log2fc.mean(),
                     neut_minus_bind_F=F.neut_minus_bind.mean(), neut_minus_bind_M=M.neut_minus_bind.mean(),
                     p_neut_minus_bind=stats.mannwhitneyu(M.neut_minus_bind, F.neut_minus_bind).pvalue,
                     spearman_bind_vs_neut=stats.spearmanr(j.log2_fold_change_mfi, j.log2fc).correlation))
bv = pd.DataFrame(rows)
bv.to_csv('/tmp/outputs/analysis/binding_vs_neutralisation.csv', index=False)
print('\nBinding vs neutralisation (log2 fold-change; M=mRNA-1010, F=Fluarix)'); print(bv.round(3).to_string())
