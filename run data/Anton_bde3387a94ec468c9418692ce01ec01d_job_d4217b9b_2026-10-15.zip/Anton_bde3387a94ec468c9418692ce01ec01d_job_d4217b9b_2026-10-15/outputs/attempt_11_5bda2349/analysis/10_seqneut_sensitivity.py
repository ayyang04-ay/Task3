"""Sensitivity analyses for the seq-neut arm comparison:
 (a) censoring imputation: 'upper' (<= LOD) values at reported value instead of half;
 (b) late visit restricted to d181 only;
 (c) H3N2 contemporary strains stratified by antigenic escape (overall d29 GMT tertile across all sera) -
     does any mRNA advantage concentrate in the most escaped (lowest-titre) strains?
"""
import pandas as pd, numpy as np
from scipy import stats
import statsmodels.formula.api as smf
pd.set_option('display.width', 250); pd.set_option('display.max_columns', 60); pd.set_option('display.max_rows', 200)
d = pd.read_csv('/tmp/world/filesystem/neutralization_seqbased.csv')
cls = pd.read_csv('/tmp/outputs/analysis/virus_classification.csv')
d = d.merge(cls, on='virus')
d['arm'] = d.serum.str.split('_').str[0]; d['pid'] = d.serum.str.split('_').str[1]; d['day'] = d.serum.str.split('_').str[2]
def run(mode, late_days=('d121', 'd181')):
    t = d.titer.copy()
    if mode == 'half':
        t[d.titer_bound == 'upper'] = d.titer[d.titer_bound == 'upper'] / 2
    d['l'] = np.log2(t)
    w = d.pivot_table(index=['arm', 'pid', 'virus', 'subtype', 'role'], columns='day', values='l').reset_index()
    late = None
    for ld in late_days[::-1]:
        late = w[ld] if late is None else late.fillna(w[ld])
    w['late'] = late
    w['mrna'] = (w.arm == 'mRNA-1010').astype(int)
    res = []
    for st in ['H1N1', 'H3N2']:
        g = w[(w.role == 'contemporary_2023_24') & (w.subtype == st)].groupby(['pid', 'mrna'])[['d0', 'd29', 'late']].mean().reset_index()
        f = smf.ols('d29 ~ mrna + d0', data=g).fit(); lo, hi = f.conf_int().loc['mrna']
        gl = g.dropna(subset=['late'])
        fl = smf.ols('late ~ mrna + d0', data=gl).fit(); lol, hil = fl.conf_int().loc['mrna']
        res.append(dict(mode=mode, late_days='+'.join(late_days), subtype=st, adj_d29=2 ** f.params['mrna'], d29_lo=2 ** lo, d29_hi=2 ** hi,
                        adj_late=2 ** fl.params['mrna'], late_lo=2 ** lol, late_hi=2 ** hil, n_late=len(gl)))
    return pd.DataFrame(res), w
r1, w_half = run('half')
r2, _ = run('asis')
r3, _ = run('half', late_days=('d181',))
r = pd.concat([r1, r2, r3])
r.to_csv('/tmp/outputs/analysis/seqneut_sensitivity.csv', index=False)
print(r.round(3).to_string())

# (c) escape tertiles among H3N2 contemporary viruses
w = w_half
c = w[(w.role == 'contemporary_2023_24') & (w.subtype == 'H3N2')]
vg = c.groupby('virus').d29.mean().rename('mean_log2_d29_allsera')
terc = pd.qcut(vg, 3, labels=['most_escaped(lowest titre)', 'middle', 'least_escaped'])
c = c.merge(terc.rename('escape_tertile'), left_on='virus', right_index=True)
rows = []
for tt, g in c.groupby('escape_tertile', observed=True):
    p = g.groupby(['pid', 'mrna'])[['d0', 'd29']].mean().reset_index()
    f = smf.ols('d29 ~ mrna + d0', data=p).fit(); lo, hi = f.conf_int().loc['mrna']
    rows.append(dict(tertile=tt, n_viruses=g.virus.nunique(), GMT_d29_allsera=2 ** g.d29.mean(), adj_ratio=2 ** f.params['mrna'], lo=2 ** lo, hi=2 ** hi, p=f.pvalues['mrna']))
et = pd.DataFrame(rows)
et.to_csv('/tmp/outputs/analysis/seqneut_H3_escape_tertiles.csv', index=False)
print(et.round(3).to_string())
# the five lowest-titre (most escaped) H3N2 strains individually
pv = pd.read_csv('/tmp/outputs/analysis/seqneut_per_virus_ancova.csv')
low = vg.sort_values().head(8)
print(pv[pv.virus.isin(low.index)][['virus', 'adj_ratio', 'lo', 'hi', 'p']].round(3).to_string())
print(low.apply(lambda x: 2 ** x).round(1))
