"""(1) Baseline (pre-vaccination) balance between arms across assays - non-randomised allocation check.
   (2) Data-integrity checks across files: cohort sizes vs trial_summary, visit assignment consistency,
       ID formatting, duplicated keys, timepoints vs protocol schedule."""
import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width', 250); pd.set_option('display.max_columns', 60); pd.set_option('display.max_rows', 300)
F = '/tmp/world/filesystem/'
rows = []
def gmr_ci(a, b):
    a = np.log2(a); b = np.log2(b)
    diff = b.mean() - a.mean(); va = a.var(ddof=1) / len(a); vb = b.var(ddof=1) / len(b); se = np.sqrt(va + vb)
    df = (va + vb) ** 2 / (va ** 2 / (len(a) - 1) + vb ** 2 / (len(b) - 1)); t = stats.t.ppf(0.975, df)
    return 2 ** diff, 2 ** (diff - t * se), 2 ** (diff + t * se), stats.mannwhitneyu(b, a).pvalue
h = pd.read_csv(F + 'hai_titers.csv', dtype={'participant': str})
for ag, g in h[h.timepoint == 'wk0'].groupby('antigen'):
    r = gmr_ci(g[g.arm == 'Fluarix'].hai_titer, g[g.arm == 'mRNA-1010'].hai_titer)
    rows.append(dict(assay='HAI', target=ag, ratio_mRNA_over_Flu=r[0], lo=r[1], hi=r[2], MWU_p=r[3]))
m = pd.read_csv(F + 'microneutralization.csv')
for pn, g in m[(m.timepoint == 'wk0') & (m.measure == 'titer')].groupby('panel'):
    r = gmr_ci(g[g.arm == 'Fluarix'].value, g[g.arm == 'mRNA-1010'].value)
    rows.append(dict(assay='MN', target=pn, ratio_mRNA_over_Flu=r[0], lo=r[1], hi=r[2], MWU_p=r[3]))
e = pd.read_csv(F + 'elisa_igg_titers.csv')
for ag, g in e[(e.timepoint == 'wk0') & (e.measure == 'ec50')].groupby('antigen'):
    r = gmr_ci(g[g.arm == 'Fluarix'].value, g[g.arm == 'mRNA-1010'].value)
    rows.append(dict(assay='ELISA IgG', target=ag, ratio_mRNA_over_Flu=r[0], lo=r[1], hi=r[2], MWU_p=r[3]))
s = pd.read_csv('/tmp/outputs/analysis/seqneut_participant_virus_log2.csv')
s['cat'] = np.where(s.role == 'contemporary_2023_24', s.subtype + '_contemporary', np.where(s.role == 'historical_pre2022', s.subtype + '_historical', s.role))
for k, g in s.groupby('cat'):
    p = g.groupby(['arm', 'pid']).d0.mean().reset_index()
    r = gmr_ci(2 ** p[p.arm == 'Fluarix'].d0, 2 ** p[p.arm == 'mRNA-1010'].d0)
    rows.append(dict(assay='SeqNeut (participant mean)', target=k, ratio_mRNA_over_Flu=r[0], lo=r[1], hi=r[2], MWU_p=r[3]))
bb = pd.DataFrame(rows)
bb.to_csv('/tmp/outputs/analysis/baseline_balance.csv', index=False)
print('Baseline GMT ratio mRNA/Fluarix'); print(bb.round(3).to_string())

print('\n==== Integrity checks')
# cohort sizes
def n_by_arm(df, col='participant'):
    return df.groupby('arm')[col].nunique().to_dict()
print('HAI n:', n_by_arm(h), '| MN n:', n_by_arm(m), '| ELISA n:', n_by_arm(e))
im = pd.read_csv(F + 'igm_fold_change.csv', dtype={'participant': str}); print('IgM n:', n_by_arm(im), '(summary says ELISA/IgM cohort 38/37)')
for f in ['binding_breadth_h1.csv', 'binding_breadth_h3.csv']:
    print(f, n_by_arm(pd.read_csv(F + f)))
sn = pd.read_csv(F + 'neutralization_seqbased.csv'); sn['arm'] = sn.serum.str.split('_').str[0]; sn['pid'] = sn.serum.str.split('_').str[1]; sn['day'] = sn.serum.str.split('_').str[2]
print('SeqNeut n:', sn.groupby('arm').pid.nunique().to_dict())
gc = pd.read_csv(F + 'gc_frequencies.csv', dtype={'participant': str}); pb = pd.read_csv(F + 'plasmablast_frequencies.csv', dtype={'participant': str})
print('GC n:', n_by_arm(gc), ' timepoints:', sorted(gc.timepoint.unique()), '(protocol FNA: wk1,2,4,8,17,26)')
print('PB n:', n_by_arm(pb), ' timepoints:', sorted(pb.timepoint.unique()), '(protocol blood: d0,d7,d29,d121,d181)')
dup = gc.duplicated(['timepoint', 'arm', 'participant'], keep=False)
print('GC file: rows sharing (timepoint, arm, participant) key:', int(dup.sum()), 'of', len(gc))
x = gc[dup].groupby(['timepoint', 'arm', 'participant']).pct_ha_specific_igg_gc.apply(list)
print(x.head(8))
# HAI participants present in one cohort but not the other
hai_ids = set(h.participant.map(lambda p: '397-' + p)); sn_ids = set(sn.pid)
print('In HAI/MN cohort but absent from SeqNeut:', sorted(hai_ids - sn_ids))
# late visit assignment consistency
hv = h[h.timepoint.isin(['wk17', 'wk26'])].groupby(['participant', 'antigen']).timepoint.first().unstack()
incons = hv[hv.nunique(axis=1) > 1]
print('HAI participants whose late visit label differs by antigen:'); print(incons)
mv = m[(m.measure == 'titer') & m.timepoint.isin(['wk17', 'wk26'])].groupby(['participant']).timepoint.first()
sv = sn[sn.day.isin(['d121', 'd181'])].groupby('pid').day.first().map({'d121': 'wk17', 'd181': 'wk26'})
ev = e[(e.measure == 'ec50') & e.timepoint.isin(['wk17', 'wk26'])].groupby('participant').timepoint.first()
ev.index = ['397-%03d' % i for i in ev.index]
comp = pd.DataFrame({'MN': mv, 'SeqNeut': sv, 'ELISA': ev})
hv2 = hv.copy(); hv2.index = ['397-' + i for i in hv2.index]
comp = comp.join(hv2.add_prefix('HAI_'))
comp = comp.dropna(subset=['MN'])
comp['consistent'] = comp.apply(lambda r: r.dropna().nunique() == 1, axis=1)
print('\nLate-visit label by assay (participants in HAI/MN cohort):'); print(comp.to_string())
print('B/Vic HAI: mRNA participants present:', sorted(h[(h.antigen == 'B/Vic') & (h.arm == 'mRNA-1010')].participant.unique()))
print('Malformed virus names:', [v for v in sn.virus.unique() if '202023' in v])
print('PB-GC overlap IDs (2-digit):', pd.read_csv(F + 'pb_gc_clonal_overlap.csv').Participant.tolist())
