"""Classify the 96 viruses in the sequencing-based neutralisation panel.
Categories are assigned from the virus name only (year, subtype, reassortant designation)
and from the vaccine compositions:
  mRNA-1010 (per trial_summary.md): H1 A/Victoria/4897/2022; H3 A/Darwin/6/2021; B/Austria/1359417/2021; B/Phuket/3073/2013
  Fluarix 2022-23 NH (per licensed label / WHO 2022-23 egg-based recommendation):
      H1 A/Victoria/2570/2019 (IVR-215); H3 A/Darwin/9/2021 (SAN-010); B/Austria/1359417/2021; B/Phuket/3073/2013
"""
import pandas as pd, re
d = pd.read_csv('/tmp/world/filesystem/neutralization_seqbased.csv')
viruses = sorted(d.virus.unique())
rows = []
egg_pat = re.compile(r'(egg|IVR-\d+|NIB-\d+|X-\d+[A-Z]?)_')
for v in viruses:
    subtype = v.split('_')[-1]
    name = v.rsplit('_', 1)[0]
    m = re.search(r'/(\d{4,6})(egg|X-\d+[A-Z]?|NIB-\d+)?(_IVR-\d+)?$', name)
    yr = re.search(r'/(\d{4})\d*(?:egg|X-\d+[A-Z]?|NIB-\d+)?(?:_IVR-\d+)?$', name)
    year = int(yr.group(1)) if yr else None
    if year == 2020 and 'SOUTHAFRICA/R07876/202023' in v:
        year = 2023   # malformed year field '202023' in source name; treated as 2023
    egg = bool(egg_pat.search(v + '_')) or 'IVR-' in v
    rows.append(dict(virus=v, subtype=subtype, year=year, egg_reassortant=egg))
c = pd.DataFrame(rows)
# fix year parse for the malformed name explicitly
c.loc[c.virus.str.contains('202023'), 'year'] = 2023

def role(r):
    v = r.virus
    if r.egg_reassortant:
        return 'egg_reassortant'
    if v.startswith('A/Darwin/6/2021'):
        return 'mRNA_vaccine_strain_H3'
    if v.startswith('A/Darwin/9/2021'):
        return 'Fluarix_vaccine_strain_H3'
    if v.startswith('A/Wisconsin/67/2022'):
        return 'mRNA_H1_cell_analog'      # cell-based counterpart of A/Victoria/4897/2022 (WHO 2023-24)
    if v.startswith('A/Wisconsin/588/2019'):
        return 'Fluarix_H1_cell_analog'   # cell-based counterpart of A/Victoria/2570/2019 (WHO 2022-23)
    if r.year is not None and r.year >= 2023:
        return 'contemporary_2023_24'
    if r.year == 2022:
        return 'recent_2022'
    return 'historical_pre2022'
c['role'] = c.apply(role, axis=1)
c.to_csv('/tmp/outputs/analysis/virus_classification.csv', index=False)
print(c.groupby(['subtype', 'role']).size())
print(c[c.role.isin(['egg_reassortant','mRNA_vaccine_strain_H3','Fluarix_vaccine_strain_H3','mRNA_H1_cell_analog','Fluarix_H1_cell_analog','recent_2022','historical_pre2022'])].to_string())
