"""Summary figure for the committee: /tmp/outputs/wu397_key_findings.png"""
import pandas as pd, numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
pv = pd.read_csv('/tmp/outputs/analysis/seqneut_per_virus_ancova.csv')
order = [('H1N1', 'historical_pre2022', 'H1 historical'), ('H1N1', 'Fluarix_H1_cell_analog', 'H1 Fluarix-strain analog\n(Wisconsin/588/2019)'),
         ('H1N1', 'mRNA_H1_cell_analog', 'H1 mRNA-strain analog\n(Wisconsin/67/2022)'), ('H1N1', 'contemporary_2023_24', 'H1 2023-24 circulating'),
         ('H3N2', 'historical_pre2022', 'H3 historical'), ('H3N2', 'Fluarix_vaccine_strain_H3', 'H3 Fluarix strain\n(Darwin/9/2021, egg)'),
         ('H3N2', 'mRNA_vaccine_strain_H3', 'H3 mRNA strain\n(Darwin/6/2021)'), ('H3N2', 'recent_2022', 'H3 2022'),
         ('H3N2', 'contemporary_2023_24', 'H3 2023-24 circulating'), (None, 'egg_reassortant', 'egg reassortants')]
fig, axes = plt.subplots(1, 3, figsize=(19, 7.5), gridspec_kw={'width_ratios': [1.5, 1, 1]})
ax = axes[0]
rng = np.random.default_rng(1)
labels = []
for i, (st, role, lab) in enumerate(order):
    g = pv[(pv.role == role) & ((pv.subtype == st) if st else True)]
    x = np.log2(g.adj_ratio.values)
    jitter = rng.uniform(-0.18, 0.18, len(x))
    col = 'tab:blue' if (st == 'H1N1') else ('tab:red' if st == 'H3N2' else 'grey')
    ax.scatter(x, i + jitter, s=14, alpha=0.6, color=col)
    ax.plot([np.median(x)] * 2, [i - 0.3, i + 0.3], color='k', lw=2.5)
    labels.append(f'{lab} (n={len(x)})')
ax.axvline(0, color='k', ls='--', lw=0.8)
ax.set_yticks(range(len(order))); ax.set_yticklabels(labels, fontsize=9)
ax.set_xticks(np.log2([0.5, 0.75, 1, 1.5, 2, 3])); ax.set_xticklabels(['0.5', '0.75', '1', '1.5', '2', '3'])
ax.set_xlabel('Day-29 neutralising GMT ratio, mRNA-1010 / Fluarix\n(baseline-adjusted, per virus; bar = category median)')
ax.set_title('A. Sequencing-based neutralisation, 96 viruses\n(13 mRNA vs 14 Fluarix participants; non-randomised)', fontsize=10)
ax.invert_yaxis()
# panel B binding vs neut
bv = pd.read_csv('/tmp/outputs/analysis/binding_vs_neutralisation.csv')
ax = axes[1]
y = np.arange(len(bv))
ax.barh(y - 0.2, bv.bind_diff_M_minus_F, height=0.38, color='tab:orange', label='binding (bead array) log2 FC, mRNA − Fluarix')
ax.barh(y + 0.2, bv.neut_diff_M_minus_F, height=0.38, color='tab:green', label='neutralisation log2 FC, mRNA − Fluarix')
ax.set_yticks(y); ax.set_yticklabels(bv.strain, fontsize=9); ax.axvline(0, color='k', lw=0.8)
ax.set_xlabel('difference in mean log2 fold-rise (mRNA − Fluarix)')
ax.set_title('B. Binding gain does not translate into\nneutralisation for H3 (same participants, same strains)', fontsize=10)
ax.legend(fontsize=8, loc='lower right'); ax.invert_yaxis()
# panel C durability
ax = axes[2]
dur = pd.read_csv('/tmp/outputs/analysis/seqneut_durability_category.csv').set_index('category')
hai = pd.read_csv('/tmp/outputs/analysis/hai_arm_comparison.csv').set_index('antigen')
hdur = pd.read_csv('/tmp/outputs/analysis/hai_durability.csv').set_index('antigen')
items = [('SeqNeut H1 2023-24 panel', dur.loc['H1N1_contemporary_2023_24', 'adj_d29_ratio'], dur.loc['H1N1_contemporary_2023_24', 'adj_late_ratio']),
         ('SeqNeut H3 2023-24 panel', dur.loc['H3N2_contemporary_2023_24', 'adj_d29_ratio'], dur.loc['H3N2_contemporary_2023_24', 'adj_late_ratio']),
         ('SeqNeut H1 Wisconsin/588/2019', dur.loc['A/Wisconsin/588/2019_H1N1', 'adj_d29_ratio'], dur.loc['A/Wisconsin/588/2019_H1N1', 'adj_late_ratio']),
         ('SeqNeut H3 Darwin/6/2021', dur.loc['A/Darwin/6/2021_H3N2', 'adj_d29_ratio'], dur.loc['A/Darwin/6/2021_H3N2', 'adj_late_ratio']),
         ('HAI H1N1', hai.loc['A/H1N1', 'adj_wk4_GMT_ratio'], hdur.loc['A/H1N1', 'adj_late_ratio']),
         ('HAI H3N2', hai.loc['A/H3N2', 'adj_wk4_GMT_ratio'], hdur.loc['A/H3N2', 'adj_late_ratio'])]
for i, (lab, a, b) in enumerate(items):
    ax.plot([0, 1], [a, b], marker='o', label=lab)
ax.axhline(1, color='k', ls='--', lw=0.8); ax.set_yscale('log', base=2)
ax.set_yticks([0.5, 0.75, 1, 1.5, 2, 2.5]); ax.set_yticklabels(['0.5', '0.75', '1', '1.5', '2', '2.5'])
ax.set_xticks([0, 1]); ax.set_xticklabels(['week 4 (d29)', 'week 17/26']); ax.set_xlim(-0.2, 1.2)
ax.set_ylabel('baseline-adjusted GMT ratio, mRNA-1010 / Fluarix')
ax.set_title('C. The only functional advantage (H1) is gone\nby week 17/26', fontsize=10)
ax.legend(fontsize=8, loc='upper right')
plt.tight_layout()
plt.savefig('/tmp/outputs/wu397_key_findings.png', dpi=150)
print('saved')
