"""ELISA IgG (elisa_igg_titers.csv) and IgM fold change (igm_fold_change.csv).
Checks: reported fold_change vs recomputed wk4/wk0; arm comparison with baseline adjustment;
IgM cohort size vs summary table; outliers."""
import pandas as pd, numpy as np
from scipy import stats
import statsmodels.formula.api as smf
pd.set_option('display.width', 250); pd.set_option('display.max_columns', 60); pd.set_option('display.max_rows', 500)
e = pd.read_csv('/tmp/world/filesystem/elisa_igg_titers.csv')
ec = e[e.measure == 'ec50'].pivot_table(index=['antigen', 'arm', 'participant'], columns='timepoint', values='value').reset_index()
fc = e[e.measure == 'fold_change'].pivot_table(index=['antigen', 'arm', 'participant'], columns='timepoint', values='value').reset_index()
fc.columns = ['antigen', 'arm', 'participant', 'fc_late_rep', 'fc4_rep']
x = ec.merge(fc, on=['antigen', 'arm', 'participant'])
x['late'] = x.wk26.fillna(x.wk17)
x['fc4_calc'] = x.wk4 / x.wk0
x['fclate_calc'] = x.late / x.wk0
bad4 = (np.abs(np.log2(x.fc4_calc / x.fc4_rep)) > 0.05)
badl = (np.abs(np.log2(x.fclate_calc / x.fc_late_rep)) > 0.05)
print('ELISA fold-change rows inconsistent with ec50 ratio: wk4', int(bad4.sum()), ' late', int(badl.sum()), 'of', len(x))
if bad4.sum() or badl.sum():
    print(x[bad4 | badl].head(20).to_string())
x.to_csv('/tmp/outputs/analysis/elisa_wide.csv', index=False)
rows = []
for ag, g in x.groupby('antigen'):
    F = g[g.arm == 'Fluarix']; M = g[g.arm == 'mRNA-1010']
    gg = g.copy(); gg['l0'] = np.log2(gg.wk0); gg['l4'] = np.log2(gg.wk4); gg['mrna'] = (gg.arm == 'mRNA-1010').astype(int)
    fit = smf.ols('l4 ~ mrna + l0', data=gg).fit()
    b = fit.params['mrna']; lo, hi = fit.conf_int().loc['mrna']
    gl = gg.dropna(subset=['late']).copy(); gl['ll'] = np.log2(gl.late)
    fitl = smf.ols('ll ~ mrna + l0', data=gl).fit()
    bl = fitl.params['mrna']; lol, hil = fitl.conf_int().loc['mrna']
    rows.append(dict(antigen=ag, nF=len(F), nM=len(M),
                     GMT0_F=2 ** np.log2(F.wk0).mean(), GMT0_M=2 ** np.log2(M.wk0).mean(),
                     GMT4_F=2 ** np.log2(F.wk4).mean(), GMT4_M=2 ** np.log2(M.wk4).mean(),
                     GMFR4_F=2 ** np.log2(F.fc4_rep).mean(), GMFR4_M=2 ** np.log2(M.fc4_rep).mean(),
                     adj_wk4_ratio=2 ** b, lo=2 ** lo, hi=2 ** hi, p=fit.pvalues['mrna'],
                     GMFRlate_F=2 ** np.log2(F.fc_late_rep).mean(), GMFRlate_M=2 ** np.log2(M.fc_late_rep).mean(),
                     adj_late_ratio=2 ** bl, lo_late=2 ** lol, hi_late=2 ** hil))
es = pd.DataFrame(rows)
es.to_csv('/tmp/outputs/analysis/elisa_arm_comparison.csv', index=False)
print(es.round(3).to_string())
# enrolment-order pattern
ids = e[['arm', 'participant']].drop_duplicates().sort_values('participant')
print('\nParticipant ID ranges by arm (ELISA cohort):')
for arm, g in ids.groupby('arm'):
    print(arm, 'n=', len(g), 'IDs<=32:', int((g.participant <= 32).sum()), 'IDs 33-59:', int(((g.participant >= 33) & (g.participant <= 59)).sum()), 'IDs>=60:', int((g.participant >= 60).sum()))
# does the extended cohort (IDs>32) differ from the core cohort?
x['core'] = x.participant <= 32
print('\nELISA wk4 GMFR by arm and core (IDs<=32, = HAI/MN cohort) vs extended cohort:')
print(x.groupby(['antigen', 'arm', 'core']).fc4_rep.apply(lambda s: round(2 ** np.log2(s).mean(), 2)).unstack())
print(x.groupby(['antigen', 'arm', 'core']).wk0.apply(lambda s: round(2 ** np.log2(s).mean(), 0)).unstack())

# IgM
im = pd.read_csv('/tmp/world/filesystem/igm_fold_change.csv', dtype={'participant': str})
print('\nIgM participants per arm:', im.groupby('arm').participant.nunique().to_dict(), '(summary table states 38 mRNA / 37 Fluarix)')
print('IgM participant IDs not zero-padded:', sorted(set(im.participant[im.participant.str.len() < 3])))
print(im.groupby(['antigen', 'arm']).fold_change.agg(['median', lambda s: (s > 1).mean(), 'max']).round(2))
print(im[im.fold_change > 100])
