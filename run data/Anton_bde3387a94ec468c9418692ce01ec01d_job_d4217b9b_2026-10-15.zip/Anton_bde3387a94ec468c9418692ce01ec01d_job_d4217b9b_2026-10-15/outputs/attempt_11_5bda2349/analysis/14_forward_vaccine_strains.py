"""Neutralisation of H3N2 viruses later selected by WHO as vaccine strains because of antigenic drift
(external fact: WHO NH 2024-25 H3N2 = A/Thailand/8/2022 (egg-based), A/Massachusetts/18/2022 (cell-based);
 WHO 2025-26 NH H3N2 cell-based = A/District of Columbia/27/2023; egg-based A/Croatia/10136RV/2023 is only in the mAb panel).
These are the most defensible 'forward heterologous' H3 targets in the package."""
import pandas as pd, numpy as np
import statsmodels.formula.api as smf
w = pd.read_csv('/tmp/outputs/analysis/seqneut_participant_virus_log2.csv')
w['late'] = w['d181'].fillna(w['d121']); w['mrna'] = (w.arm == 'mRNA-1010').astype(int)
fwd = ['A/Thailand/8/2022_H3N2', 'A/Massachusetts/18/2022_H3N2', 'A/DistrictOfColumbia/27/2023_H3N2']
rows = []
for v in fwd + ['ALL_THREE']:
    g = w[w.virus.isin(fwd)] if v == 'ALL_THREE' else w[w.virus == v]
    p = g.groupby(['pid', 'mrna'])[['d0', 'd29', 'late']].mean().reset_index().dropna(subset=['d0', 'd29'])
    f = smf.ols('d29 ~ mrna + d0', data=p).fit(); lo, hi = f.conf_int().loc['mrna']
    pl = p.dropna(subset=['late']); fl = smf.ols('late ~ mrna + d0', data=pl).fit(); lol, hil = fl.conf_int().loc['mrna']
    rows.append(dict(virus=v, nF=int((p.mrna == 0).sum()), nM=int((p.mrna == 1).sum()),
                     GMT_d29_F=2 ** p[p.mrna == 0].d29.mean(), GMT_d29_M=2 ** p[p.mrna == 1].d29.mean(),
                     adj_d29_ratio=2 ** f.params['mrna'], lo=2 ** lo, hi=2 ** hi, p=f.pvalues['mrna'],
                     adj_late_ratio=2 ** fl.params['mrna'], late_lo=2 ** lol, late_hi=2 ** hil))
r = pd.DataFrame(rows); r.to_csv('/tmp/outputs/analysis/seqneut_forward_who_strains.csv', index=False)
pd.set_option('display.width', 250); print(r.round(3).to_string())
