"""Egg-reassortant vs wild-type pairs in the sequencing-based neutralisation panel.
Within-serum log2 titre difference (egg - wild type), by arm and visit; right-censoring counts."""
import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width', 250); pd.set_option('display.max_columns', 60)
d = pd.read_csv('/tmp/world/filesystem/neutralization_seqbased.csv')
d['arm'] = d.serum.str.split('_').str[0]; d['pid'] = d.serum.str.split('_').str[1]; d['day'] = d.serum.str.split('_').str[2]
t = d.titer.where(d.titer_bound != 'upper', d.titer / 2)
d['log2t'] = np.log2(t)
pairs = [('A/Cambodia/e0826360/2020egg_H3N2', 'A/Cambodia/e0826360/2020_H3N2'),
         ('A/HongKong/4801/2014egg_H3N2', 'A/HongKong/4801/2014_H3N2'),
         ('A/Singapore/INFIMH-16-0019/2016X-307A_H3N2', 'A/Singapore/INFIMH-16-0019/2016_H3N2'),
         ('A/Switzerland/9715293/2013NIB-88_H3N2', 'A/Switzerland/9715293/2013_H3N2'),
         ('A/Texas/50/2012X-223A_H3N2', 'A/Texas/50/2012_H3N2'),
         ('A/Victoria/4897/2022_IVR-238_H1N1', 'A/Wisconsin/67/2022_H1N1'),   # egg-based vs cell-based CVV of the same 2023-24 recommendation (not an identical-strain pair)
         ('A/Darwin/9/2021_H3N2', 'A/Darwin/6/2021_H3N2')]                    # egg-based vs cell-based CVV of the same 2022-23 recommendation
rows = []
w = d.pivot_table(index=['arm', 'pid', 'day'], columns='virus', values='log2t')
for egg, wt in pairs:
    x = (w[egg] - w[wt]).dropna().reset_index()
    x.columns = ['arm', 'pid', 'day', 'diff']
    for (arm, day), g in x.groupby(['arm', 'day']):
        if day not in ('d0', 'd29'): continue
        rows.append(dict(egg=egg, wildtype=wt, arm=arm, day=day, n=len(g), mean_fold_egg_over_wt=2 ** g['diff'].mean()))
    nc = d[(d.virus == egg)].titer_bound.eq('lower').sum()
    rows.append(dict(egg=egg, wildtype=wt, arm='all', day='all', n=int(d[d.virus == egg].shape[0]), mean_fold_egg_over_wt=2 ** x['diff'].mean(), right_censored_egg=int(nc),
                     right_censored_wt=int(d[(d.virus == wt)].titer_bound.eq('lower').sum())))
r = pd.DataFrame(rows)
r.to_csv('/tmp/outputs/analysis/egg_vs_wildtype_pairs.csv', index=False)
print(r.round(2).to_string())
