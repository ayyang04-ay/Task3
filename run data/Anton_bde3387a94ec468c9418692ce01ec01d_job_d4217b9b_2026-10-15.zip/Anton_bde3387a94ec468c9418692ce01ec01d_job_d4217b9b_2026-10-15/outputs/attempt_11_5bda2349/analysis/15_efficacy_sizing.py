"""Design arithmetic for the clinical-endpoint studies (illustrative; assumptions stated).
(1) Event-driven relative-efficacy trial, 1:1: events needed D = (1+k)^2/k * (z_{1-a/2}+z_{1-b})^2 / ln(HR)^2, k=1, HR = 1 - rVE.
(2) Controlled human infection, two-proportion comparison (normal approximation, pooled variance under H0)."""
import numpy as np
from scipy import stats
za = stats.norm.ppf(0.975)
out = []
for power in (0.8, 0.9):
    zb = stats.norm.ppf(power)
    for rve in (0.20, 0.25, 0.30, 0.40):
        D = 4 * (za + zb) ** 2 / np.log(1 - rve) ** 2
        out.append(f'rVE {int(rve*100)}%, power {int(power*100)}%: ~{int(np.ceil(D))} cases (both arms combined) of the endpoint in question')
print('\n'.join(out))
def n2p(p1, p2, power=0.8):
    zb = stats.norm.ppf(power); pb = (p1 + p2) / 2
    return int(np.ceil((za * np.sqrt(2 * pb * (1 - pb)) + zb * np.sqrt(p1 * (1 - p1) + p2 * (1 - p2))) ** 2 / (p1 - p2) ** 2))
for p1, p2 in [(0.4, 0.2), (0.4, 0.24), (0.5, 0.3)]:
    print(f'CHIM: comparator attack {p1:.0%} vs mRNA {p2:.0%} (rel. reduction {1-p2/p1:.0%}): n/arm 80% power = {n2p(p1,p2)}, 90% = {n2p(p1,p2,0.9)}')
