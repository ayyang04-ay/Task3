"""Arm comparison of the sequencing-based neutralisation data (neutralization_seqbased.csv).
Censoring: titer_bound=='upper' -> true titre <= reported value (below lower limit); imputed as reported/2 (primary) or reported (sensitivity).
           titer_bound=='lower' -> true titre >= reported value (above upper limit); kept at reported value (conservative).
Unit of analysis: participant. Fold change = d29 / d0 within participant.
"""
import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width', 250); pd.set_option('display.max_columns', 50); pd.set_option('display.max_rows', 500)
d = pd.read_csv('/tmp/world/filesystem/neutralization_seqbased.csv')
cls = pd.read_csv('/tmp/outputs/analysis/virus_classification.csv')
d = d.merge(cls, on='virus', how='left')
d['arm'] = d.serum.str.split('_').str[0]
d['pid'] = d.serum.str.split('_').str[1]
d['day'] = d.serum.str.split('_').str[2]

def impute(df, mode='half'):
    t = df.titer.copy()
    if mode == 'half':
        t[df.titer_bound == 'upper'] = df.titer[df.titer_bound == 'upper'] / 2
    return np.log2(t)

out = {}
for mode in ['half', 'asis']:
    d['log2t'] = impute(d, mode)
    w = d.pivot_table(index=['arm', 'pid', 'virus', 'subtype', 'role'], columns='day', values='log2t').reset_index()
    w['log2fc'] = w['d29'] - w['d0']
    out[mode] = w

w = out['half']
w.to_csv('/tmp/outputs/analysis/seqneut_participant_virus_log2.csv', index=False)

# ---- per-virus summary
rows = []
for (v, st, role), g in w.groupby(['virus', 'subtype', 'role']):
    r = dict(virus=v, subtype=st, role=role)
    for arm in ['Fluarix', 'mRNA-1010']:
        gg = g[g.arm == arm]
        r[f'GMT_d0_{arm}'] = 2 ** gg.d0.mean()
        r[f'GMT_d29_{arm}'] = 2 ** gg.d29.mean()
        r[f'GMFR_{arm}'] = 2 ** gg.log2fc.mean()
        r[f'n_{arm}'] = gg.log2fc.notna().sum()
        r[f'pct4x_{arm}'] = 100 * (gg.log2fc.dropna() >= 2).mean()
    a = g[g.arm == 'Fluarix'].log2fc.dropna(); b = g[g.arm == 'mRNA-1010'].log2fc.dropna()
    r['GMFR_ratio_mRNA_vs_Flu'] = 2 ** (b.mean() - a.mean())
    r['MWU_p_fc'] = stats.mannwhitneyu(b, a).pvalue
    a0 = g[g.arm == 'Fluarix'].d0.dropna(); b0 = g[g.arm == 'mRNA-1010'].d0.dropna()
    r['GMT_d0_ratio_mRNA_vs_Flu'] = 2 ** (b0.mean() - a0.mean())
    r['MWU_p_d0'] = stats.mannwhitneyu(b0, a0).pvalue
    a1 = g[g.arm == 'Fluarix'].d29.dropna(); b1 = g[g.arm == 'mRNA-1010'].d29.dropna()
    r['GMT_d29_ratio_mRNA_vs_Flu'] = 2 ** (b1.mean() - a1.mean())
    r['MWU_p_d29'] = stats.mannwhitneyu(b1, a1).pvalue
    rows.append(r)
pv = pd.DataFrame(rows)
pv.to_csv('/tmp/outputs/analysis/seqneut_per_virus_arm_summary.csv', index=False)
cols = ['virus', 'role', 'n_Fluarix', 'n_mRNA-1010', 'GMT_d0_Fluarix', 'GMT_d0_mRNA-1010', 'GMT_d29_Fluarix', 'GMT_d29_mRNA-1010',
        'GMFR_Fluarix', 'GMFR_mRNA-1010', 'GMFR_ratio_mRNA_vs_Flu', 'MWU_p_fc', 'pct4x_Fluarix', 'pct4x_mRNA-1010']
print(pv[pv.role != 'contemporary_2023_24'][cols].round(2).to_string())
print()
print('Contemporary 2023-24 viruses, summary of per-virus GMFR ratio (mRNA/Fluarix):')
print(pv[pv.role == 'contemporary_2023_24'].groupby('subtype')[['GMFR_Fluarix', 'GMFR_mRNA-1010', 'GMFR_ratio_mRNA_vs_Flu']].describe().T.round(2))
print('n contemporary viruses with MWU p<0.05 by subtype:')
print(pv[pv.role == 'contemporary_2023_24'].groupby('subtype').apply(lambda x: pd.Series({'n': len(x), 'p<0.05': (x.MWU_p_fc < 0.05).sum(), 'ratio>1': (x.GMFR_ratio_mRNA_vs_Flu > 1).sum()}), include_groups=False))
