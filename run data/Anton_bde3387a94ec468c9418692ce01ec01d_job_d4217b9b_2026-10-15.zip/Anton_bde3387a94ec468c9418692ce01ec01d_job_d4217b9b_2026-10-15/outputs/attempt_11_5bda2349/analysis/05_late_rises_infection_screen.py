"""Screen for possible intercurrent infection between week 4 and week 17/26:
a >=4-fold rise in titre from the week-4 (d29) visit to the late visit (d121/d181) in the same participant.
Vaccine-induced titres should wane, not rise, after week 4, so a >=4-fold late rise is a conventional infection flag.
Sources: hai_titers.csv, microneutralization.csv, elisa_igg_titers.csv, neutralization_seqbased.csv
"""
import pandas as pd, numpy as np
pd.set_option('display.width', 250); pd.set_option('display.max_columns', 60); pd.set_option('display.max_rows', 500)
out = []
h = pd.read_csv('/tmp/outputs/analysis/hai_wide.csv', dtype={'participant': str})
h['late_over_wk4'] = h.late / h.wk4
for _, r in h[h.late_over_wk4 >= 4].iterrows():
    out.append(dict(assay='HAI', target=r.antigen, arm=r.arm, participant='397-' + r.participant, wk4=r.wk4, late=r.late, ratio=r.late_over_wk4))
m = pd.read_csv('/tmp/outputs/analysis/mn_wide.csv')
m['late_over_wk4'] = m.late / m.wk4
for _, r in m[m.late_over_wk4 >= 4].iterrows():
    out.append(dict(assay='MN', target=r.panel, arm=r.arm, participant=r.participant, wk4=r.wk4, late=r.late, ratio=r.late_over_wk4))
e = pd.read_csv('/tmp/outputs/analysis/elisa_wide.csv')
e['late_over_wk4'] = e.late / e.wk4
for _, r in e[e.late_over_wk4 >= 4].iterrows():
    out.append(dict(assay='ELISA IgG', target=r.antigen, arm=r.arm, participant='397-%03d' % r.participant, wk4=r.wk4, late=r.late, ratio=r.late_over_wk4))
s = pd.read_csv('/tmp/outputs/analysis/seqneut_participant_virus_log2.csv')
s['late'] = s['d181'].fillna(s['d121'])
s['late_minus_d29'] = s.late - s.d29
flag = s[s.late_minus_d29 >= 2]
agg = flag.groupby(['arm', 'pid', 'subtype']).agg(n_viruses=('virus', 'size'), median_log2_rise=('late_minus_d29', 'median')).reset_index()
tot = s.dropna(subset=['late']).groupby(['arm', 'pid', 'subtype']).virus.size().rename('n_tested').reset_index()
agg = agg.merge(tot, on=['arm', 'pid', 'subtype'])
for _, r in agg.iterrows():
    out.append(dict(assay='SeqNeut', target=f'{r.subtype}: {r.n_viruses}/{r.n_tested} viruses >=4x', arm=r.arm, participant=r.pid, wk4=np.nan, late=np.nan, ratio=2 ** r.median_log2_rise))
o = pd.DataFrame(out)
o.to_csv('/tmp/outputs/analysis/late_rise_infection_flags.csv', index=False)
print(o.to_string())
# participant-level late change distribution for seqneut
pl = s.dropna(subset=['late']).groupby(['arm', 'pid', 'subtype']).late_minus_d29.median().unstack()
print('\nSeqNeut median log2(late/d29) per participant:'); print(pl.round(2))
