"""Durability: arm comparison at the late visit (d121/d181 = wk17/wk26) for seq-neut, HAI, MN.
Participant-level category means for seq-neut; ANCOVA on log2(late) with log2(d0)."""
import pandas as pd, numpy as np
from scipy import stats
import statsmodels.formula.api as smf
pd.set_option('display.width', 250); pd.set_option('display.max_columns', 60)
s = pd.read_csv('/tmp/outputs/analysis/seqneut_participant_virus_log2.csv')
s['late'] = s['d181'].fillna(s['d121'])
s['late_visit'] = np.where(s['d181'].notna(), 'd181', np.where(s['d121'].notna(), 'd121', None))
s['mrna'] = (s.arm == 'mRNA-1010').astype(int)
def cat(row):
    if row.role == 'contemporary_2023_24': return f'{row.subtype}_contemporary_2023_24'
    if row.role == 'egg_reassortant': return 'egg_reassortants'
    if row.role == 'historical_pre2022': return f'{row.subtype}_historical_pre2022'
    if row.role == 'recent_2022': return 'H3N2_2022'
    return row.virus
s['category'] = s.apply(cat, axis=1)
pm = s.groupby(['arm', 'pid', 'mrna', 'category']).agg(d0=('d0', 'mean'), d29=('d29', 'mean'), late=('late', 'mean')).reset_index()
rows = []
for k, g in pm.groupby('category'):
    g = g.dropna(subset=['d0', 'late'])
    F = g[g.mrna == 0]; M = g[g.mrna == 1]
    fit = smf.ols('late ~ mrna + d0', data=g).fit()
    b = fit.params['mrna']; lo, hi = fit.conf_int().loc['mrna']
    g2 = g.dropna(subset=['d29'])
    fit29 = smf.ols('d29 ~ mrna + d0', data=g2).fit()
    rows.append(dict(category=k, nF=len(F), nM=len(M), GMT_late_F=2 ** F.late.mean(), GMT_late_M=2 ** M.late.mean(),
                     late_over_d29_F=2 ** (F.late - F.d29).mean(), late_over_d29_M=2 ** (M.late - M.d29).mean(),
                     adj_d29_ratio=2 ** fit29.params['mrna'],
                     adj_late_ratio=2 ** b, lo=2 ** lo, hi=2 ** hi, p=fit.pvalues['mrna']))
r = pd.DataFrame(rows)
r.to_csv('/tmp/outputs/analysis/seqneut_durability_category.csv', index=False)
print(r.round(3).to_string())
print('\nlate visit mix (participants):')
print(s.drop_duplicates(['arm', 'pid'])[['arm', 'pid', 'late_visit']].groupby(['arm', 'late_visit']).size())

h = pd.read_csv('/tmp/outputs/analysis/hai_wide.csv', dtype={'participant': str})
rows = []
for ag, g in h.groupby('antigen'):
    g = g.dropna(subset=['late']).copy(); g['l0'] = np.log2(g.wk0); g['ll'] = np.log2(g.late); g['mrna'] = (g.arm == 'mRNA-1010').astype(int)
    fit = smf.ols('ll ~ mrna + l0', data=g).fit()
    b = fit.params['mrna']; lo, hi = fit.conf_int().loc['mrna']
    rows.append(dict(antigen=ag, GMT_late_F=2 ** g[g.mrna == 0].ll.mean(), GMT_late_M=2 ** g[g.mrna == 1].ll.mean(),
                     adj_late_ratio=2 ** b, lo=2 ** lo, hi=2 ** hi, p=fit.pvalues['mrna'],
                     SPR_late_F=100 * (g[g.mrna == 0].late >= 40).mean(), SPR_late_M=100 * (g[g.mrna == 1].late >= 40).mean()))
print('\nHAI late (wk17/26)'); hr = pd.DataFrame(rows); print(hr.round(3).to_string())
hr.to_csv('/tmp/outputs/analysis/hai_durability.csv', index=False)
m = pd.read_csv('/tmp/outputs/analysis/mn_wide.csv')
rows = []
for pn, g in m.groupby('panel'):
    g = g.dropna(subset=['late']).copy(); g['l0'] = np.log2(g.wk0); g['ll'] = np.log2(g.late); g['mrna'] = (g.arm == 'mRNA-1010').astype(int)
    fit = smf.ols('ll ~ mrna + l0', data=g).fit()
    b = fit.params['mrna']; lo, hi = fit.conf_int().loc['mrna']
    rows.append(dict(panel=pn, GMT_late_F=2 ** g[g.mrna == 0].ll.mean(), GMT_late_M=2 ** g[g.mrna == 1].ll.mean(),
                     adj_late_ratio=2 ** b, lo=2 ** lo, hi=2 ** hi, p=fit.pvalues['mrna']))
print('\nMN late (wk17/26)'); mr = pd.DataFrame(rows); print(mr.round(3).to_string())
mr.to_csv('/tmp/outputs/analysis/mn_durability.csv', index=False)
