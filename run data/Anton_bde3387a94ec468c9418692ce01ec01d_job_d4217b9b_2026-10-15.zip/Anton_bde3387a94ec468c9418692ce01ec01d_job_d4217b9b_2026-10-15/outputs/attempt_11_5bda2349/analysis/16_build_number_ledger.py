"""Assemble every number cited in answer.md into /tmp/outputs/key_numbers.csv with its source file and derivation."""
import pandas as pd, numpy as np
A = '/tmp/outputs/analysis/'
L = []
def add(id_, what, value, source_file, derivation):
    L.append(dict(id=id_, quantity=what, value=value, source_data=source_file, derivation=derivation))
f2 = lambda x: f'{x:.2f}'
ci = lambda a, b, c: f'{a:.2f} ({b:.2f}-{c:.2f})'
# HAI
hs = pd.read_csv(A + 'hai_summary_by_arm.csv'); hc = pd.read_csv(A + 'hai_arm_comparison.csv').set_index('antigen'); hd = pd.read_csv(A + 'hai_durability.csv').set_index('antigen')
for _, r in hs.iterrows():
    add(f'HAI-GMT4-{r.antigen}-{r.arm}', f'HAI wk4 GMT {r.antigen} {r.arm} (95% CI), n={r.n}', f"{r.GMT_wk4:.1f} ({r.GMT_wk4_lo:.1f}-{r.GMT_wk4_hi:.1f})", 'hai_titers.csv', '02_hai_mn_analysis.py -> hai_summary_by_arm.csv')
    add(f'HAI-GMFR4-{r.antigen}-{r.arm}', f'HAI wk4 GMFR {r.antigen} {r.arm}', f"{r.GMFR_wk4:.2f}", 'hai_titers.csv', '02 -> hai_summary_by_arm.csv')
    add(f'HAI-SCR-{r.antigen}-{r.arm}', f'HAI wk4 seroconversion {r.antigen} {r.arm} (n/N, %)', f"{int(r.SCR_wk4_n)}/{r.n} ({r.SCR_wk4_pct:.1f}%)", 'hai_titers.csv', '02 -> hai_summary_by_arm.csv; SC = pre<10 & post>=40, or pre>=10 & >=4-fold')
    add(f'HAI-SPR0-{r.antigen}-{r.arm}', f'HAI wk0 % >=1:40 {r.antigen} {r.arm}', f"{r.SPR_wk0_pct:.1f}%", 'hai_titers.csv', '02 -> hai_summary_by_arm.csv')
for ag, r in hc.iterrows():
    add(f'HAI-RATIO4-{ag}', f'HAI wk4 GMT ratio mRNA/Fluarix {ag}, unadjusted (95% CI)', ci(r.wk4_GMT_ratio, r.wk4_lo, r.wk4_hi), 'hai_titers.csv', '02 -> hai_arm_comparison.csv (Welch t on log2)')
    add(f'HAI-ADJ4-{ag}', f'HAI wk4 GMT ratio mRNA/Fluarix {ag}, baseline-adjusted (95% CI), p', ci(r.adj_wk4_GMT_ratio, r.adj_lo, r.adj_hi) + f', p={r.adj_p:.3f}', 'hai_titers.csv', '02 -> hai_arm_comparison.csv (ANCOVA log2 wk4 ~ arm + log2 wk0)')
    add(f'HAI-SCRDIFF-{ag}', f'HAI SCR difference mRNA - Fluarix {ag}, percentage points (Newcombe 95% CI)', f"{r.SCR_diff_pct:.1f} ({r.SCR_lo:.1f} to {r.SCR_hi:.1f})", 'hai_titers.csv', '02 -> hai_arm_comparison.csv')
    add(f'HAI-BASE-{ag}', f'HAI wk0 GMT ratio mRNA/Fluarix {ag} (95% CI)', ci(r.wk0_GMT_ratio, r.wk0_lo, r.wk0_hi), 'hai_titers.csv', '02 -> hai_arm_comparison.csv')
for ag, r in hd.iterrows():
    add(f'HAI-LATE-{ag}', f'HAI wk17/26 GMT Fluarix vs mRNA {ag}; adjusted ratio (95% CI)', f"{r.GMT_late_F:.1f} vs {r.GMT_late_M:.1f}; {ci(r.adj_late_ratio, r.lo, r.hi)}", 'hai_titers.csv', '06_durability.py -> hai_durability.csv')
# MN
ms = pd.read_csv(A + 'mn_summary_by_arm.csv'); mc = pd.read_csv(A + 'mn_arm_comparison.csv').set_index('panel'); md = pd.read_csv(A + 'mn_durability.csv').set_index('panel')
for _, r in ms.iterrows():
    add(f'MN-{r.panel}-{r.arm}', f'MN {r.panel} {r.arm}: wk0 GMT, wk4 GMT (95% CI), GMFR, median FC, % >=4-fold, n at 1:1280 ceiling wk0/wk4',
        f"{r.GMT_wk0:.1f}; {r.GMT_wk4:.1f} ({r.GMT_wk4_lo:.1f}-{r.GMT_wk4_hi:.1f}); {r.GMFR_wk4:.2f}; {r.median_fc4:.2f}; {r.pct_4fold_wk4:.1f}%; {int(r.n_at_ceiling_wk0)}/{r.n} & {int(r.n_at_ceiling_wk4)}/{r.n}",
        'microneutralization.csv', '02 -> mn_summary_by_arm.csv')
for pn, r in mc.iterrows():
    add(f'MN-RATIO-{pn}', f'MN {pn} mRNA/Fluarix: wk0 ratio; wk4 ratio; adjusted wk4 ratio (95% CI)',
        f"{ci(r.wk0_GMT_ratio, r.wk0_lo, r.wk0_hi)}; {ci(r.wk4_GMT_ratio, r.wk4_lo, r.wk4_hi)}; {ci(r.adj_wk4_GMT_ratio, r.adj_lo, r.adj_hi)}", 'microneutralization.csv', '02 -> mn_arm_comparison.csv')
for pn, r in md.iterrows():
    add(f'MN-LATE-{pn}', f'MN {pn} wk17/26 adjusted ratio mRNA/Fluarix (95% CI)', ci(r.adj_late_ratio, r.lo, r.hi), 'microneutralization.csv', '06 -> mn_durability.csv')
# seq-neut categories
cs = pd.read_csv(A + 'seqneut_category_participant_level.csv').set_index('category'); du = pd.read_csv(A + 'seqneut_durability_category.csv').set_index('category')
for k, r in cs.iterrows():
    add(f'SEQ-{k}', f'SeqNeut {k}: d0 GMT F vs M; d29 GMT F vs M; GMFR F vs M; adjusted d29 ratio M/F (95% CI), p',
        f"{r.GMT_d0_F:.0f} vs {r.GMT_d0_M:.0f}; {r.GMT_d29_F:.0f} vs {r.GMT_d29_M:.0f}; {r.GMFR_F:.2f} vs {r.GMFR_M:.2f}; {ci(r.adj_d29_ratio, r.adj_lo, r.adj_hi)}, p={r.adj_p:.3f}",
        'neutralization_seqbased.csv', '01/03 -> seqneut_category_participant_level.csv (participant-mean of log2 titres; ANCOVA)')
for k, r in du.iterrows():
    add(f'SEQLATE-{k}', f'SeqNeut {k}: late/d29 GMT fold F vs M; adjusted late ratio M/F (95% CI)',
        f"{r.late_over_d29_F:.2f} vs {r.late_over_d29_M:.2f}; {ci(r.adj_late_ratio, r.lo, r.hi)}", 'neutralization_seqbased.csv', '06 -> seqneut_durability_category.csv')
fw = pd.read_csv(A + 'seqneut_forward_who_strains.csv').set_index('virus')
for k, r in fw.iterrows():
    add(f'SEQFWD-{k}', f'SeqNeut later-WHO-selected H3 strain {k}: adjusted d29 ratio; adjusted late ratio', f"{ci(r.adj_d29_ratio, r.lo, r.hi)}; {ci(r.adj_late_ratio, r.late_lo, r.late_hi)}", 'neutralization_seqbased.csv', '14_forward_vaccine_strains.py')
et = pd.read_csv(A + 'seqneut_H3_escape_tertiles.csv')
for _, r in et.iterrows():
    add(f'SEQESC-{r.tertile}', f'SeqNeut H3 2023-24 escape tertile {r.tertile}: adjusted d29 ratio', ci(r.adj_ratio, r.lo, r.hi), 'neutralization_seqbased.csv', '10_seqneut_sensitivity.py')
se = pd.read_csv(A + 'seqneut_sensitivity.csv')
for _, r in se.iterrows():
    add(f'SEQSENS-{r["mode"]}-{r.late_days}-{r.subtype}', f'SeqNeut contemporary {r.subtype}, censoring={r["mode"]}, late={r.late_days}: adj d29; adj late', f"{ci(r.adj_d29, r.d29_lo, r.d29_hi)}; {ci(r.adj_late, r.late_lo, r.late_hi)}", 'neutralization_seqbased.csv', '10_seqneut_sensitivity.py')
pv = pd.read_csv(A + 'seqneut_per_virus_ancova.csv')
c = pv[pv.role == 'contemporary_2023_24']
for st, g in c.groupby('subtype'):
    add(f'SEQPV-{st}', f'SeqNeut per-virus adjusted d29 ratios, {st} 2023-24: n viruses; median; n with p<0.05', f"{len(g)}; {g.adj_ratio.median():.2f}; {(g.p < 0.05).sum()}", 'neutralization_seqbased.csv', '03 -> seqneut_per_virus_ancova.csv')
from statsmodels.stats.multitest import multipletests
add('SEQPV-BH', 'SeqNeut: viruses with BH-adjusted q<0.05 for arm effect (of 96)', str(int((multipletests(pv.p, method="fdr_bh")[1] < 0.05).sum())), 'neutralization_seqbased.csv', '03')
for v in ['A/Darwin/6/2021_H3N2', 'A/Darwin/9/2021_H3N2', 'A/Wisconsin/588/2019_H1N1', 'A/Wisconsin/67/2022_H1N1']:
    r = pv[pv.virus == v].iloc[0]
    add(f'SEQV-{v}', f'SeqNeut {v}: adjusted d29 ratio M/F (95% CI)', ci(r.adj_ratio, r.lo, r.hi), 'neutralization_seqbased.csv', '03 -> seqneut_per_virus_ancova.csv')
eg = pd.read_csv(A + 'egg_vs_wildtype_pairs.csv'); eg = eg[eg.arm == 'all']
for _, r in eg.iterrows():
    add(f'EGG-{r.egg}', f'Egg/egg-based vs wild-type/cell counterpart ({r.wildtype}): mean within-serum titre fold; right-censored sera egg vs wt', f"{r.mean_fold_egg_over_wt:.2f}; {int(r.right_censored_egg)} vs {int(r.right_censored_wt)}", 'neutralization_seqbased.csv', '09_egg_vs_wildtype_pairs.py')
# binding
bs = pd.read_csv(A + 'binding_breadth_arm_comparison.csv')
for _, r in bs.iterrows():
    add(f'BEAD-{r.strain}', f'Bead-array binding log2 fold-change median Fluarix vs mRNA, {r.strain}; mean fold difference; MWU p', f"{r.median_F:.2f} vs {r.median_M:.2f}; {r.fold_diff:.2f}x; p={r.MWU_p:.4f}", f'binding_breadth_{r.subtype.lower()}.csv', '08_binding_vs_function.py -> binding_breadth_arm_comparison.csv')
bv = pd.read_csv(A + 'binding_vs_neutralisation.csv')
for _, r in bv.iterrows():
    add(f'BVN-{r.strain}', f'{r.strain}: mRNA-minus-Fluarix mean log2 fold-rise, binding vs neutralisation', f"{r.bind_diff_M_minus_F:+.2f} vs {r.neut_diff_M_minus_F:+.2f}", 'binding_breadth_h1/h3.csv + neutralization_seqbased.csv', '08 -> binding_vs_neutralisation.csv')
el = pd.read_csv(A + 'elisa_arm_comparison.csv')
for _, r in el.iterrows():
    add(f'ELISA-{r.antigen}', f'ELISA IgG {r.antigen}: wk4 GMFR F vs M; adjusted wk4 ratio (95% CI); adjusted late ratio (95% CI)', f"{r.GMFR4_F:.2f} vs {r.GMFR4_M:.2f}; {ci(r.adj_wk4_ratio, r.lo, r.hi)}; {ci(r.adj_late_ratio, r.lo_late, r.hi_late)}", 'elisa_igg_titers.csv', '04_elisa_igm_analysis.py -> elisa_arm_comparison.csv')
bb = pd.read_csv(A + 'baseline_balance.csv')
for _, r in bb.iterrows():
    add(f'BASE-{r.assay}-{r.target}', f'Baseline GMT ratio mRNA/Fluarix, {r.assay} {r.target} (95% CI)', ci(r.ratio_mRNA_over_Flu, r.lo, r.hi), 'various', '11_baseline_balance_and_integrity.py -> baseline_balance.csv')
ss = pd.read_csv(A + 'sample_size_inputs.csv')
for _, r in ss.iterrows():
    add(f'SS-{r.readout}', f'{r.readout}: residual SD log2; n/arm for 1.5x sup; 1.3x sup; NI margin 0.67 (90% power)', f"{r.resid_sd_log2:.2f}; {r['n_arm_sup_R1.5_90pct']}; {r['n_arm_sup_R1.3_90pct']}; {r['n_arm_NI_M0.67_90pct']}", 'various', '07_variance_and_sample_size.py')
mab = pd.read_csv(A + 'mab_donor_level_binding.csv')
s = mab.groupby(['antigen', 'arm']).bind.median().unstack()
for ag, r in s.iterrows():
    add(f'MAB-{ag}', f'mAb fraction binding (fold>10) {ag}, donor-level median Fluarix (3 donors) vs mRNA (4 donors)', f"{r['Fluarix']:.2f} vs {r['mRNA-1010']:.2f}", 'mab_binding_panels.csv', '12_cellular_descriptive.py -> mab_donor_level_binding.csv')
pd.DataFrame(L).to_csv('/tmp/outputs/key_numbers.csv', index=False)
print(len(L), 'numbers written')
