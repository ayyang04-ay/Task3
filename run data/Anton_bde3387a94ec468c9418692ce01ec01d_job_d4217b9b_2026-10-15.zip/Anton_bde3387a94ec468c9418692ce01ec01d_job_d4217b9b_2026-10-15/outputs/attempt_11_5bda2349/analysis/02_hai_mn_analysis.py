"""HAI and microneutralisation (MN): GMT, GMFR, seroconversion, seroprotection, baseline balance,
ceiling effects, and baseline-adjusted arm comparison (ANCOVA on log2 post titre with log2 baseline).
Sources: hai_titers.csv, microneutralization.csv
Seroconversion (HAI, regulatory convention): pre <1:10 and post >=1:40, or pre >=1:10 and >=4-fold rise.
Seroprotection (HAI): titre >=1:40.
"""
import pandas as pd, numpy as np
from scipy import stats
import statsmodels.formula.api as smf
pd.set_option('display.width', 250); pd.set_option('display.max_columns', 60); pd.set_option('display.max_rows', 500)

def gmt(x):
    x = np.asarray(x, float); x = x[~np.isnan(x)]
    return 2 ** np.mean(np.log2(x)) if len(x) else np.nan

def gm_ci(x):
    x = np.log2(np.asarray(x, float)); x = x[~np.isnan(x)]
    n = len(x); m = x.mean(); se = x.std(ddof=1) / np.sqrt(n)
    t = stats.t.ppf(0.975, n - 1)
    return 2 ** m, 2 ** (m - t * se), 2 ** (m + t * se)

def ratio_ci(a, b):
    """GMT ratio b/a with Welch t CI on log scale"""
    a = np.log2(np.asarray(a, float)); b = np.log2(np.asarray(b, float))
    a = a[~np.isnan(a)]; b = b[~np.isnan(b)]
    diff = b.mean() - a.mean()
    va = a.var(ddof=1) / len(a); vb = b.var(ddof=1) / len(b)
    se = np.sqrt(va + vb)
    df = (va + vb) ** 2 / (va ** 2 / (len(a) - 1) + vb ** 2 / (len(b) - 1))
    t = stats.t.ppf(0.975, df)
    return 2 ** diff, 2 ** (diff - t * se), 2 ** (diff + t * se)

def newcombe_diff(x1, n1, x2, n2):
    """Difference in proportions p2-p1 with Newcombe hybrid score CI"""
    z = 1.959964
    def wilson(x, n):
        p = x / n; den = 1 + z * z / n
        c = (p + z * z / (2 * n)) / den; h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
        return c - h, c + h
    p1, p2 = x1 / n1, x2 / n2
    l1, u1 = wilson(x1, n1); l2, u2 = wilson(x2, n2)
    d = p2 - p1
    lo = d - np.sqrt((p2 - l2) ** 2 + (u1 - p1) ** 2)
    hi = d + np.sqrt((u2 - p2) ** 2 + (p1 - l1) ** 2)
    return d, lo, hi

# ---------------- HAI
h = pd.read_csv('/tmp/world/filesystem/hai_titers.csv', dtype={'participant': str})
h['late'] = h.timepoint.isin(['wk17', 'wk26'])
w = h.pivot_table(index=['antigen', 'arm', 'participant'], columns='timepoint', values='hai_titer').reset_index()
w['late'] = w['wk26'].fillna(w['wk17'])
w['late_visit'] = np.where(w['wk26'].notna(), 'wk26', np.where(w['wk17'].notna(), 'wk17', None))
w['fr4'] = w.wk4 / w.wk0
w['frlate'] = w.late / w.wk0
w['sc4'] = ((w.wk0 < 10) & (w.wk4 >= 40)) | ((w.wk0 >= 10) & (w.fr4 >= 4))
w['sp0'] = w.wk0 >= 40
w['sp4'] = w.wk4 >= 40
w.to_csv('/tmp/outputs/analysis/hai_wide.csv', index=False)
rows = []
for (ag, arm), g in w.groupby(['antigen', 'arm']):
    r = dict(antigen=ag, arm=arm, n=len(g))
    r['GMT_wk0'], r['GMT_wk0_lo'], r['GMT_wk0_hi'] = gm_ci(g.wk0)
    r['GMT_wk4'], r['GMT_wk4_lo'], r['GMT_wk4_hi'] = gm_ci(g.wk4)
    r['GMT_late'] = gmt(g.late)
    r['n_late'] = g.late.notna().sum()
    r['GMFR_wk4'], r['GMFR_wk4_lo'], r['GMFR_wk4_hi'] = gm_ci(g.fr4)
    r['SCR_wk4_n'] = int(g.sc4.sum()); r['SCR_wk4_pct'] = 100 * g.sc4.mean()
    r['SPR_wk0_pct'] = 100 * g.sp0.mean(); r['SPR_wk4_pct'] = 100 * g.sp4.mean()
    rows.append(r)
hs = pd.DataFrame(rows)
hs.to_csv('/tmp/outputs/analysis/hai_summary_by_arm.csv', index=False)
print('HAI summary'); print(hs.round(1).to_string())

rows = []
for ag, g in w.groupby('antigen'):
    F = g[g.arm == 'Fluarix']; M = g[g.arm == 'mRNA-1010']
    r = dict(antigen=ag)
    r['wk0_GMT_ratio'], r['wk0_lo'], r['wk0_hi'] = ratio_ci(F.wk0, M.wk0)
    r['wk4_GMT_ratio'], r['wk4_lo'], r['wk4_hi'] = ratio_ci(F.wk4, M.wk4)
    r['GMFR_ratio'], r['GMFR_lo'], r['GMFR_hi'] = ratio_ci(F.fr4, M.fr4)
    r['SCR_diff_pct'], r['SCR_lo'], r['SCR_hi'] = [100 * v for v in newcombe_diff(F.sc4.sum(), len(F), M.sc4.sum(), len(M))]
    # ANCOVA
    gg = g.copy(); gg['l0'] = np.log2(gg.wk0); gg['l4'] = np.log2(gg.wk4); gg['mrna'] = (gg.arm == 'mRNA-1010').astype(int)
    fit = smf.ols('l4 ~ mrna + l0', data=gg).fit()
    b = fit.params['mrna']; lo, hi = fit.conf_int().loc['mrna']
    r['adj_wk4_GMT_ratio'] = 2 ** b; r['adj_lo'] = 2 ** lo; r['adj_hi'] = 2 ** hi; r['adj_p'] = fit.pvalues['mrna']
    r['MWU_p_wk4_fold'] = stats.mannwhitneyu(M.fr4, F.fr4).pvalue
    rows.append(r)
hc = pd.DataFrame(rows)
hc.to_csv('/tmp/outputs/analysis/hai_arm_comparison.csv', index=False)
print('\nHAI arm comparison (mRNA-1010 / Fluarix)'); print(hc.round(3).to_string())

# ---------------- MN
m = pd.read_csv('/tmp/world/filesystem/microneutralization.csv')
t = m[m.measure == 'titer'].pivot_table(index=['panel', 'arm', 'participant'], columns='timepoint', values='value').reset_index()
t['late'] = t['wk26'].fillna(t['wk17'])
fc = m[m.measure == 'fold_change'].pivot_table(index=['panel', 'arm', 'participant'], columns='timepoint', values='value').reset_index()
t = t.merge(fc.rename(columns={'wk4': 'fc4_reported', 'wk17/26': 'fclate_reported'}), on=['panel', 'arm', 'participant'])
t['fc4_calc'] = t.wk4 / t.wk0
t['fclate_calc'] = t.late / t.wk0
t['ceiling_wk0'] = t.wk0 >= 1280
t['ceiling_wk4'] = t.wk4 >= 1280
t.to_csv('/tmp/outputs/analysis/mn_wide.csv', index=False)
print('\nMN reported vs recomputed fold-change mismatches:')
mm_ = t[(np.abs(np.log2(t.fc4_calc) - np.log2(t.fc4_reported)) > 0.01) | (np.abs(np.log2(t.fclate_calc) - np.log2(t.fclate_reported)) > 0.01)]
print(mm_[['panel', 'arm', 'participant', 'wk0', 'wk4', 'late', 'fc4_reported', 'fc4_calc', 'fclate_reported', 'fclate_calc']].to_string())
rows = []
for (pn, arm), g in t.groupby(['panel', 'arm']):
    r = dict(panel=pn, arm=arm, n=len(g))
    r['GMT_wk0'], r['GMT_wk0_lo'], r['GMT_wk0_hi'] = gm_ci(g.wk0)
    r['GMT_wk4'], r['GMT_wk4_lo'], r['GMT_wk4_hi'] = gm_ci(g.wk4)
    r['GMT_late'] = gmt(g.late)
    r['GMFR_wk4'] = gmt(g.fc4_reported)
    r['median_fc4'] = g.fc4_reported.median()
    r['pct_4fold_wk4'] = 100 * (g.fc4_reported >= 4).mean()
    r['n_at_ceiling_wk0'] = int(g.ceiling_wk0.sum()); r['n_at_ceiling_wk4'] = int(g.ceiling_wk4.sum())
    r['n_at_floor_wk4(<=10)'] = int((g.wk4 <= 10).sum())
    rows.append(r)
ms = pd.DataFrame(rows)
ms.to_csv('/tmp/outputs/analysis/mn_summary_by_arm.csv', index=False)
print('\nMN summary'); print(ms.round(1).to_string())
rows = []
for pn, g in t.groupby('panel'):
    F = g[g.arm == 'Fluarix']; M = g[g.arm == 'mRNA-1010']
    r = dict(panel=pn)
    r['wk0_GMT_ratio'], r['wk0_lo'], r['wk0_hi'] = ratio_ci(F.wk0, M.wk0)
    r['wk4_GMT_ratio'], r['wk4_lo'], r['wk4_hi'] = ratio_ci(F.wk4, M.wk4)
    r['GMFR_ratio'], r['GMFR_lo'], r['GMFR_hi'] = ratio_ci(F.fc4_reported, M.fc4_reported)
    r['MWU_p_fold'] = stats.mannwhitneyu(M.fc4_reported, F.fc4_reported).pvalue
    gg = g.copy(); gg['l0'] = np.log2(gg.wk0); gg['l4'] = np.log2(gg.wk4); gg['mrna'] = (gg.arm == 'mRNA-1010').astype(int)
    fit = smf.ols('l4 ~ mrna + l0', data=gg).fit()
    b = fit.params['mrna']; lo, hi = fit.conf_int().loc['mrna']
    r['adj_wk4_GMT_ratio'] = 2 ** b; r['adj_lo'] = 2 ** lo; r['adj_hi'] = 2 ** hi; r['adj_p'] = fit.pvalues['mrna']
    # excluding participants at ceiling at baseline
    g2 = gg[gg.wk0 < 1280]
    F2 = g2[g2.arm == 'Fluarix']; M2 = g2[g2.arm == 'mRNA-1010']
    r['GMFR_ratio_excl_ceiling0'], r['lo2'], r['hi2'] = ratio_ci(F2.fc4_reported, M2.fc4_reported)
    r['n_F_excl'] = len(F2); r['n_M_excl'] = len(M2)
    rows.append(r)
mc = pd.DataFrame(rows)
mc.to_csv('/tmp/outputs/analysis/mn_arm_comparison.csv', index=False)
print('\nMN arm comparison (mRNA-1010 / Fluarix)'); print(mc.round(3).to_string())
