"""Baseline-adjusted comparison of sequencing-based neutralisation titres.
Per virus: OLS log2(d29) ~ arm + log2(d0).
Per virus category: participant-level mean of log2 titres across the viruses in the category
(one value per participant -> no pseudo-replication), then Welch t / ANCOVA on those participant means.
Also reports the fraction of contemporary (2023-24) viruses with d29 titre above thresholds per participant.
"""
import pandas as pd, numpy as np
from scipy import stats
import statsmodels.formula.api as smf
pd.set_option('display.width', 250); pd.set_option('display.max_columns', 60); pd.set_option('display.max_rows', 500)
w = pd.read_csv('/tmp/outputs/analysis/seqneut_participant_virus_log2.csv')
w['mrna'] = (w.arm == 'mRNA-1010').astype(int)

# per-virus ANCOVA
rows = []
for (v, st, role), g in w.groupby(['virus', 'subtype', 'role']):
    g = g.dropna(subset=['d0', 'd29'])
    fit = smf.ols('d29 ~ mrna + d0', data=g).fit()
    b = fit.params['mrna']; lo, hi = fit.conf_int().loc['mrna']
    rows.append(dict(virus=v, subtype=st, role=role, adj_ratio=2 ** b, lo=2 ** lo, hi=2 ** hi, p=fit.pvalues['mrna'],
                     raw_d29_ratio=2 ** (g[g.mrna == 1].d29.mean() - g[g.mrna == 0].d29.mean()),
                     d0_ratio=2 ** (g[g.mrna == 1].d0.mean() - g[g.mrna == 0].d0.mean())))
pa = pd.DataFrame(rows)
pa.to_csv('/tmp/outputs/analysis/seqneut_per_virus_ancova.csv', index=False)
print(pa[pa.role != 'contemporary_2023_24'].round(3).to_string())
c = pa[pa.role == 'contemporary_2023_24']
print('\ncontemporary viruses: adjusted d29 GMT ratio (mRNA/Fluarix) distribution by subtype')
print(c.groupby('subtype').adj_ratio.describe().round(3))
print(c.groupby('subtype').apply(lambda x: pd.Series({'n': len(x), 'p<0.05': int((x.p < 0.05).sum()), 'BH_q<0.05': 0}), include_groups=False))
from statsmodels.stats.multitest import multipletests
pa['q_BH_all'] = multipletests(pa.p, method='fdr_bh')[1]
print('viruses with BH q<0.05 (all 96):'); print(pa[pa.q_BH_all < 0.05][['virus', 'role', 'adj_ratio', 'p', 'q_BH_all']].round(4).to_string())
print('raw d0 ratio (mRNA/Fluarix) contemporary, by subtype:'); print(c.groupby('subtype').d0_ratio.describe().round(3))

# participant-level category means
def cat(row):
    if row.role == 'contemporary_2023_24':
        return f'{row.subtype}_contemporary_2023_24'
    if row.role == 'egg_reassortant':
        return 'egg_reassortants'
    if row.role in ('historical_pre2022',):
        return f'{row.subtype}_historical_pre2022'
    if row.role == 'recent_2022':
        return 'H3N2_2022'
    return row.virus  # vaccine strains / analogs individually
w['category'] = w.apply(cat, axis=1)
pm = w.groupby(['arm', 'pid', 'mrna', 'category'])[['d0', 'd29', 'log2fc']].mean().reset_index()
rows = []
for k, g in pm.groupby('category'):
    g = g.dropna(subset=['d0', 'd29'])
    F = g[g.mrna == 0]; M = g[g.mrna == 1]
    fit = smf.ols('d29 ~ mrna + d0', data=g).fit()
    b = fit.params['mrna']; lo, hi = fit.conf_int().loc['mrna']
    tt = stats.ttest_ind(M.log2fc, F.log2fc, equal_var=False)
    rows.append(dict(category=k, nF=len(F), nM=len(M),
                     GMT_d0_F=2 ** F.d0.mean(), GMT_d0_M=2 ** M.d0.mean(),
                     GMT_d29_F=2 ** F.d29.mean(), GMT_d29_M=2 ** M.d29.mean(),
                     GMFR_F=2 ** F.log2fc.mean(), GMFR_M=2 ** M.log2fc.mean(),
                     GMFR_ratio=2 ** (M.log2fc.mean() - F.log2fc.mean()), welch_p_fc=tt.pvalue,
                     adj_d29_ratio=2 ** b, adj_lo=2 ** lo, adj_hi=2 ** hi, adj_p=fit.pvalues['mrna']))
cs = pd.DataFrame(rows)
cs.to_csv('/tmp/outputs/analysis/seqneut_category_participant_level.csv', index=False)
print('\nParticipant-level category comparison'); print(cs.round(3).to_string())

# correlation between baseline and fold change (why unadjusted GMFR is biased when baselines differ)
r = stats.spearmanr(w.d0, w.log2fc, nan_policy='omit')
print('\nSpearman rho(log2 d0, log2 fold), all participant-virus pairs:', round(r.correlation, 3), r.pvalue)
pc = pm[pm.category == 'H3N2_contemporary_2023_24']
r2 = stats.spearmanr(pc.d0, pc.log2fc)
print('Participant-level, H3N2 contemporary: rho', round(r2.correlation, 3), 'p', r2.pvalue)
