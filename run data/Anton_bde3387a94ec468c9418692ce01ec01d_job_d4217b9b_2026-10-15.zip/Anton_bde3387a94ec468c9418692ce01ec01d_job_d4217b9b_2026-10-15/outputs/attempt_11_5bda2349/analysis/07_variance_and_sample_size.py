"""Variance estimates from WU397 used to size the next randomised study.
Sizing formulas (two-arm, 1:1, normal approximation on log2 scale):
  superiority on GMT ratio R:       n/arm = 2*(z_{1-a/2}+z_{1-b})^2 * s^2 / log2(R)^2
  non-inferiority on GMT ratio (true ratio 1, margin M): n/arm = 2*(z_{1-a}+z_{1-b})^2 * s^2 / log2(1/M)^2  (one-sided a=0.025)
  NI on seroconversion difference (margin -10 pts, true diff 0, rate p): n/arm = (z_{1-a}+z_{1-b})^2 * 2p(1-p)/0.10^2
s = residual SD from ANCOVA log2(post) ~ arm + log2(pre)  (i.e. the baseline-adjusted analysis recommended for the next study)
"""
import pandas as pd, numpy as np
from scipy import stats
import statsmodels.formula.api as smf
za = stats.norm.ppf(0.975); zb90 = stats.norm.ppf(0.90); zb80 = stats.norm.ppf(0.80)
rows = []
# seq-neut participant-level category means
s = pd.read_csv('/tmp/outputs/analysis/seqneut_participant_virus_log2.csv')
s['late'] = s['d181'].fillna(s['d121'])
s['mrna'] = (s.arm == 'mRNA-1010').astype(int)
for st in ['H1N1', 'H3N2']:
    g = s[(s.role == 'contemporary_2023_24') & (s.subtype == st)].groupby(['pid', 'mrna'])[['d0', 'd29', 'late']].mean().reset_index()
    f = smf.ols('d29 ~ mrna + d0', data=g).fit()
    rows.append(dict(readout=f'SeqNeut {st} contemporary panel mean, d29', resid_sd_log2=np.sqrt(f.scale), n=len(g)))
    f2 = smf.ols('late ~ mrna + d0', data=g.dropna()).fit()
    rows.append(dict(readout=f'SeqNeut {st} contemporary panel mean, late', resid_sd_log2=np.sqrt(f2.scale), n=len(g.dropna())))
# single-virus example (Darwin/6/2021)
g = s[s.virus == 'A/Darwin/6/2021_H3N2'].dropna(subset=['d0', 'd29'])
f = smf.ols('d29 ~ mrna + d0', data=g).fit(); rows.append(dict(readout='SeqNeut A/Darwin/6/2021 single virus, d29', resid_sd_log2=np.sqrt(f.scale), n=len(g)))
h = pd.read_csv('/tmp/outputs/analysis/hai_wide.csv', dtype={'participant': str})
for ag, g in h.groupby('antigen'):
    g = g.copy(); g['l0'] = np.log2(g.wk0); g['l4'] = np.log2(g.wk4); g['mrna'] = (g.arm == 'mRNA-1010').astype(int)
    f = smf.ols('l4 ~ mrna + l0', data=g).fit(); rows.append(dict(readout=f'HAI {ag} wk4', resid_sd_log2=np.sqrt(f.scale), n=len(g)))
m = pd.read_csv('/tmp/outputs/analysis/mn_wide.csv')
for pn, g in m.groupby('panel'):
    g = g.copy(); g['l0'] = np.log2(g.wk0); g['l4'] = np.log2(g.wk4); g['mrna'] = (g.arm == 'mRNA-1010').astype(int)
    f = smf.ols('l4 ~ mrna + l0', data=g).fit(); rows.append(dict(readout=f'MN {pn} wk4', resid_sd_log2=np.sqrt(f.scale), n=len(g)))
v = pd.DataFrame(rows)
def n_sup(sd, R, zb): return int(np.ceil(2 * (za + zb) ** 2 * sd ** 2 / np.log2(R) ** 2))
def n_ni(sd, M, zb): return int(np.ceil(2 * (za + zb) ** 2 * sd ** 2 / np.log2(1 / M) ** 2))
v['n_arm_sup_R1.5_90pct'] = v.resid_sd_log2.apply(lambda x: n_sup(x, 1.5, zb90))
v['n_arm_sup_R1.3_90pct'] = v.resid_sd_log2.apply(lambda x: n_sup(x, 1.3, zb90))
v['n_arm_NI_M0.67_90pct'] = v.resid_sd_log2.apply(lambda x: n_ni(x, 0.67, zb90))
print(v.round(3).to_string())
v.to_csv('/tmp/outputs/analysis/sample_size_inputs.csv', index=False)
for p in [0.15, 0.3, 0.4, 0.5]:
    n = int(np.ceil((za + zb90) ** 2 * 2 * p * (1 - p) / 0.10 ** 2))
    print(f'SCR NI (-10 pts), p={p}: n/arm={n} (90% power)')
# Power of WU397 itself: minimum detectable GMT ratio at n=14/arm, 80% power
for _, r in v.iterrows():
    mdr = 2 ** ((za + zb80) * r.resid_sd_log2 * np.sqrt(2 / 14))
    print(f"{r.readout}: minimum detectable GMT ratio at n=14/arm, 80% power = {mdr:.2f}")

# Recommended Study 1 size: inflate the H3-panel residual SD by 20% for multicentre heterogeneity
sd_h3 = v.loc[v.readout == 'SeqNeut H3N2 contemporary panel mean, d29', 'resid_sd_log2'].iloc[0]
n_infl = n_sup(sd_h3 * 1.2, 1.3, zb90)
print(f'H3 panel, 1.3x superiority, 90% power, SD inflated 20% ({sd_h3*1.2:.2f} log2): n/arm = {n_infl}')
print(f'200 evaluable/arm with 15% attrition -> randomised/arm = {int(round(200/0.85))}')
