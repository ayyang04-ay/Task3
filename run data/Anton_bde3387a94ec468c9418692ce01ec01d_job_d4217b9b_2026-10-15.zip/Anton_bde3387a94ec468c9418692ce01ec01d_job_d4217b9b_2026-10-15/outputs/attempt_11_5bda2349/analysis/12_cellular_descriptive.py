"""Descriptive summaries of cellular / repertoire / mAb data (mechanistic; not usable for a protection claim).
GC file contains two complete blocks with identical keys (timepoint, arm, participant); reported separately as block1/block2."""
import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width', 250); pd.set_option('display.max_columns', 60); pd.set_option('display.max_rows', 300)
F = '/tmp/world/filesystem/'
gc = pd.read_csv(F + 'gc_frequencies.csv', dtype={'participant': str})
gc['block'] = np.where(gc.index < len(gc) // 2, 'block1', 'block2')
t = gc.groupby(['block', 'timepoint', 'arm']).pct_ha_specific_igg_gc.agg(['count', 'median']).unstack('arm')
print('GC % HA-specific (median by arm):'); print(t.round(2))
pb = pd.read_csv(F + 'plasmablast_frequencies.csv', dtype={'participant': str})
t2 = pb.groupby(['timepoint', 'arm']).pct_plasmablast.agg(['count', 'median']).unstack('arm')
print('\nPlasmablast % (median by arm):'); print(t2.round(4))
rc = pd.read_csv(F + 'repertoire_clonotype_counts.csv')
print('\nRepertoire metrics (median by arm, n):'); print(rc.groupby(['metric', 'arm']).value.agg(['count', 'median']).round(1))
for met, g in rc.groupby('metric'):
    print(met, 'MWU p =', round(stats.mannwhitneyu(g[g.arm == 'mRNA-1010'].value, g[g.arm == 'Fluarix'].value).pvalue, 3))
sc = pd.read_csv(F + 'serum_igg_clonotypes.csv')
print('\nSerum IgG clonotypes (median by arm):'); print(sc.groupby(['timepoint', 'arm']).n_clonotypes.agg(['count', 'median']))
cd = pd.read_csv(F + 'cdrh3_diversity_index.csv')
print('\nCDRH3 diversity (median by arm):'); print(cd.groupby(['timepoint', 'arm']).diversity_index.agg(['count', 'median']).round(1))
ov = pd.read_csv(F + 'pb_gc_clonal_overlap.csv')
print('\nPB-GC overlap:'); print(ov[['Participant', 'Number of wk1 PB clones', 'Number of GC B cell clones', 'Number of overlapping clones spanning wk1 PB and GC B cell', 'Percentage of overlapping clones out of GC B cell clones']].to_string())
# mAbs at donor level
mb = pd.read_csv(F + 'mab_binding_panels.csv'); mb['donor'] = mb.mab_id.str.split('.').str[1]
mb = mb[mb.antigen != 'SARS-CoV-2 RBD']; mb['bind'] = mb.fold_over_control > 10
dl = mb.groupby(['panel', 'antigen', 'arm', 'donor']).bind.mean().reset_index()
summ = dl.groupby(['panel', 'antigen', 'arm']).bind.agg(['count', 'median', 'min', 'max']).unstack('arm')
print('\nmAb binding (fold>10) - donor-level fraction, summarised across donors:'); print(summ.round(2))
print('\nmAbs per donor:'); print(mb.drop_duplicates('mab_id').groupby(['arm', 'donor']).size())
dl.to_csv('/tmp/outputs/analysis/mab_donor_level_binding.csv', index=False)
