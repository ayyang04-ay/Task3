# WU397 re-analysis — scripts and outputs

Inputs: `/tmp/world/filesystem/*` (read-only). Re-run everything with `./run_all.sh` (conda env `core`: pandas, scipy, statsmodels, matplotlib).
All arm comparisons use the **participant** as the unit of analysis. The primary estimand is the ratio of post-vaccination
geometric mean titres (mRNA-1010 / Fluarix), adjusted for the participant's own baseline titre (ANCOVA on log2 titres).
Fold-rise is reported only as a secondary metric because baselines were unbalanced.

| Script | What it does | Main outputs |
|---|---|---|
| 00_virus_classification.py | Sorts the 96 sequencing-neutralisation viruses into vaccine strains and their analogues, egg reassortants, historical, 2022 and 2023–24 groups | virus_classification.csv |
| 01_seqneut_analysis.py | Per-virus GMT, GMFR and % ≥4-fold by arm. Censoring rule: at or below the lower limit = LOD/2; above the upper limit = the reported value | seqneut_per_virus_arm_summary.csv, seqneut_participant_virus_log2.csv |
| 02_hai_mn_analysis.py | HAI and MN: GMT, GMFR, seroconversion (regulatory definition), seroprotection, ceiling counts, baseline-adjusted ratios, Newcombe CIs | hai_*.csv, mn_*.csv |
| 03_seqneut_adjusted.py | Baseline-adjusted comparisons per virus and per virus category (participant-mean), BH multiplicity correction, baseline-vs-rise correlation | seqneut_per_virus_ancova.csv, seqneut_category_participant_level.csv |
| 04_elisa_igm_analysis.py | ELISA IgG arm comparison, consistency of reported vs recomputed fold-changes, enrolment-ID pattern, IgM checks | elisa_arm_comparison.csv, elisa_wide.csv |
| 05_late_rises_infection_screen.py | Flags ≥4-fold rises from week 4 to the late visit (possible intercurrent infection) | late_rise_infection_flags.csv |
| 06_durability.py | Arm comparison at week 17/26 for seq-neut, HAI and MN | seqneut_durability_category.csv, hai_durability.csv, mn_durability.csv |
| 07_variance_and_sample_size.py | Residual SDs from WU397, sample sizes for the next study, WU397's minimum detectable differences | sample_size_inputs.csv |
| 08_binding_vs_function.py | Bead-array binding by arm; binding vs neutralisation gain in the same participants and strains | binding_breadth_arm_comparison.csv, binding_vs_neutralisation.csv |
| 09_egg_vs_wildtype_pairs.py | Titre inflation and right-censoring for egg-adapted viruses vs their wild-type or cell-derived counterparts | egg_vs_wildtype_pairs.csv |
| 10_seqneut_sensitivity.py | Sensitivity to the censoring rule and late-visit definition; H3 antigenic-escape tertiles | seqneut_sensitivity.csv, seqneut_H3_escape_tertiles.csv |
| 11_baseline_balance_and_integrity.py | Baseline balance across assays; cross-file integrity checks | baseline_balance.csv (integrity results in logs/) |
| 12_cellular_descriptive.py | Descriptive GC, plasmablast, repertoire and mAb results (mAbs summarised per donor) | mab_donor_level_binding.csv |
| 14_forward_vaccine_strains.py | H3N2 viruses that WHO later selected as vaccine strains because of drift | seqneut_forward_who_strains.csv |
| 13_figure.py | Summary figure | ../wu397_key_findings.png |
| 15_efficacy_sizing.py | Case numbers for an event-driven relative-efficacy trial; challenge-study sizes | efficacy_sizing.txt |
| 16/17_*.py | Collect every number cited in answer.md, with its source | ../key_numbers.csv |
