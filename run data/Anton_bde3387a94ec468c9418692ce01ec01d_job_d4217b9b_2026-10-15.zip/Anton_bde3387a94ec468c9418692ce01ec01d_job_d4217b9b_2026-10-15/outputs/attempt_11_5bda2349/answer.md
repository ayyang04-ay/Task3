**Recommendation:** WU397 does not support a heterologous-protection claim, so the protocol for committee should be a randomised, observer-blind, strain-matched trivalent Phase 2 against an egg-based and a non-egg licensed comparator, gated on day-29 and day-181 neutralisation of a pre-specified panel of wild-type drifted strains (H3N2 primary); only if it passes that gate should an event-driven Phase 3 relative-efficacy trial follow, with PCR-confirmed influenza caused by antigenically mismatched strains as its key endpoint.

# WU397 (mRNA-1010 vs Fluarix, 2022–23): what the data support, and the next studies

Figure: `wu397_key_findings.png`. Every number below is traceable in `key_numbers.csv`, which gives source file, script and derivation. Scripts and intermediate tables are in `analysis/` (run `analysis/run_all.sh`).

---

## 1. Bottom line

1. **What WU397 shows.**
   - mRNA-1010 produced much more HA-binding antibody than Fluarix. Baseline-adjusted week-4 ELISA ratios were 2.66× for H1 and 3.31× for H3.
   - Binding reached strains as old as A/Hong Kong/1/1968 and A/Puerto Rico/8/1934.
   - Germinal-centre responses were larger (small lymph-node subset, 6 vs 11).
   - The only *functional* advantage was for H1: 1.95× (95% CI 1.19–3.20) higher neutralising titres against 2023–24 H1N1 viruses at day 29.
2. **What it does not show.**
   - **No functional advantage against H3N2**, the subtype where vaccine mismatch matters most:
     - 64 circulating 2023–24 viruses: 1.19 (0.65–2.16).
     - The three H3N2 viruses WHO later selected *because* of drift: 1.04 (0.55–1.97).
     - mRNA-1010's own H3 strain: 0.63 (0.35–1.14).
   - For H3, the mRNA arm's binding rose roughly 7–12× more than Fluarix's, while its neutralisation rose no more than Fluarix's (difference −0.2 log2).
   - The H1 advantage had disappeared by week 17/26: 1.08 (0.70–1.67).
   - HAI and microneutralisation showed no statistically supported advantage for any component (best case HAI H1 1.54, 0.87–2.71). B lineages barely responded in either arm.
3. **Why these numbers could not carry a claim even if they were stronger.**
   - Allocation was by site, not randomised, and baselines were unbalanced.
   - The arms received **different H1 strains** and egg- vs cell-derived H3 strains.
   - "Homologous/heterologous" was defined only against mRNA-1010's antigens.
   - Functional cohorts were 13–15 per arm, so only differences of about 1.6–3× were detectable.
   - There is no clinical endpoint. The one accepted immune correlate (HAI ≥1:40) applies to vaccine-matched strains, not drifted ones.
4. **Next studies.** Studies 1 and 2 together are what is sufficient for the claim; Studies 0 and 3 are supportive.
   - **Study 0:** bridging work on banked WU397 samples, now. It informs Study 1's design.
   - **Study 1 (the protocol for committee):** a randomised, strain-matched Phase 2 breadth study with a hard go/no-go.
   - **Study 2:** a Phase 3 relative-efficacy trial with a mismatched-strain endpoint. This is the only design that can support the word "protection".
   - **Study 3 (optional):** a heterologous human-challenge study.

---

## 2. What the data package shows

### 2.1 The two arms were not given the same strains

| Component | mRNA-1010 (trial_summary.md) | Fluarix 2022–23 NH (licensed composition = WHO 2022–23 egg-based recommendation) [X1] | Consequence |
|---|---|---|---|
| H1N1pdm09 | A/Victoria/4897/2022. This is WHO's **2023–24** egg-based pick [X2], clade 5a.2a.1. | A/Victoria/2570/2019, clade 5a.2 | **Different strains.** "Homologous" H1 is heterologous for Fluarix. The 2023–24 H1N1 test viruses belong to the 5a.2a/5a.2a.1 lineage of the mRNA antigen (WHO clade designations), so for the mRNA arm they are closer to homologous than heterologous. |
| H3N2 | A/Darwin/6/2021 (cell-derived) | A/Darwin/9/2021 (egg-derived) | Same antigenic group, but egg- vs cell-derived. The same sera neutralise Darwin/9/2021 2.88× better than Darwin/6/2021 [S]. |
| B/Victoria | B/Austria/1359417/2021 | same | matched |
| B/Yamagata | B/Phuket/3073/2013 | same | Matched, but no confirmed circulation since March 2020; WHO and FDA have dropped it [X3]. |

The summary file itself states that "homologous/heterologous" labels "refer to the mRNA-1010 antigens". The package therefore cannot separate a **platform** effect from a **strain-choice** effect.

The H1 gain was at least as large against the analogue of Fluarix's own strain (A/Wisconsin/588/2019: 2.27×) as against 2023–24 viruses (1.95×). That points to a magnitude effect rather than breadth. It still cannot be separated from site effects.

### 2.2 Functional antibody: the readouts that bear on protection

Ratios are mRNA-1010 / Fluarix, adjusted for each participant's baseline titre (ANCOVA on log2; analysis/02, 03, 06, 14).

| Readout (source) | Target | Fluarix | mRNA-1010 | Week 4 / day 29 adjusted ratio (95% CI) | Week 17/26 adjusted ratio |
|---|---|---|---|---|---|
| HAI GMT, week 4 [H] (n = 15 / 14) | H1N1 | 87.7 | 138.0 | 1.54 (0.87–2.71) | 0.83 (0.47–1.46) |
| | H3N2 | 57.9 | 56.4 | 1.06 (0.67–1.65) | 0.92 (0.60–1.41) |
| | B/Victoria | 51.6 | 56.5 (n = 13) | 1.05 (0.71–1.56) | 1.06 (0.65–1.73) |
| | B/Yamagata | 98.6 | 88.3 | 1.01 (0.73–1.40) | 0.91 (0.63–1.31) |
| HAI seroconversion, week 4 [H] | H1 / H3 / B-Vic / B-Yam | 5/15, 2/15, 1/15, 1/15 | 7/14, 2/14, 0/13, 0/14 | H1 difference +16.7 points (−17.4 to 46.1) | — |
| MN GMT, week 4 [M] | "homologous" panel | 588 | 325 | 0.68 (0.31–1.51) | 0.64 (0.30–1.37) |
| | "heterologous" panel | 368 | 235 | 1.17 (0.52–2.62) | 0.73 (0.37–1.45) |
| Sequencing-based neutralisation GMT, day 29 [S] (n = 14 / 13) | H1N1 2023–24 (6 viruses) | 252 | 478 | **1.95 (1.19–3.20)** | 1.08 (0.70–1.67) |
| | H1 A/Wisconsin/588/2019 (Fluarix-strain analogue) | 506 | 1073 | 2.27 (1.11–4.65) | 1.03 (0.52–2.04) |
| | H1 A/Wisconsin/67/2022 (mRNA-strain analogue) | 187 | 431 | 1.82 (1.13–2.92) | 1.13 (0.74–1.72) |
| | **H3N2 2023–24 (64 viruses)** | 459 | 396 | **1.19 (0.65–2.16)** | 1.06 (0.66–1.70) |
| | H3N2 viruses WHO later chose because of drift (A/Thailand/8/2022, A/Massachusetts/18/2022, A/District of Columbia/27/2023) [X4] | 377 | 282 | 1.04 (0.55–1.97) | 0.89 (0.47–1.70) |
| | Most antigenically escaped third of 2023–24 H3N2 viruses | — | — | 1.25 (0.66–2.34) | — |
| | **H3 A/Darwin/6/2021 (mRNA-1010's own H3)** | 482 | 244 | **0.63 (0.35–1.14)** | 0.72 (0.40–1.32) |
| | H3 A/Darwin/9/2021 (Fluarix's H3, egg-derived) | 1539 | 1009 | 0.81 (0.35–1.87) | 0.57 (0.25–1.27) |

**Per-virus results.** All 6 of 6 H1 2023–24 viruses reached p < 0.05 individually. None of the 64 H3N2 2023–24 viruses did; their median per-virus ratio was 1.16. None of the 96 viruses survives Benjamini–Hochberg correction.

**Robustness.** Results do not change if values at the detection limit are kept at the limit instead of halved (H1 2.06, H3 1.18), or if the late visit is restricted to day 181 (H1 1.03, H3 0.99).

**Waning.** mRNA-arm titres waned faster: for the H1 2023–24 panel, the late/day-29 ratio was 0.41 in the mRNA arm vs 0.74 for Fluarix.

**Two numbers that would mislead if quoted as they stand.**
- MN "heterologous": ≥4-fold rise in 64.3% vs 40.0%, and GMFR 4.12 vs 3.03.
- Sequencing-based H3 2023–24: GMFR 2.94 vs 2.17.

Both reflect the mRNA arm **starting lower**, not ending higher:
- Baseline ratios were 0.47 (0.22–1.00) for the MN heterologous panel and 0.64 (0.37–1.09) for the H3 2023–24 panel.
- Fold-rise falls as baseline rises (Spearman ρ = −0.375 across all participant × virus pairs).
- Absolute week-4 titres were numerically *lower* in the mRNA arm for both readouts.

### 2.3 Binding antibody and B-cell data: large, broad, and for H3 not neutralising

**ELISA IgG, week 4 (n = 37 / 38) [E].** Adjusted ratios:

| Component | Week 4 | Week 17/26 |
|---|---|---|
| H1 | 2.66 (2.01–3.53) | 1.51 |
| H3 | 3.31 (2.47–4.43) | 2.06 |
| B/Victoria | 1.35 (1.04–1.75) | 0.99 |
| B/Yamagata | 1.38 (1.11–1.71) | 1.06 |

**Bead-array binding breadth [B].** The mRNA arm had a higher fold-rise for every strain.
- H3: 3.07–10.07× higher, including A/Hong Kong/1/1968 at 9.51× (median log2 fold change 0.17 in Fluarix vs 3.61 in mRNA).
- H1: 1.26–2.70× higher, including A/Puerto Rico/8/1934 at 2.70×.

**The binding gain does not become neutralisation for H3.** Same participants and strains; difference in mean log2 fold-rise, mRNA minus Fluarix [B + S]:

| Strain | Binding | Neutralisation |
|---|---|---|
| A/Darwin/6/2021 | +2.85 | −0.22 |
| A/Thailand/8/2022 | +3.57 | −0.17 |
| H1 A/Wisconsin/588/2019 (for contrast: binding and neutralisation track together) | +1.30 | +1.25 |

Binding breadth is therefore **not a valid surrogate for functional breadth** with this platform, at least for H3.

**Monoclonal antibodies [Ab].**
- There are 589 mAbs from 4 mRNA donors vs 106 from 3 Fluarix donors, 84 of which come from one donor. The donor, not the mAb, must be the unit of analysis.
- Donor-level median fraction binding, Fluarix vs mRNA:

| Antigen | Fluarix | mRNA-1010 |
|---|---|---|
| A/Hong Kong/1/1968 | 0.00 | 0.45 |
| A/Croatia/10136RV/2023 | 0.00 | 0.52 |
| H1 A/Netherlands/01317/2025 | 0.78 | 0.90 |
| H5 | 0.00 | 0.02 |
| H7 | 0.00 | 0.07 |

- With 3 vs 4 donors this is descriptive only. Nothing here supports a heterosubtypic claim.

**Cellular and repertoire data [G, P, R, I]** (mechanistic support only):
- Germinal-centre HA-specific % at "week 2": median 24.2 (n = 6) vs 2.3 (n = 11).
- Plasmablasts at "week 2": 0.068% vs 0.031%.
- Vaccine-elicited serum clonotypes: 32 vs 17.5 (n = 8 per arm; p = 0.066).
- IgM fold-rise did not favour mRNA: median 1.0 for every antigen vs 1.0–2.96 for Fluarix.
- These files have labelling problems (Section 5).

### 2.4 Why the package cannot carry a heterologous-protection claim

| Problem | Evidence in the package | What it means for the next design |
|---|---|---|
| Non-randomised, site-based allocation | In the ELISA extension, Fluarix IDs fall in 33–59 (22/37) and mRNA IDs in 64–102 (24/38), i.e. arms were enrolled in separate blocks [E]. Baseline imbalances run both ways: MN heterologous 0.47, sequencing-based H3 historical 0.55, HAI H1 1.28 [baseline_balance.csv]. Age, site, vaccination history and enrolment dates are **not in the package**. | Randomise within site, enrol concurrently, stratify by age and prior vaccination, adjust for baseline. |
| Comparator not strain-matched | Section 2.1 | Same strain designations in every arm, plus a non-egg comparator. |
| Underpowered | Minimum detectable GMT ratio with 80% power at n ≈ 14 per arm: HAI 1.57–2.15, sequencing-based neutralisation 1.79–2.14, MN 2.84–2.98 [analysis/07] | Size from WU397 variances (Study 1). |
| Ceiling on MN titres | Titres capped at 1:1280. At week 4 on the homologous panel, 9/15 Fluarix and 4/14 mRNA participants were at the cap [M]. | Titre range must not truncate post-vaccination responses. |
| Egg-adapted viruses in panels | Neutralised 1.43–6.41× better than their wild-type or cell-derived counterparts; 13–19 sera were above the upper limit for three of them. A/Darwin/9/2021 is an egg-derived vaccine virus but carries **no** reassortant suffix [S]. | Use wild-type viruses for every breadth endpoint; report egg versions separately. |
| Unbalanced or unspecified panels | Sequencing-based panel: 64 H3 vs 6 H1 2023–24 viruses and **no B viruses**. MN panel composition, HAI strains and the binding-breadth timepoint are not stated [S, M, H, B]. | Pre-specified, balanced panel with B/Victoria included. |
| Durability | The H1 advantage fell from 1.95 to 1.08. Week 17 and week 26 are pooled, and visit labels disagree across files. | Separate day-91 and day-181 endpoints. |
| Intercurrent infection not monitored | No ≥4-fold rise after week 4 in HAI, MN or ELISA; one participant rose on 2/83 viruses in the sequencing-based assay. Reassuring, but infection before week 4 cannot be excluded. | Active influenza-like-illness surveillance plus infection-specific serology. |
| No clinical endpoint | HAI ≥1:40 is associated with about 50% protection against *matched* strains [X5]. There is no accepted correlate for drifted strains. | A protection claim needs a clinical-endpoint trial (Study 2). |

---

## 3. Recommended studies

### Study 0: bridging work on banked WU397 samples (no new enrolment; start now)

This study cannot create the claim. It closes gaps that change Study 1's design. It covers all WU397 participants with banked day 0, day 29 and week 17/26 sera: the functional cohort (14 mRNA / 15 Fluarix) and the ELISA extension (38 / 37) where sera exist. Results are descriptive and baseline-adjusted.

| Measured | Against what | Why |
|---|---|---|
| Neutralising antibody against B/Victoria: the vaccine strain plus recent drifted B/Victoria viruses | both arms | There is no functional B data at all: HAI GMFR was 1.05 vs 1.08, and seroconversion was 1/15 vs 0/13. B/Victoria will be one of the three components. |
| NA-inhibiting antibody (N1, N2, B NA; vaccine-matched and drifted) | both arms | Split vaccine contains NA. mRNA-1010 lists only four strain antigens (assumed to be HA only), and NA immunity contributes to protection against drifted strains. |
| Infection-specific serology (an antigen present in neither vaccine) | both arms, day 0 vs later visits | Identify and censor intercurrent infections. |
| Fc-effector activity of H3-binding antibody | both arms | Tests whether the large non-neutralising H3 binding response has any function. Exploratory. |
| Demographics, site, enrolment date, prior-season vaccination (from source documents) | — | Enables a confounder-adjusted re-analysis. |
| Data reconciliation (Section 5) | — | Required before any WU397 figure goes into the protocol's rationale. |

### Study 1: randomised, strain-matched Phase 2 breadth study (the protocol for committee)

**Conditions**

| Element | Specification |
|---|---|
| Design | Phase 2, randomised 1:1:1, observer-blind, active-controlled, multicentre. All arms enrolled **concurrently at every site**. Vaccination completed before local influenza activity. One Northern Hemisphere season. |
| Arm A | mRNA candidate at the dose intended for Phase 3. **Trivalent** (H1N1pdm09, H3N2, B/Victoria). HA sequences = the WHO cell/recombinant-based strains for that season. |
| Arm B | Licensed egg-based standard-dose inactivated vaccine for the same season (Fluarix, for continuity with WU397). |
| Arm C | Licensed **non-egg** vaccine with the same strain designations as Arm A. A cell-based inactivated vaccine separates a platform effect from egg adaptation at the same HA dose; a recombinant HA vaccine instead sets the stronger, higher-dose non-egg benchmark. |
| Adults ≥65 | Comparators must be the vaccines preferentially recommended for this age group [X6], ideally one egg-based high-dose and one non-egg (recombinant) vaccine. A claim in ≥65 measured against standard-dose vaccine would not be relevant to practice. |
| Optional Arm D | Only if an alternative H3 construct or dose exists. WU397's weakest component is H3. |
| Population | Community-dwelling adults in two strata, 18–64 and ≥65 (or restrict to the claim's target age group). Exclusions: current-season influenza vaccination, immunocompromise, PCR-confirmed influenza within 6 months, other vaccines within ±28 days. |
| Randomisation strata and covariates | Stratify by site, age stratum and prior-season vaccination. Record birth year (imprinting cohort), influenza vaccinations in the prior 5 seasons, and prior confirmed influenza. |
| Visits | Day 0, day 29 (primary), day 91, day 181 (end of season). Active surveillance for influenza-like illness with PCR swabs from day 0 to day 181. |
| Laboratory conduct (specification level) | Central testing blinded to arm. All of a participant's timepoints tested together. One panel for all arms. Rules for values outside the measurable range fixed in the SAP. |
| Size | About 200 evaluable per arm per age stratum, about 235 randomised (see sizing below). |

**Readouts: what is measured, in whom, against what**

In every row, "in whom" is the per-protocol immunogenicity set, analysed separately within each age stratum, and the comparison is mRNA vs each comparator separately, unless the row says otherwise. The per-protocol set is all randomised, vaccinated participants with valid day-0 and post-vaccination samples and no confirmed influenza infection before the sample.

| # | What is measured | Against what (strains) | When | Estimand and criterion |
|---|---|---|---|---|
| **P1** | Neutralising titre | **Forward H3N2 drift panel** (specified below) | Day 29 | Baseline-adjusted GMT ratio of participant-mean titres across the panel. Superiority: lower 95% bound > 1.0. |
| **P2** | HAI and neutralising titre | Each **vaccine strain** in wild-type form (H1, H3, B/Victoria) | Day 29 | Non-inferiority: lower 95% bound of GMT ratio ≥ 0.67 [X7]. HAI seroconversion and % ≥1:40 reported. |
| KS1 | Neutralising titre | Forward H1N1 panel and forward B/Victoria panel | Day 29 | As P1 |
| KS2 | Neutralising titre | Forward H3N2 panel (then H1, B) | **Day 181** (and day 91) | As P1. Tests whether any breadth lasts through the season; WU397's did not. |
| S1 | Participant-level breadth: proportion of panel viruses above a pre-specified titre threshold | Forward panels | Days 29, 181 | Difference in mean proportion |
| S2 | NA-inhibiting titre | N1, N2 and B NA, vaccine-matched and drifted | Days 0, 29, 181 | GMT ratio (descriptive or non-inferiority) |
| S3 | Neutralising titre | Retrospective panel (earlier vaccine strains) | Day 29 | Reported separately. Measures back-boosting, not breadth. |
| S4 | Neutralising titre | Egg-adapted versions of the vaccine viruses | Day 29 | Reported separately; never part of P1/KS. |
| E1 | HA-binding IgG, and the ratio of neutralising to binding antibody | Vaccine strains and forward panel | Days 29, 181 | Exploratory. Binding is not a breadth endpoint (Section 2.3). |
| E2 | Fc-effector activity | H3 vaccine strain and forward H3 viruses | Day 29 | Exploratory; random subset |
| Safety | Solicited reactions (7 days), unsolicited AEs (28 days), SAEs and AESIs | All vaccinated (safety set) | to day 181 | Descriptive |
| Infection | PCR-confirmed influenza; infection-specific seroconversion | All randomised | Days 0–181 | Censoring rule for P1–KS2; descriptive attack rates |

**"Against what": specification of the forward panel**
- **Wild-type viruses only** (not egg-adapted).
- Separate panels for H3N2, H1N1 and B/Victoria, with ≥10 viruses each. WU397 had 6 H1 viruses and no B viruses.
- **Composition:**
  - Viruses representing every HA genetic subclade that reaches ≥5% of sequenced viruses in the 12 months up to the end of the study season.
  - Every virus WHO selects or shortlists at the next consultations because of drift. In WU397's data the equivalents are A/Thailand/8/2022, A/Massachusetts/18/2022 and A/District of Columbia/27/2023.
- **Weighting:** equal weight per subclade, so that one over-represented clade cannot drive the score. WU397 had 64 H3 viruses vs 6 H1.
- **Locking:** fixed by an arm-blinded virology committee before unblinding.
- **Excluded from the forward panel:** vaccine strains (covered by P2), historical strains (S3) and egg-adapted viruses (S4).

**Analysis rules**
- The primary metric is the baseline-adjusted post-vaccination GMT ratio, not fold-rise. In WU397, fold-rise differences came from unequal baselines (ρ = −0.375).
- The participant is the unit of analysis. Per-mAb and per-virus tests are not independent evidence.
- Fixed testing order: P2 (all three components) → P1 → KS1 → KS2.
- Sensitivity analyses: including infected participants; alternative rules for out-of-range values.

**Sizing (from WU397 variances; analysis/07)**
- The residual SD of the baseline-adjusted day-29 titre was 1.03 log2 for the H3 2023–24 panel, 0.89 for H1, and 0.85–1.05 for HAI.
- Evaluable n per arm at 90% power, two-sided α 0.05:

| Aim | H3 panel | H1 panel | HAI |
|---|---|---|---|
| Detect a 1.3× GMT ratio | 156 | 118 | — |
| Detect a 1.5× GMT ratio | 66 | 49 | — |
| GMT non-inferiority, margin 0.67 | 67 | 51 | 46–69 |

- Inflating the SD by 20% for multicentre heterogeneity gives about 225 for 1.3×, hence **about 200 evaluable per arm per stratum**.
- HAI seroconversion non-inferiority (−10 percentage points) needs 268–526 per arm depending on the seroconversion rate. That belongs in the Phase 3 immunogenicity subset.

**Go/no-go to Study 2 (pre-specified): proceed only if all of the following hold.**
- (a) P2 non-inferiority met for H1, H3 and B/Victoria against each comparator.
- (b) On the forward H3N2 panel at day 29, the lower 95% bound is > 1.0 against **both** comparators, with a point estimate ≥ 1.3.
- (c) The day-181 point estimate on the same panel is ≥ 1.2.
- (d) Reactogenicity and safety are acceptable.

**How to read the other outcomes.**
- Advantage against the egg-based comparator only: the benefit is avoiding egg adaptation, which non-egg vaccines already provide. There is no distinct claim.
- H1-only advantage (WU397's pattern): fix the H3 component before going to Phase 3.
- Day-29-only advantage (also WU397's pattern): no basis for a seasonal protection claim.

### Study 2: Phase 3 relative-efficacy trial with a mismatched-strain endpoint (the study that supports "protection")

**Conditions**
- Randomised 1:1, observer-blind, active-controlled, event-driven, multinational.
- Runs across ≥2 seasons and/or both hemispheres, so that enough mismatched-strain cases accrue.
- Population: the claim's target population (for example ≥50 or ≥65), stratified 50–64 / 65–74 / ≥75.
- Comparator: a licensed, age-appropriate vaccine with the same season's strain designations (preferentially recommended vaccine if ≥65).
- Trivalent composition and dose locked from Study 1.

**Readouts: measured / in whom / against what**

| Readout | Specification |
|---|---|
| Primary | **In whom:** the per-protocol efficacy set from 14 days after vaccination to end of season. **Measured:** first episode of PCR-confirmed, protocol-defined influenza-like illness caused by any influenza A or B. **Estimand:** relative vaccine efficacy (rVE), mRNA vs comparator. **Criterion:** non-inferiority, then superiority with lower bound > 0%. |
| **Key secondary (the claim)** | **Measured:** rVE against PCR-confirmed illness caused by **antigenically dissimilar** viruses. **How cases are classified:** every positive specimen is sequenced and then classified by an algorithm fixed in the SAP before unblinding and applied blind to arm. The algorithm combines HA genetic subclade relative to the vaccine strain with antigenic characterisation against reference post-vaccination human sera and ferret antisera, using a pre-specified fold-drop threshold. |
| Secondary | rVE against matched strains. Results by subtype (especially dissimilar H3N2), by age, and early vs late season (waning). Medically attended or hospitalised influenza. Safety. |
| Immunogenicity / correlates sub-cohort | **In whom:** a random sub-cohort plus all cases (case-cohort design). **When:** day 0, day 29 and end of season. **Measured:** HAI and neutralising titres against the vaccine strains, the forward panel and representative case viruses, plus NA-inhibiting titres. **Purpose:** (i) establish whether titre against drifted strains predicts protection, which would support future strain changes on immunogenicity alone; (ii) provide the regulatory immunogenicity non-inferiority dataset (GMT ratio and seroconversion, about 500 per arm). |
| Size | Case-driven. To show rVE > 0 against dissimilar strains: about 247 cases for 80% power or 331 for 90% if true rVE is 30%; about 380 / 508 if 25% (analysis/15). Enrolment = required cases ÷ (attack rate × share of dissimilar cases). Require a minimum number of dissimilar cases before the key-secondary analysis. |

### Study 3 (optional): heterologous controlled human infection

This is supportive only. It cannot support licensure on its own because challenge strains are few and participants are young.

- **In whom:** healthy adults aged 18–50 with low pre-existing neutralising titre against the challenge virus.
- **Arms:** randomised to mRNA vs a licensed comparator with the same strain designations, with or without placebo.
- **Challenge:** 4–8 weeks after vaccination, with a characterised challenge virus of the same subtype that is antigenically heterologous to both vaccines' strains (H3N2 preferred).
- **Endpoints:** PCR-confirmed infection, symptomatic infection and viral shedding, plus pre-challenge titre against the challenge virus as a correlate.
- **Size:** about 82 per arm (80% power) for a 50% relative reduction at a 40% comparator attack rate; 133 per arm for a 40% reduction.

---

## 4. What to drop from the current plan

- **The B/Yamagata component and all B/Yamagata readouts.** Also consider using the freed slot for a second H3N2 antigen from a co-circulating clade, tested as its own arm.
- **Binding breadth (bead array or ELISA) and mAb cross-reactivity as evidence of breadth.** H3 binding rose about 7–12× more than with Fluarix, while neutralisation rose no more than with Fluarix.
- **Fold-rise as the primary metric.**
- **Egg-adapted viruses in heterologous endpoints.**
- **Pooled week 17/26 visits.**
- **Per-assay convenience subsets.**
- **Lymph-node aspiration and germinal-centre data as endpoints.** The WU397 cohort was 6 vs 11.
- **"Homologous/heterologous" defined by one arm's antigens.**
- **Heterosubtypic (for example H5) claims.**
- **Conflating two different claims.** If the commercial case is faster strain updates ("better match"), that is a different claim from intrinsic breadth and needs its own design. WU397's choice of a newer H1 strain mixed the two.

## 5. Data-integrity issues to resolve before WU397 figures go into the protocol rationale

From analysis/11 and the logs:

1. **Late-visit labels disagree.**
   - HAI B/Victoria late-visit labels (wk17 vs wk26) differ from the other three antigens for 8 participants: 007, 008, 009, 010, 016, 018, 021 and 023.
   - The sequencing-based file labels 397-007 and 397-011 as day 121, while MN, ELISA and most HAI rows say week 26.
2. **Participant 397-014 has implausible MN titres.** MN was 15/10/10 (homologous) and 10/10/10 (heterologous) at weeks 0/4/26 while HAI rose 57→320 (H1) and 40→226 (H3). 397-014 and 397-019 are also absent from the sequencing-based data.
3. **397-031 has no B/Victoria HAI data.**
4. **`gc_frequencies.csv` contains two complete blocks** (156 rows, each key appearing twice) with conflicting values under one column name. Its timepoints (wk0/2/8/17/26) do not match the protocol's aspiration schedule (weeks 1/2/4/8/17/26).
5. **`plasmablast_frequencies.csv` timepoints do not match the blood schedule.** It uses wk2/wk8, but blood was drawn on days 0/7/29/121/181. It has no week-1 data, even though the plasmablast–GC overlap file uses week-1 plasmablasts.
6. **The IgM file has problems.**
   - It covers 15/14 participants, not the 37/38 stated in the summary.
   - One ID is unpadded ("20").
   - Fluarix participant 397-005 shows a 166–212× IgM rise for all four antigens.
7. **Other formatting problems.**
   - Participant IDs are inconsistent: 397-06 vs 397-006, and plain integers in the ELISA file.
   - One virus name is malformed: "A/SOUTHAFRICA/R07876/202023".
   - A/Darwin/9/2021 is an egg-derived virus with no reassortant label.

## 6. Where every number came from

**Data files** (in `/tmp/world/filesystem/`):

| Tag | File(s) |
|---|---|
| [H] | `hai_titers.csv` |
| [M] | `microneutralization.csv` |
| [S] | `neutralization_seqbased.csv` (81 sera, 96 viruses, 7,719 rows; 171 values at or below the detection limit, 70 above the upper limit) |
| [E] | `elisa_igg_titers.csv` |
| [B] | `binding_breadth_h1.csv`, `binding_breadth_h3.csv` |
| [Ab] | `mab_binding_panels.csv` (binder = >10-fold over the RBD control, which is fixed at 1.0) |
| [G] | `gc_frequencies.csv` (block 1 used) |
| [P] | `plasmablast_frequencies.csv` |
| [R] | `repertoire_clonotype_counts.csv` |
| [I] | `igm_fold_change.csv` |
| — | `trial_summary.md` (design, compositions, cohort sizes) |

**Derivations.** Scripts and result tables are listed in `analysis/README.md`. Each number is recorded with its source and derivation in **`key_numbers.csv`** (232 entries).

**External facts (not in the package):**

| Tag | Fact |
|---|---|
| [X1] | WHO recommended composition for 2022–23 NH, egg-based: A/Victoria/2570/2019 (H1N1)pdm09-like, A/Darwin/9/2021 (H3N2)-like, B/Austria/1359417/2021-like, B/Phuket/3073/2013-like. Cell/recombinant-based: A/Wisconsin/588/2019-like and A/Darwin/6/2021-like. These are the strains on the 2022–23 Fluarix label. |
| [X2] | WHO 2023–24 NH: egg-based A/Victoria/4897/2022 and cell-based A/Wisconsin/67/2022 (H1N1)pdm09-like, clade 5a.2a.1. |
| [X3] | No confirmed B/Yamagata detections since March 2020. WHO (September 2023) advised removing it; FDA/VRBPAC moved US vaccines to trivalent for 2024–25. |
| [X4] | WHO 2024–25 NH H3N2: A/Thailand/8/2022 (egg) and A/Massachusetts/18/2022 (cell). WHO 2025–26 NH H3N2: A/Croatia/10136RV/2023 (egg) and A/District of Columbia/27/2023 (cell). |
| [X5] | HAI 1:40 ≈ 50% protection (Hobson et al., 1972), established for vaccine-matched strains. |
| [X6] | ACIP (2022): high-dose, recombinant or adjuvanted vaccine preferred for ≥65. |
| [X7] | FDA/CBER 2007 seasonal inactivated influenza vaccine guidance: non-inferiority if the upper bound of the comparator/new GMT ratio ≤ 1.5 (equivalently, the lower bound of new/comparator ≥ 0.67) and the upper bound of the seroconversion difference ≤ 10 percentage points. |

**Caveats on my analysis.**
- WU397 is non-randomised, so baseline adjustment removes imbalance in the *measured* baseline titre but not site or age confounding.
- The MN panel viruses, HAI strains and binding-breadth timepoint are not stated in the package.
- Clade assignments are from WHO reports, not from sequences in the package.

## 7. Files

- `answer.md` — this document.
- `key_numbers.csv` — every cited number with its source and derivation.
- `wu397_key_findings.png` — panels A: per-virus neutralisation ratios; B: binding vs neutralisation; C: durability.
- `analysis/` — 18 scripts, `run_all.sh`, result tables, logs and a README.
