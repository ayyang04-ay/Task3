"""Bead-array binding breadth vs sequencing-based neutralisation, per participant (WU397)."""
import pandas as pd, numpy as np, os
from scipy import stats
pd.set_option('display.width',250); pd.set_option('display.max_rows',2000)
F='/tmp/world/filesystem/'; T='/tmp/outputs/analysis/tables/'
rows=[]
for f,sub in [('binding_breadth_h1.csv','H1'),('binding_breadth_h3.csv','H3')]:
    b=pd.read_csv(F+f)
    for s,x in b.groupby('strain'):
        a=x[x.arm=='mRNA-1010'].log2_fold_change_mfi; c=x[x.arm=='Fluarix'].log2_fold_change_mfi
        t=stats.ttest_ind(a,c,equal_var=False)
        diff=a.mean()-c.mean(); se=np.sqrt(a.var(ddof=1)/len(a)+c.var(ddof=1)/len(c))
        dfw=(a.var(ddof=1)/len(a)+c.var(ddof=1)/len(c))**2/((a.var(ddof=1)/len(a))**2/(len(a)-1)+(c.var(ddof=1)/len(c))**2/(len(c)-1))
        q=stats.t.ppf(.975,dfw)
        mw=stats.mannwhitneyu(a,c)
        rows.append({'subtype':sub,'strain':s,'n_mRNA':len(a),'n_Flu':len(c),'mean_log2FC_mRNA':a.mean(),'mean_log2FC_Flu':c.mean(),
                     'fold_diff(2^diff)':2**diff,'lo95':2**(diff-q*se),'hi95':2**(diff+q*se),'welch_p':t.pvalue,'MWU_p':mw.pvalue})
B=pd.DataFrame(rows); B.round(3).to_csv(T+'binding_breadth_by_strain.csv',index=False)
print(B.round(2).to_string(index=False))

# per-participant: H3 binding mean log2FC (all 12 strains) vs seq-neut H3 contemporary WT log2 GMFR (d29/d0)
b3=pd.read_csv(F+'binding_breadth_h3.csv').groupby(['arm','participant']).log2_fold_change_mfi.mean().rename('H3_bind_log2FC')
b1=pd.read_csv(F+'binding_breadth_h1.csv').groupby(['arm','participant']).log2_fold_change_mfi.mean().rename('H1_bind_log2FC')
d=pd.read_csv(F+'neutralization_seqbased.csv')
d[['arm','participant','day']]=d.serum.str.extract(r'^(.*)_(397-\d+)_d(\d+)$')
cls=pd.read_csv(T+'seqneut_virus_classification.csv').set_index('virus').category
d['category']=d.virus.map(cls); d['lt']=np.log2(d.titer)
n=d[d.day.isin(['0','29'])].groupby(['category','arm','participant','day']).lt.mean().unstack('day')
n=(n['29']-n['0']).unstack('category')
m=pd.concat([b1,b3,n[['H1_contemporary_WT(2022-24)','H3_contemporary_WT(2022-24)','H3_vaccine_mRNA-matched']]],axis=1).dropna()
m.columns=['H1_bind_log2FC','H3_bind_log2FC','H1_contemp_neut_log2FR','H3_contemp_neut_log2FR','H3_Darwin6_neut_log2FR']
print(m.groupby(level='arm').mean().round(2))
for sub in ['H1','H3']:
    for arm in ['Fluarix','mRNA-1010']:
        x=m.loc[arm]; r=stats.spearmanr(x[f'{sub}_bind_log2FC'],x[f'{sub}_contemp_neut_log2FR'])
        print(sub,arm,'Spearman rho binding-FC vs neut-FR = %.2f (p=%.2f, n=%d)'%(r.correlation,r.pvalue,len(x)))
# ratio of neutralisation rise to binding rise
m['H3_neut_minus_bind']=m.H3_contemp_neut_log2FR-m.H3_bind_log2FC
m['H1_neut_minus_bind']=m.H1_contemp_neut_log2FR-m.H1_bind_log2FC
print(m.groupby(level='arm')[['H1_neut_minus_bind','H3_neut_minus_bind']].mean().round(2))
m.round(3).to_csv(T+'binding_vs_neutralisation_per_participant.csv')
