#!/bin/bash
# Re-runs the full WU397 re-analysis. Inputs are read-only from /tmp/world/filesystem; outputs go to /tmp/outputs/analysis.
set -e
cd /tmp/outputs/analysis
mkdir -p logs tables
for s in integrity_checks.py wu397_serology.py wu397_seqneut.py wu397_baseline_balance.py wu397_binding_vs_neut.py \
         wu397_same_strain.py wu397_mab.py wu397_cellular.py wu397_mn_identity.py wu397_power.py wu397_figure.py; do
  echo "== $s"; micromamba run -n core python $s > logs/${s%.py}.log 2>&1
done
echo done
