"""
Sequencing-based neutralisation re-analysis (WU397).
- Classifies each virus relative to BOTH arms' vaccine antigens (not only mRNA-1010's).
- Separates egg/production reassortants and historic strains from contemporary wild-type isolates.
- Baseline-adjusted arm comparison (ANCOVA on per-participant mean log2 titre across the viruses of a category).
- Censoring sensitivity: titres flagged 'upper' (<= value) and 'lower' (>= value) imputed at the bound (primary),
  at bound/2 and bound*2 (sensitivity).
"""
import pandas as pd, numpy as np, os, re
import statsmodels.formula.api as smf
from statsmodels.stats.multitest import multipletests
pd.set_option('display.width',250); pd.set_option('display.max_rows',2000); pd.set_option('display.max_columns',60)
F='/tmp/world/filesystem/'; T='/tmp/outputs/analysis/tables/'; os.makedirs(T,exist_ok=True)
d=pd.read_csv(F+'neutralization_seqbased.csv')
d[['arm','participant','day']]=d.serum.str.extract(r'^(.*)_(397-\d+)_d(\d+)$'); d['day']=d.day.astype(int)
d['tp']=d.day.map({0:'d0',29:'d29',121:'late',181:'late'})
d['subtype']=d.virus.str[-4:]

# ---- virus classification (names as given in the file) ----
mrna_equiv = {'A/Victoria/4897/2022_IVR-238_H1N1':'H1 mRNA-1010 antigen (egg reassortant of A/Victoria/4897/2022)',
              'A/Wisconsin/67/2022_H1N1':'H1 mRNA-1010 antigen-equivalent (cell-based A/Victoria/4897/2022-like)',
              'A/Darwin/6/2021_H3N2':'H3 mRNA-1010 antigen'}
flu_equiv  = {'A/Wisconsin/588/2019_H1N1':'H1 Fluarix 2022-23 antigen-equivalent (cell-based A/Victoria/2570/2019-like)',
              'A/Darwin/9/2021_H3N2':'H3 Fluarix 2022-23 antigen (egg-based A/Darwin/9/2021)'}
eggre = [v for v in d.virus.unique() if re.search(r'egg|X-\d+A|NIB-\d+|IVR-\d+',v)]
def yr(v):
    if '/202023_' in v: return 2023   # malformed year in source file; isolate name indicates 2023
    m=re.search(r'/(\d{4})(?:egg|X-\d+A|NIB-\d+)?(?:_IVR-\d+)?_H\dN\d$',v); return int(m.group(1)) if m else np.nan
def cat(v):
    st=v[-4:]
    if v in mrna_equiv: return f'{st[:2]}_vaccine_mRNA-matched'
    if v in flu_equiv: return f'{st[:2]}_vaccine_Fluarix-matched'
    if v in eggre: return f'{st[:2]}_egg/reassortant'
    y=yr(v)
    if y<=2020: return f'{st[:2]}_historic_WT(<=2020)'
    return f'{st[:2]}_contemporary_WT(2022-24)'
V=pd.DataFrame({'virus':sorted(d.virus.unique())}); V['year']=V.virus.map(yr); V['category']=V.virus.map(cat)
V['note']=V.virus.map({**mrna_equiv,**flu_equiv}).fillna('')
V.loc[V.virus.str.contains('202023'),'note']='malformed year in source (202023); treated as 2023'
V.loc[V.virus.str.contains('YAMAGATA'),'note']='influenza A(H3N2) isolate from Yamagata, Japan - not B/Yamagata lineage'
V.to_csv(T+'seqneut_virus_classification.csv',index=False)
print(V.groupby('category').size())
d=d.merge(V[['virus','category']],on='virus')

def impute(df,mode):
    t=df.titer.copy()
    if mode=='bound': pass
    elif mode=='wide':
        t[df.titer_bound=='upper']=df.titer[df.titer_bound=='upper']/2
        t[df.titer_bound=='lower']=df.titer[df.titer_bound=='lower']*2
    return np.log2(t)

# ---- censoring summary
cs=d.groupby(['category','arm','tp']).titer_bound.value_counts(normalize=True).unstack().fillna(0)*100
cs.round(1).to_csv(T+'seqneut_censoring_by_category.csv')

def ancova(df):
    df=df.dropna(subset=['pre','post']).copy(); df['mrna']=(df.arm=='mRNA-1010').astype(int)
    f=smf.ols('post ~ mrna + pre',data=df).fit()
    return 2**f.params['mrna'],*2**f.conf_int().loc['mrna'].values,f.pvalues['mrna'],len(df)

rows=[]
for mode in ['bound','wide']:
    d['lt']=impute(d,mode)
    # per participant x category mean log2 titre
    pc=d.groupby(['category','arm','participant','tp']).lt.mean().unstack('tp').reset_index()
    for c in sorted(pc.category.unique()):
        x=pc[pc.category==c]
        for post in ['d29','late']:
            r=ancova(pd.DataFrame({'arm':x.arm,'pre':x.d0,'post':x[post]}))
            g=x.groupby('arm')
            rows.append({'censoring':mode,'category':c,'post':post,'n_viruses':int((V.category==c).sum()),
                         'GMT_d0_Flu':2**g.d0.mean()['Fluarix'],'GMT_d0_mRNA':2**g.d0.mean()['mRNA-1010'],
                         f'GMT_post_Flu':2**g[post].mean()['Fluarix'],f'GMT_post_mRNA':2**g[post].mean()['mRNA-1010'],
                         'GMFR_Flu':2**(x[post]-x.d0)[x.arm=='Fluarix'].mean(),'GMFR_mRNA':2**(x[post]-x.d0)[x.arm=='mRNA-1010'].mean(),
                         'adj_GMT_ratio_mRNA/Flu':r[0],'lo95':r[1],'hi95':r[2],'p':r[3],'n_pairs':r[4]})
R=pd.DataFrame(rows); R.round(3).to_csv(T+'seqneut_category_ancova.csv',index=False)
print(R[R.censoring=='bound'].round(2).to_string(index=False)); print()
print(R[R.censoring=='wide'][['category','post','adj_GMT_ratio_mRNA/Flu','lo95','hi95','p']].round(2).to_string(index=False))

# ---- per-virus ANCOVA (bound imputation), BH-FDR
d['lt']=impute(d,'bound')
w=d.pivot_table(index=['virus','arm','participant'],columns='tp',values='lt').reset_index()
pv=[]
for v,x in w.groupby('virus'):
    r=ancova(pd.DataFrame({'arm':x.arm,'pre':x.d0,'post':x.d29}))
    g=x.groupby('arm')
    pv.append({'virus':v,'category':V.set_index('virus').category[v],
               'GMT_d0_Flu':2**g.d0.mean()['Fluarix'],'GMT_d0_mRNA':2**g.d0.mean()['mRNA-1010'],
               'GMT_d29_Flu':2**g.d29.mean()['Fluarix'],'GMT_d29_mRNA':2**g.d29.mean()['mRNA-1010'],
               'GMFR_Flu':2**(x.d29-x.d0)[x.arm=='Fluarix'].mean(),'GMFR_mRNA':2**(x.d29-x.d0)[x.arm=='mRNA-1010'].mean(),
               'pct4x_Flu':100*((x.d29-x.d0)[x.arm=='Fluarix']>=2).mean(),'pct4x_mRNA':100*((x.d29-x.d0)[x.arm=='mRNA-1010']>=2).mean(),
               'adj_ratio':r[0],'lo95':r[1],'hi95':r[2],'p':r[3]})
P=pd.DataFrame(pv); P['q_BH']=multipletests(P.p,method='fdr_bh')[1]
P=P.sort_values(['category','adj_ratio']); P.round(3).to_csv(T+'seqneut_per_virus_ancova.csv',index=False)
print(P.round(2).to_string(index=False))
print('\nViruses with BH q<0.05:'); print(P[P.q_BH<0.05][['virus','category','adj_ratio','lo95','hi95','q_BH']].round(3).to_string(index=False))
print('\nSummary of per-virus adjusted ratios by category:')
print(P.groupby('category').adj_ratio.describe()[['count','min','50%','max']].round(2))

# ---- H3 contemporary strains poorly neutralised at baseline in BOTH arms (baseline GMT <100 in each arm)
adv=P[(P.category=='H3_contemporary_WT(2022-24)')&(P.GMT_d0_Flu<100)&(P.GMT_d0_mRNA<100)].virus.tolist()
print('\nLow-baseline (antigenically advanced) H3 viruses:',adv)
x=d[d.virus.isin(adv)].groupby(['arm','participant','tp']).lt.mean().unstack('tp').reset_index()
for post in ['d29','late']:
    r=ancova(pd.DataFrame({'arm':x.arm,'pre':x.d0,'post':x[post]}))
    g=x.groupby('arm')
    print(post,'GMT d0 Flu/mRNA %.1f/%.1f'%(2**g.d0.mean()['Fluarix'],2**g.d0.mean()['mRNA-1010']),
          'post Flu/mRNA %.1f/%.1f'%(2**g[post].mean()['Fluarix'],2**g[post].mean()['mRNA-1010']),
          'adj ratio %.2f (%.2f-%.2f) p=%.2f n=%d'%r)
cens=d[d.virus.isin(adv)].groupby(['arm','tp']).titer_bound.apply(lambda z:(z=='upper').mean()*100).round(1)
print('percent of titres censored at <=40 in this subset:',cens.to_dict())

# ---- waning: mean log2 change from d29 to d121/181 (per-participant category means), by arm
d['lt']=impute(d,'bound')
pc=d.groupby(['category','arm','participant','tp']).lt.mean().unstack('tp').reset_index()
pc['d29_to_late']=pc['late']-pc['d29']
wan=pc.groupby(['category','arm']).d29_to_late.agg(['mean','count']).reset_index()
wan['fold_change_d29_to_late']=2**wan['mean']
print('\nWaning d29 -> d121/181 (fold change of GMT, per-participant category means):')
print(wan.round(2).to_string(index=False))
wan.round(3).to_csv(T+'seqneut_waning.csv',index=False)

# ---- per-category average of the per-virus % of participants with >=4-fold rise at d29
print('\nMean (range) across viruses of % participants with >=4-fold rise d0->d29:')
g=P.groupby('category').agg(Flu_mean=('pct4x_Flu','mean'),Flu_min=('pct4x_Flu','min'),Flu_max=('pct4x_Flu','max'),
                            mRNA_mean=('pct4x_mRNA','mean'),mRNA_min=('pct4x_mRNA','min'),mRNA_max=('pct4x_mRNA','max'))
print(g.round(1).to_string()); g.round(2).to_csv(T+'seqneut_pct4fold_by_category.csv')

# ---- durability restricted to day-181 sera only (excludes the day-121 sera pooled into 'late')
d['lt']=impute(d,'bound')
x=d.groupby(['category','arm','participant','day'])['lt'].mean().unstack('day').reset_index()
print('\nDay-181-only baseline-adjusted GMT ratio (mRNA/Fluarix):')
for c in ['H1_contemporary_WT(2022-24)','H3_contemporary_WT(2022-24)','H1_vaccine_mRNA-matched','H3_vaccine_mRNA-matched']:
    y=x[(x.category==c)&x[181].notna()]
    r=ancova(pd.DataFrame({'arm':y.arm,'pre':y[0],'post':y[181]}))
    print('  %s: %.2f (%.2f-%.2f), n=%d'%(c,r[0],r[1],r[2],r[4]))
