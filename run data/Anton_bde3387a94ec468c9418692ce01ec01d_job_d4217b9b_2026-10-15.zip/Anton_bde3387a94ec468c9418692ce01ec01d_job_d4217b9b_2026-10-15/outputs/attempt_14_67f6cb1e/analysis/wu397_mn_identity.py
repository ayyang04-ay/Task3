"""Which seq-neut virus best tracks the MN 'homologous' / 'heterologous' titres? (panel identity is not stated in the package)"""
import pandas as pd, numpy as np
from scipy import stats
F='/tmp/world/filesystem/'
m=pd.read_csv(F+'microneutralization.csv'); m=m[(m.measure=='titer')&(m.timepoint.isin(['wk0','wk4']))]
m['day']=m.timepoint.map({'wk0':'0','wk4':'29'})
d=pd.read_csv(F+'neutralization_seqbased.csv')
d[['arm','participant','day']]=d.serum.str.extract(r'^(.*)_(397-\d+)_d(\d+)$')
d=d[d.day.isin(['0','29'])]
res=[]
for p in ['homologous','heterologous']:
    mm_=m[m.panel==p][['participant','day','value']]
    for v,x in d.groupby('virus'):
        j=mm_.merge(x[['participant','day','titer']],on=['participant','day'])
        r=stats.spearmanr(np.log2(j.value),np.log2(j.titer)).correlation
        # also correlation of fold-rise
        jw=j.pivot_table(index='participant',columns='day',values=['value','titer'])
        fr=stats.spearmanr(np.log2(jw['value']['29']/jw['value']['0']),np.log2(jw['titer']['29']/jw['titer']['0'])).correlation
        res.append((p,v,len(j),r,fr))
R=pd.DataFrame(res,columns=['MN_panel','seqneut_virus','n_pairs','rho_titre','rho_foldrise'])
for p in ['homologous','heterologous']:
    print(p); print(R[R.MN_panel==p].sort_values('rho_titre',ascending=False).head(8).round(2).to_string(index=False))
    print(' by subtype, median rho titre:',R[R.MN_panel==p].assign(st=lambda z:z.seqneut_virus.str[-4:]).groupby('st').rho_titre.median().round(2).to_dict())
R.round(3).to_csv('/tmp/outputs/analysis/tables/mn_vs_seqneut_correlation.csv',index=False)
