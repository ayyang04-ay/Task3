"""Baseline (day 0) balance between arms - seq-neut categories, HAI, MN, ELISA (WU397)."""
import pandas as pd, numpy as np
from scipy import stats
F='/tmp/world/filesystem/'; T='/tmp/outputs/analysis/tables/'
def cmp(a,f):
    diff=a.mean()-f.mean(); va=a.var(ddof=1)/len(a); vf=f.var(ddof=1)/len(f); se=np.sqrt(va+vf)
    df=(va+vf)**2/(va**2/(len(a)-1)+vf**2/(len(f)-1)); q=stats.t.ppf(.975,df)
    return 2**diff,2**(diff-q*se),2**(diff+q*se),2*stats.t.sf(abs(diff/se),df),len(a),len(f)
rows=[]
d=pd.read_csv(F+'neutralization_seqbased.csv')
d[['arm','participant','day']]=d.serum.str.extract(r'^(.*)_(397-\d+)_d(\d+)$')
cls=pd.read_csv(T+'seqneut_virus_classification.csv').set_index('virus').category
d['category']=d.virus.map(cls); d['lt']=np.log2(d.titer)
b=d[d.day=='0'].groupby(['category','arm','participant'])['lt'].mean().reset_index()
for c,x in b.groupby('category'):
    rows.append(('seq-neut '+c,)+cmp(x[x.arm=='mRNA-1010']['lt'],x[x.arm=='Fluarix']['lt']))
h=pd.read_csv(F+'hai_titers.csv'); h=h[h.timepoint=='wk0']
for ag,x in h.groupby('antigen'):
    rows.append(('HAI '+ag,)+cmp(np.log2(x[x.arm=='mRNA-1010'].hai_titer),np.log2(x[x.arm=='Fluarix'].hai_titer)))
m=pd.read_csv(F+'microneutralization.csv'); m=m[(m.timepoint=='wk0')&(m.measure=='titer')]
for p,x in m.groupby('panel'):
    rows.append(('MN '+p,)+cmp(np.log2(x[x.arm=='mRNA-1010'].value),np.log2(x[x.arm=='Fluarix'].value)))
e=pd.read_csv(F+'elisa_igg_titers.csv'); e=e[(e.timepoint=='wk0')&(e.measure=='ec50')]
for ag,x in e.groupby('antigen'):
    rows.append(('ELISA '+ag,)+cmp(np.log2(x[x.arm=='mRNA-1010'].value),np.log2(x[x.arm=='Fluarix'].value)))
R=pd.DataFrame(rows,columns=['readout','baseline_GMT_ratio_mRNA/Flu','lo95','hi95','p','n_mRNA','n_Flu'])
R.round(3).to_csv(T+'baseline_balance.csv',index=False); print(R.round(2).to_string(index=False))

# ---- does fold-rise depend on baseline? (within-arm slope of log2 fold-rise on log2 baseline, seq-neut category means)
import statsmodels.formula.api as smf
x=d[d.day.isin(['0','29'])].groupby(['category','arm','participant','day'])['lt'].mean().unstack('day').reset_index()
x.columns=['category','arm','participant','d0','d29']; x['fr']=x.d29-x.d0; x['mrna']=(x.arm=='mRNA-1010').astype(int)
rows=[]
for c in sorted(x.category.unique()):
    y=x[x.category==c]
    f=smf.ols('fr ~ d0 + mrna',data=y).fit(); f2=smf.ols('fr ~ mrna',data=y).fit()
    rows.append({'category':c,'slope_foldrise_on_baseline':f.params['d0'],'slope_lo':f.conf_int().loc['d0'][0],'slope_hi':f.conf_int().loc['d0'][1],
                 'unadj_foldrise_ratio':2**f2.params['mrna'],'unadj_lo':2**f2.conf_int().loc['mrna'][0],'unadj_hi':2**f2.conf_int().loc['mrna'][1],
                 'baseline_adj_ratio':2**f.params['mrna'],'adj_lo':2**f.conf_int().loc['mrna'][0],'adj_hi':2**f.conf_int().loc['mrna'][1]})
S=pd.DataFrame(rows); S.round(3).to_csv(T+'foldrise_vs_baseline.csv',index=False)
print('\nFold-rise vs baseline (seq-neut, per-participant category means):'); print(S.round(2).to_string(index=False))
