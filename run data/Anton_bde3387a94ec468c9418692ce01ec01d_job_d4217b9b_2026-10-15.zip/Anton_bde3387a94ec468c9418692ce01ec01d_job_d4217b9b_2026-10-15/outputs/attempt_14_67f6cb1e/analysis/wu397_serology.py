"""
WU397 serology re-analysis (HAI, MN, ELISA IgG, bead-array breadth).
Outputs tables to /tmp/outputs/analysis/tables/.
Conventions: titres analysed on log2 scale; GMT = 2^mean(log2); GMFR = 2^mean(log2 post - log2 pre).
Baseline-adjusted comparison = ANCOVA: log2(post) ~ arm + log2(pre); reported as adjusted GMT ratio mRNA/Fluarix.
Seroconversion (HAI) = >=4-fold rise AND post >=40 (or pre <10 and post >=40); seroprotection = titre >=40.
"""
import pandas as pd, numpy as np, os
import statsmodels.formula.api as smf
from scipy import stats
pd.set_option('display.width',250); pd.set_option('display.max_rows',2000); pd.set_option('display.max_columns',50)
F='/tmp/world/filesystem/'; T='/tmp/outputs/analysis/tables/'; os.makedirs(T,exist_ok=True)

def welch_ci(a,b):
    a=np.asarray(a); b=np.asarray(b)
    m=a.mean()-b.mean(); va=a.var(ddof=1)/len(a); vb=b.var(ddof=1)/len(b)
    se=np.sqrt(va+vb); df=(va+vb)**2/(va**2/(len(a)-1)+vb**2/(len(b)-1))
    t=stats.t.ppf(0.975,df); p=2*stats.t.sf(abs(m/se),df)
    return m,m-t*se,m+t*se,p

def ancova(df):
    # df columns: arm, pre, post (log2)
    df=df.dropna(subset=['pre','post']).copy()
    df['mrna']=(df.arm=='mRNA-1010').astype(int)
    fit=smf.ols('post ~ mrna + pre',data=df).fit()
    b=fit.params['mrna']; lo,hi=fit.conf_int().loc['mrna']; p=fit.pvalues['mrna']
    return 2**b,2**lo,2**hi,p,fit.resid.std(ddof=3)

def summarise(w, label, post='wk4', pre='wk0', hai=False):
    """w: DataFrame index participant with columns arm, pre, post timepoints (raw titres)"""
    rows=[]
    for arm in ['Fluarix','mRNA-1010']:
        x=w[w.arm==arm].dropna(subset=[pre,post])
        lp=np.log2(x[pre]); lq=np.log2(x[post])
        r={'assay':label,'arm':arm,'n':len(x),'GMT_pre':2**lp.mean(),'GMT_post':2**lq.mean(),'GMFR':2**(lq-lp).mean(),
           'pct_4fold':100*((lq-lp)>=2-1e-9).mean()}
        if hai:
            sc=(((lq-lp)>=2-1e-9)&(x[post]>=40))|((x[pre]<10)&(x[post]>=40))
            r.update({'SCR_pct':100*sc.mean(),'SPR_pre_pct':100*(x[pre]>=40).mean(),'SPR_post_pct':100*(x[post]>=40).mean()})
        rows.append(r)
    out=pd.DataFrame(rows)
    x=w.dropna(subset=[pre,post])
    a=np.log2(x[x.arm=='mRNA-1010'][post]); b=np.log2(x[x.arm=='Fluarix'][post])
    m,lo,hi,p=welch_ci(a,b)
    fa=np.log2(x[x.arm=='mRNA-1010'][post])-np.log2(x[x.arm=='mRNA-1010'][pre]); fb=np.log2(x[x.arm=='Fluarix'][post])-np.log2(x[x.arm=='Fluarix'][pre])
    mf,lof,hif,pf=welch_ci(fa,fb)
    a0=np.log2(x[x.arm=='mRNA-1010'][pre]); b0=np.log2(x[x.arm=='Fluarix'][pre])
    m0,lo0,hi0,p0=welch_ci(a0,b0)
    r,rlo,rhi,rp,rsd=ancova(pd.DataFrame({'arm':x.arm,'pre':np.log2(x[pre]),'post':np.log2(x[post])}))
    comp={'assay':label,'baseline_GMT_ratio':2**m0,'bl_lo':2**lo0,'bl_hi':2**hi0,'bl_p':p0,
          'post_GMT_ratio_unadj':2**m,'unadj_lo':2**lo,'unadj_hi':2**hi,'unadj_p':p,
          'GMFR_ratio':2**mf,'gmfr_lo':2**lof,'gmfr_hi':2**hif,'gmfr_p':pf,
          'post_GMT_ratio_adj':r,'adj_lo':rlo,'adj_hi':rhi,'adj_p':rp,'resid_SD_log2':rsd,
          'SD_log2_post_pooled':np.sqrt(((len(a)-1)*a.var(ddof=1)+(len(b)-1)*b.var(ddof=1))/(len(a)+len(b)-2))}
    return out, comp

per_arm=[]; comps=[]
# ---------------- HAI
h=pd.read_csv(F+'hai_titers.csv',dtype={'participant':str})
# HAI values are geometric means of replicate 2-fold dilutions rounded to integers (e.g. 57 = 40*sqrt2, 226 = 160*sqrt2);
# snap them back to exact half-log2 steps so that a true 4-fold rise (e.g. 57 -> 226) is not lost to rounding.
_l=np.log2(h.hai_titer/10); _s=np.round(_l*2)/2
h['hai_titer']=np.where(np.abs(_l-_s)<0.03,10*2**_s,h.hai_titer)
for ag in ['A/H1N1','A/H3N2','B/Vic','B/Yam']:
    w=h[h.antigen==ag].pivot_table(index=['participant','arm'],columns='timepoint',values='hai_titer').reset_index()
    w['late']=w['wk26'].fillna(w['wk17'])
    o,c=summarise(w,f'HAI {ag} wk4',hai=True); per_arm.append(o); comps.append(c)
    o,c=summarise(w,f'HAI {ag} wk17/26',post='late',hai=True); per_arm.append(o); comps.append(c)
# ---------------- MN
m=pd.read_csv(F+'microneutralization.csv',dtype={'participant':str}); m=m[m.measure=='titer']
for pn in ['homologous','heterologous']:
    w=m[m.panel==pn].pivot_table(index=['participant','arm'],columns='timepoint',values='value').reset_index()
    w['late']=w['wk26'].fillna(w['wk17'])
    o,c=summarise(w,f'MN {pn} wk4'); per_arm.append(o); comps.append(c)
    o,c=summarise(w,f'MN {pn} wk17/26',post='late'); per_arm.append(o); comps.append(c)
# ---------------- ELISA
e=pd.read_csv(F+'elisa_igg_titers.csv',dtype={'participant':str}); e=e[e.measure=='ec50']
for ag in ['A/H1','A/H3','B/Vic','B/Yam']:
    w=e[e.antigen==ag].pivot_table(index=['participant','arm'],columns='timepoint',values='value').reset_index()
    w['late']=w['wk26'].fillna(w['wk17'])
    o,c=summarise(w,f'ELISA IgG {ag} wk4'); per_arm.append(o); comps.append(c)
    o,c=summarise(w,f'ELISA IgG {ag} wk17/26',post='late'); per_arm.append(o); comps.append(c)
# ELISA restricted to the 29 HAI-cohort participants (IDs <=32) vs the additional participants
e['cohort']=np.where(e.participant.astype(int)<=32,'core(<=032)','extra(>=033)')
ecoh=[]
for ag in ['A/H1','A/H3','B/Vic','B/Yam']:
    for coh in ['core(<=032)','extra(>=033)']:
        w=e[(e.antigen==ag)&(e.cohort==coh)].pivot_table(index=['participant','arm'],columns='timepoint',values='value').reset_index()
        o,c=summarise(w,f'ELISA IgG {ag} wk4 {coh}'); ecoh.append(o)
PA=pd.concat(per_arm); C=pd.DataFrame(comps)
PA.round(2).to_csv(T+'serology_per_arm.csv',index=False); C.round(4).to_csv(T+'serology_arm_comparisons.csv',index=False)
pd.concat(ecoh).round(2).to_csv(T+'elisa_by_id_block.csv',index=False)
print(PA.round(2).to_string(index=False)); print()
print(C[['assay','baseline_GMT_ratio','bl_lo','bl_hi','post_GMT_ratio_unadj','unadj_lo','unadj_hi','GMFR_ratio','gmfr_lo','gmfr_hi','post_GMT_ratio_adj','adj_lo','adj_hi','adj_p','resid_SD_log2','SD_log2_post_pooled']].round(2).to_string(index=False))
print(); print(pd.concat(ecoh).round(2).to_string(index=False))
