"""Same strain, two readouts: bead-array binding fold-rise ratio vs seq-neut baseline-adjusted neutralising GMT ratio (mRNA-1010/Fluarix)."""
import pandas as pd, numpy as np
T='/tmp/outputs/analysis/tables/'
B=pd.read_csv(T+'binding_breadth_by_strain.csv'); P=pd.read_csv(T+'seqneut_per_virus_ancova.csv')
pairs={'A/Brisbane/2/2018':'A/Brisbane/02/2018_H1N1','A/Hawaii/70/2019':'A/Hawaii/70/2019_H1N1','A/Michigan/45/2015':'A/Michigan/45/2015_H1N1',
       'A/Wisconsin/588/2019':'A/Wisconsin/588/2019_H1N1','A/Wisconsin/67/2022':'A/Wisconsin/67/2022_H1N1',
       'A/Texas/50/2012':'A/Texas/50/2012_H3N2','A/Singapore/INFIMH-16-0019/2016':'A/Singapore/INFIMH-16-0019/2016_H3N2',
       'A/Hong Kong/2671/2019':'A/HongKong/2671/2019_H3N2','A/Cambodia/e0826360/2020':'A/Cambodia/e0826360/2020_H3N2',
       'A/Darwin/6/2021':'A/Darwin/6/2021_H3N2','A/Thailand/8/2022':'A/Thailand/8/2022_H3N2'}
rows=[]
for b,s in pairs.items():
    rb=B[B.strain==b].iloc[0]; rs=P[P.virus==s].iloc[0]
    rows.append({'strain':b,'subtype':rb.subtype,'binding_foldrise_ratio':rb['fold_diff(2^diff)'],'bind_lo':rb.lo95,'bind_hi':rb.hi95,
                 'neut_adj_GMT_ratio':rs.adj_ratio,'neut_lo':rs.lo95,'neut_hi':rs.hi95,'neut_GMT_d29_mRNA':rs.GMT_d29_mRNA,'neut_GMT_d29_Flu':rs.GMT_d29_Flu})
R=pd.DataFrame(rows); R.round(2).to_csv(T+'same_strain_binding_vs_neutralisation.csv',index=False); print(R.round(2).to_string(index=False))
