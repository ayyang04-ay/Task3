"""Lymph-node / cellular / repertoire summaries (WU397). Descriptive only; see integrity caveats."""
import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width',250); pd.set_option('display.max_rows',2000); pd.set_option('display.max_columns',50)
F='/tmp/world/filesystem/'; T='/tmp/outputs/analysis/tables/'
gc=pd.read_csv(F+'gc_frequencies.csv',dtype={'participant':str})
gc['block']=gc.groupby(['timepoint','arm','participant']).cumcount().map({0:'block1',1:'block2'})
rows=[]
for (b,tp),x in gc.groupby(['block','timepoint']):
    a=x[x.arm=='mRNA-1010'].pct_ha_specific_igg_gc; f=x[x.arm=='Fluarix'].pct_ha_specific_igg_gc
    p=stats.mannwhitneyu(a,f).pvalue if len(a) and len(f) else np.nan
    rows.append({'block':b,'timepoint':tp,'n_mRNA':len(a),'median_mRNA':a.median(),'n_Flu':len(f),'median_Flu':f.median(),'MWU_p':p})
G=pd.DataFrame(rows); print(G.round(3).to_string(index=False)); G.round(4).to_csv(T+'gc_summary.csv',index=False)
pb=pd.read_csv(F+'plasmablast_frequencies.csv',dtype={'participant':str})
rows=[]
for tp,x in pb.groupby('timepoint'):
    a=x[x.arm=='mRNA-1010'].pct_plasmablast; f=x[x.arm=='Fluarix'].pct_plasmablast
    rows.append({'timepoint':tp,'n_mRNA':len(a),'median_mRNA':a.median(),'n_Flu':len(f),'median_Flu':f.median(),'MWU_p':stats.mannwhitneyu(a,f).pvalue})
P=pd.DataFrame(rows); print(P.round(4).to_string(index=False)); P.round(5).to_csv(T+'plasmablast_summary.csv',index=False)
# repertoire
rc=pd.read_csv(F+'repertoire_clonotype_counts.csv')
print(rc.groupby(['metric','arm']).value.agg(['count','median','mean']).round(1))
for mtr in rc.metric.unique():
    x=rc[rc.metric==mtr]; print(mtr,'MWU p=%.3f'%stats.mannwhitneyu(x[x.arm=='mRNA-1010'].value,x[x.arm=='Fluarix'].value).pvalue)
sc=pd.read_csv(F+'serum_igg_clonotypes.csv'); print(sc.groupby(['timepoint','arm']).n_clonotypes.agg(['count','median']))
cd=pd.read_csv(F+'cdrh3_diversity_index.csv'); print(cd.groupby(['timepoint','arm']).diversity_index.agg(['count','median']).round(1))
ov=pd.read_csv(F+'pb_gc_clonal_overlap.csv'); print(ov.iloc[:,[0,2,4,5,8,9]].to_string(index=False))
