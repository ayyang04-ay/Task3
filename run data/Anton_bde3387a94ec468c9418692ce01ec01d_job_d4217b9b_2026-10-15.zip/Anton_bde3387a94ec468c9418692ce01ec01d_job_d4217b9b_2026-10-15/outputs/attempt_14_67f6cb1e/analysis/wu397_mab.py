"""Monoclonal antibody panel re-analysis (WU397): donor-level summaries (mAbs are clustered within donors)."""
import pandas as pd, numpy as np
pd.set_option('display.width',250); pd.set_option('display.max_rows',2000); pd.set_option('display.max_columns',50)
F='/tmp/world/filesystem/'; T='/tmp/outputs/analysis/tables/'
d=pd.read_csv(F+'mab_binding_panels.csv'); d['donor']='397-0'+d.mab_id.str.split('.').str[1]
THR=5  # fold over SARS-CoV-2 RBD control; sensitivity at 3 and 10 below
vacc={'group_I':['A/Wisconsin/588/2019','A/Victoria/4897/2022'],'group_II':['A/Darwin/6/2021']}
out=[]
for thr in [3,5,10]:
  for panel in ['group_I','group_II']:
    w=d[d.panel==panel].pivot_table(index=['arm','donor','mab_id'],columns='antigen',values='fold_over_control').drop(columns='SARS-CoV-2 RBD')
    pos=w>thr
    anypos=pos.any(axis=1)
    het=[c for c in w.columns if c not in vacc[panel]]
    for (arm,donor),x in pos.groupby(level=['arm','donor']):
        xs=x[anypos.loc[x.index]]
        r={'threshold':thr,'panel':panel,'arm':arm,'donor':donor,'n_mAbs':len(x),'n_binding_any':len(xs)}
        for c in w.columns: r[c]=round(100*xs[c].mean(),1) if len(xs) else np.nan
        r['mean_n_heterologous_bound']=round(xs[het].sum(axis=1).mean(),2) if len(xs) else np.nan
        out.append(r)
O=pd.DataFrame(out); O.to_csv(T+'mab_donor_level_binding.csv',index=False)
print(O[O.threshold==5].to_string(index=False))
# share of each arm's mAbs contributed by the largest donor
c=d.groupby(['arm','donor']).mab_id.nunique()
print(c); print((c/c.groupby(level=0).transform('sum')).round(3))
