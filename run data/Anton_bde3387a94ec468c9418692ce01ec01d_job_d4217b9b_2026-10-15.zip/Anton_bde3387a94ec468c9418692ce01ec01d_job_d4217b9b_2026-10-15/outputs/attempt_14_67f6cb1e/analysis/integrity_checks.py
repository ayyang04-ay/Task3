"""Data-integrity checks on the WU397 package (read-only; inputs in /tmp/world/filesystem)."""
import pandas as pd, numpy as np, re
pd.set_option('display.width',250); pd.set_option('display.max_rows',2000); pd.set_option('display.max_columns',50)
F='/tmp/world/filesystem/'
out=[]
def log(*a):
    s=' '.join(str(x) for x in a); print(s); out.append(s)

# 1. ELISA fold-change recomputation
e=pd.read_csv(F+'elisa_igg_titers.csv',dtype={'participant':str})
ec=e[e.measure=='ec50'].pivot_table(index=['antigen','arm','participant'],columns='timepoint',values='value')
fc=e[e.measure=='fold_change'].pivot_table(index=['antigen','arm','participant'],columns='timepoint',values='value')
late=ec['wk26'].fillna(ec['wk17'])
chk=pd.DataFrame({'fc4_rep':fc['wk4'],'fc4_calc':ec['wk4']/ec['wk0'],'fcl_rep':fc['wk17/26'],'fcl_calc':late/ec['wk0']})
chk['d4']=np.abs(np.log(chk.fc4_rep/chk.fc4_calc)); chk['dl']=np.abs(np.log(chk.fcl_rep/chk.fcl_calc))
log('ELISA: max |log ratio| reported vs recomputed FC wk4 =',round(chk.d4.max(),4),' wk17/26 =',round(chk.dl.max(),4))
log('ELISA: rows with wk17 AND wk26 both present:',int((ec['wk17'].notna()&ec['wk26'].notna()).sum()),'; rows with neither:',int((ec['wk17'].isna()&ec['wk26'].isna()).sum()))
bad=chk[(chk.d4>0.01)|(chk.dl>0.01)]
log('ELISA FC mismatches (>1%):',len(bad)); 
if len(bad): log(bad.to_string())

# 2. MN fold-change recomputation
m=pd.read_csv(F+'microneutralization.csv',dtype={'participant':str})
mt=m[m.measure=='titer'].pivot_table(index=['panel','arm','participant'],columns='timepoint',values='value')
mf=m[m.measure=='fold_change'].pivot_table(index=['panel','arm','participant'],columns='timepoint',values='value')
latem=mt['wk26'].fillna(mt['wk17'])
c2=pd.DataFrame({'fc4_rep':mf['wk4'],'fc4_calc':mt['wk4']/mt['wk0'],'fcl_rep':mf['wk17/26'],'fcl_calc':latem/mt['wk0']})
bad2=c2[(np.abs(np.log(c2.fc4_rep/c2.fc4_calc))>0.01)|(np.abs(np.log(c2.fcl_rep/c2.fcl_calc))>0.01)]
log('MN FC mismatches:',len(bad2))
if len(bad2): log(bad2.to_string())
log('MN titre range:',mt.min().min(),'-',mt.max().max())
for p in ['homologous','heterologous']:
    for arm in ['Fluarix','mRNA-1010']:
        x=mt.loc[(p,arm)]
        log(f'MN {p} {arm}: n at 1280 (ULOQ?) wk0={int((x.wk0>=1280).sum())}, wk4={int((x.wk4>=1280).sum())}; n at <=10 wk0={int((x.wk0<=10).sum())}, wk4={int((x.wk4<=10).sum())} (n={len(x)})')

# 3. Visit (wk17 vs wk26) consistency across files
h=pd.read_csv(F+'hai_titers.csv',dtype={'participant':str})
h['pid']='397-'+h.participant.str.zfill(3)
# within-file check: late-visit label by HAI antigen
hl=h[h.timepoint.isin(['wk17','wk26'])].pivot_table(index=['arm','pid'],columns='antigen',values='timepoint',aggfunc='first')
log('HAI within-file: participants whose late-visit label differs between antigens:')
log(hl[hl.nunique(axis=1)>1].to_string())
hv=h[h.antigen=='A/H1N1'].groupby('pid').timepoint.apply(lambda s: 'wk17' if 'wk17' in set(s) else ('wk26' if 'wk26' in set(s) else 'none'))
m['pid']=m.participant
mv=m[m.measure=='titer'].groupby('pid').timepoint.apply(lambda s: 'wk17' if 'wk17' in set(s) else ('wk26' if 'wk26' in set(s) else 'none'))
s=pd.read_csv(F+'neutralization_seqbased.csv')
s[['arm','pid','day']]=s.serum.str.extract(r'^(.*)_(397-\d+)_d(\d+)$')
sv=s.groupby('pid').day.apply(lambda x: 'wk17' if '121' in set(x) else ('wk26' if '181' in set(x) else 'none'))
e['pid']='397-'+e.participant.str.zfill(3)
ev=e[e.measure=='ec50'].groupby('pid').timepoint.apply(lambda s_: 'wk17' if 'wk17' in set(s_) else ('wk26' if 'wk26' in set(s_) else 'none'))
V=pd.DataFrame({'HAI(H1 rows)':hv,'MN':mv,'seqneut':sv,'ELISA':ev})
V=V[V['HAI(H1 rows)'].notna()|V.seqneut.notna()]
incons=V[V.nunique(axis=1,dropna=True)>1]
log('Cross-file late-visit label (HAI H1 rows / MN / seq-neut / ELISA) -- inconsistent participants:')
log(incons.to_string())

# 4. Arm assignment consistency across files
arms={}
for name,df,col in [('HAI',h,'pid'),('ELISA',e,'pid'),('MN',m,'pid'),('seqneut',s,'pid')]:
    arms[name]=df.groupby(col).arm.agg(lambda x: ';'.join(sorted(set(x))))
A=pd.DataFrame(arms)
log('Participants with conflicting arm labels across files:', int((A.nunique(axis=1)>1).sum()))
# IgM, GC, PB, binding
ig=pd.read_csv(F+'igm_fold_change.csv',dtype={'participant':str})
log('IgM participant IDs not zero-padded:',sorted(set(ig.participant[ig.participant.str.len()<3])))
log('IgM n per arm:',ig.groupby('arm').participant.nunique().to_dict(),' (summary table says ELISA/IgM cohort 38 mRNA / 37 Fluarix)')
gc=pd.read_csv(F+'gc_frequencies.csv',dtype={'participant':str})
dups=gc.groupby(['timepoint','arm','participant']).size()
log('GC file: participant-timepoints with >1 row:',int((dups>1).sum()),'of',len(dups),'(no column distinguishes the duplicate rows)')
log('GC timepoints:',sorted(gc.timepoint.unique()),' vs FNA schedule in summary: wk1,wk2,wk4,wk8,wk17,wk26')
pb=pd.read_csv(F+'plasmablast_frequencies.csv',dtype={'participant':str})
log('PB timepoints:',sorted(pb.timepoint.unique()),' blood schedule in summary: d0,d7,d29,d121,d181')
log('PB n per arm:',pb.groupby('arm').participant.nunique().to_dict(),'; GC n per arm:',gc.groupby('arm').participant.nunique().to_dict(),' (FNA cohort in summary: 6 mRNA / 11 Fluarix)')
pb_not_fna=sorted(set(pb.participant)-set(gc.participant))
log('PB participants not in the FNA (GC) cohort:',pb_not_fna)

# 5. seq-neut naming issues
vir=pd.Series(sorted(s.virus.unique()))
log('seq-neut viruses:',len(vir),'; H1N1:',int(vir.str.endswith('H1N1').sum()),'; H3N2:',int(vir.str.endswith('H3N2').sum()),'; influenza B:',int(vir.str.startswith('B/').sum()))
log('malformed year:',list(vir[vir.str.contains(r'/\d{5,}_')]))
log('A-virus with "YAMAGATA" in name (H3N2, not B/Yamagata lineage):',list(vir[vir.str.upper().str.contains('YAMAGATA')]))
reas=vir[vir.str.contains(r'egg|X-\d+A|NIB-\d+|IVR-\d+')]
log('egg/reassortant-designated viruses:',list(reas))
# sera per arm
log('seq-neut sera per arm/day:',s.groupby(['arm','day']).serum.nunique().to_dict())
# missing titres
exp=s.serum.nunique()*s.virus.nunique()
log('seq-neut expected serum x virus =',exp,'; observed rows =',len(s),'; missing =',exp-len(s))
miss=(s.groupby('virus').serum.nunique().rsub(s.serum.nunique()))
log('viruses with missing sera (n missing):',miss[miss>0].to_dict())

# ---- censoring counts in seq-neut and ELISA participant-ID blocks
log('seq-neut titre_bound counts:',s.titer_bound.value_counts().to_dict(),
    '; upper-bound titres are <= reported value (min reported',s[s.titer_bound=='upper'].titer.min(),'), lower-bound titres are >= reported value (values',sorted(s[s.titer_bound=='lower'].titer.unique()),')')
ids=e.groupby('arm').participant.apply(lambda z: sorted(set(int(i) for i in z)))
for arm,v in ids.items(): log(f'ELISA participant numbers, {arm}: n={len(v)}:',v)
log('Bead-array files carry no timepoint column (log2 fold-change assumed week 4 vs week 0; not stated).')

open('/tmp/outputs/analysis/integrity_checks.txt','w').write('\n'.join(out))
