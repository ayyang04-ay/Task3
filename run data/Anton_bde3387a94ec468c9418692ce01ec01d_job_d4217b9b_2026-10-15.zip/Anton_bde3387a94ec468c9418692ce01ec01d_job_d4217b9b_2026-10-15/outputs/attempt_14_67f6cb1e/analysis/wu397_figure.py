"""Forest plot: mRNA-1010 vs Fluarix, binding vs functional readouts (WU397)."""
import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
T='/tmp/outputs/analysis/tables/'
C=pd.read_csv(T+'serology_arm_comparisons.csv').set_index('assay')
S=pd.read_csv(T+'seqneut_category_ancova.csv'); S=S[S.censoring=='bound']
B=pd.read_csv(T+'binding_breadth_by_strain.csv')
rows=[]
def add(label,r,lo,hi,grp): rows.append((label,r,lo,hi,grp))
add('ELISA IgG H1 (wk4)',*C.loc['ELISA IgG A/H1 wk4',['post_GMT_ratio_adj','adj_lo','adj_hi']],'Binding')
add('ELISA IgG H3 (wk4)',*C.loc['ELISA IgG A/H3 wk4',['post_GMT_ratio_adj','adj_lo','adj_hi']],'Binding')
for s in ['A/Wisconsin/67/2022','A/Darwin/6/2021','A/Thailand/8/2022','A/Hong Kong/1/1968']:
    r=B[B.strain==s].iloc[0]; add(f'Bead-array {s} (fold-rise ratio)',r['fold_diff(2^diff)'],r.lo95,r.hi95,'Binding')
for a in ['A/H1N1','A/H3N2','B/Vic','B/Yam']:
    add(f'HAI {a} (wk4)',*C.loc[f'HAI {a} wk4',['post_GMT_ratio_adj','adj_lo','adj_hi']],'HAI / MN')
add('MN "homologous" (wk4)',*C.loc['MN homologous wk4',['post_GMT_ratio_adj','adj_lo','adj_hi']],'HAI / MN')
add('MN "heterologous" (wk4)',*C.loc['MN heterologous wk4',['post_GMT_ratio_adj','adj_lo','adj_hi']],'HAI / MN')
lab={'H1_vaccine_mRNA-matched':'seq-neut H1 mRNA-antigen-matched','H1_vaccine_Fluarix-matched':'seq-neut H1 Fluarix-antigen-matched',
     'H1_contemporary_WT(2022-24)':'seq-neut H1 2023 wild-type (6)','H1_historic_WT(<=2020)':'seq-neut H1 historic (4)',
     'H3_vaccine_mRNA-matched':'seq-neut H3 A/Darwin/6/2021 (mRNA Ag)','H3_vaccine_Fluarix-matched':'seq-neut H3 A/Darwin/9/2021 (Fluarix egg Ag)',
     'H3_contemporary_WT(2022-24)':'seq-neut H3 2022-24 wild-type (68)','H3_historic_WT(<=2020)':'seq-neut H3 historic (8)','H3_egg/reassortant':'seq-neut H3 egg/reassortant (5)'}
for c in lab:
    for post,tag in [('d29','D29'),('late','D121/181')]:
        r=S[(S.category==c)&(S.post==post)].iloc[0]
        add(f'{lab[c]} {tag}',r['adj_GMT_ratio_mRNA/Flu'],r.lo95,r.hi95,'Neutralisation (seq-neut)')
R=pd.DataFrame(rows,columns=['label','ratio','lo','hi','group'])
R.round(3).to_csv(T+'forest_plot_data.csv',index=False)
fig,ax=plt.subplots(figsize=(11.5,12)); y=np.arange(len(R))[::-1]
col={'Binding':'tab:orange','HAI / MN':'tab:blue','Neutralisation (seq-neut)':'tab:green'}
for yi,(_,r) in zip(y,R.iterrows()):
    ax.plot([r.lo,r.hi],[yi,yi],color=col[r.group]); ax.plot(r.ratio,yi,'o',color=col[r.group])
ax.axvline(1,color='k',lw=0.8); ax.axvline(1.5,color='grey',ls=':',lw=0.8)
ax.set_xscale('log',base=2); ax.set_yticks(y); ax.set_yticklabels(R.label,fontsize=7.5)
ax.set_xlabel('mRNA-1010 / Fluarix ratio (95% CI)\nANCOVA baseline-adjusted GMT ratio; bead-array = ratio of fold-rises (no baseline MFI supplied)',fontsize=8)
for g,c in col.items(): ax.plot([],[],'o',color=c,label=g)
ax.legend(loc='lower right',fontsize=8); ax.set_title('WU397: binding advantage is not matched by functional/neutralising advantage for H3',fontsize=9)
plt.subplots_adjust(left=0.30,right=0.98,top=0.96,bottom=0.07); plt.savefig('/tmp/outputs/analysis/forest_binding_vs_function.png',dpi=150)
print(R.round(2).to_string(index=False))
