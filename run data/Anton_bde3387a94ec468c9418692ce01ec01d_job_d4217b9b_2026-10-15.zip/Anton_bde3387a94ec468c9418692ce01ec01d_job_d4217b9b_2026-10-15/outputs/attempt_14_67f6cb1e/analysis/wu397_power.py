"""Sample-size / event calculations for the recommended next studies, using variance observed in WU397.
All calculations are normal-approximation planning figures, not final protocol numbers."""
import pandas as pd, numpy as np
import statsmodels.formula.api as smf
from scipy import stats
F='/tmp/world/filesystem/'; T='/tmp/outputs/analysis/tables/'
z=stats.norm.ppf
out=[]
def log(s): print(s); out.append(s)

# --- residual SD (log2) of baseline-adjusted day-29 titres, per-participant category means (seq-neut)
d=pd.read_csv(F+'neutralization_seqbased.csv')
d[['arm','participant','day']]=d.serum.str.extract(r'^(.*)_(397-\d+)_d(\d+)$')
cls=pd.read_csv(T+'seqneut_virus_classification.csv').set_index('virus').category
d['category']=d.virus.map(cls); d['lt']=np.log2(d.titer)
x=d[d.day.isin(['0','29'])].groupby(['category','arm','participant','day'])['lt'].mean().unstack('day').reset_index()
x.columns=['category','arm','participant','d0','d29']
sds={}
for c in ['H1_contemporary_WT(2022-24)','H3_contemporary_WT(2022-24)']:
    y=x[x.category==c].copy(); y['mrna']=(y.arm=='mRNA-1010').astype(int)
    f=smf.ols('d29 ~ mrna + d0',data=y).fit(); sds[c]=np.sqrt(f.mse_resid)
    log(f'{c}: residual SD (log2) = {sds[c]:.2f}')
# single-strain residual SD (median across contemporary strains) - relevant if a single-strain endpoint is used
w=d[d.day.isin(['0','29'])].pivot_table(index=['virus','arm','participant'],columns='day',values='lt').reset_index()
rs=[]
for v,y in w.groupby('virus'):
    y=y.dropna(); y=y.assign(mrna=(y.arm=='mRNA-1010').astype(int))
    f=smf.ols('Q("29") ~ mrna + Q("0")',data=y).fit(); rs.append((v,np.sqrt(f.mse_resid)))
rs=pd.DataFrame(rs,columns=['virus','sd']); rs['category']=rs.virus.map(cls)
for c in ['H1_contemporary_WT(2022-24)','H3_contemporary_WT(2022-24)']:
    log(f'{c}: single-strain residual SD median {rs[rs.category==c].sd.median():.2f} (range {rs[rs.category==c].sd.min():.2f}-{rs[rs.category==c].sd.max():.2f})')

def n_sup(ratio,sd,alpha=0.05,power=0.9):
    return int(np.ceil(2*(z(1-alpha/2)+z(power))**2*sd**2/np.log2(ratio)**2))
log('\nSuperiority on baseline-adjusted neutralising GMT ratio (2-sided alpha 0.05, 90% power), n evaluable per arm:')
for sd in [1.0,1.2,1.5]:
    log('  SD %.1f: '%sd+', '.join(f'ratio {r}: n={n_sup(r,sd)}' for r in [1.17,1.3,1.5,2.0]))
log('  with alpha split 0.025 per subtype (H1, H3): '+', '.join(f'ratio {r}: n={n_sup(r,1.2,alpha=0.025)}' for r in [1.3,1.5,2.0])+' (SD 1.2)')

# --- HAI non-inferiority (FDA 2007 criteria): UB 95% CI of GMT ratio comparator/new <=1.5 ; UB of SCR difference <=10 pts
def n_ni_gmt(sd,true_ratio=1.0,margin=1.5,alpha=0.025,power=0.9):
    return int(np.ceil(2*(z(1-alpha)+z(power))**2*sd**2/(np.log2(margin)-np.log2(true_ratio))**2))
def n_ni_scr(p,delta=0.10,alpha=0.025,power=0.9,true_diff=0.0):
    return int(np.ceil((z(1-alpha)+z(power))**2*(2*p*(1-p))/(delta-true_diff)**2))
log('\nHAI non-inferiority, per strain, n evaluable per arm (one-sided alpha 0.025, 90% power, true difference 0):')
for sd in [1.0,1.4]: log(f'  GMT ratio margin 1.5, SD {sd}: n={n_ni_gmt(sd)}')
for p in [0.15,0.3,0.5]: log(f'  SCR margin 10 points, SCR {int(p*100)}%: n={n_ni_scr(p)}')
log('  -> for 3 strains x 2 criteria jointly, power each comparison at ~98 pct: SCR 50 pct: n='+str(n_ni_scr(0.5,power=0.98)))

# --- Efficacy (relative VE) event-driven, 1:1 randomisation
def cases(rve,alpha=0.05,power=0.9,null=0.0):
    th1=(1-rve)/(2-rve); th0=(1-null)/(2-null)
    num=(z(1-alpha/2)*np.sqrt(th0*(1-th0))+z(power)*np.sqrt(th1*(1-th1)))**2
    return int(np.ceil(num/(th0-th1)**2))
log('\nRelative VE (mRNA vs licensed comparator), total RT-PCR-confirmed cases needed (2-sided alpha 0.05, 90% power):')
for r in [0.15,0.2,0.25,0.3]: log(f'  true rVE {int(r*100)}%: superiority (rVE>0) cases={cases(r)} ; NI (LB > -10%) cases={cases(r,null=-0.10)}')
log('  If the mismatched-strain endpoint must itself be powered and mismatched strains are a fraction f of cases, total cases ~= cases/f')
for f in [0.3,0.5,0.7]: log(f'   f={f}: true rVE 25% -> ~{int(np.ceil(cases(0.25)/f))} total cases')
open('/tmp/outputs/analysis/power_calculations.txt','w').write('\n'.join(out))

# --- Controlled human infection (heterologous challenge), two-proportion comparison, per arm
def n_two_prop(p1,p2,alpha=0.05,power=0.9):
    pbar=(p1+p2)/2
    num=(z(1-alpha/2)*np.sqrt(2*pbar*(1-pbar))+z(power)*np.sqrt(p1*(1-p1)+p2*(1-p2)))**2
    return int(np.ceil(num/(p1-p2)**2))
log('\nCHIM: symptomatic laboratory-confirmed infection, comparator vs mRNA (per arm, 2-sided alpha 0.05):')
for p1,p2 in [(0.45,0.225),(0.40,0.20),(0.50,0.30)]:
    log(f'  {int(p1*100)}% vs {p2*100:.1f}%: n={n_two_prop(p1,p2)} (90% power), n={n_two_prop(p1,p2,power=0.8)} (80% power)')

# --- participants needed for the efficacy trial under ASSUMED attack rates (not from WU397)
log('\nEfficacy trial: participants needed = cases / (attack rate x seasons); attack rates are planning assumptions, not data:')
for cases_needed in [511,1022]:
    for ar in [0.01,0.02,0.03]:
        log(f'  {cases_needed} cases at {int(ar*100)}% PCR-confirmed ILI per season: ~{int(np.ceil(cases_needed/ar/1000))*1000:,} participant-seasons')
open('/tmp/outputs/analysis/power_calculations.txt','w').write('\n'.join(out))

# --- minimum detectable adjusted GMT ratio for Study 1 planning sizes
def mdr(n,sd=1.2,alpha=0.025,power=0.9):
    return 2**np.sqrt(2*(z(1-alpha/2)+z(power))**2*sd**2/n)
log('\nStudy 1 minimum detectable adjusted GMT ratio (SD 1.2 log2, 2-sided alpha 0.025 per subtype, 90% power):')
for n in [100,150,250,300]: log(f'  n={n} evaluable/arm: {mdr(n):.2f}-fold')
open('/tmp/outputs/analysis/power_calculations.txt','w').write('\n'.join(out))
