**Recommendation (one line):** Don't claim heterologous protection on WU397's evidence — next run a randomised, observer-blind, strain-matched trial (mRNA vs same-season Fluarix and a recombinant-HA vaccine; adults 18–64 and ≥65) whose primary endpoint is baseline-adjusted *neutralising* titre against a pre-locked panel of current wild-type heterologous H3N2/H1N1/B strains, and only if it succeeds, an event-driven relative-efficacy trial whose claim endpoint is PCR-confirmed influenza caused by antigenically mismatched strains.

---

## 1. Bottom line for the committee

- **The claim is about clinical outcomes, and WU397 has no clinical outcomes.** "Heterologous protection" means fewer lab-confirmed illnesses from strains that differ antigenically from the vaccine strains, compared with a licensed vaccine. Supporting it takes three things:
  - (a) homologous immunogenicity that is not inferior to the comparator;
  - (b) more *functional* antibody against current heterologous strains, lasting through the season, and attributable to the product;
  - (c) clinical relative efficacy against mismatched strains, or a validated correlate of protection. No such correlate exists for heterologous strains or for antibody raised by mRNA vaccines.

  WU397 was non-randomised and open-label. It had about 14 people per arm for the functional assays, gave the two arms **different H1 antigens**, and had no clinical endpoints. It cannot deliver (a), (b) or (c) to the standard needed.
- **For H3, the "breadth" is in binding assays, not neutralisation.** On the *same* H3 strains, mRNA-1010's rise in bead-array binding was 6–10× Fluarix's, but baseline-adjusted neutralisation did not follow:
  - A/Darwin/6/2021 (the mRNA vaccine's own H3): binding 6.10×, neutralisation 0.62×.
  - A/Thailand/8/2022: binding 9.45×, neutralisation 0.82×.
  - Across 68 current wild-type H3N2 viruses, the adjusted neutralisation ratio was **1.17 (95% CI 0.64–2.12) at day 29** and **1.05 (0.65–1.68) at day 121/181**.
- **The one real neutralisation advantage is for H1, and it is short-lived and confounded.**
  - It was about 2× at day 29 against 2023 H1N1 isolates (2.06; 1.23–3.46) but 1.17 (0.78–1.76) by day 121/181.
  - mRNA-arm H1 titres fell to 0.43× of their day-29 level, against 0.76× for Fluarix.
  - The mRNA vaccine's H1 (A/Victoria/4897/2022) is not the H1 in 2022–23 Fluarix (A/Victoria/2570/2019-like). So this comparison can't separate the effect of the platform from the effect of choosing a different antigen, or of egg adaptation.
- **The only H3 neutralisation "breadth" comes from egg-adapted or production-reassortant viruses (1.54; 1.05–2.27) and historic strains (1.63; 0.99–2.68).**
  - The mRNA arm also started lower (baseline ratio 0.66 for current H3 strains; 0.47 on the MN "heterologous" virus).
  - Unadjusted fold-rises therefore flatter it: for historic H3, 2.08× unadjusted becomes 1.63× adjusted.
- **HAI and MN show no difference between arms.**
  - Adjusted HAI ratios were 1.54 (0.87–2.71) for H1 and 1.01–1.06 for H3 and both B lineages.
  - mRNA-1010's HAI seroconversion to the B strains was 0/13 (B/Victoria) and 0/14 (B/Yamagata).
  - The MN readouts track H3N2 and show 0.68 (homologous) and 1.17 (heterologous) after adjustment.
- **Plan (full detail in §3):**
  - **Study 0:** repair and complete the WU397 package before the committee.
  - **Study 1:** the strain-matched neutralisation-breadth trial (Phase 2b).
  - **Go/no-go gate** on Study 1.
  - **Study 2:** the relative-efficacy trial with a mismatched-strain endpoint and a nested correlates analysis (Phase 3). This is the study that carries the claim.
  - **Study 3 (optional):** a heterologous human-challenge study for an earlier proof-of-concept.

---

## 2. What the WU397 data show (re-analysis)

**Methods in brief.**
- All titres were log2-transformed.
- Arms were compared by ANCOVA: log post-dose titre ~ arm + log baseline titre. Results are adjusted GMT ratios (mRNA-1010 / Fluarix) with 95% CIs.
- Sequencing-based neutralisation ("seq-neut") was analysed on each participant's mean log2 titre within each virus class.
- Censored titres ("upper" = ≤~40; "lower" = ≥17,300 or ≥6,291) were set at the bound. A sensitivity analysis at bound/2 and bound×2 did not change any conclusion.
- HAI values stored as rounded geometric means (e.g., 57 = 40√2, 226 = 160√2) were snapped back to exact half-step dilutions, so that true 4-fold rises are not lost to rounding.
- All scripts are in `/tmp/outputs/analysis/`. Section 5 maps every number to its source.

### 2.1 Design features that undermine every arm comparison

| Issue | Evidence | Consequence |
|---|---|---|
| **Arms received different H1 antigens** | mRNA-1010 encoded A/Victoria/4897/2022 (H1N1)pdm09-like (trial_summary.md). 2022–23 NH Fluarix follows the WHO 2022–23 egg-based recommendation, which is A/Victoria/2570/2019 (H1N1)pdm09-like [EXT-1]. A/Victoria/4897/2022 is the H1 WHO recommended a season *later*, for 2023–24 [EXT-2]. The package defines "homologous/heterologous" relative to the mRNA-1010 antigens only (trial_summary.md). | For Fluarix recipients, "homologous H1" is a heterologous strain. Any breadth difference mixes up platform, antigen choice and egg adaptation. |
| **H3: cell-type vs egg-type version** | mRNA-1010: A/Darwin/6/2021-like (cell-type recommendation). Fluarix: A/Darwin/9/2021-like (egg-based) [EXT-1]. | The platform effect is mixed up with egg adaptation. A non-egg comparator is needed to separate them. |
| **Allocation by site, not randomised; open-label** | Baseline neutralisation was lower in the mRNA arm: contemporary H3 baseline GMT ratio **0.66 (0.40–1.11)**; historic H3 **0.58 (0.24–1.40)**; MN "heterologous" **0.47 (0.22–1.00)**. Fold-rise falls as baseline rises (slope −0.44 log2 per log2 for historic H3; −0.26 for contemporary H3). The 29 core participants have interleaved IDs (001–032), but the ELISA-only participants form separate blocks (Fluarix 033–059; mRNA 064–102), consistent with enrolment by site or period. | Unadjusted fold-rises favour the mRNA arm for reasons unrelated to the vaccine. Unmeasured site effects (age, prior vaccination, timing relative to the epidemic) cannot be removed by analysis. |
| **Small functional cohorts** | HAI, MN and bead array: 14 vs 15. Seq-neut: 13 vs 14. FNA: 6 vs 11. mAbs: 4 vs 3 donors (trial_summary.md and files). | Wide CIs. None of the 96 per-virus seq-neut comparisons survives FDR correction (smallest q = 0.11). |
| **Missing from the package** | No age, sex, prior-vaccination or infection history, site, or enrolment/dosing dates. No reactogenicity or safety data. No dose. HAI, MN and ELISA virus/antigen identities are not stated. | Confounding can't be assessed. The committee package is incomplete. |
| **Late visits pooled** | Week 17 and week 26 are reported together as "wk17/26". | Durability is blurred. Fixed visits are needed in future. |

### 2.2 Same strain, two readouts: binding versus neutralisation

Binding = ratio of bead-array fold-rises (no baseline MFI was supplied). Neutralisation = seq-neut baseline-adjusted GMT ratio at day 29. Both are mRNA-1010 / Fluarix.

| Strain | Binding ratio (95% CI) | Neutralisation ratio (95% CI) | Day-29 neut GMT, mRNA vs Fluarix |
|---|---|---|---|
| H1 A/Wisconsin/67/2022 (≈ mRNA H1) | 2.65 (1.54–4.55) | 2.07 (1.26–3.38) | 431 vs 197 |
| H1 A/Wisconsin/588/2019 (≈ Fluarix H1) | 2.04 (1.01–4.10) | 2.44 (1.18–5.05) | 1073 vs 506 |
| H1 A/Michigan/45/2015 | 1.83 (0.92–3.64) | 1.76 (0.94–3.31) | 3568 vs 2158 |
| H1 A/Brisbane/2/2018 | 1.30 (0.70–2.44) | 1.73 (0.88–3.41) | 2012 vs 1363 |
| H1 A/Hawaii/70/2019 | 1.26 (0.68–2.34) | 1.66 (0.94–2.96) | 1349 vs 951 |
| **H3 A/Darwin/6/2021 (mRNA H3)** | **6.10 (2.20–16.91)** | **0.62 (0.34–1.12)** | **244 vs 482** |
| **H3 A/Thailand/8/2022** | **9.45 (3.18–28.02)** | **0.82 (0.35–1.91)** | **480 vs 695** |
| H3 A/Cambodia/e0826360/2020 | 5.86 (2.75–12.48) | 1.34 (0.67–2.66) | 611 vs 595 |
| H3 A/Singapore/INFIMH-16-0019/2016 | 10.07 (4.02–25.25) | 1.96 (0.88–4.35) | 1097 vs 1135 |
| H3 A/Hong Kong/2671/2019 | 3.87 (2.10–7.15) | 2.06 (1.29–3.30) | 5679 vs 3045 |
| H3 A/Texas/50/2012 | 3.80 (2.10–6.90) | 1.83 (1.23–2.74) | 6355 vs 4568 |

**How to read this:**
- **For H1, binding and neutralisation agree.**
- **For H3, they don't.** Per participant, the mean log2 neutralisation rise minus the mean log2 binding rise for H3 was **−1.94 in the mRNA arm vs +0.38 for Fluarix**.
- In the mRNA arm, binding rise barely tracks neutralisation rise: Spearman ρ 0.29 (p=0.33) for H3 and 0.30 for H1. For Fluarix the figures are ρ 0.66 (p=0.01) and 0.71.
- The extra H3 binding antibody from mRNA-1010 therefore appears to be largely non-neutralising. Binding extended to HK/1968 (9.51×) and, among mAbs, to H7 (2.8–25.3% of mRNA-donor group-II mAbs vs 0% for Fluarix donors).
- Whether that antibody protects through Fc-mediated functions is **unknown**. It has to be measured (Study 1) and then shown clinically (Study 2); it cannot be assumed.

See `analysis/forest_binding_vs_function.png`.

### 2.3 Neutralisation by virus class (seq-neut, 96 viruses, 27 participants)

The panel is 13 H1N1, 83 H3N2 and no influenza B viruses; 7,719 of 7,776 possible titres are present. Each virus was reclassified against **both** arms' vaccine antigens:
- Vaccine-equivalent for mRNA: A/Victoria/4897/2022 IVR-238 (the egg reassortant of the mRNA H1 itself) and A/Wisconsin/67/2022 (its cell-type counterpart); A/Darwin/6/2021 for H3.
- Vaccine-equivalent for Fluarix: A/Wisconsin/588/2019 and A/Darwin/9/2021.
- Egg/production reassortants: names carrying "egg", X-307A, X-223A, NIB-88 or IVR-238.
- Historic wild type: isolated in 2020 or earlier.
- Contemporary wild type: isolated 2022–24.

Two naming problems in the file: "A/YAMAGATA/98/2023" is an H3N2 virus, not B/Yamagata lineage; "…/202023" is a malformed year, treated as 2023.

Columns: GMT = baseline GMT, Fluarix vs mRNA. Adj ratio = adjusted GMT ratio, mRNA/Fluarix. ≥4× = mean % of participants with a ≥4-fold rise, Fluarix vs mRNA.

| Virus class (n viruses) | Baseline GMT | Adj ratio, D29 | Adj ratio, D121/181 | ≥4× at D29 |
|---|---|---|---|---|
| H1 contemporary wild type, 2023 (6) | 132 vs 117 | **2.06 (1.23–3.46)** | 1.17 (0.78–1.76) | 11.9% vs 52.6% |
| H1 historic (4) | 855 vs 706 | 1.69 (0.91–3.13) | 1.11 (0.60–2.03) | 17.9% vs 38.5% |
| H1 ≈ Fluarix antigen: Wis/588/2019 (1) | 216 vs 175 | 2.44 (1.18–5.05) | 1.17 (0.62–2.23) | 14.3% vs 69.2% |
| H1 ≈ mRNA antigen: IVR-238 and Wis/67/2022 (2) | 264 vs 267 | 1.84 (1.17–2.90) | 1.15 (0.76–1.72) | 14.3% vs 50.0% |
| **H3 contemporary wild type, 2022–24 (68)** | 215 vs 143 | **1.17 (0.64–2.12)** | **1.05 (0.65–1.68)** | 23.7% vs 26.2% |
| H3, the 5 least-recognised viruses (baseline GMT <100 in both arms: the three 2024 isolates, A/District of Columbia/27/2023, A/British Columbia/RV00920/2023) | 78 vs 53 | 1.04 (0.49–2.18) | 0.76 (0.39–1.49) | — |
| H3 historic wild type (8) | 708 vs 408 | 1.63 (0.99–2.68) | 1.44 (0.87–2.40) | 20.5% vs 41.3% |
| H3 egg/production reassortant (5) | 2172 vs 1911 | 1.54 (1.05–2.27) | 1.37 (0.85–2.21) | 5.7% vs 20.0% |
| H3 Darwin/6/2021, the mRNA antigen (1) | 176 vs 109 | 0.62 (0.34–1.12) | 0.72 (0.40–1.30) | 28.6% vs 15.4% |
| H3 Darwin/9/2021, the Fluarix antigen (1) | 343 vs 211 | 0.81 (0.35–1.87) | 0.57 (0.25–1.27) | 35.7% vs 53.8% |

More detail:
- **Unadjusted vs adjusted.** Unadjusted fold-rise ratios were 1.30 for contemporary H3 and 2.08 for historic H3. After baseline adjustment they are 1.17 and 1.63.
- **Censoring.** In the advanced-H3 subset, 46.2% of mRNA-arm baseline titres sat at the assay floor, against 21.4% for Fluarix. Breadth endpoints therefore need an assay range and analysis that handle the floor and ceiling.
- **Waning, day 29 to day 121/181:**
  - H1 contemporary: mRNA 0.43×, Fluarix 0.76×.
  - H3 contemporary: 0.64× and 0.67×.
- **Day 181 only:**
  - H1 contemporary: 1.14 (0.68–1.94).
  - H3 contemporary: 0.98 (0.58–1.66).

### 2.4 HAI and MN (week 4, unless stated)

| Readout | n (mRNA/Flu) | GMT, mRNA vs Flu | Seroconversion, mRNA vs Flu | Adjusted ratio (95% CI) |
|---|---|---|---|---|
| HAI A/H1N1 | 14/15 | 137.9 vs 87.8 | 50.0% vs 33.3% | 1.54 (0.87–2.71) |
| HAI A/H1N1, wk17/26 | 14/15 | 72.5 vs 81.9 | **0% vs 33.3%** | 0.83 (0.47–1.45) |
| HAI A/H3N2 | 14/15 | 56.6 vs 57.9 | 14.3% vs 20.0% | 1.06 (0.68–1.66) |
| HAI B/Victoria | 13/15 | 56.6 vs 51.6 | **0% vs 6.7%** | 1.05 (0.71–1.56) |
| HAI B/Yamagata | 14/15 | 88.3 vs 98.5 | **0% vs 6.7%** | 1.01 (0.73–1.40) |
| MN "homologous" | 14/15 | 325 vs 588 (GMFR 2.49 vs 3.32) | — | 0.68 (0.31–1.51) |
| MN "heterologous" | 14/15 | 235 vs 368 (GMFR 4.12 vs 3.03) | — | 1.17 (0.52–2.62) |
| MN "heterologous", wk17/26 | 14/15 | 126 vs 320 | — | 0.73 (0.37–1.45) |
| ELISA IgG H1 / H3 (binding) | 38/37 | 8329 vs 3131 / 7936 vs 2610 | — | 2.66 (2.01–3.53) / 3.31 (2.47–4.43) |

Notes on this table:
- **HAI seroprotection.** H3 post-dose seroprotection (HAI ≥40) was 64.3% in the mRNA arm vs 86.7% for Fluarix.
- **The MN panels behave as H3N2 readouts.** MN titres track the H3N2 seq-neut titres: median ρ 0.42, rising to 0.73 against A/Darwin/9/2021 for the "homologous" MN virus. Against H1N1 the median ρ is 0.12. MN conclusions are therefore H3 conclusions.
- **MN has a ceiling.** It topped out at 1:1280. At week 4, 9 of 15 Fluarix "homologous" titres were at the cap, which understates Fluarix.

### 2.5 Mechanistic data: supportive of a stronger germinal-centre response, not of breadth or protection

- **Germinal-centre B cells.** Median HA-specific GC B cells at week 2 were 24.2% (mRNA) vs 2.3% (Fluarix), p=0.036, n=6 vs 11. But the file holds two unlabelled blocks per participant-visit, and a "wk0" FNA that isn't in the FNA schedule (see 2.6).
- **mAbs: 695 in total, and the split is too lopsided for any inference.**
  - mRNA: 589 from 4 donors. Fluarix: 106 from 3 donors, 79% of them from donor 397-005.
  - The other two Fluarix donors contributed only 1 and 5 group-II HA-binding mAbs.
  - At the donor level, mRNA-donor H1 mAbs bound A/California/04/2009 *less* often (21.5–64.0%) than Fluarix-donor mAbs (50.0–88.9%).
  - For H3 (group II), mRNA-donor mAbs bound HK/1968 more often (32.7–69.0% vs 0–17.4%). These are binding data only.
- **Serum clonotypes.** Vaccine-elicited clonotypes: median 32 vs 17.5 (p=0.066, 8 vs 8).

### 2.6 Data-integrity problems to fix before any of this is reused

1. **HAI B/Victoria rows:** 8 participants (007, 009, 016, 018; 008, 010, 021, 023) have a late-visit label (wk17 vs wk26) that conflicts with their other three HAI antigens. Either visit labels or participant IDs are transposed. B/Victoria paired analyses are unverified until this is resolved.
2. **Seq-neut late visits:** participants 397-007 and 397-011 are labelled day 121 here, but week 26 in the HAI, MN and ELISA files.
3. **GC frequencies:** every participant-visit (78 of 78) appears twice, with no column saying what the second block is (a second probe?). The file also has a "wk0" timepoint, but FNAs were only scheduled at weeks 1, 2, 4, 8, 17 and 26; weeks 1 and 4 are absent.
4. **Plasmablast file:** its week-2 and week-8 timepoints are not blood-sampling visits (blood was drawn on days 0, 7, 29, 121 and 181), and it includes 11 participants who are not in the FNA cohort. The sampling compartment is therefore unclear.
5. **IgM:** only 14/15 participants, although the cohort table says "ELISA, IgM 38/37". One ID is unpadded ("20").
6. **Seq-neut panel:** the malformed year "202023"; "A/YAMAGATA/98/2023" is H3N2; 57 titres are missing (8 for A/SouthAfrica/R06506/2023, 6 for A/YAMAGATA/98/2023); no influenza B viruses.
7. **Unspecified identities:** HAI, MN and ELISA virus/antigen identities, and whether cell- or egg-derived, are not stated. The bead-array files have no timepoint column (week 4 vs week 0 assumed).

Checks that passed: reported ELISA and MN fold-changes match a recomputation exactly, and arm labels agree across all files.

---

## 3. Recommended next studies

### Study 0: before the committee. Repair the WU397 package (no new participants)

1. **Comparator composition.** Document the composition of the Fluarix lot(s) used, from the lot label, and state the H1 mismatch (and the egg/cell H3 difference) in the study report.
2. **Participant covariates.** Retrieve age, sex, prior-season vaccination (3 seasons), known influenza infection, site and dosing date for each participant. Re-run the arm comparisons adjusted for them. If dosing dates differ between arms relative to the 2022–23 epidemic, say so.
3. **Data problems.** Resolve items 1–7 in §2.6 against source records. Re-issue the data files with virus identities (wild type vs egg vs reassortant), assay limits and a probe column for GC.
4. **Safety.** Add reactogenicity and safety data to the committee package.
5. **Reporting.** Re-label the breadth analyses using the classification above (vaccine-equivalent for *either* arm, egg/reassortant, historic, contemporary), reported per subtype. Stop reporting unadjusted fold-rises and pooled wk17/26 as headline results.
6. **Optional and inexpensive.** Test banked WU397 day-0 and day-29 sera for NA-inhibiting antibody and for Fc-effector activity against current H3 HAs. This tells you whether the excess H3 binding antibody has any function, and whether those readouts belong in Study 1. It does **not** remove the confounding.

### Study 1: randomised, observer-blind, strain-matched neutralisation-breadth trial (Phase 2b)

**Question.** When every arm gets the same strains, does the mRNA vaccine produce more *neutralising* antibody against current heterologous strains than licensed vaccines, lasting through the season, without losing homologous immunogenicity?

**Conditions**
- Randomised 1:1:1 within each site.
- Observer-blind: unblinded vaccinators, blinded participants and assessors, and a laboratory blinded to arm and visit.
- Single season. Every dose is given within one pre-season window, before local influenza activity starts.
- **Arm A:** mRNA candidate, **trivalent** (A/H1N1, A/H3N2, B/Victoria). It encodes exactly the WHO-recommended strains for that season, using the cell/recombinant-type recommendation, at the intended Phase 3 dose.
  - No sponsor-selected antigens.
  - No B/Yamagata: that lineage has not been detected since 2020 and WHO recommended dropping it [EXT-3].
- **Arm B:** licensed, same-season, egg-based standard-dose inactivated vaccine (Fluarix). This gives continuity with WU397 and is the usual comparator for adults under 65.
- **Arm C:** licensed, same-season recombinant-HA vaccine (RIV). It carries the same non-egg strain sequences as Arm A. This is what separates a "platform" effect from a "non-egg antigen" effect. It is also one of the vaccines preferentially recommended for people ≥65 [EXT-5].
- **Arm D (≥65 stratum, optional):** high-dose or adjuvanted inactivated vaccine, only if that will be the Phase 3 comparator.
- If the Phase 3 dose is not yet fixed, add a second mRNA dose arm rather than running a separate dose study. The breadth endpoint then needs multiplicity control across doses.

**In whom**
- Community-dwelling adults in two equal strata: **18–64** (no more than about half aged 18–49) and **≥65**.
- Randomisation stratified by age stratum × prior-season influenza vaccination (yes/no) × site.
- Record: birth year (early-life imprinting cohort), 3-season vaccination history, prior confirmed influenza, comorbidities.
- Exclude: current-season influenza vaccination, PCR-confirmed influenza in the previous 6 months, immunosuppression, any prior mRNA influenza vaccine.

**Against what: the virus and antigen panels**
- **Homologous references.** For each arm, both the cell-type and egg-type versions of each vaccine strain. The cell-type version is the primary reference for HAI.
- **Tier 1 (primary breadth panel).**
  - Wild-type clinical isolates only: no egg passage and no production reassortants.
  - Circulating in the 12 months before vaccination.
  - Covering every antigenic or genetic group with ≥5% prevalence, with ≥6 viruses each for H3N2, H1N1 and B/Victoria.
  - Each must be antigenically distinct from *every* arm's vaccine strain. Define this quantitatively, e.g., a ≥8-fold drop in ferret-antiserum HI titre relative to homologous, per WHO collaborating-centre data [EXT-6].
  - Chosen by an independent virology committee and **locked before any Study 1 serum is tested**.
  - Reported per subtype with equal weight. WU397's panel was 83 H3N2 / 13 H1N1 / 0 B.
- **Tier 2 (forward panel).** Wild-type isolates from the season of conduct and the next season, tested on banked day-29 and day-181 sera. This is the closest laboratory stand-in for future drift.
- **Descriptive only, never pooled into breadth endpoints:** historic strains, and egg-adapted or reassortant viruses.
- **Exclude from "heterologous":** any strain WHO treats as equivalent to an arm's vaccine strain (e.g., egg/cell counterparts such as Darwin/9 vs Darwin/6).

**What is measured, in whom, when**

| Readout | Participants | Visits | Role |
|---|---|---|---|
| Neutralising titre, Tier 1 panel | All | D0, D29, D181 (D91 in a random third) | **Primary / key secondary** |
| Neutralising titre, Tier 2 panel | All | D29, D181 | Key secondary |
| HAI against each vaccine strain (cell-type; egg-type as secondary) | All | D0, D29, D181 | Homologous comparison |
| NA-inhibiting antibody (N1, N2) | Random third | D0, D29, D181 | Secondary. The split-virion comparator contains NA; RIV does not; the package names the mRNA antigens by strain only (HA-only constructs would induce none) |
| Binding IgG (same antigens as WU397) | Random third | D0, D29, D181 | Bridging to WU397 only; **not** a breadth endpoint |
| Fc-effector activity and stem-directed antibody against Tier 1 H3 and H1 HAs | Random third | D0, D29 | Exploratory: does the excess binding antibody function? |
| Antigen-specific CD4 T cells | ~60 per arm | D0, D29 | Exploratory |
| Solicited local/systemic reactions (7 days); unsolicited AEs (28 days); medically attended AEs, SAEs and AESIs (to D181) | All | — | Safety |
| Influenza-like illness → PCR; serological marker of infection with proteins not in any vaccine, at D181 | All | Through D181 | Identifies intercurrent infection so that it does not distort durability |

Visits have fixed windows (±7 days) and each is analysed separately; there is no pooling of late visits. The assay range must cover the expected titres: WU397's MN capped 9/15 Fluarix titres.

**Endpoints and success criteria**
- **Primary (two subtype-specific endpoints, two-sided α 0.025 each).** Day-29 adjusted GMT ratio A/B of each participant's geometric-mean neutralising titre across Tier 1, for **H3N2** and for **H1N1**. Superiority requires the lower 95% bound >1.0 **and** a point estimate ≥1.5. The 1.5 threshold mirrors the conventional 1.5 non-inferiority margin for HAI GMT ratios [EXT-4]. A general heterologous claim needs the H3N2 endpoint, because H3N2 drives most vaccine mismatch.
- **Key secondary, in a fixed testing order within each subtype that passes its primary:**
  1. The same comparison against Arm C (RIV).
  2. Day-181 Tier 1 ratios against B and C (durability).
  3. B/Victoria Tier 1.
  4. Breadth response rate: % of participants with a ≥4-fold rise against ≥50% of a subtype's Tier 1 viruses.
  5. Tier 2 ratios.
- **Homologous (estimated here, formally confirmed in Phase 3).** HAI GMT ratio B/A, upper 95% bound ≤1.5; seroconversion difference B−A, upper bound ≤10 percentage points, for each strain [EXT-4]. B/Victoria is the one to watch (0/13 seroconversions in WU397).
- **Go to Study 2 only if all of these hold:**
  - The H3N2 primary endpoint is met.
  - The day-181 H3N2 ratio against B has a lower bound >1.0.
  - Non-inferiority is not excluded for any vaccine strain.
  - Reactogenicity is acceptable.
- **Interpretation rules:**
  - If A beats B but not C: the advantage comes from non-egg antigen, not from the mRNA platform. The defensible claim becomes parity with RIV, not superior breadth.
  - If only H1 passes: do not pursue a general heterologous claim. Rework the H3 immunogen or dose first.

**Size**
- About **350 randomised per arm (~300 evaluable)**: about 1,050 in total, or about 1,400 with Arm D.
- Planning SD 1.2 log2, slightly above the residual SDs seen in WU397 (0.94–1.15). With 300 evaluable per arm, the smallest detectable ratio is **1.27×** (two-sided α 0.025 per subtype, 90% power); within the ≥65 stratum (150 per arm) it is **1.40×**.
- At WU397's H3 estimate of 1.17×, about 590 per arm would be needed, and an effect that small would not be worth claiming.
- Formal HAI seroconversion non-inferiority needs about 440–530 per arm per strain, which is why it belongs in Phase 3.

**Pre-specified analysis rules**
- Intention-to-treat immunogenicity set.
- ANCOVA on log titre with baseline and the stratification factors as covariates.
- Censored titres handled with a censored-data (Tobit-type) model.
- Multiplicity: α split across the two subtype primaries; fixed testing order for the key secondaries.
- Intercurrent-infection sensitivity analysis.
- Virus panel and classification locked before unblinding.

### Study 2: event-driven relative-efficacy trial (Phase 3). This is the study that carries the claim.

**Conditions**
- Randomised 1:1, observer-blind, against an active comparator.
- Event-driven, multinational, over at least 2 seasons, using both hemispheres if needed to accrue mismatched cases.
- Strains follow WHO each season, matched between arms exactly as in Study 1.
- An optional second-season revaccination cohort tests whether breadth and relative efficacy hold up with annual dosing.

**In whom**
- Community-dwelling adults **≥50**, stratified 50–64 / 65–74 / ≥75, with at least half aged ≥65. Stable chronic conditions are allowed.
- Stratified by age, prior-season vaccination and region.

**Against what**
- A licensed, age-appropriate comparator: standard-dose egg-based inactivated vaccine (e.g., Fluarix) for ages 50–64; for ≥65, a preferentially recommended vaccine (high-dose, adjuvanted or RIV) [EXT-5].
- Using a standard-dose comparator in people ≥65 limits the claim to that comparison.

**What is measured**
- **Surveillance.** Active surveillance for influenza-like illness, with at least weekly contact, from day 14 to the end of the season (≥6 months). Symptom-triggered swabs within a fixed window.
- **Lab confirmation.** Central RT-PCR with subtype/lineage; HA and NA sequencing of every positive.
- **Antigenic characterisation.** Each isolate is compared with that season's vaccine strain by an independent reference laboratory blinded to arm.
- **Mismatch classification, locked before unblinding.**
  - Primary: antigenic, e.g., ferret-antiserum HI ≥8-fold below homologous, or the equivalent cartographic distance.
  - Sensitivity: genetic (clade, or substitutions at antigenic sites).
  - Imputation rules for cases with no isolate or sequence.

**Endpoints**
- **Primary:** relative vaccine efficacy (rVE) against PCR-confirmed protocol-defined influenza-like illness from any influenza A or B, ≥14 days after dosing. Non-inferiority first, then superiority.
- **Key secondary, the claim:** rVE against PCR-confirmed illness caused by **antigenically mismatched strains** (superiority). Also report rVE against matched strains, to show the advantage is specific to breadth, and rVE by subtype, with H3N2-mismatched cases called out.
- **Other:**
  - rVE for cases more than 90 days after dosing (durability).
  - Medically attended influenza.
  - Influenza hospitalisation and pneumonia.
  - Safety: solicited reactions in a subset; SAEs and AESIs in everyone.
- **Immunogenicity subset:** HAI non-inferiority for the regulatory comparison; about 530 per arm per strain at a 50% seroconversion rate, or about 800 if all strains and criteria are powered jointly.
- **Nested correlates (case-cohort design).** All cases plus a random subcohort, with day-29 serum tested for:
  - HAI against the vaccine strain;
  - neutralisation against the infecting strain, or its closest panel virus;
  - NA-inhibiting antibody;
  - binding IgG.

  Model risk against titre, by arm. This is how a correlate is earned that could later let strain updates be approved by immunobridging. It is also the only route by which the mRNA vaccine's non-neutralising H3 binding antibody could earn credit.

**Size**
- About **510 PCR-confirmed cases** give 90% power to show rVE >0 if the true rVE is 25%; about 850 if it is 20%.
- If the mismatched-strain endpoint must itself have 90% power, and mismatched strains make up 30–70% of cases, about **730–1,700 total cases** are needed.
- The number of participants depends on the seasonal attack rate, which is an assumption here, not data. At 2% PCR-confirmed illness per season, 510 cases need about 26,000 participant-seasons. This is why Study 1 has to show a meaningful, durable advantage first.

### Study 3 (optional, can run alongside Study 1): heterologous human-challenge study

- **Conditions.** Randomised, double-blind, three arms: mRNA candidate, licensed comparator (same season) and, where ethics review accepts it, placebo (to calibrate the attack rate). Challenge about 4–6 weeks after dosing, with a GMP challenge virus that is **antigenically heterologous to every arm's vaccine strains**, with the distance documented as in the panel rules.
- **In whom.** Healthy adults aged 18–50 with low pre-existing HAI and neutralising titres against the challenge strain (screening threshold pre-specified).
- **Readouts.**
  - Primary: PCR-confirmed symptomatic infection.
  - Secondary: infection (shedding or seroconversion), viral-load and symptom-score area under the curve, duration of shedding.
  - Pre-challenge neutralising titre against the challenge strain, analysed as a correlate.
- **Size.** About 90 per arm for 90% power to detect a halving of symptomatic infection from 45% to 22.5% (about 70 per arm at 80% power).
- **Limits.** There are few challenge strains and most are older. Participants are young, healthy and low-immunity, and disease is mild. The study supports proof-of-concept only; it cannot replace Study 2.

### Gating summary

| Step | Proceed if | If not |
|---|---|---|
| Study 0 → protocol | Comparator composition documented; covariates retrieved; data problems resolved; safety data added | The committee package is incomplete |
| Study 1 → Study 2 | H3N2 Tier 1 D29 ratio vs Fluarix: lower bound >1.0 and point ≥1.5; D181 lower bound >1.0; homologous non-inferiority not excluded; acceptable reactogenicity | H1 only → rework H3 before Phase 3. A > Fluarix but ≈ RIV → reframe the claim away from platform superiority |
| Study 2 → claim | Mismatched-strain rVE lower bound >0, with primary rVE met | The claim is limited to what the primary endpoint supports |

---

## 4. What should not be used to support the claim

- **Binding breadth** (bead array, ELISA), mAb breadth counts, GC or plasmablast frequencies, and clonotype counts.
  - On the same H3 strains, binding and neutralisation diverge by up to about 10×.
  - The mAb and FNA data come from 4 vs 3 and 6 vs 11 donors.
- **Unadjusted fold-rises** between non-randomised arms.
- **Egg-adapted or production-reassortant viruses and historic strains** within a "heterologous breadth" composite. Also, any "homologous" definition that refers to only one arm's antigens.
- **HAI ≥1:40 "seroprotection" as evidence of protection against heterologous strains**, or for antibody raised by mRNA vaccines. That threshold is not validated for either.
- **Pooled week 17/26** durability.

---

## 5. Where every number came from

Abbreviations:
- **TS** = `trial_summary.md`.
- Input data files are in `/tmp/world/filesystem/`.
- Scripts and tables are in `/tmp/outputs/analysis/`; `tables/` = `/tmp/outputs/analysis/tables/`.
- Re-run everything with `analysis/run_all.sh`.

| Number(s) | Meaning | Source data | Computation → output |
|---|---|---|---|
| 38/37, 14/15, 14/15, 13/14, 6/11 | Assay cohort sizes (mRNA/Fluarix) | TS | As stated |
| Days 0, 7, 29, 121, 181; FNA weeks 1, 2, 4, 8, 17, 26 | Visit schedule | TS | As stated |
| mRNA antigens A/Victoria/4897/2022, A/Darwin/6/2021, B/Austria/1359417/2021, B/Phuket/3073/2013 | Vaccine composition | TS | As stated |
| Fluarix 2022–23: A/Victoria/2570/2019-like, A/Darwin/9/2021-like, B/Austria, B/Phuket | Comparator composition | **[EXT-1]**, not in the folder | Verify against the lot label (Study 0) |
| HAI GMTs 137.9/87.8, 56.6/57.9, 56.6/51.6, 88.3/98.5; late H1 72.5/81.9; seroconversion 50.0/33.3, 14.3/20.0, 0/6.7, 0/6.7, late H1 0/33.3; H3 seroprotection 64.3/86.7 | HAI by arm | `hai_titers.csv` | `wu397_serology.py` → `tables/serology_per_arm.csv` |
| HAI adjusted ratios 1.54 (0.87–2.71), 0.83 (0.47–1.45), 1.06 (0.68–1.66), 1.05 (0.71–1.56), 1.01 (0.73–1.40) | HAI arm comparison | `hai_titers.csv` | `wu397_serology.py` → `tables/serology_arm_comparisons.csv` |
| MN GMT 325/588, 235/368, late 126/320; GMFR 2.49/3.32, 4.12/3.03; adjusted 0.68 (0.31–1.51), 1.17 (0.52–2.62), late 0.73 (0.37–1.45); baseline ratio 0.47 (0.22–1.00) | MN | `microneutralization.csv` | `wu397_serology.py` → `tables/serology_per_arm.csv`, `tables/serology_arm_comparisons.csv` |
| 9/15 Fluarix titres at 1:1280 | MN ceiling | `microneutralization.csv` | `integrity_checks.py` → `logs/integrity_checks.log` |
| ρ 0.73 (Darwin/9/2021); median ρ 0.42 (H3N2) vs 0.12 (H1N1) | MN behaves as H3 | `microneutralization.csv`, `neutralization_seqbased.csv` | `wu397_mn_identity.py` → `tables/mn_vs_seqneut_correlation.csv` |
| ELISA GMTs 8329/3131, 7936/2610; adjusted 2.66 (2.01–3.53), 3.31 (2.47–4.43) | Binding IgG | `elisa_igg_titers.csv` | `wu397_serology.py` → `tables/serology_*.csv` |
| ELISA ID blocks 1–59 vs 3–31 and 64–102 | Enrolment pattern | `elisa_igg_titers.csv` | `integrity_checks.py` → `logs/integrity_checks.log`; `tables/elisa_by_id_block.csv` |
| Binding fold-rise ratios 6.10, 9.45, 9.51, 10.07, 5.86, 3.87, 3.80, 2.65, 2.04, 1.83, 1.30, 1.26 (with CIs) | Bead-array arm ratios | `binding_breadth_h1.csv`, `binding_breadth_h3.csv` | `wu397_binding_vs_neut.py` → `tables/binding_breadth_by_strain.csv` |
| −1.94 vs +0.38; ρ 0.29/0.66 (H3) and 0.30/0.71 (H1) | Binding–neutralisation dissociation | Bead-array + seq-neut files | `wu397_binding_vs_neut.py` → `tables/binding_vs_neutralisation_per_participant.csv`, `logs/` |
| Same-strain neutralisation ratios 0.62, 0.82, 1.34, 1.96, 2.06, 1.83, 2.07, 2.44, 1.76, 1.73, 1.66; GMTs 244/482, 480/695, etc. | Seq-neut per virus | `neutralization_seqbased.csv` | `wu397_seqneut.py` → `tables/seqneut_per_virus_ancova.csv`; `wu397_same_strain.py` → `tables/same_strain_binding_vs_neutralisation.csv` |
| Class ratios 2.06, 1.17, 1.69, 2.44, 1.84, 1.17, 1.05, 1.63, 1.54, 0.62, 0.81 and late values; baseline GMTs; ≥4× rates (11.9/52.6, 23.7/26.2, …) | Seq-neut by class | `neutralization_seqbased.csv` | `wu397_seqneut.py` → `tables/seqneut_category_ancova.csv`, `tables/seqneut_pct4fold_by_category.csv` |
| Advanced-H3 subset 1.04 (0.49–2.18), 0.76 (0.39–1.49); floor 46.2% vs 21.4% | Drifted H3 | `neutralization_seqbased.csv` | `wu397_seqneut.py` → `logs/wu397_seqneut.log` |
| Waning 0.43 vs 0.76 (H1), 0.64 vs 0.67 (H3) | D29 → D121/181 | `neutralization_seqbased.csv` | `wu397_seqneut.py` → `tables/seqneut_waning.csv` |
| Day-181-only 1.14 (0.68–1.94), 0.98 (0.58–1.66) | Durability check | `neutralization_seqbased.csv` | `wu397_seqneut.py` (day-181 sera only, n=21) → `logs/wu397_seqneut.log` |
| Smallest q = 0.11; 0/96 significant | FDR | `neutralization_seqbased.csv` | `wu397_seqneut.py` → `tables/seqneut_per_virus_ancova.csv` |
| 96 viruses (13 H1N1 / 83 H3N2 / 0 B); 7,719/7,776 titres; 6 reassortant-designated; naming errors | Panel facts | `neutralization_seqbased.csv` | `integrity_checks.py` → `logs/integrity_checks.log`; `tables/seqneut_virus_classification.csv` |
| Baseline ratios 0.66 (0.40–1.11), 0.58 (0.24–1.40); slopes −0.44, −0.26; unadjusted 1.30 and 2.08 vs adjusted 1.17 and 1.63 | Baseline imbalance | Seq-neut, HAI, MN, ELISA files | `wu397_baseline_balance.py` → `tables/baseline_balance.csv`, `tables/foldrise_vs_baseline.csv` |
| Censoring: 171 upper- and 70 lower-bound titres | Assay limits | `neutralization_seqbased.csv` | `integrity_checks.py` → `logs/integrity_checks.log`; `tables/seqneut_censoring_by_category.csv` |
| GC 24.2% vs 2.3%, p=0.036 | FNA germinal-centre B cells | `gc_frequencies.csv` | `wu397_cellular.py` → `tables/gc_summary.csv` |
| 695 mAbs; 589/106; 79.2%; 1 and 5 group-II binders; Cal/09 21.5–64.0% vs 50.0–88.9%; HK/68 32.7–69.0% vs 0–17.4%; H7 2.8–25.3% vs 0% | mAb panels (threshold 5× over control) | `mab_binding_panels.csv` | `wu397_mab.py` → `tables/mab_donor_level_binding.csv` |
| Clonotypes 32 vs 17.5, p=0.066 | Serum repertoire | `repertoire_clonotype_counts.csv` | `wu397_cellular.py` → `logs/wu397_cellular.log` |
| Integrity items 1–7 | Data problems | All files | `integrity_checks.py` → `logs/integrity_checks.log` |
| Residual SD 0.94 / 1.03 (single-strain 0.98 / 1.15); minimum detectable 1.27× / 1.40×; 590 per arm at 1.17×; 442–526 per arm HAI seroconversion NI; 510 / 850 cases; 730–1,700; about 26,000 participant-seasons; challenge study 91 / 69 per arm | Planning calculations | Seq-neut file plus stated assumptions | `wu397_power.py` → `power_calculations.txt` (attack rates and effect sizes are assumptions, not data) |
| **[EXT-1]** WHO 2022–23 NH recommendation: egg-based A/Victoria/2570/2019 (H1N1)pdm09-like, A/Darwin/9/2021 (H3N2)-like; cell/recombinant-based A/Wisconsin/588/2019, A/Darwin/6/2021; B/Austria/1359417/2021, B/Phuket/3073/2013 | External reference, general knowledge | — | Verify against the WHO document and the lot label |
| **[EXT-2]** WHO 2023–24 NH: H1 A/Victoria/4897/2022 (egg-based) / A/Wisconsin/67/2022 (cell-based) | External | — | Verify |
| **[EXT-3]** B/Yamagata not detected since 2020; WHO advised dropping it; trivalent vaccines from 2024–25 NH | External | — | Verify |
| **[EXT-4]** FDA 2007 seasonal inactivated influenza guidance: non-inferiority upper bounds ≤1.5 (GMT ratio) and ≤10 points (seroconversion) | External | — | Confirm with the agency in pre-submission |
| **[EXT-5]** US ACIP (2022): high-dose, adjuvanted or recombinant vaccines preferred for ≥65 | External | — | Verify for the target jurisdiction |
| **[EXT-6]** WHO collaborating-centre convention: ≥8-fold HI reduction with ferret antiserum indicates antigenic difference | External | — | Define operationally in the protocol |

---

## 6. Files produced

Everything is in `/tmp/outputs/analysis/`.

- **Report:** `/tmp/outputs/answer.md` (this file).
- **Figure:** `forest_binding_vs_function.png` shows every arm comparison on one axis; the dotted line marks 1.5×.
- **Scripts:**
  - `integrity_checks.py`
  - `wu397_serology.py`
  - `wu397_seqneut.py`
  - `wu397_baseline_balance.py`
  - `wu397_binding_vs_neut.py`
  - `wu397_same_strain.py`
  - `wu397_mab.py`
  - `wu397_cellular.py`
  - `wu397_mn_identity.py`
  - `wu397_power.py`
  - `wu397_figure.py`
  - `run_all.sh` re-runs all of them.
- **Outputs:** `tables/*.csv`, `logs/*.log` and `power_calculations.txt`.
