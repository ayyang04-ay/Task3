**Recommendation:** WU397 does not support a heterologous-protection claim — next run a randomised, observer-blind, strain-matched trial (mRNA vs the same season's egg-based vaccine and an HA-matched non-egg vaccine, ages 18–64 and ≥65) whose primary endpoint is the baseline-adjusted Day-29 neutralising GMT ratio against a locked panel of wild-type, antigenically distant and post-vaccination H1N1/H3N2/B-Victoria strains, and start an event-driven relative-efficacy trial with antigenic typing of breakthrough strains only if it succeeds.

---

## 0. Summary for the committee

- **WU397 cannot separate the mRNA platform from other causes.** Arms were allocated by site and were not randomised or blinded. The two vaccines also did not contain the same strains: the H1 strains differ, and the comparator's H3 is egg-based. The package has no demographics or prior-vaccination data.
- **Where the two vaccines' antigens are essentially the same (H3N2), mRNA-1010 shows no heterologous neutralisation advantage.** Against 68 drifted 2022–24 H3N2 viruses, the Day-29 GMT ratio (mRNA-1010:Fluarix) is 0.86 (95% CI 0.44–1.69), or 1.18 (0.65–2.14) after baseline adjustment.
- **The one functional signal is H1**: baseline-adjusted ratio 1.95 (1.21–3.14). But the H1 antigens differ between arms, and by Day 181 the ratio is 1.05 (0.60–1.82).
- **The large mRNA advantages are in binding assays, germinal-centre size and monoclonal-antibody counts. None of these is an established correlate of protection, and binding did not track neutralisation here.** In the same participants, H3 binding is 6.5× higher with mRNA-1010, but H3 neutralising titre is 0.86×.
- **Next:** Study A (below) is the gating study. Study B, the relative-efficacy (rVE) trial, is the only study that can carry a *protection* claim. An optional challenge study (Study C) can de-risk timing.

---

## 1. What WU397 can and cannot support

### 1.1 Design problems that bias every arm comparison
1. **Allocation.** Arms were assigned by enrolment site, not randomised, and the study was open-label (`trial_summary.md`).
   - Participant IDs show the structure. IDs 1–32 interleave the two arms (15 Fluarix, 14 mRNA-1010); these are the *entire* cohort for the functional assays (HAI, MN, bead array, seq-neut). IDs 33–59 are Fluarix only (22) and 64–102 are mRNA-1010 only (24) (`elisa_igg_titers.csv`).
   - Enrolment block already matters within one arm. In the Fluarix arm, block enrolees had lower baseline B antibody than the interleaved-ID enrolees: ELISA B/Vic GMT 877 vs 1,794 (p=0.011); B/Yam 1,139 vs 2,247 (p=0.030).
   - The package has no variables for age, sex, site or prior vaccination, so none of this can be adjusted for.
2. **Baseline imbalance inflates fold-rise comparisons.** On the H3 seq-neut panel, the mRNA-1010 arm started lower: baseline GMT 136 vs 212 (0.64×, p=0.10). Lower baseline predicts larger fold-rise (r = −0.39 between baseline and fold-rise). So the "higher fold-rise" for mRNA-1010 on H3 mostly disappears when titres are compared directly (Fig. 1).
3. **The arms received different antigens.**
   - The summary says mRNA-1010 encodes A/Victoria/4897/2022 (H1) and A/Darwin/6/2021 (H3, cell-type).
   - Fluarix 2022–23, per its label, contains A/Victoria/2570/2019 (H1, an earlier clade) and egg-based A/Darwin/9/2021 (H3). This is external knowledge, see §5.
   - Every "homologous/heterologous" label in the package is defined against the mRNA-1010 antigens only. So the "homologous" H1 readouts are not homologous for Fluarix, and H1 "breadth" mixes platform with a newer antigen.
4. **The data don't corroborate the stated mRNA-1010 H1 antigen.**
   - In the mRNA-1010 arm, the largest H1 neutralising rise is against A/Wisconsin/588/2019 (5a.2, Fluarix-like): fold-rise 6.48. Against A/Wisconsin/67/2022, the cell-type counterpart of the stated Victoria/4897/2022, it is 3.70.
   - 202 of 264 mRNA-donor group I monoclonal antibodies (mAbs) bind Wisconsin/588/2019 most strongly, and only 56 bind Victoria/4897/2022 most strongly. Median signal is 212.5 vs 48.9.
   - Recall of prior immunity could produce this pattern, so it isn't proof. But the lot's encoded HA must be confirmed: it decides whether the H1 signal reflects the platform or the antigen (§3).
5. **Egg-adapted and reassortant viruses are mixed into the panels.**
   - The seq-neut panel includes 6 egg/reassortant-designated viruses plus A/Darwin/9/2021. All neutralise far more easily than their wild-type partners; for example, A/Cambodia/e0826360/2020 egg vs wild-type median titre is 2,494 vs 324.
   - Five of them are duplicates of wild-type strains already in the panel, so counting them as extra "strains" inflates breadth.
   - The only Victoria/4897/2022 virus in the panel is the egg reassortant IVR-238.

### 1.2 Functional antibody where the antigens are matched (H3N2): no breadth advantage
Source: seq-neut data (`neutralization_seqbased.csv`; 96 viruses, 27 participants, Day 29 vs Day 0). Participant is the unit of analysis (`02_`, `10_`, `09_` scripts).

| H3N2 panel (wild-type only) | Day-29 GMT, mRNA vs Fluarix | Unadjusted ratio (95% CI) | Baseline-adjusted ratio (95% CI) |
|---|---|---|---|
| Contemporary / forward 2022–24 (68 viruses) | 400 vs 464 | 0.86 (0.44–1.69) | 1.18 (0.65–2.14); mixed model 1.09 (0.64–1.86) |
| 2024 isolates (3; post-date all sampling) | 133 vs 162 | 0.82 (0.35–1.97) | 0.96 (0.39–2.35) |
| Most distant quartile (19; ranked arm-independently) | 266 vs 308 | 0.86 (0.42–1.76) | 1.23 (0.64–2.35) |
| mRNA-1010's own H3 (Darwin/6/2021) | 244 vs 482 | **0.51 (0.27–0.96)** | 0.63 (0.35–1.14) |
| Historical 2012–20 (8) | 1,520 vs 1,268 | 1.20 (0.60–2.38) | 1.65 (0.99–2.73); mixed model 1.84 (1.13–3.00) |

Other readouts agree:
- **HAI H3N2 at week 4:** GMT 56 vs 58, ratio 0.97 (0.47–2.02); seroconversion 2/14 vs 3/15.
- **Microneutralisation (MN).** The files don't name the viruses, but both MN panels track the H3N2 seq-neut titres (mean r 0.44–0.47) and not H1N1 (0.12–0.17). Fluarix is numerically higher:
  - "homologous" week 4: GMT 325 vs 588, ratio 0.55 (0.22–1.39);
  - the MN ceiling of 1,280 hides more of the Fluarix response (9/15 Fluarix vs 4/14 mRNA-1010 at the ceiling). A censored-data model gives 0.27 (0.05–1.38).

Where there is any H3 breadth, it points backwards to old strains, not forward to drifted ones. That is the wrong direction for a claim about protection against mismatched strains.

### 1.3 H1N1: the one encouraging signal, but confounded and transient
- **Contemporary 2022–23 H1 viruses (7):**
  - Day-29 GMT 471 vs 241; baseline-adjusted ratio **1.95 (1.21–3.14)**, p=0.008;
  - share of panel viruses with a ≥4-fold rise: 0.53 vs 0.13.
- **Historical H1:** 1.79 (0.97–3.33).
- **HAI H1N1 at week 4:** 1.57 (0.91–2.71); seroconversion 7/14 vs 5/15.
- **Caveats:**
  - The arms received different H1 antigens (§1.1) and were not randomised.
  - **At Day 181 the advantage is gone:** contemporary H1 1.05 (0.60–1.82), H3 0.99 (0.58–1.69), n=11/10.
  - HAI H1N1 at week 26 is 0.94 (0.50–1.76).

This is worth testing properly, and it sets the effect size used for Study A.

### 1.4 Binding, germinal-centre and mAb readouts are not evidence of heterologous protection
- **Bead-array binding breadth.**
  - H3 participant-mean log2 fold-change is 3.39 vs 0.87 (p<0.001). The largest gains are on A/Hong Kong/1/1968 (9.5×) and A/Puerto Rico/8/1934 for H1 (2.7×). That pattern fits conserved-epitope or recall binding, not coverage of drifted strains.
  - **In the same 27 participants, H3 binding is 6.5× higher but H3 neutralising titre is 0.86×** (Fig. 2). For H1, binding (2.2×) and neutralisation (1.95×) agree.
  - The file doesn't state which timepoint the fold-change refers to.
- **ELISA IgG at week 4:** H1 2.66× (1.89–3.75) and H3 3.04× (2.21–4.18). The antigens are not named, and this is binding, not function.
- **Germinal centres.** Medians are larger with mRNA-1010 (24.2% vs 2.3% HA-specific at the "wk2" visit, p=0.037; n=6 vs 11). But:
  - every key (visit, arm, participant) appears twice in the file with different values;
  - the visit labels (wk0/2/8/17/26) don't match the biopsy schedule in the summary (wk1/2/4/8/17/26);
  - germinal centres persisting to week 26 did not produce a serum difference at Day 181.
- **mAbs** come from 4 mRNA-1010 donors and 3 Fluarix donors.
  - One Fluarix donor supplies 84 of the 106 Fluarix mAbs. Group II (H3-lineage) Fluarix mAbs per donor are 25, 2 and 7.
  - Treating each mAb as independent gives p<0.001 differences. At the donor level they largely disappear:
    - A/Hong Kong/1/1968: p=0.029, the smallest p-value possible with 4 vs 3 donors;
    - H7: p=0.086;
    - H5: about 5% of mAbs bind in both arms (4.9% vs 5.4%), donor-level p=0.74.
  - So there is **no basis for a claim against other subtypes (H5/H7).**
- **Serum IgG repertoire:** 84–86% of the post-vaccination response comes from clonotypes that already existed before vaccination, in both arms (n=8/8). Breadth in this population mostly reflects prior exposure, and WU397 did not record exposure history.

### 1.5 Package inconsistencies that affect interpretation
Details are in §3. In brief: late visits (week 17 and week 26) are pooled, and 9 participants have conflicting late-visit labels across files. The IgM file has 14/15 participants, not the 38/37 in the summary. The plasmablast file contains 11 participants who are not in the lymph-node cohort, and its visit labels don't match the blood-draw schedule.

**What WU397 does support:** mRNA-1010 produced more binding antibody, larger and longer-lasting germinal centres, and, in a confounded comparison, higher *early* H1 neutralisation. **What it does not support:** forward H3 neutralisation breadth, durable breadth for any subtype, or anything about protection.

---

## 2. Recommended next studies

**What each study lets you claim.**
- **Study A:** "higher and longer-lasting neutralising antibody against antigenically drifted strains than the licensed comparator, attributable to the platform." This is an immunogenicity statement.
- **Study B:** "better protection against antigenically mismatched strains." This is the heterologous-protection claim.
- **WU397:** neither.

### Study A: randomised, strain-matched breadth trial (the protocol to take to committee)

**Question:** does the *platform* produce higher functional antibody against drifted strains, and does that last the season? The design has to rule out antigen choice, egg adaptation, site and baseline as explanations.

| Condition | Specification |
|---|---|
| Design | Randomised 1:1:1, observer-blind, active-controlled, multicentre. Randomise *within site*, stratified by age stratum and prior-season vaccination (yes/no). One Northern Hemisphere season, plus a pre-planned replicate cohort in the next season with a different strain composition, so the result isn't specific to one season. |
| Strain composition | Every arm carries the WHO-recommended strains for that season: trivalent A/H1N1pdm09, A/H3N2 and B/Victoria, with no B/Yamagata. The mRNA encodes the recommended cell/recombinant-type HA sequences. **No sponsor-selected strains.** Optional arm A2: mRNA encoding a later-updated strain, if "strain agility" is part of the value proposition; this tests that benefit separately from the platform effect. |
| Arms / comparators | **A:** mRNA vaccine. **B:** the same season's licensed egg-based standard-dose inactivated vaccine (e.g., Fluarix), the reference comparator for ages 18–64. **C:** the same season's licensed non-egg vaccine (cell-based inactivated or recombinant HA) with HA sequences matched to the mRNA. This separates the platform effect from egg adaptation. In the ≥65 stratum, B should be an age-preferred enhanced egg-based vaccine (high-dose or adjuvanted) and C a recombinant HA vaccine, which is also age-preferred. |
| Population | Healthy adults in two separately powered strata: 18–64 and ≥65 (or 50–64 / ≥65 to mirror the intended label). Exclude current-season vaccination and lab-confirmed influenza in the prior 6 months. Record vaccinations over the prior 5 seasons, prior confirmed influenza, birth year (childhood-imprinting cohort), sex and comorbidities. |
| Size | About 150 evaluable per arm per stratum; about 1,000 randomised for 3 arms × 2 strata including ~10% attrition. Basis is in the sample-size note below. |
| Visits | Day 1 (pre-dose), Day 29, Day 91 and Day 181, each analysed separately with no pooled visits. Influenza-like-illness surveillance with PCR confirmation through Day 181. Infections before Day 29 are excluded from the per-protocol immunogenicity set; later infections censor the durability analysis. |

**Readouts: what, in whom, against what, when**

| Role | Measured | In whom | Against what | When |
|---|---|---|---|---|
| **Primary** | Neutralising antibody titre, summarised per participant as the panel GMT per subtype; ratio A:B from an analysis adjusted for log baseline and strata | All randomised participants with valid Day-1 and Day-29 samples (full analysis set); per-protocol set as sensitivity | **Locked heterologous panel** (spec below) | Day 29 (Day 1 as covariate) |
| Key secondary 1 | Same endpoint, A:C | Same | Same panel | Day 29 |
| Key secondary 2 | Same endpoint | Same | Same panel | **Day 181** |
| Key secondary 3 | Same endpoint | Same | **Forward panel**: strains emerging after the composition decision, picked by a locked rule at the last Day-181 visit, before unblinding | Day 29, 181 |
| Key secondary 4 | HAI GMT ratio and seroconversion difference (non-inferiority, vs B) | Per-protocol set | Each arm's *own* vaccine strains, both egg and cell/sequence versions | Day 29 |
| Secondary | Per-strain GMT and ≥4-fold rise; breadth score (share of panel strains with ≥4-fold rise); neuraminidase-inhibiting antibody to N1 and N2 (split vaccine carries neuraminidase, an HA-only vaccine does not); HA-stem antibody | All (neuraminidase and stem: random subset of at least 1/3) | Vaccine and drifted N1/N2; group 1 and 2 stems | Day 1, 29, 181 |
| Exploratory | Multiplex binding breadth; Fc-effector function; T cells; optional randomised lymph-node/B-cell substudy with equal n per arm, donor as the unit | Random subsets | Panel antigens | Prespecified fixed visits |
| Safety | Solicited reactions Day 1–7; unsolicited events to Day 29; serious and special-interest adverse events to Day 181 | All | — | — |

**Heterologous panel specification (design level)**
- **Per subtype:** 8–12 wild-type strains for H1N1 and for H3N2, and 4–6 for B/Victoria. Each strain is counted once. Egg-adapted and reassortant versions are reported separately and excluded from breadth.
- **"Heterologous" is defined by antigenic distance from *both* arms' vaccine strains.** Selection uses a rule locked before randomisation, e.g., a different HA subclade and at least 4-fold reduced reactivity with reference antisera. The panel should span recent clades, clades co-circulating in the study season, and (through the forward panel) strains that emerge later.
- **Testing:** one central blinded laboratory, with arms balanced across testing batches.
- **Reportable range:** wide enough that no more than 5% of results are censored at either end. WU397's MN had 19% at the ceiling (33 of 174 titres). Censored-data methods are prespecified.
- **For H3N2,** make neutralisation the functional readout rather than HAI alone.

**Analysis and go/no-go into Study B**
- **Analysis:** participant-level summaries only (never virus-level or mAb-level counts), adjusted for baseline and strata. Multiplicity is hierarchical: H3N2, then H1N1, then B/Victoria. A claim extends only to subtypes that succeed.
- **GO:** all of the following, with direction consistent in the ≥65 stratum:
  - at Day 29, A:B lower 95% bound above 1.0 with point estimate ≥1.5 for H3N2 and/or H1N1;
  - at Day 181, point estimate ≥1.3 (the criterion WU397's H1 signal would have failed);
  - homologous HAI GMT ratio lower bound ≥0.67 for every strain.
- **NARROW THE CLAIM** if A beats B but not C. The advantage is then an egg-adaptation effect that non-egg vaccines share, not a platform property.
- **STOP / REDESIGN FOR H3N2** if the Day-29 H3N2 upper bound is below 1.5, which rules out a meaningful effect. WU397's baseline-adjusted H3 estimate was 1.18; detecting that would need about 390–500 per arm, and it would not be clinically meaningful.

**Sample-size basis (from WU397 variance, `11_sample_size.py`)**
- The residual SD of log2 Day-29 panel GMT after baseline adjustment was 1.03 for H3 and 0.86 for H1.
- For a GMT ratio of 1.5 at 90% power with two-sided α=0.0167 (3 subtypes), that needs 84 per arm (H3 SD) or 59 per arm (H1 SD). Allowing SD 1.3 for multi-site variability needs 134 per arm. Hence about 150 per arm per stratum.
- Homologous HAI GMT non-inferiority needs only 45–68 per arm.
- **Confirmatory seroconversion non-inferiority (margin −10 points) needs 268–526 per arm** (assumed seroconversion 15–50%). At 150 per arm, Study A *estimates* seroconversion rather than confirming it. Size it up only if Study A must also serve as the licensure immunobridging study.

### Study B: relative-efficacy trial with antigenically characterised cases (needed for a protection claim)
Run only if Study A says GO.

| Element | Specification |
|---|---|
| Design | Randomised 1:1, observer-blind, active-controlled, event-driven. At least 2 seasons and/or both hemispheres, multinational, so that several drift events are sampled. |
| Population | The intended-label population (e.g., ≥50 with a prespecified ≥65 share), stratified by age and prior vaccination. |
| Comparator | Age-appropriate licensed vaccine with the same season's strains. |
| Primary endpoint | First RT-PCR-confirmed protocol-defined influenza-like illness due to any influenza A/B, from ≥14 days after the dose to season end; rVE tested for non-inferiority, then superiority (hierarchical). |
| **Key secondary (the claim)** | rVE against cases caused by **antigenically mismatched** strains, by subtype. Mismatch is prespecified as a different HA subclade *and* at least 4-fold reduced reactivity with reference antisera to the vaccine strain. Tested hierarchically after the primary. |
| Case characterisation | All positives sequenced (HA, NA); antigenic characterisation by the prespecified rule, done blind to arm. |
| Correlates sub-cohort | Case-cohort design: Day-29 sera from a random sub-cohort plus all cases, tested against the vaccine strains **and each case's own infecting strain**. This shows whether Study A's neutralising endpoint actually predicts heterologous protection. |
| Events | rVE 25% needs 508 events and rVE 20% needs 845 (90% power, 1:1). If 40% of cases are mismatched, a 508-event trial has only 54% power for the mismatched endpoint at rVE 25% (87% at rVE 35%). So plan multi-season accrual of about 500 mismatched events, or treat the mismatched endpoint as estimation. |
| Other | Hospitalisation and severity; early- vs late-season rVE (durability); safety. |

**Study B readouts: what, in whom, against what, when**

| Measured | In whom | Against what | When |
|---|---|---|---|
| RT-PCR-confirmed protocol-defined influenza-like illness (any A/B) | Efficacy set: all randomised, cases counted from ≥14 days post-dose | Comparator arm | Each season, ≥14 days post-dose to season end |
| Same, limited to cases with antigenically mismatched strains (key secondary) | Same | Comparator arm; mismatch classified against that season's vaccine strains | Same |
| HA/NA sequence and antigenic characterisation | Every case, blind to arm | The season's vaccine strains | At case detection |
| Neutralising titre (correlates) | Random sub-cohort plus all cases | Vaccine strains, each case's own infecting strain, and Study A's drift panel | Day 1, Day 29 (Day 181 in a subset, for late-season cases) |
| Hospitalisation, severity | All | Comparator arm | Season |
| Reactogenicity and safety | All (solicited reactions in a subset) | Comparator arm | Days 1–7 solicited; serious adverse events through the season |

### Optional Study C: heterologous challenge study (de-risking only)
- Randomised, double-blind: mRNA vs licensed comparator, in healthy adults aged 18–55.
- Challenge 4–8 weeks after vaccination with a characterised same-subtype virus that is antigenically distant from the vaccine strain.
- Primary endpoint: laboratory-confirmed infection. Secondary: symptomatic infection and viral-load AUC. About 40–60 per arm.
- Limits: available challenge viruses tend to be older strains, so the test points backwards. Screening for low pre-existing titre gives an unrepresentative population. It cannot replace Study B.

### Alternatives considered
- **Going straight to efficacy with immunogenicity embedded:** faster, but WU397 shows no forward H3 breadth, and the H1 signal is gone by Day 181. A failed rVE trial is the most expensive way to learn that.
- **Re-testing WU397 sera with a better panel:** cheap and useful for designing the panel. But it can't fix non-randomisation or the antigen mismatch, so do it alongside Study A, not instead of it.

### Readouts not to build the claim on
Any of these as primary or key-secondary endpoints for breadth: binding (ELISA or bead array), germinal-centre or biopsy frequencies, mAb-level percentages, fold-rise between non-randomised groups, pooled visits, egg-adapted viruses counted as strains, B/Yamagata, or H5/H7.

---

## 3. Fix or verify in the WU397 package before the committee
1. **Encoded HA sequence of the mRNA-1010 lots.** The H1 responses peak on Wisconsin/588/2019, not on the stated Victoria/4897/2022 (§1.1). Then re-label homologous and heterologous for *each* arm.
2. **Identity and passage history of the MN viruses.** Neither panel is named. Both track H3N2. The "homologous" MN correlates best with egg-based Darwin/9/2021 (r=0.74) rather than Darwin/6/2021 (r=0.59), so it may be homologous to the *comparator*.
3. **Germinal-centre file (`gc_frequencies.csv`).** All 156 of 156 rows share their key with another row, and the two blocks give different values. The visit labels don't match the biopsy schedule (no wk1 or wk4; a wk0 that isn't in the protocol).
4. **Plasmablast file (`plasmablast_frequencies.csv`).**
   - Its visits are wk0/2/8/17/26, but blood was drawn on d0/7/29/121/181.
   - 11 of its participants are not in the lymph-node cohort.
   - Its n (13/15, mRNA-1010/Fluarix) matches no cohort in the summary.
5. **IgM file.** 14/15 participants, not 38/37 as stated; no timepoint; 61 of 116 values floored at 1.
6. **Bead-array files.** Which timepoint the fold-change refers to is not stated.
7. **Late visits.** Nine participants have week-17/week-26 labels that conflict across files (IDs 7, 8, 9, 10, 11, 16, 18, 21, 23): HAI B/Vic conflicts for 8 of them, seq-neut for 2. The fold-change tables pool week 17 and week 26 (ELISA: 7 participants at week 17, 68 at week 26). Report each visit separately.
8. **Missing information.** ELISA and HAI antigens are not named. There are no demographics, site or prior-vaccination fields. The repertoire files have no participant IDs. One virus name has a typo ("A/SOUTHAFRICA/R07876/202023").

---

## 4. Numbers relied on and their sources
Every quoted number, with its input file and output file, is in **`/tmp/outputs/numbers_ledger.csv`** (234 entries, generated by script). The key ones:

| Number | Value | Input file → analysis output |
|---|---|---|
| Cohort n (mRNA-1010/Fluarix) | ELISA 38/37; HAI, MN, bead array, IgM 14/15; seq-neut 13/14; germinal centre 6/11; plasmablast 13/15 | each file (direct count); `trial_summary.md` |
| Enrolment structure; Fluarix baseline B/Vic GMT, interleaved IDs vs block | IDs 1–32 interleave arms; 1,794 vs 877, p=0.011 | `elisa_igg_titers.csv` → `enrolment_block_check.csv` |
| Seq-neut H3 2022–24 (68 viruses): baseline GMT; Day-29 GMT; ratio; adjusted ratio | 136 vs 212; 400 vs 464; 0.86 (0.44–1.69); 1.18 (0.65–2.14) | `neutralization_seqbased.csv` → `seqneut_breadth_ancova.csv` |
| Same panel, mixed model | 1.09 (0.64–1.86) | → `seqneut_mixed_model.csv` |
| Seq-neut Darwin/6/2021 Day-29 GMT; ratio; adjusted | 244 vs 482; 0.51 (0.27–0.96); 0.63 (0.35–1.14) | → `seqneut_breadth_ancova.csv` |
| Seq-neut H3 2024 isolates; most distant quartile (adjusted) | 0.96 (0.39–2.35); 1.23 (0.64–2.35) | → `seqneut_h3_distant_subsets.csv` |
| Seq-neut H3 historical (adjusted; mixed model) | 1.65 (0.99–2.73); 1.84 (1.13–3.00) | → `seqneut_breadth_ancova.csv`, `seqneut_mixed_model.csv` |
| Seq-neut H1 2022–23: Day-29 GMT; adjusted ratio; share of viruses with ≥4-fold rise | 471 vs 241; 1.95 (1.21–3.14); 0.53 vs 0.13 | → `seqneut_breadth_ancova.csv` |
| Seq-neut Day 181, adjusted (H1 contemporary; H3 contemporary) | 1.05 (0.60–1.82); 0.99 (0.58–1.69); n=11/10 | → `seqneut_d181.csv` |
| Baseline vs fold-rise correlation (H3) | r = −0.39 (n=27) | → `09_seqneut_distant_subsets.py` |
| H1 fold-rise, mRNA-1010 arm: Wisconsin/588/2019 vs Wisconsin/67/2022 | 6.48 vs 3.70 | → `seqneut_per_virus.csv` |
| Egg vs wild-type median titre (Cambodia/e0826360/2020) | 2,494 vs 324 | `neutralization_seqbased.csv` (direct) |
| Seq-neut censoring | 171 below detection (≤~40); 70 above range (≥~17,300) of 7,719 | direct count |
| HAI week 4: H1N1 ratio, seroconversion; H3N2 ratio, seroconversion; H1N1 week 26 | 1.57 (0.91–2.71), 7/14 vs 5/15; 0.97 (0.47–2.02), 2/14 vs 3/15; 0.94 (0.50–1.76) | `hai_titers.csv` → `serology_ancova.csv` |
| MN week 4 homologous GMT, ratio; censored-data (Tobit) estimate; ceiling counts | 325 vs 588, 0.55 (0.22–1.39); 0.27 (0.05–1.38); 33/174 titres at 1,280; at week 4, 4/14 mRNA-1010 vs 9/15 Fluarix | `microneutralization.csv` → `serology_ancova.csv`, `mn_tobit.csv` |
| MN vs seq-neut correlation (homologous: Darwin/9 vs Darwin/6; H3N2 vs H1N1 mean) | 0.74 vs 0.59; 0.47 vs 0.12 | → `mn_vs_seqneut_correlation.csv` |
| ELISA week 4 GMT ratio: H1; H3 | 2.66 (1.89–3.75); 3.04 (2.21–4.18) | `elisa_igg_titers.csv` → `serology_ancova.csv` |
| Bead-array H3 participant mean log2 fold-change; Hong Kong/1968; Puerto Rico/8/1934 | 3.39 vs 0.87; 9.5×; 2.7× | `binding_breadth_h3/h1.csv` → `binding_breadth_per_strain.csv` |
| Same participants: binding vs neutralising fold-rise vs Day-29 titre | H3 6.5× / 1.3× / 0.86×; H1 2.2× / 1.9× / 1.95× | → `binding_vs_neut_participant.csv` |
| mAbs per donor; donor-level p (Hong Kong/1968, H7, H5) | Fluarix 84/11/11, mRNA-1010 200/162/53/174; 0.029, 0.086, 0.743 | `mab_binding_panels.csv` → `mab_donor_level.csv` |
| Group I mAbs binding Wisconsin/588 vs Victoria/4897 most strongly (mRNA-1010); medians | 202 vs 56 of 264; 212.5 vs 48.9 | → `out_14_h1_antigen_identity_check.txt` |
| Germinal centre "wk2" medians; p | 24.2% vs 2.3%; p=0.037 (n=6/11) | `gc_frequencies.csv` → `out_07_cellular.txt` |
| Pre-existing share of serum IgG | 83.9% vs 86.2% (n=8/8) | `repertoire_clonotype_counts.csv` → `out_07_cellular.txt` |
| Residual SD (log2) H3 / H1; n per arm for ratio 1.5 (α 0.0167, 90% power) | 1.03 / 0.86; 84 / 59; 134 at SD 1.3 | → `sample_size_immunogenicity.csv` |
| Seroconversion non-inferiority n per arm; events for rVE 25% / 20%; power of mismatched endpoint | 268–526; 508 / 845; 0.54 (40% mismatched, rVE 25%) | formulas → `sample_size_rve_events.csv`, `power_mismatched_subendpoint.csv` |

Analysis conventions:
- Titres are analysed on the log2 scale.
- Seq-neut values below detection are set to LOD/2; setting them at the LOD instead gives the same conclusions (`seqneut_breadth_ancova.csv`).
- A 4-fold rise is tested with a tolerance because HAI titres are rounded (57→226 is exactly 4-fold).
- Week 17 is never pooled with week 26.
- The participant, or the donor for mAbs, is the unit of analysis.

## 5. External facts and assumptions (not in the package)
- **Fluarix 2022–23 composition** (the WHO 2022–23 Northern Hemisphere egg-based recommendation): A/Victoria/2570/2019, A/Darwin/9/2021, B/Austria/1359417/2021 and B/Phuket/3073/2013.
- **WHO strain history:**
  - A/Victoria/4897/2022 was first recommended in February 2023 (2023–24 Northern Hemisphere), with cell-type counterpart A/Wisconsin/67/2022.
  - A/Wisconsin/588/2019 was the 2022–23 cell/recombinant H1.
  - A/Darwin/6/2021 is the cell-type counterpart of A/Darwin/9/2021.
- **B/Yamagata** has not been confirmed in circulation since 2020, and WHO has advised dropping it, hence trivalent vaccines.
- **FDA (2007) seasonal-vaccine guidance** for non-inferiority: upper bound of the comparator:new GMT ratio ≤1.5, and upper bound of the seroconversion difference ≤10 points.
- **Split inactivated vaccines carry neuraminidase; mRNA-1010's four antigens are HA.** This comes from product descriptions, not the package.
- **Regulatory judgement.** My reading is that a label-level *protection* claim against mismatched strains needs clinical-endpoint data, which is why Study B is needed. Confirm this at a scientific-advice meeting.
- **Design numbers.** The rVE figures and the mismatched-case fractions are assumptions used for planning, not data.

## 6. Files
- `/tmp/outputs/answer.md`: this document.
- `/tmp/outputs/numbers_ledger.csv`: every number, with its source.
- Figures:
  - [`fig1_seqneut_per_virus.png`](fig1_seqneut_per_virus.png): Day-29 GMT ratio and fold-rise ratio for every seq-neut virus, grouped by panel.
  - [`fig2_binding_vs_neutralisation.png`](fig2_binding_vs_neutralisation.png): binding vs neutralisation in the same 27 participants.
- `/tmp/outputs/analysis/`: scripts `00_`–`19_`, their CSV/TXT outputs, and a README explaining each.
