"""Exploratory: do conclusions change for the most antigenically distant H3N2 viruses?
Distance proxy = pooled (both arms) d0 GMT ranking -> arm-independent. Also the three 2024 isolates (post-date all sampling)."""
import importlib.util, numpy as np, pandas as pd
import statsmodels.formula.api as smf
spec = importlib.util.spec_from_file_location('L', '/tmp/outputs/analysis/00_load.py'); L = importlib.util.module_from_spec(spec); spec.loader.exec_module(L)
pd.set_option('display.width', 250)
d = L.load_seqneut(); d['l2'] = np.log2(np.where(d.cens=='left', 20, d.titer))
h3 = d[(d.subtype=='H3N2') & ~d.egg_or_reassortant & ~d.virus.str.contains('Darwin')]
pooled0 = h3[h3.day==0].groupby('virus').l2.mean().sort_values()
q = pooled0.quantile(0.25)
subsets = {'H3 2024 isolates (n=3)': [v for v in pooled0.index if '/2024_' in v],
           'H3 lowest-quartile pooled d0 GMT (most distant)': list(pooled0[pooled0 <= q].index),
           'H3 all wild-type non-vaccine (n=%d)' % len(pooled0): list(pooled0.index)}
rows = []
for name, vs in subsets.items():
    s = h3[h3.virus.isin(vs) & h3.day.isin([0,29])]
    p = s.pivot_table(index=['arm','pid','virus'], columns='day', values='l2').dropna().reset_index()
    g = p.groupby(['arm','pid']).agg(l0=(0,'mean'), l29=(29,'mean')).reset_index(); g['m'] = (g.arm=='mRNA-1010').astype(int)
    f = smf.ols('l29 ~ m + l0', g).fit(); u = smf.ols('l29 ~ m', g).fit()
    rows.append(dict(subset=name, n_viruses=len(vs), GMT29_m=2**g[g.m==1].l29.mean(), GMT29_f=2**g[g.m==0].l29.mean(),
                     unadj=2**u.params.m, unadj_lo=2**u.conf_int().loc['m',0], unadj_hi=2**u.conf_int().loc['m',1],
                     adj=2**f.params.m, adj_lo=2**f.conf_int().loc['m',0], adj_hi=2**f.conf_int().loc['m',1], adj_p=f.pvalues.m))
r = pd.DataFrame(rows); r.to_csv('/tmp/outputs/analysis/seqneut_h3_distant_subsets.csv', index=False); print(r.round(3).to_string())
print('lowest-quartile viruses:', list(pooled0[pooled0 <= q].index))
# baseline dependence of fold-rise (why fold-rise comparisons mislead under imbalance)
s = h3[h3.day.isin([0,29])].pivot_table(index=['arm','pid','virus'], columns='day', values='l2').dropna().reset_index()
g = s.groupby(['arm','pid']).agg(l0=(0,'mean'), l29=(29,'mean')).reset_index(); g['lfr'] = g.l29-g.l0
print('H3 wild-type panel: corr(baseline log2 panel-GMT, log2 fold-rise) r = %.2f (n=%d)' % (np.corrcoef(g.l0, g.lfr)[0,1], len(g)))
