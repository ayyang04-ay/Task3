"""Shared loaders / harmonisation for the WU397 data package.
All inputs read from /tmp/world/filesystem (read-only)."""
import re, numpy as np, pandas as pd
IN = '/tmp/world/filesystem'

def pid_norm(p):
    """Harmonise participant IDs: '397-001', '001', '1', '20', '397-06' -> int 1, 20, 6"""
    m = re.search(r'(\d+)$', str(p).strip())
    return int(m.group(1))

def gm(x):
    x = pd.Series(x).dropna()
    return float(np.exp(np.mean(np.log(x)))) if len(x) else np.nan

def load_seqneut():
    d = pd.read_csv(f'{IN}/neutralization_seqbased.csv')
    s = d.serum.str.extract(r'^(?P<arm>.+?)_(?P<pid>397-\d+)_d(?P<day>\d+)$')
    d = pd.concat([d, s], axis=1)
    d['day'] = d.day.astype(int)
    d['pid'] = d.pid.map(pid_norm)
    v = d.virus.str.extract(r'^(?P<type>A)/(?P<rest>.+)_(?P<subtype>H1N1|H3N2)$')
    d['subtype'] = v.subtype
    # strain year: the 4-digit year in the name (fix the one typo '202023')
    def year(name):
        core = name.rsplit('_', 1)[0]
        core = core.replace('_IVR-238', '')
        m = re.search(r'/(\d{4,6})(egg|X-307A|X-223A|NIB-88)?$', core)
        y = m.group(1)
        if len(y) > 4:  # 'A/SOUTHAFRICA/R07876/202023' -> typo; take last 4
            y = y[-4:]
        return int(y)
    d['year'] = d.virus.map(year)
    # flagged by nomenclature only (per trial_summary.md 'Notes on the virus panels')
    d['egg_or_reassortant'] = d.virus.str.contains(r'egg|IVR-|X-307A|X-223A|NIB-88', regex=True)
    # A/Darwin/9/2021 carries no designation but is the egg-based H3N2 vaccine virus in the
    # 2022-23 NH egg-based formulation (external knowledge; Fluarix is egg-based) -> flagged separately
    d['comparator_vaccine_strain'] = d.virus.str.contains('/Darwin/9/2021')
    # censoring: 'upper' => true titer <= value (below LOD); 'lower' => true titer >= value (above ULOQ)
    d['cens'] = d.titer_bound.map({'interpolated': 'none', 'upper': 'left', 'lower': 'right'})
    return d
