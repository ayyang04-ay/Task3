# Virus-level mixed model sensitivity analysis: log2 d29 ~ arm + log2 d0 + (1|participant) + (1|virus)
suppressMessages({library(lme4)})
p <- read.csv('/tmp/outputs/analysis/seqneut_long_d0_d29.csv')
p$m <- as.integer(p$arm == 'mRNA-1010')
out <- data.frame()
for (pan in c('H3 contemporary/forward 2022-24', 'H3 historical 2012-20', 'H1 contemporary 2022-23', 'H1 historical 2009-19')) {
  s <- subset(p, panel == pan)
  s$l0c <- s$l0 - mean(s$l0)
  f <- lmer(l29 ~ m + l0c + (1|pid) + (1|virus), data = s, REML = TRUE)
  ci <- confint(f, parm = 'm', method = 'Wald')
  f0 <- lmer(l29 ~ m + (1|pid) + (1|virus), data = s, REML = TRUE)
  ci0 <- confint(f0, parm = 'm', method = 'Wald')
  vc <- as.data.frame(VarCorr(f))
  out <- rbind(out, data.frame(panel = pan, n_obs = nrow(s), n_pid = length(unique(s$pid)), n_virus = length(unique(s$virus)),
     unadj_ratio = 2^fixef(f0)['m'], unadj_lo = 2^ci0[1], unadj_hi = 2^ci0[2],
     adj_ratio = 2^fixef(f)['m'], adj_lo = 2^ci[1], adj_hi = 2^ci[2],
     sd_pid = vc$sdcor[vc$grp=='pid'], sd_virus = vc$sdcor[vc$grp=='virus'], sd_resid = vc$sdcor[vc$grp=='Residual']))
}
rownames(out) <- NULL
print(format(out, digits = 3))
write.csv(out, '/tmp/outputs/analysis/seqneut_mixed_model.csv', row.names = FALSE)
