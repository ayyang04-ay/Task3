"""MN: 33/174 titres sit at 1280 (apparent upper limit) and 8 at 10 (apparent '<20').
Censored-normal (Tobit) regression of log2 wk4 titre on arm (+/- log2 baseline) to see how much the ceiling hides."""
import importlib.util, numpy as np, pandas as pd
from scipy import optimize, stats
spec = importlib.util.spec_from_file_location('L', '/tmp/outputs/analysis/00_load.py'); L = importlib.util.module_from_spec(spec); spec.loader.exec_module(L)
mn = pd.read_csv(f'{L.IN}/microneutralization.csv'); mn = mn[mn.measure=='titer']; mn['pid'] = mn.participant.map(L.pid_norm)
print('titres at 1280:', (mn.value>=1280).sum(), 'of', len(mn), '; at 10:', (mn.value<=10).sum())
print((mn[mn.timepoint=='wk4'].assign(c=lambda x: x.value>=1280).groupby(['panel','arm']).c.agg(['sum','count'])))
def tobit(y, X, lo, hi):
    def nll(b):
        mu = X @ b[:-1]; s = np.exp(b[-1])
        ll = np.where(y >= hi, stats.norm.logsf((hi-mu)/s), np.where(y <= lo, stats.norm.logcdf((lo-mu)/s), stats.norm.logpdf((y-mu)/s) - np.log(s)))
        return -ll.sum()
    b0 = np.r_[np.linalg.lstsq(X, y, rcond=None)[0], 0.0]
    r = optimize.minimize(nll, b0, method='BFGS')
    se = np.sqrt(np.diag(r.hess_inv))
    return r.x, se
rows = []
for panel, s in mn.groupby('panel'):
    w = s.pivot_table(index=['arm','pid'], columns='timepoint', values='value').reset_index().dropna(subset=['wk0','wk4'])
    y = np.log2(w.wk4.values); m = (w.arm=='mRNA-1010').astype(float).values; l0 = np.log2(w.wk0.values)
    lo, hi = np.log2(10), np.log2(1280)
    for label, X in [('unadjusted', np.c_[np.ones_like(m), m]), ('baseline-adjusted', np.c_[np.ones_like(m), m, l0])]:
        b, se = tobit(y, X, lo, hi)
        ols = np.linalg.lstsq(X, y, rcond=None)[0]
        rows.append(dict(panel=panel, model=label, ols_ratio=2**ols[1], tobit_ratio=2**b[1], tobit_lo=2**(b[1]-1.96*se[1]), tobit_hi=2**(b[1]+1.96*se[1]), tobit_sd=np.exp(b[-1])))
r = pd.DataFrame(rows); r.to_csv('/tmp/outputs/analysis/mn_tobit.csv', index=False); print(r.round(3).to_string())
