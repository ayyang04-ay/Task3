"""Adds data-integrity and descriptive numbers to numbers_ledger.csv (computed directly from the input files)."""
import re, numpy as np, pandas as pd
IN = '/tmp/world/filesystem'; A = '/tmp/outputs/analysis'
led = pd.read_csv('/tmp/outputs/numbers_ledger.csv'); L = []
def add(key, value, source, output, note=''): L.append(dict(key=key, value=value, source_input=source, analysis_output=output, note=note))
pid = lambda p: int(re.search(r'(\d+)$', str(p)).group(1))
# cohort sizes per file
for f in ['elisa_igg_titers.csv','hai_titers.csv','microneutralization.csv','binding_breadth_h1.csv','igm_fold_change.csv','gc_frequencies.csv','plasmablast_frequencies.csv']:
    d = pd.read_csv(f'{IN}/{f}', dtype=str); n = d.groupby('arm').participant.nunique()
    add(f'participants in {f} (mRNA-1010/Fluarix)', f"{n.get('mRNA-1010',0)}/{n.get('Fluarix',0)}", f, 'direct count')
s = pd.read_csv(f'{IN}/neutralization_seqbased.csv').serum.str.extract(r'^(?P<arm>.+?)_(?P<pid>397-\d+)_d(?P<day>\d+)$')
n = s.groupby('arm').pid.nunique(); add('participants in neutralization_seqbased.csv (mRNA-1010/Fluarix)', f"{n['mRNA-1010']}/{n['Fluarix']}", 'neutralization_seqbased.csv', 'direct count')
sq = pd.read_csv(f'{IN}/neutralization_seqbased.csv')
add('seq-neut: viruses / sera / titres', f"{sq.virus.nunique()} / {sq.serum.nunique()} / {len(sq)}", 'neutralization_seqbased.csv', 'direct count')
add('seq-neut: titres censored below LOD (upper bound ~40) / above ULOQ (lower bound ~17300)', f"{(sq.titer_bound=='upper').sum()} / {(sq.titer_bound=='lower').sum()}", 'neutralization_seqbased.csv', 'direct count')
add('seq-neut: H1N1 / H3N2 viruses; egg/reassortant-designated', '13 / 83; 6 (+A/Darwin/9/2021, egg-based vaccine virus without designation)', 'neutralization_seqbased.csv', 'seqneut_virus_panel_assignment.csv')
mn = pd.read_csv(f'{IN}/microneutralization.csv'); t = mn[mn.measure=='titer']
add('MN: titres at 1280 (ceiling) / at 10 (floor) of all titres', f"{(t.value>=1280).sum()} / {(t.value<=10).sum()} of {len(t)}", 'microneutralization.csv', 'direct count')
w4 = t[(t.timepoint=='wk4')]
for p in ['homologous','heterologous']:
    x = w4[w4.panel==p].groupby('arm').value.apply(lambda v: f'{(v>=1280).sum()}/{len(v)}')
    add(f'MN {p} wk4 at 1280 ceiling (mRNA-1010; Fluarix)', f"{x['mRNA-1010']}; {x['Fluarix']}", 'microneutralization.csv', 'direct count')
c = pd.read_csv(f'{A}/mn_vs_seqneut_correlation.csv')
for p, g in c.groupby('mn_panel'):
    h3 = g[~g.seqneut_virus.str.contains('H1N1')].pearson_r_log.mean(); h1 = g[g.seqneut_virus.str.contains('H1N1')].pearson_r_log.mean()
    d9 = g[g.seqneut_virus=='A/Darwin/9/2021_H3N2'].pearson_r_log.iloc[0]; d6 = g[g.seqneut_virus=='A/Darwin/6/2021_H3N2'].pearson_r_log.iloc[0]
    top = g.sort_values('pearson_r_log', ascending=False).iloc[0]
    add(f'MN {p} vs seq-neut log-titre correlation: mean r with H3N2 / H1N1 viruses; r Darwin/9 (egg) / Darwin/6 (cell); top virus', f'{h3:.2f} / {h1:.2f}; {d9:.2f} / {d6:.2f}; {top.seqneut_virus} ({top.pearson_r_log:.2f})', 'microneutralization.csv + neutralization_seqbased.csv', 'mn_vs_seqneut_correlation.csv')
gc = pd.read_csv(f'{IN}/gc_frequencies.csv', dtype=str)
add('GC file rows sharing (timepoint, arm, participant) with another row', f"{gc.duplicated(['timepoint','arm','participant'], keep=False).sum()} of {len(gc)}", 'gc_frequencies.csv', '07_cellular.py')
add('GC file timepoints vs protocol FNA schedule', 'wk0, wk2, wk8, wk17, wk26 vs wk1, 2, 4, 8, 17, 26', 'gc_frequencies.csv + trial_summary.md', '07_cellular.py')
g = pd.read_csv(f'{IN}/gc_frequencies.csv', dtype={'participant':str}).iloc[:78]
for tp in ['wk2','wk26']:
    x = g[g.timepoint==tp].groupby('arm').pct_ha_specific_igg_gc.median()
    add(f'GC block-1 median % HA-specific at "{tp}" (mRNA-1010 vs Fluarix)', f"{x['mRNA-1010']:.1f} vs {x['Fluarix']:.1f}", 'gc_frequencies.csv (rows 1-78)', '07_cellular.py', 'block-2 rows give different values for the same keys')
pb = pd.read_csv(f'{IN}/plasmablast_frequencies.csv', dtype=str)
extra = sorted(set(pb.participant) - set(gc.participant)); add('PB file participants absent from the FNA/GC cohort', f"{len(extra)}: {', '.join(extra)}", 'plasmablast_frequencies.csv', '07_cellular.py')
ig = pd.read_csv(f'{IN}/igm_fold_change.csv', dtype=str); ig['fc'] = ig.fold_change.astype(float)
add('IgM fold-change values equal to exactly 1 (floor)', f"{(ig.fc==1).sum()} of {len(ig)}", 'igm_fold_change.csv', 'direct count')
for ag, s_ in ig.groupby('antigen'):
    x = s_.groupby('arm').fc.apply(lambda v: f'{(v>=4).sum()}/{len(v)}')
    add(f'IgM >=4-fold {ag} (mRNA-1010; Fluarix)', f"{x['mRNA-1010']}; {x['Fluarix']}", 'igm_fold_change.csv', 'direct count', 'timepoint not stated in file')
rc = pd.read_csv(f'{IN}/repertoire_clonotype_counts.csv')
for met, s_ in rc.groupby('metric'):
    x = s_.groupby('arm').value.mean(); add(f'repertoire {met} mean (mRNA-1010 vs Fluarix, n=8/8)', f"{x['mRNA-1010']:.1f} vs {x['Fluarix']:.1f}", 'repertoire_clonotype_counts.csv', '07_cellular.py')
ov = pd.read_csv(f'{IN}/pb_gc_clonal_overlap.csv')
add('GC B-cell clones per donor (mRNA-1010: 06,17,28,29 | Fluarix: 05,09,22)', ', '.join(str(v) for v in ov['Number of GC B cell clones']), 'pb_gc_clonal_overlap.csv', 'direct read')
mab = pd.read_csv(f'{IN}/mab_binding_panels.csv'); mab['donor'] = mab.mab_id.str.split('.').str[1]
x = mab.groupby(['arm','donor']).mab_id.nunique()
add('mAbs per donor', '; '.join(f'{a} {d}: {v}' for (a, d), v in x.items()), 'mab_binding_panels.csv', 'direct count')
x2 = mab[mab.panel=='group_II'].groupby(['arm','donor']).mab_id.nunique()
add('group II (H3-lineage) mAbs per donor', '; '.join(f'{a} {d}: {v}' for (a, d), v in x2.items()), 'mab_binding_panels.csv', 'direct count')
m1 = mab[(mab.panel=='group_I') & (mab.antigen!='SARS-CoV-2 RBD')].pivot_table(index=['arm','mab_id'], columns='antigen', values='fold_over_control')
b = m1.idxmax(axis=1).groupby(level='arm').value_counts()
add('group I mAbs whose strongest antigen is A/Wisconsin/588/2019 vs A/Victoria/4897/2022 (mRNA-1010; Fluarix)', f"{b[('mRNA-1010','A/Wisconsin/588/2019')]} vs {b[('mRNA-1010','A/Victoria/4897/2022')]} of 264; {b[('Fluarix','A/Wisconsin/588/2019')]} vs {b[('Fluarix','A/Victoria/4897/2022')]} of 74", 'mab_binding_panels.csv', '14_h1_antigen_identity_check.py')
med = mab[mab.antigen.isin(['A/Wisconsin/588/2019','A/Victoria/4897/2022'])].groupby(['arm','antigen']).fold_over_control.median()
add('group I median fold-over-control Wisconsin/588/2019 vs Victoria/4897/2022 (mRNA-1010; Fluarix)', f"{med[('mRNA-1010','A/Wisconsin/588/2019')]:.1f} vs {med[('mRNA-1010','A/Victoria/4897/2022')]:.1f}; {med[('Fluarix','A/Wisconsin/588/2019')]:.1f} vs {med[('Fluarix','A/Victoria/4897/2022')]:.1f}", 'mab_binding_panels.csv', '14_h1_antigen_identity_check.py')
# visit-label inconsistencies
add('participants whose late-visit label (wk17 vs wk26) differs between assay files', '9 (IDs 7, 8, 9, 10, 11, 16, 18, 21, 23); HAI B/Vic disagrees with all other assays for 8, seq-neut for 2 (7, 11)', 'hai_titers.csv, elisa_igg_titers.csv, microneutralization.csv, neutralization_seqbased.csv', 'inline check (see answer.md section 4)')
eb = pd.read_csv(f'{A}/enrolment_block_check.csv')
for ag in ['B/Vic','B/Yam']:
    r = eb[(eb.antigen==ag) & (eb.arm=='Fluarix')].iloc[0]
    add(f'Fluarix arm ELISA {ag} baseline GMT: interleaved IDs 1-32 vs block IDs 33-59', f'{r.GMT0_inter:.0f} vs {r.GMT0_block:.0f} (p={r.p0:.3f})', 'elisa_igg_titers.csv', 'enrolment_block_check.csv')
add('ID structure', 'IDs 1-32 interleave arms (15 Fluarix, 14 mRNA-1010) and are the whole functional-assay cohort; IDs 33-59 Fluarix only (22), 64-102 mRNA-1010 only (24)', 'elisa_igg_titers.csv', '13_enrolment_structure.py')
out = pd.concat([led, pd.DataFrame(L)], ignore_index=True); out.to_csv('/tmp/outputs/numbers_ledger.csv', index=False)
pd.set_option('display.width', 250); pd.set_option('display.max_colwidth', 170); pd.set_option('display.max_rows', 400)
print(pd.DataFrame(L)[['key','value']].to_string())
