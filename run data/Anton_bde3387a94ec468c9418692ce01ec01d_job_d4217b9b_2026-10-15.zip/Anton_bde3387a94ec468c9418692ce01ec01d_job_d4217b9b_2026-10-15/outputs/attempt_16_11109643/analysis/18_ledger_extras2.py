import numpy as np, pandas as pd, importlib.util
from scipy import stats
IN = '/tmp/world/filesystem'; A = '/tmp/outputs/analysis'
spec = importlib.util.spec_from_file_location('L', f'{A}/00_load.py'); Lm = importlib.util.module_from_spec(spec); spec.loader.exec_module(Lm)
led = pd.read_csv('/tmp/outputs/numbers_ledger.csv'); L = []
def add(key, value, source, output, note=''): L.append(dict(key=key, value=value, source_input=source, analysis_output=output, note=note))
# baseline vs fold-rise correlation, H3 wild-type non-vaccine panel
d = Lm.load_seqneut(); d['l2'] = np.log2(np.where(d.cens=='left', 20, d.titer))
h3 = d[(d.subtype=='H3N2') & ~d.egg_or_reassortant & ~d.virus.str.contains('Darwin') & d.day.isin([0,29])]
p = h3.pivot_table(index=['arm','pid','virus'], columns='day', values='l2').dropna().reset_index()
g = p.groupby(['arm','pid']).agg(l0=(0,'mean'), l29=(29,'mean')).reset_index()
add('H3 wild-type panel: correlation of participant baseline log2 panel-GMT with log2 fold-rise', f'r = {np.corrcoef(g.l0, g.l29-g.l0)[0,1]:.2f} (n={len(g)})', 'neutralization_seqbased.csv', '09_seqneut_distant_subsets.py')
# bead-array participant-level
for sub, f in [('H1','binding_breadth_h1.csv'), ('H3','binding_breadth_h3.csv')]:
    b = pd.read_csv(f'{IN}/{f}'); q = b.groupby(['arm','participant']).log2_fold_change_mfi.mean().reset_index()
    m = q[q.arm=='mRNA-1010'].log2_fold_change_mfi; fl = q[q.arm=='Fluarix'].log2_fold_change_mfi
    add(f'bead-array {sub} participant-mean log2FC mRNA vs Fluarix (MWU p)', f'{m.mean():.2f} vs {fl.mean():.2f} (p={stats.mannwhitneyu(m, fl).pvalue:.2g}); n={len(m)}/{len(fl)}', f, '05_binding_vs_function.py', 'timepoint of fold-change not stated in file')
# GC block-1 wk2 test
gc = pd.read_csv(f'{IN}/gc_frequencies.csv', dtype={'participant':str}).iloc[:78]
x = gc[gc.timepoint=='wk2']; m = x[x.arm=='mRNA-1010'].pct_ha_specific_igg_gc; fl = x[x.arm=='Fluarix'].pct_ha_specific_igg_gc
add('GC block-1 "wk2" MWU p (n)', f'p={stats.mannwhitneyu(m, fl).pvalue:.3f} (n={len(m)}/{len(fl)})', 'gc_frequencies.csv', '07_cellular.py')
# ELISA cohort timepoints
el = pd.read_csv(f'{IN}/elisa_igg_titers.csv'); late = el[el.timepoint.isin(['wk17','wk26'])].drop_duplicates(['participant','timepoint']).groupby(['timepoint','arm']).size()
add('ELISA late visit: participants sampled at wk17 vs wk26 (mRNA-1010; Fluarix)', f"wk17 {late[('wk17','mRNA-1010')]}, wk26 {late[('wk26','mRNA-1010')]}; wk17 {late[('wk17','Fluarix')]}, wk26 {late[('wk26','Fluarix')]}", 'elisa_igg_titers.csv', 'direct count', 'pooled as wk17/26 in fold-change rows')
# summary cohort table vs files
add('trial_summary.md assay-cohort table: ELISA/IgM 38/37; HAI 14/15; bead-array & MN 14/15; seq-neut 13/14; FNA 6/11', 'IgM file actually 14/15; PB file 13/15 (not listed)', 'trial_summary.md + files', 'direct count')
out = pd.concat([led, pd.DataFrame(L)], ignore_index=True); out.to_csv('/tmp/outputs/numbers_ledger.csv', index=False)
pd.set_option('display.width', 250); pd.set_option('display.max_colwidth', 170)
print(pd.DataFrame(L)[['key','value']].to_string()); print(len(out), 'total ledger entries')
