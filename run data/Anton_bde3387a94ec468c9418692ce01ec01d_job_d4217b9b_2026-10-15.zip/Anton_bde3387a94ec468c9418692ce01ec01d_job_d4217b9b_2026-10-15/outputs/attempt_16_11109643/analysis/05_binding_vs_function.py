"""Bead-array binding breadth (log2 fold-change MFI; timepoint not stated in file) at participant level,
and whether binding breadth tracks functional (neutralising) breadth in the same participants."""
import importlib.util, numpy as np, pandas as pd
import statsmodels.formula.api as smf
from scipy import stats
spec = importlib.util.spec_from_file_location('L', '/tmp/outputs/analysis/00_load.py'); L = importlib.util.module_from_spec(spec); spec.loader.exec_module(L)
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 300)
rows = []; part = []
for sub, f in [('H1', 'binding_breadth_h1.csv'), ('H3', 'binding_breadth_h3.csv')]:
    b = pd.read_csv(f'{L.IN}/{f}'); b['pid'] = b.participant.map(L.pid_norm)
    for st, s in b.groupby('strain'):
        m = s[s.arm=='mRNA-1010'].log2_fold_change_mfi; fl = s[s.arm=='Fluarix'].log2_fold_change_mfi
        rows.append(dict(subtype=sub, strain=st, mean_log2fc_m=m.mean(), mean_log2fc_f=fl.mean(), diff=m.mean()-fl.mean(),
                         ratio_fold=2**(m.mean()-fl.mean()), p_mwu=stats.mannwhitneyu(m, fl).pvalue,
                         sd_m=m.std(), sd_f=fl.std()))
    g = b.groupby(['arm','pid']).log2_fold_change_mfi.mean().rename(f'bind_breadth_{sub}').reset_index()
    part.append(g)
r = pd.DataFrame(rows); r.to_csv('/tmp/outputs/analysis/binding_breadth_per_strain.csv', index=False)
print(r.round(3).to_string())
P = part[0].merge(part[1], on=['arm','pid'])
for sub in ['H1','H3']:
    m = P[P.arm=='mRNA-1010'][f'bind_breadth_{sub}']; f = P[P.arm=='Fluarix'][f'bind_breadth_{sub}']
    print(sub, 'participant-mean log2FC: mRNA %.2f (sd %.2f, n=%d) vs Fluarix %.2f (sd %.2f, n=%d); MWU p=%.2g' % (m.mean(), m.std(), len(m), f.mean(), f.std(), len(f), stats.mannwhitneyu(m, f).pvalue))
# functional breadth from seq-neut participant files (d29/d0 mean log2 fold-rise over panel)
h1 = pd.read_csv('/tmp/outputs/analysis/seqneut_participant_H1_contemporary_2022-23.csv')
h3 = pd.read_csv('/tmp/outputs/analysis/seqneut_participant_H3_contemporary-forward_2022-24.csv')
h1['neut_lfr_H1'] = h1.l29 - h1.l0; h3['neut_lfr_H3'] = h3.l29 - h3.l0
Q = P.merge(h1[['pid','neut_lfr_H1','l29']].rename(columns={'l29':'neut_l29_H1'}), on='pid').merge(h3[['pid','neut_lfr_H3','l29']].rename(columns={'l29':'neut_l29_H3'}), on='pid')
Q.to_csv('/tmp/outputs/analysis/binding_vs_neut_participant.csv', index=False)
for sub in ['H1','H3']:
    rho, p = stats.spearmanr(Q[f'bind_breadth_{sub}'], Q[f'neut_lfr_{sub}'])
    print(f'{sub}: Spearman(binding breadth log2FC, neut fold-rise on contemporary panel) all n={len(Q)} rho={rho:.2f} p={p:.2g}')
    for arm, s in Q.groupby('arm'):
        rho, p = stats.spearmanr(s[f'bind_breadth_{sub}'], s[f'neut_lfr_{sub}'])
        print(f'   {arm}: n={len(s)} rho={rho:.2f} p={p:.2g}')
    # the key contrast: arm difference in binding vs arm difference in neutralisation (same people)
    bm = Q[Q.arm=='mRNA-1010'][f'bind_breadth_{sub}'].mean()-Q[Q.arm=='Fluarix'][f'bind_breadth_{sub}'].mean()
    nm = Q[Q.arm=='mRNA-1010'][f'neut_lfr_{sub}'].mean()-Q[Q.arm=='Fluarix'][f'neut_lfr_{sub}'].mean()
    print(f'   same participants: arm diff binding log2FC = {bm:.2f} (x{2**bm:.1f}); arm diff neut log2 fold-rise = {nm:.2f} (x{2**nm:.1f})')
