"""Sequencing-based neutralisation: per-virus arm comparison of d0, d29 titres and d29/d0 fold-rise.
Censoring: 'upper' bound (<=40, below LOD) imputed at LOD/2 = 20 for point estimates (sensitivity: at 40);
'lower' bound (>= 17300, above ULOQ) kept at the bound (so rises are under-estimated -> flagged)."""
import importlib.util, numpy as np, pandas as pd
from scipy import stats
spec = importlib.util.spec_from_file_location('L', '/tmp/outputs/analysis/00_load.py'); L = importlib.util.module_from_spec(spec); spec.loader.exec_module(L)
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 300)
d = L.load_seqneut()
d['t_imp'] = np.where(d.cens == 'left', d.titer / 2, d.titer)
w = d.pivot_table(index=['virus', 'subtype', 'year', 'egg_or_reassortant', 'comparator_vaccine_strain', 'arm', 'pid'], columns='day', values='t_imp').reset_index()
w['fc29'] = w[29] / w[0]
rows = []
for (v, st, yr, egg, cvs), s in w.groupby(['virus', 'subtype', 'year', 'egg_or_reassortant', 'comparator_vaccine_strain']):
    m = s[(s.arm == 'mRNA-1010')].dropna(subset=[0, 29]); f = s[(s.arm == 'Fluarix')].dropna(subset=[0, 29])
    r = dict(virus=v, subtype=st, year=yr, egg=egg, cvs=cvs, n_m=len(m), n_f=len(f),
             GMT0_m=L.gm(m[0]), GMT0_f=L.gm(f[0]), GMT29_m=L.gm(m[29]), GMT29_f=L.gm(f[29]),
             GMFR_m=L.gm(m.fc29), GMFR_f=L.gm(f.fc29),
             p4_m=(m.fc29 >= 4).mean(), p4_f=(f.fc29 >= 4).mean())
    r['GMFR_ratio'] = r['GMFR_m'] / r['GMFR_f']
    r['GMT29_ratio'] = r['GMT29_m'] / r['GMT29_f']
    r['p_fc'] = stats.mannwhitneyu(np.log(m.fc29), np.log(f.fc29)).pvalue
    r['p_gmt29'] = stats.mannwhitneyu(np.log(m[29]), np.log(f[29])).pvalue
    r['p_gmt0'] = stats.mannwhitneyu(np.log(m[0]), np.log(f[0])).pvalue
    rows.append(r)
r = pd.DataFrame(rows).sort_values(['subtype', 'year', 'virus'])
r.to_csv('/tmp/outputs/analysis/seqneut_per_virus.csv', index=False)
print(r.round(3).to_string())
