"""Which virus (if any) do the microneutralisation 'homologous'/'heterologous' panels track?
Correlate MN log titres with seq-neut log titres (same participant, wk0<->d0, wk4<->d29)."""
import importlib.util, numpy as np, pandas as pd
spec = importlib.util.spec_from_file_location('L', '/tmp/outputs/analysis/00_load.py'); L = importlib.util.module_from_spec(spec); spec.loader.exec_module(L)
pd.set_option('display.width', 250)
d = L.load_seqneut(); d['t'] = np.where(d.cens=='left', 20, d.titer)
sn = d[d.day.isin([0,29])].assign(tp=lambda x: x.day.map({0:'wk0',29:'wk4'}))[['pid','tp','virus','t']]
mn = pd.read_csv(f'{L.IN}/microneutralization.csv'); mn = mn[(mn.measure=='titer') & mn.timepoint.isin(['wk0','wk4'])]
mn['pid'] = mn.participant.map(L.pid_norm)
res = []
for panel, m in mn.groupby('panel'):
    j = m.merge(sn, left_on=['pid','timepoint'], right_on=['pid','tp'])
    for v, s in j.groupby('virus'):
        if len(s) > 20:
            res.append((panel, v, len(s), np.corrcoef(np.log(s.value), np.log(s.t))[0,1]))
r = pd.DataFrame(res, columns=['mn_panel','seqneut_virus','n_pairs','pearson_r_log']).sort_values(['mn_panel','pearson_r_log'], ascending=[True, False])
r.to_csv('/tmp/outputs/analysis/mn_vs_seqneut_correlation.csv', index=False)
for p, s in r.groupby('mn_panel'):
    print(p); print(s.head(8).round(3).to_string(index=False)); print('...'); print(s.tail(3).round(3).to_string(index=False))

# --- fold-rise correlation (more strain-specific than raw titre correlation)
snw = sn.pivot_table(index=['pid','virus'], columns='tp', values='t').dropna().reset_index()
snw['lfc'] = np.log2(snw.wk4/snw.wk0)
mnw = mn.pivot_table(index=['pid','panel'], columns='timepoint', values='value').reset_index()
mnw['lfc_mn'] = np.log2(mnw.wk4/mnw.wk0)
# exclude MN pairs where either timepoint is at the 1280 ceiling (fold-rise uninformative)
mnw['ceiling'] = (mnw.wk0 >= 1280) | (mnw.wk4 >= 1280)
res = []
for panel, m in mnw[~mnw.ceiling].groupby('panel'):
    j = m.merge(snw, on='pid')
    for v, s in j.groupby('virus'):
        if len(s) >= 12:
            res.append((panel, v, len(s), np.corrcoef(s.lfc_mn, s.lfc)[0,1]))
r2 = pd.DataFrame(res, columns=['mn_panel','seqneut_virus','n_participants','pearson_r_log2foldrise']).sort_values(['mn_panel','pearson_r_log2foldrise'], ascending=[True,False])
r2.to_csv('/tmp/outputs/analysis/mn_vs_seqneut_foldrise_correlation.csv', index=False)
for p, s in r2.groupby('mn_panel'):
    s = s.reset_index(drop=True); s['rank'] = s.index+1
    print('FOLD-RISE', p); print(s.head(6).round(3).to_string(index=False))
    print(s[s.seqneut_virus.str.contains('Darwin')].round(3).to_string(index=False))
