"""Durability in seq-neut, day 181 only (day 121 participants analysed separately, not pooled)."""
import importlib.util, numpy as np, pandas as pd
import statsmodels.formula.api as smf
spec = importlib.util.spec_from_file_location('L', '/tmp/outputs/analysis/00_load.py'); L = importlib.util.module_from_spec(spec); spec.loader.exec_module(L)
pd.set_option('display.width', 250)
d = L.load_seqneut(); d['l2'] = np.log2(np.where(d.cens=='left', 20, d.titer))
a = pd.read_csv('/tmp/outputs/analysis/seqneut_virus_panel_assignment.csv')[['virus','panel']]
d = d.merge(a, on='virus')
rows = []
for panel in ['H1 contemporary 2022-23','H3 contemporary/forward 2022-24','H3 historical 2012-20','H1 historical 2009-19']:
    s = d[d.panel==panel]
    p = s.pivot_table(index=['arm','pid','virus'], columns='day', values='l2').reset_index()
    g = p.groupby(['arm','pid']).agg(l0=(0,'mean'), l29=(29,'mean'), l121=(121,'mean'), l181=(181,'mean')).reset_index()
    g['m'] = (g.arm=='mRNA-1010').astype(int)
    gg = g.dropna(subset=['l181'])
    f = smf.ols('l181 ~ m + l0', gg).fit()
    rows.append(dict(panel=panel, n_m=int(gg.m.sum()), n_f=int((1-gg.m).sum()), GMT181_m=2**gg[gg.m==1].l181.mean(), GMT181_f=2**gg[gg.m==0].l181.mean(),
                     GMFR181_m=2**(gg[gg.m==1].l181-gg[gg.m==1].l0).mean(), GMFR181_f=2**(gg[gg.m==0].l181-gg[gg.m==0].l0).mean(),
                     adj_ratio181=2**f.params.m, lo=2**f.conf_int().loc['m',0], hi=2**f.conf_int().loc['m',1],
                     n121_m=int(g[g.m==1].l121.notna().sum()), n121_f=int(g[g.m==0].l121.notna().sum())))
r = pd.DataFrame(rows); r.to_csv('/tmp/outputs/analysis/seqneut_d181.csv', index=False); print(r.round(2).to_string())
