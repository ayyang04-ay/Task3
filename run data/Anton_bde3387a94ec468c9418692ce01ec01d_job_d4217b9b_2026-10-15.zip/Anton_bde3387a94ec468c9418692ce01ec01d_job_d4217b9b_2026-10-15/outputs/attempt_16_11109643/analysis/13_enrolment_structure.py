"""Allocation was by enrolment site (non-randomised). Participant numbering shows the structure:
IDs 1-32 interleave both arms (odd/even-ish), Fluarix-only block 33-59, mRNA-1010-only block 64-102.
Check whether the ELISA baseline and response differ between the interleaved and block enrolees within each arm."""
import importlib.util, numpy as np, pandas as pd
from scipy import stats
spec = importlib.util.spec_from_file_location('L', '/tmp/outputs/analysis/00_load.py'); L = importlib.util.module_from_spec(spec); spec.loader.exec_module(L)
pd.set_option('display.width', 250)
el = pd.read_csv(f'{L.IN}/elisa_igg_titers.csv')
ids = el[['arm','participant']].drop_duplicates()
print(ids.groupby('arm').participant.agg(['min','max','count']))
print('IDs <=32 by arm:', ids[ids.participant<=32].groupby('arm').size().to_dict(), '| IDs >32 by arm:', ids[ids.participant>32].groupby('arm').size().to_dict())
e = el[el.measure=='ec50'].pivot_table(index=['antigen','arm','participant'], columns='timepoint', values='value').reset_index()
e['block'] = np.where(e.participant <= 32, 'interleaved 1-32', 'block >32')
rows = []
for (ag, arm), s in e.groupby(['antigen','arm']):
    a = s[s.block=='interleaved 1-32']; b = s[s.block=='block >32']
    rows.append(dict(antigen=ag, arm=arm, n_inter=len(a), n_block=len(b), GMT0_inter=L.gm(a.wk0), GMT0_block=L.gm(b.wk0), p0=stats.mannwhitneyu(np.log(a.wk0), np.log(b.wk0)).pvalue,
                     GMFR4_inter=L.gm(a.wk4/a.wk0), GMFR4_block=L.gm(b.wk4/b.wk0), p_fr=stats.mannwhitneyu(np.log(a.wk4/a.wk0), np.log(b.wk4/b.wk0)).pvalue))
r = pd.DataFrame(rows); r.to_csv('/tmp/outputs/analysis/enrolment_block_check.csv', index=False); print(r.round(3).to_string())
# arm comparison restricted to the interleaved IDs (closest thing to concurrent enrolment)
rows = []
for ag, s in e[e.block=='interleaved 1-32'].groupby('antigen'):
    m = s[s.arm=='mRNA-1010']; f = s[s.arm=='Fluarix']
    rows.append(dict(antigen=ag, n_m=len(m), n_f=len(f), GMT4_ratio=L.gm(m.wk4)/L.gm(f.wk4), GMFR_m=L.gm(m.wk4/m.wk0), GMFR_f=L.gm(f.wk4/f.wk0)))
print(pd.DataFrame(rows).round(2).to_string())
