"""Lymph-node GC, plasmablast, clonal-overlap, repertoire and IgM files: descriptive only, with integrity checks."""
import numpy as np, pandas as pd
from scipy import stats
IN='/tmp/world/filesystem'
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 300)
gc = pd.read_csv(f'{IN}/gc_frequencies.csv', dtype={'participant':str})
gc['block'] = np.where(np.arange(len(gc)) < len(gc)//2, 'block1(rows 1-78)', 'block2(rows 79-156)')
dup = gc.duplicated(['timepoint','arm','participant'], keep=False)
print('GC rows', len(gc), '; rows sharing (timepoint,arm,participant) with another row:', dup.sum())
print('GC timepoints in file:', sorted(gc.timepoint.unique()), ' | protocol FNA schedule: wk1,2,4,8,17,26')
print('GC participants per arm:', gc.groupby('arm').participant.nunique().to_dict())
s = gc.groupby(['block','timepoint','arm']).pct_ha_specific_igg_gc.agg(['count','median','mean']).unstack('arm')
print(s.round(2).to_string())
# per block, per timepoint MWU
for (b, tp), x in gc.groupby(['block','timepoint']):
    m = x[x.arm=='mRNA-1010'].pct_ha_specific_igg_gc; f = x[x.arm=='Fluarix'].pct_ha_specific_igg_gc
    print(b, tp, 'MWU p=%.3f' % stats.mannwhitneyu(m, f).pvalue, 'n=%d/%d' % (len(m), len(f)))
pb = pd.read_csv(f'{IN}/plasmablast_frequencies.csv', dtype={'participant':str})
print('PB timepoints in file:', sorted(pb.timepoint.unique()), ' | protocol blood schedule: d0, d7(wk1), d29(wk4), d121(wk17), d181(wk26)')
print('PB participants per arm:', pb.groupby('arm').participant.nunique().to_dict())
print('PB participants not in GC/FNA file:', sorted(set(pb.participant) - set(gc.participant)))
print(pb.groupby(['timepoint','arm']).pct_plasmablast.agg(['count','median','mean']).unstack('arm').round(3).to_string())
ov = pd.read_csv(f'{IN}/pb_gc_clonal_overlap.csv')
print(ov.to_string())
# repertoire
rc = pd.read_csv(f'{IN}/repertoire_clonotype_counts.csv')
for met, s in rc.groupby('metric'):
    m = s[s.arm=='mRNA-1010'].value; f = s[s.arm=='Fluarix'].value
    print(met, 'mRNA mean %.1f median %.1f (n=%d) | Fluarix mean %.1f median %.1f (n=%d) | MWU p=%.3f' % (m.mean(), m.median(), len(m), f.mean(), f.median(), len(f), stats.mannwhitneyu(m, f).pvalue))
ig = pd.read_csv(f'{IN}/igm_fold_change.csv', dtype={'participant':str})
print('IgM participant ids not zero-padded:', sorted(set(p for p in ig.participant if len(p) < 3)))
ig['resp'] = ig.fold_change >= 4
print(ig.groupby(['antigen','arm']).agg(n=('fold_change','size'), n_fc_eq_1=('fold_change', lambda x: (x==1).sum()), n_ge4=('resp','sum'), median=('fold_change','median')).unstack('arm').to_string())
print('IgM fold-change values are multiples of 40/27:', np.allclose((ig.fold_change*27/40) - np.round(ig.fold_change*27/40), 0, atol=1e-3))
