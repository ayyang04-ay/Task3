"""Monoclonal antibody panels: mAb-level vs donor-level comparison.
mAbs are clustered within donors (Fluarix donor 05 supplies 84/106 Fluarix mAbs), so the donor is the unit of inference.
Binding call: fold_over_control >= 5 (sensitivity at 3 and 10). SARS-CoV-2 RBD is the normaliser (=1 for all) and is dropped."""
import itertools, numpy as np, pandas as pd
from scipy import stats
IN='/tmp/world/filesystem'
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 300)
d = pd.read_csv(f'{IN}/mab_binding_panels.csv')
d['donor'] = d.mab_id.str.split('.').str[1]
d = d[d.antigen != 'SARS-CoV-2 RBD']
cnt = d.groupby(['arm','donor']).mab_id.nunique()
print('mAbs per donor:'); print(cnt.to_string()); print(cnt.groupby('arm').sum())
def exact_perm_p(a, b):
    """two-sided exact permutation test on difference in means (donor-level)."""
    a, b = np.asarray(a, float), np.asarray(b, float); pooled = np.r_[a, b]; obs = a.mean()-b.mean(); n = len(a)
    diffs = []
    for idx in itertools.combinations(range(len(pooled)), n):
        m = np.zeros(len(pooled), bool); m[list(idx)] = True
        diffs.append(pooled[m].mean()-pooled[~m].mean())
    diffs = np.array(diffs)
    return np.mean(np.abs(diffs) >= abs(obs)-1e-12), len(diffs)
rows = []
for thr in [3, 5, 10]:
    d['bind'] = d.fold_over_control >= thr
    for (panel, ag), s in d.groupby(['panel','antigen']):
        # mAb-level (naive) Fisher test
        tab = s.groupby('arm').bind.agg(['sum','count'])
        a = [[tab.loc['mRNA-1010','sum'], tab.loc['mRNA-1010','count']-tab.loc['mRNA-1010','sum']],
             [tab.loc['Fluarix','sum'], tab.loc['Fluarix','count']-tab.loc['Fluarix','sum']]]
        p_naive = stats.fisher_exact(a).pvalue
        dl = s.groupby(['arm','donor']).bind.mean()
        pm, nperm = exact_perm_p(dl['mRNA-1010'].values, dl['Fluarix'].values)
        rows.append(dict(threshold=thr, panel=panel, antigen=ag,
                         mab_frac_m=tab.loc['mRNA-1010','sum']/tab.loc['mRNA-1010','count'], mab_frac_f=tab.loc['Fluarix','sum']/tab.loc['Fluarix','count'],
                         n_mab_m=int(tab.loc['mRNA-1010','count']), n_mab_f=int(tab.loc['Fluarix','count']), p_naive_mab_level=p_naive,
                         donor_fracs_m=', '.join(f'{k}:{v:.2f}' for k, v in dl['mRNA-1010'].items()),
                         donor_fracs_f=', '.join(f'{k}:{v:.2f}' for k, v in dl['Fluarix'].items()),
                         donor_mean_m=dl['mRNA-1010'].mean(), donor_mean_f=dl['Fluarix'].mean(), p_exact_donor_level=pm, n_permutations=nperm))
r = pd.DataFrame(rows); r.to_csv('/tmp/outputs/analysis/mab_donor_level.csv', index=False)
print(r[r.threshold==5].drop(columns=['threshold','n_permutations']).round(3).to_string())
# per-mAb breadth: number of non-vaccine antigens bound in its panel
d['bind'] = d.fold_over_control >= 5
br = d.groupby(['panel','arm','donor','mab_id']).bind.sum().reset_index()
print(br.groupby(['panel','arm','donor']).bind.mean().unstack('panel').round(2))
print('smallest achievable two-sided exact p with 4 vs 3 donors = 1/35 =', round(1/35,3))
