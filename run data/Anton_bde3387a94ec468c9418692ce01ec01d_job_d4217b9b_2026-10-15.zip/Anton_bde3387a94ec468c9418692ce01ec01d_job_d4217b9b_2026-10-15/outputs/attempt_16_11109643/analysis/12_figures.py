import numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
r = pd.read_csv('/tmp/outputs/analysis/seqneut_per_virus.csv')
a = pd.read_csv('/tmp/outputs/analysis/seqneut_virus_panel_assignment.csv')[['virus','panel']]
r = r.merge(a, on='virus')
order = ['H1 historical 2009-19','H1 contemporary 2022-23','H3 historical 2012-20','H3 mRNA-1010 vaccine strain (Darwin/6/2021, cell)','H3 Fluarix vaccine strain (Darwin/9/2021, egg)','H3 contemporary/forward 2022-24','egg/reassortant (excluded)']
fig, axes = plt.subplots(1, 2, figsize=(13, 6.5), sharey=True)
for ax, col, title in [(axes[0], 'GMT29_ratio', 'Day-29 GMT ratio (mRNA-1010 / Fluarix)'), (axes[1], 'GMFR_ratio', 'Fold-rise ratio d29/d0 (mRNA-1010 / Fluarix)')]:
    for i, p in enumerate(order):
        s = r[r.panel == p]
        ax.scatter(np.log2(s[col]), np.full(len(s), i) + np.random.default_rng(1).uniform(-0.25, 0.25, len(s)), s=14, alpha=0.7)
        ax.plot([np.log2(np.exp(np.mean(np.log(s[col]))))]*2, [i-0.35, i+0.35], 'k-', lw=2)
    ax.axvline(0, color='grey', ls='--'); ax.set_title(title, fontsize=10)
    ax.set_xticks(np.log2([0.25, 0.5, 1, 2, 4])); ax.set_xticklabels(['0.25', '0.5', '1', '2', '4'])
axes[0].set_yticks(range(len(order))); axes[0].set_yticklabels([f"{p} (n={len(r[r.panel==p])})" for p in order], fontsize=8)
fig.suptitle('Sequencing-based neutralisation, per virus (each dot = one virus; bar = geometric mean across viruses)\n'
             'H3 fold-rise advantage disappears at the titre level: the mRNA-1010 arm started lower (baseline imbalance)', fontsize=10)
plt.tight_layout(); plt.savefig('/tmp/outputs/fig1_seqneut_per_virus.png', dpi=150)

Q = pd.read_csv('/tmp/outputs/analysis/binding_vs_neut_participant.csv')
fig, ax = plt.subplots(figsize=(6.5, 4.5))
vals = []
for sub in ['H1', 'H3']:
    b = Q[Q.arm=='mRNA-1010'][f'bind_breadth_{sub}'].mean()-Q[Q.arm=='Fluarix'][f'bind_breadth_{sub}'].mean()
    n = Q[Q.arm=='mRNA-1010'][f'neut_lfr_{sub}'].mean()-Q[Q.arm=='Fluarix'][f'neut_lfr_{sub}'].mean()
    t = Q[Q.arm=='mRNA-1010'][f'neut_l29_{sub}'].mean()-Q[Q.arm=='Fluarix'][f'neut_l29_{sub}'].mean()
    vals.append((sub, 2**b, 2**n, 2**t))
x = np.arange(2); w = 0.27
ax.bar(x-w, [v[1] for v in vals], w, label='binding breadth (bead array, mean log2FC)')
ax.bar(x, [v[2] for v in vals], w, label='neutralisation fold-rise (contemporary panel)')
ax.bar(x+w, [v[3] for v in vals], w, label='neutralisation d29 titre (contemporary panel)')
for i, v in enumerate(vals):
    for j, val in enumerate(v[1:]):
        ax.text(i+(j-1)*w, val+0.1, f'{val:.1f}x', ha='center', fontsize=8)
ax.axhline(1, color='grey', ls='--'); ax.set_xticks(x); ax.set_xticklabels(['H1', 'H3']); ax.set_ylabel('mRNA-1010 : Fluarix (same 27 participants)')
ax.set_title('Binding advantage does not translate into neutralising titre for H3', fontsize=10); ax.legend(fontsize=7)
plt.tight_layout(); plt.savefig('/tmp/outputs/fig2_binding_vs_neutralisation.png', dpi=150)
print(vals)
