"""HAI, MN and ELISA: participant-level GMT / GMFR / seroconversion with CIs, baseline-adjusted GMT ratios (ANCOVA on log2),
and the regulatory-style immunobridging quantities (GMT ratio, SCR difference) that a pivotal study would use.
Late visits (wk17 and wk26) are NOT pooled here: wk26 only is used for durability (wk17 n is tiny)."""
import importlib.util, numpy as np, pandas as pd
import statsmodels.formula.api as smf
from scipy import stats
spec = importlib.util.spec_from_file_location('L', '/tmp/outputs/analysis/00_load.py'); L = importlib.util.module_from_spec(spec); spec.loader.exec_module(L)
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 300)

def newcombe_diff(x1, n1, x2, n2, z=1.96):
    """Newcombe hybrid score CI for p1-p2 (Wilson intervals)."""
    def wilson(x, n):
        p = x/n; den = 1+z*z/n; c = (p + z*z/(2*n))/den; h = z*np.sqrt(p*(1-p)/n + z*z/(4*n*n))/den
        return c-h, c+h
    p1, p2 = x1/n1, x2/n2; l1, u1 = wilson(x1, n1); l2, u2 = wilson(x2, n2)
    d = p1-p2
    return d, d - np.sqrt((p1-l1)**2 + (u2-p2)**2), d + np.sqrt((u1-p1)**2 + (p2-l2)**2)

rows = []
def analyse(assay, key, df, post, value='value'):
    for k, s in df.groupby(key):
        w = s.pivot_table(index=['arm','pid'], columns='timepoint', values=value).reset_index()
        w = w.dropna(subset=['wk0', post])
        w['l0'] = np.log2(w.wk0); w['lp'] = np.log2(w[post]); w['m'] = (w.arm=='mRNA-1010').astype(int)
        w['sc'] = (w.lp - w.l0) >= 1.9   # 4-fold rise; tolerance because reported titres are rounded (e.g. 57->226 is 40*sqrt2 -> 160*sqrt2)
        m, f = w[w.m==1], w[w.m==0]
        fit = smf.ols('lp ~ m + l0', data=w).fit(); un = smf.ols('lp ~ m', data=w).fit(); fr = smf.ols('I(lp-l0) ~ m', data=w).fit()
        dsc, dlo, dhi = newcombe_diff(m.sc.sum(), len(m), f.sc.sum(), len(f))
        rows.append(dict(assay=assay, antigen=k, post=post, n_m=len(m), n_f=len(f),
            GMT0_m=2**m.l0.mean(), GMT0_f=2**f.l0.mean(), GMTpost_m=2**m.lp.mean(), GMTpost_f=2**f.lp.mean(),
            GMT_ratio=2**un.params.m, GMT_ratio_lo=2**un.conf_int().loc['m',0], GMT_ratio_hi=2**un.conf_int().loc['m',1],
            adj_ratio=2**fit.params.m, adj_lo=2**fit.conf_int().loc['m',0], adj_hi=2**fit.conf_int().loc['m',1], adj_p=fit.pvalues.m,
            GMFR_m=2**(m.lp-m.l0).mean(), GMFR_f=2**(f.lp-f.l0).mean(), GMFR_ratio=2**fr.params.m, GMFR_p=fr.pvalues.m,
            SC_m=f'{m.sc.sum()}/{len(m)}', SC_f=f'{f.sc.sum()}/{len(f)}', SC_diff=dsc, SC_diff_lo=dlo, SC_diff_hi=dhi,
            sd_lpost=w.lp.std(), resid_sd=np.sqrt(fit.scale), r_pre_post=np.corrcoef(w.l0, w.lp)[0,1]))

hai = pd.read_csv(f'{L.IN}/hai_titers.csv', dtype={'participant':str}); hai['pid'] = hai.participant.map(L.pid_norm)
analyse('HAI', 'antigen', hai, 'wk4', 'hai_titer'); analyse('HAI', 'antigen', hai, 'wk26', 'hai_titer')
mn = pd.read_csv(f'{L.IN}/microneutralization.csv'); mn = mn[mn.measure=='titer']; mn['pid'] = mn.participant.map(L.pid_norm)
analyse('MN (ceiling 1280 not modelled)', 'panel', mn, 'wk4'); analyse('MN (ceiling 1280 not modelled)', 'panel', mn, 'wk26')
el = pd.read_csv(f'{L.IN}/elisa_igg_titers.csv'); el = el[el.measure=='ec50']; el['pid'] = el.participant.map(L.pid_norm)
analyse('ELISA IgG EC50', 'antigen', el, 'wk4'); analyse('ELISA IgG EC50', 'antigen', el, 'wk26')
r = pd.DataFrame(rows)
r.to_csv('/tmp/outputs/analysis/serology_ancova.csv', index=False)
cols = ['assay','antigen','post','n_m','n_f','GMT0_m','GMT0_f','GMTpost_m','GMTpost_f','GMT_ratio','GMT_ratio_lo','GMT_ratio_hi','adj_ratio','adj_lo','adj_hi','adj_p','GMFR_m','GMFR_f','SC_m','SC_f','SC_diff','SC_diff_lo','SC_diff_hi']
print(r[cols].round(2).to_string())
print(r[['assay','antigen','post','sd_lpost','resid_sd','r_pre_post']].round(2).to_string())
