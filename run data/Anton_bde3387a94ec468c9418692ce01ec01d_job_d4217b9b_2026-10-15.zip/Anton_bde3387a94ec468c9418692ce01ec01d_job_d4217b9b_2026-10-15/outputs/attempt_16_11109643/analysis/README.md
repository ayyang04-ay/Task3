# WU397 re-analysis — scripts and outputs

Inputs: `/tmp/world/filesystem/*` (read-only). Environment: `mm core python` (pandas/statsmodels/scipy), `mm renv Rscript` (lme4).
Run order matters only where a script reads an earlier output.

| Script | What it does | Main outputs |
|---|---|---|
| `00_load.py` | shared loaders; participant-ID harmonisation (`397-001`/`001`/`1`/`20`/`397-06` → int); seq-neut parsing (arm, participant, day, subtype, isolate year, egg/reassortant flag by nomenclature, A/Darwin/9/2021 flagged separately as the egg-based comparator strain); censoring flags (`upper` = ≤LOD ~40, `lower` = ≥ULOQ ~17,300) | — |
| `01_seqneut_per_virus.py` | per-virus d0/d29 GMT, GMFR, ≥4-fold rise by arm (LOD/2 imputation) | `seqneut_per_virus.csv` |
| `02_seqneut_breadth_participant.py` | participant-level panel GMTs (unit = participant, not virus), ANCOVA of log2 d29 on arm + log2 d0; LOD/2 and LOD sensitivity | `seqneut_breadth_ancova.csv`, `seqneut_virus_panel_assignment.csv`, `seqneut_participant_*.csv` |
| `03_mn_identity_probe.py` | which seq-neut virus the unnamed MN "homologous"/"heterologous" titres track | `mn_vs_seqneut_correlation.csv`, `mn_vs_seqneut_foldrise_correlation.csv` |
| `04_serology_ancova.py` | HAI, MN, ELISA: GMT, GMT ratio (95% CI), baseline-adjusted ratio, GMFR, ≥4-fold rise with Newcombe CI; wk4 and wk26 (wk17 not pooled) | `serology_ancova.csv` |
| `05_binding_vs_function.py` | bead-array binding breadth per strain and per participant; same-participant comparison with neutralisation | `binding_breadth_per_strain.csv`, `binding_vs_neut_participant.csv` |
| `06_mab_donor_level.py` | mAb binding: naive mAb-level Fisher vs donor-level exact permutation test (4 vs 3 donors) | `mab_donor_level.csv` |
| `07_cellular.py` | GC / plasmablast / clonal overlap / repertoire / IgM: descriptives + integrity checks | stdout |
| `08_mn_censored.py` | Tobit (censored) regression for MN ceiling (1280) / floor (10) | `mn_tobit.csv` |
| `09_seqneut_distant_subsets.py` | H3: 2024 isolates; most-distant quartile (arm-independent pooled-baseline ranking); baseline vs fold-rise | `seqneut_h3_distant_subsets.csv` |
| `10a_make_long.py` then `10_seqneut_mixed.R` | virus-level mixed model (participant + virus random intercepts), sensitivity | `seqneut_mixed_model.csv` |
| `11_sample_size.py` | n/arm and event numbers for the next studies from WU397 variance | `sample_size_immunogenicity.csv`, `sample_size_rve_events.csv`, `power_mismatched_subendpoint.csv` |
| `12_figures.py` | figures | `../fig1_seqneut_per_virus.png`, `../fig2_binding_vs_neutralisation.png` |
| `13_enrolment_structure.py` | participant-ID / enrolment-block structure and baseline heterogeneity | `enrolment_block_check.csv` |
| `14_h1_antigen_identity_check.py` | does the data corroborate the stated mRNA-1010 H1 antigen? | stdout |
| `15_seqneut_durability.py` | day-181 (not pooled with day-121) baseline-adjusted ratios | `seqneut_d181.csv` |
| `16_numbers_ledger.py`, `17_ledger_extras.py`, `18_ledger_extras2.py`, `19_ledger_extras3.py` | build `../numbers_ledger.csv` (every number quoted in answer.md, with source file and output); run in this order | `../numbers_ledger.csv` |
