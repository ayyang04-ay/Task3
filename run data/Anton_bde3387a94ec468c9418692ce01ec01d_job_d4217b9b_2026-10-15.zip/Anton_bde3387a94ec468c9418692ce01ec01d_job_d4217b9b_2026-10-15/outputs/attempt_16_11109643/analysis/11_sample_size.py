"""Sample-size inputs for the next studies, using variance observed in WU397 (participant-level, log2 scale).
Normal-approximation formulas; two arms 1:1."""
import numpy as np, pandas as pd
from scipy.stats import norm
rows = []
def n_ratio(ratio, sd, alpha=0.05, power=0.9, sided=2):
    za = norm.ppf(1-alpha/sided); zb = norm.ppf(power)
    return int(np.ceil(2*(za+zb)**2*sd**2/np.log2(ratio)**2))
def n_ni_ratio(margin, true_ratio, sd, alpha=0.025, power=0.9):
    za = norm.ppf(1-alpha); zb = norm.ppf(power)
    return int(np.ceil(2*(za+zb)**2*sd**2/(np.log2(true_ratio)-np.log2(margin))**2))
def n_ni_prop(p_new, p_comp, margin=-0.10, alpha=0.025, power=0.9):
    za = norm.ppf(1-alpha); zb = norm.ppf(power)
    return int(np.ceil((za+zb)**2*(p_new*(1-p_new)+p_comp*(1-p_comp))/((p_new-p_comp)-margin)**2))
# residual SDs (log2) after baseline adjustment, from seqneut_breadth_ancova.csv / serology_ancova.csv
sd_h3 = 1.028; sd_h1 = 0.863; sd_hai_h1 = 1.05; sd_hai_h3 = 0.85
for lab, sd in [('H3 forward panel, observed resid SD', sd_h3), ('H1 contemporary panel, observed resid SD', sd_h1), ('conservative multi-site SD', 1.3)]:
    for R in [1.18, 1.3, 1.5, 2.0]:
        for a in [0.05, 0.05/3]:
            rows.append(dict(endpoint='heterologous neut GMT ratio (superiority, ANCOVA)', sd_log2=sd, basis=lab, target_ratio=R, alpha_two_sided=round(a,4), power=0.9, n_per_arm=n_ratio(R, sd, alpha=a)))
for lab, sd in [('HAI H1N1 wk4 resid SD', sd_hai_h1), ('HAI H3N2 wk4 resid SD', sd_hai_h3)]:
    rows.append(dict(endpoint='homologous HAI GMT ratio NI (margin 0.67 = 1/1.5)', sd_log2=sd, basis=lab, target_ratio=1.0, alpha_two_sided=0.05, power=0.9, n_per_arm=n_ni_ratio(1/1.5, 1.0, sd)))
for p in [0.15, 0.35, 0.50]:
    rows.append(dict(endpoint='homologous HAI seroconversion NI (margin -10 pts)', sd_log2=np.nan, basis=f'assumed SCR {p:.0%} both arms', target_ratio=np.nan, alpha_two_sided=0.05, power=0.9, n_per_arm=n_ni_prop(p, p)))
r = pd.DataFrame(rows)
# events for relative VE (log-rank/Cox, 1:1): D = 4 (za+zb)^2 / (ln HR)^2
ev = []
for rve in [0.15, 0.20, 0.25, 0.30, 0.40]:
    hr = 1-rve; D = 4*(norm.ppf(0.975)+norm.ppf(0.9))**2/np.log(hr)**2
    ev.append(dict(rVE=rve, HR=hr, events_needed_90pct_power=int(np.ceil(D))))
e = pd.DataFrame(ev)
# power of a mismatched-strain sub-endpoint when it is a fraction f of the events of a trial sized for overall rVE 25%
pw = []
D = int(np.ceil(4*(norm.ppf(0.975)+norm.ppf(0.9))**2/np.log(0.75)**2))
for f in [0.2, 0.4, 0.6]:
    for rve in [0.25, 0.35]:
        z = np.sqrt(f*D/4)*abs(np.log(1-rve)) - norm.ppf(0.975)
        pw.append(dict(total_events=D, fraction_mismatched=f, mismatched_events=int(f*D), true_rVE_mismatched=rve, power=norm.cdf(z)))
p = pd.DataFrame(pw)
r.to_csv('/tmp/outputs/analysis/sample_size_immunogenicity.csv', index=False); e.to_csv('/tmp/outputs/analysis/sample_size_rve_events.csv', index=False); p.to_csv('/tmp/outputs/analysis/power_mismatched_subendpoint.csv', index=False)
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 200)
print(r.to_string()); print(e.to_string()); print(p.round(3).to_string())
