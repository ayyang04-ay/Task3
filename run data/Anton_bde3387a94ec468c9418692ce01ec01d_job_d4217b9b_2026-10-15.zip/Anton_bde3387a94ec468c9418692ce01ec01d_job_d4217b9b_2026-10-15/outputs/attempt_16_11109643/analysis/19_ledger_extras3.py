import numpy as np, pandas as pd
IN = '/tmp/world/filesystem'
led = pd.read_csv('/tmp/outputs/numbers_ledger.csv'); L = []
def add(key, value, source, output, note=''): L.append(dict(key=key, value=value, source_input=source, analysis_output=output, note=note))
sq = pd.read_csv(f'{IN}/neutralization_seqbased.csv')
med = sq.groupby('virus').titer.median()
pairs = [('A/Cambodia/e0826360/2020egg_H3N2','A/Cambodia/e0826360/2020_H3N2'), ('A/HongKong/4801/2014egg_H3N2','A/HongKong/4801/2014_H3N2'),
         ('A/Singapore/INFIMH-16-0019/2016X-307A_H3N2','A/Singapore/INFIMH-16-0019/2016_H3N2'), ('A/Switzerland/9715293/2013NIB-88_H3N2','A/Switzerland/9715293/2013_H3N2'),
         ('A/Texas/50/2012X-223A_H3N2','A/Texas/50/2012_H3N2'), ('A/Darwin/9/2021_H3N2','A/Darwin/6/2021_H3N2'), ('A/Victoria/4897/2022_IVR-238_H1N1','A/Wisconsin/67/2022_H1N1')]
for e, w in pairs:
    add(f'seq-neut median titre (all sera): {e} vs {w}', f'{med[e]:.0f} vs {med[w]:.0f}', 'neutralization_seqbased.csv', 'direct (median over all sera/timepoints)')
add('egg/reassortant-designated viruses that duplicate a wild-type strain already in the panel', '5 of 6 (only A/Victoria/4897/2022 is present solely as the IVR-238 egg reassortant)', 'neutralization_seqbased.csv', 'seqneut_virus_panel_assignment.csv')
m = pd.read_csv(f'{IN}/mab_binding_panels.csv'); h5 = m[m.antigen=='A/Hubei/1/2010 (H5)']
x = h5.assign(b=h5.fold_over_control>=5).groupby('arm').b.mean()
add('mAb-level H5 (A/Hubei/1/2010) binding >=5x (mRNA-1010 vs Fluarix)', f"{100*x['mRNA-1010']:.1f}% vs {100*x['Fluarix']:.1f}%", 'mab_binding_panels.csv', 'mab_donor_level.csv')
out = pd.concat([led, pd.DataFrame(L)], ignore_index=True); out.to_csv('/tmp/outputs/numbers_ledger.csv', index=False)
pd.set_option('display.width', 250); pd.set_option('display.max_colwidth', 140)
print(pd.DataFrame(L)[['key','value']].to_string()); print(len(out))
