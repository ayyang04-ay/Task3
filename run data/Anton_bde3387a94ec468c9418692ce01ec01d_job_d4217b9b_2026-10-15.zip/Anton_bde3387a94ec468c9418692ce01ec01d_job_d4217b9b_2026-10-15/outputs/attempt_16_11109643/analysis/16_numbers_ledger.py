"""Builds /tmp/outputs/numbers_ledger.csv: every number quoted in answer.md, with its source file(s) and the
analysis output it was read from. Values are pulled programmatically from the analysis outputs (no hand transcription)."""
import pandas as pd, numpy as np
A = '/tmp/outputs/analysis'
L = []
def add(key, value, source, output, note=''):
    L.append(dict(key=key, value=value, source_input=source, analysis_output=output, note=note))
f = lambda x, k=2: f'{x:.{k}f}'
ci = lambda r, a, b, c, k=2: f'{r[a]:.{k}f} ({r[b]:.{k}f}-{r[c]:.{k}f})'
# --- seq-neut participant-level ANCOVA
s = pd.read_csv(f'{A}/seqneut_breadth_ancova.csv'); s = s[s.imputation=='LOD/2'].set_index('panel')
for p in s.index:
    r = s.loc[p]
    add(f'seqneut {p}: n viruses', int(r.n_viruses), 'neutralization_seqbased.csv', 'seqneut_breadth_ancova.csv')
    add(f'seqneut {p}: d0 GMT mRNA vs Fluarix', f'{r.GMT0_m:.0f} vs {r.GMT0_f:.0f} (ratio {r.base_ratio:.2f}, p={r.base_p:.2f})', 'neutralization_seqbased.csv', 'seqneut_breadth_ancova.csv')
    add(f'seqneut {p}: d29 GMT mRNA vs Fluarix', f'{r.GMT29_m:.0f} vs {r.GMT29_f:.0f}', 'neutralization_seqbased.csv', 'seqneut_breadth_ancova.csv')
    add(f'seqneut {p}: unadjusted d29 GMT ratio (95% CI)', ci(r,'unadj_ratio','unadj_lo','unadj_hi'), 'neutralization_seqbased.csv', 'seqneut_breadth_ancova.csv')
    add(f'seqneut {p}: baseline-adjusted d29 GMT ratio (95% CI), p', ci(r,'adj_ratio','adj_lo','adj_hi') + f', p={r.adj_p:.3f}', 'neutralization_seqbased.csv', 'seqneut_breadth_ancova.csv')
    add(f'seqneut {p}: mean fraction of panel viruses with >=4-fold rise', f'{r.frac4_m:.2f} vs {r.frac4_f:.2f} (p={r.frac4_p:.3f})', 'neutralization_seqbased.csv', 'seqneut_breadth_ancova.csv')
    add(f'seqneut {p}: residual SD log2 (ANCOVA)', f'{r.resid_sd_log2:.2f}', 'neutralization_seqbased.csv', 'seqneut_breadth_ancova.csv')
mm = pd.read_csv(f'{A}/seqneut_mixed_model.csv').set_index('panel')
for p in mm.index:
    add(f'seqneut mixed model {p}: adjusted ratio (95% CI)', ci(mm.loc[p],'adj_ratio','adj_lo','adj_hi'), 'neutralization_seqbased.csv', 'seqneut_mixed_model.csv (lme4)')
d181 = pd.read_csv(f'{A}/seqneut_d181.csv').set_index('panel')
for p in d181.index:
    add(f'seqneut d181 {p}: adjusted ratio (95% CI), n', ci(d181.loc[p],'adj_ratio181','lo','hi') + f', n={int(d181.loc[p].n_m)}/{int(d181.loc[p].n_f)}', 'neutralization_seqbased.csv', 'seqneut_d181.csv')
ds = pd.read_csv(f'{A}/seqneut_h3_distant_subsets.csv').set_index('subset')
for p in ds.index:
    add(f'seqneut {p}: adjusted ratio (95% CI)', ci(ds.loc[p],'adj','adj_lo','adj_hi'), 'neutralization_seqbased.csv', 'seqneut_h3_distant_subsets.csv')
pv = pd.read_csv(f'{A}/seqneut_per_virus.csv').set_index('virus')
for v in ['A/Wisconsin/588/2019_H1N1','A/Wisconsin/67/2022_H1N1','A/Victoria/4897/2022_IVR-238_H1N1','A/Darwin/6/2021_H3N2','A/Darwin/9/2021_H3N2']:
    r = pv.loc[v]
    add(f'seqneut per-virus {v}: GMFR mRNA vs Fluarix; d29 GMT mRNA vs Fluarix', f'{r.GMFR_m:.2f} vs {r.GMFR_f:.2f}; {r.GMT29_m:.0f} vs {r.GMT29_f:.0f}', 'neutralization_seqbased.csv', 'seqneut_per_virus.csv')
# --- serology
se = pd.read_csv(f'{A}/serology_ancova.csv')
for _, r in se.iterrows():
    add(f'{r.assay} {r.antigen} {r.post}: GMT mRNA vs Fluarix', f'{r.GMTpost_m:.0f} vs {r.GMTpost_f:.0f} (baseline {r.GMT0_m:.0f} vs {r.GMT0_f:.0f})', {'HAI':'hai_titers.csv','ELISA IgG EC50':'elisa_igg_titers.csv'}.get(r.assay,'microneutralization.csv'), 'serology_ancova.csv')
    add(f'{r.assay} {r.antigen} {r.post}: GMT ratio (95% CI); baseline-adjusted', ci(r,'GMT_ratio','GMT_ratio_lo','GMT_ratio_hi') + '; ' + ci(r,'adj_ratio','adj_lo','adj_hi'), {'HAI':'hai_titers.csv','ELISA IgG EC50':'elisa_igg_titers.csv'}.get(r.assay,'microneutralization.csv'), 'serology_ancova.csv')
    add(f'{r.assay} {r.antigen} {r.post}: >=4-fold rise mRNA vs Fluarix; difference (95% CI)', f'{r.SC_m} vs {r.SC_f}; {100*r.SC_diff:.0f} pts ({100*r.SC_diff_lo:.0f} to {100*r.SC_diff_hi:.0f})', {'HAI':'hai_titers.csv','ELISA IgG EC50':'elisa_igg_titers.csv'}.get(r.assay,'microneutralization.csv'), 'serology_ancova.csv')
mt = pd.read_csv(f'{A}/mn_tobit.csv')
for _, r in mt.iterrows():
    add(f'MN {r.panel} wk4 Tobit ({r.model}) ratio (95% CI)', ci(r,'tobit_ratio','tobit_lo','tobit_hi'), 'microneutralization.csv', 'mn_tobit.csv')
# --- binding
bb = pd.read_csv(f'{A}/binding_breadth_per_strain.csv').set_index('strain')
for st in ['A/Hong Kong/1/1968','A/Darwin/6/2021','A/Thailand/8/2022','A/Puerto Rico/8/1934','A/Wisconsin/67/2022']:
    r = bb.loc[st]; add(f'bead-array {st}: mean log2FC mRNA vs Fluarix (fold difference)', f'{r.mean_log2fc_m:.2f} vs {r.mean_log2fc_f:.2f} (x{r.ratio_fold:.1f})', 'binding_breadth_h1.csv / binding_breadth_h3.csv', 'binding_breadth_per_strain.csv')
Q = pd.read_csv(f'{A}/binding_vs_neut_participant.csv')
for sub in ['H1','H3']:
    b = Q[Q.arm=='mRNA-1010'][f'bind_breadth_{sub}'].mean()-Q[Q.arm=='Fluarix'][f'bind_breadth_{sub}'].mean()
    n = Q[Q.arm=='mRNA-1010'][f'neut_lfr_{sub}'].mean()-Q[Q.arm=='Fluarix'][f'neut_lfr_{sub}'].mean()
    t = Q[Q.arm=='mRNA-1010'][f'neut_l29_{sub}'].mean()-Q[Q.arm=='Fluarix'][f'neut_l29_{sub}'].mean()
    add(f'{sub} same-participant arm ratio: binding breadth / neut fold-rise / neut d29 titre', f'x{2**b:.1f} / x{2**n:.1f} / x{2**t:.2f} (n={len(Q)})', 'binding_breadth_*.csv + neutralization_seqbased.csv', 'binding_vs_neut_participant.csv')
# --- mAbs
mb = pd.read_csv(f'{A}/mab_donor_level.csv'); mb = mb[mb.threshold==5].set_index('antigen')
for ag in ['A/Hong Kong/1/1968','A/Shanghai/1/2013 (H7)','A/Hubei/1/2010 (H5)','A/California/04/2009','A/Thailand/8/2022']:
    r = mb.loc[ag]
    add(f'mAb {ag} (>=5x): mAb-level mRNA vs Fluarix (naive p) | donor-level fractions (exact p)', f'{r.mab_frac_m:.2f} vs {r.mab_frac_f:.2f} (p={r.p_naive_mab_level:.3g}) | mRNA {r.donor_fracs_m}; Fluarix {r.donor_fracs_f} (p={r.p_exact_donor_level:.3f})', 'mab_binding_panels.csv', 'mab_donor_level.csv')
# --- sample size
ss = pd.read_csv(f'{A}/sample_size_immunogenicity.csv')
for _, r in ss.iterrows():
    add(f'n/arm: {r.endpoint} | {r.basis} | ratio {r.target_ratio} | alpha {r.alpha_two_sided}', int(r.n_per_arm), 'derived from WU397 variance', 'sample_size_immunogenicity.csv')
ev = pd.read_csv(f'{A}/sample_size_rve_events.csv')
for _, r in ev.iterrows():
    add(f'events for rVE {r.rVE:.0%} at 90% power (1:1, two-sided 0.05)', int(r.events_needed_90pct_power), 'formula (assumption-based)', 'sample_size_rve_events.csv')
pw = pd.read_csv(f'{A}/power_mismatched_subendpoint.csv')
for _, r in pw.iterrows():
    add(f'power of mismatched-strain rVE endpoint: {r.fraction_mismatched:.0%} of {int(r.total_events)} events, true rVE {r.true_rVE_mismatched:.0%}', f'{r.power:.2f}', 'formula (assumption-based)', 'power_mismatched_subendpoint.csv')
out = pd.DataFrame(L); out.to_csv('/tmp/outputs/numbers_ledger.csv', index=False)
print(len(out), 'entries'); pd.set_option('display.width', 250); pd.set_option('display.max_colwidth', 120); pd.set_option('display.max_rows', 400)
print(out[['key','value']].to_string())
