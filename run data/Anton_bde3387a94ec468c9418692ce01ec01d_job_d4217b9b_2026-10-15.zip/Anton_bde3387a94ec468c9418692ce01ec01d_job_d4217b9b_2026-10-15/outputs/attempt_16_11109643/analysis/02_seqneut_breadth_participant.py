"""Participant-level breadth summaries from the sequencing-based neutralisation data (d0 vs d29),
baseline-adjusted (ANCOVA) arm comparison. Participant is the unit of analysis (n=13 vs 14),
so viruses are NOT treated as independent replicates."""
import importlib.util, numpy as np, pandas as pd
import statsmodels.formula.api as smf
from scipy import stats
spec = importlib.util.spec_from_file_location('L', '/tmp/outputs/analysis/00_load.py'); L = importlib.util.module_from_spec(spec); spec.loader.exec_module(L)
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 300)
d = L.load_seqneut()

def panel_of(r):
    if r.egg_or_reassortant: return 'egg/reassortant (excluded)'
    v = r.virus
    if r.subtype == 'H3N2':
        if '/Darwin/6/2021' in v: return 'H3 mRNA-1010 vaccine strain (Darwin/6/2021, cell)'
        if '/Darwin/9/2021' in v: return 'H3 Fluarix vaccine strain (Darwin/9/2021, egg)'
        if r.year >= 2022: return 'H3 contemporary/forward 2022-24'
        return 'H3 historical 2012-20'
    else:
        if r.year >= 2022: return 'H1 contemporary 2022-23'
        return 'H1 historical 2009-19'
d['panel'] = d.apply(panel_of, axis=1)
print(d.groupby('panel').virus.nunique())
d[['virus','subtype','year','egg_or_reassortant','comparator_vaccine_strain','panel']].drop_duplicates().sort_values(['panel','virus']).to_csv('/tmp/outputs/analysis/seqneut_virus_panel_assignment.csv', index=False)

out = []
for imp_name, lod_value in [('LOD/2', 20.0), ('LOD', 40.0)]:
    d['t'] = np.where(d.cens == 'left', lod_value, d.titer)
    d['l2'] = np.log2(d.t)
    for panel, s in d[d.day.isin([0, 29])].groupby('panel'):
        p = s.pivot_table(index=['arm', 'pid', 'virus'], columns='day', values='l2').dropna().reset_index()
        p['rise4'] = (p[29] - p[0]) >= 2
        g = p.groupby(['arm', 'pid']).agg(l0=(0, 'mean'), l29=(29, 'mean'), frac4=('rise4', 'mean'), nv=('virus', 'nunique')).reset_index()
        g['m'] = (g.arm == 'mRNA-1010').astype(int)
        fit = smf.ols('l29 ~ m + l0', data=g).fit()
        est, lo, hi = fit.params['m'], *fit.conf_int().loc['m']
        unadj = smf.ols('l29 ~ m', data=g).fit()
        base = smf.ols('l0 ~ m', data=g).fit()
        gm_ = g.groupby('arm').agg(n=('pid','size'), GMT0=('l0', lambda x: 2**x.mean()), GMT29=('l29', lambda x: 2**x.mean()), frac4=('frac4','mean'))
        out.append(dict(imputation=imp_name, panel=panel, n_viruses=s.virus.nunique(),
                        n_m=int(gm_.loc['mRNA-1010','n']), n_f=int(gm_.loc['Fluarix','n']),
                        GMT0_m=gm_.loc['mRNA-1010','GMT0'], GMT0_f=gm_.loc['Fluarix','GMT0'],
                        base_ratio=2**base.params['m'], base_p=base.pvalues['m'],
                        GMT29_m=gm_.loc['mRNA-1010','GMT29'], GMT29_f=gm_.loc['Fluarix','GMT29'],
                        unadj_ratio=2**unadj.params['m'], unadj_lo=2**unadj.conf_int().loc['m',0], unadj_hi=2**unadj.conf_int().loc['m',1], unadj_p=unadj.pvalues['m'],
                        adj_ratio=2**est, adj_lo=2**lo, adj_hi=2**hi, adj_p=fit.pvalues['m'],
                        frac4_m=gm_.loc['mRNA-1010','frac4'], frac4_f=gm_.loc['Fluarix','frac4'],
                        frac4_p=stats.mannwhitneyu(g[g.m==1].frac4, g[g.m==0].frac4).pvalue,
                        resid_sd_log2=np.sqrt(fit.scale), sd_l29=g.l29.std(), r_l0_l29=np.corrcoef(g.l0,g.l29)[0,1]))
        if imp_name == 'LOD/2':
            g.to_csv(f"/tmp/outputs/analysis/seqneut_participant_{panel.split(' (')[0].replace(' ','_').replace('/','-')}.csv", index=False)
r = pd.DataFrame(out)
r.to_csv('/tmp/outputs/analysis/seqneut_breadth_ancova.csv', index=False)
print(r.round(3).to_string())
