"""Long-format d0/d29 seq-neut table (one row per participant x virus) used by 10_seqneut_mixed.R."""
import importlib.util, numpy as np, pandas as pd
spec = importlib.util.spec_from_file_location('L', '/tmp/outputs/analysis/00_load.py'); L = importlib.util.module_from_spec(spec); spec.loader.exec_module(L)
d = L.load_seqneut(); d['l2'] = np.log2(np.where(d.cens == 'left', 20, d.titer))
a = pd.read_csv('/tmp/outputs/analysis/seqneut_virus_panel_assignment.csv')[['virus', 'panel']]
d = d.merge(a, on='virus')
p = d[d.day.isin([0, 29])].pivot_table(index=['arm', 'pid', 'virus', 'panel'], columns='day', values='l2').dropna().reset_index()
p.columns = ['arm', 'pid', 'virus', 'panel', 'l0', 'l29']
p.to_csv('/tmp/outputs/analysis/seqneut_long_d0_d29.csv', index=False)
print(p.shape)
