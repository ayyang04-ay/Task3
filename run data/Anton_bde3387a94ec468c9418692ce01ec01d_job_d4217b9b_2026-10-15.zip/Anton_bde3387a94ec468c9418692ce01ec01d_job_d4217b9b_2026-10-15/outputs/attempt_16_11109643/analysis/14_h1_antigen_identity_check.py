"""Consistency check of the stated mRNA-1010 H1 antigen (A/Victoria/4897/2022, clade 5a.2a.1 per WHO naming)
against the data. Expectation if the statement is right: mRNA-1010 responses should peak on Victoria/4897/2022 or its
cell-type counterpart A/Wisconsin/67/2022, not on A/Wisconsin/588/2019 (5a.2; counterpart of Fluarix's A/Victoria/2570/2019)."""
import importlib.util, numpy as np, pandas as pd
spec = importlib.util.spec_from_file_location('L', '/tmp/outputs/analysis/00_load.py'); L = importlib.util.module_from_spec(spec); spec.loader.exec_module(L)
pd.set_option('display.width', 250)
r = pd.read_csv('/tmp/outputs/analysis/seqneut_per_virus.csv')
h1 = r[r.subtype=='H1N1'][['virus','GMFR_m','GMFR_f','p4_m','p4_f','GMT29_m','GMT29_f']].sort_values('GMFR_m', ascending=False)
print('Seq-neut H1 viruses ranked by mRNA-1010 GMFR:'); print(h1.round(2).to_string(index=False))
m = pd.read_csv(f'{L.IN}/mab_binding_panels.csv'); m = m[(m.panel=='group_I') & (m.antigen!='SARS-CoV-2 RBD')]
w = m.pivot_table(index=['arm','mab_id'], columns='antigen', values='fold_over_control')
best = w.idxmax(axis=1).groupby(level='arm').value_counts().unstack(fill_value=0)
print('\ngroup I mAbs: antigen with highest signal, by arm'); print(best.to_string())
print('\ngroup I median fold-over-control by arm'); print(m.groupby(['antigen','arm']).fold_over_control.median().unstack().round(1).to_string())
m['donor'] = m.mab_id.str.split('.').str[1]
dm = m[m.antigen.isin(['A/Victoria/4897/2022','A/Wisconsin/588/2019'])].groupby(['arm','donor','antigen']).fold_over_control.median().unstack()
dm['W588_over_V4897'] = dm['A/Wisconsin/588/2019']/dm['A/Victoria/4897/2022']
print('\nper-donor median FOC'); print(dm.round(1).to_string())
b = pd.read_csv(f'{L.IN}/binding_breadth_h1.csv')
print('\nbead-array H1 mean log2FC by arm'); print(b.groupby(['strain','arm']).log2_fold_change_mfi.mean().unstack().sort_values('mRNA-1010', ascending=False).round(2).to_string())
