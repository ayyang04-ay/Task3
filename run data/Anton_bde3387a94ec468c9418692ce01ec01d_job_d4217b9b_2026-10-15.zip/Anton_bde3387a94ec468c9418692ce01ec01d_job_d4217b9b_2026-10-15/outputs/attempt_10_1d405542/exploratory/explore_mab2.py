import pandas as pd, numpy as np
d = pd.read_csv("/tmp/world/filesystem/mab_binding_panels.csv")
d["donor"] = d.mab_id.str.split(".").str[1]
w = d.pivot_table(index=["panel","arm","donor","mab_id"], columns="antigen", values="fold_over_control")
pd.set_option("display.width",250); pd.set_option("display.max_columns",20)
for panel in ["group_I","group_II"]:
    x = w.loc[panel].dropna(axis=1, how="all")
    print("=== ", panel, x.shape)
    print(x.head(30).round(1))
    # histogram of values
    vals = x.drop(columns=["SARS-CoV-2 RBD"]).values.ravel()
    print(np.percentile(vals,[1,5,10,25,50,75,90,95,99]))
    print("fraction <=1:", (vals<=1).mean(), " fraction ==1:", (vals==1).mean())
