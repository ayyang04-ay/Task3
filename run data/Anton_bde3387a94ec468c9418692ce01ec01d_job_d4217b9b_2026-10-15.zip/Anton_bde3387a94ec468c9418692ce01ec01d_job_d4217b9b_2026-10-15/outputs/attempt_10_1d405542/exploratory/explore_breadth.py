import pandas as pd, numpy as np
from scipy import stats
for f in ["/tmp/world/filesystem/binding_breadth_h1.csv","/tmp/world/filesystem/binding_breadth_h3.csv"]:
    d = pd.read_csv(f)
    print("=====", f)
    order = list(dict.fromkeys(d.strain))
    rows=[]
    for s in order:
        x = d[(d.strain==s)&(d.arm=="mRNA-1010")].log2_fold_change_mfi
        y = d[(d.strain==s)&(d.arm=="Fluarix")].log2_fold_change_mfi
        u = stats.mannwhitneyu(x,y)
        rows.append([s, len(x), x.mean(), x.median(), len(y), y.mean(), y.median(), u.pvalue])
    r = pd.DataFrame(rows, columns=["strain","n_m","mean_m","med_m","n_f","mean_f","med_f","MWU_p"])
    print(r.to_string())
