import pandas as pd, numpy as np
from scipy import stats
pd.set_option("display.width",250); pd.set_option("display.max_rows",500)
d = pd.read_csv("/tmp/world/filesystem/neutralization_seqbased.csv")
sp = d.serum.str.extract(r"^(?P<arm>mRNA-1010|Fluarix)_(?P<pid>397-\d+)_d(?P<day>\d+)$")
d = pd.concat([d, sp], axis=1)
d["day"] = d.day.astype(int)
d["tp"] = np.where(d.day==0,"d0",np.where(d.day==29,"d29","late"))
d["lt"] = np.log2(d.titer)
w = d.pivot_table(index=["virus","arm","pid"], columns="tp", values="lt").reset_index()
w["fr29"] = w.d29 - w.d0
w["frl"] = w.late - w.d0
rows=[]
for v, g in w.groupby("virus"):
    a = g[g.arm=="mRNA-1010"]; b = g[g.arm=="Fluarix"]
    r = dict(virus=v,
             m_gmfr29=2**a.fr29.mean(), f_gmfr29=2**b.fr29.mean(),
             p_fr29=stats.ttest_ind(a.fr29.dropna(), b.fr29.dropna()).pvalue,
             m_4x=(a.fr29>=2).mean(), f_4x=(b.fr29>=2).mean(),
             gmr29=2**(a.d29.mean()-b.d29.mean()), gmr0=2**(a.d0.mean()-b.d0.mean()),
             m_gmfrl=2**a.frl.mean(), f_gmfrl=2**b.frl.mean(),
             gmrl=2**(a.late.mean()-b.late.mean()))
    rows.append(r)
r = pd.DataFrame(rows).set_index("virus").round(3)
print(r.to_string())
r.to_csv("/tmp/outputs/exploratory/seqneut_per_virus_summary_raw.csv")
