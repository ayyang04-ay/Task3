import pandas as pd, numpy as np
pd.set_option("display.width",250); pd.set_option("display.max_rows",500)
d = pd.read_csv("/tmp/world/filesystem/neutralization_seqbased.csv")
sp = d.serum.str.extract(r"^(?P<arm>mRNA-1010|Fluarix)_(?P<pid>397-\d+)_d(?P<day>\d+)$")
d = pd.concat([d, sp], axis=1)
d["day"] = d.day.astype(int)
d["tp"] = np.where(d.day==0,"d0",np.where(d.day==29,"d29","late"))
d["subtype"] = d.virus.str.extract(r"_(H\dN\d)$")
print(d.groupby(["arm","tp"]).pid.nunique())
print(d.groupby(["subtype"]).virus.nunique())
# GMT per virus arm tp
d["lt"] = np.log2(d.titer)
g = d.groupby(["virus","arm","tp"]).lt.mean().unstack(["arm","tp"])
g = 2**g
g = g.round(0)
print(g.sort_index().to_string())
