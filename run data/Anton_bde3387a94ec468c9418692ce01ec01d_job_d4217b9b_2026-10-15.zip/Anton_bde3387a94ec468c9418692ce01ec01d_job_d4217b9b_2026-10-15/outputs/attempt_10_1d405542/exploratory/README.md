Scratch scripts used while exploring the WU397 files before the consolidated analysis was written.
They are not needed to reproduce any number in answer.md - every cited number comes from
/tmp/outputs/wu397_analysis.py. explore_mn_identity.py is referenced in answer.md section 3.8
(which seq-neut viruses the unnamed MN 'homologous'/'heterologous' series track most closely).
Run with: micromamba run -n core python <script>
