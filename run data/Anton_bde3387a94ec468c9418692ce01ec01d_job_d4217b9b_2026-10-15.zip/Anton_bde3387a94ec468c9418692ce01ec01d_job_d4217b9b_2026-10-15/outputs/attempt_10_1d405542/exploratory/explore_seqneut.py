import pandas as pd, numpy as np
pd.set_option("display.width",250); pd.set_option("display.max_rows",500)
d = pd.read_csv("/tmp/world/filesystem/neutralization_seqbased.csv")
print(d.describe(include="all").T)
print(d.titer_bound.value_counts())
print(d[d.titer_bound=="lower"].titer.describe())
print(d[d.titer_bound=="upper"].titer.describe())
print(d[d.titer_bound=="interpolated"].titer.describe())
print(d.sort_values("titer").head(10)); print(d.sort_values("titer").tail(10))
