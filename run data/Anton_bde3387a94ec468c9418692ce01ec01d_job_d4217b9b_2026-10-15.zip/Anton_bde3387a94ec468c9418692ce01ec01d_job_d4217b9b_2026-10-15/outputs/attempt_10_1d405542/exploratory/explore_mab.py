import pandas as pd, numpy as np
d = pd.read_csv("/tmp/world/filesystem/mab_binding_panels.csv")
print(d.groupby(["panel","arm"]).mab_id.nunique())
d["donor"] = d.mab_id.str.split(".").str[1]
print(d.groupby(["panel","arm","donor"]).mab_id.nunique())
print(d.fold_over_control.describe())
print(d.groupby(["panel","antigen"]).fold_over_control.describe())
