import pandas as pd, numpy as np
from scipy import stats
pd.set_option("display.width",250)
d = pd.read_csv("/tmp/world/filesystem/neutralization_seqbased.csv")
sp = d.serum.str.extract(r"^(?P<arm>mRNA-1010|Fluarix)_(?P<pid>397-\d+)_d(?P<day>\d+)$")
d = pd.concat([d, sp], axis=1); d["day"]=d.day.astype(int)
d["tp"] = d.day.map({0:"wk0",29:"wk4",121:"wk17",181:"wk26"})
d["logt"] = np.log2(d.titer)
h = pd.read_csv("/tmp/world/filesystem/hai_titers.csv", dtype={"participant":str})
h["pid"] = "397-"+h.participant; h["lh"]=np.log2(h.hai_titer); h=h.rename(columns={"timepoint":"tp"})
for ag in ["A/H1N1","A/H3N2"]:
    m = h[h.antigen==ag]
    j = d.merge(m[["pid","tp","lh"]], on=["pid","tp"])
    res=[]
    for v,g in j.groupby("virus"):
        res.append((v,len(g),stats.spearmanr(g.logt,g.lh).correlation))
    r = pd.DataFrame(res,columns=["virus","n","rho"]).sort_values("rho",ascending=False)
    print(ag); print(r.head(10).to_string()); print(r.tail(3).to_string())
# ELISA vs seq-neut (only 27 overlapping participants)
e = pd.read_csv("/tmp/world/filesystem/elisa_igg_titers.csv"); e = e[e.measure=="ec50"].copy()
e["pid"] = "397-"+e.participant.astype(int).map(lambda x: f"{x:03d}"); e["logE"]=np.log2(e.value); e=e.rename(columns={"timepoint":"tp"})
for ag in ["A/H1","A/H3"]:
    m = e[e.antigen==ag]
    j = d.merge(m[["pid","tp","logE"]], on=["pid","tp"])
    res=[]
    for v,g in j.groupby("virus"):
        res.append((v,len(g),stats.spearmanr(g.logt,g.logE).correlation))
    r = pd.DataFrame(res,columns=["virus","n","rho"]).sort_values("rho",ascending=False)
    print("ELISA",ag); print(r.head(8).to_string())
