import pandas as pd, numpy as np
from scipy import stats
d = pd.read_csv("/tmp/world/filesystem/hai_titers.csv", dtype={"participant":str})
p = d.pivot_table(index=["antigen","arm","participant"], columns="timepoint", values="hai_titer").reset_index()
p["late"] = p["wk26"].fillna(p["wk17"])
def gm(x): x=np.asarray(x,float); x=x[~np.isnan(x)]; return np.exp(np.mean(np.log(x))) if len(x) else np.nan, len(x)
for ag in ["A/H1N1","A/H3N2","B/Vic","B/Yam"]:
    print("====", ag)
    for arm in ["mRNA-1010","Fluarix"]:
        s = p[(p.antigen==ag)&(p.arm==arm)]
        g0,n0 = gm(s.wk0); g4,n4 = gm(s.wk4); gl,nl = gm(s.late)
        fr4,_ = gm(s.wk4/s.wk0)
        sc = (((s.wk4/s.wk0)>=4)&(s.wk4>=40)).sum()
        sp0 = (s.wk0>=40).sum(); sp4 = (s.wk4>=40).sum()
        print(f"{arm:10s} n={n0} GMT0={g0:6.1f} GMT4={g4:6.1f} GMTlate={gl:6.1f}(n={nl}) GMFR4={fr4:4.2f} SCR={sc}/{n4} SP0={sp0}/{n0} SP4={sp4}/{n4}")
    a = p[(p.antigen==ag)&(p.arm=="mRNA-1010")]; b = p[(p.antigen==ag)&(p.arm=="Fluarix")]
    for col in ["wk0","wk4","late"]:
        t = stats.ttest_ind(np.log(a[col].dropna()), np.log(b[col].dropna()))
        print(f"  {col}: GMR(m/F)={np.exp(np.log(a[col].dropna()).mean()-np.log(b[col].dropna()).mean()):.2f} p={t.pvalue:.3f}")
    t = stats.ttest_ind(np.log(a.wk4/a.wk0).dropna(), np.log(b.wk4/b.wk0).dropna()); print(f"  GMFR4 p={t.pvalue:.3f}")
print(p[p.antigen=="A/H1N1"].to_string())
