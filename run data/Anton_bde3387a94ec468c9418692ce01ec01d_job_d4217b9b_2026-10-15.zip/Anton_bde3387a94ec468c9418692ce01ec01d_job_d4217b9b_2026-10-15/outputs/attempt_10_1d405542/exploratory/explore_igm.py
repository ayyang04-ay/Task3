import pandas as pd, numpy as np
from scipy import stats
d = pd.read_csv("/tmp/world/filesystem/igm_fold_change.csv", dtype={"participant":str})
print(d.participant.unique())
for ag in ["H1","H3","B/Vic","B/Yam"]:
    for arm in ["mRNA-1010","Fluarix"]:
        x = d[(d.antigen==ag)&(d.arm==arm)].fold_change
        print(f"{ag:5s} {arm:10s} n={len(x)} GMFR={np.exp(np.log(x).mean()):.2f} median={x.median():.2f} n>1={(x>1).sum()} n>=4={(x>=4).sum()}")
    a = d[(d.antigen==ag)&(d.arm=="mRNA-1010")].fold_change; b = d[(d.antigen==ag)&(d.arm=="Fluarix")].fold_change
    print("   MWU p=%.3f"%stats.mannwhitneyu(a,b).pvalue)
# base unit
print(sorted(set((d.fold_change*27).round(2))))
