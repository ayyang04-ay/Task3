import pandas as pd, numpy as np
d = pd.read_csv("/tmp/world/filesystem/gc_frequencies.csv", dtype={"participant":str})
d["block"] = (d.groupby(["timepoint","arm","participant"]).cumcount()+1)
print(d.groupby(["block"]).size())
print(d.groupby(["block","timepoint","arm"]).pct_ha_specific_igg_gc.agg(["count","median","mean"]).round(2).unstack("arm"))
pb = pd.read_csv("/tmp/world/filesystem/plasmablast_frequencies.csv", dtype={"participant":str})
print(pb.groupby(["timepoint","arm"]).pct_plasmablast.agg(["count","median","mean"]).round(3).unstack("arm"))
print("PB participants:", {a: sorted(pb[pb.arm==a].participant.unique()) for a in pb.arm.unique()})
print("GC participants:", {a: sorted(d[d.arm==a].participant.unique()) for a in d.arm.unique()})
# precision of PB values
pb["ndec"] = pb.pct_plasmablast.astype(str).str.split(".").str[1].str.len()
print(pb.groupby("participant").ndec.max().sort_values())
