import pandas as pd, numpy as np
pd.set_option("display.width",250); pd.set_option("display.max_columns",30)
d = pd.read_csv("/tmp/world/filesystem/mab_binding_panels.csv")
d["donor"] = d.mab_id.str.split(".").str[1]
w = d.pivot_table(index=["panel","arm","donor","mab_id"], columns="antigen", values="fold_over_control")
T = 10
g1 = w.loc["group_I"].dropna(axis=1, how="all").drop(columns=["SARS-CoV-2 RBD"])
pos = g1 >= T
g1s = pd.DataFrame({
  "n": pos.groupby(level=["arm","donor"]).size(),
  "any_H1": (pos[["A/Victoria/4897/2022","A/Wisconsin/588/2019","A/California/04/2009","A/New Caledonia/20/1999","A/Puerto Rico/8/1934","A/Netherlands/01317/2025"]].any(axis=1)).groupby(level=["arm","donor"]).sum(),
  "Vic4897": pos["A/Victoria/4897/2022"].groupby(level=["arm","donor"]).sum(),
  "Wis588": pos["A/Wisconsin/588/2019"].groupby(level=["arm","donor"]).sum(),
  "Wis588_not_Vic4897": (pos["A/Wisconsin/588/2019"] & ~pos["A/Victoria/4897/2022"]).groupby(level=["arm","donor"]).sum(),
  "Vic4897_not_Wis588": (pos["A/Victoria/4897/2022"] & ~pos["A/Wisconsin/588/2019"]).groupby(level=["arm","donor"]).sum(),
  "Neth2025": pos["A/Netherlands/01317/2025"].groupby(level=["arm","donor"]).sum(),
  "H5": pos["A/Hubei/1/2010 (H5)"].groupby(level=["arm","donor"]).sum(),
  "PR8": pos["A/Puerto Rico/8/1934"].groupby(level=["arm","donor"]).sum(),
  "NC99": pos["A/New Caledonia/20/1999"].groupby(level=["arm","donor"]).sum(),
  "Cal09": pos["A/California/04/2009"].groupby(level=["arm","donor"]).sum(),
})
print("GROUP I (threshold >=%d-fold)"%T); print(g1s)
print(g1s.groupby(level="arm").sum())
g2 = w.loc["group_II"].dropna(axis=1, how="all").drop(columns=["SARS-CoV-2 RBD"])
pos = g2 >= T
cols = list(g2.columns)
g2s = pd.DataFrame({"n": pos.groupby(level=["arm","donor"]).size()})
for c in cols: g2s[c.split("/")[1] if "H7" not in c else "H7"] = pos[c].groupby(level=["arm","donor"]).sum()
g2s["any"] = pos.any(axis=1).groupby(level=["arm","donor"]).sum()
print("GROUP II"); print(g2s); print(g2s.groupby(level="arm").sum())
