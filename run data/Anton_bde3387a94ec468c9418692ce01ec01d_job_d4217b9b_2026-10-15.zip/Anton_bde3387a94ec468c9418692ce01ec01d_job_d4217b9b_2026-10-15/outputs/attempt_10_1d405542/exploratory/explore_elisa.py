import pandas as pd, numpy as np
from scipy import stats
d = pd.read_csv("/tmp/world/filesystem/elisa_igg_titers.csv")
print(d.head())
# pivot ec50
e = d[d.measure=="ec50"].pivot_table(index=["antigen","arm","participant"], columns="timepoint", values="value")
print(e.head(20))
fc = d[d.measure=="fold_change"].pivot_table(index=["antigen","arm","participant"], columns="timepoint", values="value")
print(fc.head(20))
# check fold change consistency
m = e.join(fc, rsuffix="_fc")
m["calc_wk4"] = m["wk4"]/m["wk0"]
m["late"] = m["wk26"].fillna(m["wk17"]) if "wk17" in m else m["wk26"]
m["calc_late"] = m["late"]/m["wk0"]
m["d4"] = np.log2(m["calc_wk4"]/m["wk4_fc"])
m["dl"] = np.log2(m["calc_late"]/m["wk17/26"])
print(m[["wk4_fc","calc_wk4","d4","wk17/26","calc_late","dl"]].describe())
print(m[(m.d4.abs()>0.05)|(m.dl.abs()>0.05)])
