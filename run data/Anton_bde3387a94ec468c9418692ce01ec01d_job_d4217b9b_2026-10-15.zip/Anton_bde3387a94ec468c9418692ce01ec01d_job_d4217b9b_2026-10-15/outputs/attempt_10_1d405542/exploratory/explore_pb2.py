import pandas as pd, numpy as np
from scipy import stats
pb = pd.read_csv("/tmp/world/filesystem/plasmablast_frequencies.csv", dtype={"participant":str})
fna = {'001','005','009','011','018','020','022','024','026','027','032','006','017','021','028','029','030'}
pb["in_fna"] = pb.participant.isin(fna)
for sub, s in [("all", pb), ("FNA-cohort only", pb[pb.in_fna]), ("extra only", pb[~pb.in_fna])]:
    print("==", sub)
    print(s.groupby(["timepoint","arm"]).pct_plasmablast.agg(["count","median","mean"]).round(3).unstack("arm"))
    for tp in ["wk2","wk8","wk17","wk26"]:
        a = s[(s.timepoint==tp)&(s.arm=="mRNA-1010")].pct_plasmablast; b = s[(s.timepoint==tp)&(s.arm=="Fluarix")].pct_plasmablast
        if len(a)>1 and len(b)>1: print(tp, "MWU p=%.3f"%stats.mannwhitneyu(a,b).pvalue)
