import pandas as pd, numpy as np
from scipy import stats
pd.set_option("display.width",250)
d = pd.read_csv("/tmp/world/filesystem/elisa_igg_titers.csv")
e = d[d.measure=="ec50"].pivot_table(index=["antigen","arm","participant"], columns="timepoint", values="value").reset_index()
e["late"] = e["wk26"].fillna(e["wk17"])
hai_ids = {3,6,8,10,14,15,17,21,23,25,28,29,30,31, 1,2,5,7,9,11,16,18,19,20,22,24,26,27,32}
e["sub"] = np.where(e.participant.isin(hai_ids), "HAI-subset", "ELISA-only")
for ag in ["A/H1","A/H3","B/Vic","B/Yam"]:
    for arm in ["mRNA-1010","Fluarix"]:
        for sub in ["HAI-subset","ELISA-only"]:
            s = e[(e.antigen==ag)&(e.arm==arm)&(e["sub"]==sub)]
            fr = np.log2(s.wk4/s.wk0)
            print(f"{ag:6s} {arm:10s} {sub:11s} n={len(s):2d} GMT0={2**np.log2(s.wk0).mean():7.0f} GMT4={2**np.log2(s.wk4).mean():7.0f} GMFR4={2**fr.mean():5.2f} >=4x={(fr>=2).mean():.2f}")
    # test within mRNA: HAI-subset vs ELISA-only
    m = e[(e.antigen==ag)&(e.arm=="mRNA-1010")]
    a = np.log2(m[m["sub"]=="HAI-subset"].wk4/m[m["sub"]=="HAI-subset"].wk0); b = np.log2(m[m["sub"]=="ELISA-only"].wk4/m[m["sub"]=="ELISA-only"].wk0)
    print("   mRNA subset diff p=", round(stats.ttest_ind(a,b).pvalue,4))
