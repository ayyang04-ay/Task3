import pandas as pd, numpy as np
from scipy import stats
pd.set_option("display.width",250)
d = pd.read_csv("/tmp/world/filesystem/neutralization_seqbased.csv")
sp = d.serum.str.extract(r"^(?P<arm>mRNA-1010|Fluarix)_(?P<pid>397-\d+)_d(?P<day>\d+)$")
d = pd.concat([d, sp], axis=1); d["day"]=d.day.astype(int)
d["tp"] = np.where(d.day==0,"d0",np.where(d.day==29,"d29","late"))
d["logt"] = np.log2(d.titer)
w = d.pivot_table(index=["arm","pid","tp"], columns="virus", values="logt")
pairs = [("A/Cambodia/e0826360/2020egg_H3N2","A/Cambodia/e0826360/2020_H3N2"),
         ("A/HongKong/4801/2014egg_H3N2","A/HongKong/4801/2014_H3N2"),
         ("A/Singapore/INFIMH-16-0019/2016X-307A_H3N2","A/Singapore/INFIMH-16-0019/2016_H3N2"),
         ("A/Texas/50/2012X-223A_H3N2","A/Texas/50/2012_H3N2"),
         ("A/Switzerland/9715293/2013NIB-88_H3N2","A/Switzerland/9715293/2013_H3N2"),
         ("A/Darwin/9/2021_H3N2","A/Darwin/6/2021_H3N2"),
         ("A/Victoria/4897/2022_IVR-238_H1N1","A/Wisconsin/67/2022_H1N1")]
for egg, wt in pairs:
    diff = (w[egg]-w[wt]).rename("egg_minus_wt").reset_index()
    t = diff.pivot_table(index=["arm","pid"], columns="tp", values="egg_minus_wt")
    out=[]
    for arm in ["Fluarix","mRNA-1010"]:
        x = t.loc[arm]
        out.append(f"{arm}: egg/wt ratio d0={2**x.d0.mean():.2f} d29={2**x.d29.mean():.2f} late={2**x.late.mean():.2f}")
    # fold-rise on egg vs fold-rise on wt, by arm
    fr = w.reset_index().pivot_table(index=["arm","pid"], columns="tp", values=[egg,wt])
    fr_egg = fr[(egg,"d29")]-fr[(egg,"d0")]; fr_wt = fr[(wt,"d29")]-fr[(wt,"d0")]
    s = []
    for arm in ["Fluarix","mRNA-1010"]:
        s.append(f"{arm}: GMFR egg={2**fr_egg.loc[arm].mean():.2f} wt={2**fr_wt.loc[arm].mean():.2f}")
    print(egg.split("_")[0], "vs", wt.split("_")[0]); print("   ", " | ".join(out)); print("   ", " | ".join(s))
