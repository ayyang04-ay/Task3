import pandas as pd, numpy as np
from scipy import stats
d = pd.read_csv("/tmp/world/filesystem/elisa_igg_titers.csv")
e = d[d.measure=="ec50"].pivot_table(index=["antigen","arm","participant"], columns="timepoint", values="value").reset_index()
e["late"] = e["wk26"].fillna(e["wk17"])
def gm(x): x=np.asarray(x,float); x=x[~np.isnan(x)]; return np.exp(np.mean(np.log(x))), len(x)
for ag in ["A/H1","A/H3","B/Vic","B/Yam"]:
    print("====", ag)
    for arm in ["mRNA-1010","Fluarix"]:
        s = e[(e.antigen==ag)&(e.arm==arm)]
        g0,n0 = gm(s.wk0); g4,n4 = gm(s.wk4); gl,nl = gm(s.late)
        fr4,_ = gm(s.wk4/s.wk0); frl,nfl = gm(s.late/s.wk0)
        p4 = ((s.wk4/s.wk0)>=4).mean()
        print(f"{arm:10s} n={n0} GMT0={g0:8.0f} GMT4={g4:8.0f} GMTlate={gl:8.0f}(n={nl}) GMFR4={fr4:5.2f} GMFRlate={frl:5.2f} pct>=4x wk4={p4:.2f}")
    a = e[(e.antigen==ag)&(e.arm=="mRNA-1010")]; b = e[(e.antigen==ag)&(e.arm=="Fluarix")]
    for col in ["wk0","wk4","late"]:
        t = stats.ttest_ind(np.log(a[col].dropna()), np.log(b[col].dropna()))
        print(f"  {col}: log t-test p={t.pvalue:.4f}; GMR={np.exp(np.log(a[col].dropna()).mean()-np.log(b[col].dropna()).mean()):.2f}")
    t = stats.ttest_ind(np.log(a.wk4/a.wk0), np.log(b.wk4/b.wk0)); print(f"  GMFR4 ratio p={t.pvalue:.4f}")
