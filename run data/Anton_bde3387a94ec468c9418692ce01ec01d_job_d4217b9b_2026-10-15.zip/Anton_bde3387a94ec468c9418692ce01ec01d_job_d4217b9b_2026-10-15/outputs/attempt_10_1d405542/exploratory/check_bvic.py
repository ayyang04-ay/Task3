import pandas as pd, numpy as np
d = pd.read_csv("/tmp/world/filesystem/hai_titers.csv", dtype={"participant":str})
p = d.pivot_table(index=["antigen","arm","participant"], columns="timepoint", values="hai_titer")
b = p.loc["B/Vic"]
print(b.to_string())
for arm in ["mRNA-1010","Fluarix"]:
    s = b.loc[arm]
    late = s.wk26.fillna(s.wk17)
    print(arm, "GMT wk4 %.4f  late %.4f"%(2**np.log2(s.wk4.dropna()).mean(), 2**np.log2(late.dropna()).mean()))
    print(sorted(s.wk4.dropna().values)); print(sorted(late.dropna().values))
# which participants have wk17 per antigen
for ag in p.index.get_level_values(0).unique():
    x = p.loc[ag]
    print(ag, "wk17:", list(x[x.wk17.notna()].index), " missing wk26 & wk17:", list(x[x.wk17.isna() & x.wk26.isna()].index))
