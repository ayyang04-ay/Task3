import pandas as pd, numpy as np
d = pd.read_csv("/tmp/world/filesystem/mab_binding_panels.csv")
d = d[d.antigen!="SARS-CoV-2 RBD"]
v = d.fold_over_control.values
bins = [-1,0,0.5,1,1.5,2,3,5,10,20,50,100,200,500,2000]
print(pd.cut(v,bins).value_counts().sort_index())
# mAbs in both panels
g1 = set(d[d.panel=="group_I"].mab_id); g2=set(d[d.panel=="group_II"].mab_id)
both = g1 & g2
print("n in both panels:", len(both))
print(sorted(both)[:50])
