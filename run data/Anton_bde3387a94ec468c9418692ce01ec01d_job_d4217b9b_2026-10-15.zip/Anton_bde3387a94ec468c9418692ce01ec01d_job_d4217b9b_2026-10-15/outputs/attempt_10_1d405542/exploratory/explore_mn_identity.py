import pandas as pd, numpy as np
from scipy import stats
pd.set_option("display.width",250); pd.set_option("display.max_rows",500)
d = pd.read_csv("/tmp/world/filesystem/neutralization_seqbased.csv")
sp = d.serum.str.extract(r"^(?P<arm>mRNA-1010|Fluarix)_(?P<pid>397-\d+)_d(?P<day>\d+)$")
d = pd.concat([d, sp], axis=1); d["day"]=d.day.astype(int)
d["tp"] = d.day.map({0:"wk0",29:"wk4",121:"wk17",181:"wk26"})
d["logt"] = np.log2(d.titer)
mn = pd.read_csv("/tmp/world/filesystem/microneutralization.csv")
mn = mn[mn.measure=="titer"].copy(); mn["lmn"]=np.log2(mn.value)
mn = mn.rename(columns={"participant":"pid","timepoint":"tp"})
res=[]
for panel in ["homologous","heterologous"]:
    m = mn[mn.panel==panel]
    j = d.merge(m[["pid","tp","lmn"]], on=["pid","tp"])
    for v,g in j.groupby("virus"):
        r = stats.spearmanr(g.logt, g.lmn).correlation
        # fold-change correlation: wk4 minus wk0
        res.append((panel, v, len(g), r))
r = pd.DataFrame(res, columns=["panel","virus","n","spearman"])
for panel in ["homologous","heterologous"]:
    print(panel); print(r[r.panel==panel].sort_values("spearman", ascending=False).head(12).to_string())
# fold change correlation
def fc(df, val):
    w = df.pivot_table(index="pid", columns="tp", values=val)
    return (w["wk4"]-w["wk0"])
res=[]
for panel in ["homologous","heterologous"]:
    m = mn[mn.panel==panel]
    fm = fc(m, "lmn")
    for v,g in d.groupby("virus"):
        fv = fc(g, "logt")
        jj = pd.concat([fm.rename("mn"), fv.rename("sn")], axis=1).dropna()
        res.append((panel, v, len(jj), stats.spearmanr(jj.mn, jj.sn).correlation))
r = pd.DataFrame(res, columns=["panel","virus","n","spearman_fc"])
for panel in ["homologous","heterologous"]:
    print(panel, "FOLD CHANGE"); print(r[r.panel==panel].sort_values("spearman_fc", ascending=False).head(12).to_string())
