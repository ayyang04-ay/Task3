#!/usr/bin/env python
"""
WU397 data-package re-analysis (mRNA-1010 vs Fluarix, 2022-23 NH season).

Purpose: establish what the existing immunogenicity package does and does not
support with respect to a *heterologous protection* claim, and derive the
quantities (effect sizes, variances, baseline imbalances) used to specify the
next studies.

Run:  micromamba run -n core python /tmp/outputs/wu397_analysis.py
Input: /tmp/world/filesystem/*.csv, trial_summary.md (read-only)
Output: /tmp/outputs/tables/*.csv, /tmp/outputs/analysis_log.txt,
        /tmp/outputs/figures/*.png

Conventions
- All titres analysed on log2 scale; GMT = 2^mean(log2); GMR = ratio of GMTs
  (mRNA-1010 / Fluarix unless stated); 95% CIs from Welch t on log2 values.
- Fold-rise = post / pre within participant; GMFR = geometric mean fold-rise.
- HAI seroconversion (SCR) = >=4-fold rise AND post titre >=40 (pre <10 -> post
  >=40 rule folded in because no pre-titre <10 exists in this file).
- Reported numbers are descriptive; this was a non-randomised, open-label
  study, so p-values are nominal and unadjusted.
"""
import os, re, math, io, sys
import numpy as np
import pandas as pd
from scipy import stats

IN = "/tmp/world/filesystem"
OUT = "/tmp/outputs"
TAB = os.path.join(OUT, "tables"); FIG = os.path.join(OUT, "figures")
os.makedirs(TAB, exist_ok=True); os.makedirs(FIG, exist_ok=True)
pd.set_option("display.width", 250); pd.set_option("display.max_rows", 500)
pd.set_option("display.max_columns", 40)

LOG = io.StringIO()
def log(*a):
    s = " ".join(str(x) for x in a)
    print(s); LOG.write(s + "\n")

def gmt(x):
    x = np.asarray(x, float); x = x[~np.isnan(x)]
    return float(2 ** np.mean(np.log2(x))) if len(x) else np.nan

def welch_log2(a, b):
    """GMR (a/b) with 95% CI and Welch p on log2-transformed data."""
    a = np.log2(np.asarray(a, float)); b = np.log2(np.asarray(b, float))
    a = a[~np.isnan(a)]; b = b[~np.isnan(b)]
    diff = a.mean() - b.mean()
    va, vb = a.var(ddof=1) / len(a), b.var(ddof=1) / len(b)
    se = math.sqrt(va + vb)
    df = (va + vb) ** 2 / (va ** 2 / (len(a) - 1) + vb ** 2 / (len(b) - 1))
    t = stats.t.ppf(0.975, df)
    p = stats.ttest_ind(a, b, equal_var=False).pvalue
    return 2 ** diff, 2 ** (diff - t * se), 2 ** (diff + t * se), p

def gm_ci(x):
    x = np.log2(np.asarray(x, float)); x = x[~np.isnan(x)]
    m, s, n = x.mean(), x.std(ddof=1), len(x)
    t = stats.t.ppf(0.975, n - 1)
    return 2 ** m, 2 ** (m - t * s / math.sqrt(n)), 2 ** (m + t * s / math.sqrt(n))

def wilson(k, n):
    if n == 0: return (np.nan, np.nan)
    z = 1.959964; p = k / n
    c = (p + z * z / (2 * n)) / (1 + z * z / n)
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / (1 + z * z / n)
    return c - h, c + h

ARMS = ["mRNA-1010", "Fluarix"]

# ----------------------------------------------------------------------------
# 0. Trial summary facts used in the interpretation (quoted from the document)
# ----------------------------------------------------------------------------
summary = open(os.path.join(IN, "trial_summary.md")).read()
log("=" * 100); log("0. TRIAL SUMMARY FACTS (trial_summary.md)"); log("=" * 100)
for key in ["Open-label", "Non-randomised", "A/Victoria/4897/2022", "A/Darwin/6/2021",
            "B/Austria/1359417/2021", "B/Phuket/3073/2013", "was not set for this study",
            "refer to the mRNA-1010 antigens", "weeks 1, 2, 4, 8, 17 and 26"]:
    line = [l.strip() for l in summary.splitlines() if key in l]
    log(f"  [{key}] -> {line[0] if line else 'NOT FOUND'}")

# ----------------------------------------------------------------------------
# 1. Load data
# ----------------------------------------------------------------------------
hai = pd.read_csv(os.path.join(IN, "hai_titers.csv"), dtype={"participant": str})
elisa = pd.read_csv(os.path.join(IN, "elisa_igg_titers.csv"))
mn = pd.read_csv(os.path.join(IN, "microneutralization.csv"))
bb1 = pd.read_csv(os.path.join(IN, "binding_breadth_h1.csv")); bb1["subtype"] = "H1"
bb3 = pd.read_csv(os.path.join(IN, "binding_breadth_h3.csv")); bb3["subtype"] = "H3"
bb = pd.concat([bb1, bb3], ignore_index=True)
sn = pd.read_csv(os.path.join(IN, "neutralization_seqbased.csv"))
igm = pd.read_csv(os.path.join(IN, "igm_fold_change.csv"), dtype={"participant": str})
gc = pd.read_csv(os.path.join(IN, "gc_frequencies.csv"), dtype={"participant": str})
pb = pd.read_csv(os.path.join(IN, "plasmablast_frequencies.csv"), dtype={"participant": str})
ov = pd.read_csv(os.path.join(IN, "pb_gc_clonal_overlap.csv"))
cdr = pd.read_csv(os.path.join(IN, "cdrh3_diversity_index.csv"))
rep = pd.read_csv(os.path.join(IN, "repertoire_clonotype_counts.csv"))
sig = pd.read_csv(os.path.join(IN, "serum_igg_clonotypes.csv"))
mab = pd.read_csv(os.path.join(IN, "mab_binding_panels.csv"))

sp = sn.serum.str.extract(r"^(?P<arm>mRNA-1010|Fluarix)_(?P<pid>397-\d+)_d(?P<day>\d+)$")
sn = pd.concat([sn, sp], axis=1); sn["day"] = sn.day.astype(int)
sn["tp"] = np.where(sn.day == 0, "d0", np.where(sn.day == 29, "d29", "late"))
sn["l2"] = np.log2(sn.titer)
sn["subtype"] = sn.virus.str.extract(r"_(H\dN\d)$")[0]

# ----------------------------------------------------------------------------
# 2. Cohort sizes per file vs the summary table
# ----------------------------------------------------------------------------
log("\n" + "=" * 100); log("2. COHORT SIZES (unique participants per file and arm)"); log("=" * 100)
rows = []
def add(name, df, idcol, armcol="arm", stated=None):
    for arm in ARMS:
        n = df[df[armcol] == arm][idcol].nunique()
        rows.append(dict(file=name, arm=arm, n_unique=n, stated_in_summary=stated.get(arm) if stated else None))
add("elisa_igg_titers.csv", elisa, "participant", stated={"mRNA-1010": 38, "Fluarix": 37})
add("igm_fold_change.csv", igm, "participant", stated={"mRNA-1010": 38, "Fluarix": 37})
add("hai_titers.csv", hai, "participant", stated={"mRNA-1010": 14, "Fluarix": 15})
add("microneutralization.csv", mn, "participant", stated={"mRNA-1010": 14, "Fluarix": 15})
add("binding_breadth_h1/h3.csv", bb, "participant", stated={"mRNA-1010": 14, "Fluarix": 15})
add("neutralization_seqbased.csv", sn, "pid", stated={"mRNA-1010": 13, "Fluarix": 14})
add("gc_frequencies.csv", gc, "participant", stated={"mRNA-1010": 6, "Fluarix": 11})
add("plasmablast_frequencies.csv", pb, "participant", stated={"mRNA-1010": 6, "Fluarix": 11})
mab["donor"] = mab.mab_id.str.split(".").str[1]
add("mab_binding_panels.csv (donors)", mab, "donor")
cs = pd.DataFrame(rows); cs.to_csv(os.path.join(TAB, "cohort_sizes.csv"), index=False)
log(cs.to_string(index=False))
for arm in ARMS:
    ids = sorted(elisa[elisa.arm == arm].participant.unique())
    log(f"  ELISA participant numbers, {arm}: {ids}")

# ----------------------------------------------------------------------------
# 3. Data-integrity checks
# ----------------------------------------------------------------------------
log("\n" + "=" * 100); log("3. DATA-INTEGRITY CHECKS"); log("=" * 100)
issues = []
def issue(area, file, finding, evidence):
    issues.append(dict(area=area, file=file, finding=finding, evidence=evidence)); log(f"  - [{file}] {finding} :: {evidence}")

# 3a late-visit mapping inconsistent across HAI antigens
hp = hai.pivot_table(index=["antigen", "arm", "participant"], columns="timepoint", values="hai_titer")
wk17 = {ag: sorted(f"{a}:{p}" for (a, p) in hp.loc[ag][hp.loc[ag].wk17.notna()].index) for ag in hp.index.levels[0]}
issue("visit mapping", "hai_titers.csv",
      "Week-17 attendees differ by antigen: B/Vic uses different participants than H1N1/H3N2/B/Yam",
      f"B/Vic wk17={wk17['B/Vic']} vs A/H1N1 wk17={wk17['A/H1N1']}")
late_sn = sorted(sn[sn.day == 121].pid.unique())
issue("visit mapping", "neutralization_seqbased.csv vs hai/microneutralization",
      "d121 (wk17) sera used for participants whose HAI/MN late value is wk26",
      f"seq-neut d121 participants={late_sn}; HAI/MN wk17 participants=397-009,018 (Fluarix), 397-010,023 (mRNA)")
# 3b unrounded HAI value repeated
v = hai[(hai.participant == "016") & (hai.antigen == "A/H1N1")][["timepoint", "hai_titer"]].values.tolist()
issue("possible imputation", "hai_titers.csv",
      "Only unrounded HAI values in file (226.27417 = 160*sqrt2) appear at both wk0 and wk26 for one participant (baseline carried forward?)",
      f"Fluarix 016 A/H1N1: {v}")
odd = hai[~hai.hai_titer.round(5).isin([5, 7, 10, 14, 20, 28, 40, 57, 80, 113, 160, 226, 226.27417, 320, 453, 640])]
issue("non-grid value", "hai_titers.csv", "HAI value off the two-fold/geometric-mean dilution grid",
      odd[["antigen", "timepoint", "arm", "participant", "hai_titer"]].to_dict("records"))
# 3c GC file has two unlabeled blocks
gc["block"] = gc.groupby(["timepoint", "arm", "participant"]).cumcount() + 1
issue("unlabelled duplicate series", "gc_frequencies.csv",
      "Every (timepoint, arm, participant) key appears twice with different values; no column identifies what the second series is",
      f"rows={len(gc)}, unique keys={gc[['timepoint','arm','participant']].drop_duplicates().shape[0]}; e.g. wk0 Fluarix 001 = {gc[(gc.timepoint=='wk0')&(gc.participant=='001')].pct_ha_specific_igg_gc.round(3).tolist()}")
issue("schedule mismatch", "gc_frequencies.csv / plasmablast_frequencies.csv",
      "Timepoints in file (wk0, wk2, wk8, wk17, wk26) do not match the stated FNA schedule (weeks 1, 2, 4, 8, 17, 26)",
      f"gc timepoints={sorted(gc.timepoint.unique())}; pb timepoints={sorted(pb.timepoint.unique())}")
fna_ids = set(gc.participant)
extra = sorted(set(pb.participant) - fna_ids)
issue("cohort provenance", "plasmablast_frequencies.csv",
      "Contains participants outside the stated FNA cohort (6 mRNA / 11 Fluarix); several are reported at lower numeric precision",
      f"extra participants={extra}; pb n per arm={pb.groupby('arm').participant.nunique().to_dict()}")
issue("cohort size", "igm_fold_change.csv",
      "IgM file has the HAI-subset participants (14/15), not the 38/37 stated for 'Binding antibody (ELISA, IgM)'",
      f"n={igm.groupby('arm').participant.nunique().to_dict()}")
issue("identifier format", "igm_fold_change.csv / pb_gc_clonal_overlap.csv",
      "IDs deviate from 397-0NN convention", f"igm has '{[p for p in igm.participant.unique() if len(p)!=3]}'; overlap file uses {ov.Participant.tolist()}")
bad = [v for v in sn.virus.unique() if re.search(r"/\d{5,}_", v)]
issue("virus naming", "neutralization_seqbased.csv", "Malformed isolate year", bad)
issue("panel identity", "microneutralization.csv / hai_titers.csv / elisa_igg_titers.csv",
      "Virus/antigen identities for 'homologous', 'heterologous', 'A/H1N1', 'A/H1' etc. are not given; bead-array file has no timepoint",
      "labels only; 'homologous' is defined relative to mRNA-1010 antigens (trial_summary.md)")
# MN ceiling
mt = mn[mn.measure == "titer"]
ceil = mt.groupby(["panel", "timepoint", "arm"]).apply(lambda g: f"{(g.value>=1280).sum()}/{len(g)}", include_groups=False)
issue("assay ceiling", "microneutralization.csv", "Titres capped at 1280 -> fold-rises censored",
      ceil.to_dict())
# seq-neut censoring
cens = pd.crosstab([sn.arm, sn.tp], sn.titer_bound)
issue("assay range", "neutralization_seqbased.csv", "Values at assay limits ('upper' = at/below lowest dilution; 'lower' = at/above highest)",
      cens.to_dict())
missing = sn.groupby("arm").apply(lambda g: 96 * g.serum.nunique() - len(g), include_groups=False).to_dict()
issue("missingness", "neutralization_seqbased.csv", "Serum x virus combinations missing", missing)
pd.DataFrame(issues).to_csv(os.path.join(TAB, "data_integrity_issues.csv"), index=False)

# ----------------------------------------------------------------------------
# 4. HAI
# ----------------------------------------------------------------------------
log("\n" + "=" * 100); log("4. HAI (hai_titers.csv)"); log("=" * 100)
hp = hai.pivot_table(index=["antigen", "arm", "participant"], columns="timepoint", values="hai_titer").reset_index()
hp["late"] = hp.wk26.fillna(hp.wk17)
rows = []
for ag in ["A/H1N1", "A/H3N2", "B/Vic", "B/Yam"]:
    for arm in ARMS:
        s = hp[(hp.antigen == ag) & (hp.arm == arm)]
        s4 = s.dropna(subset=["wk0", "wk4"])
        fr = s4.wk4 / s4.wk0
        sc = int(((fr >= 4) & (s4.wk4 >= 40)).sum())
        g0 = gm_ci(s.wk0); g4 = gm_ci(s.wk4); gl = gm_ci(s.late.dropna()); gf = gm_ci(fr)
        rows.append(dict(antigen=ag, arm=arm, n=len(s4), GMT_d0=g0[0], GMT_d29=g4[0], GMT_d29_lo=g4[1], GMT_d29_hi=g4[2],
                         GMT_late=gl[0], GMFR_d29=gf[0], SCR_k=sc, SCR_pct=100 * sc / len(s4),
                         SCR_lo=100 * wilson(sc, len(s4))[0], SCR_hi=100 * wilson(sc, len(s4))[1],
                         SP40_d0=int((s.wk0 >= 40).sum()), SP40_d29=int((s.wk4 >= 40).sum()),
                         SD_log2_d29=np.log2(s.wk4).std(ddof=1)))
    a = hp[(hp.antigen == ag) & (hp.arm == "mRNA-1010")]; b = hp[(hp.antigen == ag) & (hp.arm == "Fluarix")]
    for tp in ["wk0", "wk4", "late"]:
        g = welch_log2(a[tp].dropna(), b[tp].dropna())
        rows.append(dict(antigen=ag, arm=f"GMR mRNA/Fluarix {tp}", GMT_d29=g[0], GMT_d29_lo=g[1], GMT_d29_hi=g[2], p=g[3]))
    # SCR difference and Fisher
    ka = int((((a.wk4 / a.wk0) >= 4) & (a.wk4 >= 40)).sum()); na_ = int(a.dropna(subset=["wk0","wk4"]).shape[0])
    kb = int((((b.wk4 / b.wk0) >= 4) & (b.wk4 >= 40)).sum()); nb_ = int(b.dropna(subset=["wk0","wk4"]).shape[0])
    p = stats.fisher_exact([[ka, na_ - ka], [kb, nb_ - kb]]).pvalue
    rows.append(dict(antigen=ag, arm="SCR diff (mRNA - Fluarix), Fisher p", SCR_pct=100 * (ka / na_ - kb / nb_), p=p))
haiT = pd.DataFrame(rows); haiT.to_csv(os.path.join(TAB, "hai_summary.csv"), index=False)
log(haiT.round(3).to_string(index=False))

# ----------------------------------------------------------------------------
# 5. ELISA IgG
# ----------------------------------------------------------------------------
log("\n" + "=" * 100); log("5. ELISA IgG EC50 (elisa_igg_titers.csv)"); log("=" * 100)
ep = elisa[elisa.measure == "ec50"].pivot_table(index=["antigen", "arm", "participant"], columns="timepoint", values="value").reset_index()
ep["late"] = ep.wk26.fillna(ep.wk17)
rows = []
for ag in ["A/H1", "A/H3", "B/Vic", "B/Yam"]:
    for arm in ARMS:
        s = ep[(ep.antigen == ag) & (ep.arm == arm)]
        fr = s.wk4 / s.wk0; frl = s.late / s.wk0
        rows.append(dict(antigen=ag, arm=arm, n=len(s), GMT_d0=gmt(s.wk0), GMT_d29=gmt(s.wk4), GMT_late=gmt(s.late),
                         GMFR_d29=gmt(fr), GMFR_late=gmt(frl), pct_4fold_d29=100 * (fr >= 4).mean()))
    a = ep[(ep.antigen == ag) & (ep.arm == "mRNA-1010")]; b = ep[(ep.antigen == ag) & (ep.arm == "Fluarix")]
    for tp in ["wk0", "wk4", "late"]:
        g = welch_log2(a[tp], b[tp])
        rows.append(dict(antigen=ag, arm=f"GMR {tp}", GMT_d29=g[0], GMT_late=None, GMFR_d29=None, GMFR_late=None,
                         pct_4fold_d29=None, n=None, GMT_d0=None, lo=g[1], hi=g[2], p=g[3]))
elT = pd.DataFrame(rows); elT.to_csv(os.path.join(TAB, "elisa_summary.csv"), index=False)
log(elT.round(3).to_string(index=False))

# ----------------------------------------------------------------------------
# 6. Microneutralisation
# ----------------------------------------------------------------------------
log("\n" + "=" * 100); log("6. MICRONEUTRALISATION (microneutralization.csv)"); log("=" * 100)
mp = mt.pivot_table(index=["panel", "arm", "participant"], columns="timepoint", values="value").reset_index()
mp["late"] = mp.wk26.fillna(mp.wk17)
rows = []
for panel in ["homologous", "heterologous"]:
    for arm in ARMS:
        s = mp[(mp.panel == panel) & (mp.arm == arm)]
        fr = s.wk4 / s.wk0; frl = s.late / s.wk0
        rows.append(dict(panel=panel, arm=arm, n=len(s), GMT_d0=gmt(s.wk0), GMT_d29=gmt(s.wk4), GMT_late=gmt(s.late),
                         GMFR_d29=gmt(fr), GMFR_late=gmt(frl), n_4fold_d29=int((fr >= 4).sum()),
                         n_at_ceiling_d0=int((s.wk0 >= 1280).sum()), n_at_ceiling_d29=int((s.wk4 >= 1280).sum())))
    a = mp[(mp.panel == panel) & (mp.arm == "mRNA-1010")]; b = mp[(mp.panel == panel) & (mp.arm == "Fluarix")]
    g = welch_log2(a.wk4 / a.wk0, b.wk4 / b.wk0)
    k1, n1 = int(((a.wk4 / a.wk0) >= 4).sum()), len(a); k2, n2 = int(((b.wk4 / b.wk0) >= 4).sum()), len(b)
    rows.append(dict(panel=panel, arm="GMFR ratio mRNA/Fluarix d29", GMFR_d29=g[0], lo=g[1], hi=g[2], p=g[3],
                     fisher_p_4fold=stats.fisher_exact([[k1, n1 - k1], [k2, n2 - k2]]).pvalue))
mnT = pd.DataFrame(rows); mnT.to_csv(os.path.join(TAB, "microneutralization_summary.csv"), index=False)
log(mnT.round(3).to_string(index=False))

# ----------------------------------------------------------------------------
# 7. Bead-array binding breadth
# ----------------------------------------------------------------------------
log("\n" + "=" * 100); log("7. BEAD-ARRAY BINDING BREADTH (binding_breadth_h1/h3.csv; log2 fold-change MFI, timepoint not stated)"); log("=" * 100)
rows = []
for (st, strain), g in bb.groupby(["subtype", "strain"], sort=False):
    a = g[g.arm == "mRNA-1010"].log2_fold_change_mfi; b = g[g.arm == "Fluarix"].log2_fold_change_mfi
    t = stats.ttest_ind(a, b, equal_var=False)
    diff = a.mean() - b.mean(); se = math.sqrt(a.var(ddof=1) / len(a) + b.var(ddof=1) / len(b))
    rows.append(dict(subtype=st, strain=strain, n_m=len(a), n_f=len(b), mean_log2FC_mRNA=a.mean(), mean_log2FC_Fluarix=b.mean(),
                     diff_log2=diff, diff_lo=diff - 1.96 * se, diff_hi=diff + 1.96 * se,
                     fold_mRNA=2 ** a.mean(), fold_Fluarix=2 ** b.mean(), welch_p=t.pvalue,
                     mwu_p=stats.mannwhitneyu(a, b).pvalue))
bbT = pd.DataFrame(rows); bbT.to_csv(os.path.join(TAB, "binding_breadth_summary.csv"), index=False)
log(bbT.round(3).to_string(index=False))

# ----------------------------------------------------------------------------
# 8. Sequencing-based neutralisation (96 viruses)
# ----------------------------------------------------------------------------
log("\n" + "=" * 100); log("8. SEQUENCING-BASED NEUTRALISATION (neutralization_seqbased.csv)"); log("=" * 100)
EGG_TAG = re.compile(r"egg_|X-307A|X-223A|NIB-88|IVR-238")
def year_of(v):
    m = re.search(r"/(\d{4})(\d*)(?:egg|X-\d+A|NIB-\d+|_IVR-\d+)?_H", v)
    y = int(m.group(1)) if m else np.nan
    return 2023 if "202023" in v else y
def category(v):
    st = v[-4:]; y = year_of(v)
    if EGG_TAG.search(v): return f"{st} egg-propagated reassortant/egg isolate (labelled)"
    if v.startswith("A/Wisconsin/67/2022"): return "H1N1 mRNA-1010 H1 antigen, cell-type equivalent"
    if v.startswith("A/Wisconsin/588/2019"): return "H1N1 Fluarix 2022-23 H1, cell-type equivalent"
    if v.startswith("A/Darwin/6/2021"): return "H3N2 mRNA-1010 H3 antigen (cell-type)"
    if v.startswith("A/Darwin/9/2021"): return "H3N2 Fluarix 2022-23 H3 (egg-type reference)"
    if y >= 2023: return f"{st} circulating isolates 2023-24 (post-vaccination drift)"
    if y == 2022: return f"{st} 2022 isolates/reference viruses"
    return f"{st} historical wild-type (<=2020)"
vir = pd.DataFrame({"virus": sn.virus.unique()})
vir["subtype"] = vir.virus.str[-4:]; vir["year"] = vir.virus.map(year_of); vir["category"] = vir.virus.map(category)
vir.to_csv(os.path.join(TAB, "seqneut_virus_categories.csv"), index=False)
log(vir.groupby("category").virus.count().to_string())

w = sn.pivot_table(index=["virus", "arm", "pid"], columns="tp", values="l2").reset_index()
rows = []
for v_, g in w.groupby("virus"):
    a = g[g.arm == "mRNA-1010"]; b = g[g.arm == "Fluarix"]
    r = dict(virus=v_, category=category(v_))
    for arm, s in [("m", a), ("f", b)]:
        r[f"{arm}_GMT_d0"] = 2 ** s.d0.mean(); r[f"{arm}_GMT_d29"] = 2 ** s.d29.mean(); r[f"{arm}_GMT_late"] = 2 ** s.late.mean()
        r[f"{arm}_GMFR_d29"] = 2 ** (s.d29 - s.d0).mean(); r[f"{arm}_GMFR_late"] = 2 ** (s.late - s.d0).mean()
        r[f"{arm}_pct4x_d29"] = 100 * ((s.d29 - s.d0) >= 2).mean()
    r["GMR_d0"] = 2 ** (a.d0.mean() - b.d0.mean()); r["GMR_d29"] = 2 ** (a.d29.mean() - b.d29.mean())
    r["GMR_late"] = 2 ** (a.late.mean() - b.late.mean())
    r["p_GMFR_d29"] = stats.ttest_ind((a.d29 - a.d0).dropna(), (b.d29 - b.d0).dropna(), equal_var=False).pvalue
    rows.append(r)
pv = pd.DataFrame(rows); pv.to_csv(os.path.join(TAB, "seqneut_per_virus.csv"), index=False)
log(f"  per-virus table: {len(pv)} viruses -> tables/seqneut_per_virus.csv")
log(f"  viruses with nominal p<0.05 for GMFR difference: {int((pv.p_GMFR_d29<0.05).sum())} of {len(pv)} "
    f"(H1N1: {int(((pv.p_GMFR_d29<0.05)&pv.virus.str.endswith('H1N1')).sum())}/13; H3N2: {int(((pv.p_GMFR_d29<0.05)&pv.virus.str.endswith('H3N2')).sum())}/83)")
h3c = pv[pv.category.str.startswith("H3N2 circulating")]
log(f"  H3N2 2023-24 isolates (n={len(h3c)}): d29 GMR<1 for {int((h3c.GMR_d29<1).sum())}; baseline GMR<1 for {int((h3c.GMR_d0<1).sum())}; "
    f"median GMR d0={h3c.GMR_d0.median():.2f}, d29={h3c.GMR_d29.median():.2f}, late={h3c.GMR_late.median():.2f}")
h1c = pv[pv.category.str.startswith("H1N1 circulating")]
log(f"  H1N1 2023 isolates (n={len(h1c)}): median GMR d0={h1c.GMR_d0.median():.2f}, d29={h1c.GMR_d29.median():.2f}, late={h1c.GMR_late.median():.2f}; "
    f"median GMFR m={h1c.m_GMFR_d29.median():.2f} f={h1c.f_GMFR_d29.median():.2f}")

# participant-level category means + ANCOVA
sn["category"] = sn.virus.map(category)
pc = sn.groupby(["category", "arm", "pid", "tp"]).l2.mean().unstack("tp").reset_index()
rows = []
for cat, g in pc.groupby("category"):
    a = g[g.arm == "mRNA-1010"]; b = g[g.arm == "Fluarix"]
    nv = vir[vir.category == cat].shape[0]
    r = dict(category=cat, n_viruses=nv, n_m=len(a), n_f=len(b))
    for tp in ["d0", "d29", "late"]:
        gg = welch_log2(2 ** a[tp], 2 ** b[tp]); r[f"GMR_{tp}"] = gg[0]; r[f"GMR_{tp}_lo"] = gg[1]; r[f"GMR_{tp}_hi"] = gg[2]; r[f"p_{tp}"] = gg[3]
    gf = welch_log2(2 ** (a.d29 - a.d0), 2 ** (b.d29 - b.d0))
    r["GMFR_m"] = 2 ** (a.d29 - a.d0).mean(); r["GMFR_f"] = 2 ** (b.d29 - b.d0).mean()
    r["GMFR_ratio"] = gf[0]; r["GMFR_ratio_lo"] = gf[1]; r["GMFR_ratio_hi"] = gf[2]; r["p_GMFR"] = gf[3]
    # ANCOVA: d29 ~ arm + d0 ; late ~ arm + d0
    for tp in ["d29", "late"]:
        X = pd.DataFrame({"y": pd.concat([a[tp], b[tp]]), "arm": [1] * len(a) + [0] * len(b), "base": pd.concat([a.d0, b.d0])}).dropna()
        Xm = np.column_stack([np.ones(len(X)), X.arm, X.base]); beta, res, rk, _ = np.linalg.lstsq(Xm, X.y, rcond=None)
        resid = X.y - Xm @ beta; dof = len(X) - 3; s2 = (resid ** 2).sum() / dof
        cov = s2 * np.linalg.inv(Xm.T @ Xm); se = math.sqrt(cov[1, 1]); t = stats.t.ppf(0.975, dof)
        r[f"adjGMR_{tp}"] = 2 ** beta[1]; r[f"adjGMR_{tp}_lo"] = 2 ** (beta[1] - t * se); r[f"adjGMR_{tp}_hi"] = 2 ** (beta[1] + t * se)
        r[f"adj_p_{tp}"] = 2 * stats.t.sf(abs(beta[1] / se), dof); r[f"resid_SD_log2_{tp}"] = math.sqrt(s2)
        r[f"raw_SD_log2_{tp}"] = X.y.std(ddof=1)
    rows.append(r)
catT = pd.DataFrame(rows); catT.to_csv(os.path.join(TAB, "seqneut_category_ancova.csv"), index=False)
show = ["category", "n_viruses", "n_m", "n_f", "GMR_d0", "GMR_d29", "GMR_d29_lo", "GMR_d29_hi", "GMFR_m", "GMFR_f", "p_GMFR",
        "adjGMR_d29", "adjGMR_d29_lo", "adjGMR_d29_hi", "adj_p_d29", "GMR_late", "adjGMR_late", "adjGMR_late_lo", "adjGMR_late_hi", "resid_SD_log2_d29"]
log(catT[show].round(3).to_string(index=False))

# breadth: per participant fraction of 2023-24 isolates with >=4-fold rise
rows = []
for st in ["H1N1", "H3N2"]:
    cat = f"{st} circulating isolates 2023-24 (post-vaccination drift)"
    s = sn[sn.category == cat].pivot_table(index=["arm", "pid", "virus"], columns="tp", values="l2").reset_index()
    s["rise4"] = (s.d29 - s.d0) >= 2
    f = s.groupby(["arm", "pid"]).rise4.mean().reset_index()
    a = f[f.arm == "mRNA-1010"].rise4; b = f[f.arm == "Fluarix"].rise4
    rows.append(dict(subtype=st, metric="fraction of 2023-24 isolates with >=4-fold rise at d29 (per participant)",
                     median_m=a.median(), median_f=b.median(), mean_m=a.mean(), mean_f=b.mean(),
                     n_m_any_strain=int((a > 0).sum()), n_m=len(a), n_f_any_strain=int((b > 0).sum()), n_f=len(b),
                     mwu_p=stats.mannwhitneyu(a, b).pvalue))
brT = pd.DataFrame(rows); brT.to_csv(os.path.join(TAB, "seqneut_breadth_4fold.csv"), index=False)
log(brT.round(3).to_string(index=False))

# egg-adapted vs wild-type pairs
pairs = [("A/Cambodia/e0826360/2020egg_H3N2", "A/Cambodia/e0826360/2020_H3N2"),
         ("A/HongKong/4801/2014egg_H3N2", "A/HongKong/4801/2014_H3N2"),
         ("A/Singapore/INFIMH-16-0019/2016X-307A_H3N2", "A/Singapore/INFIMH-16-0019/2016_H3N2"),
         ("A/Texas/50/2012X-223A_H3N2", "A/Texas/50/2012_H3N2"),
         ("A/Switzerland/9715293/2013NIB-88_H3N2", "A/Switzerland/9715293/2013_H3N2"),
         ("A/Victoria/4897/2022_IVR-238_H1N1", "A/Wisconsin/67/2022_H1N1"),
         ("A/Darwin/9/2021_H3N2", "A/Darwin/6/2021_H3N2")]
wide = sn.pivot_table(index=["arm", "pid", "tp"], columns="virus", values="l2")
rows = []
for e, c in pairs:
    for arm in ARMS:
        x = wide.loc[arm]
        dd = (x[e] - x[c]).unstack("tp")
        fe = (x[e].unstack("tp").d29 - x[e].unstack("tp").d0); fc = (x[c].unstack("tp").d29 - x[c].unstack("tp").d0)
        rows.append(dict(egg_or_reference=e, wild_type_or_cell=c, arm=arm, titre_ratio_d0=2 ** dd.d0.mean(),
                         titre_ratio_d29=2 ** dd.d29.mean(), GMFR_eggtype=2 ** fe.mean(), GMFR_celltype=2 ** fc.mean()))
eggT = pd.DataFrame(rows); eggT.to_csv(os.path.join(TAB, "seqneut_egg_vs_wildtype.csv"), index=False)
log(eggT.round(2).to_string(index=False))

# H3N2 drift gradient (within the 64 post-vaccination 2023-24 H3N2 isolates only)
# distance proxy = arm-pooled d29 log2 titre vs A/Darwin/6/2021 minus that vs the virus (larger = further from vaccine H3)
pooled = sn[(sn.subtype == "H3N2") & (sn.tp == "d29")].groupby("virus").l2.mean()
dg = pv[pv.category.str.startswith("H3N2 circulating")].set_index("virus").copy()
dg["distance_log2"] = pooled["A/Darwin/6/2021_H3N2"] - pooled[dg.index]
rho = {c: stats.spearmanr(dg.distance_log2, np.log2(dg[c])) for c in ["GMR_d29", "GMR_late"]}
rho["GMFR_ratio"] = stats.spearmanr(dg.distance_log2, np.log2(dg.m_GMFR_d29 / dg.f_GMFR_d29))
for k, v_ in rho.items(): log(f"  H3N2 2023-24 drift gradient: Spearman(distance, log2 {k}) rho={v_.correlation:.2f} p={v_.pvalue:.3f} (n={len(dg)})")
dg["tertile"] = pd.qcut(dg.distance_log2, 3, labels=["closest third", "middle third", "most distant third"])
dgt = dg.groupby("tertile", observed=True).agg(n=("GMR_d29", "size"), mean_distance_log2=("distance_log2", "mean"),
    GMT_Fluarix_d29=("f_GMT_d29", gmt), GMT_mRNA_d29=("m_GMT_d29", gmt), GMR_d29=("GMR_d29", gmt),
    GMFR_mRNA=("m_GMFR_d29", gmt), GMFR_Fluarix=("f_GMFR_d29", gmt), GMR_late=("GMR_late", gmt))
dgt.to_csv(os.path.join(TAB, "seqneut_h3_drift_gradient.csv"))
log(dgt.round(2).to_string())
log(dg.sort_values("distance_log2", ascending=False).head(5)[["distance_log2", "f_GMT_d29", "m_GMT_d29", "GMR_d29", "m_GMFR_d29", "f_GMFR_d29"]].round(2).to_string())

# ----------------------------------------------------------------------------
# 9. Binding vs neutralisation concordance (same HAI-subset participants)
# ----------------------------------------------------------------------------
log("\n" + "=" * 100); log("9. BINDING vs FUNCTIONAL READOUTS - arm contrast by readout"); log("=" * 100)
def gmfr_ratio_elisa(ag, ids=None):
    s = ep[ep.antigen == ag]
    if ids is not None: s = s[s.participant.isin(ids)]
    a = s[s.arm == "mRNA-1010"]; b = s[s.arm == "Fluarix"]
    return gmt(a.wk4 / a.wk0), gmt(b.wk4 / b.wk0)
subset_ids = set(int(p) for p in hai.participant.unique())
rows = []
for st, elag, haiag, bbstrain, snv in [("H3", "A/H3", "A/H3N2", "A/Darwin/6/2021", "A/Darwin/6/2021_H3N2"),
                                        ("H1", "A/H1", "A/H1N1", "A/Wisconsin/67/2022", "A/Wisconsin/67/2022_H1N1")]:
    m_all, f_all = gmfr_ratio_elisa(elag); m_sub, f_sub = gmfr_ratio_elisa(elag, subset_ids)
    rows.append(dict(subtype=st, readout="ELISA IgG GMFR d29 (all, n=38/37)", mRNA=m_all, Fluarix=f_all, ratio=m_all / f_all))
    rows.append(dict(subtype=st, readout="ELISA IgG GMFR d29 (HAI subset, n=14/15)", mRNA=m_sub, Fluarix=f_sub, ratio=m_sub / f_sub))
    r = bbT[(bbT.strain == bbstrain)].iloc[0]
    rows.append(dict(subtype=st, readout=f"Bead-array binding fold-change, {bbstrain}", mRNA=r.fold_mRNA, Fluarix=r.fold_Fluarix, ratio=r.fold_mRNA / r.fold_Fluarix))
    h = haiT[(haiT.antigen == haiag) & (haiT.arm.isin(ARMS))].set_index("arm")
    rows.append(dict(subtype=st, readout="HAI GMFR d29", mRNA=h.loc["mRNA-1010", "GMFR_d29"], Fluarix=h.loc["Fluarix", "GMFR_d29"],
                     ratio=h.loc["mRNA-1010", "GMFR_d29"] / h.loc["Fluarix", "GMFR_d29"]))
    q = pv[pv.virus == snv].iloc[0]
    rows.append(dict(subtype=st, readout=f"Neutralisation GMFR d29, {snv}", mRNA=q.m_GMFR_d29, Fluarix=q.f_GMFR_d29, ratio=q.m_GMFR_d29 / q.f_GMFR_d29))
    cat = catT[catT.category.str.startswith(f"{st}N") & catT.category.str.contains("2023-24")].iloc[0]
    rows.append(dict(subtype=st, readout=f"Neutralisation GMFR d29, mean over {cat.n_viruses} 2023-24 isolates", mRNA=cat.GMFR_m, Fluarix=cat.GMFR_f, ratio=cat.GMFR_ratio))
conc = pd.DataFrame(rows); conc.to_csv(os.path.join(TAB, "binding_vs_neutralisation.csv"), index=False)
log(conc.round(2).to_string(index=False))

# ----------------------------------------------------------------------------
# 10. IgM
# ----------------------------------------------------------------------------
log("\n" + "=" * 100); log("10. IgM fold-change (igm_fold_change.csv; timepoint not stated)"); log("=" * 100)
rows = []
for ag in ["H1", "H3", "B/Vic", "B/Yam"]:
    a = igm[(igm.antigen == ag) & (igm.arm == "mRNA-1010")].fold_change; b = igm[(igm.antigen == ag) & (igm.arm == "Fluarix")].fold_change
    rows.append(dict(antigen=ag, n_m=len(a), n_f=len(b), GMFR_m=gmt(a), GMFR_f=gmt(b), n_rise_m=int((a > 1).sum()), n_rise_f=int((b > 1).sum()),
                     mwu_p=stats.mannwhitneyu(a, b).pvalue))
igT = pd.DataFrame(rows); igT.to_csv(os.path.join(TAB, "igm_summary.csv"), index=False)
log(igT.round(3).to_string(index=False))
log("  Fluarix 005 IgM fold-changes:", igm[igm.participant == "005"][["antigen", "fold_change"]].round(1).values.tolist())

# ----------------------------------------------------------------------------
# 11. Cellular / repertoire / mAb (mechanistic, exploratory)
# ----------------------------------------------------------------------------
log("\n" + "=" * 100); log("11. MECHANISTIC READOUTS (exploratory)"); log("=" * 100)
rows = []
for blk in [1, 2]:
    for tp in ["wk0", "wk2", "wk8", "wk17", "wk26"]:
        s = gc[(gc.block == blk) & (gc.timepoint == tp)]
        a = s[s.arm == "mRNA-1010"].pct_ha_specific_igg_gc; b = s[s.arm == "Fluarix"].pct_ha_specific_igg_gc
        rows.append(dict(readout=f"GC HA-specific IgG % (series {blk})", timepoint=tp, n_m=len(a), n_f=len(b), median_m=a.median(), median_f=b.median(),
                         mwu_p=stats.mannwhitneyu(a, b).pvalue if len(a) > 1 and len(b) > 1 else np.nan))
for sub, s0 in [("all rows", pb), ("stated FNA cohort only", pb[pb.participant.isin(fna_ids)])]:
    for tp in ["wk0", "wk2", "wk8", "wk17", "wk26"]:
        s = s0[s0.timepoint == tp]
        a = s[s.arm == "mRNA-1010"].pct_plasmablast; b = s[s.arm == "Fluarix"].pct_plasmablast
        rows.append(dict(readout=f"Plasmablast % ({sub})", timepoint=tp, n_m=len(a), n_f=len(b), median_m=a.median(), median_f=b.median(),
                         mwu_p=stats.mannwhitneyu(a, b).pvalue if len(a) > 1 and len(b) > 1 else np.nan))
for metric in rep.metric.unique():
    a = rep[(rep.metric == metric) & (rep.arm == "mRNA-1010")].value; b = rep[(rep.metric == metric) & (rep.arm == "Fluarix")].value
    rows.append(dict(readout=f"Serum IgG repertoire: {metric}", timepoint="(post)", n_m=len(a), n_f=len(b), median_m=a.median(), median_f=b.median(),
                     mwu_p=stats.mannwhitneyu(a, b).pvalue))
for tp in ["wk0", "wk4", "wk26"]:
    a = cdr[(cdr.timepoint == tp) & (cdr.arm == "mRNA-1010")].diversity_index; b = cdr[(cdr.timepoint == tp) & (cdr.arm == "Fluarix")].diversity_index
    rows.append(dict(readout="CDRH3 diversity index", timepoint=tp, n_m=len(a), n_f=len(b), median_m=a.median(), median_f=b.median(),
                     mwu_p=stats.mannwhitneyu(a, b).pvalue))
mechT = pd.DataFrame(rows); mechT.to_csv(os.path.join(TAB, "mechanistic_summary.csv"), index=False)
log(mechT.round(3).to_string(index=False))
ov["pct_GC_clones_overlapping_PB"] = ov["Percentage of overlapping clones out of GC B cell clones"].str.rstrip("%").astype(float)
log("  PB-GC clonal overlap (pb_gc_clonal_overlap.csv):")
log(ov[["Participant", "Number of GC B cell sequences", "Number of GC B cell clones", "pct_GC_clones_overlapping_PB"]].to_string(index=False))

# mAbs: donor-level (the donor is the unit of inference)
mw = mab.pivot_table(index=["panel", "arm", "donor", "mab_id"], columns="antigen", values="fold_over_control")
rows = []
for thr in [10]:
    for panel in ["group_I", "group_II"]:
        x = mw.loc[panel].dropna(axis=1, how="all").drop(columns=["SARS-CoV-2 RBD"])
        pos = x >= thr
        for (arm, donor), g in pos.groupby(level=["arm", "donor"]):
            r = dict(threshold=thr, panel=panel, arm=arm, donor=donor, n_mabs=len(g))
            for c in x.columns: r[c] = round(100 * g[c].mean(), 1)
            if panel == "group_I":
                r["Wis588_not_Vic4897_%"] = round(100 * (g["A/Wisconsin/588/2019"] & ~g["A/Victoria/4897/2022"]).mean(), 1)
                r["Vic4897_not_Wis588_%"] = round(100 * (g["A/Victoria/4897/2022"] & ~g["A/Wisconsin/588/2019"]).mean(), 1)
            rows.append(r)
mabT = pd.DataFrame(rows); mabT.to_csv(os.path.join(TAB, "mab_donor_summary.csv"), index=False)
log(mabT.to_string(index=False))
for panel in ["group_I", "group_II"]:
    x = mw.loc[panel].dropna(axis=1, how="all").drop(columns=["SARS-CoV-2 RBD"]); pos = x >= 10
    for arm in ARMS:
        g = pos.loc[arm]
        log(f"  {panel} {arm}: n mAbs={len(g)}; " + "; ".join(f"{c}: {int(g[c].sum())} ({100*g[c].mean():.0f}%)" for c in x.columns))

# ----------------------------------------------------------------------------
# 11b. Baseline-adjusted arm contrasts for HAI / MN / ELISA (ANCOVA on log2: post ~ arm + log2 baseline)
# ----------------------------------------------------------------------------
log("\n" + "=" * 100); log("11b. BASELINE-ADJUSTED GMRs (ANCOVA), mRNA-1010 / Fluarix"); log("=" * 100)
def ancova(df, post, pre="wk0"):
    X = df[["arm", pre, post]].dropna()
    y = np.log2(X[post].values.astype(float)); base = np.log2(X[pre].values.astype(float)); arm = (X.arm == "mRNA-1010").astype(float).values
    M = np.column_stack([np.ones(len(X)), arm, base]); beta = np.linalg.lstsq(M, y, rcond=None)[0]
    resid = y - M @ beta; dof = len(X) - 3; s2 = (resid ** 2).sum() / dof
    se = math.sqrt((s2 * np.linalg.inv(M.T @ M))[1, 1]); t = stats.t.ppf(0.975, dof)
    return 2 ** beta[1], 2 ** (beta[1] - t * se), 2 ** (beta[1] + t * se), 2 * stats.t.sf(abs(beta[1] / se), dof), len(X)
rows = []
for label, df, key in [("HAI", hp, "antigen"), ("ELISA IgG", ep, "antigen"), ("Microneutralisation", mp, "panel")]:
    for k in df[key].unique():
        sub = df[df[key] == k]
        for post in ["wk4", "late"]:
            g = ancova(sub, post)
            rows.append(dict(assay=label, antigen_or_panel=k, timepoint={"wk4": "d29", "late": "wk17/26"}[post],
                             adjGMR=g[0], lo=g[1], hi=g[2], p=g[3], n=g[4]))
adjT = pd.DataFrame(rows); adjT.to_csv(os.path.join(TAB, "baseline_adjusted_gmr_hai_mn_elisa.csv"), index=False)
log(adjT.round(3).to_string(index=False))

# ----------------------------------------------------------------------------
# 12. Sample-size inputs and calculations for the next studies
# ----------------------------------------------------------------------------
log("\n" + "=" * 100); log("12. SAMPLE-SIZE CALCULATIONS"); log("=" * 100)
z = stats.norm.ppf
rows = []
# (a) HAI GMT non-inferiority, margin 1.5, true GMR 1.0
sd_hai = haiT[haiT.arm.isin(ARMS)].groupby("antigen").SD_log2_d29.max()
for ag, sd in sd_hai.items():
    for pw in [0.90, 0.97]:
        n = 2 * sd ** 2 * (z(0.975) + z(pw)) ** 2 / math.log2(1.5) ** 2
        rows.append(dict(calc="HAI GMT NI (UB 95%CI comparator/mRNA <=1.5; true ratio 1.0)", input=f"{ag}: SD log2 d29 (max of arms)={sd:.2f}",
                         power=pw, n_per_arm_evaluable=math.ceil(n)))
# (b) HAI SCR non-inferiority, margin 10 percentage points, equal true SCR
for p in [0.3, 0.5]:
    for pw in [0.90, 0.97]:
        n = (z(0.975) + z(pw)) ** 2 * 2 * p * (1 - p) / 0.10 ** 2
        rows.append(dict(calc="HAI SCR NI (UB 95%CI comparator-mRNA <=10 pts)", input=f"true SCR both arms={p}", power=pw, n_per_arm_evaluable=math.ceil(n)))
# (c) heterologous neutralisation superiority (baseline-adjusted), from WU397 residual SD
for cat in ["H3N2 circulating isolates 2023-24 (post-vaccination drift)", "H1N1 circulating isolates 2023-24 (post-vaccination drift)"]:
    r = catT[catT.category == cat].iloc[0]
    for sd_name in ["resid_SD_log2_d29", "raw_SD_log2_d29", "resid_SD_log2_late"]:
        sd = r[sd_name]
        for tgt in [1.5, 1.3]:
            n = 2 * sd ** 2 * (z(0.975) + z(0.90)) ** 2 / math.log2(tgt) ** 2
            rows.append(dict(calc=f"Heterologous neutralisation superiority, {cat.split(' ')[0]} panel mean (two-sided 0.05, 90% power)",
                             input=f"{sd_name}={sd:.2f}; target GMR={tgt}", power=0.90, n_per_arm_evaluable=math.ceil(n)))
# (d) event-driven relative VE against antigenically mismatched strains (assumptions, not WU397 data)
for rve in [0.20, 0.25, 0.30]:
    th = (1 - rve) / (2 - rve)
    D = ((z(0.975) * 0.5 + z(0.90) * math.sqrt(th * (1 - th))) / (0.5 - th)) ** 2
    rows.append(dict(calc="Phase 3: mismatched-strain cases needed (1:1, LB 95%CI rVE>0, 90% power)", input=f"true rVE={rve:.0%}",
                     power=0.90, n_per_arm_evaluable=None, events_needed=math.ceil(D)))
    for ar, frac in [(0.02, 0.5), (0.03, 0.5), (0.02, 0.3)]:
        # expected mismatched-case rate averaged over arms
        rate = ar * frac * (1 + (1 - rve)) / 2
        rows.append(dict(calc="Phase 3: randomised N PER ARM implied (ASSUMED attack rate & mismatch fraction)",
                         input=f"rVE={rve:.0%}; comparator attack rate={ar:.0%}/season; mismatched share={frac:.0%}", power=0.90,
                         n_per_arm_evaluable=math.ceil(D / rate / 2), events_needed=math.ceil(D)))
# (e) challenge study
for p0, p1 in [(0.5, 0.2), (0.4, 0.15), (0.5, 0.3)]:
    pbar = (p0 + p1) / 2
    n = (z(0.975) * math.sqrt(2 * pbar * (1 - pbar)) + z(0.80) * math.sqrt(p0 * (1 - p0) + p1 * (1 - p1))) ** 2 / (p0 - p1) ** 2
    rows.append(dict(calc="Challenge study: comparator vs mRNA infection+illness proportion (two-sided 0.05, 80% power)",
                     input=f"comparator={p0:.0%}, mRNA={p1:.0%}", power=0.80, n_per_arm_evaluable=math.ceil(n)))
ssT = pd.DataFrame(rows); ssT.to_csv(os.path.join(TAB, "sample_size.csv"), index=False)
log(ssT.to_string(index=False))

# ----------------------------------------------------------------------------
# 13. Figures
# ----------------------------------------------------------------------------
try:
    import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    fig, axes = plt.subplots(1, 2, figsize=(14, 6))
    for ax, st in zip(axes, ["H1N1", "H3N2"]):
        s = pv[pv.virus.str.endswith(st)].copy()
        colors = {"circulating": "tab:red", "egg": "tab:orange", "historical": "tab:grey", "2022": "tab:purple"}
        def col(c):
            if "mRNA-1010" in c: return "tab:blue"
            if "Fluarix" in c: return "tab:green"
            if "egg" in c: return "tab:orange"
            if "circulating" in c: return "tab:red"
            if "2022" in c: return "tab:purple"
            return "tab:grey"
        ax.scatter(np.log2(s.f_GMFR_d29), np.log2(s.m_GMFR_d29), c=[col(c) for c in s.category], s=30, alpha=0.8)
        lim = [-0.2, 3.0]; ax.plot(lim, lim, "k--", lw=0.8); ax.set_xlim(lim); ax.set_ylim(lim)
        ax.set_xlabel("Fluarix: log2 GMFR d29/d0"); ax.set_ylabel("mRNA-1010: log2 GMFR d29/d0"); ax.set_title(f"{st}: per-virus neutralisation fold-rise")
        for _, r in s.iterrows():
            if any(k in r.virus for k in ["Darwin", "Wisconsin", "Victoria/4897", "Thailand/8", "Massachusetts"]):
                ax.annotate(r.virus.split("_")[0].replace("A/", ""), (np.log2(r.f_GMFR_d29), np.log2(r.m_GMFR_d29)), fontsize=7)
    from matplotlib.lines import Line2D
    leg = [Line2D([0], [0], marker="o", color="w", markerfacecolor=c, label=l, markersize=8) for c, l in
           [("tab:red", "2023-24 circulating isolates"), ("tab:purple", "2022 isolates/references"), ("tab:grey", "historical wild-type"),
            ("tab:orange", "egg-propagated / reassortant"), ("tab:blue", "mRNA-1010 antigen (cell-type)"), ("tab:green", "Fluarix 2022-23 antigen (H3: egg-type Darwin/9; H1: cell-type equivalent Wisconsin/588)")]]
    axes[1].legend(handles=leg, loc="lower right", fontsize=8)
    plt.tight_layout(); plt.savefig(os.path.join(FIG, "seqneut_gmfr_by_virus.png"), dpi=150); plt.close()

    fig, ax = plt.subplots(figsize=(9, 5))
    cats = catT.sort_values("category")
    y = np.arange(len(cats))
    ax.errorbar(cats.adjGMR_d29, y, xerr=[cats.adjGMR_d29 - cats.adjGMR_d29_lo, cats.adjGMR_d29_hi - cats.adjGMR_d29], fmt="o", label="d29 (baseline-adjusted)")
    ax.errorbar(cats.adjGMR_late, y + 0.25, xerr=[cats.adjGMR_late - cats.adjGMR_late_lo, cats.adjGMR_late_hi - cats.adjGMR_late], fmt="s", label="d121/181 (baseline-adjusted)")
    ax.axvline(1, color="k", lw=0.8); ax.set_xscale("log", base=2)
    ax.set_yticks(y + 0.12); ax.set_yticklabels(cats.category, fontsize=7); ax.set_xlabel("GMR mRNA-1010 / Fluarix (95% CI)")
    ax.legend(fontsize=8); plt.tight_layout(); plt.savefig(os.path.join(FIG, "seqneut_category_gmr.png"), dpi=150); plt.close()
    log("\n  figures written to /tmp/outputs/figures/")
except Exception as ex:
    log("figure generation failed:", ex)

open(os.path.join(OUT, "analysis_log.txt"), "w").write(LOG.getvalue())
log("\nDONE. Tables in /tmp/outputs/tables, log in /tmp/outputs/analysis_log.txt")
