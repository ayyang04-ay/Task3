**Recommendation:** Don't take a heterologous-protection claim forward on WU397. Its breadth signal either comes from binding antibody only or, for H1 neutralisation, is confounded by a newer H1 strain and site-based allocation and is gone by day 121–181. There is no H3N2 advantage. The next study should be a randomised, observer-blind, strain-matched immunogenicity study with a pre-registered drifted-strain neutralisation endpoint, used as the go/no-go. Only if it passes, run a drifted-strain human challenge study and then an event-driven relative-efficacy trial powered on sequence-confirmed, antigenically mismatched influenza.

# WU397 (mRNA-1010 vs Fluarix, 2022–23): what the data support, and the studies to run next

This document covers study design, specification and data interpretation only. It contains no laboratory or assay procedures.
I computed every number from the files in `/tmp/world/filesystem` with `/tmp/outputs/wu397_analysis.py`. The tables are in `/tmp/outputs/tables/` and the full printout is in `/tmp/outputs/analysis_log.txt`. §7 maps each number to its source, and §8 lists the facts I used that are not in the data package.
Conventions: GMR = geometric-mean ratio, mRNA-1010 ÷ Fluarix. Day 29 = the "wk4" visit. "Late" = wk17/26, which is day 121 or day 181. "Adjusted" means adjusted for each participant's baseline titre (ANCOVA on log2 titres). The study was non-randomised, so all p-values are nominal.

---

## 1. Bottom line

1. **What WU397 shows.**
   - mRNA-1010 produced more **binding** antibody than Fluarix. ELISA IgG GMR at day 29 was 2.66 for H1 and 3.04 for H3.
   - Bead-array binding rises were larger for all 21 H1/H3 strains tested. The largest gap was against A/Hong Kong/1/1968: 10.9-fold rise vs 1.15-fold.
   - In a 6-vs-11-person lymph-node subset, germinal-centre responses were larger and lasted longer.
2. **What it does not show: more functional antibody.**
   - By HAI, the accepted correlate, the adjusted day-29 GMRs were 1.01–1.54. Every 95% CI spans 1.
   - HAI seroconversion for H3N2 was 2/14 vs 2/15; for the two B strains it was 0–1 participants per arm.
   - H3N2 is the subtype that drives vaccine mismatch. Against 64 H3N2 isolates from 2023–24, neutralisation was not better with mRNA-1010: GMR 0.86 raw, 1.18 adjusted (95% CI 0.65–2.13).
   - mRNA-1010 neutralised its *own* H3 antigen less well than Fluarix did: GMR 0.51 (0.27–0.95).
3. **The one functional "breadth" signal can't be credited to the mRNA platform.** H1N1 neutralisation was about 2-fold higher at day 29 (adjusted GMR 2.06, 1.23–3.46, against six 2023 isolates). But:
   - That arm received a newer H1 strain than Fluarix.
   - Allocation was by site, with no randomisation and no blinding.
   - The same advantage appeared against old H1 strains, so it reflects a bigger response rather than broader coverage.
   - It was gone by day 121–181 (adjusted GMR 1.17, 0.77–1.77).
4. **Consequence.**
   - WU397 supports no heterologous claim, either immunological or clinical.
   - The next study has to remove the confounds and test breadth directly.
   - Protection then has to be shown with challenge or clinical endpoints. There is no established immune correlate of protection against drifted strains; HAI against the vaccine strain is a correlate only for matched strains.

## 2. Evidence table (WU397)

| Readout (source file) | n (mRNA / Fluarix) | Day-29 GMR, raw (95% CI) | Day-29 GMR, adjusted | Late GMR, adjusted | Reading |
|---|---|---|---|---|---|
| HAI A/H1N1 (`hai_titers.csv`) | 14/15 | 1.57 (0.92–2.71) | 1.54 (0.87–2.71) | 0.83 (0.47–1.46) | No difference |
| HAI A/H3N2 | 14/15 | 0.97 (0.46–2.06) | 1.06 (0.67–1.66) | 0.92 (0.60–1.41) | No difference |
| HAI B/Victoria | 13/15 | 1.09 (0.62–1.92) | 1.05 (0.71–1.56) | 1.06 (0.65–1.73) | No difference; almost no response in either arm (GMFR 1.08 / 1.05) |
| HAI B/Yamagata | 14/15 | 0.90 (0.57–1.41) | 1.01 (0.73–1.40) | 0.91 (0.63–1.31) | As above (GMFR 1.35 / 1.29) |
| ELISA IgG A/H1 (`elisa_igg_titers.csv`) | 38/37 | 2.66 (1.88–3.76) | 2.67 (2.01–3.53) | 1.51 (1.19–1.91) | Binding higher; gap roughly halves by late visit |
| ELISA IgG A/H3 | 38/37 | 3.04 (2.21–4.18) | 3.31 (2.47–4.44) | 2.06 (1.57–2.70) | Binding higher |
| ELISA IgG B/Victoria | 38/37 | 1.32 (0.94–1.84) | 1.35 (1.04–1.76) | 0.99 (0.78–1.26) | Small and transient |
| ELISA IgG B/Yamagata | 38/37 | 1.46 (1.05–2.05) | 1.38 (1.11–1.71) | 1.06 (0.88–1.29) | Small and transient |
| Microneutralisation (MN) "homologous" (`microneutralization.csv`) | 14/15 | 0.55 (0.22–1.40) | 0.68 (0.31–1.51) | 0.64 (0.30–1.37) | Virus not identified; 9/15 Fluarix day-29 titres at the 1280 assay ceiling |
| MN "heterologous" | 14/15 | 0.64 (0.24–1.70) | 1.17 (0.52–2.62) | 0.73 (0.37–1.45) | Virus not identified; baseline GMR 0.47 |
| Sequencing-based virus neutralisation (VN), six H1N1 isolates from 2023 (`neutralization_seqbased.csv`) | 13/14 | 1.86 (0.75–4.62) | **2.06 (1.23–3.46)** | 1.17 (0.77–1.77) | Higher at day 29 only |
| VN, A/Wisconsin/588/2019 (cell-type equivalent of Fluarix's 2022–23 H1) | 13/14 | 2.12 (0.80–5.63) | 2.44 (1.18–5.05) | 1.17 (0.62–2.23) | Equally higher on Fluarix's own H1, so a magnitude effect |
| VN, 64 H3N2 isolates, 2023–24 | 13/14 | 0.86 (0.44–1.68) | 1.18 (0.65–2.13) | 1.05 (0.65–1.68) | **No advantage** |
| VN, A/Darwin/6/2021 (mRNA-1010's own H3) | 13/14 | **0.51 (0.27–0.95)** | 0.62 (0.34–1.12) | 0.72 (0.40–1.31) | mRNA-1010 lower |
| Bead-array binding, 21 H1/H3 strains (`binding_breadth_h1/h3.csv`) | 14/15 | mRNA log2 fold-change higher for all 21; Welch p<0.05 for 12/12 H3 and 4/9 H1 strains | – | – | Binding only; sampling timepoint not stated |

## 3. Why WU397 cannot carry a heterologous claim

### 3.1 The two arms did not receive the same antigens
The trial summary says the mRNA-1010 strains were "selected by the sponsor for this study". It says Fluarix's composition was "per the manufacturer's labelling and was not set for this study", and that "homologous and heterologous panel designations throughout refer to the mRNA-1010 antigens".

| Component | mRNA-1010 in WU397 (trial_summary.md) | Fluarix QIV 2022–23 (WHO egg-based recommendation; external, see §8) | Matched? |
|---|---|---|---|
| H1N1 | A/Victoria/4897/2022-like: the strain WHO picked *a year later* for 2023–24 | A/Victoria/2570/2019-like (cell-type equivalent: A/Wisconsin/588/2019) | **No – different strain** |
| H3N2 | A/Darwin/6/2021-like (cell-type reference) | A/Darwin/9/2021-like (egg-type reference) | Same antigenic group; cell- vs egg-type |
| B/Victoria | B/Austria/1359417/2021-like | Same | Yes |
| B/Yamagata | B/Phuket/3073/2013-like | Same | Yes (lineage no longer circulating; see §8) |

- **"Heterologous" H1 isolates sit next to the mRNA arm's antigen.** In both arms' sera, the six 2023 H1N1 isolates behave like A/Wisconsin/67/2022, the cell-type equivalent of mRNA-1010's H1.
  - Fluarix day-29 GMTs: 193–319 against the isolates vs 197 against A/Wisconsin/67/2022.
  - mRNA-1010 day-29 GMTs: 431–557 vs 431.
  - Both arms' titres against the isolates are about 1.6–2.6-fold lower than against A/Wisconsin/588/2019, the Fluarix-like strain (506 for Fluarix, 1073 for mRNA-1010).
  - So the 2023 H1 "heterologous" comparison is effectively near-homologous for one arm and heterologous for the other.
- **Only the B components were matched.** Where the comparison is clean, there is no functional difference:
  - HAI adjusted GMR 1.05 (B/Victoria) and 1.01 (B/Yamagata).
  - ELISA 1.35 and 1.38 at day 29, falling to 0.99 and 1.06 late.

### 3.2 Open-label, site allocation, and the arms differed before vaccination
- **Allocation.** Participants were assigned by enrolment site. All 24 ELISA participants numbered 064–102 are mRNA-1010, while Fluarix participants are numbered 001–059. This pattern is consistent with site- or wave-based allocation.
- **Baseline imbalance in neutralisation.** Before vaccination, mRNA-arm sera neutralised every one of the 64 contemporary H3N2 isolates less well than Fluarix-arm sera: median per-virus baseline GMR 0.67, 64/64 below 1. The "heterologous" MN virus started at about half the titre (baseline GMR 0.47, 0.22–1.00).
- **Why this matters.** A low starting titre inflates fold-rise. That is why mRNA-1010's larger fold-rises do not become higher post-vaccination titres:
  - MN "heterologous": fold-rise 4.12 vs 3.03, but day-29 GMR 0.64.
  - H3N2 isolates: fold-rise 2.81 vs 2.15, but day-29 GMR 0.86.
- **Other between-cohort differences.**
  - IgM rises were more frequent in the Fluarix arm (H3: 12/15 vs 4/14, p=0.013).
  - One Fluarix participant (005) had 166–212-fold IgM rises to all four antigens; this should be source-verified.
- **Missing covariates.** The package has no age, sex, vaccination history, vaccination dates or infection surveillance, so these imbalances cannot be adjusted for properly.
- **Low HAI responses in both arms.** HAI seroconversion for H3N2 was 14% vs 13% (mRNA-1010 95% CI 4–40%). For the B strains it was 0–7%. The population and its prior exposure need to be characterised.

### 3.3 Binding breadth is not functional breadth
- **Arm contrast for H3 by readout** (day-29 fold-rise ratio, mRNA-1010 ÷ Fluarix):

  | H3 readout | Fold-rise ratio |
  |---|---|
  | ELISA IgG | 3.82 |
  | Bead-array binding, A/Darwin/6/2021 | 6.10 |
  | HAI | 1.03 |
  | VN, A/Darwin/6/2021 | 0.82 |
  | VN, 64 isolates from 2023–24 (unadjusted) | 1.31 |

  The extra H3 antibody that mRNA-1010 induces does not show up as HAI or neutralising activity. Post-vaccination neutralising titres against the 2023–24 isolates were actually lower (GMR 0.86).
- **Where the striking "breadth" lies:**
  - binding to A/Hong Kong/1/1968, which rose 10.9-fold vs 1.15-fold in the bead array;
  - the share of group-2 mAbs binding Hong Kong/1968: 28–65% in each mRNA-1010 donor vs 0–16% in each Fluarix donor;
  - occasional H7 binding: 2.6–21% of mAbs in each mRNA-1010 donor vs 0% in Fluarix donors.

  That pattern fits conserved (e.g. stalk) epitopes. It is a hypothesis that needs functional readouts and clinical endpoints, not evidence of protection.
- **H1.** Binding and neutralisation agree (ELISA ratio 2.67, VN ratio 2.07–2.09), but HAI does not (1.23).

### 3.4 H1: a transient magnitude effect, not selective breadth
- **Similar gap across the whole H1 panel** (day-29 fold-rise, mRNA-1010 vs Fluarix):

  | H1 viruses | mRNA-1010 | Fluarix | Ratio |
  |---|---|---|---|
  | Historical strains (2009–2019) | 3.59 | 1.97 | 1.8 |
  | A/Wisconsin/588/2019 (Fluarix-like) | 6.15 | 2.34 | 2.6 |
  | A/Wisconsin/67/2022 (mRNA-1010-like) | 3.51 | 1.69 | 2.1 |
  | Six 2023 isolates | 4.07 | 1.95 | 2.1 |

- **Interpretation.** mRNA-1010 gives a bigger H1 response, not a selectively broader one. Because the H1 antigens differ between arms, even that cannot be attributed to the platform.
- **Duration.** The gap had closed by wk17/26: adjusted GMR 1.17 (0.77–1.77) against the 2023 isolates, and HAI H1 0.83 (0.47–1.46).

### 3.5 H3N2: no advantage at any antigenic distance
- **Across the panel.**
  - At day 29, mRNA-1010 titres were lower than Fluarix for 55 of the 64 contemporary H3N2 isolates (GMR <1).
  - Nominally significant fold-rise differences occurred for 5 of 83 H3N2 viruses, vs 8 of 13 H1N1 viruses.
- **By antigenic distance.**
  - I split the 64 isolates into thirds by how far their titres drop relative to A/Darwin/6/2021 (the distance proxy).
  - Day-29 GMR by third, closest to most distant: 0.91, 0.80, 0.87. There is no trend (Spearman ρ −0.19, p=0.13).
  - By wk17/26 the contrast is smallest for the most drifted viruses (ρ −0.35, p=0.005; GMR 0.79 in the most distant third).
- **Most-drifted isolates.** These include A/District of Columbia/27/2023 (GMR 0.81) and A/Lisboa/124/2024 (0.86). This is exactly where a heterologous claim would have to win.

### 3.6 Egg-adapted viruses in the panels distort the "homologous" anchors
- **Higher readings.** At baseline, egg-propagated or reassortant viruses read 1.4–10.9-fold higher than their wild-type counterparts.
- **The mRNA-1010 H1 is represented only by an egg reassortant.** In the neutralisation panel it appears only as A/Victoria/4897/2022 IVR-238. At day 29 that virus reads 5.3× (mRNA arm) to 7.5× (Fluarix arm) higher than its cell-type equivalent.
- **The egg reading flatters the egg-based comparator.** Fluarix fold-rise was 2.44 on IVR-238 vs 1.69 on the cell-type virus.
- **Design rule.** Primary breadth readouts must use wild-type viruses. Each arm's homologous anchor must be measured against both egg-type and cell-type references.

### 3.7 Mechanistic data are hypothesis-generating only
- **Germinal-centre responses.**
  - HA-specific germinal-centre B cells were higher with mRNA-1010: week 2 median 24.2% vs 2.3% (n 6 vs 11, p=0.037); week 26 median 18.9% vs 1.6% (n 5 vs 8).
  - But the file contains two unlabelled series (§3.8).
- **Monoclonal antibodies.**
  - 589 mAbs from 4 mRNA-1010 donors vs 106 from 3 Fluarix donors, 84 of them from a single donor. The donor is the unit of inference, so this is effectively 4 vs 3.
- **Responses were recall-dominated.**
  - About 87–89% of post-vaccination serum IgG abundance came from pre-existing clonotypes in both arms (medians, n 8/8).
  - 97% of mRNA-derived group-1 mAbs bind A/Wisconsin/588/2019. Only 1 of 264 binds the mRNA-1010 H1 without also binding that older strain.
  - Breadth will therefore depend on each person's exposure history. The next study must stratify by prior vaccination and analyse by birth cohort.

### 3.8 Data problems to fix before the package goes to committee
Full list with evidence: `tables/data_integrity_issues.csv`.

- **Antigen identities are missing.** The files do not name the viruses or antigens behind MN "homologous/heterologous", HAI "A/H1N1" and the other labels, or ELISA "A/H1". Statistically, the MN series track H3N2 Darwin-like readouts most closely (`exploratory/explore_mn_identity.py`), but this must be documented, not inferred.
- **Timepoints are missing or inconsistent.**
  - The bead-array and IgM files give no timepoint.
  - The lymph-node files use wk0/2/8/17/26, but the stated aspiration schedule is weeks 1, 2, 4, 8, 17, 26.
- **Late-visit mapping is inconsistent.**
  - HAI B/Victoria uses different week-17 participants (Fluarix 007, 016; mRNA 008, 021) from the other antigens (009, 018; 010, 023).
  - Sequencing-based neutralisation uses day-121 sera for 397-007 and 397-011, whose HAI/MN late values are week 26.
- **`gc_frequencies.csv` holds two unlabelled series.** Each participant/visit appears twice with different values (156 rows, 78 keys).
- **`plasmablast_frequencies.csv` includes people outside the stated lymph-node cohort.** There are 15 Fluarix and 13 mRNA-1010 participants vs the stated 11 and 6. The 11 extras (036, 043, 048, 055, 071, 073, 074, 082, 083, 101, 102) are partly reported at lower numeric precision.
- **IgM cohort size doesn't match the summary.** The IgM file has 14/15 participants, not the stated 38/37.
- **HAI oddities.**
  - Participant 016 (Fluarix, H1N1) has an unrounded 226.27417 at both week 0 and week 26, which suggests baseline carried forward.
  - There is an off-grid titre of 288 (B/Yamagata, Fluarix 018, week 17).
- **Assay limits censor results.**
  - The MN ceiling of 1280 capped 9/15 Fluarix and 4/14 mRNA-1010 homologous day-29 titres.
  - In sequencing-based neutralisation, 85 mRNA-1010 vs 47 Fluarix baseline values sit at the lower limit.
- **Minor formatting.** Participant ID "20" appears instead of 020; overlap-file IDs use the form 397-NN; one virus name has a malformed year ("R07876/202023").

## 4. State the claim so it can be tested
- **Claim to pursue.** Compared with a licensed same-season vaccine containing the same WHO-recommended strains, the mRNA vaccine reduces RT-PCR-confirmed influenza illness caused by viruses that are antigenically mismatched to the vaccine strain of the same subtype or lineage.
- **Immunological precondition.** Higher functional antibody (neutralising, and NA-inhibiting) against a pre-registered panel of drifted wild-type viruses, sustained through the season, with non-inferior responses to the vaccine strains.
- **Out of scope.** Heterosubtypic protection (H5, H7). WU397 has only binding data for a handful of mAbs. Treat it as exploratory or a separate programme.
- **Drop B/Yamagata** from the composition and endpoints (§8).

## 5. Recommended studies

### Study 1: Randomised, observer-blind, strain-matched breadth study (Phase 2b). This is the go/no-go.
**Question:** once antigen composition is matched and allocation is randomised, does the mRNA vaccine induce more functional antibody against drifted viruses, and does it last through the season? If so, is that due to the mRNA platform or simply to non-egg antigen?

**Conditions**

| Element | Specification |
|---|---|
| Season | Next available Northern Hemisphere season. Vaccinate before local influenza activity begins. Year-2 extension: revaccinate with that season's composition, keeping each participant in the same arm. |
| Composition | Trivalent in every arm (H1N1, H3N2, B/Victoria) at the WHO-recommended strains for that season. The mRNA product encodes the cell/recombinant-recommended (wild-type) HA sequences at the intended commercial dose. |
| Arm A | mRNA vaccine |
| Arm B (standard of care) | Licensed egg-based inactivated vaccine (IIV), same season. Standard-dose for ages 18–64. High-dose or adjuvanted IIV for ≥65 (the enhanced vaccines preferred for that age group; see §8). |
| Arm C (platform control) | Licensed non-egg vaccine with wild-type HA of the same recommended strains. Recombinant HA (RIV) preferred, because it is also a preferred vaccine for ≥65; cell-based IIV is acceptable for 18–64. Comparing A with C separates "mRNA" from "non-egg antigen". |
| Randomisation and blinding | 1:1:1. Stratified by age band (18–49, 50–64, ≥65), number of influenza vaccinations in the two prior seasons (0/1/2), and site. Observer-blind. |
| Visits | Day 1 (pre-dose), day 29, day 91, day 181 (end of season). Year 2: day 366 (pre-revaccination) and 29 days after revaccination. |

**In whom**
- Adults in two independently powered cohorts: 18–64 and ≥65.
- Not yet vaccinated this season, and no laboratory-confirmed influenza this season.
- Record birth year and documented vaccination history.
- Symptom-triggered RT-PCR testing throughout follow-up. Participants with intercurrent influenza are censored from per-protocol immunogenicity from the date of infection, with a pre-specified sensitivity analysis.
- Any lymph-node or monoclonal sub-study must be a pre-specified, randomly sampled subset of equal size per arm. It is optional and not needed for the claim.

**Readouts: what is measured, against what, and when**

| Readout | Measured against | When | Role |
|---|---|---|---|
| HAI titre | Each component's vaccine reference viruses, **both egg-type and cell-type**, so each arm is anchored to its own homologous antigen | D1, D29, D181 | Homologous non-inferiority (standard licensure metric) |
| Virus-neutralising titre | (a) the same vaccine references; (b) a **pre-registered drifted panel of wild-type viruses**, separately for H3N2, H1N1 and B/Victoria (rule below); (c) **forward-drift viruses**: subclades that emerge in the 12 months after vaccination, plus the next WHO-selected strains, tested on banked D29/D181 sera | D1, D29, D181 (+D366) | **Primary breadth readout** |
| Neuraminidase-inhibiting (NAI) titre | N1, N2 and B neuraminidase (NA), both vaccine-strain and drifted | D1, D29, D181 | NA is an independent correlate of protection. The package has no NA data, and the mRNA product's NA content must be declared. |
| HA-stalk binding IgG; Fc-effector (ADCC-type) activity; bead-array binding | Drifted panel; H5 and H7 HAs | D1, D29, D181 | Exploratory: tests whether WU397's binding-only breadth has a functional counterpart |
| Safety and reactogenicity | – | Solicited reactions 7 days; unsolicited adverse events 28 days; medically attended and special-interest events and SAEs to D181 | Standard |

- **Drifted-panel rule** (fix it before unblinding; WU397's 64-isolate H3N2 panel is the model for scale):
  - one wild-type representative of every HA genetic subclade with ≥5% of global sequences in the 6 months before vaccination;
  - plus the forward-drift set.
- **Egg-propagated or reassortant viruses** are reported only as labelled secondary results and never pooled into the primary panel.
- **Reporting requirements:**
  - all arms tested blinded to arm;
  - a measuring range wide enough that titres are not capped (WU397's MN ceiling capped 9/15 results);
  - pre-specified handling of values at assay limits;
  - virus identity, passage history and HA sequence reported for every panel member.

**Endpoints and success criteria** (hierarchical, with the type-I error controlled)

| # | Endpoint | Success criterion |
|---|---|---|
| P1 | Baseline-adjusted GMR of neutralising titre, A ÷ B, averaged over the H3N2 drifted panel, at D29 | Superiority: lower 95% CI bound >1.0; sized to detect a true GMR of 1.3. (WU397: 0.86 raw; 1.18 adjusted, 0.65–2.13) |
| P2 | Same, at D181 | Lower bound >1.0. (WU397's H1 gap had closed by then.) |
| S1 | P1/P2 for the H1N1 and B/Victoria drifted panels | Lower bound >1.0 |
| S2 | A vs C on P1/P2 | Shows whether any advantage is platform or non-egg antigen |
| S3 | HAI GMT ratio B ÷ A for each vaccine component, D29 | Upper bound ≤1.5 (non-inferiority; the 2007 FDA margin applied by analogy, §8). Seroconversion reported descriptively. |
| S4 | NAI GMR, A ÷ B | Non-inferiority (upper bound of B ÷ A ≤1.5) |
| S5 | Share of drifted-panel viruses with a ≥4-fold rise, per participant | Descriptive (WU397: H1N1 median 0.50 vs 0.00; H3N2 median 0.16 vs 0.04, p=0.36) |

**Size:** about 250 randomised per arm per age cohort (about 200 evaluable), 3 arms × 2 cohorts ≈ 1,500 in total.
- **P1.** WU397's baseline-adjusted residual SD for the H3N2 panel mean was 1.03 log2. That requires 65 evaluable per arm to detect GMR 1.5, or 155 per arm for GMR 1.3 (90% power, two-sided α 0.05). The unadjusted SD of 1.20 gives 89 and 212.
- **S3.** HAI non-inferiority with margin 1.5 needs 74–167 evaluable per arm at 90% power (104–234 at 97%), for WU397 SDs of 1.09–1.64 log2.
- **Deferred.** Seroconversion non-inferiority (442–738 per arm) is deferred to Study 3's immunogenicity subset.

**Decision rule**

| Outcome | Action |
|---|---|
| P1 and P2 met for H3N2, P1 point estimate ≥1.5 (the smallest gain worth a Phase 3; committee to confirm), and S3 met | Proceed to Studies 2–3 with a heterologous objective |
| A beats B but not C | The advantage is non-egg antigen, not mRNA; reposition or drop the claim |
| H3N2 fails | Stop the heterologous claim; continue a conventional licensure path (HAI non-inferiority plus efficacy against all strains) if wanted |
| H3N2 homologous response inferior (as in WU397, GMR 0.51 against A/Darwin/6/2021) | Reformulation or dose work comes first |

### Study 2: Drifted-strain controlled human influenza challenge (proof of protection and correlate selection)
**Why:** immunogenicity alone cannot show protection against drifted strains. A challenge study tests protection directly, in a small controlled setting, before committing to a very large field trial. It also shows which Study-1 readout predicts protection. It supports the programme but cannot on its own support a label claim.

| Element | Specification |
|---|---|
| Design | Randomised 1:1:1, double-blind: mRNA (that season's composition) vs licensed egg IIV with the same strains vs placebo |
| In whom | Healthy adults 18–50 (the usual challenge population). Low pre-existing antibody to the challenge virus (e.g. HAI ≤1:20 or low neutralising titre). No influenza vaccine in the prior 6–12 months. Stratified by baseline titre. |
| Challenge condition | 4–8 weeks after vaccination. GMP challenge virus whose HA is **antigenically distinct from the vaccine component of the same subtype**: a different HA subclade and a ≥4-fold lower reactivity of post-vaccination reference sera than against the vaccine strain. H3N2 preferred, because that is where WU397 shows nothing. |
| Primary endpoint | RT-PCR-confirmed infection with ≥1 influenza symptom (mild-to-moderate influenza disease) |
| Secondary endpoints | Viral shedding (area under the curve and duration); symptom-score area under the curve; any infection (shedding or ≥4-fold rise against the challenge virus) |
| Correlate readouts | Titres on the day of challenge **against the challenge virus**: HAI, neutralising, NAI, stalk IgG, Fc-effector activity; each related to the outcome |
| Size | About 40–50 per arm. Comparator 50% vs mRNA 20% needs 39 per arm; 40% vs 15% needs 49 (80% power, two-sided 0.05). |
| Success | mRNA superior to comparator on the primary endpoint or shedding; placebo confirms the challenge attack rate |

### Study 3: Event-driven Phase 3 relative-efficacy trial with a mismatched-strain endpoint (the claim-supporting study)

| Element | Specification |
|---|---|
| Design | Randomised 1:1, observer-blind, active comparator. Multi-country, both hemispheres, at least 2 seasons (event-driven), so the trial covers seasons with different degrees of mismatch. |
| Arms | mRNA with each season's WHO-recommended strains vs licensed vaccine with the same strains: standard-dose egg IIV for 50–64; high-dose or adjuvanted IIV, or RIV, for ≥65 (local standard of care). |
| In whom | Adults ≥50 (or the intended label population), stratified 50–64 / ≥65 and by prior-season vaccination. Enough participants aged ≥65 for a separate analysis. Birth year recorded. |
| Case ascertainment | Active and passive surveillance for protocol-defined influenza-like illness from day 15 to season end, with RT-PCR testing. Every positive specimen is HA/NA sequenced. Isolates are antigenically characterised by an independent reference laboratory blinded to arm. |
| Mismatch definition (pre-specified, adjudicated blind) | The infecting virus is in a different HA subclade from the vaccine strain **and** shows ≥4-fold (≥2 antigenic-unit) reduced reactivity with vaccine-strain reference antisera. If there is no isolate, the sequence is assigned to a subclade that is antigenically characterised for that season. All other cases are classed as matched or undetermined, with sensitivity analyses. |
| Primary endpoint | Relative vaccine efficacy (rVE) against RT-PCR-confirmed protocol-defined influenza-like illness, any strain: non-inferiority (lower bound > −10%; margin to be agreed), then superiority (lower bound > 0%) |
| **Key secondary (the claim)** | **rVE against mismatched-strain cases: superiority, lower bound > 0%** |
| Other secondaries | rVE by subtype/lineage and for matched strains; medically attended illness and hospitalisation; late-season cases (>90 days after vaccination) |
| Correlates sub-study | Case-cohort design: a random subcohort plus all cases. D1, D29 and mid-season sera tested against the vaccine strains **and the actual infecting viruses** (neutralising, HAI, NAI) to estimate titre–risk relationships for mismatched strains. |
| Immunogenicity subset | HAI non-inferiority by the standard criteria: GMT ratio upper bound ≤1.5 and seroconversion difference upper bound ≤10 points; 442–738 evaluable per arm |
| Size | Event-driven: **511 mismatched-strain cases** detect rVE 25% (847 for 20%, 334 for 30%) with 90% power. At an *assumed* 2–3% seasonal attack rate with 30–50% of cases mismatched, that is about 19,500–48,600 person-seasons per arm for rVE 25%. These assumptions are not WU397 data. A blinded review of event rates should re-size enrolment. |

If that size is not feasible, the committee has to decide explicitly whether to downgrade mismatched-strain rVE to a supportive (non-label) analysis.

### Optional now: WU397 close-out (no new participants; does not support the claim)
1. Reconcile the issues in §3.8 and declare every antigen and virus identity.
2. Re-test banked sera so each arm is anchored to its own strain and the gaps are filled:
   - Fluarix's 2022–23 H1 (A/Victoria/2570/2019-like), egg-type and cell-type;
   - drifted B/Victoria viruses (the package has no B breadth data at all);
   - N1/N2 NA inhibition;
   - stalk and Fc-effector readouts for the Hong Kong/1968 and H7 binding signal.
3. Use the results only to refine the Study-1 assumptions. The comparison stays non-randomised.

## 6. Sequence

| Step | Condition to proceed |
|---|---|
| WU397 close-out (weeks) | None; informs Study 1 |
| Study 1 (one season, plus optional year 2) | Pass the gate: P1 and P2 for H3N2 (P1 point estimate ≥1.5), plus S3 for every component |
| Study 2 (can overlap the second season of Study 1) | Confirms protection and picks the correlate |
| Study 3 (at least 2 seasons, event-driven) | The label-grade heterologous claim |

Don't design Study 3's mismatched-strain endpoint before Study 1 passes. WU397 gives no effect-size estimate for H3N2 that would justify the investment.

Before Study 3, agree with regulators the mismatch definition, the endpoint hierarchy and the rVE margins (e.g. at the end-of-Phase-2 meeting).

## 7. Numbers ledger (value → where it came from)
All tables are under `/tmp/outputs/tables/` and produced by `wu397_analysis.py`; the section number refers to the script and `analysis_log.txt`.

| Number(s) | Value | Source file(s) | Derivation / output table |
|---|---|---|---|
| Cohort sizes | ELISA 38/37; HAI, MN, bead-array 14/15; sequencing neutralisation 13/14; lymph node 6/11; plasmablast file 13/15; IgM 14/15; mAb donors 4/3 | all data files; trial_summary.md | §2 → `cohort_sizes.csv` |
| HAI GMRs, GMFRs, seroconversion, seroprotection | Table in §2; seroconversion H1N1 7/14 vs 5/15, H3N2 2/14 vs 2/15, B/Victoria 0/13 vs 1/15, B/Yamagata 0/14 vs 1/15; H3N2 mRNA seroconversion 14% (95% CI 4.0–39.9%) | hai_titers.csv | §4 → `hai_summary.csv`; adjusted: §11b → `baseline_adjusted_gmr_hai_mn_elisa.csv` |
| ELISA GMRs and GMFRs | H1 GMFR 5.07 vs 1.90; H3 7.60 vs 1.99; GMRs in §2 | elisa_igg_titers.csv | §5 → `elisa_summary.csv`; §11b |
| ELISA ID pattern | mRNA IDs 3–31 (14) and 64–102 (24); Fluarix 1–59 (37) | elisa_igg_titers.csv | §2 log |
| MN | Homologous GMFR 2.49 vs 3.33; heterologous GMFR 4.12 vs 3.03; 4-fold responders 9/14 vs 6/15 (p=0.27); day-0 GMT 57 vs 121; ceiling 9/15 vs 4/14; raw GMRs 0.55 (0.22–1.40) and 0.64 (0.24–1.70) | microneutralization.csv | §6 → `microneutralization_summary.csv`; §11b |
| Bead-array | Hong Kong/1968 10.9× vs 1.15× (difference 3.25 log2, 2.50–4.00); Darwin/6 26.2× vs 4.3×; Wisconsin/67/2022 4.07× vs 1.54×; Welch p<0.05 for 12/12 H3 and 4/9 H1 | binding_breadth_h1.csv, _h3.csv | §7 → `binding_breadth_summary.csv` |
| Sequencing-neutralisation category contrasts | All GMRs in §2, 3.4, 3.5; residual SDs 1.03 (H3N2) and 0.94 (H1N1) log2 | neutralization_seqbased.csv | §8 → `seqneut_category_ancova.csv`; categories in `seqneut_virus_categories.csv` |
| Per-virus results | 55/64 H3N2 isolates below 1; nominal fold-rise differences 8/13 H1N1 vs 5/83 H3N2; H1 day-29 GMTs 193–319 (Fluarix) and 431–557 (mRNA) vs Wisconsin/67 197/431 and Wisconsin/588 506/1073; DC/27/2023 GMR 0.81; Lisboa/124/2024 0.86 | neutralization_seqbased.csv | §8 → `seqneut_per_virus.csv` |
| Baseline imbalance | Median per-virus day-0 GMR 0.67; 64/64 <1 | neutralization_seqbased.csv | §8 log; `seqneut_per_virus.csv` (GMR_d0) |
| Drift gradient | Thirds 0.91 / 0.80 / 0.87 (day 29), 0.86 / 0.81 / 0.79 (late); ρ −0.19 (p=0.13), late ρ −0.35 (p=0.005) | neutralization_seqbased.csv | §8 → `seqneut_h3_drift_gradient.csv` |
| Breadth (≥4-fold share) | H1N1 median 0.50 vs 0.00 (p=0.006); H3N2 0.16 vs 0.04 (p=0.36) | neutralization_seqbased.csv | §8 → `seqneut_breadth_4fold.csv` |
| Egg vs wild-type | Baseline ratios 1.4–10.9×; IVR-238 vs Wisconsin/67 day-29 ratio 7.46 (Fluarix) and 5.33 (mRNA); Fluarix fold-rise 2.44 vs 1.69 | neutralization_seqbased.csv | §8 → `seqneut_egg_vs_wildtype.csv` |
| Binding vs functional | H3 ratios 3.82 / 6.10 / 1.03 / 0.82 / 1.31; H1 ratios 2.67 / 2.65 / 1.23 / 2.07 / 2.09 | ELISA, bead-array, HAI, sequencing neutralisation | §9 → `binding_vs_neutralisation.csv` |
| IgM | H3 rises 12/15 vs 4/14 (p=0.013); participant 005: 166–212-fold | igm_fold_change.csv | §10 → `igm_summary.csv` |
| Germinal centre, plasmablast, repertoire, CDR-H3 | Germinal centre 24.2% vs 2.3% (week 2), 18.9% vs 1.6% (week 26); pre-existing share 87.0% vs 88.7%; vaccine-elicited clonotypes 32 vs 17.5 (p=0.066) | gc_frequencies.csv, plasmablast_frequencies.csv, repertoire_clonotype_counts.csv, cdrh3_diversity_index.csv | §11 → `mechanistic_summary.csv` |
| mAbs | 589 mAbs / 4 donors vs 106 / 3 (84 from donor 05); Hong Kong/1968 binders 28–65% vs 0–16% per donor; H7 2.6–21% vs 0%; 97% of mRNA group-1 mAbs bind Wisconsin/588; 1/264 binds Victoria/4897 only | mab_binding_panels.csv | §11 → `mab_donor_summary.csv` (binder = ≥10-fold over control) |
| Data issues | As listed in §3.8 | various | §3 → `data_integrity_issues.csv` |
| Sample sizes | 65/155 (P1); 74–234 (HAI GMT); 442–738 (seroconversion); 511/847/334 events; 19,456–48,638 per arm; 39/49 (challenge) | WU397 SDs from the above; attack rates and mismatch share **assumed** | §12 → `sample_size.csv` |

## 8. Facts used that are not in the data package (verify against the regulatory file)
- **Fluarix 2022–23 composition.** Fluarix QIV 2022–23 follows the WHO 2022–23 Northern Hemisphere egg-based recommendation: A/Victoria/2570/2019 (H1N1)pdm09-like, A/Darwin/9/2021 (H3N2)-like, B/Austria/1359417/2021-like, B/Phuket/3073/2013-like. The cell/recombinant counterparts are A/Wisconsin/588/2019 and A/Darwin/6/2021. Confirm against the 2022–23 package insert.
- **2023–24 recommendation.** A/Victoria/4897/2022 (egg; reassortant IVR-238) and A/Wisconsin/67/2022 (cell) were WHO's H1N1 choices for 2023–24 Northern Hemisphere, made after the 2022–23 season had started.
- **A/District of Columbia/27/2023.** To my knowledge WHO later chose it as the cell-based H3N2 reference for 2025 Southern Hemisphere and 2025–26 Northern Hemisphere. Please verify.
- **B/Yamagata.** No confirmed detections since March 2020. WHO recommended removing it, and US vaccines have been trivalent since 2024–25, so the comparator must be the current trivalent product.
- **HAI criteria.** FDA (2007) guidance for seasonal inactivated vaccines, used here by analogy:
  - adults <65: seroconversion lower bound ≥40% and HAI ≥1:40 lower bound ≥70%;
  - adults ≥65: 30% and 60%;
  - non-inferiority: GMT ratio (comparator ÷ new) upper bound ≤1.5 and seroconversion difference upper bound ≤10 percentage points.
- **Older adults.** ACIP preferentially recommends high-dose IIV, RIV or adjuvanted IIV for adults ≥65.
- **NA antibody.** NA-inhibiting antibody is an independent correlate of protection (Monto et al., *J Infect Dis* 2015; Memoli et al., *mBio* 2016).
- **H3N2 drift.** H3N2 is generally the fastest-drifting subtype and the most frequent cause of vaccine mismatch. This is general knowledge and is not derived from WU397.

## 9. Files
- `/tmp/outputs/answer.md`: this document.
- `/tmp/outputs/wu397_analysis.py`: a single reproducible analysis (run: `micromamba run -n core python /tmp/outputs/wu397_analysis.py`).
- `/tmp/outputs/analysis_log.txt`: full printed output.
- `/tmp/outputs/tables/*.csv`: every table cited above.
- `/tmp/outputs/figures/seqneut_gmfr_by_virus.png`: per-virus fold-rise, mRNA-1010 vs Fluarix.
- `/tmp/outputs/figures/seqneut_category_gmr.png`: baseline-adjusted GMRs by virus category, day 29 and late.
- `/tmp/outputs/exploratory/`: scratch scripts used while exploring; not needed to reproduce the numbers.
