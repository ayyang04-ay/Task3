"""Shared loaders / helpers for the WU397 re-analysis.
All inputs are read read-only from /tmp/world/filesystem."""
import re
import numpy as np
import pandas as pd

SRC = "/tmp/world/filesystem"

def gm(x):
    x = pd.Series(x).dropna()
    return float(np.exp(np.mean(np.log(x)))) if len(x) else np.nan

def pid3(p):
    """Harmonise participant ids to 3-digit strings ('397-006' / '6' / '06' / '006' -> '006')."""
    p = str(p)
    if p.startswith("397-"):
        p = p[4:]
    return p.zfill(3)

# ---------------------------------------------------------------- virus annotation
REASSORTANT_TAGS = ["egg", "X-307A", "X-223A", "NIB-88", "IVR-238"]

def annotate_virus(v):
    """Return dict of annotations for a sequencing-neut panel virus name."""
    name, subtype = v.rsplit("_", 1)
    is_reassortant = any(t in v for t in REASSORTANT_TAGS)
    m = re.search(r"/(\d{4,6})(?:[A-Za-z_\-].*)?$", name)
    yr_raw = m.group(1) if m else None
    year = int(yr_raw) if yr_raw and len(yr_raw) == 4 else None
    malformed = yr_raw is not None and len(yr_raw) != 4
    if malformed and yr_raw.endswith("2023"):
        year = 2023  # 'A/SOUTHAFRICA/R07876/202023' -> flagged, treated as 2023
    return dict(virus=v, subtype=subtype, reassortant=is_reassortant, year=year, malformed_name=malformed)

def load_seqneut():
    d = pd.read_csv(f"{SRC}/neutralization_seqbased.csv")
    parts = d.serum.str.split("_")
    d["arm"] = parts.str[0]
    d["pid"] = parts.str[1].map(pid3)
    d["day"] = parts.str[2].str[1:].astype(int)
    d["visit"] = d.day.map({0: "d0", 29: "d29", 121: "late", 181: "late"})
    ann = pd.DataFrame([annotate_virus(v) for v in d.virus.unique()])
    d = d.merge(ann, on="virus", how="left")
    return d
