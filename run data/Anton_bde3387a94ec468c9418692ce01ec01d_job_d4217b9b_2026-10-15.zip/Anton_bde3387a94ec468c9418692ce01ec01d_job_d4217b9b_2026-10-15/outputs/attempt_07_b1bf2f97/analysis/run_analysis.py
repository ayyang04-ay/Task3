"""
WU397 (mRNA-1010 vs Fluarix, 2022-23) - re-analysis of the data package to decide the next studies.

Run:  micromamba run -n core python /tmp/outputs/analysis/run_analysis.py
Inputs (read-only): /tmp/world/filesystem/*.csv, trial_summary.md
Outputs: /tmp/outputs/analysis/results/*.csv, /tmp/outputs/analysis/figures/*.png,
         /tmp/outputs/analysis/results/key_numbers.csv (every number quoted in answer.md)

Conventions
  * GMT = geometric mean titre; GMFR = geometric mean fold rise; ratios are mRNA-1010 / Fluarix unless stated.
  * "Adjusted" = ANCOVA on log2 post-vaccination titre with log2 baseline titre as covariate
    (participant is the unit of analysis; for multi-virus panels the participant-level mean log2 titre across the panel is used).
  * Sequencing-based neutralisation: titres reported as bounds (titer_bound = 'upper' -> at/below the lowest dilution,
    'lower' -> at/above the top dilution) are used at the reported bound (primary) and, as a sensitivity analysis,
    below-LOD values are halved.
  * Production reassortants / egg-propagated viruses (names containing egg, X-307A, X-223A, NIB-88, IVR-238) are
    excluded from the wild-type breadth analyses and reported separately, per the naming note in trial_summary.md.
"""
import os, sys, json, warnings
import numpy as np
import pandas as pd
from scipy import stats
import statsmodels.formula.api as smf
from statsmodels.stats.proportion import proportion_confint
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(__file__))
from common import SRC, gm, pid3, load_seqneut  # noqa: E402

OUT = "/tmp/outputs/analysis"
RES = f"{OUT}/results"; FIG = f"{OUT}/figures"
os.makedirs(RES, exist_ok=True); os.makedirs(FIG, exist_ok=True)

KEY = []  # (id, value, description, source_file, method)
def key(kid, value, desc, src, method):
    KEY.append(dict(id=kid, value=value, description=desc, source=src, method=method))

def ancova(df, post, pre, arm_col="mrna", extra=""):
    m = smf.ols(f"{post} ~ {arm_col} + {pre}{extra}", data=df).fit()
    ci = m.conf_int().loc[arm_col]
    return 2 ** m.params[arm_col], 2 ** ci[0], 2 ** ci[1], m.pvalues[arm_col], m

def fmt_ratio(r, lo, hi, p):
    return f"{r:.2f} [{lo:.2f}-{hi:.2f}], p={p:.2g}"

issues = []  # data-integrity log
def issue(area, finding, consequence):
    issues.append(dict(area=area, finding=finding, consequence=consequence))

# =====================================================================================
# 0. Cohort / identifier audit
# =====================================================================================
S = SRC + "/"
elisa = pd.read_csv(S + "elisa_igg_titers.csv")
hai = pd.read_csv(S + "hai_titers.csv", dtype={"participant": str})
mn = pd.read_csv(S + "microneutralization.csv")
igm = pd.read_csv(S + "igm_fold_change.csv", dtype={"participant": str})
bh1 = pd.read_csv(S + "binding_breadth_h1.csv"); bh3 = pd.read_csv(S + "binding_breadth_h3.csv")
gc = pd.read_csv(S + "gc_frequencies.csv", dtype={"participant": str})
pb = pd.read_csv(S + "plasmablast_frequencies.csv", dtype={"participant": str})
ov = pd.read_csv(S + "pb_gc_clonal_overlap.csv")
rep = pd.read_csv(S + "repertoire_clonotype_counts.csv")
sig = pd.read_csv(S + "serum_igg_clonotypes.csv")
cdr = pd.read_csv(S + "cdrh3_diversity_index.csv")
mab = pd.read_csv(S + "mab_binding_panels.csv")
sn = load_seqneut()

recs = []
def add(df, src, pcol):
    for p, a in zip(df[pcol], df["arm"]):
        recs.append((src, pid3(p), a))
add(elisa, "ELISA IgG", "participant"); add(hai, "HAI", "participant"); add(mn, "MN", "participant")
add(igm, "IgM", "participant"); add(bh1, "bead H1", "participant"); add(bh3, "bead H3", "participant")
add(gc, "GC (FNA)", "participant"); add(pb, "plasmablast", "participant"); add(sn, "seq-neut", "pid")
mab["donor"] = mab.mab_id.str.split(".").str[1]; add(mab.rename(columns={"donor": "d"}), "mAb donors", "d")
coh = pd.DataFrame(recs, columns=["assay", "pid", "arm"]).drop_duplicates()
n_by_assay = coh.groupby(["assay", "arm"]).pid.nunique().unstack()
n_by_assay.to_csv(f"{RES}/cohort_sizes_by_assay.csv")
arm_conflicts = coh.groupby("pid").arm.nunique()
assert (arm_conflicts == 1).all(), "participant in >1 arm"
declared = {"ELISA IgG": (38, 37), "IgM": (38, 37), "HAI": (14, 15), "bead H1": (14, 15), "MN": (14, 15),
            "seq-neut": (13, 14), "GC (FNA)": (6, 11), "plasmablast": (6, 11)}
for a, (m_, f_) in declared.items():
    obs = (int(n_by_assay.loc[a, "mRNA-1010"]), int(n_by_assay.loc[a, "Fluarix"]))
    if obs != (m_, f_):
        issue("Cohort sizes", f"{a}: declared (trial_summary.md) mRNA {m_} / Fluarix {f_}; observed {obs[0]} / {obs[1]}",
              "Provenance of the extra/missing participants must be reconciled before these data are cited.")
key("n_elisa", "38 / 37", "ELISA IgG cohort (mRNA / Fluarix)", "elisa_igg_titers.csv", "unique participants")
key("n_hai", "14 / 15 (B/Vic 13 / 15)", "HAI cohort", "hai_titers.csv", "unique participants")
key("n_seqneut", "13 / 14", "sequencing-based neutralisation cohort", "neutralization_seqbased.csv", "unique participants")
key("n_fna", "6 / 11", "FNA (germinal-centre) cohort", "gc_frequencies.csv", "unique participants")

# ID-block structure (site allocation proxy)
core_ids = set(coh[coh.assay == "HAI"].pid)
elisa_only = coh[(coh.assay == "ELISA IgG") & (~coh.pid.isin(core_ids))]
rng = elisa_only.groupby("arm").pid.agg(lambda x: f"{min(x)}-{max(x)} (n={len(x)})")
key("elisa_extra_id_blocks", f"Fluarix {rng['Fluarix']}; mRNA-1010 {rng['mRNA-1010']}",
    "ELISA-only participants fall in arm-specific ID blocks (consistent with site-based allocation)",
    "elisa_igg_titers.csv", "ID ranges of participants not in the serology core (IDs 001-032 interleave both arms)")

# =====================================================================================
# 1. HAI
# =====================================================================================
hai["pid"] = hai.participant.map(pid3)
hai["tp"] = hai.timepoint.replace({"wk17": "late", "wk26": "late"})
hw = hai.pivot_table(index=["antigen", "arm", "pid"], columns="tp", values="hai_titer").reset_index()
hw["fr4"] = hw.wk4 / hw.wk0; hw["frl"] = hw.late / hw.wk0
hw["sc4"] = (hw.fr4 >= 4) & (hw.wk4 >= 40); hw["sp4"] = hw.wk4 >= 40; hw["scl"] = (hw.frl >= 4) & (hw.late >= 40)
rows = []
for (a, arm), s in hw.groupby(["antigen", "arm"]):
    n = len(s); k = int(s.sc4.sum()); ksp = int(s.sp4.sum())
    lo, hi = proportion_confint(k, n, method="beta"); lo2, hi2 = proportion_confint(ksp, n, method="beta")
    rows.append(dict(antigen=a, arm=arm, n=n, GMT_d0=gm(s.wk0), GMT_wk4=gm(s.wk4), GMT_late=gm(s.late),
                     GMFR_wk4=gm(s.fr4), GMFR_late=gm(s.frl), SCR_wk4=f"{k}/{n}", SCR_pct=k / n, SCR_lo=lo, SCR_hi=hi,
                     SP_wk4=f"{ksp}/{n}", SP_pct=ksp / n, SP_lo=lo2, SP_hi=hi2, SCR_late=f"{int(s.scl.sum())}/{n}"))
hai_tab = pd.DataFrame(rows); hai_tab.to_csv(f"{RES}/hai_summary.csv", index=False)
hai_cmp = []
for a, s in hw.groupby("antigen"):
    s = s.copy(); s["mrna"] = (s.arm == "mRNA-1010").astype(int)
    for c in ["wk0", "wk4", "late"]: s["l" + c] = np.log2(s[c])
    r = ancova(s, "lwk4", "lwk0")
    x = np.log2(s[s.mrna == 0].wk4); y = np.log2(s[s.mrna == 1].wk4)
    diff = x.mean() - y.mean(); se = np.sqrt(x.var(ddof=1) / len(x) + y.var(ddof=1) / len(y))
    q = stats.t.ppf(0.975, len(x) + len(y) - 2)
    hai_cmp.append(dict(antigen=a, adj_GMT_ratio_wk4=r[0], lo=r[1], hi=r[2], p=r[3],
                        GMFR_ratio_wk4=gm(s[s.mrna == 1].fr4) / gm(s[s.mrna == 0].fr4),
                        p_GMFR_MWU=stats.mannwhitneyu(np.log(s[s.mrna == 1].fr4), np.log(s[s.mrna == 0].fr4)).pvalue,
                        GMT_ratio_Flu_over_mRNA=2 ** diff, GMT_ratio_Flu_over_mRNA_UB=2 ** (diff + q * se),
                        meets_CBER_NI_UB_le_1p5=2 ** (diff + q * se) <= 1.5,
                        SD_log2_wk4_Flu=x.std(), SD_log2_wk4_mRNA=y.std()))
hai_cmp = pd.DataFrame(hai_cmp); hai_cmp.to_csv(f"{RES}/hai_arm_comparison.csv", index=False)
for _, r in hai_tab.iterrows():
    key(f"hai_{r.antigen}_{r.arm}", f"GMT d0 {r.GMT_d0:.0f} -> wk4 {r.GMT_wk4:.0f}; GMFR {r.GMFR_wk4:.2f}; SCR {r.SCR_wk4} ({r.SCR_pct:.0%}, 95% CI {r.SCR_lo:.0%}-{r.SCR_hi:.0%}); >=1:40 at wk4 {r.SP_wk4}; late SCR {r.SCR_late}",
        f"HAI {r.antigen}, {r.arm}", "hai_titers.csv", "GMT/GMFR; SCR = >=4-fold rise and titre >=40; Clopper-Pearson CI")
for _, r in hai_cmp.iterrows():
    key(f"hai_cmp_{r.antigen}", f"GMFR ratio {r.GMFR_ratio_wk4:.2f} (MWU p={r.p_GMFR_MWU:.2f}); Fluarix/mRNA GMT ratio UB {r.GMT_ratio_Flu_over_mRNA_UB:.2f}",
        f"HAI {r.antigen}, mRNA vs Fluarix at wk4", "hai_titers.csv", "GMFR ratio; two-sample t on log2 wk4 titre for CI")

# =====================================================================================
# 2. Microneutralisation (panel viruses not identified in the package)
# =====================================================================================
t = mn[mn.measure == "titer"].copy(); t["tp"] = t.timepoint.replace({"wk17": "late", "wk26": "late"})
mw = t.pivot_table(index=["panel", "arm", "participant"], columns="tp", values="value").reset_index()
fc = mn[mn.measure == "fold_change"].pivot_table(index=["panel", "arm", "participant"], columns="timepoint", values="value").reset_index()
chk = mw.merge(fc, on=["panel", "arm", "participant"])
assert np.allclose(chk.wk4_x / chk.wk0, chk.wk4_y) and np.allclose(chk.late / chk.wk0, chk["wk17/26"]), "MN fold-change mismatch"
rows = []
for (panel, arm), s in mw.groupby(["panel", "arm"]):
    rows.append(dict(panel=panel, arm=arm, n=len(s), GMT_wk0=gm(s.wk0), GMT_wk4=gm(s.wk4), GMT_late=gm(s.late),
                     GMFR_wk4=gm(s.wk4 / s.wk0), GMFR_late=gm(s.late / s.wk0), n_4fold_wk4=int((s.wk4 / s.wk0 >= 4).sum()),
                     n_at_ULOQ1280_wk0=int((s.wk0 >= 1280).sum()), n_at_ULOQ1280_wk4=int((s.wk4 >= 1280).sum())))
mn_tab = pd.DataFrame(rows); mn_tab.to_csv(f"{RES}/mn_summary.csv", index=False)
mn_cmp = []
for panel, s in mw.groupby("panel"):
    s = s.copy(); s["mrna"] = (s.arm == "mRNA-1010").astype(int)
    for c in ["wk0", "wk4", "late"]: s["l" + c] = np.log2(s[c])
    r4 = ancova(s, "lwk4", "lwk0"); rl = ancova(s, "llate", "lwk0")
    b = smf.ols("lwk0 ~ mrna", s).fit()
    mn_cmp.append(dict(panel=panel, baseline_GMT_ratio=2 ** b.params.mrna, adj_ratio_wk4=r4[0], lo4=r4[1], hi4=r4[2], p4=r4[3],
                       adj_ratio_late=rl[0], lol=rl[1], hil=rl[2], pl=rl[3]))
mn_cmp = pd.DataFrame(mn_cmp); mn_cmp.to_csv(f"{RES}/mn_arm_comparison.csv", index=False)
for _, r in mn_tab.iterrows():
    key(f"mn_{r.panel}_{r.arm}", f"GMT wk0 {r.GMT_wk0:.0f}, wk4 {r.GMT_wk4:.0f}, late {r.GMT_late:.0f}; GMFR wk4 {r.GMFR_wk4:.2f}; at 1280 ceiling wk4 {r.n_at_ULOQ1280_wk4}/{r.n}",
        f"MN {r.panel} panel, {r.arm}", "microneutralization.csv", "GMT/GMFR; ceiling count = titre >=1280")
for _, r in mn_cmp.iterrows():
    key(f"mn_cmp_{r.panel}", f"baseline ratio {r.baseline_GMT_ratio:.2f}; adj wk4 {fmt_ratio(r.adj_ratio_wk4, r.lo4, r.hi4, r.p4)}; adj late {fmt_ratio(r.adj_ratio_late, r.lol, r.hil, r.pl)}",
        f"MN {r.panel}: mRNA/Fluarix", "microneutralization.csv", "ANCOVA log2 titre ~ arm + log2 wk0")

# =====================================================================================
# 3. ELISA IgG (largest cohort)
# =====================================================================================
e = elisa[elisa.measure == "ec50"].copy(); e["tp"] = e.timepoint.replace({"wk17": "late", "wk26": "late"})
ew = e.pivot_table(index=["antigen", "arm", "participant"], columns="tp", values="value").reset_index()
efc = elisa[elisa.measure == "fold_change"].pivot_table(index=["antigen", "arm", "participant"], columns="timepoint", values="value").reset_index()
chk = ew.merge(efc, on=["antigen", "arm", "participant"])
assert np.allclose(chk.wk4_x / chk.wk0, chk.wk4_y, rtol=1e-4) and np.allclose(chk.late / chk.wk0, chk["wk17/26"], rtol=1e-4)
for c in ["wk0", "wk4", "late"]: ew["l" + c] = np.log2(ew[c])
ew["mrna"] = (ew.arm == "mRNA-1010").astype(int); ew["core"] = ew.participant <= 32
rows = []
for a, s in ew.groupby("antigen"):
    for subset, ss in [("all", s), ("serology core (IDs<=32)", s[s.core]), ("ELISA-only ID blocks", s[~s.core])]:
        r4 = ancova(ss, "lwk4", "lwk0"); rl = ancova(ss, "llate", "lwk0")
        rows.append(dict(antigen=a, subset=subset, n_mrna=int(ss.mrna.sum()), n_flu=int((1 - ss.mrna).sum()),
                         GMT0_mrna=gm(ss[ss.mrna == 1].wk0), GMT0_flu=gm(ss[ss.mrna == 0].wk0),
                         GMFR4_mrna=gm(ss[ss.mrna == 1].wk4 / ss[ss.mrna == 1].wk0), GMFR4_flu=gm(ss[ss.mrna == 0].wk4 / ss[ss.mrna == 0].wk0),
                         adj_ratio_wk4=r4[0], lo4=r4[1], hi4=r4[2], p4=r4[3], adj_ratio_late=rl[0], lol=rl[1], hil=rl[2], pl=rl[3]))
el_tab = pd.DataFrame(rows); el_tab.to_csv(f"{RES}/elisa_arm_comparison.csv", index=False)
for _, r in el_tab.iterrows():
    key(f"elisa_{r.antigen}_{r.subset}", f"GMFR wk4 mRNA {r.GMFR4_mrna:.2f} vs Fluarix {r.GMFR4_flu:.2f}; adj wk4 ratio {fmt_ratio(r.adj_ratio_wk4, r.lo4, r.hi4, r.p4)}; adj late ratio {fmt_ratio(r.adj_ratio_late, r.lol, r.hil, r.pl)}",
        f"ELISA IgG {r.antigen} [{r.subset}] n={r.n_mrna}/{r.n_flu}", "elisa_igg_titers.csv", "ANCOVA log2 EC50 ~ arm + log2 wk0")

# =====================================================================================
# 4. Bead-array binding breadth (fold-change only; no baseline MFI supplied; timepoint not stated)
# =====================================================================================
rows = []
for sub, b in [("H1", bh1), ("H3", bh3)]:
    for strain, s in b.groupby("strain"):
        x = s[s.arm == "mRNA-1010"].log2_fold_change_mfi; y = s[s.arm == "Fluarix"].log2_fold_change_mfi
        rows.append(dict(subtype=sub, strain=strain, median_log2FC_mrna=x.median(), median_log2FC_flu=y.median(),
                         mean_diff_log2=x.mean() - y.mean(), p_MWU=stats.mannwhitneyu(x, y).pvalue))
bead = pd.DataFrame(rows); bead.to_csv(f"{RES}/bead_array_by_strain.csv", index=False)
for _, r in bead.iterrows():
    key(f"bead_{r.strain}", f"median log2FC mRNA {r.median_log2FC_mrna:.2f} vs Fluarix {r.median_log2FC_flu:.2f} (MWU p={r.p_MWU:.2g})",
        f"bead-array binding fold-change, {r.strain}", f"binding_breadth_{r.subtype.lower()}.csv", "Mann-Whitney U")

# =====================================================================================
# 5. Sequencing-based neutralisation - the only multi-strain functional readout
# =====================================================================================
def vgroup(r):
    if r.reassortant: return "egg/reassortant"
    if r.subtype == "H1N1": return "H1 2022-23 wild-type" if r.year >= 2022 else "H1 2009-19 wild-type"
    if r.virus.startswith("A/Darwin"): return "H3 2021 vaccine strains (Darwin/6, Darwin/9)"
    return "H3 2022-24 wild-type" if r.year >= 2022 else "H3 2012-20 wild-type"
ann = sn.drop_duplicates("virus")[["virus", "subtype", "year", "reassortant", "malformed_name"]].copy()
ann["group"] = ann.apply(vgroup, axis=1)
ann.to_csv(f"{RES}/seqneut_virus_annotation.csv", index=False)
sn = sn.merge(ann[["virus", "group"]], on="virus")
for lab, fn in [("primary", lambda d: d.titer),
                ("sens_LOD_halved", lambda d: np.where(d.titer_bound == "upper", d.titer / 2, d.titer))]:
    sn[f"l2_{lab}"] = np.log2(fn(sn))
key("seqneut_panel", f"{ann.shape[0]} viruses: {int((ann.subtype=='H3N2').sum())} H3N2 ({int(((ann.subtype=='H3N2')&ann.reassortant).sum())} egg/reassortant), {int((ann.subtype=='H1N1').sum())} H1N1 ({int(((ann.subtype=='H1N1')&ann.reassortant).sum())} egg/reassortant); no influenza B",
    "sequencing-based neutralisation panel composition", "neutralization_seqbased.csv", "name parsing")
key("seqneut_groups", "; ".join(f"{g}: {n}" for g, n in ann.group.value_counts().items()), "virus groups used for breadth analysis",
    "neutralization_seqbased.csv", "year/subtype/reassortant tag from virus name")
key("seqneut_bounds", f"{(sn.titer_bound=='upper').sum()} at/below LOD (40), {(sn.titer_bound=='lower').sum()} at/above top dilution (17300 or 6291) of {len(sn)} titres",
    "censored titres", "neutralization_seqbased.csv", "titer_bound column")

grp_rows = []
for lab in ["primary", "sens_LOD_halved"]:
    p = sn.groupby(["group", "arm", "pid", "visit"])[f"l2_{lab}"].mean().unstack("visit").reset_index()
    p["mrna"] = (p.arm == "mRNA-1010").astype(int)
    lateday = sn[sn.visit == "late"].groupby("pid").day.first(); p["lateday"] = p.pid.map(lateday)
    for g, s in p.groupby("group"):
        s = s.dropna(subset=["d0", "d29", "late"])
        b = smf.ols("d0 ~ mrna", s).fit()
        fr = smf.ols("I(d29 - d0) ~ mrna", s).fit()
        u = smf.ols("d29 ~ mrna", s).fit()
        r29 = ancova(s, "d29", "d0"); rl = ancova(s, "late", "d0")
        s181 = s[s.lateday == 181]; r181 = ancova(s181, "late", "d0")
        dec = (s.late - s.d29)
        grp_rows.append(dict(analysis=lab, group=g, n_mrna=int(s.mrna.sum()), n_flu=int((1 - s.mrna).sum()),
                             baseline_ratio=2 ** b.params.mrna, p_baseline=b.pvalues.mrna,
                             GMFR_mrna=2 ** (s[s.mrna == 1].d29 - s[s.mrna == 1].d0).mean(), GMFR_flu=2 ** (s[s.mrna == 0].d29 - s[s.mrna == 0].d0).mean(),
                             GMFR_ratio=2 ** fr.params.mrna, p_GMFR=fr.pvalues.mrna,
                             unadj_d29_ratio=2 ** u.params.mrna, p_unadj=u.pvalues.mrna,
                             adj_d29_ratio=r29[0], adj_d29_lo=r29[1], adj_d29_hi=r29[2], adj_d29_p=r29[3], resid_SD_log2=np.sqrt(r29[4].scale),
                             adj_late_ratio=rl[0], adj_late_lo=rl[1], adj_late_hi=rl[2], adj_late_p=rl[3],
                             adj_d181only_ratio=r181[0], adj_d181_lo=r181[1], adj_d181_hi=r181[2], n_d181=f"{int(s181.mrna.sum())}/{int((1-s181.mrna).sum())}",
                             late_over_d29_mrna=2 ** dec[s.mrna == 1].mean(), late_over_d29_flu=2 ** dec[s.mrna == 0].mean(),
                             p_decay=stats.ttest_ind(dec[s.mrna == 1], dec[s.mrna == 0]).pvalue))
sg = pd.DataFrame(grp_rows); sg.to_csv(f"{RES}/seqneut_group_ancova.csv", index=False)
for _, r in sg[sg.analysis == "primary"].iterrows():
    key(f"sn_{r.group}", f"baseline ratio {r.baseline_ratio:.2f}; GMFR {r.GMFR_mrna:.2f} vs {r.GMFR_flu:.2f} (ratio {r.GMFR_ratio:.2f}, p={r.p_GMFR:.2g}); unadjusted d29 GMT ratio {r.unadj_d29_ratio:.2f}; "
        f"baseline-adjusted d29 {fmt_ratio(r.adj_d29_ratio, r.adj_d29_lo, r.adj_d29_hi, r.adj_d29_p)}; adjusted late (d121/181) {fmt_ratio(r.adj_late_ratio, r.adj_late_lo, r.adj_late_hi, r.adj_late_p)}; "
        f"d181-only {r.adj_d181only_ratio:.2f} [{r.adj_d181_lo:.2f}-{r.adj_d181_hi:.2f}]; late/d29 mRNA {r.late_over_d29_mrna:.2f} vs Fluarix {r.late_over_d29_flu:.2f} (p={r.p_decay:.2g})",
        f"seq-neut, {r.group} (n={r.n_mrna}/{r.n_flu})", "neutralization_seqbased.csv",
        "participant-level mean log2 titre across group; ANCOVA post ~ arm + baseline")

# per-participant trajectories (wild-type 2022+ viruses) - screen for intercurrent infection (late >= 2x day 29)
traj = sn[(~sn.reassortant) & (sn.year >= 2022)].groupby(["subtype", "arm", "pid", "visit"]).l2_primary.mean().unstack("visit").reset_index()
traj["late_day"] = traj.pid.map(sn[sn.visit == "late"].groupby("pid").day.first())
traj["d29_over_d0"] = 2 ** (traj.d29 - traj.d0); traj["late_over_d29"] = 2 ** (traj.late - traj.d29)
traj["possible_intercurrent_boost"] = traj.late_over_d29 >= 2
traj.to_csv(f"{RES}/seqneut_participant_trajectories.csv", index=False)
key("sn_traj", f"max late/d29 ratio {traj.late_over_d29.max():.2f}; participants with late >= 2x d29: {int(traj.possible_intercurrent_boost.sum())}",
    "screen for intercurrent infection in seq-neut trajectories (2022+ wild-type panel means)", "neutralization_seqbased.csv", "participant-level panel means")

# cluster-robust virus-level check
chk_rows = []
w = sn.pivot_table(index=["group", "virus", "arm", "pid"], columns="visit", values="l2_primary").reset_index()
w["mrna"] = (w.arm == "mRNA-1010").astype(int)
for g, s in w.groupby("group"):
    s = s.dropna(subset=["d0", "d29"])
    m = smf.ols("d29 ~ mrna + d0 + C(virus)", s).fit(cov_type="cluster", cov_kwds={"groups": pd.factorize(s.pid)[0]})
    ci = m.conf_int().loc["mrna"]
    chk_rows.append(dict(group=g, adj_ratio=2 ** m.params.mrna, lo=2 ** ci[0], hi=2 ** ci[1], p=m.pvalues.mrna))
pd.DataFrame(chk_rows).to_csv(f"{RES}/seqneut_group_virus_level_clustered.csv", index=False)

# per-virus
pv = []
for v, s in w.groupby("virus"):
    s = s.dropna(subset=["d0", "d29"])
    r = ancova(s, "d29", "d0")
    pv.append(dict(virus=v, group=s.group.iloc[0], GMT0_mrna=2 ** s[s.mrna == 1].d0.mean(), GMT0_flu=2 ** s[s.mrna == 0].d0.mean(),
                   GMT29_mrna=2 ** s[s.mrna == 1].d29.mean(), GMT29_flu=2 ** s[s.mrna == 0].d29.mean(),
                   GMFR_mrna=2 ** (s[s.mrna == 1].d29 - s[s.mrna == 1].d0).mean(), GMFR_flu=2 ** (s[s.mrna == 0].d29 - s[s.mrna == 0].d0).mean(),
                   adj_ratio=r[0], lo=r[1], hi=r[2], p=r[3]))
pv = pd.DataFrame(pv).merge(ann[["virus", "year"]], on="virus"); pv.to_csv(f"{RES}/seqneut_per_virus.csv", index=False)
for v in ["A/Darwin/6/2021_H3N2", "A/Darwin/9/2021_H3N2", "A/Wisconsin/588/2019_H1N1", "A/Wisconsin/67/2022_H1N1",
          "A/Victoria/4897/2022_IVR-238_H1N1", "A/Thailand/8/2022_H3N2", "A/Massachusetts/18/2022_H3N2", "A/DistrictOfColumbia/27/2023_H3N2"]:
    r = pv[pv.virus == v].iloc[0]
    key(f"sn_virus_{v}", f"GMT d0 {r.GMT0_mrna:.0f} vs {r.GMT0_flu:.0f}; d29 {r.GMT29_mrna:.0f} vs {r.GMT29_flu:.0f}; GMFR {r.GMFR_mrna:.2f} vs {r.GMFR_flu:.2f}; adj d29 ratio {fmt_ratio(r.adj_ratio, r.lo, r.hi, r.p)}",
        f"seq-neut {v} (mRNA vs Fluarix)", "neutralization_seqbased.csv", "per-virus ANCOVA")
h3f = pv[pv.group == "H3 2022-24 wild-type"]
key("sn_h3_forward_pervirus", f"{(h3f.GMT29_mrna < h3f.GMT29_flu).sum()}/{len(h3f)} viruses with lower raw d29 GMT in mRNA arm; {(h3f.GMT0_mrna < h3f.GMT0_flu).sum()}/{len(h3f)} with lower d0 GMT; {(h3f.p < 0.05).sum()} nominally significant adjusted differences",
    "H3N2 2022-24 wild-type viruses, per-virus pattern", "neutralization_seqbased.csv", "per-virus ANCOVA")

# coverage / seroconversion breadth
wt = sn.pivot_table(index=["group", "virus", "arm", "pid"], columns="visit", values="titer").reset_index()
cov = []
for g in ["H3 2022-24 wild-type", "H1 2022-23 wild-type"]:
    s = wt[wt.group == g].copy(); s["sc"] = s.d29 / s.d0 >= 4
    pp = s.groupby(["arm", "pid"]).agg(frac_4fold=("sc", "mean"), frac_ge160_d29=("d29", lambda x: (x >= 160).mean()))
    x = pp.loc["mRNA-1010"].frac_4fold; y = pp.loc["Fluarix"].frac_4fold
    cov.append(dict(group=g, median_frac_4fold_mrna=x.median(), median_frac_4fold_flu=y.median(), p=stats.mannwhitneyu(x, y).pvalue,
                    n_majority_4fold_mrna=f"{(x >= .5).sum()}/{len(x)}", n_majority_4fold_flu=f"{(y >= .5).sum()}/{len(y)}"))
    key(f"sn_cov_{g}", f"median fraction of panel with >=4-fold rise: mRNA {x.median():.2f} vs Fluarix {y.median():.2f} (MWU p={stats.mannwhitneyu(x, y).pvalue:.2g}); participants with >=4-fold rise to >=50% of panel: mRNA {(x>=.5).sum()}/{len(x)}, Fluarix {(y>=.5).sum()}/{len(y)}",
        f"seq-neut breadth of seroconversion, {g}", "neutralization_seqbased.csv", "participant-level fraction of viruses with d29/d0 >= 4")
pd.DataFrame(cov).to_csv(f"{RES}/seqneut_breadth_coverage.csv", index=False)

# binding vs neutralisation dissociation (same participants)
ef = elisa[(elisa.measure == "fold_change") & (elisa.timepoint == "wk4")].copy(); ef["pid"] = ef.participant.map(pid3)
ef["subtype"] = ef.antigen.map({"A/H1": "H1N1", "A/H3": "H3N2"}); ef = ef.dropna(subset=["subtype"])
nf = sn[(~sn.reassortant) & (sn.year >= 2022)].groupby(["subtype", "arm", "pid", "visit"]).l2_primary.mean().unstack("visit").reset_index()
nf["l2_neut_fr"] = nf.d29 - nf.d0
bn = nf.merge(ef[["pid", "subtype", "value"]], on=["pid", "subtype"]); bn["l2_bind_fr"] = np.log2(bn.value)
bn["bind_over_neut"] = bn.l2_bind_fr - bn.l2_neut_fr
rows = []
for s_, s in bn.groupby("subtype"):
    x = s[s.arm == "mRNA-1010"]; y = s[s.arm == "Fluarix"]
    rows.append(dict(subtype=s_, n=f"{len(x)}/{len(y)}", bind_GMFR_mrna=2 ** x.l2_bind_fr.mean(), bind_GMFR_flu=2 ** y.l2_bind_fr.mean(),
                     neut_GMFR_mrna=2 ** x.l2_neut_fr.mean(), neut_GMFR_flu=2 ** y.l2_neut_fr.mean(),
                     bind_over_neut_mrna=2 ** x.bind_over_neut.mean(), bind_over_neut_flu=2 ** y.bind_over_neut.mean(),
                     p=stats.mannwhitneyu(x.bind_over_neut, y.bind_over_neut).pvalue))
bnd = pd.DataFrame(rows); bnd.to_csv(f"{RES}/binding_vs_neutralisation.csv", index=False)
for _, r in bnd.iterrows():
    key(f"bind_vs_neut_{r.subtype}", f"binding IgG GMFR mRNA {r.bind_GMFR_mrna:.2f} vs Fluarix {r.bind_GMFR_flu:.2f}; neutralisation GMFR (2022+ wild-type panel) {r.neut_GMFR_mrna:.2f} vs {r.neut_GMFR_flu:.2f}; binding/neutralisation fold-rise ratio {r.bind_over_neut_mrna:.2f} vs {r.bind_over_neut_flu:.2f} (MWU p={r.p:.2g})",
        f"binding vs neutralisation in the same participants, {r.subtype} (n={r.n})", "elisa_igg_titers.csv + neutralization_seqbased.csv", "within-participant log2 fold-rise difference")

# bead-array adjusted for baseline neutralisation (closest available proxy for baseline immunity)
base = sn[~sn.reassortant & (sn.visit == "d0")].groupby(["subtype", "pid"]).l2_primary.mean().rename("base").reset_index()
for sub, b, st in [("H1", bh1, "H1N1"), ("H3", bh3, "H3N2")]:
    b = b.copy(); b["pid"] = b.participant.map(pid3)
    pm = b.groupby(["arm", "pid"]).log2_fold_change_mfi.mean().rename("bfc").reset_index()
    m = pm.merge(base[base.subtype == st], on="pid").dropna(); m["mrna"] = (m.arm == "mRNA-1010").astype(int)
    r = smf.ols("bfc ~ mrna + base", m).fit()
    key(f"bead_adj_{sub}", f"mean log2FC difference {r.params.mrna:.2f} (= {2**r.params.mrna:.1f}-fold), p={r.pvalues.mrna:.2g}, n={len(m)}",
        f"bead-array {sub} binding breadth (mean across strains), mRNA - Fluarix, adjusted for baseline neutralisation", f"binding_breadth_{sub.lower()}.csv + neutralization_seqbased.csv", "OLS")

# =====================================================================================
# 6. Cellular / repertoire
# =====================================================================================
split = gc.index[(gc.timepoint == "wk0") & (gc.arm == "Fluarix") & (gc.participant == "001")].tolist()
gc["block"] = np.where(gc.index < split[1], "A (first block)", "B (second, unlabelled duplicate header)")
issue("gc_frequencies.csv", f"File contains two complete blocks ({split[1]} rows each) under the same column header 'pct_ha_specific_igg_gc' with different values (e.g. 397-028 wk2: {gc.loc[(gc.participant=='028')&(gc.timepoint=='wk2'),'pct_ha_specific_igg_gc'].round(1).tolist()})",
      "Second block is uninterpretable (different specificity/isotype?); only the first block is used, and even that assignment is an assumption. "
      "Also, GC/plasmablast timepoints (wk0/2/8/17/26) do not match the stated FNA schedule (wk1/2/4/8/17/26): wk0 is not in the schedule and wk1/wk4 are absent.")
rows = []
for (bl, tp), s in gc.groupby(["block", "timepoint"]):
    x = s[s.arm == "mRNA-1010"].pct_ha_specific_igg_gc; y = s[s.arm == "Fluarix"].pct_ha_specific_igg_gc
    rows.append(dict(block=bl, timepoint=tp, n_mrna=len(x), n_flu=len(y), median_mrna=x.median(), median_flu=y.median(), p_MWU=stats.mannwhitneyu(x, y).pvalue))
gct = pd.DataFrame(rows); gct.to_csv(f"{RES}/gc_summary.csv", index=False)
for _, r in gct[gct.block.str.startswith("A")].iterrows():
    key(f"gc_{r.timepoint}", f"median {r.median_mrna:.1f}% vs {r.median_flu:.1f}% (n={r.n_mrna}/{r.n_flu}, MWU p={r.p_MWU:.2g})",
        f"HA-specific IgG GC B cells, {r.timepoint} (block A)", "gc_frequencies.csv", "Mann-Whitney U")

fna = set(zip(gc.arm, gc.participant))
pb["in_fna"] = [(a, p) in fna for a, p in zip(pb.arm, pb.participant)]
pb["n_decimals"] = pb.pct_plasmablast.astype(str).str.split(".").str[1].str.len()
extra = pb[~pb.in_fna].groupby("arm").participant.unique()
issue("plasmablast_frequencies.csv", f"Timepoints (wk0/2/8/17/26) match the FNA schedule, but file holds 15 Fluarix / 13 mRNA participants vs the declared FNA cohort of 11 / 6; extra IDs Fluarix {list(extra['Fluarix'])}, mRNA {list(extra['mRNA-1010'])}; extra rows recorded at lower precision (mean {pb[~pb.in_fna].n_decimals.mean():.1f} vs {pb[pb.in_fna].n_decimals.mean():.1f} decimals)",
      "Compartment (blood vs lymph node) and provenance of 11 participants unverified; analysed with and without them.")
rows = []
for lab, s0 in [("all rows", pb), ("declared FNA cohort only", pb[pb.in_fna])]:
    for tp, s in s0.groupby("timepoint"):
        x = s[s.arm == "mRNA-1010"].pct_plasmablast; y = s[s.arm == "Fluarix"].pct_plasmablast
        rows.append(dict(subset=lab, timepoint=tp, n_mrna=len(x), n_flu=len(y), median_mrna=x.median(), median_flu=y.median(), p_MWU=stats.mannwhitneyu(x, y).pvalue))
pbt = pd.DataFrame(rows); pbt.to_csv(f"{RES}/plasmablast_summary.csv", index=False)
for _, r in pbt[pbt.timepoint.isin(["wk2", "wk26"])].iterrows():
    key(f"pb_{r.subset}_{r.timepoint}", f"median {r.median_mrna:.3f}% vs {r.median_flu:.3f}% (n={r.n_mrna}/{r.n_flu}, MWU p={r.p_MWU:.2g})",
        f"plasmablast frequency {r.timepoint} [{r.subset}]", "plasmablast_frequencies.csv", "Mann-Whitney U")

ov["pct_gc_overlap"] = ov["Percentage of overlapping clones out of GC B cell clones"].str.rstrip("%").astype(float)
ov["arm"] = ov.Participant.map(lambda p: "mRNA-1010" if p in ["397-06", "397-17", "397-28", "397-29"] else "Fluarix")
ov.to_csv(f"{RES}/pb_gc_overlap_annotated.csv", index=False)
m_ov = ov[ov.arm == "mRNA-1010"]; f_ov = ov[ov.arm == "Fluarix"]
key("gc_pb_overlap", f"mRNA donors: {', '.join(f'{a:.0f}%' for a in m_ov.pct_gc_overlap)} of GC clones (of {', '.join(map(str, m_ov['Number of GC B cell clones']))} clones) shared with wk1 blood plasmablasts; Fluarix donors: {', '.join(f'{a:.0f}%' for a in f_ov.pct_gc_overlap)} (of {', '.join(map(str, f_ov['Number of GC B cell clones']))} clones)",
    "GC clones overlapping week-1 plasmablast clones", "pb_gc_clonal_overlap.csv", "as reported")
rep["i"] = rep.groupby(["metric", "arm"]).cumcount()
rw = rep.pivot_table(index=["arm", "i"], columns="metric", values="value")
for mtr in rw.columns:
    x = rw.loc["mRNA-1010"][mtr]; y = rw.loc["Fluarix"][mtr]
    key(f"rep_{mtr}", f"median mRNA {x.median():.1f} vs Fluarix {y.median():.1f} (n=8/8, MWU p={stats.mannwhitneyu(x, y).pvalue:.2g})",
        f"serum IgG repertoire: {mtr}", "repertoire_clonotype_counts.csv", "Mann-Whitney U (rows unlinked to participant IDs)")
cdr_w4 = cdr[cdr.timepoint == "wk4"]
key("cdrh3_wk4", f"median {cdr_w4[cdr_w4.arm=='mRNA-1010'].diversity_index.median():.1f} vs {cdr_w4[cdr_w4.arm=='Fluarix'].diversity_index.median():.1f} (n=8/8)",
    "CDRH3 diversity index at wk4", "cdrh3_diversity_index.csv", "median")

igm["pid"] = igm.participant.map(pid3)
for a, s in igm.groupby("antigen"):
    x = s[s.arm == "mRNA-1010"].fold_change; y = s[s.arm == "Fluarix"].fold_change
    key(f"igm_{a}", f"GMFR mRNA {gm(x):.2f} vs Fluarix {gm(y):.2f}; >=4-fold: {(x>=4).sum()}/{len(x)} vs {(y>=4).sum()}/{len(y)} (MWU p={stats.mannwhitneyu(x, y).pvalue:.2g})",
        f"IgM fold change {a}", "igm_fold_change.csv", "GMFR, Mann-Whitney U")

# mAbs
mw_ = mab.pivot_table(index=["panel", "arm", "donor", "mab_id"], columns="antigen", values="fold_over_control")
rows = []
for panel in ["group_I", "group_II"]:
    s = mw_.loc[panel].dropna(axis=1, how="all").drop(columns=["SARS-CoV-2 RBD"])
    pos = (s >= 3)
    for arm in ["mRNA-1010", "Fluarix"]:
        pa = pos.loc[arm]
        donor_means = pa.groupby(level="donor").mean()
        for ag in s.columns:
            rows.append(dict(panel=panel, arm=arm, antigen=ag, n_mabs=len(pa), n_donors=pa.index.get_level_values("donor").nunique(),
                             pct_pos_pooled=100 * pa[ag].mean(), pct_pos_donor_mean=100 * donor_means[ag].mean()))
mabt = pd.DataFrame(rows); mabt.to_csv(f"{RES}/mab_breadth_by_arm.csv", index=False)
cnt = mab.groupby(["arm", "donor"]).mab_id.nunique()
key("mab_counts", "; ".join(f"{a} donor {d}: {n}" for (a, d), n in cnt.items()), "mAbs per donor (both panels)", "mab_binding_panels.csv", "unique mab_id")
for ag in ["A/Hubei/1/2010 (H5)", "A/Shanghai/1/2013 (H7)", "A/Hong Kong/1/1968", "A/Netherlands/01317/2025", "A/Croatia/10136RV/2023"]:
    s = mabt[mabt.antigen == ag]
    if len(s):
        key(f"mab_{ag}", "; ".join(f"{r.arm}: {r.pct_pos_pooled:.0f}% of {r.n_mabs} mAbs ({r.n_donors} donors; donor-mean {r.pct_pos_donor_mean:.0f}%)" for _, r in s.iterrows()),
            f"mAbs binding {ag} at >=3x over control", "mab_binding_panels.csv", "pooled and donor-averaged proportions")

# =====================================================================================
# 7. Remaining integrity checks
# =====================================================================================
b = hai[hai.timepoint == "wk17"].groupby("antigen").participant.apply(lambda x: sorted(set(x)))
issue("hai_titers.csv", f"Week-17 participants differ by antigen: B/Vic {b['B/Vic']} vs other antigens {b['A/H1N1']}; B/Vic has 13 mRNA participants (397-031 absent)",
      "Visit labels are not consistent within a single assay; late-timepoint HAI comparisons are unreliable until reconciled.")
snl = sn[sn.day == 121].pid.unique(); mnl = mn[(mn.timepoint == "wk17")].participant.map(pid3).unique()
issue("neutralization_seqbased.csv vs microneutralization.csv", f"Late visit for Fluarix 397-007 and 397-011 is day 121 in the sequencing-based assay but week 26 in MN/HAI/ELISA (seq-neut d121 IDs {sorted(snl)}; MN wk17 IDs {sorted(mnl)})",
      "Late-timepoint samples may not be the same draw across assays.")
issue("neutralization_seqbased.csv", "Virus name 'A/SOUTHAFRICA/R07876/202023_H3N2' has a malformed year; 'A/Victoria/4897/2022' (the mRNA-1010 H1) is present only as the egg reassortant IVR-238",
      "Panel metadata need curation; the mRNA arm's own H1 is represented only by an egg-adapted reassortant.")
issue("microneutralization.csv / hai_titers.csv / elisa_igg_titers.csv", "The viruses/antigens behind 'homologous', 'heterologous', 'A/H1N1', 'A/H3N2', 'A/H1', 'A/H3' are not identified; homologous/heterologous are defined relative to mRNA-1010 antigens only (trial_summary.md)",
      "For Fluarix recipients the 'homologous' H1 target is a different strain from the one they received; MN/HAI/ELISA cannot be read as symmetric breadth comparisons.")
issue("Identifiers", "Formats differ: '397-0NN' (serology), bare integers (ELISA), 3-digit strings (HAI/GC/PB), unpadded '20' (IgM), 2-digit '397-NN' (clonal overlap), no IDs at all (repertoire, serum clonotypes, CDRH3 files)",
      "Repertoire readouts cannot be linked to serology; cross-assay linkage relies on inferred mapping.")
issue("Covariates", "No age, sex, site, prior-vaccination history, vaccination date, dose, or reactogenicity/safety data anywhere in the package",
      "Site-based allocation cannot be checked for balance; no benefit-risk assessment possible.")
issue("binding_breadth_h1/h3.csv", "Only log2 fold-change is supplied (no baseline MFI, no timepoint label)",
      "Bead-array breadth cannot be baseline-adjusted directly.")
issue("Antigen composition", "mRNA-1010 H1 = A/Victoria/4897/2022-like (WHO pick for 2023-24); Fluarix 2022-23 H1 = A/Victoria/2570/2019-like (egg); H3 = A/Darwin/6/2021 (cell reference) vs A/Darwin/9/2021 (egg reference) [Fluarix composition from WHO 2022-23 NH recommendation / label - external to the package]",
      "Arm differences in H1 (strain) and H3 (egg adaptation) are confounded with platform.")
pd.DataFrame(issues).to_csv(f"{RES}/data_integrity_issues.csv", index=False)

# =====================================================================================
# 8. Sample-size inputs for the next study (from observed variability)
# =====================================================================================
z = stats.norm.ppf
ss_rows = []
for _, r in sg[sg.analysis == "primary"].iterrows():
    for R in [1.5, 2.0]:
        for alpha, lab in [(0.05, "two-sided 0.05"), (0.0125, "two-sided 0.0125 (4 comparisons)")]:
            n = 2 * ((z(1 - alpha / 2) + z(0.9)) * r.resid_SD_log2 / np.log2(R)) ** 2
            ss_rows.append(dict(group=r.group, resid_SD_log2=r.resid_SD_log2, target_ratio=R, alpha=lab, power=0.9, n_per_arm=int(np.ceil(n))))
    # n needed to detect the observed effect
    if r.adj_d29_ratio > 1:
        n_obs = 2 * ((z(0.975) + z(0.9)) * r.resid_SD_log2 / np.log2(r.adj_d29_ratio)) ** 2
        ss_rows.append(dict(group=r.group, resid_SD_log2=r.resid_SD_log2, target_ratio=round(r.adj_d29_ratio, 2), alpha="two-sided 0.05", power=0.9, n_per_arm=int(np.ceil(n_obs))))
ssz = pd.DataFrame(ss_rows); ssz.to_csv(f"{RES}/sample_size_breadth_endpoint.csv", index=False)
for g in ["H3 2022-24 wild-type", "H1 2022-23 wild-type"]:
    s = ssz[(ssz.group == g)]
    key(f"ss_{g}", "; ".join(f"ratio {r.target_ratio}, {r.alpha}: {r.n_per_arm}/arm" for _, r in s.iterrows()) + f" (residual SD {s.resid_SD_log2.iloc[0]:.2f} log2)",
        f"evaluable n per arm for 90% power, baseline-adjusted panel GMT ratio, {g}", "neutralization_seqbased.csv (variance)", "n = 2((z_a/2+z_b) sd / log2 R)^2")
# HAI NI (licensure-style) using observed SDs
sd_hai = hai_cmp[["SD_log2_wk4_Flu", "SD_log2_wk4_mRNA"]].values.max()
n_gmt = 2 * ((z(0.975) + z(0.9)) * sd_hai / np.log2(1.5)) ** 2
n_scr = lambda p: 2 * p * (1 - p) * (z(0.975) + z(0.9)) ** 2 / 0.10 ** 2
key("ss_hai_ni", f"GMT-ratio NI (margin 1.5, SD {sd_hai:.2f} log2): {int(np.ceil(n_gmt))}/arm per strain; seroconversion NI (margin 10 pts): {int(np.ceil(n_scr(0.5)))}/arm at SCR 50%, {int(np.ceil(n_scr(0.15)))}/arm at SCR 15%",
    "evaluable n per arm, 90% power, one-sided 0.025 - licensure-style HAI non-inferiority (CBER 2007 margins)", "hai_titers.csv (variance); margins from FDA/CBER 2007 guidance", "normal approximation")
# efficacy event counts (external assumptions)
for rve in [0.2, 0.3, 0.4]:
    D = 4 * (z(0.975) + z(0.9)) ** 2 / np.log(1 - rve) ** 2
    for ar in [0.005, 0.01, 0.02]:
        N = D / (ar * (1 + (1 - rve)) / 2)
        ss_rows.append(dict(group=f"efficacy rVE {rve:.0%}", resid_SD_log2=np.nan, target_ratio=np.nan, alpha=f"comparator attack rate {ar:.1%} (assumed)", power=0.9, n_per_arm=int(np.ceil(N / 2))))
    key(f"ss_eff_{int(rve*100)}", f"{int(np.ceil(D))} mismatched-strain cases; total N ~{int(np.ceil(D/(0.01*(2-rve)/2))):,} participant-seasons at an assumed 1.0% comparator attack rate (~{int(np.ceil(D/(0.02*(2-rve)/2))):,} at 2.0%)",
        f"efficacy trial size for relative VE {rve:.0%} vs licensed vaccine (superiority, 90% power, two-sided 0.05, 1:1)", "attack rates are planning assumptions, not from the package", "Schoenfeld events formula")
pd.DataFrame(ss_rows).to_csv(f"{RES}/sample_size_all.csv", index=False)
# FNA sub-study: bootstrap power from the WU397 GC values (block A), Mann-Whitney at 0.05
rng = np.random.default_rng(1)
gA_ = gc[gc.block.str.startswith("A")]
fna_rows = []
for tp in ["wk2", "wk8", "wk17", "wk26"]:
    x = gA_[(gA_.timepoint == tp) & (gA_.arm == "mRNA-1010")].pct_ha_specific_igg_gc.values
    y = gA_[(gA_.timepoint == tp) & (gA_.arm == "Fluarix")].pct_ha_specific_igg_gc.values
    for n in [15, 20, 25, 40]:
        hits = sum(stats.mannwhitneyu(rng.choice(x, n), rng.choice(y, n)).pvalue < 0.05 for _ in range(2000))
        fna_rows.append(dict(timepoint=tp, n_per_arm=n, bootstrap_power=hits / 2000))
fna_pw = pd.DataFrame(fna_rows); fna_pw.to_csv(f"{RES}/fna_substudy_bootstrap_power.csv", index=False)
fp = fna_pw[fna_pw.n_per_arm == 25].set_index("timepoint").bootstrap_power
key("ss_fna", f"25/arm: wk2 {fp['wk2']:.2f}, wk8 {fp['wk8']:.2f}, wk17 {fp['wk17']:.2f}, wk26 {fp['wk26']:.2f}",
    "bootstrap power (MWU, 0.05) of a randomised FNA sub-study if WU397 GC effect sizes hold", "gc_frequencies.csv (block A)", "resampling observed values, 2000 draws")
# CHIM: two-proportion sample sizes under stated planning assumptions (not from the package)
from statsmodels.stats.power import NormalIndPower
from statsmodels.stats.proportion import proportion_effectsize
chim = []
for p1, p2, lab in [(0.40, 0.12, "placebo 40% vs mRNA 12% (VE 70%)"), (0.40, 0.20, "placebo 40% vs mRNA 20% (VE 50%)"),
                    (0.25, 0.12, "licensed IIV 25% vs mRNA 12%"), (0.30, 0.15, "licensed IIV 30% vs mRNA 15%")]:
    es = proportion_effectsize(p1, p2)
    chim.append(dict(scenario=lab, n80=int(np.ceil(NormalIndPower().solve_power(es, alpha=0.05, power=0.8))),
                     n90=int(np.ceil(NormalIndPower().solve_power(es, alpha=0.05, power=0.9)))))
chim = pd.DataFrame(chim); chim.to_csv(f"{RES}/chim_sample_size_assumptions.csv", index=False)
key("ss_chim", "; ".join(f"{r.scenario}: {r.n80}/arm (80%), {r.n90}/arm (90%)" for _, r in chim.iterrows()),
    "CHIM evaluable n per arm (two-sided 0.05) under planning assumptions for symptomatic laboratory-confirmed infection", "assumed attack rates - not from the package", "arcsine effect size, normal approximation")


# =====================================================================================
# 9. Figures
# =====================================================================================
# Fig 1: per-virus forest, grouped
order = ["H1 2009-19 wild-type", "H1 2022-23 wild-type", "H3 2012-20 wild-type", "H3 2021 vaccine strains (Darwin/6, Darwin/9)", "H3 2022-24 wild-type", "egg/reassortant"]
colors = dict(zip(order, ["#9ecae1", "#08519c", "#fdae6b", "#d94801", "#a63603", "#969696"]))
pvs = pv.copy(); pvs["g"] = pd.Categorical(pvs.group, order); pvs = pvs.sort_values(["g", "year", "virus"]).reset_index(drop=True)
fig, ax = plt.subplots(figsize=(8, 17))
ypos = np.arange(len(pvs))[::-1]
for i, r in pvs.iterrows():
    ax.plot([r.lo, r.hi], [ypos[i]] * 2, color=colors[r.group], lw=1)
    ax.plot(r.adj_ratio, ypos[i], "o", color=colors[r.group], ms=4)
ax.axvline(1, color="k", lw=0.8)
ax.set_xscale("log")
ax.set_yticks(ypos); ax.set_yticklabels([v.replace("_H3N2", "").replace("_H1N1", "") for v in pvs.virus], fontsize=5)
ax.set_xlabel("Baseline-adjusted day-29 neutralising GMT ratio, mRNA-1010 / Fluarix (95% CI)")
for gname in order:
    ax.plot([], [], "o", color=colors[gname], label=gname)
ax.legend(fontsize=6, loc="lower right")  # legend bottom-right, estimates bottom-left
pr = sg[sg.analysis == "primary"].set_index("group")
txt = "\n".join(f"{g}: {pr.loc[g,'adj_d29_ratio']:.2f} [{pr.loc[g,'adj_d29_lo']:.2f}-{pr.loc[g,'adj_d29_hi']:.2f}]" for g in order)
ax.text(0.02, 0.005, "Participant-level pooled (panel-mean) estimates:\n" + txt, transform=ax.transAxes, fontsize=6, va="bottom",
        bbox=dict(fc="white", ec="grey"))
ax.set_ylim(-12, len(pvs) + 1)
ax.set_xticks([0.25, 0.5, 1, 2, 4]); ax.set_xticklabels(["0.25", "0.5", "1", "2", "4"]); ax.minorticks_off()
ax.set_title("WU397 sequencing-based neutralisation (n = 13 mRNA-1010, 14 Fluarix)", fontsize=8)
plt.tight_layout(); plt.savefig(f"{FIG}/fig1_seqneut_per_virus_forest.png", dpi=200); plt.close()

# Fig 2: readout-by-readout adjusted ratios
items = []
for _, r in el_tab[(el_tab.subset == "all") & el_tab.antigen.isin(["A/H1", "A/H3"])].iterrows():
    items.append((f"ELISA IgG {r.antigen} wk4 (n=75)", r.adj_ratio_wk4, r.lo4, r.hi4, "binding"))
    items.append((f"ELISA IgG {r.antigen} wk17/26 (n=75)", r.adj_ratio_late, r.lol, r.hil, "binding"))
for g in ["H1 2022-23 wild-type", "H3 2022-24 wild-type", "H3 2021 vaccine strains (Darwin/6, Darwin/9)"]:
    r = pr.loc[g]
    items.append((f"Neut {g} d29 (n=27)", r.adj_d29_ratio, r.adj_d29_lo, r.adj_d29_hi, "neutralisation"))
    items.append((f"Neut {g} d181 only (n={r.n_d181})", r.adj_d181only_ratio, r.adj_d181_lo, r.adj_d181_hi, "neutralisation"))
for _, r in mn_cmp.iterrows():
    items.append((f"MN '{r.panel}' wk4 (n=29)", r.adj_ratio_wk4, r.lo4, r.hi4, "neutralisation"))
for _, r in hai_cmp[hai_cmp.antigen.isin(["A/H1N1", "A/H3N2"])].iterrows():
    items.append((f"HAI {r.antigen} wk4 (n=29)", r.adj_GMT_ratio_wk4, r.lo, r.hi, "HAI"))
fig, ax = plt.subplots(figsize=(8, 6))
cmap = {"binding": "#6a51a3", "neutralisation": "#cb181d", "HAI": "#238b45"}
for i, (lab, r, lo, hi, kind) in enumerate(items[::-1]):
    ax.plot([lo, hi], [i, i], color=cmap[kind]); ax.plot(r, i, "o", color=cmap[kind])
ax.set_yticks(range(len(items))); ax.set_yticklabels([it[0] for it in items[::-1]], fontsize=7)
ax.axvline(1, color="k", lw=0.8); ax.set_xscale("log")
ax.set_xticks([0.25, 0.5, 1, 2, 4]); ax.set_xticklabels(["0.25", "0.5", "1", "2", "4"]); ax.minorticks_off()
ax.set_xlabel("Baseline-adjusted GMT ratio, mRNA-1010 / Fluarix (95% CI)")
for k, c in cmap.items(): ax.plot([], [], "o", color=c, label=k)
ax.legend(fontsize=7, loc="lower right"); ax.set_title("WU397: binding advantage is robust; neutralisation advantage only for H1 at d29, gone by d181", fontsize=8)
plt.tight_layout(); plt.savefig(f"{FIG}/fig2_binding_vs_function_summary.png", dpi=200); plt.close()

# Fig 3: GC and PB trajectories
tps = ["wk0", "wk2", "wk8", "wk17", "wk26"]
fig, axes = plt.subplots(1, 2, figsize=(10, 4))
gA = gc[gc.block.str.startswith("A")]
for arm, c in [("mRNA-1010", "#cb181d"), ("Fluarix", "#2171b5")]:
    for p_, s in gA[gA.arm == arm].groupby("participant"):
        s = s.set_index("timepoint").reindex(tps)
        axes[0].plot(range(5), s.pct_ha_specific_igg_gc, color=c, alpha=0.35, lw=0.8)
    med = gA[gA.arm == arm].groupby("timepoint").pct_ha_specific_igg_gc.median().reindex(tps)
    axes[0].plot(range(5), med, color=c, lw=2.5, label=f"{arm} median")
    s0 = pb[(pb.arm == arm) & pb.in_fna]
    med = s0.groupby("timepoint").pct_plasmablast.median().reindex(tps)
    axes[1].plot(range(5), med, color=c, lw=2.5, label=f"{arm} median (declared FNA cohort)")
    s1 = pb[(pb.arm == arm) & ~pb.in_fna]
    med1 = s1.groupby("timepoint").pct_plasmablast.median().reindex(tps)
    axes[1].plot(range(5), med1, color=c, lw=1.2, ls="--", label=f"{arm} median (unverified extra IDs)")
for a_ in axes: a_.set_xticks(range(5)); a_.set_xticklabels(tps)
axes[0].set_ylabel("% HA-specific IgG among GC B cells (block A)"); axes[0].legend(fontsize=7); axes[0].set_title("Germinal centre (n=6 vs 11)", fontsize=9)
axes[1].set_ylabel("% plasmablasts"); axes[1].legend(fontsize=6); axes[1].set_title("Plasmablasts (compartment unstated)", fontsize=9)
plt.tight_layout(); plt.savefig(f"{FIG}/fig3_gc_pb.png", dpi=200); plt.close()

pd.DataFrame(KEY).to_csv(f"{RES}/key_numbers.csv", index=False)
print(f"wrote {len(KEY)} key numbers, {len(issues)} integrity issues")
print(sg[sg.analysis == 'primary'][["group", "baseline_ratio", "GMFR_ratio", "unadj_d29_ratio", "adj_d29_ratio", "adj_d29_lo", "adj_d29_hi", "adj_d29_p", "adj_late_ratio", "adj_d181only_ratio", "late_over_d29_mrna", "late_over_d29_flu"]].round(3).to_string())
print(sg[sg.analysis != 'primary'][["group", "adj_d29_ratio", "adj_d29_lo", "adj_d29_hi"]].round(3).to_string())
