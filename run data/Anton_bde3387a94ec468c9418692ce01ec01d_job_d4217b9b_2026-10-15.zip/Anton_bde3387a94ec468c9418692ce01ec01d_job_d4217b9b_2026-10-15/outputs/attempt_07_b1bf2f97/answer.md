**Recommendation:** WU397 does not yet support a heterologous-protection claim (mRNA-1010 raised binding antibody and germinal-centre responses but not baseline-adjusted neutralisation of drifted H3N2, and its H1 edge was antigen-confounded and gone by day 181), so the next study should be a randomised, observer-blind, strain-matched Phase 2 — mRNA vs Fluarix vs a non-egg vaccine carrying identical strains, in 18–64 and ≥65 cohorts — powered on baseline-adjusted neutralising titre against a locked panel of drifted wild-type viruses at day 29 with day-91/181 durability, and its result should gate a heterologous human-challenge study and then a mismatched-strain relative-efficacy trial.

---

## 1. Bottom line for the committee

1. **Where mRNA-1010 does better (binding antibody and B-cell engagement).**
   - **Binding IgG (ELISA, n = 38/37).** After adjusting for baseline, mRNA-1010 gave 3.31× Fluarix's H3 binding IgG at week 4 [2.47–4.43] and 2.66× for H1 [2.01–3.53]. At week 17/26 the ratios were still 2.06× (H3) and 1.51× (H1).
   - **Breadth of binding (bead array).** mRNA-1010 had larger binding rises on 20 of 21 HAs, including A/Puerto Rico/8/1934 and A/Hong Kong/1/1968.
   - **Germinal centres.** Lymph-node germinal-centre responses were larger and lasted longer. At week 2, a median 24.2% of germinal-centre B cells were HA-specific after mRNA-1010 versus 2.3% after Fluarix (n = 6 vs 11, p = 0.037).
2. **Where it does not: the functional antibody a heterologous claim rests on.**
   - **Forward-drift test.** The package's strongest forward-drift test is 68 wild-type H3N2 viruses from 2022–24 in the sequencing-based neutralisation panel. Against these, baseline-adjusted day-29 neutralisation was **1.17× Fluarix [0.64–2.12], p = 0.60**, and **0.98× [0.58–1.66] at day 181**.
   - **Raw titres and the fold-rise artefact.** Raw day-29 titres were *lower* in the mRNA arm for 59 of the 68 viruses. The 1.30× fold-rise "advantage" is mostly explained by the mRNA arm starting lower: its baseline was 0.66× Fluarix's, and lower for all 68 viruses. That imbalance is consistent with allocating participants by site rather than by randomisation.
   - **Against its own H3 antigen.** mRNA-1010 neutralised its own H3 strain (A/Darwin/6/2021) no better than Fluarix did; the point estimate was lower (adjusted 0.62× [0.34–1.12]).
   - **HAI and microneutralisation.** HAI showed no difference for any component. Microneutralisation showed no difference either: adjusted 0.68× for the "homologous" panel and 1.17× for the "heterologous" panel, with unidentified viruses and 9 of 15 Fluarix sera at the assay ceiling.
3. **H1 is the exception, but it is confounded and short-lived.**
   - At day 29, neutralisation of the seven 2022–23 H1N1 viruses was **2.08× [1.25–3.44]** higher with mRNA-1010.
   - The two arms received *different* H1s. mRNA-1010 carried A/Victoria/4897/2022-like H1, which WHO picked for 2023–24. Fluarix 2022–23 carried the egg-grown A/Victoria/2570/2019-like H1.
   - The edge had fallen to **1.15× [0.69–1.94] by day 181**. mRNA-arm titres dropped to 0.44× of their day-29 level, against 0.77× for Fluarix (p = 0.0004).
4. **Binding does not mean function.**
   - In the same 27 people, mRNA-1010 raised H3 binding IgG 8.0-fold but neutralisation of drifted H3 only 2.8-fold. For Fluarix the two rises matched (2.2 and 2.2).
   - The ratio of binding rise to neutralisation rise was 2.84 versus 1.01 (p = 0.0015). Most of the extra antibody mRNA-1010 makes is therefore non-neutralising.
   - Nothing in the package tests whether that extra antibody protects by other routes, such as Fc-mediated effects or neuraminidase (NA) inhibition.
5. **The design cannot separate platform from other explanations.**
   - The arm difference could come from the platform, the choice of antigen, egg adaptation, site or calendar time.
   - The package has no data on age, sex, site, vaccination history, vaccination date, dose or safety.
   - It includes B/Yamagata, which has not been detected in circulation since 2020, and has no drifted B/Victoria panel.
   - There are 12 data-integrity problems (Section 6).
6. **Consequence.** "Heterologous protection" is currently a hypothesis supported only by mechanistic signals.
   - The next study must be randomised, strain-matched and include a non-egg comparator.
   - It must be powered on baseline-adjusted neutralisation against a locked panel of drifted viruses, with durability, NA and Fc readouts.
   - Evidence of clinical protection (a challenge study, then efficacy against mismatched strains) should be gated on its result.

Figure summary: `analysis/figures/fig2_binding_vs_function_summary.png` (each readout's adjusted ratio) and `analysis/figures/fig1_seqneut_per_virus_forest.png` (all 96 viruses).

---

## 2. What WU397 shows, and what it cannot show

### 2.1 Design facts that limit inference

| Fact | Evidence | Consequence for the claim |
|---|---|---|
| **Non-randomised, open-label; allocation by enrolment site** | `trial_summary.md`. The ELISA-only participants sit in arm-specific ID blocks: Fluarix 033–059 (n = 22), mRNA 064–102 (n = 24). Only IDs 001–032 interleave the two arms. | Baseline immunity was not balanced. The mRNA arm's neutralising titres were lower at baseline (Section 2.3). Any fold-rise comparison is biased in its favour. |
| **The arms got different antigens** | mRNA-1010 H1 was A/Victoria/4897/2022-like; Fluarix 2022–23 H1 was A/Victoria/2570/2019-like, egg-based (*external: WHO Feb-2022 Northern Hemisphere egg-based recommendation / Fluarix label — verify against the lot's package insert*). mRNA-1010 H3 was A/Darwin/6/2021, the cell-based reference; Fluarix H3 was A/Darwin/9/2021, the egg-based reference. | An H1 difference cannot be attributed to the platform. An H3 difference could be an egg-adaptation effect. |
| **"Homologous/heterologous" is defined only against mRNA-1010's antigens** | `trial_summary.md` | For Fluarix recipients, the "homologous" H1 target is not the strain they received. The microneutralisation and HAI panels are not a symmetric breadth test. |
| **Small functional-assay cohorts** | HAI 14/15; microneutralisation 14/15; sequencing-based neutralisation 13/14; lymph-node FNA 6/11 | 95% CIs on the key ratios span roughly 0.6–2.1. |
| **No covariates** | No age, sex, site, prior vaccination, vaccination date, dose, reactogenicity or safety data in any file | Balance cannot be checked or adjusted for, and benefit–risk cannot be judged. |
| **Calendar time** | A/Victoria/4897/2022 was designated by WHO in Feb 2023 for 2023–24 (*external*). Vaccination dates are absent. | mRNA participants may have been vaccinated later in an early-peaking season. That would confound baseline titres and the day-121/181 readouts. |
| **B/Yamagata included** | mRNA-1010 encodes B/Phuket/3073/2013 | No B/Yamagata has been detected since March 2020, and vaccines have moved to trivalent for 2024–25 (*external: WHO/FDA*). No future claim can use these data. |
| **No B/Victoria breadth panel** | The sequencing-based panel has 83 H3N2 and 13 H1N1 viruses and no B | Heterologous B cannot be assessed at all. |
| **No infection surveillance** | — | Intercurrent infection cannot be excluded from late readouts. No participant's panel-mean titre rose between day 29 and the late visit by 2× or more (maximum 1.28×; `seqneut_participant_trajectories.csv`), but single-strain infections would not show up this way. |

### 2.2 Binding antibody and B-cell readouts — the positive signal

**ELISA IgG** (n = 38 mRNA / 37 Fluarix; ANCOVA on log₂ EC50 adjusted for baseline; source `elisa_igg_titers.csv`):

| Antigen | GMFR wk4 (mRNA / Fluarix) | Adjusted GMT ratio wk4 | Adjusted GMT ratio wk17/26 | Core IDs ≤ 032 only (interleaved) |
|---|---|---|---|---|
| A/H1 | 5.07 / 1.90 | 2.66 [2.01–3.53] | 1.51 [1.19–1.91] | 2.10 [1.15–3.82] |
| A/H3 | 7.60 / 1.99 | 3.31 [2.47–4.43] | 2.06 [1.57–2.70] | 3.19 [1.78–5.71] |
| B/Vic | 3.16 / 2.30 | 1.35 [1.04–1.75] | 0.99 [0.78–1.26] | 0.96 [0.64–1.44] |
| B/Yam | 2.67 / 2.03 | 1.38 [1.11–1.71] | 1.06 [0.88–1.29] | 1.01 [0.67–1.53] |

- The A-strain binding advantage is robust: it holds in the interleaved core of 29 participants.
- The B-strain "advantage" appears only in the arm-blocked extra participants, which is consistent with a site effect.
- The ELISA antigens themselves are not identified in the package.

**Bead-array binding breadth** (log₂ fold-change in MFI; n = 14/15; timepoint not stated; sources `binding_breadth_h1.csv`, `binding_breadth_h3.csv`):
- mRNA-1010 had higher medians on 20 of 21 HAs (Mann–Whitney p < 0.05). Examples, mRNA vs Fluarix median log₂ fold-change:
  - A/Hong Kong/1/1968: 3.61 vs 0.17
  - A/Puerto Rico/8/1934: 1.55 vs −0.06
  - A/Darwin/6/2021: 4.48 vs 2.41
  - A/Thailand/8/2022: 4.66 vs 1.56
  - A/Wisconsin/67/2022: 2.15 vs 0.42
- No baseline MFI was supplied. Adjusting instead for each participant's baseline neutralising titre leaves the difference intact: H3 ≈ 5.0-fold (p = 5×10⁻⁵) and H1 ≈ 2.2-fold (p = 3×10⁻⁴).
- Binding to 1934 and 1968 HAs suggests antibodies against conserved, mostly non-neutralising regions such as the stalk.

**Lymph node and B cells** (sources: `gc_frequencies.csv` block A, `plasmablast_frequencies.csv`, `pb_gc_clonal_overlap.csv`, repertoire files):
- **Germinal centres.** Median percentage of HA-specific IgG germinal-centre B cells, mRNA vs Fluarix (n = 6 vs 11 unless stated):
  - week 2: 24.2% vs 2.3% (p = 0.037)
  - week 8: 8.3% vs 1.7% (p = 0.17)
  - week 17: 16.0% vs 2.3% (n = 5/9, p = 0.083)
  - week 26: 18.9% vs 1.6% (n = 5/8, p = 0.34)
- **Plasmablasts (declared FNA cohort only).** Week 2: 0.656% vs 0.031% (p = 0.052). Week 26: 0.145% vs 0.006% (p = 0.034).
- **The germinal centres are mostly re-used pre-existing lineages.** In the four mRNA donors, 92%, 91%, 83% and 73% of germinal-centre clones were also present among week-1 blood plasmablasts (out of 25, 11, 18 and 63 clones). The three Fluarix donors had too few clones to interpret (7, 5 and 1).
- **Serum IgG repertoire (n = 8/8).** Pre-existing clonotypes made up 87.0% vs 88.7% of serum IgG abundance (p = 0.72). Vaccine-elicited clonotypes: median 32 vs 17.5 (p = 0.066).
- **IgM.** Fluarix induced *more* IgM: H3 GMFR 1.83 (mRNA) vs 5.53 (Fluarix), p = 0.013.
- **Reading.** mRNA-1010 drives a larger, longer germinal-centre reaction that mainly re-engages imprinted memory lineages. Serum antibody at week 4 is still about 87% pre-existing clonotypes in both arms.

**Monoclonal antibodies** (`mab_binding_panels.csv`, binding only):
- The arms are badly unbalanced: 589 mAbs from 4 mRNA donors versus 106 from 3 Fluarix donors, 84 of which come from one donor. Donors, not mAbs, are the unit of inference, so this is descriptive only.
- Results are mixed:
  - mRNA-derived H3 mAbs bound A/Hong Kong/1/1968 (47% vs 12%) and H7 (13% vs 0%) more often.
  - Fluarix-derived H1 mAbs bound H5 more often (41% vs 19%).

### 2.3 Functional antibody — the gap

**Sequencing-based neutralisation**
- **Panel.** 96 viruses: 83 H3N2 (5 egg-grown or reassortant) and 13 H1N1 (1 egg-grown reassortant). There are no influenza B viruses. 241 of 7,719 titres are censored. Halving the values below the detection limit barely moves the result: the H3 2022–24 estimate goes from 1.17 to 1.18.
- **Cohort.** n = 13 mRNA / 14 Fluarix.
- **Method.** Each participant's titres are averaged (log₂) across the virus group; day-29 and late titres are then compared in an ANCOVA adjusted for baseline.
- **Exclusions.** Egg-grown and reassortant viruses are excluded from the wild-type groups.
- Source: `neutralization_seqbased.csv` → `analysis/results/seqneut_group_ancova.csv`.

| Virus group (n viruses) | Baseline ratio (mRNA/Flu) | GMFR, mRNA vs Flu | Unadjusted d29 ratio | **Adjusted d29 ratio [95% CI]** | Adjusted d181-only ratio | Late/d29 retained, mRNA vs Flu |
|---|---|---|---|---|---|---|
| **H3 2022–24 wild-type (68)** — forward drift | 0.66 | 2.82 vs 2.17 | 0.86 | **1.17 [0.64–2.12], p = 0.60** | 0.98 [0.58–1.66] | 0.64 vs 0.67 |
| H3 2021 vaccine strains (Darwin/6, Darwin/9) | 0.62 | 3.27 vs 3.51 | 0.58 | 0.71 [0.36–1.38] | 0.53 [0.27–1.01] | 0.54 vs 0.65 |
| H3 2012–20 wild-type (8) — backward | 0.58 | 3.74 vs 1.80 | 1.20 | 1.63 [0.99–2.68], p = 0.056 | 1.02 [0.66–1.58] | 0.64 vs 0.75 |
| **H1 2022–23 wild-type (7)** | 0.91 | 3.99 vs 1.90 | 1.91 | **2.08 [1.25–3.44], p = 0.006** | 1.15 [0.69–1.94] | **0.44 vs 0.77 (p = 0.0004)** |
| H1 2009–19 wild-type (5) | 0.82 | 3.99 vs 2.04 | 1.61 | 1.82 [0.97–3.41] | 1.05 [0.48–2.32] | 0.50 vs 0.83 |
| Egg/reassortant (6), reported separately | 0.89 | 2.70 vs 1.66 | 1.45 | 1.57 [1.10–2.24] | 0.99 [0.65–1.51] | 0.68 vs 0.81 |

- A check at the single-virus level, with standard errors clustered by participant, gives the same answer: H3 2022–24 1.13 [0.69–1.85]; H1 2022–23 2.09 [1.31–3.34].
- **H3, virus by virus.** None of the 68 individual H3 2022–24 comparisons is nominally significant. Viruses later chosen as 2024–25 H3N2 vaccine reference strains (*external: WHO Feb 2024*) show no advantage: A/Thailand/8/2022 0.82 [0.35–1.91]; A/Massachusetts/18/2022 0.90 [0.46–1.79].
- **H1 effect is not only antigen match.** It extends to A/Wisconsin/588/2019, the cell-grown analogue of Fluarix's own H1: adjusted 2.44 [1.18–5.05].
  - But Fluarix's H1 was both egg-grown and a different strain, so platform, egg adaptation and strain choice cannot be separated.
  - Either way the effect is transient.
- **Breadth of seroconversion** (share of the panel with a ≥4-fold rise per participant):
  - H3: median 0.18 vs 0.05 (p = 0.40). Participants with a ≥4-fold rise to at least half the panel: 3/13 vs 3/14.
  - H1: median 0.57 vs 0.00 (p = 0.007). At least half the panel: 7/13 vs 2/14.
- **Pattern.** Where mRNA-1010 adds neutralisation for H3, it points *backwards* to 2012–20 strains (1.63) rather than *forwards* to 2022–24 strains (1.17). That is the back-boosting signature of recalled memory — the opposite of what a forward heterologous claim needs.

**Haemagglutination inhibition (HAI)** (n = 14/15; B/Vic 13/15; `hai_titers.csv`)

| Component | GMT d0→wk4, mRNA | GMT d0→wk4, Fluarix | GMFR ratio (p) | Seroconversion, mRNA / Fluarix | Titre ≥1:40 at wk4 | Late seroconversion |
|---|---|---|---|---|---|---|
| A/H1N1 | 50 → 138 | 39 → 88 | 1.23 (0.26) | 7/14 (50%) / 5/15 (33%) | 14/14 / 14/15 | 0/14 / 5/15 |
| A/H3N2 | 33 → 56 | 35 → 58 | 1.03 (0.69) | 2/14 (14%, CI 2–43%) / 2/15 (13%) | 9/14 / 13/15 | 1/14 / 0/15 |
| B/Vic | 52 → 56 | 49 → 52 | 1.03 (0.68) | 0/13 / 1/15 | 9/13 / 12/15 | 1/13 / 0/15 |
| B/Yam | 66 → 88 | 76 → 99 | 1.05 (0.64) | 0/14 / 1/15 | 14/14 / 15/15 | 0/14 / 0/15 |

- **Not evaluable against the FDA/CBER 2007 non-inferiority criterion** (*external*; upper bound of the Fluarix/mRNA GMT ratio ≤ 1.5): the observed upper bounds were H3 2.15, B/Vic 1.60, B/Yam 1.76. The study is underpowered for this test.
- **Seroconversion is far below the CBER accelerated-approval bar** (lower 95% bound ≥ 40% in adults under 65, ≥ 30% at 65 and over; *external*) in *both* arms — for H3N2 the lower bound is 2% in each. This is a heavily primed population. WU397's ages are not given.

**Microneutralisation** (n = 14/15; panel viruses not named; ceiling 1280; `microneutralization.csv`):
- **"Homologous" panel.** GMT at week 4 was 325 (mRNA) vs 588 (Fluarix). Nine of 15 Fluarix sera sat at the 1280 ceiling, so Fluarix is *under*-estimated. Adjusted ratio 0.68 [0.31–1.51].
- **"Heterologous" panel.** Baseline GMT was 57 vs 121, a 0.47× imbalance. GMFR was 4.12 vs 3.03, but the adjusted ratio was 1.17 [0.52–2.62] at week 4 and 0.73 [0.37–1.45] late.

### 2.4 Binding versus function in the same people

Week-4 ELISA fold-rise versus fold-rise in neutralisation of 2022+ wild-type viruses, same participants (n = 13/14); source `binding_vs_neutralisation.csv`.

| Subtype | Binding GMFR, mRNA / Flu | Neutralisation GMFR, mRNA / Flu | Binding ÷ neutralisation, mRNA / Flu | p |
|---|---|---|---|---|
| H3N2 | 8.01 / 2.20 | 2.82 / 2.17 | **2.84 / 1.01** | 0.0015 |
| H1N1 | 4.92 / 2.06 | 3.99 / 1.90 | 1.24 / 1.08 | 0.32 |

What this means for the claim:
- The H3 antibody surplus from mRNA-1010 is largely non-neutralising.
- If mRNA-1010 confers heterologous protection, it would have to come from one of three sources:
  - non-neutralising, for example Fc-mediated, activity;
  - memory that pays off at the next exposure;
  - an effect that WU397's confounders hid.
- None of these is measured in the package, so each becomes a required readout below.

---

## 3. Recommended studies

The claim has three tiers. Each needs different evidence.

| Claim tier | Evidence required | Study that supplies it |
|---|---|---|
| C1 — "broader neutralising antibody than licensed vaccines, from the platform itself" | Randomised, strain-matched, baseline-adjusted neutralisation against locked drifted and forward panels, durable through the season, with a non-egg control | **Study 1** (informed by Study 0) |
| C2 — "protects against a heterologous strain" (proof of concept) | Reduced lab-confirmed infection or disease after challenge with an antigenically distinct strain | **Study 2** |
| C3 — "greater protection than licensed vaccines against antigenically mismatched influenza" (the label-level claim) | Relative vaccine efficacy against RT-PCR-confirmed illness caused by strains classified as mismatched | **Study 3** |

There is no validated correlate of heterologous protection, so C3 cannot be reached by immunobridging from C1.

### Study 0 — Re-interrogation of stored WU397 samples and data-package remediation (no new enrolment; run before or alongside committee review)

*Purpose.* Close the gaps that decide how Study 1 is built. Cannot remove the allocation confound.

| Readout | In whom | Against what | Decision it informs |
|---|---|---|---|
| Neutralising and HAI titres to **each arm's own vaccine strains** | WU397 sequencing-based neutralisation cohort (13/14) and microneutralisation/HAI cohort (14/15); d0, d29, d181 sera | Fluarix 2022–23 egg-based H1 and H3 references, and mRNA-1010's wild-type antigens | Makes "homologous" symmetric, so each arm's drift from its own strain can be measured |
| **NA-inhibiting antibody** | same | N1 and N2 of the 2022–23 strains, plus drifted NAs; B NA | If mRNA-1010 encodes HA only (as "four antigens" implies), the arms differ in NA immunity, which contributes to heterologous protection |
| **Fc-effector function and stalk-binding antibody** | same | Vaccine and drifted H1/H3 HAs | Tests whether the non-neutralising binding surplus (2.84×) is functional |
| Neutralisation of drifted **B/Victoria** | same | Wild-type B/Victoria isolates, 2022–24 | No B breadth data exist |
| Recover **metadata** | all 75 | Age, sex, site, vaccination date, 3-season vaccination history, dose, reactogenicity | Enables adjusted re-analysis and checks the calendar-time confound |

Consent must cover re-testing of stored samples.

### Study 1 — Randomised, observer-blind, strain-matched Phase 2 "breadth" study *(the decisive next study)*

**Conditions**

- **Design.** Phase 2, 1:1:1 randomisation within each cohort, observer-blind, active-controlled, multicentre, one Northern Hemisphere season. Vaccinate before local influenza activity starts.
  - Randomise individuals, not sites.
  - The vaccines look different, so only the staff who prepare and give them are unblinded; participants, investigators and laboratories stay blinded.
  - Stratify by site, age band (18–49 / 50–64; 65–74 / ≥75) and previous-season vaccination (yes/no).
- **Formulation.** Trivalent in every arm (H1N1pdm09, H3N2, B/Victoria — no B/Yamagata), using the WHO-recommended strains for that season.
  - The mRNA vaccine encodes the **cell/recombinant reference HAs**, so it carries exactly the same strain designations as the non-egg comparator.
  - Use the intended licensure dose. WU397 reports no dose, and the B responses were weak (HAI seroconversion 0/13 B/Vic), so if the dose is not fixed, add a second mRNA dose level.
- **Cohort A (18–64 years), three arms:**
  1. mRNA vaccine;
  2. Fluarix (egg-based standard-dose inactivated vaccine, same season) — the bridge to WU397;
  3. cell-culture standard-dose inactivated vaccine with the **same cell reference strains** as the mRNA vaccine.
  - Arm 3 isolates the platform effect from egg adaptation and strain choice: mRNA vs arm 3 is the platform; arm 3 vs arm 2 is egg adaptation.
- **Cohort B (≥65 years), three arms:** mRNA vs high-dose (or adjuvanted) inactivated vaccine vs recombinant HA vaccine (non-egg).
  - A differentiated claim in older adults has to be made against the vaccines preferentially recommended for them, not standard-dose.
- **Eligibility.**
  - Exclude influenza vaccination or laboratory-confirmed influenza in the prior 6 months, immunosuppression, and previous receipt of any investigational mRNA influenza vaccine.
  - Record birth year (imprinting cohort) and 3-season vaccination history.
- **Sampling.**
  - Blood at D0, D8, D29, D91, D181 and D365.
  - Active influenza-like-illness surveillance with RT-PCR through D181.
- **Size.** About 110 randomised per arm per cohort (≈90 evaluable) — roughly 660 in total.
  - The WU397 residual SDs (log₂) of the panel-mean endpoint are 1.03 for H3 and 0.91 for H1.
  - Detecting a **1.5-fold** adjusted GMT ratio with 90% power at two-sided α = 0.0125 (4 primary comparisons) needs **89 (H3) and 70 (H1) evaluable per arm**.
  - If the true H3 effect is the 1.17 seen in WU397, 448 per arm would be needed. In other words, Study 1 is designed to *fail the gate* if WU397's H3 result is the truth.
- **Randomised lymph-node sub-study.** At least 25 per arm in Cohort A, at sites able to do FNA.
  - If WU397 effect sizes hold, bootstrap power is 0.98 at week 2, 0.97 at week 17, 0.75 at week 8 and 0.58 at week 26.

**Readouts — what, in whom, against what**

| Readout | In whom | Against what | When | Role |
|---|---|---|---|---|
| **Neutralising titre, averaged per participant (geometric mean) across the locked drifted panel** | Per-protocol immunogenicity set, all arms, both cohorts. Exclude anyone with lab-confirmed influenza before the sample. | **Locked panel**, fixed before unblinding by an independent virology group: wild-type (non-egg, non-reassortant) H3N2 and H1N1pdm09 viruses covering every HA clade co-circulating in trial regions that season, plus WHO-flagged emerging variants; exclude all arms' vaccine reference strains. Separate B/Victoria panel. | D0; **D29 (primary)**; D91 and D181 (key secondary) | **Primary:** baseline-adjusted GMT ratio, mRNA vs each comparator, per A subtype (ANCOVA on log₂ titre with log₂ D0 and stratification factors; censoring handled as pre-specified) |
| Same, **forward panel** | same | Viruses first detected after panel lock, up to the next WHO consultation (pre-specified addition rule) | D29, D181, D365 | Key secondary — true forward breadth |
| Breadth coverage | same | Locked panel | D29, D181 | Per participant: share of panel with ≥4-fold rise, and share above a pre-set titre |
| HAI and neutralisation vs vaccine strains | all | Each arm's own vaccine strains (cell and egg versions) | D0, D29, D181 | Secondary: GMT, seroconversion, ≥1:40; NI vs CBER margins (descriptive at this size). H3N2 judged primarily on neutralisation, because many recent H3N2 viruses agglutinate red cells poorly. |
| **NA-inhibiting antibody** | all | N1, N2 (vaccine and drifted), B NA | D0, D29, D181 | Secondary |
| HA binding breadth — head vs stalk, group 1/2, historical and contemporary HAs | all | HA antigen panel | D0, D29, D181 | Secondary — replicate the WU397 binding signal under randomisation |
| **Fc-effector function** | all, or a random 50% | Vaccine and drifted HAs | D0, D29 | Secondary — is the non-neutralising surplus functional? |
| Blood plasmablasts; cross-reactive memory B cells | random subset | Vaccine and drifted HAs | D0, D8, D29, D181 | Exploratory |
| Lymph-node germinal-centre B cells; mAbs (fixed number per donor, tested for **neutralisation**, not only binding) | randomised FNA subset | Vaccine and drifted HAs / panel | wk2, wk8, wk17–26 | Exploratory — does germinal-centre output feed serum breadth? |
| Serum IgG repertoire, **linked to participant ID** | subset | — | D0, D29, D181 | Exploratory |
| Safety and reactogenicity | all vaccinated | — | Solicited reactions 7 d; unsolicited events 28 d; serious and special-interest events to D365 | Safety |
| Infection surveillance (RT-PCR-confirmed influenza) | all | — | through D181 | Censoring rule; exploratory efficacy signal |

Subgroups pre-specified: baseline titre tertile, previous-season vaccination, birth cohort, age band.

**Year-2 extension (Part B).**
- Re-consent participants.
- Test D365 sera against that season's circulating panel — one-year forward breadth against strains that did not exist at vaccination.
- Revaccinate with the same-arm vaccine, updated to the new season, and repeat the breadth endpoint at D365 + 29.
- This is the direct test of whether the mRNA germinal-centre advantage turns into broader recall.

### Study 2 — Heterologous-strain controlled human infection study *(gated on Study 1; see Section 4)*

**Conditions**
- **Design.** Randomised, double-blind, three arms (1:1:1):
  1. mRNA (Study 1 formulation);
  2. strain-matched licensed non-egg inactivated vaccine;
  3. placebo.
- **Population.** Healthy adults aged 18–49 who meet challenge-study eligibility and are pre-screened for low antibody to the challenge strain.
- **Challenge.** About 4–8 weeks after vaccination, with a GMP challenge virus.
  - Same subtype as the one where Study 1 showed a signal.
  - Chosen to be **antigenically distinct from the vaccine strain**, with the distance documented before dosing.
- **Size.** About 50 per arm is powered for mRNA vs placebo.
  - Planning assumption, not from the package: placebo symptomatic infection 40%, vaccine efficacy 70% → 36 per arm at 80% power, 48 per arm at 90%.
  - mRNA vs licensed vaccine (25% vs 12%) would need 137 per arm, so that comparison is for estimation and correlates. Superiority is left to Study 3.

**Readouts**

| Readout | In whom | Against what | When |
|---|---|---|---|
| **Primary:** laboratory-confirmed symptomatic infection (viral RNA plus symptoms) | all challenged | Challenge strain; mRNA vs placebo | challenge to end of follow-up |
| Any lab-confirmed infection (shedding or seroconversion); viral load area-under-curve; symptom-score area-under-curve; shedding duration | all challenged | mRNA vs placebo and vs licensed vaccine | challenge follow-up |
| Pre-challenge correlates: neutralisation, NA inhibition, stalk binding, Fc function, mucosal IgA | all | Challenge strain and vaccine strain | day of challenge |

### Study 3 — Phase 3 relative-efficacy trial with a mismatched-strain endpoint *(the evidence that can carry the claim; gated on Study 1 and Study 2)*

**Conditions**
- **Design.** Randomised 1:1, observer-blind, active-controlled, event-driven, at least two seasons, both hemispheres. Running several seasons and hemispheres means one well-matched season cannot starve the trial of mismatched cases.
- **Population.** Adults ≥50, stratified 50–64 and ≥65. Restrict to whichever age group passed Study 1.
- **Comparator.** Age-appropriate licensed vaccine with the same season's strains: standard-dose inactivated for 50–64; high-dose, adjuvanted or recombinant for ≥65, per local recommendations.
- **Case definition.** Active influenza-like-illness surveillance from D14 to the end of season, with RT-PCR.
  - Sequence every positive (HA and NA) and characterise a subset antigenically.
  - An independent committee, blinded to arm, classifies each case as matched or mismatched to the vaccine strain using pre-specified genetic and antigenic criteria.
- **Size.** For relative vaccine efficacy (rVE) of 30%: **331 mismatched-strain cases** (90% power, two-sided 0.05). For rVE of 20%: 845 cases.
  - At an *assumed* 1% per-season attack rate of mismatched RT-PCR-confirmed illness in the comparator arm, that is about 38,900 and 93,800 participant-seasons; about half that at 2%.
  - If that is infeasible, consider a pragmatic, registry-based randomised design.

**Readouts**

| Endpoint | In whom | Against what | Role |
|---|---|---|---|
| rVE, all RT-PCR-confirmed protocol-defined influenza-like illness | Per-protocol efficacy set | Licensed comparator | Hierarchy step 1: non-inferiority (lower bound > −10%) |
| **rVE, illness caused by antigenically mismatched strains** | same | same | **Hierarchy step 2: superiority (lower bound > 0) — the claim-bearing endpoint** |
| rVE all-strain (superiority); by subtype; severe outcomes and hospitalisation | same | same | Step 3 and secondary |
| Correlates (case-cohort): Study 1 panel titres, titres to the actual case viruses, NA inhibition, Fc function | Random subcohort plus all cases | — | Validates a correlate for future strain updates |
| Licensure HAI non-inferiority, run in parallel | Immunogenicity subset | Vaccine strains | ~167 per arm per strain for the GMT criterion; 268–526 per arm for the seroconversion criterion (WU397 variance; CBER margins) |

---

## 4. Decision gates

| Gate | Go if | Otherwise |
|---|---|---|
| **G0** (after Study 0) | The mRNA arm's binding surplus carries Fc-effector activity, or NA-inhibiting antibody is not lower in the mRNA arm | If NA inhibition is markedly lower in the mRNA arm and there is no Fc signal, the construct has a structural disadvantage for heterologous claims. Consider a redesign (for example, adding NA) before committing to Study 1. |
| **G1** (Study 1 at D29 and D91; D181 reported) | Versus the **non-egg** comparator, for at least one A subtype, all of: (a) adjusted panel GMT ratio with lower multiplicity-adjusted confidence bound > 1.0 at D29 (the study has 90% power if the true ratio is 1.5); (b) the advantage persists at D91, with lower 95% bound > 1.0 — deliberately, a D29 edge that decays as WU397's H1 edge did will fail this and gives little protection through a season peaking 2–4 months after vaccination; (c) no inferiority on vaccine-strain HAI or neutralisation (upper bound of comparator/mRNA GMT ratio ≤ 1.5) for any component; (d) acceptable reactogenicity | If only binding or Fc breadth is shown, run Study 2 before any Study 3 investment. If nothing is shown, stop the heterologous claim for this construct. |
| **G2** (Study 2) | VE vs placebo with lower CI > 0, and the mRNA point estimate at least as good as the licensed vaccine | Do not start Study 3 |

---

## 5. What not to do

- **Do not claim breadth from WU397 evidence** — fold-rise comparisons, bead-array breadth or mAb counts. The fold-rises are biased by baseline imbalance, and the other two are binding-only, non-randomised, and not counted per donor.
- **Do not repeat WU397 at larger size** without randomisation and strain matching; that reproduces its confounders.
- **Do not carry B/Yamagata forward.**
- **Do not make HAI the heterologous H3N2 endpoint.**
- **Do not plan to reach the label-level claim (C3) by immunobridging** — there is no validated correlate.

---

## 6. Data-integrity issues to fix before the committee (`analysis/results/data_integrity_issues.csv`)

1. **IgM cohort size.** The summary declares IgM in 38/37 participants; `igm_fold_change.csv` contains 14/15.
2. **Plasmablast file.**
   - It holds 13 mRNA and 15 Fluarix participants, against a declared lymph-node cohort of 6 and 11.
   - The 11 extra IDs are Fluarix 036/043/048/055 and mRNA 071/073/074/082/083/101/102.
   - Their values are recorded with about 2 decimals, versus about 5 for the rest.
   - The compartment (blood or lymph node) is not stated.
   - I analysed both with and without the extras. Including them dilutes, rather than inflates, the mRNA difference.
3. **Germinal-centre file.** `gc_frequencies.csv` has two full blocks of 78 rows under the same header, with different values (e.g. participant 028, week 2: 30.5 vs 41.8). Only block A is used, and even that labelling is an assumption.
   - The germinal-centre and plasmablast timepoints (weeks 0/2/8/17/26) also do not match the stated FNA schedule (weeks 1/2/4/8/17/26): week 0 is not in the schedule, and weeks 1 and 4 are missing.
4. **HAI week-17 participants differ by antigen.** For B/Vic they are 007/008/016/021; for the other antigens, 009/010/018/023. B/Vic is also missing participant 031.
5. **Late-visit mismatch across assays.** Fluarix 007 and 011 have their late visit at day 121 in the sequencing-based assay but at week 26 in the microneutralisation, HAI and ELISA files.
6. **Unidentified antigens.** The viruses and antigens behind microneutralisation "homologous/heterologous", HAI "A/H1N1"/"A/H3N2" and ELISA "A/H1"/"A/H3" are not named.
7. **mRNA-1010's own H1 in the neutralisation panel.** It appears only as the egg reassortant IVR-238.
8. **Malformed virus name.** `A/SOUTHAFRICA/R07876/202023`.
9. **Inconsistent ID formats** across files. The repertoire, serum-clonotype and CDRH3 files carry no participant IDs at all.
10. **No covariates, dose, dates or safety data** anywhere in the package.
11. **Bead-array files** give fold-change only, with no baseline MFI and no timepoint.
12. **Antigen composition differs between arms.** External reference for Fluarix's composition: WHO 2022–23 Northern Hemisphere recommendation and the product label.

---

## 7. Numbers ledger

Every number above, with its source. The full machine-readable list (113 entries, each with file and method) is `analysis/results/key_numbers.csv`.

**From the data package** (recomputed by `analysis/run_analysis.py`)

| Number(s) | Source file | Method |
|---|---|---|
| Cohorts 38/37 (ELISA), 14/15 (HAI, MN, bead), 13/14 (seq-neut), 6/11 (FNA), 14/15 (IgM), 13/15 (plasmablast) | all files, cross-checked against `trial_summary.md` | unique IDs per arm |
| ID blocks Fluarix 033–059 (22), mRNA 064–102 (24) | `elisa_igg_titers.csv` | ID ranges outside the serology core |
| ELISA GMFR 5.07/1.90 (H1), 7.60/1.99 (H3), 3.16/2.30, 2.67/2.03; adjusted ratios 2.66, 3.31, 1.35, 1.38 (wk4) and 1.51, 2.06, 0.99, 1.06 (late); core-subset ratios 2.10, 3.19, 0.96, 1.01 | `elisa_igg_titers.csv` | ANCOVA on log₂ EC50; fold-changes verified against EC50s (agreement to 10⁻⁶) |
| Bead array: 20/21 HAs p < 0.05; medians 3.61/0.17, 1.55/−0.06, 4.48/2.41, 4.66/1.56, 2.15/0.42; adjusted 5.0-fold (H3), 2.2-fold (H1) | `binding_breadth_h1.csv`, `binding_breadth_h3.csv` (+ seq-neut baselines) | Mann–Whitney; OLS adjusted for baseline neutralisation |
| Seq-neut panel 96 = 83 H3N2 (5 egg/reassortant) + 13 H1N1 (1); groups 68/8/2/7/5/6; 171 titres at or below the detection limit and 70 at or above the top dilution, out of 7,719 | `neutralization_seqbased.csv` | name parsing per `trial_summary.md` naming note |
| All seq-neut ratios in the Section 2.3 table; 59/68 and 68/68 virus counts; per-virus 0.62, 2.44, 2.07, 0.82, 0.90; clustered-SE 1.13 and 2.09; coverage 0.18/0.05, 3/13 vs 3/14, 0.57/0.00, 7/13 vs 2/14; retained 0.44/0.77 | `neutralization_seqbased.csv` | participant-level panel-mean ANCOVA; per-virus ANCOVA; participant-clustered OLS |
| Binding ÷ neutralisation 2.84 vs 1.01 (p = 0.0015); 1.24 vs 1.08 | ELISA + seq-neut | within-participant log₂ fold-rise difference |
| HAI GMTs, GMFRs, seroconversion/≥1:40 counts and CIs; non-inferiority upper bounds 1.09/2.15/1.60/1.76 | `hai_titers.csv` | Clopper–Pearson; t-interval on log₂ titres |
| MN GMTs 325/588, 57/121, 235/368; ceiling 9/15 and 4/14; adjusted 0.68, 1.17, 0.73 | `microneutralization.csv` | ANCOVA; fold-changes verified against titres |
| Germinal centre 24.2/2.3, 8.3/1.7, 16.0/2.3, 18.9/1.6 (%); plasmablasts 0.656/0.031, 0.145/0.006 | `gc_frequencies.csv` (block A), `plasmablast_frequencies.csv` | medians, Mann–Whitney |
| Clonal overlap 92/91/83/73% (25/11/18/63 clones); Fluarix 100/20/0% (7/5/1) | `pb_gc_clonal_overlap.csv` | as reported |
| Pre-existing abundance 87.0/88.7%; elicited clonotypes 32/17.5; CDRH3 diversity 70.8/24.5 | `repertoire_clonotype_counts.csv`, `cdrh3_diversity_index.csv` | medians |
| IgM H3 GMFR 1.83/5.53 (p = 0.013) | `igm_fold_change.csv` | geometric mean fold-rise |
| mAbs 589 vs 106; per-donor counts 200/162/53/174 and 84/11/11; H7 13/0%; HK/1968 47/12%; H5 19/41% | `mab_binding_panels.csv` | ≥3× over control |
| Residual SD 1.03/0.91 log₂ → 89/70 per arm; 448 per arm at ratio 1.17; FNA bootstrap power at 25/arm: wk2 0.98, wk8 0.75, wk17 0.97, wk26 0.58 | seq-neut; `gc_frequencies.csv` | n = 2[(z₁₋α/₂ + z₁₋β)·SD / log₂R]²; resampling |
| HAI non-inferiority 167 per arm (SD 1.64 log₂); seroconversion 268–526 per arm | `hai_titers.csv` variance + CBER margins | normal approximation |

**External to the package** (verify before citing)
- Fluarix 2022–23 composition; WHO strain picks for 2022–23, 2023–24 and 2024–25 (including A/Victoria/4897/2022, A/Thailand/8/2022 and A/Massachusetts/18/2022); absence of B/Yamagata since March 2020 and the move to trivalent vaccines. Sources: WHO composition recommendations, FDA/VRBPAC and the product labels.
- FDA/CBER 2007 seasonal inactivated influenza vaccine guidance: GMT-ratio non-inferiority bound 1.5; seroconversion-difference bound 10 percentage points; accelerated-approval lower bound for seroconversion ≥ 40% in adults under 65 and ≥ 30% at 65 and over.

**Planning assumptions, not data**
- Challenge-study attack rates: 40% placebo; 25–30% licensed vaccine.
- Efficacy-trial mismatched attack rate: 1–2% per season.
- Target effects: rVE 20–30%; neutralisation GMT ratio 1.5.
- Event counts follow from the Schoenfeld formula; the resulting sample sizes are in `sample_size_all.csv` and `chim_sample_size_assumptions.csv`.

---

## 8. Files produced (`/tmp/outputs/`)

- `answer.md` — this document.
- `analysis/run_analysis.py`, `analysis/common.py` — the full reproducible analysis. Run it with `micromamba run -n core python analysis/run_analysis.py`.
- `analysis/results/`:
  - `key_numbers.csv` — every quoted number, with file and method;
  - `data_integrity_issues.csv`;
  - `cohort_sizes_by_assay.csv`;
  - `hai_summary.csv`, `hai_arm_comparison.csv`;
  - `mn_summary.csv`, `mn_arm_comparison.csv`;
  - `elisa_arm_comparison.csv`;
  - `bead_array_by_strain.csv`;
  - `seqneut_virus_annotation.csv`, `seqneut_group_ancova.csv` (including the below-LOD-halved sensitivity), `seqneut_group_virus_level_clustered.csv`, `seqneut_per_virus.csv`, `seqneut_breadth_coverage.csv`, `seqneut_participant_trajectories.csv`;
  - `binding_vs_neutralisation.csv`;
  - `gc_summary.csv`, `plasmablast_summary.csv`, `pb_gc_overlap_annotated.csv`;
  - `mab_breadth_by_arm.csv`;
  - `sample_size_breadth_endpoint.csv`, `sample_size_all.csv`, `fna_substudy_bootstrap_power.csv`, `chim_sample_size_assumptions.csv`.
- `analysis/figures/`:
  - `fig1_seqneut_per_virus_forest.png` — adjusted day-29 ratio for all 96 viruses;
  - `fig2_binding_vs_function_summary.png` — every readout's adjusted ratio;
  - `fig3_gc_pb.png` — germinal-centre and plasmablast trajectories.
