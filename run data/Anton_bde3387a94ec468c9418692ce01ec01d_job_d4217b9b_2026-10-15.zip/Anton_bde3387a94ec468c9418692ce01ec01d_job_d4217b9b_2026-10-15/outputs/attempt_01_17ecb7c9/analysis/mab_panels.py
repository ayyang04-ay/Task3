"""
mAb binding panels: per-donor summaries (donor is the unit of replication, not the mAb).
Binding call: fold_over_control >= 5 (chosen from the distribution; SARS-CoV-2 RBD is the normaliser, =1 for all mAbs).
Sensitivity at >=3 and >=10.
"""
import pandas as pd, numpy as np
pd.set_option('display.width',250); pd.set_option('display.max_rows',800)
m=pd.read_csv('/tmp/world/filesystem/mab_binding_panels.csv')
m['donor']=m.mab_id.str.split('.').str[1]
seas={'group_I':['A/Puerto Rico/8/1934','A/New Caledonia/20/1999','A/California/04/2009','A/Wisconsin/588/2019','A/Victoria/4897/2022','A/Netherlands/01317/2025'],
      'group_II':['A/Hong Kong/1/1968','A/Fujian/411/2002','A/Texas/50/2012','A/Darwin/6/2021','A/Thailand/8/2022','A/Croatia/10136RV/2023']}
het={'group_I':'A/Hubei/1/2010 (H5)','group_II':'A/Shanghai/1/2013 (H7)'}
vacc={'group_I':'A/Victoria/4897/2022','group_II':'A/Darwin/6/2021'}
out=[]
for thr in [3,5,10]:
    for pn in ['group_I','group_II']:
        w=m[m.panel==pn].pivot_table(index=['arm','donor','mab_id'],columns='antigen',values='fold_over_control')
        B=(w>=thr)
        B['n_seasonal_bound']=B[seas[pn]].sum(axis=1)
        for (arm,d),g in B.groupby(level=['arm','donor']):
            out.append(dict(threshold=thr,panel=pn,arm=arm,donor=d,n_mabs=len(g),
               pct_bind_mRNA1010_antigen=100*g[vacc[pn]].mean(),
               pct_bind_oldest=100*g[seas[pn][0]].mean(),
               pct_bind_newest=100*g[seas[pn][-1]].mean(),
               pct_bind_all6=100*(g.n_seasonal_bound==6).mean(),
               mean_n_seasonal_bound=g.n_seasonal_bound.mean(),
               pct_bind_other_subtype=100*g[het[pn]].mean()))
O=pd.DataFrame(out)
print(O[O.threshold==5].round(1).to_string())
O.to_csv('/tmp/outputs/analysis/mab_per_donor_summary.csv',index=False)
# arm-level: mean of donor-level values (each donor weighted equally) vs pooled mAbs
for thr in [5]:
    s=O[O.threshold==thr].groupby(['panel','arm'])[['n_mabs','pct_bind_mRNA1010_antigen','pct_bind_oldest','pct_bind_newest','pct_bind_all6','mean_n_seasonal_bound','pct_bind_other_subtype']].agg(['mean','min','max'])
    print(s.round(1).to_string())
