"""
Illustrative event-driven sizing for a 1:1 randomised relative-efficacy (rVE) trial.
Conditional binomial: among cases, P(case in mRNA arm) = (1-rVE)/(2-rVE).
H0 superiority: rVE=0 ; H0 non-inferiority: rVE=-10% (margin). One-sided alpha 0.025.
Attack rates are ASSUMPTIONS (not from the WU397 package) used only to translate events into enrolment.
"""
import numpy as np, pandas as pd
from scipy import stats
def p_of(rve): return (1-rve)/(2-rve)
def events(rve_true, rve_null, power, alpha=0.025):
    p1=p_of(rve_true); p0=p_of(rve_null)
    za=stats.norm.ppf(1-alpha); zb=stats.norm.ppf(power)
    return int(np.ceil(((za*np.sqrt(p0*(1-p0))+zb*np.sqrt(p1*(1-p1)))/(p0-p1))**2))
rows=[]
for rve in [0.15,0.20,0.25,0.30]:
    for null,lab in [(0.0,'superiority (rVE>0)'),(-0.10,'non-inferiority (rVE>-10%)')]:
        for pw in [0.8,0.9]:
            E=events(rve,null,pw)
            for ar in [0.015,0.025]:
                # comparator attack rate ar; mRNA arm ar*(1-rve)
                per_person=0.5*ar+0.5*ar*(1-rve)
                rows.append(dict(assumed_true_rVE=rve,test=lab,power=pw,events_needed=E,assumed_comparator_attack_rate=ar,
                                 total_N_one_season=int(np.ceil(E/per_person))))
R=pd.DataFrame(rows)
pd.set_option('display.width',250); pd.set_option('display.max_rows',200)
print(R.to_string())
R.to_csv('/tmp/outputs/analysis/efficacy_event_sizing.csv',index=False)
# heterologous (mismatched-strain) endpoint: if a fraction f of cases are caused by antigenically mismatched strains
print()
for f in [0.3,0.5]:
    for rve in [0.25,0.30]:
        E=events(rve,0.0,0.8)
        print(f'mismatched-strain endpoint: true rVE {rve:.0%}, 80% power superiority -> {E} mismatched cases; if {f:.0%} of all cases are mismatched -> ~{int(np.ceil(E/f))} total cases')

# ---- optional CHIM (Study 3): vaccine vs placebo, symptomatic laboratory-confirmed infection; ASSUMED placebo risk
rows=[]
for p0 in [0.35,0.45]:
    for eff in [0.5,0.6]:
        p1=p0*(1-eff); pbar=(p0+p1)/2
        za=stats.norm.ppf(0.975); zb=stats.norm.ppf(0.8)
        nn=((za*np.sqrt(2*pbar*(1-pbar))+zb*np.sqrt(p0*(1-p0)+p1*(1-p1)))/(p0-p1))**2
        rows.append(dict(assumed_placebo_risk=p0,assumed_efficacy=eff,n_per_arm_80pct_power=int(np.ceil(nn))))
C=pd.DataFrame(rows); print(C.to_string()); C.to_csv('/tmp/outputs/analysis/chim_sizing.csv',index=False)
