"""
Supplementary checks quoted in answer.md:
 (a) which seq-neut virus the MN 'homologous'/'heterologous' titres track (virus identity undocumented)
 (b) ELISA arm difference within the interleaved core cohort (IDs <=032) vs arm-blocked extension (IDs >=033)
 (c) H1 fold-rise skew: A/Wisconsin/588/2019 (5a.2) vs A/Wisconsin/67/2022 and A/Victoria/4897/2022 IVR-238 (5a.2a.1)
 (d) seq-neut durability at the pooled late visit (d121 or d181)
"""
import pandas as pd, numpy as np
from scipy import stats
fs='/tmp/world/filesystem/'; A='/tmp/outputs/analysis/'
rows=[]
def add(check,quantity,value): rows.append(dict(check=check,quantity=quantity,value=value)); print(check,'|',quantity,'|',value)
n=pd.read_csv(fs+'neutralization_seqbased.csv')
n['pid']=n.serum.str.split('_').str[1]; n['day']=n.serum.str.split('_').str[2].map({'d0':'wk0','d29':'wk4','d121':'wk17','d181':'wk26'})
sq=np.log2(n.pivot_table(index=['pid','day'],columns='virus',values='titer'))
mn=pd.read_csv(fs+'microneutralization.csv'); mn=mn[mn.measure=='titer']
mnw=np.log2(mn.pivot_table(index=['participant','timepoint'],columns='panel',values='value')); mnw.index.names=['pid','day']
j=mnw.join(sq,how='inner')
for pnl in ['homologous','heterologous']:
    c=j.drop(columns=['homologous','heterologous']).corrwith(j[pnl],method='spearman').sort_values(ascending=False)
    add('(a) MN identity',f'MN {pnl}: best-tracking seq-neut virus (Spearman, all sera/timepoints, n={len(j)})',f'{c.index[0]} rho={c.iloc[0]:.2f}')
    add('(a) MN identity',f'MN {pnl}: rho with A/Darwin/6/2021 (mRNA H3 antigen)',f'{c["A/Darwin/6/2021_H3N2"]:.2f}')
    add('(a) MN identity',f'MN {pnl}: max rho with any H1N1 virus',f'{c[[v for v in c.index if v.endswith("H1N1")]].max():.2f}')
e=pd.read_csv(fs+'elisa_igg_titers.csv'); e=e[(e.measure=='fold_change')&(e.timepoint=='wk4')]
gm=lambda x: float(np.exp(np.mean(np.log(x))))
for ag in ['A/H1','A/H3']:
    for lab,sel in [('core IDs<=032',e.participant<=32),('extension IDs>=033',e.participant>32)]:
        g=e[(e.antigen==ag)&sel]
        add('(b) ELISA cohorts',f'{ag} wk4 GM fold-rise, {lab}: mRNA / Fluarix (n)',f'{gm(g[g.arm=="mRNA-1010"].value):.1f} / {gm(g[g.arm=="Fluarix"].value):.1f} ({(g.arm=="mRNA-1010").sum()}/{(g.arm=="Fluarix").sum()})')
w=n.assign(l=np.log2(n.titer)).pivot_table(index=['pid','day'],columns='virus',values='l')
arm=n.drop_duplicates('pid').set_index('pid').serum.str.split('_').str[0]
fr=(w.xs('wk4',level='day')-w.xs('wk0',level='day'))
for a in ['mRNA-1010','Fluarix']:
    f=fr[fr.index.map(arm)==a]
    for other in ['A/Wisconsin/67/2022_H1N1','A/Victoria/4897/2022_IVR-238_H1N1']:
        d=(f['A/Wisconsin/588/2019_H1N1']-f[other]).dropna()
        add('(c) H1 skew',f'{a}: fold-rise on A/Wisconsin/588/2019 relative to {other.split("_")[0]}',f'{2**d.mean():.2f}x; larger in {(d>0).sum()}/{len(d)}; Wilcoxon p={stats.wilcoxon(d).pvalue:.3f}')
ann=pd.read_csv(A+'seqneut_annotated.csv')
pp=ann.groupby(['arm','pid','cat','day']).log2t.mean().unstack('day')
pp['late']=pp['d181'].fillna(pp['d121'])
for c in ['H1_2023_circulating','H3_2023-24_circulating']:
    g=pp.xs(c,level='cat'); a=g.xs('mRNA-1010',level='arm'); f=g.xs('Fluarix',level='arm')
    add('(d) durability',f'{c}: late-visit (d121 or d181) GMT mRNA / Fluarix (n; n at d121)',f'{2**a.late.mean():.0f} / {2**f.late.mean():.0f} ({a.late.notna().sum()}/{f.late.notna().sum()}; {a.d181.isna().sum()}/{f.d181.isna().sum()})')
pd.DataFrame(rows).to_csv(A+'supplementary_checks.csv',index=False)
