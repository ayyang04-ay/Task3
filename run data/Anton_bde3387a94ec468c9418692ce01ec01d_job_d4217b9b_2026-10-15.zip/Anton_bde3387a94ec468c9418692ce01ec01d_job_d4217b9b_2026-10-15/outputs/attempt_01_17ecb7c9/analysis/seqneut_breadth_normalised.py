"""
Breadth vs magnitude: per participant, ratio of d29 titre against contemporary drifted strains
to d29 titre against that participant's OWN vaccine-like strain (arm-specific homologous reference),
and against a COMMON reference. Also, fold-rise on drifted strains relative to fold-rise on own vaccine strain.
"""
import pandas as pd, numpy as np
from scipy import stats
n=pd.read_csv('/tmp/outputs/analysis/seqneut_annotated.csv')
w=n.pivot_table(index=['arm','pid','day'],columns='virus',values='log2t')
own_ref={'H1':{'mRNA-1010':['A/Wisconsin/67/2022_H1N1','A/Victoria/4897/2022_IVR-238_H1N1'],
               'Fluarix':['A/Wisconsin/588/2019_H1N1']},
         'H3':{'mRNA-1010':['A/Darwin/6/2021_H3N2'],'Fluarix':['A/Darwin/9/2021_H3N2']}}
cats={'H1':'H1_2023_circulating','H3':'H3_2023-24_circulating'}
vir_by_cat=n.drop_duplicates('virus').groupby('cat').virus.apply(list).to_dict()
out=[]
for sub in ['H1','H3']:
    het=vir_by_cat[cats[sub]]
    for (arm,pid,day),row in w.iterrows():
        if day not in ('d0','d29'): continue
        hetm=row[het].mean()
        own=row[own_ref[sub][arm]].mean()
        out.append(dict(sub=sub,arm=arm,pid=pid,day=day,het=hetm,own=own))
o=pd.DataFrame(out)
o=o.pivot_table(index=['sub','arm','pid'],columns='day',values=['het','own'])
o.columns=[f'{a}_{b}' for a,b in o.columns]
o['het_over_own_d29']=o.het_d29-o.own_d29            # log2 ratio
o['fold_het']=o.het_d29-o.het_d0; o['fold_own']=o.own_d29-o.own_d0
o['fold_het_minus_fold_own']=o.fold_het-o.fold_own
rows=[]
for sub,g in o.groupby(level='sub'):
    a=g.xs('mRNA-1010',level='arm'); f=g.xs('Fluarix',level='arm')
    for col in ['het_d29','own_d29','het_over_own_d29','fold_het','fold_own','fold_het_minus_fold_own']:
        x=a[col].dropna(); y=f[col].dropna()
        rows.append(dict(subtype=sub,metric=col,n_mRNA=len(x),n_Flu=len(y),mRNA=2**x.mean(),Fluarix=2**y.mean(),
                         ratio=2**(x.mean()-y.mean()),MWU_p=stats.mannwhitneyu(x,y).pvalue))
r=pd.DataFrame(rows)
pd.set_option('display.width',250)
print(r.round(3).to_string())
r.to_csv('/tmp/outputs/analysis/seqneut_breadth_normalised.csv',index=False)
