"""Programmatic checks behind the data-integrity list in answer.md."""
import pandas as pd, numpy as np, re
fs='/tmp/world/filesystem/'
out=[]
def add(item,evidence): out.append(dict(issue=item,evidence=evidence)); print('-',item,'|',evidence)
# 1 GC duplicate blocks
g=pd.read_csv(fs+'gc_frequencies.csv',dtype={'participant':str})
k=g.groupby(['timepoint','arm','participant']).size()
b2=g.iloc[len(g)//2:]; z=(b2[b2.arm=='Fluarix'].pct_ha_specific_igg_gc==0).mean()
add('gc_frequencies.csv has two unlabelled measurement blocks',f'{len(g)} rows; every participant x timepoint appears {k.unique().tolist()} times; second block is mostly zero in Fluarix ({z:.0%} zeros)')
add('GC timepoints do not match documented FNA schedule (wk1,2,4,8,17,26)',f'file timepoints: {sorted(g.timepoint.unique())}')
p=pd.read_csv(fs+'plasmablast_frequencies.csv',dtype={'participant':str})
add('Plasmablast timepoints do not match documented blood schedule (d0,7,29,121,181 = wk0,1,4,17,26)',f'file timepoints: {sorted(p.timepoint.unique())}; PB cohort {p[p.arm=="mRNA-1010"].participant.nunique()}/{p[p.arm=="Fluarix"].participant.nunique()} vs FNA cohort 6/11')
i=pd.read_csv(fs+'igm_fold_change.csv',dtype={'participant':str})
add('IgM cohort smaller than documented (38/37)',f'IgM file: {i[i.arm=="mRNA-1010"].participant.nunique()} mRNA / {i[i.arm=="Fluarix"].participant.nunique()} Fluarix; non-padded ID(s): {sorted(set(x for x in i.participant if len(x)<3))}; timepoint not stated')
o=i[i.fold_change>100]
add('IgM outlier',f'participant(s) {sorted(o.participant.unique())} fold-change {o.fold_change.min():.0f}-{o.fold_change.max():.0f} on all antigens')
h=pd.read_csv(fs+'hai_titers.csv',dtype={'participant':str})
wk17=h[h.timepoint=='wk17'].groupby('antigen').participant.apply(lambda s: sorted(s))
add('HAI B/Vic late-visit labels inconsistent with other antigens',f'wk17 participants by antigen: {wk17.to_dict()}')
add('HAI B/Vic missing participant 031',f'B/Vic mRNA n at wk0 = {h[(h.antigen=="B/Vic")&(h.timepoint=="wk0")&(h.arm=="mRNA-1010")].participant.nunique()}')
n=pd.read_csv(fs+'neutralization_seqbased.csv')
n['pid']=n.serum.str.split('_').str[1]; n['day']=n.serum.str.split('_').str[2]
d121=sorted(n[n.day=='d121'].pid.unique())
add('Seq-neut late visit differs from HAI/MN/ELISA for some participants',f'd121 sera: {d121}; HAI/MN/ELISA wk17 = 009, 010, 018, 023')
bad=[v for v in n.virus.unique() if (lambda m: m is None or len(m.group(1))!=4)(re.search(r'/(\d+)(?:egg|X-\d+A|NIB-\d+|_IVR-\d+)?_H\dN\d$',v))]
add('Malformed virus name',f'{bad}')
add('Egg-derived A/Darwin/9/2021 carries no egg/reassortant designation','see egg_vs_wildtype_pairs.csv: titres 1.9x (d0) / 3.6x (d29) higher than A/Darwin/6/2021')
mn=pd.read_csv(fs+'microneutralization.csv'); mt=mn[mn.measure=='titer']
add('MN ULOQ ceiling',f'max titre {mt.value.max():.0f}; wk4 homologous at ceiling: mRNA {((mt.panel=="homologous")&(mt.timepoint=="wk4")&(mt.arm=="mRNA-1010")&(mt.value>=1280)).sum()}/14, Fluarix {((mt.panel=="homologous")&(mt.timepoint=="wk4")&(mt.arm=="Fluarix")&(mt.value>=1280)).sum()}/15')
m=pd.read_csv(fs+'mab_binding_panels.csv'); m['donor']=m.mab_id.str.split('.').str[1]
c=m.groupby(['arm','donor']).mab_id.nunique()
add('mAb sampling unbalanced across arms/donors',f'{c.to_dict()}')
add('mAb normaliser is SARS-CoV-2 RBD (=1 for all mAbs) so it is not an independent negative control; negative values present',f'RBD values unique: {m[m.antigen=="SARS-CoV-2 RBD"].fold_over_control.unique().tolist()}; negatives: {(m.fold_over_control<0).sum()}')
e=pd.read_csv(fs+'elisa_igg_titers.csv')
ids=e.drop_duplicates('participant')[['participant','arm']]
add('Arm-blocked participant ID ranges in ELISA extension',f'Fluarix IDs >32: {ids[(ids.arm=="Fluarix")&(ids.participant>32)].participant.min()}-{ids[(ids.arm=="Fluarix")&(ids.participant>32)].participant.max()}; mRNA IDs >32: {ids[(ids.arm=="mRNA-1010")&(ids.participant>32)].participant.min()}-{ids[(ids.arm=="mRNA-1010")&(ids.participant>32)].participant.max()}')
add('Identifier formats differ across files','ELISA integer (1); HAI/GC/PB/IgM "001"; MN/bead "397-001"; seq-neut "<arm>_397-001_d0"; overlap "397-06"; mAb "397.06.004"')
add('Repertoire/CDRH3/serum-clonotype files lack participant IDs; sub-study absent from cohort table','8 + 8 rows per timepoint, unpaired')
add('No demographics / prior vaccination / site variables in package','cannot assess or adjust for site-based allocation')
pd.DataFrame(out).to_csv('/tmp/outputs/analysis/data_integrity_issues.csv',index=False)
