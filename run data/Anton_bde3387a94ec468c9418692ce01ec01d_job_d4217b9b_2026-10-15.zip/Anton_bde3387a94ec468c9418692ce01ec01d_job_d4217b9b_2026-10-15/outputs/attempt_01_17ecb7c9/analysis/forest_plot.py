"""Forest plot: mRNA-1010 / Fluarix ratios (95% Welch CI) - binding vs functional readouts, same strains where possible."""
import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from scipy import stats
R=pd.read_csv('/tmp/outputs/analysis/gmt_ratio_cis.csv')
n=pd.read_csv('/tmp/outputs/analysis/seqneut_annotated.csv')
def welch(x,y):
    x=np.asarray(x,float); y=np.asarray(y,float)
    vx,vy=x.var(ddof=1)/len(x),y.var(ddof=1)/len(y); se=np.sqrt(vx+vy)
    df=(vx+vy)**2/(vx**2/(len(x)-1)+vy**2/(len(y)-1)); t=stats.t.ppf(0.975,df); d=x.mean()-y.mean()
    return 2**d,2**(d-t*se),2**(d+t*se)
def seqv(virus,metric):
    w=n[n.virus==virus].pivot_table(index=['arm','pid'],columns='day',values='log2t')
    v=(w.d29-w.d0) if metric=='fold' else w.d29
    return welch(v.xs('mRNA-1010').dropna(),v.xs('Fluarix').dropna())
def get(assay,target,metric):
    r=R[(R.assay.str.startswith(assay))&(R.target==target)&(R.metric==metric)].iloc[0]; return r.ratio,r.lo,r.hi
items=[('BINDING',None),
 ('ELISA IgG, A/H3 (wk4 fold-rise)',get('ELISA','A/H3','wk4 fold-rise')),
 ('Bead array, H3 A/Darwin/6/2021 (fold-rise)',get('Bead','H3 A/Darwin/6/2021','fold-rise MFI')),
 ('Bead array, H3 A/Thailand/8/2022 (fold-rise)',get('Bead','H3 A/Thailand/8/2022','fold-rise MFI')),
 ('ELISA IgG, A/H1 (wk4 fold-rise)',get('ELISA','A/H1','wk4 fold-rise')),
 ('Bead array, H1 A/Wisconsin/67/2022 (fold-rise)',get('Bead','H1 A/Wisconsin/67/2022','fold-rise MFI')),
 ('FUNCTION',None),
 ('HAI, A/H3N2 (wk4 fold-rise)',get('HAI','A/H3N2','wk4 fold-rise')),
 ('Neut, A/Darwin/6/2021 = mRNA H3 antigen (d29 fold-rise)',seqv('A/Darwin/6/2021_H3N2','fold')),
 ('Neut, A/Thailand/8/2022 (d29 fold-rise)',seqv('A/Thailand/8/2022_H3N2','fold')),
 ('Neut, 64 H3N2 2023-24 viruses (d29 fold-rise)',get('Seq','H3_2023-24_circulating','d29 fold-rise')),
 ('Neut, 64 H3N2 2023-24 viruses (d29 GMT)',get('Seq','H3_2023-24_circulating','d29 GMT')),
 ('MN "heterologous" (wk4 fold-rise)',get('Micro','heterologous panel (virus identity undocumented)','wk4 fold-rise')),
 ('HAI, A/H1N1 (wk4 fold-rise)',get('HAI','A/H1N1','wk4 fold-rise')),
 ('Neut, 6 H1N1 2023 viruses (d29 fold-rise)',get('Seq','H1_2023_circulating','d29 fold-rise')),
 ('Neut, 6 H1N1 2023 viruses (d29 GMT)',get('Seq','H1_2023_circulating','d29 GMT')),
]
fig,ax=plt.subplots(figsize=(9,7.5))
y=len(items)
labels=[];ys=[]
for lab,v in items:
    y-=1
    if v is None:
        ax.text(0.105,y,lab,fontweight='bold',va='center',fontsize=9); continue
    r,lo,hi=v
    col='tab:blue' if y>len(items)-8 else 'tab:red'
    ax.errorbar(r,y,xerr=[[r-lo],[hi-r]],fmt='o',color=col,capsize=3)
    ax.text(40,y,f'{r:.2f} ({lo:.2f}-{hi:.2f})',va='center',fontsize=8)
    labels.append(lab); ys.append(y)
ax.set_yticks(ys); ax.set_yticklabels(labels,fontsize=8)
ax.axvline(1,color='k',lw=0.8,ls='--')
ax.set_xscale('log'); ax.set_xlim(0.1,200); ax.set_ylim(-0.8,len(items)-0.2)
ax.set_xlabel('Ratio mRNA-1010 / Fluarix (95% CI, Welch on log scale)')
ax.set_title('WU397: binding advantage does not carry into function for H3N2\n(n mRNA/Fluarix: ELISA 38/37; HAI, bead array 14/15; seq-neut 13/14)',fontsize=10,pad=12)
plt.tight_layout(); plt.savefig('/tmp/outputs/forest_binding_vs_function.png',dpi=150)
print('saved')
for lab,v in items:
    if v: print(lab, [round(x,2) for x in v])
