"""Builds key_numbers.csv: every number quoted in answer.md, with source file and derivation."""
import pandas as pd, numpy as np
A='/tmp/outputs/analysis/'; fs='/tmp/world/filesystem/'
rows=[]
def add(section,quantity,value,source,derivation): rows.append(dict(section=section,quantity=quantity,value=value,source=source,derivation=derivation))
gm=lambda x: float(np.exp(np.mean(np.log(np.asarray(x,float)))))
# ---- ELISA
R=pd.read_csv(A+'gmt_ratio_cis.csv')
e=pd.read_csv(fs+'elisa_igg_titers.csv')
for ag in ['A/H1','A/H3','B/Vic','B/Yam']:
    g=e[(e.antigen==ag)&(e.timepoint=='wk4')&(e.measure=='fold_change')]
    a=g[g.arm=='mRNA-1010'].value; f=g[g.arm=='Fluarix'].value
    r=R[(R.assay.str.startswith('ELISA'))&(R.target==ag)&(R.metric=='wk4 fold-rise')].iloc[0]
    add('ELISA IgG',f'{ag} wk4 GM fold-rise mRNA / Fluarix; ratio (95% CI)',f'{gm(a):.2f} / {gm(f):.2f}; {r.ratio:.2f} ({r.lo:.2f}-{r.hi:.2f})','elisa_igg_titers.csv (n=38/37)','geometric mean of per-participant fold_change; Welch CI on log2 (gmt_ratio_cis.py)')
    add('ELISA IgG',f'{ag} participants with >=4-fold rise, mRNA / Fluarix',f'{(a>=4).sum()}/38 / {(f>=4).sum()}/37','elisa_igg_titers.csv','count fold_change>=4')
    g2=e[(e.antigen==ag)&(e.timepoint=='wk17/26')&(e.measure=='fold_change')]
    add('ELISA IgG',f'{ag} wk17/26 GM fold-rise mRNA / Fluarix',f'{gm(g2[g2.arm=="mRNA-1010"].value):.2f} / {gm(g2[g2.arm=="Fluarix"].value):.2f}','elisa_igg_titers.csv','pooled wk17/26 fold_change as supplied')
# ---- HAI
h=pd.read_csv(fs+'hai_titers.csv',dtype={'participant':str})
hw=h.pivot_table(index=['antigen','arm','participant'],columns='timepoint',values='hai_titer')
S=pd.read_csv(A+'hai_scr_sp.csv')
for ag in ['A/H1N1','A/H3N2','B/Vic','B/Yam']:
    g=hw.xs(ag,level=0)
    a=g.xs('mRNA-1010'); f=g.xs('Fluarix')
    r=R[(R.assay.str.startswith('HAI'))&(R.target==ag)&(R.metric=='wk4 GMT')].iloc[0]
    add('HAI',f'{ag} wk4 GMT mRNA / Fluarix; ratio (95% CI)',f'{gm(a.wk4.dropna()):.1f} / {gm(f.wk4.dropna()):.1f}; {r.ratio:.2f} ({r.lo:.2f}-{r.hi:.2f})','hai_titers.csv (n=14/15)','GMT; Welch CI')
    sa=S[(S.antigen==ag)&(S.arm=='mRNA-1010')&(S.metric=='seroconversion wk4')].iloc[0]; sf=S[(S.antigen==ag)&(S.arm=='Fluarix')&(S.metric=='seroconversion wk4')].iloc[0]
    add('HAI',f'{ag} seroconversion wk4 mRNA / Fluarix',f'{sa.k}/{sa.n} ({sa.pct:.0f}%) / {sf.k}/{sf.n} ({sf.pct:.0f}%)','hai_titers.csv','pre<10 & post>=40, or >=4-fold (hai_scr.py)')
    pa=S[(S.antigen==ag)&(S.arm=='mRNA-1010')&(S.metric=='HAI>=40 wk4')].iloc[0]; pf=S[(S.antigen==ag)&(S.arm=='Fluarix')&(S.metric=='HAI>=40 wk4')].iloc[0]
    add('HAI',f'{ag} HAI>=40 at wk4 mRNA / Fluarix',f'{pa.k}/{pa.n} / {pf.k}/{pf.n}','hai_titers.csv','count wk4>=40')
An=pd.read_csv(A+'ancova_baseline_adjusted.csv')
for _,r in An.iterrows():
    add('Baseline-adjusted (ANCOVA)',f'{r.readout}: adjusted GMT ratio (95% CI)',f'{r.adj_GMT_ratio:.2f} ({r.lo:.2f}-{r.hi:.2f}), p={r.p:.3f}','see readout','ancova.py: log2(post) ~ arm + log2(pre)')
# ---- MN
m=pd.read_csv(fs+'microneutralization.csv'); mt=m[m.measure=='titer']
mw=mt.pivot_table(index=['panel','arm','participant'],columns='timepoint',values='value')
for pn in ['homologous','heterologous']:
    g=mw.xs(pn,level=0); a=g.xs('mRNA-1010'); f=g.xs('Fluarix')
    add('Microneutralisation',f'{pn}: wk0 GMT mRNA / Fluarix',f'{gm(a.wk0):.0f} / {gm(f.wk0):.0f}','microneutralization.csv (n=14/15)','GMT')
    add('Microneutralisation',f'{pn}: wk4 GMT mRNA / Fluarix',f'{gm(a.wk4):.0f} / {gm(f.wk4):.0f}','microneutralization.csv','GMT')
    add('Microneutralisation',f'{pn}: wk4 GM fold-rise mRNA / Fluarix',f'{gm(a.wk4/a.wk0):.2f} / {gm(f.wk4/f.wk0):.2f}','microneutralization.csv','GM of wk4/wk0')
    add('Microneutralisation',f'{pn}: wk4 titres at ULOQ 1280, mRNA / Fluarix',f'{(a.wk4>=1280).sum()}/14 / {(f.wk4>=1280).sum()}/15','microneutralization.csv','count =1280')
r=R[(R.assay.str.startswith('Micro'))&(R.target.str.startswith('heterologous'))&(R.metric=='baseline GMT')].iloc[0]
add('Microneutralisation','heterologous baseline GMT ratio (95% CI)',f'{r.ratio:.2f} ({r.lo:.2f}-{r.hi:.2f}), p={r.p:.3f}','microneutralization.csv','Welch CI')
# ---- seq-neut
C=pd.read_csv(A+'seqneut_by_category.csv')
for _,r in C.iterrows():
    rr=R[(R.assay.str.startswith('Seq'))&(R.target==r.category)&(R.metric==({'d0':'baseline GMT','d29':'d29 GMT','fold_d29':'d29 fold-rise'}[r.metric]))].iloc[0]
    add('Seq-based neutralisation',f'{r.category} {r.metric}: mRNA / Fluarix; ratio (95% CI)',f'{r.GM_mRNA:.2f} / {r.GM_Flu:.2f}; {rr.ratio:.2f} ({rr.lo:.2f}-{rr.hi:.2f})','neutralization_seqbased.csv (n=13/14)','per-participant mean log2 titre over category viruses; Welch CI (seqneut_analysis.py, gmt_ratio_cis.py)')
B=pd.read_csv(A+'seqneut_breadth_normalised.csv')
for _,r in B.iterrows():
    add('Seq-based neutralisation (breadth index)',f'{r.subtype} {r.metric}: mRNA / Fluarix; ratio; p',f'{r.mRNA:.3f} / {r.Fluarix:.3f}; {r.ratio:.2f}; p={r.MWU_p:.3f}','neutralization_seqbased.csv','seqneut_breadth_normalised.py (het = 2023/2023-24 circulating; own = arm-specific vaccine-like strain)')
P=pd.read_csv(A+'seqneut_per_virus.csv')
for v in ['A/Darwin/6/2021_H3N2','A/Darwin/9/2021_H3N2','A/Thailand/8/2022_H3N2','A/Wisconsin/588/2019_H1N1','A/Wisconsin/67/2022_H1N1','A/Victoria/4897/2022_IVR-238_H1N1']:
    r=P[P.virus==v].iloc[0]
    add('Seq-based neutralisation (per virus)',f'{v}: d29 GMT mRNA / Fluarix; GM fold-rise mRNA / Fluarix',f'{r.GMT29_A:.0f} / {r.GMT29_F:.0f}; {r.GMFR_A:.2f} / {r.GMFR_F:.2f}','neutralization_seqbased.csv','seqneut_per_virus.csv')
h3=P[P.cat=='H3_2023-24_circulating']
add('Seq-based neutralisation (per virus)','H3N2 2023-24 viruses where mRNA d29 GMT > Fluarix',f'{(h3.ratio_GMT29>1).sum()}/{len(h3)} (median ratio {h3.ratio_GMT29.median():.2f}; range {h3.ratio_GMT29.min():.2f}-{h3.ratio_GMT29.max():.2f})','neutralization_seqbased.csv','seqneut_per_virus.csv')
hh=P[P.cat=='H3_historical']
add('Seq-based neutralisation (per virus)','H3N2 historical viruses where mRNA d29 GMT > Fluarix',f'{(hh.ratio_GMT29>1).sum()}/{len(hh)} (median ratio {hh.ratio_GMT29.median():.2f})','neutralization_seqbased.csv','seqneut_per_virus.csv')
Eg=pd.read_csv(A+'egg_vs_wildtype_pairs.csv'); Eg=Eg[Eg.arm=='both']
add('Seq-based neutralisation (egg/reassortant)','egg or production-reassortant vs wild-type/cell titre ratio, range over 7 pairs (d0 and d29)',f'{Eg.GM_ratio_egg_over_wt.min():.1f}-{Eg.GM_ratio_egg_over_wt.max():.1f}x','neutralization_seqbased.csv','egg_vs_wildtype_pairs.py')
# ---- bead array
for fn in ['binding_breadth_h1.csv','binding_breadth_h3.csv']:
    b=pd.read_csv(fs+fn)
    for s,g in b.groupby('strain'):
        a=g[g.arm=='mRNA-1010'].log2_fold_change_mfi.mean(); f=g[g.arm=='Fluarix'].log2_fold_change_mfi.mean()
        add('Bead-array binding',f'{s}: GM fold-rise mRNA / Fluarix; ratio',f'{2**a:.2f} / {2**f:.2f}; {2**(a-f):.2f}',fn+' (n=14/15)','2^(mean log2 FC)')
Co=pd.read_csv(A+'binding_vs_function_correlations.csv')
for _,r in Co.iterrows():
    add('Binding vs function (Spearman)',f'{r.binding} vs {r.function} [{r.arm}]',f'rho={r.spearman_rho:.2f}, p={r.p:.3f}, n={r.n}','ELISA/bead/HAI/MN/seq-neut files','binding_vs_function.py')
# ---- GC / PB / overlap
G=pd.read_csv(A+'gc_summary.csv')
for _,r in G.iterrows():
    add('Lymph-node GC',f'block {r.block} {r.timepoint}: median % mRNA / Fluarix',f'{r.median_mRNA:.2f} / {r.median_Flu:.2f} (p={r.MWU_p:.3f})','gc_frequencies.csv (n=6/11)','gc_pb.py')
g=pd.read_csv(fs+'gc_frequencies.csv',dtype={'participant':str}); gA=g.iloc[:len(g)//2]
pk=gA[gA.timepoint!='wk0'].groupby(['arm','participant']).pct_ha_specific_igg_gc.max()
add('Lymph-node GC','block A per-participant post-baseline peak, median (range) mRNA / Fluarix',f'{pk["mRNA-1010"].median():.1f} ({pk["mRNA-1010"].min():.1f}-{pk["mRNA-1010"].max():.1f}) / {pk["Fluarix"].median():.1f} ({pk["Fluarix"].min():.1f}-{pk["Fluarix"].max():.1f})','gc_frequencies.csv','gc_pb.py')
Pb=pd.read_csv(A+'pb_summary.csv')
add('Plasmablasts','MWU p-values across timepoints',f'{Pb.MWU_p.min():.2f}-{Pb.MWU_p.max():.2f}','plasmablast_frequencies.csv (n=13/15)','gc_pb.py')
ov=pd.read_csv(fs+'pb_gc_clonal_overlap.csv')
add('PB-GC clonal overlap','% of GC clones shared with wk1 PB clones, by donor',', '.join(f'{a}: {b}' for a,b in zip(ov.Participant,ov['Percentage of overlapping clones out of GC B cell clones'])),'pb_gc_clonal_overlap.csv','as supplied')
# ---- mAbs
M=pd.read_csv(A+'mab_per_donor_summary.csv'); M5=M[M.threshold==5]
for (pn,arm),g in M5.groupby(['panel','arm']):
    add('mAb panels (>=5x over control)',f'{pn} {arm}: donors; mAbs; % binding all 6 seasonal strains (donor mean, range); % binding other subtype (H5/H7)',f'{len(g)} donors; {g.n_mabs.sum()} mAbs; {g.pct_bind_all6.mean():.1f}% ({g.pct_bind_all6.min():.1f}-{g.pct_bind_all6.max():.1f}); {g.pct_bind_other_subtype.mean():.1f}%','mab_binding_panels.csv','mab_panels.py (donor-level)')
mm_=pd.read_csv(fs+'mab_binding_panels.csv')
x=mm_[(mm_.arm=='mRNA-1010')&(mm_.antigen.isin(['A/Wisconsin/588/2019','A/Victoria/4897/2022']))].groupby('antigen').fold_over_control.median()
add('mAb panels','mRNA-donor mAbs: median binding to A/Wisconsin/588/2019 vs A/Victoria/4897/2022',f'{x["A/Wisconsin/588/2019"]:.0f} vs {x["A/Victoria/4897/2022"]:.0f}','mab_binding_panels.csv','median fold_over_control')
# ---- IgM
i=pd.read_csv(fs+'igm_fold_change.csv',dtype={'participant':str})
for ag,g in i.groupby('antigen'):
    add('IgM',f'{ag}: GM fold-change mRNA / Fluarix',f'{gm(g[g.arm=="mRNA-1010"].fold_change):.2f} / {gm(g[g.arm=="Fluarix"].fold_change):.2f}','igm_fold_change.csv (n=14/15)','GM')
# ---- repertoire
Rp=pd.read_csv(A+'repertoire_summary.csv')
for _,r in Rp.iterrows():
    add('Serum repertoire',f'{r.file}: {r.metric} mean mRNA / Fluarix',f'{r.mean_mRNA:.1f} / {r.mean_Flu:.1f} (p={r.MWU_p:.3f})' if not np.isnan(r.MWU_p) else f'{r.mean_mRNA:.1f} / {r.mean_Flu:.1f}',r.file+'.csv (n=8/8 at wk0/wk4)','repertoire.py')
# ---- sizing
S1=pd.read_csv(A+'study1_sizing.csv')
for _,r in S1.iterrows():
    add('Study 1 sizing',f'{r.subtype}, GMT ratio {r.detectable_GMT_ratio}, {r.alpha}, 90% power',f'{r.n_evaluable_per_arm} evaluable / {r.n_enrolled_per_arm_15pct_attrition} enrolled per arm','WU397 SDs (neutralization_seqbased.csv)','study1_sizing.py')
HN=pd.read_csv(A+'sample_size_HAI_NI.csv')
for _,r in HN.iterrows():
    add('HAI NI sizing',f'{r.antigen}: pooled SD log2 wk4 HAI; n/arm for GMT-ratio NI (margin 1.5, 90%)',f'{r.pooled_sd_log2_HAI_wk4:.2f}; {r.n_per_arm_NI_GMTratio_margin1p5_power90}','hai_titers.csv','variance_and_power.py')
Ef=pd.read_csv(A+'efficacy_event_sizing.csv')
for _,r in Ef[(Ef.assumed_true_rVE==0.25)].iterrows():
    add('Study 2 sizing (illustrative)',f'rVE {r.assumed_true_rVE:.0%}, {r.test}, power {r.power}, comparator attack rate {r.assumed_comparator_attack_rate}',f'{r.events_needed} cases; N~{r.total_N_one_season}','assumptions (not from package)','efficacy_events.py')
K=pd.DataFrame(rows); K.to_csv(A+'key_numbers.csv',index=False)
print(len(K),'rows written')
# ---- appended: SCR NI and CHIM sizing
K=pd.read_csv(A+'key_numbers.csv'); rows=K.to_dict('records')
SC=pd.read_csv(A+'sample_size_SCR_NI.csv')
for _,r in SC.iterrows():
    rows.append(dict(section='HAI NI sizing',quantity=f'{r.antigen}: pooled WU397 SCR; n/arm for SCR-difference NI (margin 10 pp, 90% power)',value=f'{r.pooled_SCR:.2f}; {r.n_per_arm_SCR_NI_margin10pp_power90}',source='hai_titers.csv',derivation='variance_and_power.py'))
CH=pd.read_csv(A+'chim_sizing.csv')
for _,r in CH.iterrows():
    rows.append(dict(section='Study 3 sizing (illustrative)',quantity=f'CHIM vaccine vs placebo: placebo risk {r.assumed_placebo_risk}, efficacy {r.assumed_efficacy}, 80% power',value=f'{r.n_per_arm_80pct_power} per arm',source='assumptions (not from package)',derivation='efficacy_events.py'))
pd.DataFrame(rows).to_csv(A+'key_numbers.csv',index=False); print(len(rows),'rows after append')
# ---- appended: same-strain binding vs neutralisation dissociation
K=pd.read_csv(A+'key_numbers.csv'); rows=K.to_dict('records')
D=pd.read_csv(A+'binding_neut_dissociation.csv')
for _,r in D.iterrows():
    rows.append(dict(section='Binding vs neutralisation, same strain',quantity=f'{r.strain}: mRNA/Fluarix binding fold-rise ratio; neutralisation fold-rise ratio; ratio of ratios; p',value=f'{r.binding_ratio:.2f}; {r.neut_ratio:.2f}; {r.ratio_of_ratios:.2f}; p={r.welch_p:.3g}',source='binding_breadth_h1/h3.csv + neutralization_seqbased.csv (n=13/14 with both)',derivation='binding_neut_dissociation.py'))
pd.DataFrame(rows).to_csv(A+'key_numbers.csv',index=False); print(len(rows),'rows after dissociation append')
# ---- appended: supplementary checks
K=pd.read_csv(A+'key_numbers.csv'); rows=K.to_dict('records')
SC=pd.read_csv(A+'supplementary_checks.csv')
for _,r in SC.iterrows():
    rows.append(dict(section='Supplementary '+r.check,quantity=r.quantity,value=r.value,source='microneutralization.csv / elisa_igg_titers.csv / neutralization_seqbased.csv',derivation='supplementary_checks.py'))
pd.DataFrame(rows).to_csv(A+'key_numbers.csv',index=False); print(len(rows),'rows after supplementary append')
# ---- appended: remaining quoted numbers (SDs, bead CIs, Thailand/8 CI, mAb mean strains, derived sizing)
K=pd.read_csv(A+'key_numbers.csv'); rows=K.to_dict('records')
def add2(section,quantity,value,source,derivation): rows.append(dict(section=section,quantity=quantity,value=value,source=source,derivation=derivation))
SS=pd.read_csv(A+'sample_size_heterologous_neut.csv').drop_duplicates(['category','metric'])
for _,r in SS.iterrows():
    add2('Study 1 sizing inputs',f'{r.category} per-participant panel-mean log2 titre ({r.metric}) pooled within-arm SD',f'{r.pooled_sd_log2:.2f}','neutralization_seqbased.csv','variance_and_power.py')
R=pd.read_csv(A+'gmt_ratio_cis.csv')
for _,r in R[R.assay.str.startswith('Bead')].iterrows():
    add2('Bead-array binding (CI)',f'{r.target}: fold-rise ratio mRNA/Fluarix (95% CI), Welch p',f'{r.ratio:.2f} ({r.lo:.2f}-{r.hi:.2f}), p={r.p:.4f}','binding_breadth_h1/h3.csv','gmt_ratio_cis.py')
n=pd.read_csv(A+'seqneut_annotated.csv')
from scipy import stats
w=n[n.virus=='A/Thailand/8/2022_H3N2'].pivot_table(index=['arm','pid'],columns='day',values='log2t')
v=(w.d29-w.d0); a=v.xs('mRNA-1010').dropna(); f=v.xs('Fluarix').dropna()
vx,vy=a.var(ddof=1)/len(a),f.var(ddof=1)/len(f); se=np.sqrt(vx+vy); df=(vx+vy)**2/(vx**2/(len(a)-1)+vy**2/(len(f)-1)); t=stats.t.ppf(0.975,df); d=a.mean()-f.mean()
add2('Seq-based neutralisation (per virus)','A/Thailand/8/2022 d29 fold-rise ratio mRNA/Fluarix (95% CI)',f'{2**d:.2f} ({2**(d-t*se):.2f}-{2**(d+t*se):.2f})','neutralization_seqbased.csv','Welch on log2 (same as forest_plot.py)')
M=pd.read_csv(A+'mab_per_donor_summary.csv'); M5=M[M.threshold==5]
for (pn,arm),g in M5.groupby(['panel','arm']):
    add2('mAb panels (>=5x over control)',f'{pn} {arm}: mean number of the 6 seasonal strains bound per mAb (donor mean)',f'{g.mean_n_seasonal_bound.mean():.1f}','mab_binding_panels.csv','mab_panels.py')
for f_ in [0.3,0.5]:
    add2('Study 2 sizing (illustrative)',f'total cases needed if {f_:.0%} of cases are mismatched (383 mismatched cases, rVE 25%, 80% power)',f'{int(np.ceil(383/f_))}','assumptions','efficacy_events.py')
add2('Study 1 sizing','enrolment per arm if Study 1 must also carry SCR non-inferiority (510 evaluable / 0.85)',f'{int(np.ceil(510/0.85))}','hai_titers.csv + 15% attrition assumption','arithmetic')
pd.DataFrame(rows).to_csv(A+'key_numbers.csv',index=False); print(len(rows),'rows after final append')
# ---- appended: breadth-index power
K=pd.read_csv(A+'key_numbers.csv'); rows=K.to_dict('records')
BI=pd.read_csv(A+'study1_breadth_index_power.csv')
for _,r in BI.iterrows():
    rows.append(dict(section='Study 1 sizing',quantity=f'{r.subtype}: WU397 SD of log2 breadth index; true breadth-index ratio detectable with 90% power at 229/arm, alpha 0.0125',value=f'{r.pooled_sd_log2_breadth_index:.2f}; {r.true_ratio_detectable_90pct:.2f}',source='neutralization_seqbased.csv',derivation='study1_sizing.py'))
pd.DataFrame(rows).to_csv(A+'key_numbers.csv',index=False); print(len(rows),'rows (final)')
# ---- appended: minimum observed ratio for success
K=pd.read_csv(A+'key_numbers.csv'); rows=K.to_dict('records')
MO=pd.read_csv(A+'study1_min_observed_ratio.csv')
for _,r in MO.iterrows():
    rows.append(dict(section='Study 1 sizing',quantity=f'{r.subtype}: smallest observed Tier-1 GMT ratio giving lower 95% bound > 1.0 at 229/arm (alpha 0.0125)',value=f'{r.min_observed_ratio_for_LB_gt_1:.2f}',source='neutralization_seqbased.csv SDs',derivation='study1_sizing.py'))
pd.DataFrame(rows).to_csv(A+'key_numbers.csv',index=False); print(len(rows),'rows (final)')
