#!/usr/bin/env bash
# Reproduces every analysis output used in /tmp/outputs/answer.md (inputs: /tmp/world/filesystem, read-only).
set -euo pipefail
cd "$(dirname "$0")"
PY="micromamba run -n core python"
$PY seqneut_analysis.py          # annotates seq-neut panel, category summaries  -> seqneut_annotated.csv, seqneut_by_category.csv
$PY seqneut_breadth_normalised.py # breadth index (drifted / own-vaccine-strain titre) -> seqneut_breadth_normalised.csv
$PY egg_vs_wildtype_pairs.py     # egg / production-reassortant vs wild-type titres -> egg_vs_wildtype_pairs.csv
$PY gmt_ratio_cis.py             # GMT / fold-rise ratios with 95% CI, all assays -> gmt_ratio_cis.csv
$PY ancova.py                    # baseline-adjusted GMT ratios -> ancova_baseline_adjusted.csv
$PY hai_scr.py                   # HAI seroconversion / >=1:40 with exact CIs -> hai_scr_sp.csv
$PY binding_vs_function.py       # per-participant binding vs neutralisation correlations
$PY binding_neut_dissociation.py # same-strain binding vs neutralisation advantage (ratio of ratios)
$PY mab_panels.py                # donor-level mAb breadth summaries
$PY gc_pb.py                     # lymph-node GC and plasmablast summaries
$PY repertoire.py                # serum repertoire summaries (unpaired)
$PY variance_and_power.py        # SDs and HAI NI sizing
$PY study1_sizing.py             # Study 1 sample size
$PY efficacy_events.py           # Study 2 event-driven sizing; Study 3 CHIM sizing (assumption-based)
$PY data_integrity_checks.py     # data-package issues -> data_integrity_issues.csv
$PY supplementary_checks.py      # MN virus identity, ELISA core vs extension, H1 skew, late-visit neutralisation
$PY forest_plot.py               # ../forest_binding_vs_function.png
$PY key_numbers.py               # ledger of every quoted number -> key_numbers.csv
