"""
Formal test that the mRNA-vs-Fluarix advantage differs between binding and neutralisation for the SAME H3 strain:
per participant, d = log2(binding fold-rise) - log2(neutralisation fold-rise); compare d between arms (Welch t and MWU).
Strains present in both bead-array and seq-neut panels: A/Darwin/6/2021, A/Thailand/8/2022, A/Cambodia/e0826360/2020,
A/Hong Kong/2671/2019, A/Singapore/INFIMH-16-0019/2016, A/Texas/50/2012; H1: A/Wisconsin/588/2019, A/Wisconsin/67/2022,
A/Michigan/45/2015, A/Brisbane/2/2018, A/Hawaii/70/2019.
"""
import pandas as pd, numpy as np
from scipy import stats
fs='/tmp/world/filesystem/'
b=pd.concat([pd.read_csv(fs+'binding_breadth_h1.csv'),pd.read_csv(fs+'binding_breadth_h3.csv')])
n=pd.read_csv('/tmp/outputs/analysis/seqneut_annotated.csv')
w=n[n.day.isin(['d0','d29'])].pivot_table(index=['pid','virus'],columns='day',values='log2t')
w['nfold']=w.d29-w.d0; w=w.reset_index()
pairs={'A/Darwin/6/2021':'A/Darwin/6/2021_H3N2','A/Thailand/8/2022':'A/Thailand/8/2022_H3N2','A/Cambodia/e0826360/2020':'A/Cambodia/e0826360/2020_H3N2',
       'A/Hong Kong/2671/2019':'A/HongKong/2671/2019_H3N2','A/Singapore/INFIMH-16-0019/2016':'A/Singapore/INFIMH-16-0019/2016_H3N2','A/Texas/50/2012':'A/Texas/50/2012_H3N2',
       'A/Wisconsin/588/2019':'A/Wisconsin/588/2019_H1N1','A/Wisconsin/67/2022':'A/Wisconsin/67/2022_H1N1','A/Michigan/45/2015':'A/Michigan/45/2015_H1N1',
       'A/Brisbane/2/2018':'A/Brisbane/02/2018_H1N1','A/Hawaii/70/2019':'A/Hawaii/70/2019_H1N1'}
rows=[]
for bs,nv in pairs.items():
    bb=b[b.strain==bs][['participant','arm','log2_fold_change_mfi']].rename(columns={'participant':'pid'})
    nn=w[w.virus==nv][['pid','nfold']]
    j=bb.merge(nn,on='pid').dropna()
    j['d']=j.log2_fold_change_mfi-j.nfold
    a=j[j.arm=='mRNA-1010']; f=j[j.arm=='Fluarix']
    rb=2**(a.log2_fold_change_mfi.mean()-f.log2_fold_change_mfi.mean()); rn=2**(a.nfold.mean()-f.nfold.mean())
    t=stats.ttest_ind(a.d,f.d,equal_var=False)
    rows.append(dict(strain=bs,n_mRNA=len(a),n_Flu=len(f),binding_ratio=rb,neut_ratio=rn,ratio_of_ratios=rb/rn,welch_p=t.pvalue,mwu_p=stats.mannwhitneyu(a.d,f.d).pvalue))
R=pd.DataFrame(rows); pd.set_option('display.width',200); print(R.round(3).to_string()); R.to_csv('/tmp/outputs/analysis/binding_neut_dissociation.csv',index=False)
