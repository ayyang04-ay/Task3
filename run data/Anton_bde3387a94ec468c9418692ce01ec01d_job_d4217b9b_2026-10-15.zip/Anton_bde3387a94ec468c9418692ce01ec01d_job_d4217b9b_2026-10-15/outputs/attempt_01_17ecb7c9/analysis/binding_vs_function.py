"""
Per-participant binding vs functional readouts (core cohort, participants with both).
Binding: ELISA IgG wk4 fold-change (A/H1, A/H3); bead-array log2 FC (Darwin/6/2021 for H3; Wisconsin/67/2022 for H1).
Function: seq-neut d29/d0 fold (vaccine-like strains and 2023-24 circulating), HAI wk4 fold, MN wk4 fold.
"""
import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width',250)
fs='/tmp/world/filesystem/'
e=pd.read_csv(fs+'elisa_igg_titers.csv'); e=e[(e.measure=='fold_change')&(e.timepoint=='wk4')]
e['pid']=e.participant.map(lambda x:f'397-{x:03d}')
el=e.pivot_table(index='pid',columns='antigen',values='value')
b1=pd.read_csv(fs+'binding_breadth_h1.csv'); b3=pd.read_csv(fs+'binding_breadth_h3.csv')
bb=pd.concat([b1,b3]).pivot_table(index='participant',columns='strain',values='log2_fold_change_mfi')
h=pd.read_csv(fs+'hai_titers.csv',dtype={'participant':str}); h['pid']='397-'+h.participant
hw=h.pivot_table(index=['pid'],columns=['antigen','timepoint'],values='hai_titer')
hai_fc=pd.DataFrame({ag:hw[(ag,'wk4')]/hw[(ag,'wk0')] for ag in ['A/H1N1','A/H3N2']})
mn=pd.read_csv(fs+'microneutralization.csv'); mn=mn[(mn.measure=='fold_change')&(mn.timepoint=='wk4')].pivot_table(index='participant',columns='panel',values='value')
n=pd.read_csv('/tmp/outputs/analysis/seqneut_annotated.csv')
pp=n[n.day.isin(['d0','d29'])].groupby(['pid','cat','day']).log2t.mean().unstack('day')
pp['fold']=pp.d29-pp.d0
sq=pp.fold.unstack('cat')
arm=pd.concat([pd.read_csv(fs+'binding_breadth_h1.csv')[['participant','arm']].drop_duplicates().set_index('participant')])
D=pd.DataFrame(index=arm.index)
D['arm']=arm.arm
D['ELISA_H3_log2FC']=np.log2(el['A/H3']); D['ELISA_H1_log2FC']=np.log2(el['A/H1'])
D['bead_Darwin6_log2FC']=bb['A/Darwin/6/2021']; D['bead_Wis67_log2FC']=bb['A/Wisconsin/67/2022']
D['bead_HK68_log2FC']=bb['A/Hong Kong/1/1968']
D['HAI_H3_log2FC']=np.log2(hai_fc['A/H3N2']); D['HAI_H1_log2FC']=np.log2(hai_fc['A/H1N1'])
D['MN_hom_log2FC']=np.log2(mn['homologous']); D['MN_het_log2FC']=np.log2(mn['heterologous'])
D['seq_H3_2023-24_log2FC']=sq['H3_2023-24_circulating']; D['seq_Darwin6_log2FC']=sq['H3_Darwin/6 (mRNA antigen, cell-like)']
D['seq_H1_2023_log2FC']=sq['H1_2023_circulating']; D['seq_H1_mRNAlike_log2FC']=sq['H1_mRNA-antigen-like(5a.2a.1)']
D.to_csv('/tmp/outputs/analysis/per_participant_binding_function.csv')
pairs=[('ELISA_H3_log2FC','seq_H3_2023-24_log2FC'),('bead_Darwin6_log2FC','seq_Darwin6_log2FC'),('bead_Darwin6_log2FC','seq_H3_2023-24_log2FC'),
       ('ELISA_H3_log2FC','HAI_H3_log2FC'),('ELISA_H3_log2FC','MN_hom_log2FC'),
       ('ELISA_H1_log2FC','seq_H1_2023_log2FC'),('bead_Wis67_log2FC','seq_H1_mRNAlike_log2FC'),('ELISA_H1_log2FC','HAI_H1_log2FC'),
       ('bead_HK68_log2FC','seq_H3_2023-24_log2FC')]
rows=[]
for a,b in pairs:
    for arm_,g in list(D.groupby('arm'))+[('pooled',D)]:
        x=g[[a,b]].dropna()
        r=stats.spearmanr(x[a],x[b])
        rows.append(dict(binding=a,function=b,arm=arm_,n=len(x),spearman_rho=r.correlation,p=r.pvalue))
R=pd.DataFrame(rows); print(R.round(3).to_string()); R.to_csv('/tmp/outputs/analysis/binding_vs_function_correlations.csv',index=False)
print(D.groupby('arm').mean(numeric_only=True).T.round(2))
