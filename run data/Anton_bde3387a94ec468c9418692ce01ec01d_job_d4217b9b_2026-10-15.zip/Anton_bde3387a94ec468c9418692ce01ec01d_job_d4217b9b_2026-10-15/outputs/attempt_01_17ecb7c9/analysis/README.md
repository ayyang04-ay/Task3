# WU397 re-analysis (supports /tmp/outputs/answer.md)

Inputs (read-only): `/tmp/world/filesystem/*`. Regenerate everything with `./run_all.sh` (uses the `core` micromamba env).

| Script | What it does | Main outputs |
|---|---|---|
| `seqneut_analysis.py` | Annotates the 96-virus sequencing-based neutralisation panel (subtype, category, egg/reassortant flag); per-participant category means; per-virus arm comparisons | `seqneut_annotated.csv`, `seqneut_by_category.csv`, `seqneut_per_virus.csv` |
| `seqneut_breadth_normalised.py` | Breadth index = drifted-panel titre / own-vaccine-strain titre (separates breadth from magnitude) | `seqneut_breadth_normalised.csv` |
| `egg_vs_wildtype_pairs.py` | Egg/production-reassortant vs wild-type titres for the same strain | `egg_vs_wildtype_pairs.csv` |
| `gmt_ratio_cis.py` | mRNA/Fluarix GMT and fold-rise ratios with Welch 95% CIs (ELISA, HAI, MN, seq-neut, bead array) | `gmt_ratio_cis.csv` |
| `ancova.py` | Baseline-adjusted GMT ratios | `ancova_baseline_adjusted.csv` |
| `hai_scr.py` | HAI seroconversion / >=1:40 with exact CIs | `hai_scr_sp.csv` |
| `binding_vs_function.py` | Per-participant binding vs neutralisation/HAI correlations | `per_participant_binding_function.csv`, `binding_vs_function_correlations.csv` |
| `binding_neut_dissociation.py` | Same-strain, same-participant binding vs neutralisation advantage (ratio of ratios) | `binding_neut_dissociation.csv` |
| `mab_panels.py` | Donor-level mAb breadth (binding call >=5x over control; sensitivity 3x, 10x) | `mab_per_donor_summary.csv` |
| `gc_pb.py` | Lymph-node GC (two unlabelled blocks analysed separately) and plasmablast summaries | `gc_summary.csv`, `pb_summary.csv` |
| `repertoire.py` | Serum IgG repertoire files (unpaired, no IDs) | `repertoire_summary.csv` |
| `variance_and_power.py`, `study1_sizing.py` | Variance estimates and Study 1 sizing (GMT ratio, breadth index, HAI NI) | `sample_size_*.csv`, `study1_*.csv` |
| `efficacy_events.py` | Study 2 event-driven sizing and Study 3 (CHIM) sizing — assumption-based | `efficacy_event_sizing.csv`, `chim_sizing.csv` |
| `data_integrity_checks.py` | Programmatic checks behind the data-package issue list | `data_integrity_issues.csv` |
| `supplementary_checks.py` | MN virus identity (correlation), ELISA core vs extension cohorts, H1 skew, late-visit titres | `supplementary_checks.csv` |
| `forest_plot.py` | Binding vs function forest plot | `../forest_binding_vs_function.png` |
| `key_numbers.py` | Ledger of every number quoted in answer.md with source file and derivation | `key_numbers.csv` |

Conventions: ratios are mRNA-1010 / Fluarix; titres analysed on log2 scale; censored seq-neut titres (171 at/below LOD, 70 at/above ULOQ) used at the bound; p-values unadjusted/exploratory.
