"""HAI seroconversion (pre<10 & post>=40, or pre>=10 & >=4-fold) and seroprotection (>=40) at wk4, exact 95% CIs."""
import pandas as pd, numpy as np
from scipy import stats
fs='/tmp/world/filesystem/'
h=pd.read_csv(fs+'hai_titers.csv',dtype={'participant':str})
hw=h.pivot_table(index=['antigen','arm','participant'],columns='timepoint',values='hai_titer').dropna(subset=['wk0','wk4'])
hw['sc']=((hw.wk0<10)&(hw.wk4>=40))|((hw.wk0>=10)&(hw.wk4/hw.wk0>=4))
hw['sp0']=hw.wk0>=40; hw['sp4']=hw.wk4>=40
def cp(k,n):
    lo=stats.beta.ppf(0.025,k,n-k+1) if k>0 else 0.0
    hi=stats.beta.ppf(0.975,k+1,n-k) if k<n else 1.0
    return lo,hi
rows=[]
for (ag,arm),g in hw.groupby(level=[0,1]):
    for col,lab in [('sc','seroconversion wk4'),('sp0','HAI>=40 wk0'),('sp4','HAI>=40 wk4')]:
        k=int(g[col].sum()); n=len(g); lo,hi=cp(k,n)
        rows.append(dict(antigen=ag,arm=arm,metric=lab,k=k,n=n,pct=100*k/n,lo=100*lo,hi=100*hi))
R=pd.DataFrame(rows); pd.set_option('display.width',200); print(R.round(1).to_string()); R.to_csv('/tmp/outputs/analysis/hai_scr_sp.csv',index=False)
