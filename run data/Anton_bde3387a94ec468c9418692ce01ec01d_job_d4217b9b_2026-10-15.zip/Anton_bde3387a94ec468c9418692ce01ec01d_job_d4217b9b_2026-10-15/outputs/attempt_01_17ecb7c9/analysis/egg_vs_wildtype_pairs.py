"""Paired comparison of egg/production-reassortant viruses vs their wild-type counterparts in the seq-neut panel."""
import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width',250)
n=pd.read_csv('/tmp/outputs/analysis/seqneut_annotated.csv')
pairs=[('A/Cambodia/e0826360/2020egg_H3N2','A/Cambodia/e0826360/2020_H3N2'),
       ('A/HongKong/4801/2014egg_H3N2','A/HongKong/4801/2014_H3N2'),
       ('A/Singapore/INFIMH-16-0019/2016X-307A_H3N2','A/Singapore/INFIMH-16-0019/2016_H3N2'),
       ('A/Switzerland/9715293/2013NIB-88_H3N2','A/Switzerland/9715293/2013_H3N2'),
       ('A/Texas/50/2012X-223A_H3N2','A/Texas/50/2012_H3N2'),
       ('A/Darwin/9/2021_H3N2','A/Darwin/6/2021_H3N2'),
       ('A/Victoria/4897/2022_IVR-238_H1N1','A/Wisconsin/67/2022_H1N1')]
w=n.pivot_table(index=['arm','pid','day'],columns='virus',values='log2t')
rows=[]
for egg,wt in pairs:
    for day in ['d0','d29']:
        for arm in ['mRNA-1010','Fluarix','both']:
            sub=w.xs(day,level='day') if arm=='both' else w.xs((arm,day),level=('arm','day'))
            d=(sub[egg]-sub[wt]).dropna()
            rows.append(dict(egg_or_reassortant=egg,wildtype_or_cell=wt,day=day,arm=arm,n=len(d),GM_ratio_egg_over_wt=2**d.mean(),
                             wilcoxon_p=stats.wilcoxon(d).pvalue if len(d)>5 else np.nan))
R=pd.DataFrame(rows); print(R[R.arm=='both'].round(3).to_string()); R.to_csv('/tmp/outputs/analysis/egg_vs_wildtype_pairs.csv',index=False)
print(R[(R.arm!='both')&(R.day=='d29')].round(2).to_string())
