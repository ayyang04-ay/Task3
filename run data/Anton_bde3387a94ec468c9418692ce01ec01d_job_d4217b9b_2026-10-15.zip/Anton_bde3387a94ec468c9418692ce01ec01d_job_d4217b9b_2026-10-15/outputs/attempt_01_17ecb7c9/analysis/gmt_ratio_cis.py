"""
GMT ratios (mRNA-1010 / Fluarix) with Welch 95% CIs on log2 scale for the key functional and binding readouts.
Post-vaccination = wk4/d29. Also fold-rise ratios. ELISA (n=75), HAI & MN (n=29), seq-neut categories (n=27), bead array (n=29).
"""
import pandas as pd, numpy as np
from scipy import stats
fs='/tmp/world/filesystem/'
def welch(x,y):
    x=np.asarray(x,float); y=np.asarray(y,float)
    mx,my=x.mean(),y.mean(); vx,vy=x.var(ddof=1)/len(x),y.var(ddof=1)/len(y)
    se=np.sqrt(vx+vy); df=(vx+vy)**2/(vx**2/(len(x)-1)+vy**2/(len(y)-1))
    t=stats.t.ppf(0.975,df); d=mx-my
    return 2**d,2**(d-t*se),2**(d+t*se),2*stats.t.sf(abs(d/se),df)
rows=[]
# ELISA
e=pd.read_csv(fs+'elisa_igg_titers.csv')
for ag in ['A/H1','A/H3','B/Vic','B/Yam']:
    for tp,ms,lab in [('wk0','ec50','baseline EC50'),('wk4','ec50','wk4 EC50'),('wk4','fold_change','wk4 fold-rise'),('wk17/26','fold_change','wk17/26 fold-rise')]:
        g=e[(e.antigen==ag)&(e.timepoint==tp)&(e.measure==ms)]
        a=np.log2(g[g.arm=='mRNA-1010'].value); f=np.log2(g[g.arm=='Fluarix'].value)
        r=welch(a,f); rows.append(dict(assay='ELISA IgG (binding)',target=ag,metric=lab,n_mRNA=len(a),n_Flu=len(f),ratio=r[0],lo=r[1],hi=r[2],p=r[3]))
# HAI
h=pd.read_csv(fs+'hai_titers.csv',dtype={'participant':str})
hw=h.pivot_table(index=['antigen','arm','participant'],columns='timepoint',values='hai_titer')
for ag in ['A/H1N1','A/H3N2','B/Vic','B/Yam']:
    g=hw.xs(ag,level=0)
    for col,lab in [('wk0','baseline GMT'),('wk4','wk4 GMT'),('fc','wk4 fold-rise')]:
        if col=='fc': v=np.log2(g.wk4/g.wk0)
        else: v=np.log2(g[col])
        a=v.xs('mRNA-1010',level=0).dropna(); f=v.xs('Fluarix',level=0).dropna()
        r=welch(a,f); rows.append(dict(assay='HAI (functional; accepted correlate)',target=ag,metric=lab,n_mRNA=len(a),n_Flu=len(f),ratio=r[0],lo=r[1],hi=r[2],p=r[3]))
# MN
m=pd.read_csv(fs+'microneutralization.csv'); m=m[m.measure=='titer']
mw=m.pivot_table(index=['panel','arm','participant'],columns='timepoint',values='value')
for pn in ['homologous','heterologous']:
    g=mw.xs(pn,level=0)
    for col,lab in [('wk0','baseline GMT'),('wk4','wk4 GMT'),('fc','wk4 fold-rise')]:
        v=np.log2(g.wk4/g.wk0) if col=='fc' else np.log2(g[col])
        a=v.xs('mRNA-1010',level=0).dropna(); f=v.xs('Fluarix',level=0).dropna()
        r=welch(a,f); rows.append(dict(assay='Microneutralisation (functional; ULOQ 1280)',target=pn+' panel (virus identity undocumented)',metric=lab,n_mRNA=len(a),n_Flu=len(f),ratio=r[0],lo=r[1],hi=r[2],p=r[3]))
# seq-neut categories
n=pd.read_csv('/tmp/outputs/analysis/seqneut_annotated.csv')
pp=n[n.day.isin(['d0','d29'])].groupby(['arm','pid','cat','day']).log2t.mean().unstack('day'); pp['fold']=pp.d29-pp.d0
for c in sorted(n.cat.unique()):
    g=pp.xs(c,level='cat')
    for col,lab in [('d0','baseline GMT'),('d29','d29 GMT'),('fold','d29 fold-rise')]:
        a=g.xs('mRNA-1010',level='arm')[col].dropna(); f=g.xs('Fluarix',level='arm')[col].dropna()
        r=welch(a,f); rows.append(dict(assay='Seq-based neutralisation (functional)',target=c,metric=lab,n_mRNA=len(a),n_Flu=len(f),ratio=r[0],lo=r[1],hi=r[2],p=r[3]))
# bead array (log2 fold-change MFI; assumed wk4 vs wk0 - timepoint undocumented)
for fn,sub in [('binding_breadth_h1.csv','H1'),('binding_breadth_h3.csv','H3')]:
    b=pd.read_csv(fs+fn)
    for s,g in b.groupby('strain'):
        a=g[g.arm=='mRNA-1010'].log2_fold_change_mfi; f=g[g.arm=='Fluarix'].log2_fold_change_mfi
        r=welch(a,f); rows.append(dict(assay='Bead-array binding (timepoint undocumented)',target=f'{sub} {s}',metric='fold-rise MFI',n_mRNA=len(a),n_Flu=len(f),ratio=r[0],lo=r[1],hi=r[2],p=r[3]))
R=pd.DataFrame(rows)
R.to_csv('/tmp/outputs/analysis/gmt_ratio_cis.csv',index=False)
pd.set_option('display.width',250); pd.set_option('display.max_rows',500); pd.set_option('display.max_colwidth',60)
print(R.round(3).to_string())
