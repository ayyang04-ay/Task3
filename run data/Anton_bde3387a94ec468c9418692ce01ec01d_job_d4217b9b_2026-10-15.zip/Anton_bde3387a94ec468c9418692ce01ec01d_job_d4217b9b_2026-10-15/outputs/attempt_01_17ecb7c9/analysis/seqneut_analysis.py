"""
Sequencing-based neutralisation (neutralization_seqbased.csv): per-participant summaries by virus category,
arm comparisons of baseline (d0), post (d29) and fold-rise, and 'breadth' metrics normalised to the
homologous (vaccine-like) response. Titers reported as bounds (upper = at/below LOD, lower = at/above ULOQ)
are used at the bound value (conservative; flagged counts reported).
"""
import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width',250); pd.set_option('display.max_rows',800)
n=pd.read_csv('/tmp/world/filesystem/neutralization_seqbased.csv')
n['arm']=n.serum.str.split('_').str[0]; n['pid']=n.serum.str.split('_').str[1]; n['day']=n.serum.str.split('_').str[2]
n['sub']=n.virus.str.extract(r'_(H\dN\d)$')[0]
def cat(v):
    h1={'A/California/07/2009_H1N1':'H1_historical','A/Michigan/45/2015_H1N1':'H1_historical','A/Brisbane/02/2018_H1N1':'H1_historical',
        'A/Hawaii/70/2019_H1N1':'H1_historical',
        'A/Wisconsin/588/2019_H1N1':'H1_Fluarix22-23-like(5a.2)',
        'A/Wisconsin/67/2022_H1N1':'H1_mRNA-antigen-like(5a.2a.1)','A/Victoria/4897/2022_IVR-238_H1N1':'H1_mRNA-antigen-like(5a.2a.1)'}
    if v in h1: return h1[v]
    if v.endswith('H1N1'): return 'H1_2023_circulating'
    h3vac={'A/Darwin/6/2021_H3N2':'H3_Darwin/6 (mRNA antigen, cell-like)','A/Darwin/9/2021_H3N2':'H3_Darwin/9 (Fluarix egg antigen)'}
    if v in h3vac: return h3vac[v]
    hist=['Texas/50/2012','Switzerland/9715293/2013','HongKong/4801/2014','Singapore/INFIMH-16-0019/2016','Kansas/14/2017','HongKong/45/2019','HongKong/2671/2019','Cambodia/e0826360/2020']
    if any(h in v for h in hist): return 'H3_historical'
    if any(h in v for h in ['Thailand/8/2022','Massachusetts/18/2022','Bhutan/FLU-BTG-00988/2022','Romania/543634/2022']): return 'H3_2022'
    return 'H3_2023-24_circulating'
n['cat']=n.virus.map(cat)
n['egg_or_reassortant']=n.virus.str.contains(r'egg|X-\d+A|NIB-\d+|IVR-\d+')
n['log2t']=np.log2(n.titer)
n.to_csv('/tmp/outputs/analysis/seqneut_annotated.csv',index=False)
print(n.drop_duplicates('virus').groupby('cat').virus.count())
print('Censored values:',n.titer_bound.value_counts().to_dict())

# Per participant mean log2 titer per category and day
pp=n.groupby(['arm','pid','day','cat']).log2t.mean().unstack('day')
pp['fold_d29']=pp['d29']-pp['d0']
res=[]
for c,g in pp.groupby(level='cat'):
    a=g.xs('mRNA-1010',level='arm'); f=g.xs('Fluarix',level='arm')
    for col in ['d0','d29','fold_d29']:
        x=a[col].dropna(); y=f[col].dropna()
        p=stats.mannwhitneyu(x,y).pvalue
        res.append(dict(category=c,metric=col,n_mRNA=len(x),n_Flu=len(y),
                        GM_mRNA=2**x.mean(),GM_Flu=2**y.mean(),ratio_mRNA_over_Flu=2**(x.mean()-y.mean()),MWU_p=p))
res=pd.DataFrame(res)
print(res.round(3).to_string())
res.to_csv('/tmp/outputs/analysis/seqneut_by_category.csv',index=False)

# ---- per-virus arm comparison (d0, d29, fold-rise) -> seqneut_per_virus.csv
w=n.pivot_table(index=['virus','arm','pid'],columns='day',values='titer')
w['fc29']=w.d29/w.d0
rows=[]
for v,g in w.groupby(level=0):
    a=g.xs('mRNA-1010',level=1); f=g.xs('Fluarix',level=1)
    fa=a.fc29.dropna(); ff=f.fc29.dropna()
    rows.append(dict(virus=v,nA=len(fa),nF=len(ff),
        GMT0_A=np.exp(np.log(a.d0.dropna()).mean()),GMT0_F=np.exp(np.log(f.d0.dropna()).mean()),
        GMT29_A=np.exp(np.log(a.d29.dropna()).mean()),GMT29_F=np.exp(np.log(f.d29.dropna()).mean()),
        GMFR_A=np.exp(np.log(fa).mean()),GMFR_F=np.exp(np.log(ff).mean()),p=stats.mannwhitneyu(np.log(fa),np.log(ff)).pvalue))
r=pd.DataFrame(rows); r['ratio_GMFR']=r.GMFR_A/r.GMFR_F; r['ratio_GMT29']=r.GMT29_A/r.GMT29_F
r=r.merge(n[['virus','cat']].drop_duplicates(),on='virus')
r.to_csv('/tmp/outputs/analysis/seqneut_per_virus.csv',index=False)
print('per-virus table written:',len(r),'viruses')
