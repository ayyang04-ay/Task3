"""Baseline-adjusted (ANCOVA) post-vaccination GMT ratios, mRNA-1010 vs Fluarix: log2(post) ~ arm + log2(pre)."""
import pandas as pd, numpy as np
import statsmodels.formula.api as smf
fs='/tmp/world/filesystem/'
rows=[]
def fit(df,label):
    m=smf.ols('post ~ C(arm, Treatment("Fluarix")) + pre',data=df).fit()
    k=[c for c in m.params.index if 'mRNA' in c][0]
    lo,hi=m.conf_int().loc[k]
    rows.append(dict(readout=label,n=len(df),adj_GMT_ratio=2**m.params[k],lo=2**lo,hi=2**hi,p=m.pvalues[k],slope_pre=m.params['pre']))
n=pd.read_csv('/tmp/outputs/analysis/seqneut_annotated.csv')
pp=n[n.day.isin(['d0','d29'])].groupby(['arm','pid','cat','day']).log2t.mean().unstack('day').reset_index()
for c in ['H1_2023_circulating','H1_mRNA-antigen-like(5a.2a.1)','H1_Fluarix22-23-like(5a.2)','H3_2023-24_circulating','H3_Darwin/6 (mRNA antigen, cell-like)','H3_Darwin/9 (Fluarix egg antigen)','H3_historical']:
    d=pp[pp.cat==c].rename(columns={'d0':'pre','d29':'post'}).dropna(subset=['pre','post'])
    fit(d,'seq-neut d29: '+c)
h=pd.read_csv(fs+'hai_titers.csv',dtype={'participant':str})
hw=h.pivot_table(index=['antigen','arm','participant'],columns='timepoint',values='hai_titer').reset_index()
for ag in ['A/H1N1','A/H3N2','B/Vic','B/Yam']:
    d=hw[hw.antigen==ag].assign(pre=lambda x: np.log2(x.wk0),post=lambda x: np.log2(x.wk4)).dropna(subset=['pre','post'])
    fit(d,'HAI wk4: '+ag)
m=pd.read_csv(fs+'microneutralization.csv'); m=m[m.measure=='titer']
mw=m.pivot_table(index=['panel','arm','participant'],columns='timepoint',values='value').reset_index()
for pn in ['homologous','heterologous']:
    d=mw[mw.panel==pn].assign(pre=lambda x: np.log2(x.wk0),post=lambda x: np.log2(x.wk4))
    fit(d,'MN wk4 (ULOQ-censored): '+pn)
e=pd.read_csv(fs+'elisa_igg_titers.csv'); e=e[e.measure=='ec50']
ew=e.pivot_table(index=['antigen','arm','participant'],columns='timepoint',values='value').reset_index()
for ag in ['A/H1','A/H3','B/Vic','B/Yam']:
    d=ew[ew.antigen==ag].assign(pre=lambda x: np.log2(x.wk0),post=lambda x: np.log2(x.wk4))
    fit(d,'ELISA IgG wk4: '+ag)
R=pd.DataFrame(rows); pd.set_option('display.width',250); print(R.round(3).to_string())
R.to_csv('/tmp/outputs/analysis/ancova_baseline_adjusted.csv',index=False)
