"""
Study 1 sizing (randomised strain-matched immunogenicity). Primary: GMT ratio (mRNA / comparator) at Day 29 against the
prespecified contemporary drifted-strain panel, per subtype (H1N1, H3N2). SDs from WU397 seq-neut (per-participant mean
log2 titre over contemporary strains, pooled within-arm SD). Bonferroni over 2 subtypes x 2 key comparisons (egg IIV3, RIV3)
=> two-sided alpha 0.0125 each. Power 90%. 15% attrition. Also shown: unadjusted.
"""
import numpy as np, pandas as pd
from scipy import stats
sds={'H1N1 (WU397 sd, log2)':1.654,'H3N2 (WU397 sd, log2)':1.219}
rows=[]
for lab,sd in sds.items():
    for ratio in [1.5,2.0]:
        for alpha,al in [(0.05,'unadjusted two-sided 0.05'),(0.0125,'Bonferroni 4 tests, two-sided 0.0125')]:
            za=stats.norm.ppf(1-alpha/2); zb=stats.norm.ppf(0.9)
            n=2*(za+zb)**2*sd**2/np.log2(ratio)**2
            rows.append(dict(subtype=lab,detectable_GMT_ratio=ratio,alpha=al,n_evaluable_per_arm=int(np.ceil(n)),n_enrolled_per_arm_15pct_attrition=int(np.ceil(n/0.85))))
R=pd.DataFrame(rows); pd.set_option('display.width',250); print(R.to_string()); R.to_csv('/tmp/outputs/analysis/study1_sizing.csv',index=False)

# ---- power for the breadth-index endpoint (log2 ratio of drifted-panel titre to own-vaccine-strain titre, d29) at 229/arm
n=pd.read_csv('/tmp/outputs/analysis/seqneut_annotated.csv')
w=n.pivot_table(index=['arm','pid','day'],columns='virus',values='log2t')
vir=n.drop_duplicates('virus').groupby('cat').virus.apply(list).to_dict()
own={'H1':{'mRNA-1010':['A/Wisconsin/67/2022_H1N1','A/Victoria/4897/2022_IVR-238_H1N1'],'Fluarix':['A/Wisconsin/588/2019_H1N1']},
     'H3':{'mRNA-1010':['A/Darwin/6/2021_H3N2'],'Fluarix':['A/Darwin/9/2021_H3N2']}}
rows=[]
for sub,cat in [('H1','H1_2023_circulating'),('H3','H3_2023-24_circulating')]:
    vals=[dict(arm=arm,bi=row[vir[cat]].mean()-row[own[sub][arm]].mean()) for (arm,pid,day),row in w.iterrows() if day=='d29']
    v=pd.DataFrame(vals); bsd=v.groupby('arm').bi.std(); bn=v.groupby('arm').bi.count()
    sdp=np.sqrt(((bn-1)*bsd**2).sum()/(bn.sum()-2)); se=sdp*np.sqrt(2/229)
    za=stats.norm.ppf(1-0.0125/2); zb=stats.norm.ppf(0.9)
    rows.append(dict(subtype=sub,pooled_sd_log2_breadth_index=sdp,n_per_arm=229,true_ratio_detectable_90pct=2**((za+zb)*se)))
B=pd.DataFrame(rows); print(B.round(3).to_string()); B.to_csv('/tmp/outputs/analysis/study1_breadth_index_power.csv',index=False)

# ---- smallest observed GMT ratio that yields a lower 95% bound > 1.0 at 229 evaluable/arm (alpha 0.0125 two-sided)
rows=[]
for lab,sd in sds.items():
    se=sd*np.sqrt(2/229); z=stats.norm.ppf(1-0.0125/2)
    rows.append(dict(subtype=lab,n_per_arm=229,min_observed_ratio_for_LB_gt_1=2**(z*se)))
M=pd.DataFrame(rows); print(M.round(3).to_string()); M.to_csv('/tmp/outputs/analysis/study1_min_observed_ratio.csv',index=False)
