"""
Variance estimates from WU397 to size the next randomised, strain-matched immunogenicity study.
Uses per-participant d29 log titres (seq-neut, averaged over contemporary strains of a subtype) and HAI wk4 titres.
Sample size per arm for a two-sided alpha=0.05 (or one-sided 0.025) comparison of GMTs:
  n = 2*(z_a + z_b)^2 * sd^2 / (log(ratio))^2
Also: NI on HAI GMT ratio (margin 1.5) and SCR difference (margin 10 points).
"""
import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width',250)
fs='/tmp/world/filesystem/'
n=pd.read_csv('/tmp/outputs/analysis/seqneut_annotated.csv')
pp=n[n.day.isin(['d0','d29'])].groupby(['arm','pid','cat','day']).log2t.mean().unstack('day')
pp['fold']=pp.d29-pp.d0
za=stats.norm.ppf(0.975)
rows=[]
for c in ['H1_2023_circulating','H3_2023-24_circulating']:
    g=pp.xs(c,level='cat')
    for metric in ['d29','fold']:
        # pooled within-arm SD (log2)
        sds=g.groupby(level='arm')[metric].std()
        ns=g.groupby(level='arm')[metric].count()
        sdp=np.sqrt(((ns-1)*sds**2).sum()/(ns.sum()-2))
        for ratio in [1.25,1.5,2.0]:
            for power in [0.8,0.9]:
                zb=stats.norm.ppf(power)
                nn=2*(za+zb)**2*sdp**2/(np.log2(ratio))**2
                rows.append(dict(category=c,metric=metric,pooled_sd_log2=sdp,target_GMT_ratio=ratio,power=power,n_per_arm=int(np.ceil(nn))))
R=pd.DataFrame(rows); print(R.round(3).to_string())
R.to_csv('/tmp/outputs/analysis/sample_size_heterologous_neut.csv',index=False)

# HAI SD and SCR
h=pd.read_csv(fs+'hai_titers.csv',dtype={'participant':str})
hw=h.pivot_table(index=['antigen','arm','participant'],columns='timepoint',values='hai_titer')
out=[]
for ag,g in hw.groupby(level=0):
    sds=g.groupby(level=1).wk4.apply(lambda x: np.log2(x.dropna()).std())
    ns=g.groupby(level=1).wk4.count()
    sdp=np.sqrt(((ns-1)*sds**2).sum()/(ns.sum()-2))
    # NI: upper bound of 95% CI of GMT ratio (comparator/test) <= 1.5, assume true ratio 1.0, power 90%
    zb=stats.norm.ppf(0.9)
    nn=2*(za+zb)**2*sdp**2/(np.log2(1.5))**2
    out.append(dict(antigen=ag,pooled_sd_log2_HAI_wk4=sdp,n_per_arm_NI_GMTratio_margin1p5_power90=int(np.ceil(nn))))
O=pd.DataFrame(out); print(O.round(3).to_string())
O.to_csv('/tmp/outputs/analysis/sample_size_HAI_NI.csv',index=False)
# SCR NI: margin 10 points, assumed SCR p (observed pooled), power 90%
scr=[]
for ag,p in [('A/H1N1',12/29),('A/H3N2',4/29),('B/Vic',1/28),('B/Yam',1/29)]:
    zb=stats.norm.ppf(0.9)
    nn=(za+zb)**2*2*p*(1-p)/0.10**2
    print(ag,'observed pooled SCR=%.2f'%p,' n/arm for SCR-difference NI (margin 10pp, 90%% power)=%d'%np.ceil(nn))
    scr.append(dict(antigen=ag,pooled_SCR=p,n_per_arm_SCR_NI_margin10pp_power90=int(np.ceil(nn))))
pd.DataFrame(scr).to_csv('/tmp/outputs/analysis/sample_size_SCR_NI.csv',index=False)
