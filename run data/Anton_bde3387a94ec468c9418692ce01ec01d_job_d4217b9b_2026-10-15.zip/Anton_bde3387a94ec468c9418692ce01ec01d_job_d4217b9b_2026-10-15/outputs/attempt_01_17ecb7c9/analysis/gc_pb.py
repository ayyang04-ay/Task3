"""
Lymph-node GC B-cell and plasmablast frequencies. gc_frequencies.csv contains two unlabelled blocks
(each participant x timepoint appears twice, rows 1-77 and 78-154); they are analysed separately as block A / block B.
"""
import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width',250); pd.set_option('display.max_rows',800)
fs='/tmp/world/filesystem/'
g=pd.read_csv(fs+'gc_frequencies.csv',dtype={'participant':str})
half=len(g)//2
g['block']=['A']*half+['B']*(len(g)-half)
assert (g.iloc[:half][['timepoint','arm','participant']].values==g.iloc[half:][['timepoint','arm','participant']].values).all()
print('GC rows',len(g),'; identical key order in both halves -> two unlabelled measurement blocks')
rows=[]
for (blk,tp),gg in g.groupby(['block','timepoint']):
    a=gg[gg.arm=='mRNA-1010'].pct_ha_specific_igg_gc; f=gg[gg.arm=='Fluarix'].pct_ha_specific_igg_gc
    rows.append(dict(block=blk,timepoint=tp,n_mRNA=len(a),median_mRNA=a.median(),n_Flu=len(f),median_Flu=f.median(),MWU_p=stats.mannwhitneyu(a,f).pvalue))
R=pd.DataFrame(rows); R['tp']=R.timepoint.str[2:].astype(int); R=R.sort_values(['block','tp']).drop(columns='tp')
print(R.round(3).to_string()); R.to_csv('/tmp/outputs/analysis/gc_summary.csv',index=False)
# per-participant peak (block A) post-baseline
gA=g[g.block=='A']; post=gA[gA.timepoint!='wk0']
pk=post.groupby(['arm','participant']).pct_ha_specific_igg_gc.max()
print('Block A peak post-baseline per participant:'); print(pk.round(2).to_string())
late=gA[gA.timepoint.isin(['wk17','wk26'])].groupby(['arm','participant']).pct_ha_specific_igg_gc.max()
print('Block A wk17/26 max:'); print(late.round(2).to_string())
print('MWU peak p=%.3g ; late p=%.3g'%(stats.mannwhitneyu(pk['mRNA-1010'],pk['Fluarix']).pvalue, stats.mannwhitneyu(late['mRNA-1010'],late['Fluarix']).pvalue))
p=pd.read_csv(fs+'plasmablast_frequencies.csv',dtype={'participant':str})
rows=[]
for tp,gg in p.groupby('timepoint'):
    a=gg[gg.arm=='mRNA-1010'].pct_plasmablast; f=gg[gg.arm=='Fluarix'].pct_plasmablast
    rows.append(dict(timepoint=tp,n_mRNA=len(a),median_mRNA=a.median(),n_Flu=len(f),median_Flu=f.median(),MWU_p=stats.mannwhitneyu(a,f).pvalue))
R2=pd.DataFrame(rows); R2['tp']=R2.timepoint.str[2:].astype(int); R2=R2.sort_values('tp').drop(columns='tp')
print(R2.round(4).to_string()); R2.to_csv('/tmp/outputs/analysis/pb_summary.csv',index=False)
print('PB participants: mRNA',sorted(p[p.arm=="mRNA-1010"].participant.unique()),' Flu',sorted(p[p.arm=="Fluarix"].participant.unique()))
print('GC participants: mRNA',sorted(g[g.arm=="mRNA-1010"].participant.unique()),' Flu',sorted(g[g.arm=="Fluarix"].participant.unique()))
