"""Serum IgG repertoire files (no participant IDs -> unpaired, arm-level only)."""
import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width',250)
fs='/tmp/world/filesystem/'
r=pd.read_csv(fs+'repertoire_clonotype_counts.csv')
out=[]
for met,g in r.groupby('metric'):
    a=g[g.arm=='mRNA-1010'].value; f=g[g.arm=='Fluarix'].value
    out.append(dict(file='repertoire_clonotype_counts',metric=met,n_mRNA=len(a),mean_mRNA=a.mean(),median_mRNA=a.median(),n_Flu=len(f),mean_Flu=f.mean(),median_Flu=f.median(),MWU_p=stats.mannwhitneyu(a,f).pvalue))
s=pd.read_csv(fs+'serum_igg_clonotypes.csv')
for tp,g in s.groupby('timepoint'):
    a=g[g.arm=='mRNA-1010'].n_clonotypes; f=g[g.arm=='Fluarix'].n_clonotypes
    out.append(dict(file='serum_igg_clonotypes',metric=f'n_clonotypes_{tp}',n_mRNA=len(a),mean_mRNA=a.mean(),median_mRNA=a.median(),n_Flu=len(f),mean_Flu=f.mean(),median_Flu=f.median(),MWU_p=stats.mannwhitneyu(a,f).pvalue if len(a)>1 and len(f)>1 else np.nan))
c=pd.read_csv(fs+'cdrh3_diversity_index.csv')
for tp,g in c.groupby('timepoint'):
    a=g[g.arm=='mRNA-1010'].diversity_index; f=g[g.arm=='Fluarix'].diversity_index
    out.append(dict(file='cdrh3_diversity_index',metric=f'diversity_{tp}',n_mRNA=len(a),mean_mRNA=a.mean(),median_mRNA=a.median(),n_Flu=len(f),mean_Flu=f.mean(),median_Flu=f.median(),MWU_p=stats.mannwhitneyu(a,f).pvalue if len(a)>1 and len(f)>1 else np.nan))
O=pd.DataFrame(out); print(O.round(3).to_string()); O.to_csv('/tmp/outputs/analysis/repertoire_summary.csv',index=False)
# consistency: n_pre_existing_clonotypes equals wk0 n_clonotypes (same order)?
pre=r[r.metric=='n_pre_existing_clonotypes']
for arm in ['mRNA-1010','Fluarix']:
    print(arm,'pre-existing list ',pre[pre.arm==arm].value.tolist())
    print(arm,'wk0 n_clonotypes ',s[(s.arm==arm)&(s.timepoint=='wk0')].n_clonotypes.tolist())
    ve=r[(r.metric=='n_vaccine_elicited_clonotypes')&(r.arm==arm)].value.values
    w4=s[(s.arm==arm)&(s.timepoint=='wk4')].n_clonotypes.values
    print(arm,'wk4 n_clonotypes ',w4.tolist(),' vaccine-elicited',ve.tolist())
