**Recommendation:** Don't take a heterologous-protection claim forward on WU397; instead put to the committee a randomised, observer-blind, strain-matched trivalent immunogenicity study (mRNA vs a recombinant-HA vaccine with the same HA sequences vs egg-based IIV3), gated on neutralisation of prespecified drifted strains, followed — only if it passes — by a multi-season randomised relative-efficacy trial whose claim endpoint is RT-PCR-confirmed influenza caused by antigenically mismatched strains, with a nested correlates sub-study.

*Why, in one breath:* WU397's arms received different H1 antigens and weren't randomised, and the mRNA arm's 3–10× higher H3N2 binding came with no neutralising or HAI advantage against current H3N2 strains. The protocol that goes to committee now is **Study 1** (Section 3). **Study 0** (closing out WU397's data gaps) should run alongside it and finish before the committee meets.

---

## 0. Summary for the committee

- **What WU397 shows.** Compared with Fluarix, mRNA-1010 produced:
  - more binding antibody. The week-4 ELISA IgG fold-rise was 2.7× higher for H1 and 3.8× higher for H3 (n = 38 mRNA / 37 Fluarix).
  - larger and longer-lasting germinal-centre (GC) responses in the draining lymph node. The median post-baseline peak was 24.7% vs 4.7% HA-specific GC B cells (n = 6 / 11).

  Both findings are real, but they are mechanistic. They are not evidence of protection.
- **What WU397 doesn't show: functional breadth.**
  - **HAI**, the only accepted correlate, shows no detectable difference. The H3N2 week-4 GMT ratio (mRNA/Fluarix) was 0.97, and the H1N1 ratio was 1.57 (95% CI 0.92–2.70).
  - **Neutralisation of 64 contemporary (2023–24) H3N2 viruses:** the day-29 GMT ratio was 0.86 (0.44–1.68).
  - **mRNA-1010's own H3 antigen (A/Darwin/6/2021):** the mRNA arm's neutralising GMT was half of Fluarix's (0.51; 0.27–0.95).
  - **Same H3 strains, same participants:** the mRNA binding advantage exceeded its neutralising advantage by 1.9–13× (p ≤ 0.013 for all 6 strains). Most of the extra H3 antibody binds without neutralising.
  - **H1:** the mRNA arm had about 2× higher neutralisation against every H1 virus tested, from 2009 to 2023. That is magnitude, not breadth: the ratio of drifted-strain titre to own-vaccine-strain titre was 0.48 vs 0.51. The advantage had disappeared by week 17/26 (GMT 207 vs 196).
- **Even those differences can't be attributed to the mRNA platform.** The reasons are:
  - the arms received different H1 strains (A/Victoria/4897/2022 vs Fluarix 2022–23's A/Victoria/2570/2019);
  - the H3 strains differ too (cell-like vs egg-derived Darwin);
  - allocation was by site, and baselines are imbalanced;
  - the study was open-label;
  - "homologous" is defined only relative to the mRNA antigens;
  - functional assays had only 13–15 participants per arm;
  - there is no protection endpoint.
- **What comes next.**
  - **Study 1:** make the HA identical across arms, randomise, and make functional neutralisation of prespecified drifted strains the primary endpoint. Go trivalent, because B/Yamagata has been removed from vaccines.
  - **Study 2:** a claim of heterologous **protection** needs a clinical endpoint, with sequenced, antigenically classified cases. Run it only if Study 1 passes.
  - **Study 0:** fix the data package first; Section 4 lists the issues.

![binding vs function](forest_binding_vs_function.png)

*Figure: mRNA-1010/Fluarix ratios with 95% CIs (`/tmp/outputs/forest_binding_vs_function.png`). Blue = binding readouts; red = functional readouts.*

---

## 1. What the data package shows

**Table A. Binding vs functional readouts (mRNA-1010 vs Fluarix)**

Source codes are listed in Section 6. Ratios are mRNA/Fluarix with 95% Welch CIs on the log scale.

| Readout (n mRNA/Fluarix) | mRNA-1010 | Fluarix | Ratio (95% CI) | Source |
|---|---|---|---|---|
| ELISA IgG A/H3, wk4 GM fold-rise (38/37) | 7.60 | 1.99 | 3.82 (2.65–5.49) | [ELISA] |
| ELISA IgG A/H1, wk4 GM fold-rise (38/37) | 5.07 | 1.90 | 2.67 (1.94–3.68) | [ELISA] |
| ELISA ≥4-fold rise, H3 / H1 | 27/38; 22/38 | 5/37; 3/37 | — | [ELISA] |
| Bead array, H3 A/Darwin/6/2021 fold-rise (14/15) | 26.2 | 4.29 | 6.10 (2.20–16.9) | [BEAD] |
| Bead array, H3 A/Thailand/8/2022 fold-rise | 31.9 | 3.37 | 9.45 (3.19–28.0) | [BEAD] |
| Bead array, all 12 H3 strains (1968–2022), ratio range | — | — | 3.1–10.1 (all p < 0.003) | [BEAD] |
| Bead array, all 9 H1 strains, ratio range | — | — | 1.26–2.70 | [BEAD] |
| **HAI A/H3N2, wk4 GMT (14/15)** | 56.4 | 57.9 | **0.97 (0.46–2.06)** | [HAI] |
| HAI A/H3N2 seroconversion | 2/14 (14%) | 2/15 (13%) | — | [HAI] |
| HAI A/H1N1, wk4 GMT | 138.0 | 87.7 | 1.57 (0.92–2.70) | [HAI] |
| HAI A/H1N1 seroconversion | 7/14 (50%) | 5/15 (33%) | — | [HAI] |
| HAI B/Vic, wk4 GMT; seroconversion | 56.5; 0/13 | 51.6; 1/15 | 1.09 (0.62–1.92) | [HAI] |
| HAI B/Yam, wk4 GMT; seroconversion | 88.3; 0/14 | 98.6; 1/15 | 0.90 (0.57–1.41) | [HAI] |
| MN "homologous", wk4 GMT (14/15) | 325 | 588 | 0.55 (0.22–1.40) | [MN] |
| MN "heterologous", wk4 GMT | 235 | 368 | 0.64 (0.24–1.70) | [MN] |
| **Neut, 64 H3N2 2023–24 viruses, d29 GMT (13/14)** | 397 | 459 | **0.86 (0.44–1.68)** | [SEQ] |
| Same, baseline-adjusted (ANCOVA) | — | — | 1.18 (0.65–2.13) | [SEQ] |
| Same, d29 fold-rise | 2.81 | 2.15 | 1.31 (0.75–2.30) | [SEQ] |
| **Neut, A/Darwin/6/2021 (mRNA H3 antigen), d29 GMT** | 244 | 482 | **0.51 (0.27–0.95)** | [SEQ] |
| Neut, A/Thailand/8/2022: d29 GMT; fold-rise | 480; 2.58 | 695; 2.91 | fold-rise 0.89 (0.38–2.07) | [SEQ] |
| Neut, 13 historical H3 viruses, d29 fold-rise | 3.20 | 1.68 | 1.90 (1.08–3.35) | [SEQ] |
| Neut, 6 H1N1 2023 viruses, d29 GMT | 478 | 257 | 1.86 (0.75–4.62); ANCOVA 2.06 (1.23–3.46) | [SEQ] |
| Neut, H1N1 2023 viruses, late visit (d121 or d181) GMT | 207 | 196 | — | [SEQ] |
| Neut, H3N2 2023–24 viruses, late visit GMT | 253 | 309 | — | [SEQ] |

**Key interpretive findings**

1. **For H3N2, binding and function come apart.**
   - **Same strain, same people:** for all six H3 strains present in both the bead-array and neutralisation panels, the binding advantage was larger than the neutralising advantage. The ratio of ratios was 1.9–13.4 (p = 1×10⁻⁵ to 0.013).
     - A/Darwin/6/2021: binding 7.2× vs neutralisation 0.82×.
     - A/Thailand/8/2022: binding 11.9× vs neutralisation 0.89×.
   - **For H1 the two agree:** the ratio of ratios was 0.87–1.42 (p ≥ 0.24) [BEAD + SEQ].
   - **Within the mRNA arm, H3 binding rise doesn't predict neutralising rise:**
     - bead Darwin/6 vs neutralisation of 2023–24 H3: ρ = 0.24 (p = 0.44) in the mRNA arm, vs ρ = 0.70 (p = 0.005) in the Fluarix arm;
     - ELISA H3 vs the same neutralisation: ρ = 0.31 in the mRNA arm vs 0.75 in the Fluarix arm.
   - **Likely explanation:** the extra H3 antibody is mostly non-neutralising. It includes conserved-epitope binders: the mRNA arm's bead fold-rise to A/Hong Kong/1/1968 was 10.9× vs 1.15× for Fluarix, and 11.3% of mRNA H3-panel mAbs bound H7 vs 0% of Fluarix mAbs.
   - Such antibodies may or may not protect (for example through Fc-mediated mechanisms). That is a hypothesis to test, not a basis for a claim.
2. **The H3 breadth that does show up functionally points backward, not forward.**
   - mRNA post-vaccination neutralising GMT was higher on 11/13 historical H3 viruses (median ratio 1.25).
   - It was higher on only 9/64 contemporary 2023–24 viruses (median ratio 0.86; range 0.66–1.09) [SEQ].
   - Protection against future drift needs forward breadth.
3. **The H1 advantage is magnitude, not breadth, and it is short-lived.**
   - The fold-rise ratio was about 1.8–2.6× across historical, vaccine-like and 2023 H1 viruses alike.
   - The breadth index (ratio of drifted-strain titre to own-vaccine-strain titre at d29) was 0.480 vs 0.508 (ratio 0.95, p = 0.45).
   - Titres converged by week 17/26 (207 vs 196) [SEQ].
4. **Fold-rise overstates mRNA gains because the arms didn't start level.**
   - The mRNA arm started lower:
     - baseline neutralising GMT to 2023–24 H3N2: 141 vs 214 (ratio 0.66, 0.40–1.10) [SEQ];
     - MN "heterologous" baseline: 57 vs 121 (0.47, 0.22–1.00, p = 0.050) [MN].
   - This is what site-based allocation produces. Post-vaccination titres adjusted for baseline (ANCOVA) are the right metric.
5. **Mechanistic readouts favour mRNA but are small and recall-dominated.**
   - **GC B cells (block A):**
     - labelled week 2: median 24.2% vs 2.3% (p = 0.037);
     - week 17 / week 26: 16.0 / 18.9% vs 2.3 / 1.6% (n = 6 / 11) [GC].
   - **GC responses are seeded mainly by recalled clones:** 73–92% of GC clones in the four mRNA donors were shared with week-1 plasmablast clones [OVL].
   - **Serum anti-HA IgG is mostly pre-existing clonotypes:** these made up 83.9% vs 86.2% of post-vaccination abundance; the mRNA arm had more vaccine-elicited clonotypes (32.0 vs 20.1, p = 0.066; n = 8/8, unpaired) [REP].
   - Plasmablast frequencies didn't differ (p = 0.10–0.45) [PB].
   - **The mAb comparison is unbalanced:** 589 mAbs from 4 mRNA donors vs 106 from 3 Fluarix donors, and one Fluarix donor contributed 84 of the 106 [MAB].
     - On a per-donor basis, mRNA-donor H3-panel mAbs bound all six H3 strains from 1968–2023 more often: 44.5% (28–65%) vs 5.3% (0–16%).
     - H1-panel breadth didn't differ: 6.3% vs 1.6% bound all six strains; mean 3.6 vs 3.5 strains bound.
     - These are binding data only.

---

## 2. Why the current design can't carry the claim, and what the next design has to fix

| # | Problem in WU397 | Evidence | Consequence for next study |
|---|---|---|---|
| 1 | **The arms received different HA antigens.** mRNA-1010 H1 = A/Victoria/4897/2022 [TS]. Fluarix 2022–23 H1 = A/Victoria/2570/2019-like, egg-based [EXT-1]. A/Victoria/4897/2022 is the H1 WHO chose for 2023–24 because of drift [EXT-3]. H3: the mRNA antigen is cell-like A/Darwin/6/2021; Fluarix used egg-based A/Darwin/9/2021 [TS, EXT-1]. | The trial summary says "homologous/heterologous" designations refer *only* to the mRNA antigens [TS]. Any "homologous" comparison is therefore homologous only for mRNA recipients; for H1 it is a drifted strain for Fluarix recipients. | **Strain-match the arms.** The mRNA must encode exactly the HA sequences in the comparator. If the sponsor wants to test its own strain choice, that needs a separate arm. |
| 1b | **The documented composition may be wrong; verify it.** | Twelve of 13 mRNA recipients had a larger neutralising rise to A/Wisconsin/588/2019 (5a.2) than to A/Wisconsin/67/2022, the cell equivalent of A/Victoria/4897/2022: 1.75×, p = 0.003. In Fluarix recipients, who did receive a 5a.2 H1, the skew was only 1.38× (p = 0.36) [SEQ]. In all 4 mRNA donors, mAbs bound A/Wisconsin/588/2019 about 4× more strongly than A/Victoria/4897/2022 (median 212 vs 49 fold over control; selection probe undocumented) [MAB]. | This could be recall of prior 5a.2 immunity, or the antigen list could be wrong. Confirm the encoded H1 against the clinical-lot batch record. The conclusions above hold either way, because the H1 gain is uniform across strains and transient. |
| 2 | **Non-randomised allocation by site; open-label** [TS]. | Baseline imbalance (item 4 in Section 1); the ELISA extension cohort was enrolled in arm-blocked ID ranges: 033–059 all Fluarix, 064–102 all mRNA [ELISA]; the package has no demographics, prior-vaccination history, site or enrolment dates, so nothing can be adjusted for. | Randomise within site, with stratification; enrol all arms in the same calendar window; use observer-blind conduct and arm-blinded laboratory testing. |
| 3 | **Egg vs non-egg is confounded with platform.** | Fluarix is egg-derived; egg-derived or production-reassortant viruses were neutralised 1.4–6.8× more than their wild-type counterparts by both arms [SEQ]; MN virus identity isn't documented, but the MN titres track egg A/Darwin/9/2021 (ρ = 0.70) more than A/Darwin/6/2021 (ρ = 0.50) [MN + SEQ]. | Add a **non-egg protein comparator with the same HA sequences (RIV3)** to isolate the platform effect; keep egg and reassortant viruses out of breadth metrics; name every assay virus. |
| 4 | **Binding used as a proxy for breadth.** | Section 1, finding 1. | Make functional readouts (neutralisation, HAI, NAI) primary. Keep binding exploratory. |
| 5 | **Backward vs forward breadth is mixed together.** | The bead-array panels are mostly historical strains (1934–2022). | Make contemporary and forward-drifted strains the endpoint. Report historical strains descriptively. |
| 6 | **No protection endpoint.** HAI is a correlate only for matched strains. | — | Heterologous protection needs clinical efficacy against antigenically characterised mismatched strains (Study 2). |
| 7 | **Quadrivalent with B/Yamagata.** | No B/Yam circulation since 2020, and vaccines have moved to trivalent [EXT-4]. WU397 showed no B advantage (HAI seroconversion 0–1 per arm) [HAI]. | Go trivalent (H1N1, H3N2, B/Victoria). Include drifted B/Victoria strains in the neutralisation panel; WU397 had none. |
| 8 | **Small n, pooled late visits, assay ceiling.** | HAI/MN n = 14/15; "wk17/26" is pooled from different visits across assays; MN had a 1280 upper limit: 9/15 Fluarix and 4/14 mRNA homologous titres were at that limit at week 4 [MN, TS]. | Size Study 1 from WU397's variances (Section 3); use fixed visit windows with no pooling; require a reportable range that covers post-vaccination titres, with prespecified handling of censored values. |
| 9 | **Neuraminidase not measured.** The mRNA lists one antigen per strain; IIV contains NA. | — | Measure NAI in every arm. RIV3 is also NA-free, so it is NA-matched to an HA-only mRNA. |

---

## 3. Recommended studies

### Study 0: Close out WU397 before the committee (no new enrolment; weeks, not months)

- **Purpose.** Resolve the questions that change how WU397 is read, and produce planning parameters for Study 1. It can't rescue the claim, because it doesn't fix allocation.
- **Specification**
  1. Confirm from the batch record which HA sequences the mRNA-1010 clinical lot encoded (item 1b in Section 2). Also confirm the Fluarix lot's labelled composition.
  2. Blinded to arm, measure existing sera from both arms (days 0, 29 and 181) against each arm's **actual** vaccine strains:
     - the Fluarix 2022–23 H1 (A/Victoria/2570/2019-like) and its cell equivalent A/Wisconsin/588/2019;
     - egg A/Darwin/9/2021 and cell A/Darwin/6/2021;
     - the mRNA strains.

     Measure both HAI and neutralisation. This gives each arm its own homologous reference and a symmetric breadth index.
  3. Neuraminidase-inhibition (NAI) titres against N1 and N2 in both arms.
  4. Neutralisation against drifted B/Victoria viruses.
  5. Retrieve and tabulate by arm: age, sex, site, enrolment date, and prior-season vaccination and infection history. Re-run the analyses adjusted for baseline and covariates.
  6. Fix the data-package issues in Section 4.

### Study 1: Randomised, observer-blind, strain-matched immunogenicity study (Phase 2; decision gate)

- **Question it answers.** When the HA antigen is identical, does the mRNA platform give broader *functional* antibody against drifted strains than protein vaccines — breadth, not just magnitude — and does that breadth last through a season?

**Conditions**

- **Population ("in whom")**
  - Adults in the intended label population; the working assumption is ≥ 50 years.
  - Stratified 1:1 into 50–64 and ≥ 65 years.
  - Randomisation also stratified by prior-season influenza vaccination and by site.
  - Record birth year (imprinting cohort), vaccination history for the past 3–5 seasons, and prior confirmed influenza.
  - Exclude anyone vaccinated against influenza in the previous 6 months.
  - If the claim will include 18–49-year-olds, add that stratum.
- **Arms ("against what")**, randomised 1:1:1, with an optional fourth arm:

  | Arm | Product | Why it's there |
  |---|---|---|
  | A | **mRNA, trivalent.** HA sequences identical to that season's WHO cell/recombinant-recommended H1N1, H3N2 and B/Victoria strains. | Test product |
  | B | **RIV3 (recombinant HA)**, same season. Same HA sequences as Arm A; non-egg; HA-only, so no NA; preferentially recommended for ≥ 65 [EXT-5, EXT-6]. | **Primary comparator.** Isolates the platform from antigen choice, egg adaptation and NA. |
  | C | **Egg-based IIV3**, same season, age-appropriate: standard-dose (e.g. Fluarix trivalent) in 50–64; high-dose in ≥ 65. Its strains follow the WHO egg-based recommendation, which may name a different but antigenically equivalent isolate. | Standard-of-care anchor and continuity with WU397. Separates any egg-adaptation effect. |
  | D (optional) | mRNA encoding **sponsor-selected forward strain(s)**, as WU397 did for H1. | Include only if strain selection ahead of WHO is part of the product strategy. It estimates the strain-choice effect separately from the platform effect. |

- **Timing**
  - All arms are vaccinated in the same pre-season window.
  - Sampling on day 0, day 8 (cellular readouts only), day 29 (primary), day 91 and day 181.
  - Visit windows are fixed, and different visits are never pooled.
  - Active ILI surveillance with RT-PCR throughout, plus a serological marker of natural infection that neither vaccine induces. Participants with intercurrent infection are censored from durability analyses.
- **Virus panels.** All panels are locked in the SAP before unblinding. Only wild-type (non-egg-adapted) sequences are used, with one entry per strain; egg or production reassortants appear only as labelled references.
  - **Tier 0 (homologous):** the season's vaccine strains.
  - **Tier 1 (contemporary drifted):** H3N2, H1N1 and B/Victoria viruses circulating in the trial season and regions that are antigenically distinct from the shared vaccine strain. Strains are selected by clade frequency in surveillance data and weighted by that frequency.
  - **Tier 2 (forward drifted):** viruses that dominate the following season, plus that season's newly recommended strains. These are tested blind on banked sera after the season.
  - **Tier 3 (historical):** descriptive only.

**Readouts**

| Readout | Role | In whom | Against what | When |
|---|---|---|---|---|
| Neutralising antibody: frequency-weighted GMT over the Tier 1 panel, separately for H3N2 and H1N1 | **Primary.** Superiority of A vs B, then A vs C (hierarchical). | All randomised; per-protocol immunogenicity set, with ITT sensitivity analysis | Tier 1 | D29 (baseline-adjusted) |
| HAI GMT ratio and seroconversion-rate difference | **Co-primary (regulatory anchor).** Non-inferiority of A vs B and A vs C: GMT-ratio upper bound ≤ 1.5; SCR difference ≤ 10 percentage points [EXT-7]. | All | Tier 0 | D29 |
| **Breadth index:** per-participant ratio of Tier 1 to Tier 0 neutralising titre | Key secondary. Separates breadth from magnitude (WU397's H1 gain failed this test). | All | Tier 1 / Tier 0 | D29 |
| Neutralising GMT against forward-drifted strains | Key secondary. The closest immunological proxy for heterologous protection. | All (banked sera) | Tier 2 | D29, D181 |
| Durability of neutralising and HAI titres | Key secondary | All | Tiers 0–2 | D91, D181 |
| Neuraminidase-inhibition titres | Secondary | All | N1 and N2 of the vaccine strains, plus drifted NAs | D0, D29, D181 |
| HAI against drifted strains | Secondary | All | Tier 1 H1N1 and B/Victoria (and H3N2 where informative) | D29 |
| Seroconversion (≥ 4-fold) per strain; proportion of participants above a prespecified titre against ≥ X% of the panel | Secondary | All | Tier 1 | D29 |
| Binding IgG to HA head and stem, and binding breadth | **Exploratory only.** Not evidence of breadth, because of WU397's binding/function gap. | All | Tiers 0–3 | D0, D29, D181 |
| Fc-effector function of serum | Exploratory. Tests whether the non-neutralising breadth could matter. | Random subset, about 50 per arm | Tier 1 H3N2 | D29 |
| Historical-strain neutralisation | Descriptive (back-boosting) | Subset | Tier 3 | D0, D29 |
| Plasmablasts and memory B cells (blood); lymph-node GC sub-study; T cells | Exploratory. Prespecified, randomised and balanced sub-study (≥ 15 per arm); every antigen probe labelled. | Sub-study | Tier 0/1 antigens | D8, D29; lymph node at wk 2, 8, 26 |
| Safety: solicited reactions for 7 days, unsolicited AEs for 28 days, SAEs and AESIs (incl. myocarditis/pericarditis) to D181 | Primary safety | All | — | As stated |

**Endpoint definitions (for the SAP)**

- **Frequency-weighted Tier 1 GMT.** For each participant, take the weighted geometric mean titre over the Tier 1 strains, with weights equal to each strain's (clade's) share of surveillance sequences in the trial season and regions. Then compute the GMT across participants. Weights are fixed before unblinding.
- **Breadth index.** Per participant: Tier 1 titre ÷ Tier 0 (shared vaccine strain) titre, at D29. Compare as a ratio of geometric means between arms.
- **HAI seroconversion.** Pre-vaccination titre < 1:10 and post ≥ 1:40, or ≥ 4-fold rise [EXT-7].
- **"Antigenically distinct" (Tier 1/2 eligibility).** Prespecified, for example: ≥ 8-fold lower titre than the homologous titre with post-infection reference antiserum raised against the vaccine strain (the conventional "low-reactor" criterion [EXT-8]), or membership of a clade with a prespecified antigenic-site change.

**Analysis rules**

- ANCOVA on log titre, adjusted for baseline titre, age stratum, prior vaccination and site.
- Censored titres are modelled as censored values, not imputed at the limit.
- Fixed-sequence multiplicity: H3N2 → H1N1 → B/Victoria; vs RIV3 before vs egg IIV3.
- The laboratory is blinded to arm.

**Sample size** (from WU397 variances: per-participant panel-mean log₂ d29 neutralising titre SD was 1.65 for H1N1 and 1.22 for H3N2 [SEQ])

- To detect a 1.5-fold GMT ratio with 90% power at two-sided α = 0.0125 per test (Bonferroni over 4 tests) needs:
  - H1N1: 229 evaluable per arm, or about **270 enrolled per arm** allowing 15% attrition;
  - H3N2: 125 evaluable, or 146 enrolled.
- At about 270 per arm, non-inferiority on the HAI GMT ratio is also adequately powered (needs 66–118 per arm).
- Non-inferiority on the seroconversion-rate difference needs about 510 per arm (at WU397's pooled H1 seroconversion rate of 41%). If Study 1 must also serve as the formal HAI non-inferiority study, enrol about 600 per arm.

**Optional extension.** Revaccinate in season 2 with that season's updated composition. This tests whether breadth holds up under repeated annual mRNA vaccination, which is how the product will be used.

**Go / no-go (prespecify in the SAP)**

- **GO to Study 2 with a heterologous claim** only if all of the following hold:
  - Arm A vs B Tier 1 GMT ratio has a multiplicity-adjusted lower 95% bound > 1.0, for H3N2 and/or H1N1. At the planned size, this has 90% power when the true ratio is 1.5, and it can only be met if the observed ratio is at least about 1.2–1.3;
  - the breadth-index ratio has a lower bound > 1.0 (breadth, not just magnitude). At 229 per arm this has 90% power for a true ratio of 1.17 (H1N1) to 1.37 (H3N2), using WU397 SDs;
  - the Tier 1 advantage still has a lower bound > 1.0 at D181;
  - HAI non-inferiority is met vs both comparators.
- **If A beats C but not B:** the gain comes from non-egg antigen, not from mRNA. A platform-specific heterologous claim is not supported; reframe it.
- **If titres are higher but the breadth index is equal:** pursue overall relative efficacy only, and make the heterologous endpoint descriptive.
- **If there is no functional advantage vs B:** stop the heterologous claim and revisit antigen design (for example NA content, or H3 immunogen quality given the non-neutralising H3 response).

### Study 2: Randomised, observer-blind, active-comparator relative-efficacy trial with antigenic characterisation of cases (Phase 3; claim-enabling)

**Conditions**

- **Population:**
  - community-dwelling adults ≥ 50 years, stratified 50–64 / ≥ 65, with meaningful enrolment of ≥ 75-year-olds;
  - randomised 1:1, stratified by age, prior-season vaccination and region;
  - **at least 2 seasons and both hemispheres.** Mismatched seasons can't be scheduled, so mismatched-strain cases must accrue across seasons.
- **Arms:**
  - **Test:** strain-matched trivalent mRNA, with that season's WHO strains.
  - **Comparator:** a licensed, same-season vaccine with the same strains, appropriate to age. For ≥ 65 it must be preferentially recommended (RIV3, HD-IIV3 or aIIV3) [EXT-6].
  - RIV3 across all ages is the strongest comparator if Study 1 showed superiority over it.
- **Case definition and classification:**
  - RT-PCR-confirmed, protocol-defined ILI, from ≥ 14 days after vaccination to the end of the season.
  - Every case isolate is sequenced and classified as matched or antigenically mismatched to the vaccine strain, using an algorithm locked before unblinding: clade plus antigenic characterisation against vaccine-strain reference antisera. Use the same "antigenically distinct" definition as Study 1.
  - Classification is done by an independent committee blinded to arm. Unclassifiable cases are handled by prespecified rules.

**Readouts**

| Readout | Role | In whom | Against what | When |
|---|---|---|---|---|
| RT-PCR-confirmed ILI, any influenza A or B | **Primary.** Relative vaccine efficacy (rVE): non-inferiority (lower bound > −10%), then superiority (lower bound > 0). | All randomised; per-protocol, with ITT sensitivity analysis | Comparator arm | Season-long active surveillance |
| **RT-PCR-confirmed ILI caused by antigenically mismatched strains** | **Key secondary = the claim endpoint.** rVE superiority, placed in the hierarchy. | All | Comparator arm | Same |
| Matched-strain ILI; subtype-specific rVE (H3N2, H1N1, B/Victoria) | Secondary | All | Comparator | Same |
| Influenza-associated hospitalisation, pneumonia and medically attended illness | Secondary | All | Comparator | Same |
| rVE by time since vaccination (early vs late season) | Secondary (durability of protection) | All | Comparator | Same |
| **Correlates sub-study:** HAI (vaccine strains); neutralisation (vaccine strains, the season's circulating clades and each case's infecting strain); NAI; binding (exploratory) | Correlates of risk for matched and mismatched infection. Basis for future immunobridging when strains change. | Case-cohort: random sub-cohort (about 5% of participants) plus all cases | Per season | D0, D29 |
| Safety: solicited (subset), unsolicited, SAEs, AESIs | Safety | All / subset | — | 7 days / 28 days / 6 months |

**Sizing** (event-driven; illustrative, using assumptions listed in Section 7)

- **Overall rVE:** a true rVE of 25% needs **511 cases** for superiority at 90% power (one-sided α 0.025), or 287 cases for non-inferiority (−10% margin).
  - At comparator attack rates of 2.5% and 1.5%, that is about 23,400 and 38,900 participants per season for the superiority case.
- **Mismatched-strain endpoint:** needs 383 mismatched cases for 80% power at rVE 25%. If 30–50% of cases are mismatched, that means about 770–1,280 total cases. This is why the trial has to run across multiple seasons and hemispheres.

### Study 3 (optional, can run alongside Study 1): heterologous-challenge human infection study

- **Design and population**
  - Randomised, double-blind, three arms: strain-matched mRNA, RIV3 (or IIV3) and placebo.
  - Healthy adults aged 18–50 with low pre-existing antibody to the challenge virus (prespecified threshold).
  - Challenge 4–8 weeks after vaccination with an existing GMP challenge virus of the same subtype (H3N2 preferred), at a prespecified antigenic distance from the vaccine strain.
- **Readouts**
  - **Primary:** laboratory-confirmed symptomatic infection.
  - **Secondary:** any infection; viral load and symptom-score AUC; seroconversion to the challenge virus.
  - **Correlates:** pre-challenge HAI, neutralisation and NAI against the challenge virus.
- **Size:** about 46–99 per arm for vaccine vs placebo, assuming placebo risk of 35–45% and efficacy of 50–60% at 80% power. The active-comparator contrast is descriptive.
- **Limits**
  - It is an early proof of heterologous protection, in young adults and against one strain.
  - It does not replace Study 2, and it can't support a label claim on its own.

### Carry forward from WU397 / drop

**Carry forward**
- the strategy of testing many contemporary strains (the 2023–24 neutralisation panel);
- the day-29 primary timepoint;
- the GC sub-study idea, but randomised and balanced.

**Drop**
- non-random allocation;
- strain-mismatched arms;
- "homologous" defined from one arm's perspective;
- binding-based breadth claims;
- egg reassortants as panel members;
- the B/Yamagata component;
- pooled 17/26-week visits;
- unlabelled datasets.

---

## 4. Data-package issues to fix before numbers go to the committee

All of these are checked programmatically in `analysis/data_integrity_checks.py`, with output in `analysis/data_integrity_issues.csv`.

1. **H1 composition:** the serology fits the documented antigen poorly (Section 2, item 1b). Verify it.
2. **`gc_frequencies.csv` contains two unlabelled measurement blocks.** Every participant × timepoint appears twice (156 rows), and 80% of the second block's Fluarix values are 0. An antigen or probe label is needed.
3. **GC timepoints don't match the schedule.** The file has wk0/2/8/17/26, but FNA was documented at weeks 1/2/4/8/17/26 with no week-0 FNA [TS].
4. **Plasmablast timepoints don't match either.** The file has wk0/2/8/17/26, but blood was drawn on days 0/7/29/121/181. The plasmablast cohort (13/15) also doesn't match the FNA cohort (6/11), so the tissue source is ambiguous.
5. **IgM cohort size:** the file holds 14/15 participants, not the documented 38/37.
   - The timepoint is not stated.
   - ID "20" isn't zero-padded.
   - Participant 005 has 166–212-fold IgM rises to all four antigens. The same donor supplies 84 of the 106 Fluarix mAbs.
6. **HAI B/Victoria visit labels are inconsistent.** Week-17 participants are 007/008/016/021 for B/Vic but 009/010/018/023 for every other antigen and assay. Participant 031 has no B/Vic data.
7. **Late-visit sera differ by assay.** The neutralisation data use day-121 sera for 397-007 and 397-011, who are week 26 in HAI/MN/ELISA. "wk17/26" therefore means different things in different files.
8. **Assay identities are undocumented:** the MN viruses, the HAI antigens, and the bead-array and IgM comparison timepoints.
9. **Virus names:**
   - typo "A/SOUTHAFRICA/R07876/**202023**";
   - A/Darwin/9/2021 is egg-derived but carries no egg/reassortant tag, unlike the other egg viruses.
10. **mAb data:**
    - The SARS-CoV-2 RBD value is the normaliser (= 1 for all 721 rows), so it is not an independent negative control.
    - 17 values are negative.
    - The mAb selection probe isn't documented.
11. **Unlinked and undocumented files:**
    - The repertoire, CDRH3 and serum-clonotype files have no participant IDs.
    - That sub-study is absent from the cohort table.
    - Six different participant-ID formats are used across files.
12. **Missing from the package:** no demographics, prior-vaccination, site or safety data.

---

## 5. Numbers relied on and where each came from

Every number quoted above is in `analysis/key_numbers.csv` (271 rows: value, source file, derivation script). The main ones:

| Quantity | Value | Source (derivation) |
|---|---|---|
| Cohort sizes, mRNA/Fluarix | ELISA/IgM 38/37; HAI 14/15; bead array and MN 14/15; sequencing-based neutralisation 13/14; FNA 6/11. | [TS]. Files match, except IgM (14/15 in file). |
| Antigens and allocation | mRNA-1010: A/Victoria/4897/2022, A/Darwin/6/2021, B/Austria/1359417/2021, B/Phuket/3073/2013; Fluarix "as licensed 2022–23"; non-randomised by site; open-label. | [TS] |
| ELISA wk4 GM fold-rise, mRNA/Fluarix | H1 5.07 / 1.90, ratio 2.67 (1.94–3.68); H3 7.60 / 1.99, ratio 3.82 (2.65–5.49); B/Vic 3.16 / 2.30; B/Yam 2.67 / 2.03. | [ELISA] (`gmt_ratio_cis.py`) |
| ELISA ≥ 4-fold rise | H1 22/38 vs 3/37; H3 27/38 vs 5/37 | [ELISA] (`key_numbers.py`) |
| ELISA wk17/26 fold-rise | H1 2.12 vs 1.40; H3 3.47 vs 1.52 | [ELISA] |
| ELISA wk4 fold-rise by enrolment cohort | Core cohort (IDs ≤ 032): H1 5.7 vs 2.5; H3 8.8 vs 2.3; extension: H1 4.8 vs 1.6; H3 7.0 vs 1.8. | [ELISA] (`supplementary_checks.py`) |
| ELISA wk4 GMT, baseline-adjusted | H1 2.66 (2.01–3.53); H3 3.31 (2.47–4.43) | [ELISA] (`ancova.py`) |
| HAI wk4 GMT, mRNA/Fluarix | H1N1 138.0 / 87.7 (1.57; 0.92–2.70); H3N2 56.4 / 57.9 (0.97; 0.46–2.06); B/Vic 56.5 / 51.6; B/Yam 88.3 / 98.6. | [HAI] (`gmt_ratio_cis.py`) |
| HAI, baseline-adjusted | H1N1 1.54 (0.87–2.71); H3N2 1.06 (0.67–1.65) | [HAI] (`ancova.py`) |
| HAI seroconversion, mRNA vs Fluarix | H1N1 7/14 vs 5/15; H3N2 2/14 vs 2/15; B/Vic 0/13 vs 1/15; B/Yam 0/14 vs 1/15 | [HAI] (`hai_scr.py`) |
| HAI ≥ 1:40 at wk4, H3N2 | 9/14 vs 13/15 | [HAI] |
| MN wk4 GMT, mRNA/Fluarix | homologous 325 / 588 (0.55; 0.22–1.40); heterologous 235 / 368 (0.64; 0.24–1.70). | [MN] |
| MN heterologous baseline GMT | 57 / 121 (0.47; 0.22–1.00) | [MN] |
| MN titres at the 1280 limit, wk4 homologous | 4/14 vs 9/15 | [MN] |
| Which virus MN titres track | Homologous: A/Darwin/9/2021 ρ = 0.70 vs A/Darwin/6/2021 ρ = 0.50; any H1 ρ ≤ 0.19; heterologous: A/Darwin/9/2021 ρ = 0.62. | [MN + SEQ] (`supplementary_checks.py`) |
| Neutralisation panel composition | 96 viruses: 13 H1N1 and 83 H3N2; 64 H3N2 from 2023–24; 6 labelled egg/reassortant viruses | [SEQ] (`seqneut_analysis.py`) |
| Neutralisation, H3N2 2023–24 viruses | d0 141 / 214 (0.66; 0.40–1.10); d29 397 / 459 (0.86; 0.44–1.68); fold-rise 2.81 / 2.15 (1.31; 0.75–2.30); ANCOVA 1.18 (0.65–2.13); mRNA d29 GMT higher on 9/64 viruses. | [SEQ] |
| Neutralisation, A/Darwin/6/2021 | d29 GMT 244 / 482 (0.51; 0.27–0.95); fold-rise 2.24 / 2.74 | [SEQ] |
| Neutralisation, A/Darwin/9/2021 | d29 GMT 1009 / 1539; fold-rise 4.78 / 4.49 | [SEQ] |
| Neutralisation, A/Thailand/8/2022 | d29 GMT 480 / 695; fold-rise 2.58 / 2.91 | [SEQ] |
| Neutralisation, historical H3 viruses | fold-rise 3.20 / 1.68 (1.90; 1.08–3.35); mRNA d29 GMT higher on 11/13 | [SEQ] |
| Neutralisation, H1N1 2023 viruses | d29 478 / 257 (1.86; 0.75–4.62); fold-rise 4.07 / 1.95 (2.09; 1.25–3.51); ANCOVA 2.06 (1.23–3.46). | [SEQ] |
| Neutralisation, H1 fold-rise ratio by strain group | historical 1.82; A/Wisconsin/588/2019 2.62; mRNA-antigen-like 1.83; 2023 viruses 2.09. | [SEQ] |
| H1 breadth index (drifted/own titre, d29) | 0.480 vs 0.508 (0.95; p = 0.45) | [SEQ] (`seqneut_breadth_normalised.py`) |
| Late-visit (d121/d181) neutralising GMT | H1N1 2023 207 / 196; H3N2 2023–24 253 / 309 | [SEQ] (`supplementary_checks.py`) |
| H1 skew toward A/Wisconsin/588/2019 vs A/Wisconsin/67/2022 | mRNA 1.75× (12/13, p = 0.003); Fluarix 1.38× (p = 0.36) | [SEQ] (`supplementary_checks.py`) |
| Egg/reassortant vs wild-type neutralising titre | 1.4–6.8× | [SEQ] (`egg_vs_wildtype_pairs.py`) |
| Bead-array fold-rise, mRNA/Fluarix | H3 Darwin/6 26.2 / 4.29; Thailand/8 31.9 / 3.37; HK/1/1968 10.9 / 1.15; H3 ratio range 3.1–10.1; H1 ratio range 1.26–2.70. | [BEAD] |
| Same-strain binding vs neutralisation (ratio of ratios) | H3: 1.9–13.4 (p ≤ 0.013); Darwin/6 7.19 vs 0.82; Thailand/8 11.88 vs 0.89. H1: 0.87–1.42 (p ≥ 0.24) | [BEAD + SEQ] (`binding_neut_dissociation.py`) |
| Binding vs neutralisation correlation, mRNA vs Fluarix | bead Darwin/6 vs 2023–24 H3 neutralisation: ρ 0.24 vs 0.70; ELISA H3 vs the same: ρ 0.31 vs 0.75. | [ELISA/BEAD/SEQ] (`binding_vs_function.py`) |
| GC B cells, block A | peak median 24.7% (16.0–38.7) vs 4.7% (0.2–19.2); labelled wk2: 24.2 vs 2.3 (p = 0.037); wk17: 16.0 vs 2.3; wk26: 18.9 vs 1.6. | [GC] (`gc_pb.py`) |
| Plasmablasts | no arm differences (p = 0.10–0.45) | [PB] |
| GC clones shared with wk1 plasmablasts | mRNA donors 92 / 91 / 83 / 73%; Fluarix 100% (7 clones), 20% (5), 0% (1). | [OVL] |
| mAbs | 589 from 4 mRNA donors vs 106 from 3 Fluarix donors (84 from donor 05); H3 panel, bind all 6 strains: 44.5% vs 5.3%; H7 binders 11.3% vs 0%; H1 panel, bind all 6: 6.3% vs 1.6%; mRNA-donor median binding A/Wisconsin/588/2019 212 vs A/Victoria/4897/2022 49. | [MAB] (`mab_panels.py`; binding call ≥ 5× over control) |
| IgM GM fold-change, mRNA/Fluarix | H1 2.11 / 3.99; H3 1.83 / 5.53; B/Vic 1.55 / 4.40; B/Yam 1.94 / 5.77 | [IGM] |
| Serum repertoire | pre-existing share of abundance 83.9% vs 86.2%; vaccine-elicited clonotypes 32.0 vs 20.1 (p = 0.066); CDRH3 diversity wk4 71.2 vs 24.9. | [REP] (`repertoire.py`) |
| Study 1 sizing inputs | SD log₂ d29 panel titre: H1N1 1.65; H3N2 1.22. HAI wk4 SD: H1 1.03; H3 1.38 | [SEQ], [HAI] (`variance_and_power.py`) |
| Study 1 sizing outputs | 1.5× ratio, 90% power, α 0.0125: H1N1 229 evaluable / 270 enrolled; H3N2 125 / 146; HAI GMT non-inferiority 66–118 per arm; seroconversion non-inferiority 510 per arm (about 600 enrolled); breadth-index SD 0.65 (H1) / 1.28 (H3), detectable true ratio 1.17 / 1.37 at 229 per arm. | (`study1_sizing.py`, `variance_and_power.py`) |
| Study 2 sizing | rVE 25%: 511 cases for superiority at 90% power; 287 for non-inferiority; 383 mismatched cases at 80% power; N ≈ 23,400–38,900 per season. | [ASSUMP] (`efficacy_events.py`) |
| Study 3 sizing | 46–99 per arm | [ASSUMP] (`efficacy_events.py`) |

## 6. Source codes

| Code | Source |
|---|---|
| TS | `trial_summary.md` |
| ELISA | `elisa_igg_titers.csv` |
| HAI | `hai_titers.csv` |
| MN | `microneutralization.csv` |
| SEQ | `neutralization_seqbased.csv` |
| BEAD | `binding_breadth_h1.csv`, `binding_breadth_h3.csv` |
| GC | `gc_frequencies.csv` |
| PB | `plasmablast_frequencies.csv` |
| OVL | `pb_gc_clonal_overlap.csv` |
| MAB | `mab_binding_panels.csv` |
| IGM | `igm_fold_change.csv` |
| REP | `repertoire_clonotype_counts.csv`, `serum_igg_clonotypes.csv`, `cdrh3_diversity_index.csv` |

All input files are in `/tmp/world/filesystem`.

**External reference facts (not in the package; please confirm against the cited documents before the committee)**

- **EXT-1.** WHO recommendation for Northern Hemisphere 2022–23 egg-based vaccines, which Fluarix followed: A/Victoria/2570/2019 (H1N1)pdm09-like; A/Darwin/9/2021 (H3N2)-like; B/Austria/1359417/2021-like; B/Phuket/3073/2013-like. Confirm against the Fluarix 2022–2023 prescribing information or lot documentation.
- **EXT-2.** WHO 2022–23 cell/recombinant-based recommendation: A/Wisconsin/588/2019 (H1N1)pdm09-like (clade 5a.2) and A/Darwin/6/2021 (H3N2)-like.
- **EXT-3.** WHO recommendation of February 2023 for 2023–24: the H1 was changed to A/Victoria/4897/2022 (egg) and A/Wisconsin/67/2022 (cell), both clade 5a.2a.1, because of antigenic drift.
- **EXT-4.** B/Yamagata has not been confirmed in circulation since 2020. WHO advised removing the B/Yamagata component (2023), and US/NH vaccines moved to trivalent from 2024–25.
- **EXT-5.** RIV (recombinant HA) contains 45 µg HA per strain and no NA. It is produced without eggs and uses the cell/recombinant strain recommendation.
- **EXT-6.** ACIP, since 2022–23: for adults ≥ 65 years, high-dose IIV, RIV or adjuvanted IIV is preferentially recommended.
- **EXT-7.** FDA 2007 guidance on licensure data for seasonal inactivated influenza vaccines:
  - HAI seroconversion definition;
  - non-inferiority to a licensed comparator: upper 95% bound of the GMT ratio (comparator/new) ≤ 1.5, and of the seroconversion-rate difference ≤ 10 percentage points;
  - accelerated-approval thresholds, for adults < 65: seroconversion lower bound ≥ 40% and lower bound of % with HAI ≥ 1:40 ≥ 70%.
- **EXT-8.** WHO Collaborating Centre antigenic-characterisation convention: a virus whose HI titre with post-infection ferret antiserum is ≥ 8-fold below the homologous titre is treated as antigenically distinct (a "low reactor").

## 7. Assumptions (not from the data)

- **Scope of the claim.** "Heterologous protection" means protection against antigenically drifted strains within the seasonal subtypes. A heterosubtypic claim (e.g. H5/H7) would need a different programme. WU397's H5/H7 binding data don't support one.
- **Population.** The target label population is adults ≥ 50 years; adjust the strata if it isn't.
- **Study 2 planning inputs:**
  - comparator attack rate 1.5–2.5% per season;
  - true rVE 25% (range shown: 15–30%);
  - 30–50% of cases caused by mismatched strains;
  - rVE non-inferiority margin −10%, to be agreed with regulators.
- **Study 3 planning inputs:** placebo risk 35–45%; efficacy 50–60%.
- **Study 1 planning inputs:** WU397 variances carry over to the new population; the effect size worth detecting is 1.5-fold; 15% attrition.

## 8. Files produced (all under `/tmp/outputs`)

- `answer.md`: this document.
- `forest_binding_vs_function.png`: the figure above.
- `analysis/`: all scripts and outputs. Run `analysis/run_all.sh` to regenerate everything from `/tmp/world/filesystem`, using the `core` environment.
- Main outputs:
  - `key_numbers.csv`: ledger of every quoted number, with source and derivation;
  - `gmt_ratio_cis.csv`, `ancova_baseline_adjusted.csv`: all arm comparisons with CIs;
  - `seqneut_by_category.csv`, `seqneut_per_virus.csv`, `seqneut_breadth_normalised.csv`, `egg_vs_wildtype_pairs.csv`: neutralisation panel analyses;
  - `binding_neut_dissociation.csv`, `binding_vs_function_correlations.csv`: binding vs function;
  - `hai_scr_sp.csv`, `mab_per_donor_summary.csv`, `gc_summary.csv`, `pb_summary.csv`, `repertoire_summary.csv`: per-assay summaries;
  - `study1_sizing.csv`, `sample_size_*.csv`, `efficacy_event_sizing.csv`, `chim_sizing.csv`: sizing;
  - `data_integrity_issues.csv`, `supplementary_checks.csv`: data checks.

**Statistical caveat.** WU397's functional cohorts are 13–15 per arm, and every p-value above is unadjusted and exploratory. "No advantage" means the point estimates sit near 1, with CIs that don't exclude modest differences. The binding-vs-neutralisation gap for H3 is the one contrast that is statistically clear despite the small n.
