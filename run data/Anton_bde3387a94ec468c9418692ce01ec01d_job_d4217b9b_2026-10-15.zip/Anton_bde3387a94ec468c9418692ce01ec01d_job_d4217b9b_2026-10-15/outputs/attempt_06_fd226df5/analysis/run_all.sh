#!/usr/bin/env bash
# Re-runs every analysis in order; stdout of each script is kept in /tmp/outputs/logs/
set -euo pipefail
cd /tmp/outputs/analysis
mkdir -p /tmp/outputs/logs
for s in 01_seqneut_breadth.py 02_serology_hai_mn_elisa.py 03_h1_immunogen_consistency.py 04_cellular_repertoire.py \
         05_binding_vs_function.py 06_power_next_studies.py 07_egg_pairs_and_most_drifted.py 08_sensitivity.py \
         09_forest_plot.py 10_mn_panel_identity_probe.py 11_data_integrity_checks.py 12_seqneut_per_virus.py 13_mab_breadth.py 14_waning.py 15_bead_timepoint_and_falling_titres.py; do
  echo "== $s"
  micromamba run -n core python "$s" > "/tmp/outputs/logs/${s%.py}.log" 2>&1
done
echo done
