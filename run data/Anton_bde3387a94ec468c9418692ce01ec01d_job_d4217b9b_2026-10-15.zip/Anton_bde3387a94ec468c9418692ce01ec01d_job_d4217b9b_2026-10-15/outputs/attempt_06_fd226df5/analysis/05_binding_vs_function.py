"""Binding vs function within the same participants: ELISA IgG fold-rise vs HAI / neutralisation fold-rise (wk4/d29 over baseline)."""
import pandas as pd, numpy as np
from scipy import stats
exec(open('/tmp/outputs/analysis/00_common.py').read())
pd.set_option('display.width',250)
e = pd.read_csv(f'{IN}/elisa_igg_titers.csv'); e = e[(e.measure=='fold_change')&(e.timepoint=='wk4')].copy()
e['pid'] = '397-' + e.participant.astype(int).map('{:03d}'.format)
e = e.pivot_table(index=['pid','arm'], columns='antigen', values='value')
h = pd.read_csv(f'{IN}/hai_titers.csv', dtype={'participant':str}); h['pid'] = '397-' + h.participant
h = h.pivot_table(index=['pid','arm','antigen'], columns='timepoint', values='hai_titer'); h['fr'] = h.wk4/h.wk0
h = h.fr.unstack('antigen')
s = load_seqneut()
sv = s[s.virus.isin(['A/Darwin/6/2021_H3N2'])].pivot_table(index=['pid','arm'], columns='tp', values='titer')
sv['fr_Darwin6'] = sv.d29/sv.d0
fd = s[(s.category=='forward-drift isolate (2022-2024)')].groupby(['pid','arm','subtype','tp']).log2t.mean().unstack('tp')
fd['fr'] = 2**(fd.d29-fd.d0); fd = fd.fr.unstack('subtype').add_prefix('fr_fwd_')
m = e.join(h, rsuffix='_HAI').join(sv[['fr_Darwin6']]).join(fd).dropna(subset=['fr_Darwin6'])
m = m.rename(columns={'A/H1':'ELISA_H1','A/H3':'ELISA_H3','A/H1N1':'HAI_H1','A/H3N2':'HAI_H3'})
cols = ['ELISA_H3','HAI_H3','fr_Darwin6','fr_fwd_H3N2','ELISA_H1','HAI_H1','fr_fwd_H1N1']
print(m[cols].round(2).to_string())
g = np.exp(np.log(m[cols]).groupby(level='arm').mean())
print('\nGeometric-mean fold-rise (d29/wk4 over d0) in the SAME participants (n = seq-neut cohort):'); print(g.round(2).to_string())
print('\n"Neutralisation yield" = GMFR(neutralisation or HAI) / GMFR(ELISA binding):')
for arm in g.index:
    print(f'  {arm}: H3  HAI/ELISA = {g.loc[arm,"HAI_H3"]/g.loc[arm,"ELISA_H3"]:.2f}; Darwin6-neut/ELISA = {g.loc[arm,"fr_Darwin6"]/g.loc[arm,"ELISA_H3"]:.2f}; '
          f'fwd-H3-neut/ELISA = {g.loc[arm,"fr_fwd_H3N2"]/g.loc[arm,"ELISA_H3"]:.2f} | H1 HAI/ELISA = {g.loc[arm,"HAI_H1"]/g.loc[arm,"ELISA_H1"]:.2f}; fwd-H1-neut/ELISA = {g.loc[arm,"fr_fwd_H1N1"]/g.loc[arm,"ELISA_H1"]:.2f}')
for arm, x in m.groupby(level='arm'):
    r = stats.spearmanr(np.log(x.ELISA_H3), np.log(x.fr_fwd_H3N2))
    r1 = stats.spearmanr(np.log(x.ELISA_H1), np.log(x.fr_fwd_H1N1))
    print(f'  {arm}: Spearman ELISA-H3 rise vs forward-drift H3 neut rise rho={r.correlation:.2f} (p={r.pvalue:.2f}); H1 rho={r1.correlation:.2f} (p={r1.pvalue:.2f})')
m.round(3).to_csv(f'{OUT}/binding_vs_function_by_participant.csv')
