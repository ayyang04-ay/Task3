"""Sample-size inputs for the recommended next studies, using variance estimates observed in WU397.
Assumptions are printed alongside results; these are planning numbers, not final protocol numbers."""
import pandas as pd, numpy as np, statsmodels.formula.api as smf
from scipy import stats
exec(open('/tmp/outputs/analysis/00_common.py').read())
out = []
# ---------------- 1. Phase 2 breadth endpoint: participant-level mean log2 neut titre vs forward-drift panel at d29
d = load_seqneut()
g = d[d.category=='forward-drift isolate (2022-2024)'].groupby(['subtype','arm','pid','tp']).log2t.mean().unstack('tp').reset_index()
print('Observed variance components (participant-level forward-drift breadth score, log2 units):')
resid = {}
for st, x in g.groupby('subtype'):
    x = x.assign(m=(x.arm=='mRNA-1010').astype(int))
    fit = smf.ols('d29 ~ m + d0', x).fit()
    sd_raw = x.groupby('arm').d29.std().mean(); r = np.corrcoef(x.d0, x.d29)[0,1]
    resid[st] = np.sqrt(fit.mse_resid)
    print(f'  {st}: SD(d29) = {sd_raw:.2f}; corr(d0,d29) = {r:.2f}; ANCOVA residual SD = {resid[st]:.2f}')
# HAI variance (wk4, log2) for comparison
h = pd.read_csv(f'{IN}/hai_titers.csv', dtype={'participant':str}); h['l'] = np.log2(h.hai_titer)
hw = h.pivot_table(index=['antigen','arm','participant'], columns='timepoint', values='l').reset_index()
for ag, x in hw.groupby('antigen'):
    x = x.dropna(subset=['wk0','wk4']).assign(m=lambda z: (z.arm=='mRNA-1010').astype(int))
    fit = smf.ols('wk4 ~ m + wk0', x).fit()
    print(f'  HAI {ag}: SD(wk4) = {x.groupby("arm").wk4.std().mean():.2f}; ANCOVA residual SD = {np.sqrt(fit.mse_resid):.2f}')

def n_per_arm(sd, ratio, alpha=0.05, power=0.9, sided=2):
    za = stats.norm.ppf(1-alpha/sided); zb = stats.norm.ppf(power)
    return int(np.ceil(2*((za+zb)*sd/np.log2(ratio))**2))
print('\nPhase 2 superiority on forward-drift breadth GMT ratio (ANCOVA residual SD, 90% power, two-sided alpha 0.025 per subtype [Bonferroni over H1, H3]):')
for st in ['H1N1','H3N2']:
    for ratio in [1.5, 2.0]:
        n = n_per_arm(resid[st], ratio, alpha=0.025)
        print(f'  {st}: detectable GMT ratio {ratio}: n = {n} evaluable per arm'); out.append(dict(study='Phase2', endpoint=f'{st} forward-drift GMT ratio', assumption=f'residual SD {resid[st]:.2f} log2, ratio {ratio}', n_per_arm=n))
# age-stratified: powered within each of 2 age strata
for st in ['H1N1','H3N2']:
    n = n_per_arm(max(resid.values())*1.15, 1.5, alpha=0.025)   # inflate SD 15% for broader population
    print(f'  conservative (SD inflated 15%): {st} ratio 1.5 -> {n} per arm per age stratum')

# HAI non-inferiority (CBER-style: upper bound of GMT ratio comparator/new <= 1.5; SCR difference upper bound <= 10 points)
sd_hai = 1.6   # conservative log2 SD for a general adult population
za = stats.norm.ppf(0.975); zb = stats.norm.ppf(0.9)
n_gmt = int(np.ceil(2*((za+zb)*sd_hai/np.log2(1.5))**2))
p = 0.4; n_scr = int(np.ceil(2*p*(1-p)*((za+zb)/0.10)**2))
print(f'\nHAI NI (true ratio 1.0, margin 1.5, SD {sd_hai} log2, 90% power): n = {n_gmt}/arm; SCR NI (true SCR 40% both arms, margin 10 pts): n = {n_scr}/arm')
out.append(dict(study='Phase2', endpoint='HAI GMT NI per strain', assumption='SD 1.6 log2; margin 1.5', n_per_arm=n_gmt))
out.append(dict(study='Phase2', endpoint='HAI SCR NI per strain', assumption='SCR 40%; margin 10 pts', n_per_arm=n_scr))

# ---------------- 2. Controlled human infection (heterologous challenge)
def n_two_prop(p1, p2, alpha=0.05, power=0.8):
    za = stats.norm.ppf(1-alpha/2); zb = stats.norm.ppf(power); pb = (p1+p2)/2
    return int(np.ceil((za*np.sqrt(2*pb*(1-pb)) + zb*np.sqrt(p1*(1-p1)+p2*(1-p2)))**2/(p1-p2)**2))
print('\nCHIM (mRNA-1010 vs licensed comparator, endpoint = lab-confirmed symptomatic infection):')
for p1, p2 in [(0.5,0.25),(0.4,0.2),(0.5,0.3)]:
    n = n_two_prop(p1, p2); print(f'  comparator {p1:.0%} vs mRNA {p2:.0%}: n = {n} per arm (80% power, two-sided 0.05)')
    out.append(dict(study='CHIM', endpoint='symptomatic lab-confirmed infection', assumption=f'{p1:.0%} vs {p2:.0%}', n_per_arm=n))

# ---------------- 3. Efficacy (rVE) - events needed, exact conditional binomial approach
def events_needed(rve, lb=0.0, alpha=0.025, power=0.9):
    # events split ~ Binomial(D, theta), theta = (1-rve)/(2-rve) under 1:1 allocation; test H0: rVE <= lb
    th1 = (1-rve)/(2-rve); th0 = (1-lb)/(2-lb)
    za = stats.norm.ppf(1-alpha); zb = stats.norm.ppf(power)
    return int(np.ceil(((za*np.sqrt(th0*(1-th0)) + zb*np.sqrt(th1*(1-th1)))/(th0-th1))**2))
print('\nrVE trial, events needed (1:1, one-sided alpha 0.025, 90% power):')
for rve in [0.15, 0.20, 0.25, 0.30]:
    D = events_needed(rve); print(f'  true rVE {rve:.0%}, success = lower bound > 0%: {D} events')
    out.append(dict(study='Phase3 rVE', endpoint='mismatched-strain RT-PCR ILI', assumption=f'rVE {rve:.0%}, LB>0', n_per_arm=f'{D} events total'))
print('\nParticipants required for 500 mismatched-strain events, by comparator-arm attack rate and mismatched fraction (1:1, rVE 25%):')
for ar in [0.01, 0.02, 0.03]:
    for mf in [0.3, 0.5, 0.7]:
        rate_c = ar*mf; rate_v = rate_c*0.75; N = 500/((rate_c+rate_v)/2)
        print(f'  attack rate {ar:.0%}/season, mismatched fraction {mf:.0%}: ~{N/1000:.0f}k participant-seasons')
pd.DataFrame(out).to_csv(f'{OUT}/power_planning_numbers.csv', index=False)
