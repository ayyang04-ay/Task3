"""Is the H1 response pattern in the mRNA-1010 arm consistent with the documented H1 antigen
(A/Victoria/4897/2022, clade 5a.2a.1)?  Compare the fold-rise to the 5a.2 strain A/Wisconsin/588/2019
(cell-based twin of Fluarix's A/Victoria/2570/2019) with the fold-rise to the 5a.2a.1 strain
A/Wisconsin/67/2022 (cell-based twin of A/Victoria/4897/2022), within participant.
Also: monoclonal antibodies (vaccine-induced B cells) - relative binding to Wisconsin/588/2019 vs Victoria/4897/2022."""
import pandas as pd, numpy as np
from scipy import stats
exec(open('/tmp/outputs/analysis/00_common.py').read())
d = load_seqneut()
w = d[d.virus.isin(['A/Wisconsin/588/2019_H1N1','A/Wisconsin/67/2022_H1N1','A/Victoria/4897/2022_IVR-238_H1N1'])]
w = w.pivot_table(index=['arm','pid'], columns=['virus','tp'], values='log2t')
out = pd.DataFrame(index=w.index)
out['FR_Wis588_5a.2'] = 2**(w[('A/Wisconsin/588/2019_H1N1','d29')] - w[('A/Wisconsin/588/2019_H1N1','d0')])
out['FR_Wis67_5a.2a.1'] = 2**(w[('A/Wisconsin/67/2022_H1N1','d29')] - w[('A/Wisconsin/67/2022_H1N1','d0')])
out['FR_Vic4897_IVR238'] = 2**(w[('A/Victoria/4897/2022_IVR-238_H1N1','d29')] - w[('A/Victoria/4897/2022_IVR-238_H1N1','d0')])
out['ratio_5a.2_over_5a.2a.1'] = out['FR_Wis588_5a.2'] / out['FR_Wis67_5a.2a.1']
out['d29_titre_Wis588'] = 2**w[('A/Wisconsin/588/2019_H1N1','d29')]
out['d29_titre_Wis67'] = 2**w[('A/Wisconsin/67/2022_H1N1','d29')]
print(out.round(2).to_string())
for arm, x in out.groupby(level='arm'):
    r = np.log2(x['ratio_5a.2_over_5a.2a.1'])
    print(f'{arm}: geometric mean [FR 5a.2 / FR 5a.2a.1] = {2**r.mean():.2f}; participants with larger rise to 5a.2 than 5a.2a.1: {(r>0).sum()}/{len(r)}; '
          f'GM d29 titre ratio Wis588/Wis67 = {2**np.log2(x.d29_titre_Wis588/x.d29_titre_Wis67).mean():.2f}')
a = np.log2(out.loc['mRNA-1010']['ratio_5a.2_over_5a.2a.1']); f = np.log2(out.loc['Fluarix']['ratio_5a.2_over_5a.2a.1'])
print('within-arm sign test mRNA-1010 (H0: no preference): p = %.4f' % stats.binomtest(int((a>0).sum()), len(a)).pvalue)
print('Wilcoxon signed-rank mRNA-1010 log ratio vs 0: p = %.4f' % stats.wilcoxon(a).pvalue)
print('MWU mRNA vs Fluarix on log ratio: p = %.3f' % stats.mannwhitneyu(a, f).pvalue)
out.round(3).to_csv(f'{OUT}/h1_immunogen_consistency_by_participant.csv')

# monoclonal antibodies
m = pd.read_csv(f'{IN}/mab_binding_panels.csv', dtype={'mab_id':str}); m['donor'] = m.mab_id.str.split('.').str[1]
g1 = m[m.panel=='group_I'].pivot_table(index=['arm','donor','mab_id'], columns='antigen', values='fold_over_control')
g1['log2_Wis588_over_Vic4897'] = np.log2(g1['A/Wisconsin/588/2019'].clip(lower=0.1) / g1['A/Victoria/4897/2022'].clip(lower=0.1))
s = g1.groupby(level=['arm','donor']).agg(n=('log2_Wis588_over_Vic4897','size'),
        median_log2_ratio=('log2_Wis588_over_Vic4897','median'),
        frac_bind_Wis588_better=('log2_Wis588_over_Vic4897', lambda v: (v>0).mean()))
print('\nGroup-I mAbs: binding to A/Wisconsin/588/2019 (5a.2) relative to A/Victoria/4897/2022 (5a.2a.1), per donor')
print(s.round(2).to_string())
s.round(3).to_csv(f'{OUT}/mab_h1_relative_binding_by_donor.csv')
