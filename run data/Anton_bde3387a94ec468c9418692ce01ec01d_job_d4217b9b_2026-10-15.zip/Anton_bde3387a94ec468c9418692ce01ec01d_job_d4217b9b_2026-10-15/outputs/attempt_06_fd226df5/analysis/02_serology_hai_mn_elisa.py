"""HAI, microneutralisation (MN) and ELISA IgG: descriptive statistics and baseline-adjusted arm comparisons."""
import pandas as pd, numpy as np, statsmodels.formula.api as smf
from scipy import stats
IN='/tmp/world/filesystem'; OUT='/tmp/outputs'
pd.set_option('display.width',300); pd.set_option('display.max_columns',40)

def wilson(k, n, z=1.96):
    if n == 0: return (np.nan, np.nan)
    p = k/n; den = 1+z*z/n; c = (p + z*z/(2*n))/den; h = z*np.sqrt(p*(1-p)/n + z*z/(4*n*n))/den
    return (c-h, c+h)

def compare(w, label, ceiling=None):
    """w: DataFrame indexed by participant with columns arm, wk0, wk4, late (log2 titres)"""
    rows = []
    w = w.copy(); w['m'] = (w.arm=='mRNA-1010').astype(int)
    for arm, x in w.groupby('arm'):
        x4 = x.dropna(subset=['wk0','wk4'])
        k = int(((x4.wk4 - x4.wk0) >= 2 - 1e-9).sum()); n = len(x4)
        lo, hi = wilson(k, n)
        r = dict(readout=label, arm=arm, n=n, GMT_wk0=2**x.wk0.mean(), GMT_wk4=2**x.wk4.mean(),
                 GMT_late=2**x.late.mean(), n_late=int(x.late.notna().sum()),
                 GMFR_wk4=2**(x4.wk4-x4.wk0).mean(), SCR4_wk4=k/n, SCR4_CI=f'{lo:.2f}-{hi:.2f}')
        if label.startswith('HAI'):
            r['SPR40_wk0'] = (x.wk0 >= np.log2(40)-1e-9).mean(); r['SPR40_wk4'] = (x.wk4 >= np.log2(40)-1e-9).mean()
        if ceiling is not None:
            r['at_ceiling_wk0'] = int((x.wk0 >= np.log2(ceiling)-1e-9).sum()); r['at_ceiling_wk4'] = int((x.wk4 >= np.log2(ceiling)-1e-9).sum())
        rows.append(r)
    out = pd.DataFrame(rows)
    y = w.dropna(subset=['wk0','wk4'])
    m0 = smf.ols('wk4 ~ m', y).fit(); m1 = smf.ols('wk4 ~ m + wk0', y).fit()
    ci0 = m0.conf_int().loc['m']; ci1 = m1.conf_int().loc['m']
    comp = dict(readout=label, wk0_ratio=2**(y[y.m==1].wk0.mean()-y[y.m==0].wk0.mean()),
                wk4_ratio_unadj=2**m0.params['m'], wk4_unadj_CI=f'{2**ci0[0]:.2f}-{2**ci0[1]:.2f}',
                wk4_ratio_adj=2**m1.params['m'], wk4_adj_CI=f'{2**ci1[0]:.2f}-{2**ci1[1]:.2f}', p_adj=m1.pvalues['m'])
    yl = w.dropna(subset=['wk0','late'])
    if len(yl) > 6:
        m2 = smf.ols('late ~ m + wk0', yl).fit(); ci2 = m2.conf_int().loc['m']
        comp.update(late_ratio_adj=2**m2.params['m'], late_adj_CI=f'{2**ci2[0]:.2f}-{2**ci2[1]:.2f}')
    return out, comp

allrows, comps = [], []
# ---- HAI
h = pd.read_csv(f'{IN}/hai_titers.csv', dtype={'participant':str})
h['l'] = np.log2(h.hai_titer)
for ag, x in h.groupby('antigen'):
    w = x.pivot_table(index=['participant','arm'], columns='timepoint', values='l').reset_index()
    w['late'] = w['wk26'].fillna(w['wk17'])
    o, c = compare(w, f'HAI {ag}'); allrows.append(o); comps.append(c)
# ---- MN
mn = pd.read_csv(f'{IN}/microneutralization.csv'); mn = mn[mn.measure=='titer'].copy(); mn['l'] = np.log2(mn.value)
for p, x in mn.groupby('panel'):
    w = x.pivot_table(index=['participant','arm'], columns='timepoint', values='l').reset_index()
    w['late'] = w['wk26'].fillna(w['wk17'])
    o, c = compare(w, f'MN {p}', ceiling=1280); allrows.append(o); comps.append(c)
# ---- ELISA IgG
e = pd.read_csv(f'{IN}/elisa_igg_titers.csv'); e = e[e.measure=='ec50'].copy(); e['l'] = np.log2(e.value)
for ag, x in e.groupby('antigen'):
    w = x.pivot_table(index=['participant','arm'], columns='timepoint', values='l').reset_index()
    w['late'] = w['wk26'].fillna(w['wk17'])
    o, c = compare(w, f'ELISA IgG {ag}'); allrows.append(o); comps.append(c)

desc = pd.concat(allrows); comp = pd.DataFrame(comps)
print(desc.round(2).to_string()); print(); print(comp.round(3).to_string())
desc.round(3).to_csv(f'{OUT}/serology_descriptive_by_arm.csv', index=False)
comp.round(3).to_csv(f'{OUT}/serology_arm_comparison_ancova.csv', index=False)

# ---- MN ceiling check: participants whose baseline already sits at the 1280 ceiling cannot show a rise
print('\nMN participants at the 1280 ceiling at baseline (rise unmeasurable):')
x = mn[(mn.timepoint=='wk0') & (mn.value>=1280)]; print(x[['panel','arm','participant','value']].to_string(index=False))
# ---- Tobit-style sensitivity for MN wk4 (right-censored at 1280) using a censored normal likelihood
from scipy.optimize import minimize
def tobit(y, X, cens):
    def nll(b):
        mu = X @ b[:-1]; s = np.exp(b[-1])
        ll = np.where(cens, stats.norm.logsf((y-mu)/s), stats.norm.logpdf((y-mu)/s) - np.log(s))
        return -ll.sum()
    b0 = np.r_[np.linalg.lstsq(X, y, rcond=None)[0], 0.0]
    r = minimize(nll, b0, method='BFGS'); return r.x, r.hess_inv
for p, x in mn.groupby('panel'):
    w = x.pivot_table(index=['participant','arm'], columns='timepoint', values='l').reset_index().dropna(subset=['wk0','wk4'])
    X = np.c_[np.ones(len(w)), (w.arm=='mRNA-1010').astype(float), w.wk0]
    b, H = tobit(w.wk4.values, X, (w.wk4 >= np.log2(1280)-1e-9).values)
    se = np.sqrt(np.diag(H))[1]
    print(f'MN {p}: censored-regression (ceiling 1280) baseline-adjusted wk4 ratio mRNA/Fluarix = {2**b[1]:.2f} (95% CI {2**(b[1]-1.96*se):.2f}-{2**(b[1]+1.96*se):.2f})')
