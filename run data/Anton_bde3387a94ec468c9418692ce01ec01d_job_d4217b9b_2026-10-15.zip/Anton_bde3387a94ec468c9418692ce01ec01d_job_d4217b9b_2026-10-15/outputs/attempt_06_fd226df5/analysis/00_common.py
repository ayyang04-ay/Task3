"""Common loaders / virus classification for the WU397 data package re-analysis.
All paths are read-only inputs from /tmp/world/filesystem."""
import pandas as pd, numpy as np, re
IN = '/tmp/world/filesystem'
OUT = '/tmp/outputs'

# ---------------------------------------------------------------------------
# Sequencing-based neutralisation panel: classification of each virus
# relative to the two vaccines. Strain-to-clade / vaccine-history assignments
# are from WHO composition recommendations (public record), NOT from the data
# package; they are stated explicitly so they can be audited.
# ---------------------------------------------------------------------------
REASSORTANT_PAT = re.compile(r'(IVR-|NIB-|X-\d|egg)', re.I)

H1_HIST   = ['A/California/07/2009_H1N1','A/Michigan/45/2015_H1N1','A/Brisbane/02/2018_H1N1','A/Hawaii/70/2019_H1N1']
H1_FLUARIX_LIKE = ['A/Wisconsin/588/2019_H1N1']          # cell-based twin of A/Victoria/2570/2019 (Fluarix 2022-23 H1), clade 5a.2
H1_MRNA_DOC_LIKE = ['A/Wisconsin/67/2022_H1N1']          # cell-based twin of A/Victoria/4897/2022 (documented mRNA-1010 H1), clade 5a.2a.1
H1_MRNA_DOC_EGG  = ['A/Victoria/4897/2022_IVR-238_H1N1'] # egg reassortant of documented mRNA-1010 H1
H3_HIST = ['A/Texas/50/2012_H3N2','A/Switzerland/9715293/2013_H3N2','A/HongKong/4801/2014_H3N2',
           'A/Singapore/INFIMH-16-0019/2016_H3N2','A/Kansas/14/2017_H3N2','A/HongKong/45/2019_H3N2',
           'A/HongKong/2671/2019_H3N2','A/Cambodia/e0826360/2020_H3N2']
H3_VACCINE_2223 = ['A/Darwin/6/2021_H3N2','A/Darwin/9/2021_H3N2']  # Darwin/6 = mRNA-1010 antigen (cell-based rec.); Darwin/9 = egg-based rec. (Fluarix)
H3_LATER_VACCINE = ['A/Massachusetts/18/2022_H3N2','A/Thailand/8/2022_H3N2']  # 2024-25 recommendations (clade 2a.3a.1)

def classify(v):
    sub = v[-4:]
    if REASSORTANT_PAT.search(v):
        return 'egg/production reassortant'
    if v in H1_HIST or v in H3_HIST:
        return 'historical (<=2020)'
    if v in H1_FLUARIX_LIKE:
        return 'H1 5a.2 (Fluarix-2022/23-like)'
    if v in H1_MRNA_DOC_LIKE:
        return 'H1 5a.2a.1 (documented mRNA-1010 H1-like)'
    if v in H3_VACCINE_2223:
        return 'H3 2022/23 vaccine strain'
    if v in H3_LATER_VACCINE:
        return 'H3 later vaccine strain (2a.3a.1)'
    return 'forward-drift isolate (2022-2024)'

def load_seqneut():
    d = pd.read_csv(f'{IN}/neutralization_seqbased.csv')
    p = d.serum.str.split('_', expand=True)
    d['arm'] = p[0]; d['pid'] = p[1]; d['day'] = p[2].str[1:].astype(int)
    d['subtype'] = d.virus.str[-4:]
    d['category'] = d.virus.map(classify)
    d['log2t'] = np.log2(d.titer)
    d['tp'] = d.day.map({0:'d0', 29:'d29', 121:'late', 181:'late'})
    return d
