"""Sequencing-based neutralisation: baseline-adjusted arm comparison by virus category.
Unit of analysis = participant (mean log2 titre across the viruses in a category),
so that 66 correlated H3N2 viruses are not treated as 66 independent observations."""
import pandas as pd, numpy as np, statsmodels.formula.api as smf
from scipy import stats
exec(open('/tmp/outputs/analysis/00_common.py').read())
d = load_seqneut()

def summarise(d, lod_sub=None):
    x = d.copy()
    if lod_sub is not None:   # sensitivity: below-LOD values (titer_bound=='upper', i.e. true titre <= 40) set to lod_sub
        x.loc[x.titer_bound=='upper','log2t'] = np.log2(lod_sub)
    # participant x category x timepoint mean log2 titre
    g = x.groupby(['subtype','category','arm','pid','tp']).log2t.mean().unstack('tp')
    rows = []
    for (st, cat), y in g.groupby(level=[0,1]):
        y = y.reset_index()
        y['m'] = (y.arm=='mRNA-1010').astype(int)
        y['fc'] = y.d29 - y.d0
        a, f = y[y.m==1], y[y.m==0]
        r = dict(subtype=st, category=cat, n_viruses=x[(x.subtype==st)&(x.category==cat)].virus.nunique(),
                 n_mRNA=len(a), n_Flu=len(f),
                 GMT_d0_mRNA=2**a.d0.mean(), GMT_d0_Flu=2**f.d0.mean(),
                 GMT_d29_mRNA=2**a.d29.mean(), GMT_d29_Flu=2**f.d29.mean(),
                 GMFR_mRNA=2**a.fc.mean(), GMFR_Flu=2**f.fc.mean(),
                 d0_ratio=2**(a.d0.mean()-f.d0.mean()),
                 p_d0=stats.ttest_ind(a.d0, f.d0, equal_var=False).pvalue)
        # unadjusted d29 ratio
        m0 = smf.ols('d29 ~ m', y).fit()
        r['d29_ratio_unadj'] = 2**m0.params['m']; ci = m0.conf_int().loc['m']; r['d29_unadj_CI'] = f'{2**ci[0]:.2f}-{2**ci[1]:.2f}'
        # baseline-adjusted (ANCOVA)
        m1 = smf.ols('d29 ~ m + d0', y).fit()
        r['d29_ratio_adj'] = 2**m1.params['m']; ci = m1.conf_int().loc['m']; r['d29_adj_CI'] = f'{2**ci[0]:.2f}-{2**ci[1]:.2f}'
        r['p_adj'] = m1.pvalues['m']
        # late (d121/d181) baseline-adjusted
        yl = y.dropna(subset=['late'])
        if len(yl) > 6:
            m2 = smf.ols('late ~ m + d0', yl).fit()
            r['late_ratio_adj'] = 2**m2.params['m']; ci = m2.conf_int().loc['m']; r['late_adj_CI'] = f'{2**ci[0]:.2f}-{2**ci[1]:.2f}'
            r['n_late_mRNA'] = int(yl.m.sum()); r['n_late_Flu'] = int((1-yl.m).sum())
        rows.append(r)
    return pd.DataFrame(rows)

res = summarise(d)
res_lod = summarise(d, lod_sub=20)
pd.set_option('display.width', 300); pd.set_option('display.max_columns', 40)
print(res.round(2).to_string())
print('\nSensitivity (below-LOD set to 20):')
print(res_lod[['subtype','category','d29_ratio_adj','d29_adj_CI','late_ratio_adj','late_adj_CI']].round(2).to_string())
res.round(3).to_csv(f'{OUT}/seqneut_category_ancova.csv', index=False)

# Per-participant fraction of forward-drift viruses with >=4-fold rise at d29
fd = d[d.category=='forward-drift isolate (2022-2024)'].pivot_table(index=['subtype','arm','pid','virus'], columns='tp', values='log2t')
fd['rise4'] = (fd.d29 - fd.d0) >= 2
frac = fd.groupby(['subtype','arm','pid']).rise4.mean().unstack('arm')
print('\nFraction of forward-drift viruses with >=4-fold d0->d29 rise, per participant (median [IQR]):')
for st in ['H1N1','H3N2']:
    for arm in ['mRNA-1010','Fluarix']:
        v = frac.loc[st][arm].dropna()
        print(st, arm, 'n=%d median=%.2f IQR=%.2f-%.2f; participants with >=50%% of panel 4-fold: %d/%d' % (len(v), v.median(), v.quantile(.25), v.quantile(.75), (v>=0.5).sum(), len(v)))
    a = frac.loc[st]['mRNA-1010'].dropna(); f = frac.loc[st]['Fluarix'].dropna()
    print('   MWU p=%.3f' % stats.mannwhitneyu(a, f).pvalue)
frac.to_csv(f'{OUT}/seqneut_forward_drift_fraction_4fold_by_participant.csv')
