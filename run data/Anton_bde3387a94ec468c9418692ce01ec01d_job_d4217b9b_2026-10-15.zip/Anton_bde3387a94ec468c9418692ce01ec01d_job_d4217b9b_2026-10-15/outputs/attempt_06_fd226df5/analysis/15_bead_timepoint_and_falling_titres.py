"""(a) Which ELISA interval does the (unlabelled) bead-array fold-change correspond to?
   (b) Participants whose H3N2 titres fell after dosing (possible recent pre-enrolment infection)."""
import pandas as pd, numpy as np
from scipy import stats
exec(open('/tmp/outputs/analysis/00_common.py').read())
e = pd.read_csv(f'{IN}/elisa_igg_titers.csv'); e = e[e.measure=='fold_change']
e['pid'] = '397-' + e.participant.astype(int).map('{:03d}'.format)
e = e.pivot_table(index='pid', columns=['antigen','timepoint'], values='value')
rows = []
for f, ag, strain in [('binding_breadth_h3.csv','A/H3','A/Darwin/6/2021'), ('binding_breadth_h1.csv','A/H1','A/Wisconsin/67/2022'), ('binding_breadth_h1.csv','A/H1','A/Wisconsin/588/2019')]:
    b = pd.read_csv(f'{IN}/{f}'); b = b[b.strain==strain].set_index('participant')
    j = b.join(e[ag])
    for tp in ['wk4','wk17/26']:
        r = stats.spearmanr(j.log2_fold_change_mfi, np.log2(j[tp]))
        rows.append(dict(bead_strain=strain, elisa_antigen=ag, elisa_interval=tp, spearman_rho=r.correlation, p=r.pvalue, n=len(j)))
t = pd.DataFrame(rows); print(t.round(3).to_string(index=False)); t.round(4).to_csv(f'{OUT}/bead_vs_elisa_interval.csv', index=False)

d = load_seqneut()
x = d[d.pid.isin(['397-009','397-028']) & d.virus.isin(['A/Darwin/6/2021_H3N2','A/Darwin/9/2021_H3N2'])]
print('\nH3 vaccine-strain titres, participants with post-dose falls:')
print(x.pivot_table(index=['arm','pid','virus'], columns='day', values='titer').round(0).to_string())
g = d[d.pid.isin(['397-009','397-028']) & (d.category=='forward-drift isolate (2022-2024)') & (d.subtype=='H3N2')]
g = g.groupby(['pid','tp']).log2t.mean().unstack('tp')
print('\nForward-drift H3N2 GM fold-change d29/d0:', (2**(g.d29-g.d0)).round(2).to_dict(), '| late/d0:', (2**(g.late-g.d0)).round(2).to_dict())
