"""Waning of neutralising titres from d29 to the late visit (d121/d181), forward-drift panels, by arm."""
import pandas as pd, numpy as np
from scipy import stats
exec(open('/tmp/outputs/analysis/00_common.py').read())
d = load_seqneut()
g = d[d.category=='forward-drift isolate (2022-2024)'].groupby(['subtype','arm','pid','tp']).log2t.mean().unstack('tp')
g['late_over_d29'] = g.late - g.d29
rows = []
for (st, arm), x in g.groupby(level=[0,1]):
    x = x.dropna(subset=['late'])
    rows.append(dict(subtype=st, arm=arm, n=len(x), GMT_d29=2**x.d29.mean(), GMT_late=2**x.late.mean(),
                     GM_late_over_d29=2**x.late_over_d29.mean(), GM_late_over_d0=2**(x.late-x.d0).mean()))
r = pd.DataFrame(rows); print(r.round(2).to_string(index=False))
for st in ['H1N1','H3N2']:
    a = g.loc[(st,'mRNA-1010')].late_over_d29.dropna(); f = g.loc[(st,'Fluarix')].late_over_d29.dropna()
    print(st, 'waning mRNA vs Fluarix MWU p=%.3f' % stats.mannwhitneyu(a, f).pvalue)
r.round(3).to_csv(f'{OUT}/seqneut_waning_forward_drift.csv', index=False)
