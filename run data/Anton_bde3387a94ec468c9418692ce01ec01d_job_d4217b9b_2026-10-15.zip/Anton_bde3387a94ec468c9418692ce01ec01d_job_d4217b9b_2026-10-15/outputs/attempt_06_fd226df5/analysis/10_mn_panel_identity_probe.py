"""The MN 'homologous' and 'heterologous' viruses are not identified in the package.
Probe (hypothesis only): which sequencing-neutralisation viruses' baseline titres and fold-rises track the MN readouts across participants?"""
import pandas as pd, numpy as np
from scipy import stats
exec(open('/tmp/outputs/analysis/00_common.py').read())
mn = pd.read_csv(f'{IN}/microneutralization.csv'); mn = mn[mn.measure=='titer']
mw = mn.pivot_table(index='participant', columns=['panel','timepoint'], values='value')
d = load_seqneut()
sw = d.pivot_table(index='pid', columns=['virus','tp'], values='log2t')
res = []
for p in ['homologous','heterologous']:
    y0 = np.log2(mw[(p,'wk0')]); yfc = np.log2(mw[(p,'wk4')]/mw[(p,'wk0')])
    for v in d.virus.unique():
        x0 = sw[(v,'d0')]; xfc = sw[(v,'d29')] - sw[(v,'d0')]
        j = pd.concat([y0, yfc, x0, xfc], axis=1, keys=['y0','yfc','x0','xfc']).dropna()
        res.append(dict(panel=p, virus=v, subtype=v[-4:], rho_baseline=stats.spearmanr(j.y0, j.x0).correlation,
                        rho_foldrise=stats.spearmanr(j.yfc, j.xfc).correlation, n=len(j)))
r = pd.DataFrame(res); r['rho_sum'] = r.rho_baseline + r.rho_foldrise
pd.set_option('display.width', 200)
for p in ['homologous','heterologous']:
    x = r[r.panel==p].sort_values('rho_sum', ascending=False)
    print(f'== MN {p}: top 8 tracking viruses'); print(x.head(8).round(2).to_string(index=False))
    print('   mean rho_sum by subtype:', x.groupby('subtype').rho_sum.mean().round(2).to_dict())
r.round(3).to_csv(f'{OUT}/mn_panel_identity_probe.csv', index=False)
