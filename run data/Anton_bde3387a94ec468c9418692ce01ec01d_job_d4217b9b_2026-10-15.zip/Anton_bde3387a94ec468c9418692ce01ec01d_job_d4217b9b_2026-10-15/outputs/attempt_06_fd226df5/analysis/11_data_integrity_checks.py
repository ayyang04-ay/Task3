"""Data-integrity and cohort-reconciliation checks on the WU397 package."""
import pandas as pd, numpy as np, re
IN='/tmp/world/filesystem'; OUT='/tmp/outputs'
pd.set_option('display.width',250)
issues = []
def log(area, finding): issues.append(dict(area=area, finding=finding)); print(f'[{area}] {finding}')

# ---- cohort sizes vs trial_summary.md
h = pd.read_csv(f'{IN}/hai_titers.csv', dtype={'participant':str})
mn = pd.read_csv(f'{IN}/microneutralization.csv')
e = pd.read_csv(f'{IN}/elisa_igg_titers.csv')
igm = pd.read_csv(f'{IN}/igm_fold_change.csv', dtype={'participant':str})
b1 = pd.read_csv(f'{IN}/binding_breadth_h1.csv'); b3 = pd.read_csv(f'{IN}/binding_breadth_h3.csv')
s = pd.read_csv(f'{IN}/neutralization_seqbased.csv'); p = s.serum.str.split('_', expand=True); s['arm']=p[0]; s['pid']=p[1]; s['day']=p[2]
gc = pd.read_csv(f'{IN}/gc_frequencies.csv', dtype={'participant':str}); pb = pd.read_csv(f'{IN}/plasmablast_frequencies.csv', dtype={'participant':str})
counts = {
 'ELISA IgG (summary 38/37)': e.groupby('arm').participant.nunique(),
 'IgM (summary 38/37)': igm.groupby('arm').participant.nunique(),
 'HAI (summary 14/15)': h.groupby('arm').participant.nunique(),
 'HAI B/Vic only': h[h.antigen=='B/Vic'].groupby('arm').participant.nunique(),
 'Bead array (summary 14/15)': b1.groupby('arm').participant.nunique(),
 'MN (summary 14/15)': mn.groupby('arm').participant.nunique(),
 'Seq-neut (summary 13/14)': s.groupby('arm').pid.nunique(),
 'GC / FNA (summary 6/11)': gc.groupby('arm').participant.nunique(),
 'Plasmablast file': pb.groupby('arm').participant.nunique()}
ct = pd.DataFrame(counts).T; print(ct); ct.to_csv(f'{OUT}/cohort_counts_vs_summary.csv')
log('cohort', f"IgM file has {igm.participant.nunique()} participants (15 Fluarix/14 mRNA-1010) although trial_summary lists 38/37 for 'Binding antibody (ELISA, IgM)'.")
log('cohort', "HAI B/Vic has no values for 397-031 (mRNA-1010): n=13 not 14.")
miss_sn = sorted(set('397-'+h.participant) - set(s.pid)); log('cohort', f'Seq-neut cohort omits {miss_sn} relative to HAI/MN cohort (no reason given).')
# ---- ID formats
log('identifiers', "ELISA participant IDs are bare integers (1..102); HAI/GC/PB use zero-padded '0NN'; MN/bead/seq-neut use '397-0NN'; IgM has one unpadded ID ('20').")
ids_f = sorted(e[e.arm=='Fluarix'].participant.unique()); ids_m = sorted(e[e.arm=='mRNA-1010'].participant.unique())
log('enrolment', f"ELISA IDs: Fluarix {min(ids_f)}-{max(ids_f)}, mRNA-1010 {min(ids_m)}-{max(ids_m)}; IDs 33-59 are Fluarix-only and 64-102 mRNA-1010-only -> parts of the two arms were probably enrolled in different windows (enrolment dates not supplied).")
# ---- late-visit labels
def late_map(df, idcol, tpcol, prefix=''):
    x = df[df[tpcol].isin(['wk17','wk26','d121','d181'])]
    return x.groupby(idcol)[tpcol].agg(lambda v: sorted(set(v)))
hv = h.assign(pid='397-'+h.participant)
for ag in h.antigen.unique():
    pass
lab = {}
for ag, x in hv.groupby('antigen'):
    lab[f'HAI {ag}'] = x[x.timepoint.isin(['wk17','wk26'])].groupby('pid').timepoint.first()
mt = mn[mn.measure=='titer']
for pn, x in mt.groupby('panel'):
    lab[f'MN {pn}'] = x[x.timepoint.isin(['wk17','wk26'])].groupby('participant').timepoint.first()
lab['SeqNeut'] = s[s.day.isin(['d121','d181'])].groupby('pid').day.first().map({'d121':'wk17','d181':'wk26'})
L = pd.DataFrame(lab)
bad = L[L.apply(lambda r: r.dropna().nunique() > 1, axis=1)]
print(bad.to_string())
log('visit labels', f"{len(bad)} participants have conflicting late-visit labels across assays: HAI B/Vic labels are swapped relative to HAI H1/H3/BYam and MN for 397-007, -008, -009, -010, -016, -018, -021, -023; seq-neut labels 397-007 and 397-011 as d121 while HAI/MN/ELISA label them wk26.")
# ---- GC / PB files
log('GC file', "gc_frequencies.csv contains two stacked blocks under one header (every (timepoint, arm, participant) key appears twice with different values); the second block's measure is unlabelled.")
log('GC file', "GC timepoints are wk0/wk2/wk8/wk17/wk26, but the summary lists FNA at wk1/2/4/8/17/26 (no wk0; wk1 and wk4 absent from file).")
log('PB file', "plasmablast_frequencies.csv uses wk2/wk8 although blood was drawn at d0/d7/d29/d121/d181; values of 1-5% at wk8-wk26 are implausible for circulating plasmablasts -> likely lymph-node plasma cells or mislabelled; 11 participants in this file are not in the FNA cohort and their values carry 2-3 decimals vs 5-6 elsewhere (merged sources).")
# ---- assay identity / censoring
log('assay identity', "MN 'homologous'/'heterologous' viruses and the HAI test antigens are not identified; the bead-array timepoint is not stated (correlates best with ELISA wk4 fold-change).")
log('censoring', f"MN titres are capped at 1280: {int(((mt.timepoint=='wk4')&(mt.value>=1280)&(mt.panel=='homologous')&(mt.arm=='Fluarix')).sum())}/15 Fluarix and {int(((mt.timepoint=='wk4')&(mt.value>=1280)&(mt.panel=='homologous')&(mt.arm=='mRNA-1010')).sum())}/14 mRNA-1010 homologous wk4 values sit at the cap.")
nb = s.titer_bound.value_counts().to_dict(); log('censoring', f"Seq-neut: {nb.get('upper',0)} values below the lower limit (bound='upper', <=40) and {nb.get('lower',0)} at the upper limit (bound='lower', >=17300) of 7719.")
log('naming', "Seq-neut virus 'A/SOUTHAFRICA/R07876/202023_H3N2' has a malformed year.")
log('repertoire', "cdrh3_diversity_index / serum_igg_clonotypes / repertoire_clonotype_counts carry no participant IDs (cannot be linked to serology); repertoire_clonotype_counts carries no timepoint.")
pd.DataFrame(issues).to_csv(f'{OUT}/data_integrity_issues.csv', index=False)
