"""(a) Egg/production reassortant vs matched wild-type virus: titre inflation by arm.
   (b) Most antigenically advanced viruses in the panel (lowest titres): arm comparison.
   (c) Bead-array binding breadth by strain (fold-rise, both arms)."""
import pandas as pd, numpy as np, statsmodels.formula.api as smf
from scipy import stats
exec(open('/tmp/outputs/analysis/00_common.py').read())
pd.set_option('display.width',250)
d = load_seqneut()
pairs = [('A/Cambodia/e0826360/2020egg_H3N2','A/Cambodia/e0826360/2020_H3N2'),
         ('A/HongKong/4801/2014egg_H3N2','A/HongKong/4801/2014_H3N2'),
         ('A/Singapore/INFIMH-16-0019/2016X-307A_H3N2','A/Singapore/INFIMH-16-0019/2016_H3N2'),
         ('A/Switzerland/9715293/2013NIB-88_H3N2','A/Switzerland/9715293/2013_H3N2'),
         ('A/Texas/50/2012X-223A_H3N2','A/Texas/50/2012_H3N2'),
         ('A/Victoria/4897/2022_IVR-238_H1N1','A/Wisconsin/67/2022_H1N1')]   # last pair: same clade (5a.2a.1), egg-based vs cell-based twin
rows = []
for egg, wt in pairs:
    x = d[d.virus.isin([egg, wt]) & (d.tp=='d29')].pivot_table(index=['arm','pid'], columns='virus', values='log2t')
    r = (x[egg] - x[wt]).groupby(level='arm').mean()
    rows.append(dict(egg_reassortant=egg, wild_type_comparator=wt, GM_ratio_egg_over_wt_Fluarix=2**r['Fluarix'], GM_ratio_egg_over_wt_mRNA=2**r['mRNA-1010']))
eg = pd.DataFrame(rows); print(eg.round(2).to_string()); eg.round(3).to_csv(f'{OUT}/seqneut_egg_vs_wildtype_pairs.csv', index=False)

# (b) most drifted: 8 H3N2 viruses with lowest pooled d29 GMT
h3 = d[(d.subtype=='H3N2') & (d.category=='forward-drift isolate (2022-2024)')]
gm = h3[h3.tp=='d29'].groupby('virus').log2t.mean().sort_values()
low = gm.index[:8]
rows = []
for v in low:
    x = h3[h3.virus==v].pivot_table(index=['arm','pid'], columns='tp', values='log2t').reset_index().assign(m=lambda z:(z.arm=='mRNA-1010').astype(int))
    fit = smf.ols('d29 ~ m + d0', x).fit(); ci = fit.conf_int().loc['m']
    rows.append(dict(virus=v, GMT_d29_Fluarix=2**x[x.m==0].d29.mean(), GMT_d29_mRNA=2**x[x.m==1].d29.mean(),
                     ratio_unadj=2**(x[x.m==1].d29.mean()-x[x.m==0].d29.mean()), ratio_adj=2**fit.params['m'], adj_CI=f'{2**ci[0]:.2f}-{2**ci[1]:.2f}'))
md = pd.DataFrame(rows); print('\nMost antigenically advanced H3N2 isolates (lowest pooled d29 GMT):'); print(md.round(2).to_string())
md.round(3).to_csv(f'{OUT}/seqneut_most_drifted_H3N2.csv', index=False)

# (c) bead array
rows = []
for f, sub in [('binding_breadth_h1.csv','H1'), ('binding_breadth_h3.csv','H3')]:
    b = pd.read_csv(f'{IN}/{f}')
    for s, x in b.groupby('strain', sort=False):
        a = x[x.arm=='mRNA-1010'].log2_fold_change_mfi; fl = x[x.arm=='Fluarix'].log2_fold_change_mfi
        rows.append(dict(subtype=sub, strain=s, n_mRNA=len(a), n_Flu=len(fl), GMFR_mRNA=2**a.mean(), GMFR_Flu=2**fl.mean(),
                         ratio=2**(a.mean()-fl.mean()), MWU_p=stats.mannwhitneyu(a, fl).pvalue))
bb = pd.DataFrame(rows); print('\nBead-array binding breadth (log2 MFI fold-change, presumed wk4/wk0):'); print(bb.round(3).to_string())
bb.round(4).to_csv(f'{OUT}/bead_array_binding_breadth_by_strain.csv', index=False)
