"""Sensitivity analyses for the key functional-breadth comparisons (sequencing-based neutralisation)."""
import pandas as pd, numpy as np, statsmodels.formula.api as smf
exec(open('/tmp/outputs/analysis/00_common.py').read())
d = load_seqneut()
rows = []
def ancova(x, post='d29', label=''):
    x = x.assign(m=(x.arm=='mRNA-1010').astype(int)).dropna(subset=['d0', post])
    f = smf.ols(f'{post} ~ m + d0', x).fit(); ci = f.conf_int().loc['m']
    return 2**f.params['m'], 2**ci[0], 2**ci[1], len(x)
for st in ['H3N2','H1N1']:
    sub = d[(d.subtype==st) & (d.category=='forward-drift isolate (2022-2024)')]
    g = sub.groupby(['arm','pid','tp']).log2t.mean().unstack('tp').reset_index()
    r = ancova(g); rows.append((st, 'primary: participant-mean ANCOVA, d29', *r))
    # (a) linear mixed model on per-virus values: d29 ~ arm + d0 (per virus) + virus FE, random intercept participant
    w = sub.pivot_table(index=['arm','pid','virus'], columns='tp', values='log2t').reset_index().dropna(subset=['d0','d29'])
    w['m'] = (w.arm=='mRNA-1010').astype(int)
    mm = smf.mixedlm('d29 ~ m + d0 + C(virus)', w, groups=w['pid']).fit()
    b = mm.params['m']; se = mm.bse['m']; rows.append((st, 'mixed model per virus (participant random intercept), d29', 2**b, 2**(b-1.96*se), 2**(b+1.96*se), w.pid.nunique()))
    # (b) exclude participants whose titres FELL after vaccination (possible recent pre-enrolment infection): 397-009 (Fluarix), 397-028 (mRNA)
    r = ancova(g[~g.pid.isin(['397-009','397-028'])]); rows.append((st, 'excl. 397-009 & 397-028 (falling titres post-dose)', *r))
    # (c) late = d181 only
    g181 = sub[sub.day.isin([0,29,181])].groupby(['arm','pid','tp']).log2t.mean().unstack('tp').reset_index()
    r = ancova(g181, post='late'); rows.append((st, 'late, d181 only', *r))
    # (d) no baseline adjustment, fold-rise comparison (what a naive GMFR comparison shows)
    gg = g.assign(fr=g.d29-g.d0)
    a = gg[gg.arm=='mRNA-1010'].fr; f_ = gg[gg.arm=='Fluarix'].fr
    rows.append((st, 'naive GMFR ratio (no adjustment) - biased by baseline imbalance', 2**(a.mean()-f_.mean()), np.nan, np.nan, len(gg)))
out = pd.DataFrame(rows, columns=['subtype','analysis','ratio_mRNA_over_Fluarix','CI_low','CI_high','n'])
pd.set_option('display.width', 250); print(out.round(2).to_string())
out.round(3).to_csv(f'{OUT}/seqneut_sensitivity_analyses.csv', index=False)
