"""Per-virus sequencing-neutralisation summary (GMTs, baseline-adjusted ratio, fold-rise) with virus category."""
import pandas as pd, numpy as np, statsmodels.formula.api as smf
from scipy import stats
exec(open('/tmp/outputs/analysis/00_common.py').read())
d = load_seqneut(); rows = []
for v, x in d.groupby('virus'):
    w = x.pivot_table(index=['arm','pid'], columns='tp', values='log2t').reset_index().assign(m=lambda z:(z.arm=='mRNA-1010').astype(int))
    w2 = w.dropna(subset=['d0','d29']); f = smf.ols('d29 ~ m + d0', w2).fit(); ci = f.conf_int().loc['m']
    a, fl = w2[w2.m==1], w2[w2.m==0]
    rows.append(dict(virus=v, subtype=v[-4:], category=x.category.iloc[0],
        GMT_d0_Flu=2**fl.d0.mean(), GMT_d0_mRNA=2**a.d0.mean(), GMT_d29_Flu=2**fl.d29.mean(), GMT_d29_mRNA=2**a.d29.mean(),
        GMFR_Flu=2**(fl.d29-fl.d0).mean(), GMFR_mRNA=2**(a.d29-a.d0).mean(),
        ratio_d29_unadj=2**(a.d29.mean()-fl.d29.mean()), ratio_d29_adj=2**f.params['m'], CI_low=2**ci[0], CI_high=2**ci[1],
        pct4x_Flu=((fl.d29-fl.d0)>=2).mean()*100, pct4x_mRNA=((a.d29-a.d0)>=2).mean()*100, n_Flu=len(fl), n_mRNA=len(a)))
r = pd.DataFrame(rows).sort_values(['subtype','category','virus'])
r.round(3).to_csv(f'{OUT}/seqneut_per_virus_summary.csv', index=False)
print(r.groupby(['subtype','category']).agg(n_viruses=('virus','size'), median_ratio_adj=('ratio_d29_adj','median'),
      n_CI_excludes_1_above=('CI_low', lambda v: (v>1).sum())).round(2))
