"""Monoclonal antibody binding panels: donor-level summaries (the donor, not the mAb, is the unit of replication)."""
import pandas as pd, numpy as np
IN='/tmp/world/filesystem'; OUT='/tmp/outputs'
pd.set_option('display.width',250)
m = pd.read_csv(f'{IN}/mab_binding_panels.csv'); m['donor'] = m.mab_id.str.split('.').str[1]
print('mAbs per panel/arm/donor:'); print(m.groupby(['panel','arm','donor']).mab_id.nunique().unstack(['panel']).fillna(0).astype(int))
print('negative control (SARS-CoV-2 RBD) values:', m[m.antigen=='SARS-CoV-2 RBD'].fold_over_control.unique())
rows = []
for thr in [5, 10, 20]:
    x = m[m.antigen!='SARS-CoV-2 RBD'].assign(b=lambda z: z.fold_over_control >= thr)
    t = x.groupby(['panel','arm','donor','antigen']).b.mean().mul(100).rename('pct_binding').reset_index(); t['threshold'] = thr
    rows.append(t)
    pooled = x.groupby(['panel','arm','antigen']).b.mean().mul(100).rename('pct_binding').reset_index(); pooled['donor'] = 'POOLED'; pooled['threshold'] = thr
    rows.append(pooled)
r = pd.concat(rows)
r.round(1).to_csv(f'{OUT}/mab_binding_by_donor.csv', index=False)
show = r[(r.threshold==10) & r.antigen.isin(['A/Hong Kong/1/1968','A/Shanghai/1/2013 (H7)','A/Hubei/1/2010 (H5)','A/Croatia/10136RV/2023','A/Netherlands/01317/2025','A/California/04/2009'])]
print(show.pivot_table(index=['arm','donor'], columns='antigen', values='pct_binding').round(0).to_string())
