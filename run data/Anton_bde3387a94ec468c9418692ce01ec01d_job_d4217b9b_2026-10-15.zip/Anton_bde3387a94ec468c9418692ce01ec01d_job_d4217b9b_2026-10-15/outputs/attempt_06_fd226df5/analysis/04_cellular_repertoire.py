"""Lymph-node / cellular / repertoire files: descriptive summaries and integrity checks."""
import pandas as pd, numpy as np
from scipy import stats
IN='/tmp/world/filesystem'; OUT='/tmp/outputs'
pd.set_option('display.width',250)

# ---------------- GC file: header once, but two stacked blocks with identical keys
gc = pd.read_csv(f'{IN}/gc_frequencies.csv', dtype={'participant':str})
gc['block'] = (gc.index >= len(gc)//2).astype(int) + 1
dup = gc.duplicated(['timepoint','arm','participant'], keep=False)
print(f'gc_frequencies.csv: {len(gc)} rows; rows with duplicated (timepoint, arm, participant) keys: {dup.sum()}')
print('timepoints present:', sorted(gc.timepoint.unique()), '| FNA schedule in trial_summary: wk1, wk2, wk4, wk8, wk17, wk26 (no wk0)')
for b, x in gc.groupby('block'):
    t = x.groupby(['timepoint','arm']).pct_ha_specific_igg_gc.agg(['count','median','min','max']).unstack('arm')
    print(f'\n-- block {b} (label in header: pct_ha_specific_igg_gc)'); print(t.round(2).to_string())
b1 = gc[gc.block==1]
for tp in ['wk2','wk8','wk17','wk26']:
    a = b1[(b1.timepoint==tp)&(b1.arm=='mRNA-1010')].pct_ha_specific_igg_gc; f = b1[(b1.timepoint==tp)&(b1.arm=='Fluarix')].pct_ha_specific_igg_gc
    print(f'block1 {tp}: mRNA median {a.median():.1f}% (n={len(a)}) vs Fluarix {f.median():.1f}% (n={len(f)}); MWU p={stats.mannwhitneyu(a,f).pvalue:.3f}')

# ---------------- plasmablasts
pb = pd.read_csv(f'{IN}/plasmablast_frequencies.csv', dtype={'participant':str})
print('\nplasmablast_frequencies.csv timepoints:', sorted(pb.timepoint.unique()), '| blood schedule: d0, d7(wk1), d29(wk4), d121(wk17), d181(wk26)')
print(pb.groupby(['timepoint','arm']).pct_plasmablast.agg(['count','median','max']).unstack('arm').round(3).to_string())
fna_ids = set(gc.participant)
print('participants in PB file but not in FNA cohort:', sorted(set(pb.participant)-fna_ids))
# precision heterogeneity (hint of merged sources)
pb['decimals'] = pb.pct_plasmablast.astype(str).str.split('.').str[1].str.len()
print('PB value precision (decimals) by participant group:')
pb['grp'] = np.where(pb.participant.isin(fna_ids), 'FNA-cohort IDs', 'other IDs')
print(pb[pb.pct_plasmablast>0].groupby('grp').decimals.describe()[['min','50%','max']])

# ---------------- PB-GC clonal overlap
ov = pd.read_csv(f'{IN}/pb_gc_clonal_overlap.csv')
ov['arm'] = np.where(ov.Participant.isin(['397-06','397-17','397-28','397-29']), 'mRNA-1010', 'Fluarix')
print('\n', ov[['Participant','arm','Number of GC B cell sequences','Number of GC B cell clones','Percentage of overlapping clones out of GC B cell clones']].to_string(index=False))

# ---------------- repertoire / serum clonotypes (no participant IDs supplied)
rc = pd.read_csv(f'{IN}/repertoire_clonotype_counts.csv')
print('\nrepertoire_clonotype_counts (no participant IDs; no timepoint):')
print(rc.groupby(['metric','arm']).value.agg(['count','mean','median','min','max']).round(1).to_string())
sc = pd.read_csv(f'{IN}/serum_igg_clonotypes.csv'); cd = pd.read_csv(f'{IN}/cdrh3_diversity_index.csv')
print(sc.groupby(['timepoint','arm']).n_clonotypes.agg(['count','median']).unstack('arm').to_string())
print(cd.groupby(['timepoint','arm']).diversity_index.agg(['count','median']).unstack('arm').round(1).to_string())
a = rc[(rc.metric=='pct_pre_existing_abundance')]
print('pre-existing clonotypes share of post-vaccination serum IgG abundance: mRNA mean %.1f%%, Fluarix mean %.1f%%, MWU p=%.2f' % (
      a[a.arm=='mRNA-1010'].value.mean(), a[a.arm=='Fluarix'].value.mean(),
      stats.mannwhitneyu(a[a.arm=='mRNA-1010'].value, a[a.arm=='Fluarix'].value).pvalue))
v = rc[rc.metric=='n_vaccine_elicited_clonotypes']
print('vaccine-elicited clonotypes: mRNA median %.0f, Fluarix median %.0f, MWU p=%.3f' % (v[v.arm=='mRNA-1010'].value.median(), v[v.arm=='Fluarix'].value.median(),
      stats.mannwhitneyu(v[v.arm=='mRNA-1010'].value, v[v.arm=='Fluarix'].value).pvalue))

# ---------------- IgM
igm = pd.read_csv(f'{IN}/igm_fold_change.csv', dtype={'participant':str})
print('\nIgM fold-change: participants per arm', igm.groupby('arm').participant.nunique().to_dict(), '(trial_summary lists 38/37 for "Binding antibody (ELISA, IgM)")')
print('non-zero-padded IDs in IgM file:', sorted(set(igm.participant[~igm.participant.str.match(r'^\d{3}$')])))
print((np.exp(igm.assign(l=np.log(igm.fold_change)).groupby(['antigen','arm']).l.mean())).unstack('arm').round(2))
