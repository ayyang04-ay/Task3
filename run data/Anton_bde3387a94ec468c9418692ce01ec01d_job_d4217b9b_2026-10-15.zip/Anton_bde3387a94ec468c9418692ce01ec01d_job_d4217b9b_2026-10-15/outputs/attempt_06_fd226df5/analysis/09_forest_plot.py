"""Forest plot: mRNA-1010 / Fluarix ratios (baseline-adjusted where a baseline exists) for binding vs functional readouts."""
import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from scipy import stats
OUT='/tmp/outputs'; IN='/tmp/world/filesystem'
ser = pd.read_csv(f'{OUT}/serology_arm_comparison_ancova.csv')
sq = pd.read_csv(f'{OUT}/seqneut_category_ancova.csv')
rows = []
def ci(s): a,b = s.split('-'); return float(a), float(b)
for _, r in ser.iterrows():
    lo, hi = ci(r.wk4_adj_CI); rows.append(('Binding' if 'ELISA' in r.readout else 'Function', f'{r.readout} (wk4)', r.wk4_ratio_adj, lo, hi))
    lo, hi = ci(r.late_adj_CI); rows.append(('Binding' if 'ELISA' in r.readout else 'Function', f'{r.readout} (wk17/26)', r.late_ratio_adj, lo, hi))
keep = ['forward-drift isolate (2022-2024)','historical (<=2020)','H3 2022/23 vaccine strain','H1 5a.2 (Fluarix-2022/23-like)','H1 5a.2a.1 (documented mRNA-1010 H1-like)']
for _, r in sq[sq.category.isin(keep)].iterrows():
    lo, hi = ci(r.d29_adj_CI); rows.append(('Function', f'SeqNeut {r.subtype} {r.category} (d29)', r.d29_ratio_adj, lo, hi))
    lo, hi = ci(r.late_adj_CI); rows.append(('Function', f'SeqNeut {r.subtype} {r.category} (d121/181)', r.late_ratio_adj, lo, hi))
# bead array: Welch CI on difference of mean log2 fold-change (no baseline values supplied)
for f, sub in [('binding_breadth_h1.csv','H1'), ('binding_breadth_h3.csv','H3')]:
    b = pd.read_csv(f'{IN}/{f}')
    a = b[b.arm=='mRNA-1010'].groupby('participant').log2_fold_change_mfi.mean(); fl = b[b.arm=='Fluarix'].groupby('participant').log2_fold_change_mfi.mean()
    t = stats.ttest_ind(a, fl, equal_var=False); diff = a.mean()-fl.mean(); c = t.confidence_interval()
    rows.append(('Binding', f'Bead-array {sub} panel mean fold-rise (wk4, unadjusted)', 2**diff, 2**c.low, 2**c.high))
df = pd.DataFrame(rows, columns=['class','readout','ratio','lo','hi'])
df.to_csv(f'{OUT}/forest_plot_data.csv', index=False)
df = df.iloc[::-1].reset_index(drop=True)
fig, ax = plt.subplots(figsize=(11, 0.32*len(df)+1.5))
col = {'Binding':'tab:orange','Function':'tab:blue'}
for i, r in df.iterrows():
    ax.plot([r.lo, r.hi], [i, i], color=col[r['class']], lw=2); ax.plot(r.ratio, i, 'o', color=col[r['class']])
ax.axvline(1, color='k', lw=0.8); ax.set_xscale('log', base=2)
ax.set_yticks(range(len(df))); ax.set_yticklabels(df.readout, fontsize=7)
ax.set_xlabel('mRNA-1010 / Fluarix ratio, 95% CI (baseline-adjusted where a baseline exists)', fontsize=8)
ax.set_title('WU397: binding (orange) vs functional (blue) antibody readouts', fontsize=10)
plt.tight_layout(); plt.savefig(f'{OUT}/forest_binding_vs_function.png', dpi=150)
print(df.round(2).to_string())
