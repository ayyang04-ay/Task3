**One-line recommendation:** Make the next protocol a randomized, observer-blind, strain-matched Phase 2 (mRNA-1010 vs same-season licensed vaccines, adults 18–64 and ≥65) gated on baseline-adjusted neutralizing breadth against wild-type, forward-drifted H3N2 and H1N1 viruses at day 29 and day 181. Only if that succeeds, run an event-driven relative-efficacy trial with a pre-specified endpoint of RT-PCR-confirmed influenza caused by antigenically mismatched strains. WU397 shows more binding antibody and germinal-centre activity with mRNA-1010, but no broader H3N2 neutralization and only a transient ~2× H1N1 edge, so it cannot yet carry a heterologous-protection claim.

---

## 0. The claim, and what can support it

The claim to test is: *mRNA-1010 protects better than a licensed comparator against influenza illness caused by strains that are antigenically mismatched to the vaccine.*

- **Only a clinical endpoint can establish "protection".** There is no validated immune correlate for heterologous protection. HAI ≥1:40 is a correlate only for strains that match the vaccine.
- **Immunogenicity can justify the efficacy trial, but it cannot replace it.**
- WU397 is a first-in-class immunogenicity study. It was:
  - non-randomised, with arms assigned by enrolment site;
  - open-label;
  - small (functional-assay cohorts were 13–15 per arm);
  - without clinical endpoints.

  [TS = `trial_summary.md`]

---

## 1. What WU397 does and does not show

All ratios below are mRNA-1010 / Fluarix. Where a baseline exists, ratios are baseline-adjusted (ANCOVA on log titres). Ranges are 95% CIs. Ledger IDs (N##) point to §4. `forest_binding_vs_function.png` plots every ratio.

| Question | Answer | Key numbers |
|---|---|---|
| More binding antibody? | **Yes**, especially for A strains | ELISA IgG at week 4: H1 2.66× (2.01–3.53), H3 3.31× (2.47–4.43) (N20–N21). Bead-array fold-rise for H3 strains was 3.5–10.1× higher (N24). |
| More germinal-centre (GC) activity? | Yes, but only 6 vs 11 participants and the file has integrity problems | HA-specific GC B cells at week 2: median 24.2% vs 2.3% (p=0.037) (N30) |
| Better HAI (the accepted correlate)? | **No** (an H1 trend at week 4 that is gone by week 17/26) | Week 4: H1 1.54× (0.87–2.71), H3 1.06× (0.67–1.65), B/Vic 1.05×, B/Yam 1.01×. Week 17/26: H1 0.83×, H3 0.92× (N10–N13) |
| Broader neutralization of forward-drifted **H3N2** (the subtype that drifts most)? | **No signal** | 66 isolates from 2022–2024, day 29: 1.18× (0.65–2.13); late visit 1.05× (0.66–1.68). None of the 66 viruses has a per-virus CI lying entirely above 1 (N40–N44). The five most drifted viruses: unadjusted 0.80–0.86×, adjusted 0.94–1.21× (N44). Against mRNA-1010's own H3 antigen (A/Darwin/6/2021): 0.62× (0.34–1.12) (N45). |
| Broader neutralization of forward-drifted **H1N1**? | **~2× at day 29, not durable** | Six 2023 isolates: 2.06× (1.23–3.46). This falls to 1.17× (0.77–1.77) by day 121/181. By the late visit, mRNA-1010 titres were 43% of their day-29 level vs 76% for Fluarix (N46–N48). |
| Does the extra binding antibody neutralize? | **Mostly not, for H3** | Same participants: H3 ELISA rise 8.0× vs neutralization rise 2.2–2.8× and HAI rise 1.57×. That is a "neutralization yield" of 0.20–0.35, vs 0.77–1.25 for Fluarix (N50–N51). |
| Were the arms comparable? | **No** | Non-random allocation. Baseline heterologous MN titre in the mRNA-1010 arm was 0.47× Fluarix's (N14). Baseline H3N2 neutralization was 0.66× (N41). The H1 antigens differ on paper (N01–N02). |
| Any clinical endpoint or infection ascertainment? | **None** | (N00) |

**Bottom line:** WU397 supports "more HA-binding antibody and more GC activity". It does not support "broader functional antibody", and it cannot speak to protection. Even so, it does **not exclude** a modest H3N2 breadth benefit: the upper 95% bound is 2.13×. That is why a properly designed Phase 2 is the right next step, rather than either abandoning the claim or going straight to efficacy.

---

## 2. Recommended next studies

**Overview**

| | Purpose | In whom | Against what (comparator) | Decisive readout | Size | Decision it feeds |
|---|---|---|---|---|---|---|
| **Step 0** (now) | Make WU397 interpretable | Existing data and records | — | Verified composition and antigen identities; corrected records | — | Finalises the Study 1 panels and strains |
| **Study 1** (next protocol) | Test whether breadth is real and durable | Adults 18–64 and ≥65, randomized within site | Same-season egg IIV (Fluarix) and sequence-matched recombinant HA; preferred vaccine for ≥65 | Baseline-adjusted neutralizing-breadth GMT ratio vs wild-type forward-drift panel, H3N2 first, at day 29 and day 181 | ~900–1,080 | Go / limited / no-go for a heterologous endpoint |
| **Study 2** (optional) | Early direct protection signal | Healthy 18–45, low titre to challenge strain | Phase 3 comparator and placebo; antigenically drifted challenge virus | Laboratory-confirmed symptomatic infection | ~60–90 per arm | De-risks Study 3; correlates |
| **Study 3** (claim-enabling) | Show protection against mismatched strains | Adults ≥50 (50–64, ≥65) | Age-appropriate licensed vaccine, same season | rVE against RT-PCR-confirmed influenza caused by antigenically mismatched strains (key secondary, event-driven) | ~500–850 mismatched events | Label claim |

### Step 0 — Resolve these before the protocol goes to committee (no new participants)

1. **Confirm what mRNA-1010 actually encoded, especially the H1.**
   - The summary lists A/Victoria/4897/2022 (clade 5a.2a.1). Fluarix 2022–23 contained A/Victoria/2570/2019 (clade 5a.2) (E1–E2).
   - The data fit a 5a.2 immunogen better than the documented one. In 12 of 13 mRNA-1010 recipients, the titre rise to the 5a.2 strain A/Wisconsin/588/2019 was larger than the rise to the 5a.2a.1 strain A/Wisconsin/67/2022 (geometric-mean ratio 1.75; p=0.0034). This skew is stronger than in the Fluarix arm (9/14; 1.38; p=0.049 between arms), even though Fluarix *did* contain a 5a.2 H1.
   - Monoclonal antibodies from mRNA-1010 donors bound A/Wisconsin/588/2019 1.9–4.2× better than A/Victoria/4897/2022 (N52–N54). The mAb selection criteria are not documented; if the mAbs were isolated with an A/Wisconsin/588/2019 probe, this point is uninformative.
   - So there are two possibilities:
     - the documented composition is wrong and a 5a.2 H1 was given; or
     - it is right, and the skew reflects strong back-boosting of 5a.2 memory. In that case every H1 comparison confounds platform with a newer antigen.
   - Check against the lot's release documentation.
2. **Identify the test antigens.**
   - The MN "homologous" and "heterologous" viruses and the HAI and ELISA antigens are not named.
   - Both MN readouts behave like H3N2 readouts. Their mean summed Spearman ρ (baseline ρ + fold-rise ρ, range −2 to 2) with the sequencing-panel viruses was 0.68–0.70 for H3N2 vs −0.16 to 0.05 for H1N1 (N55). This is a hypothesis only.
   - The panels are defined relative to mRNA-1010's antigens only. So for Fluarix recipients, the "homologous" H1 readout is heterologous.
3. **Fix the records the committee will see.**
   - Late-visit labels conflict across assays for 9 participants.
   - `gc_frequencies.csv` contains two unlabelled stacked blocks.
   - Plasmablast timepoints (weeks 2 and 8) do not match the blood-draw schedule.
   - The IgM cohort is 15/14, not the listed 38/37.
   - Full list in §3.6 (N60–N68).
4. **Add the missing covariates:** age, sex, prior-season vaccination history, enrolment dates, site, and any influenza illness during follow-up. None are in the package. ID ranges 033–059 (Fluarix only) and 064–102 (mRNA-1010 only) suggest the two arms were partly enrolled in different windows (N62).
5. **Optional, hypothesis-generating only:** add neuraminidase-inhibition, HA-stalk IgG and Fc-effector readouts on banked WU397 sera. This would show whether the non-neutralizing binding surplus is functional, which decides whether an Fc readout belongs among the Phase 2 key endpoints. Because WU397 was non-randomised, this cannot support the claim.

### Study 1 — Phase 2 gating study (the protocol to take to committee)

**Title:** Randomized, observer-blind, active-controlled, strain-matched study of functional antibody breadth and durability of mRNA-1010 vs licensed influenza vaccines in adults.

**Conditions**

| Element | Specification | Why (WU397 evidence) |
|---|---|---|
| Allocation | Central randomization **within site**. Stratify by age band (18–49, 50–64, ≥65) and prior-season vaccination (yes/no). | Site allocation confounded arm with site and enrolment window. Baseline MN heterologous titre was 0.47× and baseline H3N2 neutralization 0.66× in the mRNA-1010 arm (N14, N41). FNA and sample-handling differences by site were inseparable from arm. |
| Blinding | Observer-blind: participants, assessors and the central laboratory are blinded to arm. | WU397 was open-label. |
| Season / timing | One Northern-Hemisphere season. Vaccinate before sustained local influenza activity, and close enrolment at activity onset. | Two participants (397-009, 397-028) had high baseline H3 titres that *fell* after dosing, e.g. A/Darwin/6/2021 957→381 and 1397→742. That pattern is consistent with, but not proof of, a recent pre-enrolment infection (N43, N58). |
| Composition | **Trivalent** (H1N1pdm09, H3N2, B/Victoria) per the WHO recommendation for that season. mRNA-1010 encodes the cell/recombinant-recommended HA sequences. Comparators use the same season's licensed formulation. Lock encoded sequences and lot composition in the protocol. | H1 antigens differed between arms on paper (N01–N02). B/Yamagata is no longer recommended (E3). |
| Arms, 18–64 y (1:1:1) | **A** mRNA-1010; **B** egg-based standard-dose split IIV (Fluarix: bridges to WU397 and is the planned Phase 3 comparator for this age); **C** recombinant-HA vaccine (its HA sequences match the cell/recombinant recommendation, so it is sequence-matched to A). | C separates a platform effect from egg-adaptation and strain-version effects. In WU397, egg reassortants read 1.3–7.5× higher than their wild-type twins in both arms (N49). |
| Arms, ≥65 y (1:1, optional third arm) | **A** mRNA-1010; **C** recombinant-HA vaccine (preferentially recommended for ≥65 and sequence-matched). Optional **D**: high-dose or adjuvanted egg-based IIV. | A heterologous-superiority claim in ≥65 is only meaningful against the preferred standard of care. |
| Eligibility | Community-dwelling adults. Exclude: current-season influenza vaccine; laboratory-confirmed influenza in the prior 6 months; immunosuppression; prior investigational influenza mRNA vaccine. Record 5-season vaccination history (registry-verified where possible) and comorbidities. | Pre-existing immunity dominates: 43–93% had baseline HAI ≥1:40, depending on strain and arm (N15). Pre-existing clonotypes made up 84–86% of post-dose serum IgG in both arms (N33). |
| Size | **~180 randomized per arm per age stratum (≈160 evaluable).** That is ~540 (18–64) + ~360 (≥65) ≈ 900 (≈1,080 with arm D). | See N70–N73 for the power basis. |
| Visits | Day 0, 29 (peak) and 181 (end of season); day 91 optional. Active surveillance for influenza-like illness (ILI) to day 181, with RT-PCR and HA sequencing of cases. | The H1 advantage disappeared by day 121/181 (N47), so durability has to be a primary endpoint. Infections during follow-up must be identifiable. |

**Power basis for the sample size:**
- WU397's residual SD for the participant-level breadth score was 0.94–1.02 log2 (N70).
- With that SD inflated by 15%, detecting a 1.5× breadth ratio per subtype at 90% power and two-sided α=0.025 needs 101 evaluable per arm (N71).
- HAI GMT non-inferiority (SD 1.6, margin 1.5, 90% power) needs 158 per arm (N72).
- HAI seroconversion non-inferiority would need ~505 per arm, so it is descriptive here (N73).

**Readouts: what, in whom, against what, when**

| Tier | What is measured | In whom | Against what | When | Analysis / success |
|---|---|---|---|---|---|
| **Primary 1 (breadth)** | Neutralizing antibody titre; breadth GMT = each participant's geometric mean across the panel | All randomized (per-protocol immunogenicity set; modified-ITT sensitivity) | **Forward-drift panel** (spec below), **H3N2 first, then H1N1** (hierarchical) | Day 29 | ANCOVA on log breadth GMT, adjusted for baseline breadth, age band, prior vaccination and site. **Success: lower bound of 95% CI of GMT ratio (A/comparator) >1.0 and point estimate ≥1.5.** Primary contrast is A vs the planned Phase 3 comparator in each stratum (B in 18–64, C in ≥65). A vs C in 18–64 is the key mechanistic contrast. |
| **Primary 2 (durability)** | Same | Same, excluding participants with intercurrent infection (sensitivity: include them) | Same panel | Day 181 | Lower bound >1.0 |
| Key secondary (regulatory) | HAI titre: GMT and seroconversion | All | Each arm's own vaccine strains (for the egg-based comparator, both the egg-derived virus and the wild-type sequence) | Day 29 | Non-inferiority: upper bound of GMT ratio (comparator/A) ≤1.5; upper bound of seroconversion difference ≤10 points (E4) |
| Secondary | Proportion with ≥4-fold rise against ≥50% of panel viruses; per-virus GMT ratios; slope of titre vs antigenic distance | All | Forward-drift panel | Day 29 and 181 | Descriptive, with CIs |
| Secondary | HAI against drifted viruses | All | Forward-drift panel (H3N2, H1N1) | Day 29 and 181 | As Primary 1 |
| Secondary | **Neuraminidase-inhibiting (NAI) antibody** | All | N1 and N2 of vaccine strains and drifted strains | Day 0, 29, 181 | GMT ratio. mRNA-1010 is described as encoding four antigens with no NA mentioned, while split-virion IIV carries NA. NA immunity protects independently and drifts more slowly, so a deficit here would count against a heterologous claim. |
| Exploratory (mechanism) | HA head- vs stalk-specific IgG; Fc-effector functional antibody; multiplex binding breadth; HA-specific T cells | Random subset, ~50 per arm per stratum | Vaccine HAs, drifted HAs, group 1/2 stalk | Day 0, 29, 181 | Tests whether mRNA-1010's extra binding antibody is functional. It is never counted as breadth on its own (N24, N50). |
| Secondary | Back-boost panel | All | Historical vaccine strains (~10–15 years) | Day 29 | Reported separately. Not counted as forward breadth. WU397's apparent H3 "breadth" to old strains was 1.63× (0.99–2.68) (N42). |
| Infection ascertainment | RT-PCR-confirmed ILI; HA sequence; serological evidence of interim infection | All | — | To day 181 | Used to censor the durability analysis. Also feeds early titre–infection exploration. |
| Safety | Solicited reactions (7 days), unsolicited AEs (28 days), SAEs / AESIs / MAAEs | All | — | To day 181 | Descriptive |

**Forward-drift panel specification (the "against what")**

- **Wild-type HA sequences only.** No egg- or cell-propagated production reassortants. In WU397 these read 1.3–7.5× higher than their wild-type twins in both arms, and mRNA-1010's own documented H1 was represented only as an egg reassortant (N49).
- **Heterologous to every vaccine in the trial.** "Homologous" is defined per arm, against that arm's own strains. WU397's designations were relative to mRNA-1010 only.
- **Chosen by a rule written before enrolment**, per subtype:
  - at least 8 H3N2 and 6 H1N1 (plus ≥3 B/Victoria as secondary);
  - representatives of each HA subclade above a pre-set share of global sequences in the 6 months before enrolment;
  - subclades that emerge during the season;
  - the strains WHO selects for the **next** season's composition, chosen precisely because circulating viruses have drifted away from the current vaccine strain.
- **Antigenic distance to each vaccine strain** is recorded, and the panel is frozen before unblinding.
- WU397 illustration: the H3N2 strains WHO later chose as updated vaccine viruses (A/Thailand/8/2022, A/Massachusetts/18/2022; E5) showed:
  - ≥4-fold rises in 8% of mRNA-1010 vs 29–31% of Fluarix recipients;
  - adjusted ratios 0.82 and 0.90 (N56).

**Analysis rules (learned from WU397)**
- Use baseline-adjusted GMT ratios as primary. Do not use fold-rise or seroconversion alone: with unbalanced baselines they manufactured an apparent heterologous advantage (MN heterologous GMFR 4.12 vs 3.03, seroconversion 64% vs 40%, despite lower GMTs; N14, N16).
- Report titres without an upper cap in the expected range, and handle values beyond the limits as censored. The WU397 MN cap of 1280 truncated 9/15 Fluarix and 4/14 mRNA-1010 week-4 homologous values (N17).
- Fix visit windows (no pooled "wk17/26").
- Use a central laboratory blinded to arm.
- Freeze antigenic classifications before unblinding.

**Go / no-go into Study 3 with a heterologous endpoint**

- **GO:** H3N2 forward-drift breadth meets Primary 1 (lower bound >1.0, point ≥1.5) **and** Primary 2 (lower bound >1.0 at day 181) against the planned Phase 3 comparator in the target age stratum. HAI non-inferiority must also be met for all vaccine strains, and safety must be acceptable.
- **LIMITED:** Only H1N1 meets the criteria. Any claim is restricted to H1N1. Reconsider H3 antigen design before efficacy.
- **NO-GO:** Neither subtype meets the criteria. Drop the heterologous-protection positioning. Proceed, if at all, on a standard non-inferiority or overall-efficacy basis, or redesign the antigen (for example, adding NA or multi-clade H3). This is out of scope here.

### Study 2 — Heterologous controlled human-infection study (optional; supportive, not claim-enabling)

- **Purpose:** An early, direct read on *protection* against a mismatched virus, plus correlates, before committing to Study 3.
- **In whom:** Healthy adults aged 18–45, the standard challenge population. Pre-specified low pre-existing titre to the challenge strain; no current-season vaccine.
- **Arms:** mRNA-1010 vs the planned Phase 3 comparator vs placebo, 1:1:1, double-blind. Placebo recipients are offered licensed vaccine after the challenge phase.
- **Against what:** Challenge 4–8 weeks after vaccination with a characterized challenge virus of the same subtype as a vaccine component (H3N2 preferred). It must be antigenically distinct from that component by a pre-specified distance.
- **Primary endpoint:** Laboratory-confirmed symptomatic influenza, mRNA-1010 vs comparator.
- **Secondary endpoints:**
  - any laboratory-confirmed infection (shedding and/or seroconversion);
  - area under the curves for viral shedding and symptom score;
  - comparisons vs placebo for absolute protection;
  - pre-challenge correlates: neutralizing titre vs the challenge strain, HAI, NAI, stalk IgG, Fc-effector readouts.
- **Size:** ~60–90 per arm. This detects 50%→25% or 50%→30% symptomatic infection at 80% power (N74).
- **Limits:**
  - Young, low-titre, selected participants.
  - Available challenge strains tend to be older, so they test "backward" rather than "forward" drift.
  - Supportive only; cannot support the claim alone.

### Study 3 — Phase 3 event-driven relative-efficacy trial (the study that can support the claim)

| Element | Specification |
|---|---|
| Design | Randomized 1:1, observer-blind, active-controlled, multinational, event-driven. Runs over ≥2 seasons (or Northern plus Southern Hemisphere), because mismatch cannot be scheduled. |
| In whom | Adults ≥50, stratified 50–64 and ≥65, including stable chronic conditions. This is where burden is highest and current vaccines perform worst. A separate 18–49 cohort is optional. |
| Comparator | Age-appropriate licensed vaccine of the same season: preferentially recommended vaccine for ≥65; standard-dose IIV or recombinant-HA for 50–64. |
| Case definition | Protocol-defined ILI with RT-PCR-confirmed influenza, onset ≥14 days after vaccination through end of season, under active surveillance. |
| Primary endpoint | Relative vaccine efficacy (rVE) against any influenza A or B: non-inferiority, then superiority. |
| **Key secondary (claim-enabling, inside the multiplicity hierarchy)** | **rVE against influenza caused by antigenically mismatched strains.** Success: lower bound >0%. |
| Mismatch classification | Every case virus is HA-sequenced and antigenically characterized against the season's WHO reference vaccine strain. This common reference makes classification arm-agnostic. Mismatch = ≥8-fold reduced reactivity with reference antisera (≥4-fold as sensitivity). Pre-specified genetic-group rules apply when antigenic data are missing. Classification is by a central laboratory blinded to arm, with rules frozen before unblinding. |
| Secondary endpoints | rVE against matched strains and by subtype; medically attended influenza; influenza hospitalization; early- vs late-season rVE; sieve analysis (genetic distance of breakthrough viruses by arm). |
| Correlates sub-study | Case-cohort design: all cases plus a random subcohort. Day-29 HAI to vaccine strains; neutralization against the forward-drift panel and against the panel virus closest to each case virus; NAI; stalk IgG; Fc-effector readouts. Goal: a correlate for protection against mismatched strains, which would enable immunobridging for future strain updates. |
| Events / size | ~511 mismatched-strain events for true rVE 25%, ~847 for 20%, ~334 for 30% (90% power, one-sided α=0.025) (N75). That is roughly 27k–57k participant-seasons if attack rates are 2–3% with 50–70% of cases mismatched, and up to ~190k in low-attack, well-matched seasons (N76). Continue across seasons until the mismatched-event target or futility. |

**If the programme must skip Study 1:** keep the mismatched-strain endpoint as a pre-specified key secondary with event-driven extension. Embed the Study 1 breadth comparison as a randomized immunogenicity sub-study. Make no heterologous claim from immunogenicity alone.

### What not to do next
- **Another non-randomized or site-allocated comparison.**
- **Using binding or GC readouts as breadth endpoints.** The H3 binding surplus (3.3× ELISA, 3.5–10× bead array) did not translate into neutralization (N21, N24, N45, N50).
- **Fold-rise-only endpoints.**
- **Egg/production reassortants in breadth panels.**
- **Expanding lymph-node FNA or mAb work as the next step.**
  - It is mechanistic and does not test the claim.
  - WU397's mAb comparison rests on 4 vs 3 donors, and one Fluarix donor supplied 61/74 group-I and 25/34 group-II mAbs (N35).
- **B/Yamagata readouts (E3).**

---

## 3. Reasoning: interpretation of the WU397 data package

### 3.1 Design limits

- **Allocation and blinding:** non-randomised, by enrolment site; open-label; single dose.
- **Assay cohorts:** 13–15 per arm for HAI, MN, bead array and sequencing-based neutralization; 6 vs 11 for FNA (N00).
- **Missing context:** no demographics, no vaccination history, no infection surveillance.
- **Consequences:**
  - Arm is confounded with site, operator (FNA yields), sample handling and probably enrolment window (N62).
  - Any difference could come from who was enrolled where and when.

### 3.2 Antigens and panel definitions are asymmetric

- **H1:** By the documents, mRNA-1010 encoded A/Victoria/4897/2022 (5a.2a.1). That is WHO's 2023–24 egg-based H1. Fluarix 2022–23 contained A/Victoria/2570/2019 (5a.2) (N01; E1–E2). If true, every H1 comparison confounds platform with a newer antigen. The data pattern argues the encoded H1 may actually have been 5a.2 (Step 0, item 1; N52–N54). This must be resolved.
- **H3:** mRNA-1010 encodes A/Darwin/6/2021, the cell-recommended strain; Fluarix has the egg-based A/Darwin/9/2021. They are antigenically equivalent by WHO designation, but one is egg-adapted.
- **B:** Identical strains. B/Yamagata is obsolete (E3).
- **Panel designations:** "Homologous/heterologous" refer to mRNA-1010's antigens only (N01). For Fluarix recipients, the "homologous" H1 is heterologous.
- **Reassortants in the sequencing panel:**
  - Six production reassortants are included. They read higher than their wild-type twins in *both* arms: H3 pairs 1.3–6.2×; H1 IVR-238 vs A/Wisconsin/67/2022 5.3–7.5× (N49).
  - Including them inflates apparent breadth. In my categorisation they are analysed separately.

### 3.3 Functional antibody

- **HAI (14–15 per arm):**
  - Week-4 GMTs: H1 138.0 vs 87.7; H3 56.4 vs 57.9; B/Vic 56.5 vs 51.6; B/Yam 88.3 vs 98.6 (N10–N13).
  - Adjusted ratios: H1 1.54 (0.87–2.71), H3 1.06 (0.67–1.65), B/Vic 1.05 (0.71–1.56), B/Yam 1.01 (0.73–1.40). Late: H1 0.83, H3 0.92.
  - Seroconversion (≥4-fold): H1 50% vs 33%; H3 14% vs 13%; B 0–7%. Baseline HAI ≥1:40 was 43–93% (N15), i.e. a heavily pre-immune population.
- **MN (14–15 per arm; viruses unnamed):**
  - Heterologous, unadjusted: baseline GMT 57.1 vs 121.3 (ratio 0.47). Week 4: 234.9 vs 367.6. GMFR 4.12 vs 3.03. Seroconversion 64% vs 40%.
  - Heterologous, adjusted: week 4 1.17 (0.52–2.62); 1.13 (0.52–2.44) in the censored model. Late 0.73 (0.37–1.45) (N14, N16).
  - The apparent fold-rise advantage is a baseline artefact.
  - Homologous: week 4 325.4 vs 588.1; adjusted 0.68 (0.31–1.51); censored model 0.47 (0.15–1.51). 9/15 Fluarix values sat at the 1280 cap (N17).
- **Sequencing-based neutralization (13 vs 14; 96 viruses; 7,719 titres):**
  - **H3N2 forward-drift (66 isolates, 2022–2024):**
    - GMT: baseline 142 vs 214 (0.66×); day 29 401 vs 463 (unadjusted 0.87, 0.44–1.69).
    - Adjusted 1.18 (0.65–2.13), p=0.58. Mixed model 1.07 (0.63–1.83). Excluding two falling-titre participants 1.28 (0.68–2.40). Day 181 only 0.99 (0.59–1.66) (N40–N43).
    - Per virus: median 1.15 (range 0.82–1.52); 0/66 with lower bound >1.
    - ≥4-fold rise on ≥50% of the panel: 3/13 vs 3/14 participants (N57).
    - Most-drifted isolates (BC/RV00920/2023, Shaanxi-Yuyang/1204/2024, DC/27/2023, Lisboa/124/2024, Oman/CPHL_7248310/2024): unadjusted 0.80–0.86, adjusted 0.94–1.21, all CIs spanning 1 (N44). To my knowledge, DC/27/2023 later became a cell-based H3N2 vaccine strain (E5).
    - Against mRNA-1010's own H3 antigen (A/Darwin/6/2021): day 29 GMT 244 vs 482, adjusted 0.62 (0.34–1.12) (N45).
  - **H1N1 forward-drift (6 isolates, 2023):**
    - Day 29 GMT 478 vs 257; adjusted 2.06 (1.23–3.46). All 6 viruses have lower bound >1.
    - Median participant has ≥4-fold rises to 50% of the panel vs 0% in Fluarix (p=0.006).
    - By day 121/181 the ratio is 1.17 (0.77–1.77); day 181 only 1.14 (0.68–1.94). mRNA-1010 titres kept 43% of peak vs 76% for Fluarix (p=0.001); late GMTs 207 vs 196 (N46–N48).
    - The edge covers old and new H1s alike: 5a.2 strain 2.44×, 5a.2a.1 strain 2.07×, historical 1.69×. That looks like a magnitude effect, not targeted forward breadth.
  - **Back-boosting:** Historical H3 strains were 1.63× (0.99–2.68) (N42). Rising titres to old strains is imprinting recall, not protection against future drift.

### 3.4 Binding antibody overstates function

- **ELISA IgG (38 vs 37):**
  - GMFR: H1 5.07 vs 1.90; H3 7.60 vs 1.99 (N20–N21).
  - Adjusted: H1 2.66 (2.01–3.53), H3 3.31 (2.47–4.43); B/Vic 1.35, B/Yam 1.38.
  - Late: H1 1.51, H3 2.06, B ≈1.0 (N20–N23).
- **Bead array (presumed week 4):**
  - H3 strains: mRNA-1010 GMFR 4.1–31.9 vs Fluarix 1.2–4.3 (ratio 3.5–10.1; e.g. A/Hong Kong/1/1968 9.5×, A/Thailand/8/2022 9.4×).
  - H1 strains: ratio 1.26–2.70 (N24).
- **Same-participant comparison (N50–N51):**
  - In Fluarix recipients, binding and neutralization rise together: yield 0.77–1.25; Spearman ρ=0.75 for H3.
  - In mRNA-1010 recipients, an 8.0× H3 binding rise produced only 1.57× HAI and 2.2–2.8× neutralization: yield 0.20–0.35; ρ=0.31, p=0.30.
  - Example: A/Thailand/8/2022 binding was 9.4× higher with mRNA-1010, yet neutralization was 0.82× (0.35–1.91) (N24, N56).
- **Reading:** the extra H3 antibody is largely non-neutralizing.
  - It could in principle protect through Fc-mediated mechanisms. WU397 did not measure these.
  - That is why Fc-effector, stalk and NAI readouts are in Study 1, and why only clinical or challenge endpoints can settle the question.

### 3.5 Cellular, monoclonal and repertoire data (mechanistic; small n)

- **GC B cells (block 1; 6 vs 11):**
  - Week 2 median 24.2% vs 2.3% (p=0.037).
  - Weeks 8, 17 and 26: 8.3 vs 1.7, 16.0 vs 2.3, 18.9 vs 1.6 (p=0.17, 0.083, 0.34) (N30).
  - The clonal-overlap file shows more GC B-cell sequences from mRNA-1010 donors: 13–302 vs 2–15 (N31).
- **Serum IgG repertoire (8 vs 8, unlinked to participants):**
  - Pre-existing clonotypes supplied 83.9% vs 86.2% of post-vaccination serum IgG abundance (p=0.72).
  - Vaccine-elicited clonotypes: median 32 vs 17.5 (p=0.066) (N33).
  - So the extra GC activity did not change the dominance of recalled antibody in serum.
- **IgM fold-change** was *higher* with Fluarix: geometric means 4.0–5.8 vs 1.6–2.1 (N34). This is not decision-relevant.
- **mAbs (donor-level):**
  - H3/group-II mAbs from mRNA-1010 donors more often bound A/Hong Kong/1/1968 (28–65% vs 0–16% of mAbs, ≥10× over control) and H7 (3–21% vs 0%).
  - Binding to the 2023/2025 strains was similar: pooled 48% vs 38% (H3 A/Croatia/10136RV/2023) and 91% vs 89% (H1 A/Netherlands/01317/2025).
  - With 4 vs 3 donors, and one Fluarix donor dominating, this is anecdotal and binding-only (N35–N36).

### 3.6 Data-integrity findings (from `data_integrity_issues.csv`)

- **Cohort sizes:**
  - The IgM file has 15/14 participants vs the 38/37 listed (N60).
  - HAI B/Vic is missing for 397-031.
  - Sequencing-based neutralization omits 397-014 and 397-019, with no reason given (N61).
- **Enrolment windows:** ELISA IDs 033–059 are Fluarix-only and 064–102 mRNA-1010-only (N62).
- **Late-visit labels** conflict across assays for 9 participants (N63):
  - HAI B/Vic labels are swapped for 8 of them;
  - the sequencing dataset labels 397-007 and 397-011 as day 121 where every other assay says week 26.
- **GC file:**
  - Every row's key is duplicated across two unlabelled blocks.
  - The timepoints include week 0, which is not in the FNA schedule, and omit weeks 1 and 4 (N64).
- **Plasmablast file:**
  - Timepoints (weeks 2 and 8) are not blood-draw visits.
  - Values of 1–5% at weeks 8–26 are implausible for circulating plasmablasts.
  - 11 participants are outside the FNA cohort, with different numeric precision (N65).
- **Unidentified antigens:** MN viruses and the HAI and ELISA antigens are unnamed; the bead-array timepoint is not stated (N66).
- **Censoring:** MN is capped at 1280; the sequencing assay has 171 values below and 70 above its limits (N17, N67).
- **Unlinkable repertoire files:** they carry no participant IDs (N68).

### 3.7 Net interpretation

- **Supported:** the mRNA platform drives larger binding-antibody and GC responses. There is a plausible, but transient, ~2× H1N1 neutralization magnitude advantage whose cause (platform vs antigen) is unresolved.
- **Not supported:** broader or more durable neutralization of drifted H3N2, or anything about protection.
- **Still open:** the data are too small and too confounded to exclude a modest H3N2 benefit (upper bound 2.13×).
- **Hence:** a randomized, strain-matched gating study with functional, forward-drift, durability-aware endpoints comes first. The clinical trial with a pre-specified mismatched-strain endpoint is the claim-enabling study.

---

## 4. Number ledger (every number used, and where it came from)

Input files are in `/tmp/world/filesystem/`. Scripts are in `/tmp/outputs/analysis/`, with logs in `/tmp/outputs/logs/`. Unless stated, ratios are mRNA-1010 / Fluarix and intervals are 95% CIs.

| ID | Number(s) | Meaning | Source → derivation → output |
|---|---|---|---|
| N00 | Non-randomised, open-label, site allocation; single IM dose; cohorts 38/37 (ELISA/IgM), 14/15 (HAI, bead array, MN), 13/14 (sequencing neutralization), 6/11 (FNA); blood at d0/7/29/121/181; FNA at weeks 1/2/4/8/17/26 | Study design | `trial_summary.md` |
| N01 | mRNA-1010 = A/Victoria/4897/2022, A/Darwin/6/2021, B/Austria/1359417/2021, B/Phuket/3073/2013; panels defined relative to these | Documented composition | `trial_summary.md` |
| N02 | Fluarix 2022–23 = A/Victoria/2570/2019, A/Darwin/9/2021, same B strains | Comparator composition | External, E1 (not in package) |
| N10 | HAI H1 week-4 GMT 138.0 vs 87.7; baseline 50.0 vs 39.0; adjusted 1.54 (0.87–2.71); late 0.83 (0.47–1.46); seroconversion 50% (27–73) vs 33% (15–58) | HAI H1 | `hai_titers.csv` → 02 → `serology_descriptive_by_arm.csv`, `serology_arm_comparison_ancova.csv` |
| N11 | HAI H3 week-4 GMT 56.4 vs 57.9; adjusted 1.06 (0.67–1.65); late 0.92 (0.60–1.41); seroconversion 14% vs 13% | HAI H3 | same |
| N12 | HAI B/Vic week-4 GMT 56.5 vs 51.6; adjusted 1.05 (0.71–1.56); late 1.06 | HAI B/Vic | same |
| N13 | HAI B/Yam week-4 GMT 88.3 vs 98.6; adjusted 1.01 (0.73–1.40); late 0.91 | HAI B/Yam | same |
| N14 | MN heterologous: baseline GMT 57.1 vs 121.3 (ratio 0.47); week 4 234.9 vs 367.6; GMFR 4.12 vs 3.03; seroconversion 64% vs 40%; adjusted 1.17 (0.52–2.62); late 0.73 (0.37–1.45) | MN heterologous | `microneutralization.csv` → 02 → same outputs |
| N15 | Baseline HAI ≥1:40: H1 86%/60%, H3 43%/67%, B/Vic 62%/80%, B/Yam 79%/93% (mRNA-1010/Fluarix) | Pre-existing immunity | `hai_titers.csv` → 02 → `serology_descriptive_by_arm.csv` |
| N16 | MN heterologous, censored-regression week-4 ratio 1.13 (0.52–2.44); MN homologous 0.47 (0.15–1.51) | Sensitivity for the 1280 cap | 02 → `logs/02_serology_hai_mn_elisa.log` |
| N17 | MN homologous week 4: 325.4 vs 588.1; adjusted 0.68 (0.31–1.51); late 0.64; 9/15 Fluarix and 4/14 mRNA-1010 values at the 1280 cap | MN homologous | 02; 11 |
| N20 | ELISA H1 GMFR 5.07 vs 1.90; adjusted 2.66 (2.01–3.53); late 1.51 (1.19–1.91) | Binding IgG H1 | `elisa_igg_titers.csv` → 02 |
| N21 | ELISA H3 GMFR 7.60 vs 1.99; adjusted 3.31 (2.47–4.43); late 2.06 (1.57–2.70) | Binding IgG H3 | same |
| N22 | ELISA B/Vic adjusted 1.35 (1.04–1.75); late 0.99 | Binding IgG B/Vic | same |
| N23 | ELISA B/Yam adjusted 1.38 (1.11–1.71); late 1.06 | Binding IgG B/Yam | same |
| N24 | Bead-array ratios: H3 3.5–10.1 (HK/1968 9.51, Thailand/8/2022 9.45, Darwin/6/2021 6.10); H1 1.26–2.70; panel means H3 5.75 (2.87–11.53), H1 1.86 (1.06–3.28) | Binding breadth | `binding_breadth_h1/h3.csv` → 07, 09 → `bead_array_binding_breadth_by_strain.csv`, `forest_plot_data.csv` |
| N30 | GC block 1, week 2: 24.2% vs 2.3% (p=0.037); week 8: 8.3 vs 1.7 (p=0.17); week 17: 16.0 vs 2.3 (p=0.083); week 26: 18.9 vs 1.6 (p=0.34) | GC B cells | `gc_frequencies.csv` → 04 → `logs/04_cellular_repertoire.log` |
| N31 | GC B-cell sequences: mRNA-1010 donors 13–302; Fluarix donors 2–15 | Clonal overlap | `pb_gc_clonal_overlap.csv` → 04 |
| N33 | Pre-existing clonotype share of serum IgG 83.9% vs 86.2% (p=0.72); vaccine-elicited clonotypes median 32 vs 17.5 (p=0.066) | Repertoire | `repertoire_clonotype_counts.csv` → 04 |
| N34 | IgM GM fold-change: Fluarix 4.0–5.8 vs mRNA-1010 1.6–2.1 | IgM | `igm_fold_change.csv` → 04 |
| N35 | mAb donors 4 vs 3; mRNA-1010 264 group-I + 349 group-II mAbs; Fluarix 74 + 34, of which donor 05 supplied 61 and 25 | mAb sampling | `mab_binding_panels.csv` → 13 → `mab_binding_by_donor.csv` |
| N36 | ≥10× binding: HK/1968 28–65% vs 0–16%; H7 3–21% vs 0%; Croatia/10136RV/2023 48% vs 38% (pooled); Netherlands/01317/2025 91% vs 89% (pooled) | mAb cross-reactivity | same |
| N40 | H3N2 forward-drift (66 viruses): adjusted 1.18 (0.65–2.13), p=0.58; late 1.05 (0.66–1.68) | Primary breadth result | `neutralization_seqbased.csv` → 01 → `seqneut_category_ancova.csv` |
| N41 | H3N2 forward-drift GMT: baseline 142 vs 214 (0.66, p=0.11); day 29 401 vs 463 (unadjusted 0.87, 0.44–1.69); GMFR 2.83 vs 2.16 | Baseline imbalance | same |
| N42 | H3N2 historical (8 viruses): adjusted 1.63 (0.99–2.68); H1 historical 1.69 (0.91–3.13) | Back-boost | same |
| N43 | H3N2: mixed model 1.07 (0.63–1.83); excluding 397-009 and 397-028 1.28 (0.68–2.40); day 181 only 0.99 (0.59–1.66); naive GMFR ratio 1.31 | Sensitivity | 08 → `seqneut_sensitivity_analyses.csv` |
| N44 | Five most-drifted H3N2: unadjusted 0.80–0.86, adjusted 0.94–1.21 (all CIs include 1); per-virus median 1.15 (range 0.82–1.52), 0/66 with lower bound >1 | Per-virus | 07, 12 → `seqneut_most_drifted_H3N2.csv`, `seqneut_per_virus_summary.csv` |
| N45 | A/Darwin/6/2021 day-29 GMT 244 vs 482; unadjusted 0.51; adjusted 0.62 (0.34–1.12). 2022/23 H3 vaccine-strain category 0.71 (0.36–1.38) | Own H3 antigen | 12, 01 |
| N46 | H1N1 forward-drift (6 viruses): day 29 GMT 478 vs 257; adjusted 2.06 (1.23–3.46), p=0.008; mixed model 2.02 (1.21–3.36); 6/6 viruses with lower bound >1 | H1 breadth | 01, 08, 12 |
| N47 | H1N1 forward-drift late 1.17 (0.77–1.77); day 181 only 1.14 (0.68–1.94); 5a.2 strain 2.44 (1.18–5.05) → late 1.17; 5a.2a.1 strain 2.07 (1.26–3.38) → late 1.23 | H1 durability | 01, 08 |
| N48 | Late/day-29 retention: H1 43% (mRNA-1010) vs 76% (Fluarix), p=0.001; late GMT 207 vs 196. H3 63% vs 67% | Waning | 14 → `seqneut_waning_forward_drift.csv` |
| N49 | Egg-reassortant / wild-type twin titre ratio at day 29: H3 pairs 1.33–6.22 (mRNA-1010) and 1.47–4.16 (Fluarix); IVR-238 vs Wis/67/2022 5.33 and 7.46 | Reassortant inflation | 07 → `seqneut_egg_vs_wildtype_pairs.csv` |
| N50 | Same participants, GMFR mRNA-1010: ELISA H3 8.01, HAI H3 1.57, Darwin/6 neutralization 2.24, forward-drift H3 2.83 → yield 0.20/0.28/0.35. Fluarix: 2.20/1.68/2.74/2.16 → 0.77/1.25/0.98 | Binding vs function | 05 → `binding_vs_function_by_participant.csv` |
| N51 | Spearman ρ (ELISA H3 rise vs forward-drift H3 neutralization rise): Fluarix 0.75, mRNA-1010 0.31 (p=0.30) | Binding vs function | 05 |
| N52 | mRNA-1010: 12/13 had larger rise to 5a.2 than 5a.2a.1; GM ratio 1.75; sign test p=0.0034 | H1 consistency check | 03 → `h1_immunogen_consistency_by_participant.csv` |
| N53 | Fluarix: 9/14; GM ratio 1.38; between-arm p=0.049 | H1 consistency check | same |
| N54 | mAb median log2(Wis588/Vic4897 binding), mRNA-1010 donors 0.90–2.08 (1.9–4.2×); Fluarix donors 0.15–1.80 | H1 consistency check | 03 → `mab_h1_relative_binding_by_donor.csv` |
| N55 | MN tracking with sequencing-panel viruses: mean over viruses of (baseline Spearman ρ + fold-rise Spearman ρ): H3N2 0.68 (homologous MN) / 0.70 (heterologous MN) vs H1N1 −0.16 / 0.05 | MN identity probe (hypothesis) | 10 → `mn_panel_identity_probe.csv`, `logs/10_mn_panel_identity_probe.log` |
| N56 | A/Thailand/8/2022 and A/Massachusetts/18/2022: ≥4-fold rise 7.7% and 8.3% (mRNA-1010) vs 28.6% and 30.8% (Fluarix); adjusted 0.82 (0.35–1.91) and 0.90 (0.46–1.79) | Later vaccine strains | 12 → `seqneut_per_virus_summary.csv` |
| N57 | Share of forward-drift viruses with ≥4-fold rise per participant: H1 median 0.50 vs 0.00 (p=0.006); H3 0.18 vs 0.05 (p=0.36); ≥50% of H3 panel 3/13 vs 3/14 | Responder breadth | 01 → `seqneut_forward_drift_fraction_4fold_by_participant.csv` |
| N58 | 397-009 (Fluarix): A/Darwin/6/2021 957→381→114 (d0→d29→d121); forward-drift H3N2 GM fold-change 0.70. 397-028 (mRNA-1010): A/Darwin/6/2021 1397→742→532, A/Darwin/9/2021 4291→1640→905 | Falling post-dose titres | 15 → `logs/15_bead_timepoint_and_falling_titres.log` |
| N60 | IgM n = 15 Fluarix / 14 mRNA-1010 vs 38/37 listed | Cohort mismatch | 11 → `cohort_counts_vs_summary.csv` |
| N61 | HAI B/Vic n=13 (397-031 missing); sequencing neutralization omits 397-014 and 397-019 | Cohort gaps | 11 |
| N62 | ELISA IDs: Fluarix 1–59, mRNA-1010 3–102; 33–59 Fluarix-only; 64–102 mRNA-1010-only | Enrolment windows | 11 |
| N63 | 9 participants with conflicting late-visit labels (HAI B/Vic swapped for 8; sequencing dataset labels 397-007 and 397-011 as day 121) | Visit labels | 11 → `data_integrity_issues.csv` |
| N64 | GC file: 156/156 rows have duplicated keys (2 blocks); timepoints week 0/2/8/17/26 vs FNA schedule week 1/2/4/8/17/26 | GC file | 04, 11 |
| N65 | Plasmablast file at weeks 2 and 8 (not blood-draw visits); mRNA-1010 maximum 2.2–4.7% at weeks 17–26; 11 non-FNA IDs with 2–3 decimals vs 5–6 | Plasmablast file | 04, 11 |
| N66 | MN, HAI and ELISA antigens unnamed. Bead-array fold-rise correlates with ELISA week-4 fold-rise (ρ 0.82–0.90) more closely than with week 17/26 (ρ 0.70–0.84), hence "presumed week 4" | Assay identity | 11; 15 → `bead_vs_elisa_interval.csv` |
| N67 | Sequencing neutralization: 171 values below the lower limit (≤40), 70 above the upper limit (≥17,300) of 7,719 | Censoring | 11 |
| N68 | Repertoire files lack participant IDs | Linkability | 11 |
| N70 | Participant-level forward-drift breadth: residual SD after ANCOVA H1 0.94, H3 1.02 log2 | Variance for sizing | 06 → `logs/06_power_next_studies.log` |
| N71 | 64 (H1) and 76 (H3) evaluable per arm for a 1.5× ratio; 101 with SD +15% (90% power, two-sided α=0.025) | Study 1 size | 06 → `power_planning_numbers.csv` |
| N72 | HAI GMT non-inferiority: 158 per arm (SD 1.6, margin 1.5, 90% power) | Study 1 size | 06 |
| N73 | HAI seroconversion non-inferiority: 505 per arm (40% vs 40%, margin 10 points) | Study 1 size | 06 |
| N74 | Challenge study: 58 / 82 / 93 per arm for 50→25%, 40→20%, 50→30% | Study 2 size | 06 |
| N75 | rVE events: 1,595 (15%), 847 (20%), 511 (25%), 334 (30%) | Study 3 size | 06 |
| N76 | Participant-seasons for 500 mismatched events at rVE 25%: 27k (3%, 70% mismatched) to 190k (1%, 30% mismatched) | Study 3 feasibility | 06 |

**Proposed design numbers (not data):**
- Study 1: 180 per arm per stratum; total ≈900–1,080.
- Primary success: lower bound >1.0 with point estimate ≥1.5. The 1.5 mirrors the standard HAI non-inferiority margin (E4), i.e. the smallest GMT difference regulators treat as meaningful.
- Study 2: 60–90 per arm.
- Study 3: rVE 20–30% range.

## 5. External facts used (not in the package; please verify)

- **E1.** WHO 2022–23 Northern-Hemisphere recommendation, egg-based: A/Victoria/2570/2019 (H1N1)pdm09-like, A/Darwin/9/2021 (H3N2)-like, B/Austria/1359417/2021-like, B/Phuket/3073/2013-like. Cell/recombinant-based: A/Wisconsin/588/2019, A/Darwin/6/2021, same B strains. Fluarix is egg-based split-virion.
- **E2.** A/Victoria/4897/2022 (egg-based) and its cell-based counterpart A/Wisconsin/67/2022 were the 2023–24 Northern-Hemisphere H1 recommendation (clade 5a.2a.1). A/Victoria/2570/2019 and A/Wisconsin/588/2019 are clade 5a.2.
- **E3.** WHO advised in 2023 that a B/Yamagata antigen is no longer warranted. Trivalent vaccines are recommended from the 2024–25 season.
- **E4.** FDA/CBER seasonal-influenza immunogenicity conventions:
  - non-inferiority: upper bound of GMT ratio (comparator/new) ≤1.5, and upper bound of seroconversion difference ≤10 percentage points;
  - accelerated-approval thresholds: seroconversion lower bound ≥40% and HAI ≥1:40 lower bound ≥70% (≥65 years: 30% and 60%);
  - HAI ≥1:40 is a strain-specific correlate.
- **E5.** A/Thailand/8/2022 (egg) and A/Massachusetts/18/2022 (cell) were the 2024–25 Northern-Hemisphere H3N2 recommendation. To my knowledge, A/Croatia/10136RV/2023 and A/District of Columbia/27/2023 followed for 2025–26.

## 6. Files in /tmp/outputs

**Analysis code**
- `analysis/00_common.py` – loaders, plus the virus classification (forward-drift / historical / vaccine-strain / reassortant), with the assumptions stated.
- `analysis/01`–`15_*.py` – the analyses.
- `analysis/run_all.sh` – reruns everything.
- `logs/*.log` – stdout of each script.

**Key tables**
- `serology_arm_comparison_ancova.csv`
- `serology_descriptive_by_arm.csv`
- `seqneut_category_ancova.csv`
- `seqneut_per_virus_summary.csv`
- `seqneut_sensitivity_analyses.csv`
- `seqneut_waning_forward_drift.csv`
- `seqneut_egg_vs_wildtype_pairs.csv`
- `seqneut_most_drifted_H3N2.csv`
- `binding_vs_function_by_participant.csv`
- `h1_immunogen_consistency_by_participant.csv`
- `mab_h1_relative_binding_by_donor.csv`
- `mab_binding_by_donor.csv`
- `bead_array_binding_breadth_by_strain.csv`
- `mn_panel_identity_probe.csv`
- `data_integrity_issues.csv`
- `cohort_counts_vs_summary.csv`
- `power_planning_numbers.csv`
- `bead_vs_elisa_interval.csv`

**Figure**
- `forest_binding_vs_function.png` – every arm ratio with its 95% CI, binding (orange) vs functional (blue).
