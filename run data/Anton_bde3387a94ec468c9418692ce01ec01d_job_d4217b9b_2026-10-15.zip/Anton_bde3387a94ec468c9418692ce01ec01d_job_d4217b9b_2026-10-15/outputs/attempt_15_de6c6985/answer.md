**Recommendation: WU397 does not support a heterologous-protection claim, so the next study should be a randomised, observer-blind, antigen-matched trial (mRNA-1010 vs egg-based and recombinant-HA vaccines carrying identical WHO strains, in adults 18–64 and ≥65, stratified by prior-season vaccination) gated on neutralising breadth against a locked forward-drift virus panel at day 29 and day 181 (plus NA inhibition); commit to a drifted-strain human-challenge study and a strain-characterised relative-efficacy trial only if it passes.**

---

Bracketed IDs such as [Q6] point to the evidence ledger in Appendix A (machine-readable copy: `/tmp/outputs/numbers_provenance.csv`). Each one gives the value, the source file in `/tmp/world/filesystem/` and the script that produced it. Every analysis can be re-run with `/tmp/outputs/analysis/run_all.sh`. Facts that do not come from the data package are tagged [X#]; please check them against their sources before the committee meets.

## 1. Bottom line

WU397 shows that mRNA-1010 gives higher **binding** antibody and larger lymph-node germinal-centre responses than Fluarix. It does not show heterologous protection, and the way it was designed means it could not have shown it. It also does not show functional breadth that can be credited to the platform.

1. **The two arms got different antigens.**
   - The mRNA-1010 H1 was A/Victoria/4897/2022 (trial summary). WHO first recommended that strain for the 2023–24 season [X3].
   - Fluarix 2022–23 contained A/Victoria/2570/2019 H1 and an egg-derived A/Darwin/9/2021 H3 [X1].
   - Every "homologous/heterologous" label in the package is defined against the mRNA-1010 antigens only (trial summary).
2. **The only functional advantage is in H1, and it is not heterologous for the mRNA arm.**
   - Day-29 neutralisation of 2023 H1N1 isolates was 2.06× higher (95% CI 1.23–3.46) [Q2].
   - Those isolates are neutralised within 1.3-fold of A/Wisconsin/67/2022, the cell-based equivalent of the mRNA-1010 H1 [Q23]. In effect they are the mRNA arm's own antigen.
   - The advantage had gone by day 121/181 (1.17, 0.77–1.77) [Q2], because H1 titres in the mRNA arm fell 2.16-fold versus 1.28-fold [Q19].
3. **H3N2, the subtype that drives most antigenic drift, shows no functional advantage.**
   - Across 68 contemporary H3N2 viruses the adjusted ratio was 1.17 (0.64–2.12) at day 29 and 1.05 (0.65–1.68) at day 121/181 [Q6].
   - None of the 68 viruses individually favoured mRNA-1010 at p<0.05 [Q17].
   - Against its own H3 (A/Darwin/6/2021), mRNA-1010 was lower: 0.62 (0.34–1.12) [Q9].
4. **Binding breadth is not functional breadth.**
   - mRNA-1010 raised H3 binding on the bead array by 2.0–5.0 log2, against 0.2–2.1 for Fluarix [B10–B21].
   - In the same participants and strains, the extra H3 binding did not neutralise. The binding-minus-neutralisation gap was 2.21 log2 for mRNA-1010 versus 0.03 for Fluarix (p=0.0001) [V13].
5. **The breadth that is there points backwards.**
   - mRNA-1010 shifted neutralisation toward older strains that participants had probably been primed with: −0.81 log2 for H1 (p=0.003) and −1.01 log2 for H3 (p=0.021) [R2, R4].
   - Its H1 monoclonals bind the older 5a.2 HA more strongly than the vaccine HA [A17].
   - In both arms, 84–86% of serum IgG after vaccination comes from clonotypes that were already present [C4].
6. **HAI, the only accepted correlate, shows no difference.** Baseline-adjusted ratios were 1.01–1.54 and every 95% CI includes 1 [H9–H12]. Microneutralisation GMTs were numerically higher with Fluarix (325 vs 588 and 235 vs 368). After baseline adjustment the ratios are 0.68 and 1.17, both with wide CIs [M1–M6].
7. **Nothing in the package measures protection.**
   - There was no randomisation and no infection or clinical endpoint.
   - There is no NA readout and no influenza-B breadth readout (0 B viruses in the sequencing-based neutralisation panel [Q24]).
   - With about 14 per arm, only differences of roughly 2-fold or more could be detected [P5].
   - Several data-integrity problems are unresolved (§2.8).

## 2. What the WU397 package does and does not show

### 2.1 The comparison is confounded by design

| Issue | Evidence | Consequence for the claim |
|---|---|---|
| The arms received different antigens | mRNA-1010: A/Victoria/4897/2022 H1 and A/Darwin/6/2021 H3 (trial summary). Fluarix 2022–23: A/Victoria/2570/2019 H1 and egg-based A/Darwin/9/2021 H3 [X1]. A/Victoria/4897/2022 was first recommended for 2023–24 [X3]. | Any H1 or H3 difference mixes platform with antigen choice, so it cannot be credited to mRNA. |
| Panel labels are defined against mRNA-1010 only | Trial summary, "Notes on the virus panels". | A "homologous" virus for mRNA-1010 is heterologous for Fluarix (clearly so for H1), so the "breadth" comparisons are lopsided. |
| The antigens used in the core serology are not identified | HAI, ELISA and IgM files name only subtype or lineage; the MN panels are unlabelled. By correlation, MN titres track H3N2 (ρ 0.52–0.61) rather than H1N1 (ρ −0.19 to 0.15) [R5–R8]. HAI H1 tracks A/Victoria/4897/2022 IVR-238 most closely (ρ 0.78, against 0.74 and 0.68 for the two A/Wisconsin H1 viruses) [R9–R11]. | We cannot tell whether Fluarix recipients were ever tested against their own vaccine strains. |
| Allocation was by site, not randomised, and there are no demographics or vaccination histories | Trial summary. Baseline MN "heterologous" GMT was 57 vs 121 (p=0.057) [M7]. | Differences between arms may be differences between populations. Prior vaccination is a likely effect modifier: the Fluarix 2022–23 H1 was identical to the 2021–22 H1 [X2]. |
| Assay subsets are small and overlap selectively | 13–15 per arm for the functional assays [D1]. Seq-neut leaves out 397-014 (mRNA-1010; MN 15→10) and 397-019 (Fluarix; MN 80→1280) [D6]. | Only differences of about 2-fold or more are detectable [P5]. The two omissions bias the comparison toward mRNA-1010. |
| Readout range and panel artefacts | MN ceiling of 1280: 9/15 Fluarix participants at the ceiling at week 4 [M8]. Seq-neut: 171 results below the limit of detection and 70 above the upper limit of quantitation (ULOQ) [Q25]. Egg or reassortant viruses titrate 1.38–7.46× above their wild-type counterparts [Q21]. | Fold-rises are truncated, mostly in the Fluarix arm. Egg-derived viruses inflate apparent "breadth". |
| No protection readout | No surveillance for infection and no clinical endpoint. | This is immunogenicity only. HAI is the only accepted correlate, and only for matched strains [X9]. |

### 2.2 Functional antibody by HAI and microneutralisation: no advantage

| Readout | mRNA-1010 | Fluarix | mRNA/Fluarix, baseline-adjusted (95% CI) |
|---|---|---|---|
| HAI H1N1: GMT at week 4; seroconversion | 138; 7/14 | 88; 5/15 | 1.54 (0.87–2.71) [H1, H2, H9] |
| HAI H3N2 | 56; 2/14 | 58; 3/15 | 1.06 (0.67–1.65) [H3, H4, H10] |
| HAI B/Victoria | 57; 0/13 | 52; 1/15 | 1.05 (0.71–1.56) [H5, H6, H11] |
| HAI B/Yamagata | 88; 0/14 | 99; 1/15 | 1.01 (0.73–1.40) [H7, H8, H12] |
| MN "homologous": GMT at week 4 | 325 | 588 | 0.68 (0.31–1.51) [M3, M4, M6] |
| MN "heterologous": GMT at week 4 | 235 | 368 | 1.17 (0.52–2.62) [M1, M2, M5] |

- Both arms are heavily pre-immune. At baseline, 12/14 vs 9/15 were at HAI ≥40 for H1 and 11/14 vs 14/15 for B/Yamagata [H1–H8].
- HAI geometric mean fold-rises were only 1.05–2.76 [H1–H8].
- Nothing distinguishes the arms on functional antibody against what are presumed to be the vaccine strains.

### 2.3 Binding antibody favours mRNA-1010, most where the antigens differ

| ELISA IgG | Fold-rise at week 4, mRNA vs Fluarix | Adjusted ratio, week 4 | Adjusted ratio, week 17/26 |
|---|---|---|---|
| H1 | 5.07 vs 1.90 | 2.66 (2.01–3.53) | 1.51 (1.19–1.91) [E1, E2, E9] |
| H3 | 7.60 vs 1.99 | 3.31 (2.47–4.43) | 2.06 (1.57–2.70) [E3, E4, E10] |
| B/Victoria | 3.16 vs 2.30 | 1.35 (1.04–1.75) | 0.99 (0.78–1.26) [E5, E6, E11] |
| B/Yamagata | 2.67 vs 2.03 | 1.38 (1.11–1.71) | 1.06 (0.88–1.29) [E7, E8, E12] |

- **Where the advantage is large.** It is large only for H1 and H3, the two components whose antigens differ between the products (a different H1 strain; a cell-like versus egg-derived H3 [X1]). For the B components, where the antigens are identical, it is modest and has disappeared by the late visit.
- **IgM.** IgM rose more in the Fluarix arm (geometric mean fold-rise 3.99–5.77 vs 1.55–2.11; p=0.013–0.34) [G1–G8]. The IgM file gives no timepoint and covers 14 and 15 participants, not the 38 and 37 stated in the summary [D2].
- **Bead array.** Binding was higher with mRNA-1010 for 20 of 21 strains at p<0.05; the exception was A/Hawaii/70/2019, p=0.10 [B1–B21]. That includes A/Puerto Rico/8/1934 (log2 fold-rise 1.54 vs 0.10) [B6] and A/Hong Kong/1/1968 (3.45 vs 0.20) [B13], whose HA heads share little with the vaccine. That pattern usually means conserved, often non-neutralising, epitopes or recall of older memory.
- **Bead-array panels look backwards.** Only two strains were isolated after 2021: one H1 (A/Wisconsin/67/2022, itself the cell-based equivalent of the mRNA-1010 H1) and one H3 (A/Thailand/8/2022). All the others are historical [B22].

### 2.4 Neutralisation breadth on the sequencing-based panel: the only readout that speaks to the claim

Participant-level analysis: 13 mRNA-1010 and 14 Fluarix participants. Viruses were grouped before analysis by their relationship to each arm's vaccine strains. The panel has 96 viruses, 0 of them influenza B [Q24].

| Subtype | Virus category (n viruses) | Day-29 GMT, mRNA vs Fluarix | Adjusted ratio, day 29 | Adjusted ratio, day 121/181 |
|---|---|---|---|---|
| H1N1 | mRNA-1010-matched (2) | 996 vs 537 | 1.84 (1.17–2.90) | 1.15 (0.76–1.72) [Q4] |
| H1N1 | Fluarix-matched, A/Wisconsin/588/2019 (1) | 1073 vs 506 | 2.44 (1.18–5.05) | 1.17 (0.62–2.23) [Q1] |
| H1N1 | Contemporary 2023 isolates (6) | 478 vs 257 | 2.06 (1.23–3.46) | 1.17 (0.77–1.77) [Q2] |
| H1N1 | Historical (4) | 2533 vs 1687 | 1.69 (0.91–3.13) | 1.11 (0.61–2.03) [Q3] |
| H3N2 | mRNA-1010-matched, A/Darwin/6/2021 (1) | 244 vs 482 | 0.62 (0.34–1.12) | 0.72 (0.40–1.31) [Q9] |
| H3N2 | Fluarix-matched, A/Darwin/9/2021 (1) | 1009 vs 1539 | 0.81 (0.35–1.87) | 0.57 (0.25–1.27) [Q5] |
| H3N2 | Contemporary 2022–24 isolates (68) | 402 vs 467 | 1.17 (0.64–2.12) | 1.05 (0.65–1.68) [Q6] |
| H3N2 | Historical wild-type (8) | 1524 vs 1273 | 1.63 (0.99–2.68) | 1.44 (0.87–2.40) [Q7] |
| H3N2 | Historical egg/reassortant (5) | 4751 vs 3345 | 1.54 (1.05–2.27) | 1.37 (0.85–2.21) [Q8] |

**H1N1: about 2× higher at day 29 across the board, but neither heterologous nor durable.**
- The 2023 isolates are antigenically the mRNA arm's own antigen: in both arms their titres sit within 1.3-fold of A/Wisconsin/67/2022 [Q23]. All six favour mRNA-1010 individually (per-virus ratios 1.93–2.29) [Q18], just as A/Wisconsin/67/2022 does (2.07; ≥4-fold rises 6/13 vs 1/14) [Q14]. No virus in the panel is heterologous to the mRNA-1010 H1. (The mRNA-matched category also contains the egg reassortant A/Victoria/4897/2022 IVR-238, ratio 1.60 [Q16].)
- The advantage also covers Fluarix's own H1 equivalent, A/Wisconsin/588/2019 (2.44×; ≥4-fold rises 9/13 vs 2/14) [Q1, Q15]. A simple antigen-match explanation cannot produce that. Two other explanations can:
  - antigen novelty: Fluarix recipients would have been re-exposed to an unchanged H1 [X2];
  - platform potency.
- WU397 cannot tell these apart.
- By day 121/181 the ratios are 1.11–1.17 [Q1–Q4], because H1 titres in the mRNA arm fell 2.16-fold against 1.28-fold in Fluarix (p=0.0005) [Q19].
- These conclusions hold when censored values are handled differently and when the late visit is restricted to day 181 (`analysis/seqneut_sensitivity.csv`).

**H3N2: no advantage against current or next-season viruses.**
- The contemporary panel shows no difference at either timepoint [Q6]. The median per-virus ratio was 1.15, and 0/68 viruses favoured mRNA-1010 at p<0.05 [Q17].
- A/Thailand/8/2022 and A/Massachusetts/18/2022, later chosen as the 2024–25 H3N2 vaccine strains [X11], gave ratios of 0.82 and 0.90. ≥4-fold rises were seen in 1/13 and 1/12 mRNA-1010 recipients versus 4/14 and 4/13 Fluarix recipients [Q10, Q11].
- For the vaccine H3 strains, ≥4-fold rises were 2/13 vs 4/14 against A/Darwin/6/2021 and 7/13 vs 5/14 against A/Darwin/9/2021 [Q12, Q13]. H3 waning was similar in the two arms (1.57- vs 1.45-fold, p=0.42) [Q20].
- The only H3 categories leaning toward mRNA-1010 are historical strains [Q7, Q8].

**How much weight these results can bear.**
- These are 13 versus 14 people. WU397 was powered only for differences of about 2-fold [P5], and its contemporary-H3N2 interval (0.64–2.12) still allows up to a 2-fold advantage [Q6]. "No evidence of an advantage" is not evidence that there is none, and that gap is why Study 1 is needed.
- **Statistical hygiene matters here.** If the 1,808 virus × participant H3N2 observations are treated as independent, the result is a spuriously "significant" 1.13× (p=0.0018). The correct participant-level model gives 1.06 (0.62–1.82), p=0.82 [Q22]. Any internal material claiming significant breadth from pooled virus-level tests should be withdrawn.

### 2.5 For H3, binding breadth is not functional breadth

Twelve strains were measured by both bead-array binding and seq-neut in the same 27 participants (Figure 1; per-strain values [V1–V12]).
- **H1.** Binding and neutralisation gains agree: the binding-minus-neutralisation gap is −0.41 vs −0.50 log2 [V13].
- **H3.** mRNA-1010's binding gain exceeds its neutralisation gain by 2.21 log2 (about 4.6-fold). In Fluarix the gap is 0.03 (p=0.0001) [V13]. Relative to Fluarix:
  - for the vaccine H3, A/Darwin/6/2021, mRNA-1010's binding was +2.85 log2 but neutralisation was −0.29 log2 [V7];
  - for A/Thailand/8/2022, binding was +3.57 and neutralisation −0.17 [V8].
- **Implications:**
  - The bead-array panels and the binding-only monoclonal data cannot be used as evidence of heterologous protection for H3.
  - Whether the surplus binding antibodies protect in some other way (for example through Fc-mediated functions) has not been tested. Studies 1 and 2 ask that question explicitly.

### 2.6 The response is pulled backwards toward imprinted strains, not forwards

- **H1.** The mRNA-1010 antigen is clade 5a.2a.1 [X12].
  - In mRNA-1010 recipients, the log2 ratio of titres against A/Wisconsin/67/2022 (5a.2a.1) to A/Wisconsin/588/2019 (5a.2) moved from −0.50 to −1.31 (shift −0.81, p=0.003) [R2].
  - In Fluarix recipients it moved by −0.47 (p=0.36). Between-arm p=0.049 [R1, R2].
- **H3.** Titres against A/Darwin/6/2021 relative to A/Cambodia/e0826360/2020 (the 2021–22 vaccine strain [X2]) moved −1.01 log2 with mRNA-1010 (p=0.021) and +0.28 with Fluarix (p=0.36). Between-arm p=0.022 [R3, R4].
- **Monoclonals.** H1 monoclonals from all four mRNA-1010 donors bind A/Wisconsin/588/2019 more strongly than their own vaccine HA (median signal ratio 0.24–0.54). Only 1 of 264 binds the vaccine HA without also binding the older HA [A17].
- **Repertoire.**
  - 83.9% versus 86.2% of serum IgG after vaccination comes from clonotypes that were already present [C4].
  - 73–92% of germinal-centre clones in mRNA-1010 donors are shared with week-1 plasmablasts [C3], which come mainly from pre-existing memory B cells [X13].
- **Implication.** The pattern is consistent with recall of imprinted memory toward older strains, i.e. backward breadth. A heterologous-protection claim is about forward breadth: viruses that emerge after strain selection.

### 2.7 Cellular, repertoire and monoclonal antibody data

- **Germinal-centre responses are larger and longer-lived with mRNA-1010.**
  - At week 2, 24.2% vs 2.3% of germinal-centre B cells were HA-specific (n=6 vs 11; p=0.037) [C1]. The responses persisted at weeks 17 and 26 (16.0 vs 2.3, p=0.083; 18.9 vs 1.6, p=0.34) [C2].
  - That is a plausible route to affinity maturation. However, the clones are largely recalled memory [C3, X13], and the Fluarix germinal-centre sample was tiny (7, 5 and 1 clones in three donors) [C3].
  - Serum breadth at the late visit did not improve [Q6].
- **Repertoire.** mRNA-1010 produced more vaccine-elicited serum clonotypes (32.0 vs 20.1, p=0.066) [C5] and higher CDR-H3 diversity at week 4 (71.2 vs 24.9, p=0.010) [C6]. These are 8 per arm and cannot be linked to other assays [D5].
- **Monoclonal antibodies: sampling is very unequal.**
  - There are 589 monoclonals from 4 mRNA-1010 donors and 106 from 3 Fluarix donors. Two of the Fluarix donors contributed only 2 and 7 H3-panel monoclonals [A15].
  - **H3 panel:** breadth at donor level favours mRNA-1010. Forward-strain binding is 35–68% vs 0–48%, and H7 cross-binding 2.6–21.3% vs 0% [A8–A14].
  - **Limits of the H3 finding:**
    - With 4 versus 3 donors, the smallest exact two-sided p that can be reached is 0.057 [A18].
    - The monoclonals were tested for binding only.
    - The control antigen is the normaliser (it equals 1.0 for every monoclonal), so there is no empirical positivity cut-off. We used >10-fold and checked 5-fold as a sensitivity analysis [A16].
  - **H1 panel:** forward binding does not differ (84–94% vs 50–93%) [A1–A7].

### 2.8 Data-integrity problems to resolve before the committee

1. The IgM file covers 14 and 15 participants, not the 38 and 37 stated. It has no timepoint, and it uses the ID "20" instead of "020" [D2].
2. `plasmablast_frequencies.csv` covers 13 and 15 participants. Eleven of them are outside the FNA cohort, and the data are at weeks 2 and 8, which are not blood-draw visits [D3]. It is unclear whether these are blood or lymph-node measurements.
3. `gc_frequencies.csv` contains two 78-row blocks under the same column name. It includes week 0, which is not an FNA visit, and lacks weeks 1 and 4, which are [D4]. The second block cannot be used until it is labelled.
4. The repertoire, CDR-H3 and serum clonotype files have no participant identifiers [D5].
5. Participant ID formats differ between files (397-0NN, NN, 397-NN and "20"). The virus name A/SOUTHAFRICA/R07876/202023 is malformed [Q26].
6. **Timepoints are unclear or pooled:**
   - the bead-array fold-change timepoint is not stated;
   - "wk17/26" pools visits two months apart;
   - late seq-neut sera are day 121 for 6 participants and day 181 for 21 [Q27].
7. There is no documented reason for leaving 397-014 and 397-019 out of the seq-neut cohort [D6].
8. The antigens used for HAI, ELISA, IgM and MN are not identified. The Fluarix lot composition and the mRNA-1010 dose are not recorded.

### 2.9 What can be said now

- **Supportable, with the non-randomised caveat:** "In a small non-randomised study, mRNA-1010 elicited higher HA-binding IgG than Fluarix (H1 2.66×, H3 3.31× at week 4) [E9, E10] and larger, more persistent lymph-node germinal-centre responses, with similar HAI and microneutralisation titres."
- **Not supportable:** "broader", "cross-protective", "heterologous protection", "durable breadth" or "superior neutralisation of drifted strains".

## 3. Recommended next studies

| # | Study | Question it settles | Timing |
|---|---|---|---|
| 0 | WU397 close-out (records plus banked samples; no new enrolment) | Makes the existing package interpretable and adds NA and Fc readouts | Now, before the committee where possible |
| 1 | **Randomised, antigen-matched immunogenicity and functional-breadth trial (the gate)** | Does the mRNA platform, not antigen choice, give better forward functional breadth that lasts through the season? | Next Northern Hemisphere season |
| 2 | Human-challenge study with a drifted strain | Does vaccination protect against an antigenically distinct virus, by any mechanism? | Not tied to a season; alongside or after Study 1 |
| 3 | Relative-efficacy trial with strain-characterised endpoints | Does it reduce influenza caused by mismatched strains in the target population? | Only after Study 1 (± Study 2) passes |

### Study 0 — WU397 close-out

**Records to obtain:**
- the Fluarix lot and its strain composition;
- the mRNA-1010 dose and lot;
- the antigen identity (strain; egg- or cell-derived) used for HAI, ELISA, IgM and each MN panel;
- age, sex, site and enrolment date for each participant;
- influenza vaccinations in the three prior seasons;
- any influenza-like illness or confirmed influenza during follow-up.

**Fix the file problems** listed in §2.8.

**Add readouts on banked sera** (same participants and visits, consent permitting):
- **NA-inhibition titres** (N1, N2) at day 0, 29 and 181. The summary lists only HA-strain antigens for mRNA-1010 [X10], whereas a split-virion vaccine contains NA, and NA inhibition is an independent correlate of protection [X8].
- **Neutralisation** against:
  - each product's own vaccine strains (A/Victoria/2570/2019-like H1 for Fluarix);
  - the viruses that actually circulated at the sites in 2022–23;
  - H1N1 viruses heterologous to A/Victoria/4897/2022 (none are in the current panel);
  - B/Victoria viruses (none are in the current panel).
- **Fc-effector function** against forward H3N2 viruses, to test whether the H3 binding surplus does anything.
- **Neutralisation, not just binding, for the broadly binding monoclonals.**

**Re-analyse:**
- with the participant as the unit;
- with homologous and heterologous defined symmetrically for each arm;
- reporting egg-derived viruses separately.

Study 0 can sharpen the hypotheses and the Study 1 panel. It cannot establish the claim, because WU397 is non-randomised, antigen-mismatched and about 14 per arm [D1].

### Study 1 — Randomised, observer-blind, antigen-matched immunogenicity and functional-breadth trial (the gate)

**Conditions**
- **Randomisation and blinding:** individual, central randomisation, stratified by site, age band and prior-season vaccination. Observer-blind, with laboratories blinded to arm.
- **Dose and timing:** a single dose at the intended commercial mRNA-1010 dose (record it; WU397 does not). One season, with vaccination finished before local influenza activity begins.
- **Identical strain composition in every arm.**
  - Use the WHO-recommended composition for the season: trivalent H1N1pdm09, H3N2 and B/Victoria, since B/Yamagata has been dropped [X4].
  - mRNA-1010 encodes the HA sequences recommended for cell or recombinant production.
  - Record each comparator's actual seed or reassortant and its sequence differences.
- **Surveillance:** active surveillance for influenza-like illness with RT-PCR through day 181. Samples taken after a confirmed infection are excluded from the primary breadth and durability analyses and reported separately.

**In whom**
- **Cohort A:** adults 18–64. **Cohort B:** adults ≥65.
- Medically stable and not yet vaccinated in the current season.
- Enrol at least 30% per cohort who were not vaccinated in the prior season, so the effect of prior vaccination can be estimated. This is the competing explanation for WU397's H1 result [X2].
- Record birth year and the prior three seasons' vaccines.

**Against what**
- **Comparators:**
  - **Cohort A:** egg-based standard-dose inactivated vaccine (Fluarix: continuity with WU397 and standard of care), and a recombinant-HA vaccine. The recombinant vaccine carries the same non-egg HA sequences as mRNA-1010, which separates the platform from egg adaptation.
  - **Cohort B:** the enhanced vaccine that is standard of care at ≥65 [X7]. Recombinant HA is preferred because its sequences match; add high-dose inactivated vaccine where that is the local standard.
- **Virus panels:** lock the selection rules in the SAP before any post-vaccination sample is tested, and finalise panel membership by those rules, blind to arm. The panels are the same for every arm because the compositions are the same.
  - **P-0 (vaccine strains):** the wild-type sequence, plus each comparator's egg-derived version, reported separately.
  - **P-1 (forward-drift panel; primary):** wild-type H3N2, H1N1 and B/Victoria viruses covering:
    - every HA subclade at ≥5% global frequency in the 6 months before and during the season;
    - viruses that WHO collaborating centres report as antigenically distinct from the vaccine strain;
    - the strain WHO later selects for the following season, added by rule when announced.
    - Balance the panel across subtypes. WU397's was 68 H3N2, 6 H1N1 and 0 B [Q24].
  - **P-2 (backward panel; secondary):** the previous 3–5 vaccine strains and older strains. Never pool it with P-1.
  - Keep egg-adapted or reassortant viruses out of all breadth scores, because they titrate 1.38–7.46× above their wild-type counterparts [Q21].

**Readouts**

| What is measured | In whom | Against | When | Role |
|---|---|---|---|---|
| Neutralising titre, quantitative across the full expected range (WU397's MN ceiling truncated 9/15 Fluarix samples [M8]). Breadth score = participant-level geometric-mean titre across P-1, per subtype. | All | P-1 | Days 0, 29, 91, 181 | **Primary** at days 29 and 181; day 91 key secondary |
| HAI titre: GMT and seroconversion | All | P-0 (plus P-1 representatives for H1N1 and B) | Days 0, 29, 181 | Key secondary: non-inferiority on vaccine strains |
| NA-inhibition titre | All | N1 and N2 of the vaccine strains plus one drifted NA each; B NA | Days 0, 29, 181 | Key secondary [X8] |
| Binding IgG to HA head and stem; binding:neutralisation ratio | All | P-0 and P-1 representatives | Days 0, 29, 181 | Secondary: checks whether the non-neutralising H3 binding excess recurs [V13] |
| Fc-effector function | Subset of about 50 per arm | P-1 representatives | Days 0, 29 | Secondary / exploratory |
| Neutralising titre | All | P-2 | Days 0, 29 | Secondary: backward breadth, reported separately |
| Memory B-cell breadth; HA-specific CD4 T cells; mucosal IgA | Subset | P-0 and P-1 representatives | Days 0, 29, 181 | Exploratory |
| Lymph-node germinal-centre responses (only if mechanistic data are still wanted; randomised, at least 10 per arm) | Subset | P-0 and P-1 representatives | Weeks 1–26 | Exploratory |
| Neutralising titre | All who consent | The following season's WHO strains, plus P-1 | Day 365, before revaccination | Exploratory: protection carried into the next season |
| RT-PCR-confirmed influenza, with HA sequence | All participants with influenza-like illness | — | Days 0–181 | Descriptive; used to censor samples |
| Reactogenicity and safety | All | — | Solicited reactions 7 days; unsolicited 28 days; SAEs and AESIs to day 181 | Safety |

**Primary endpoints and success criteria**
- **Endpoint:** breadth-score GMT ratio, mRNA-1010 / comparator, at day 29 and at day 181. It is adjusted (ANCOVA) for baseline titre, age band and prior vaccination. Test in a fixed sequence: H3N2 first, then H1N1, then B/Victoria.
- **Criteria for a heterologous-breadth claim (all must hold):**
  - the lower bound of the 95% CI is above 1.0 at both day 29 and day 181, against **both** comparators in the cohort;
  - HAI is non-inferior on the vaccine strains (upper bound of the comparator/new GMT ratio ≤1.5; upper bound of the seroconversion difference ≤10 points) [X5];
  - there is no uncompensated NA-inhibition deficit.
- **Differentiation threshold:** if a superiority claim will be marketed, pre-specify a lower bound above 1.5, by analogy with the high-dose vaccine HAI bar [X6].
- **Analysis rules:**
  - The unit is the participant, not the virus [Q22].
  - Handling of values outside the assay range is pre-specified.
  - The panel is locked before unblinding.

**Size**
- **Variability from WU397:** the participant-level breadth-score residual SD is 0.94–1.03 log2 (raw 1.21–1.65) [P1].
- **Primary endpoints:** detecting a true GMT ratio of 1.5 with 90% power, at a conservative two-sided α of 0.0125 per comparison (2 comparators × 2 timepoints), needs 84–131 evaluable per arm for SD 1.0–1.25 [P2].
- **Plan:** about 150 evaluable (about 175 randomised) per arm. That is about 525 in Cohort A and about 350 in Cohort B. At that size each comparison has 94% to >99% power, and the chance that all four succeed together is at least 78–98% [P10].
- **Differentiation bar:** a lower bound above 1.5 (true ratio 2.0) needs 166–260 per arm [P3].
- **HAI:** the plan also covers HAI GMT non-inferiority, which needs 63–117 per arm at WU397's SDs [P4, P6]. Seroconversion non-inferiority is descriptive at this size.

**How to read the result**

| Day-181 forward breadth | Interpretation | Next step |
|---|---|---|
| mRNA-1010 beats both comparators | Platform effect | Proceed to Study 3 (Study 2 supportive) |
| mRNA-1010 beats the egg-based vaccine but roughly equals recombinant HA | The advantage comes from avoiding egg adaptation, not from mRNA | No mRNA-specific heterologous claim |
| Neutralisation roughly equal, but mRNA-1010 better on Fc or binding | Unresolved | Study 2 decides |
| Anything else | No advantage | Drop the heterologous claim; pursue standard non-inferiority and relative-efficacy labelling |

### Study 2 — Human-challenge study with an antigenically drifted virus

**Conditions**
- Randomised, double-blind, 1:1:1: mRNA-1010 : licensed comparator with the same composition (recombinant HA preferred) : placebo.
- Challenge about 4–6 weeks after vaccination, at peak response.
- If the first cohort is positive, add a second cohort challenged at about 5–6 months to test durability, since WU397's H1 advantage had gone by then [Q19].

**In whom**
- Healthy adults 18–45 with no high-risk conditions.
- Screened as susceptible: low baseline HAI and neutralising titre against the challenge virus.
- Stratified by prior-season vaccination.

**Against what**
- An established, manufactured challenge virus, H3N2 first because WU397 shows no H3 signal.
- It must be antigenically distinct from the vaccine H3 by a pre-specified criterion: a different subclade and ≥8-fold reduced reactivity with vaccine-strain reference antiserum.
- It must be wild-type, not an egg-adapted vaccine variant.
- Challenge with H1N1 second, only if the H3N2 result is positive.

**Readouts**
- **Primary:** laboratory-confirmed symptomatic influenza.
- **Secondary:**
  - laboratory-confirmed infection of any kind (virus shedding, or seroconversion to challenge-virus antigens absent from the vaccine);
  - viral-load AUC, peak and duration of shedding;
  - symptom-score AUC.
- **Correlates:**
  - pre-challenge neutralising, HAI, NA-inhibition and Fc titres against the challenge virus;
  - mucosal IgA;
  - T cells.

**Size**
- With about 50% illness in controls, 39–77 per arm detects a reduction to 20–25% versus placebo at 80–90% power [P7].
- mRNA-1010 versus the licensed vaccine is an estimate only, unless the study has about 82–109 per arm (40% vs 20%) [P7].

**Value and limits**
- This is the only direct test of whether non-neutralising binding breadth protects.
- It is supportive evidence, not licensure-enabling, because it uses characterised older challenge viruses in young, susceptible adults.

### Study 3 — Relative-efficacy trial with strain-characterised endpoints

**Conditions**
- Randomised 1:1, observer-blind and multi-country.
- Run over at least two seasons and/or both hemispheres, so that mismatch events actually happen.
- Identical WHO strains in both arms, with vaccination before the season starts.

**In whom**
- Adults ≥50, stratified 50–64 and ≥65 and by prior vaccination.

**Against what**
- Standard-dose inactivated vaccine at 50–64, and the enhanced vaccine that is standard of care at ≥65 [X7].

**Readouts**
- **Primary:** first RT-PCR-confirmed, protocol-defined influenza-like illness caused by any influenza A or B, from 14 days after vaccination to the end of the season. Report relative vaccine efficacy, testing non-inferiority first and then superiority.
- **Key secondary that defines the claim:** the same endpoint, restricted to antigenically mismatched viruses.
  - Every positive specimen is HA-sequenced centrally, blinded to arm.
  - "Mismatched" is defined in advance: a subclade different from the vaccine strain, plus WHO collaborating-centre antigenic data showing ≥8-fold reduced reactivity with vaccine-strain antiserum.
  - Report relative efficacy against mismatched viruses with its 95% CI, and test the mismatched-versus-matched interaction.
- **Other secondaries:**
  - relative efficacy by subtype;
  - influenza-associated hospitalisation or pneumonia;
  - relative efficacy early versus late in the season;
  - relative efficacy by age band and prior vaccination.
- **Correlates subset (case-cohort):**
  - sera at days 0, 29 and 181;
  - HAI and neutralisation against the vaccine strains and against isolates from the trial itself;
  - NA inhibition.
  - These would form the basis for immunobridging later strain updates.

**Size**
- About 508 cases are needed for 25% relative efficacy at 90% power (one-sided α 0.025, 1:1 allocation). At an assumed 2% seasonal attack rate, that is about 29,000 participants [P8].
- A fully powered test restricted to mismatched viruses needs about 508 mismatched cases. If 40% of cases are mismatched, that is about 72,600 participant-seasons [P8].
- So pool across seasons, or treat the mismatched-virus result as an estimate.
- For 20% or 30% relative efficacy, about 845 or 331 cases are needed [P9].

### Decision logic and an alternative claim

- **Sequence.** Do Study 0 now. Study 1 is the gate. Study 2 can run alongside Study 1, and is mandatory if Study 1 shows only Fc or binding advantages. Study 3 goes ahead only if Study 1 passes (and ideally Study 2 as well).
- **Alternative claim.** A plausible and economical reading of WU397's H1 result is that mRNA-1010 carried a newer strain, a season ahead of the comparator's. If the programme wants to claim the benefit of later strain selection or faster updating, that is a different claim: better antigenic match, not heterologous protection.
  - It needs its own design: a pre-specified late-selection rule, compared against the WHO-timed composition and the comparator.
  - The endpoint would be match to, and neutralisation of, the viruses that actually circulate.

## 4. Assumptions and limits of this analysis

- **Virus categories.** These were assigned before analysis from virus names and isolation years. The package contains no sequences or antigenic-distance data. A/SOUTHAFRICA/R07876/202023 was treated as a 2023 isolate [Q26].
- **External facts.** Strain compositions, clade assignments, WHO timing, regulatory criteria and general immunology are external to the package [X1–X13] and should be checked.
- **Statistics.** All between-arm statistics use about 14 per arm [D1] and are not adjusted for multiplicity. Treat them as exploratory. ANCOVA adjusts for baseline titre only, because no covariates were supplied.
- **Censored seq-neut values** were used at their reported bounds. Alternative handling did not change any conclusion (`analysis/seqneut_sensitivity.csv`).
- **Infection during follow-up.** We found no serological sign of it in the seq-neut cohort: no participant showed a consistent ≥4-fold late rise, and the most was 2 of 83 H3N2 viruses in one participant [Q28]. Without surveillance, it cannot be ruled out.
- **Sample-size assumptions.** The calculations rest on assumed effect sizes and attack rates, stated at each use. Only the variance inputs come from WU397.

## 5. Files

- `/tmp/outputs/answer.md`: this document.
- `/tmp/outputs/numbers_provenance.csv`: every number cited, with its source file and derivation.
- `/tmp/outputs/figures/`:
  - `fig1_binding_vs_neutralisation.png`: H3 binding gains not matched by neutralisation;
  - `fig2_seqneut_ratios_by_category.png`: adjusted GMT ratios by virus category, day 29 and day 121/181;
  - `fig3_contemporary_panel_trajectories.png`.
- `/tmp/outputs/analysis/`:
  - scripts `01_hai.py` … `16_ledger_markdown.py`;
  - `run_all.sh` (re-runs everything and re-assembles this file from `answer_body.md` plus the auto-generated `ledger_table.md`);
  - intermediate tables (`*_summary.csv`, `seqneut_*.csv`, `backward_shift.csv`, `mab_breadth_by_donor.csv`, etc.);
  - logs (`log_*.txt`).

## Appendix A. Evidence ledger (every number cited, with its source)

Source files are in `/tmp/world/filesystem/`. Scripts are in `/tmp/outputs/analysis/`. "late" means the wk17 or wk26 visit (HAI, MN, ELISA) or day 121 or day 181 (seq-neut). Ratios are mRNA-1010 / Fluarix unless stated otherwise.

| ID | Quantity | Value | Source file(s) | Derivation |
|---|---|---|---|---|
| D1 | Assay cohorts stated in trial summary (mRNA-1010 / Fluarix): ELISA+IgM; HAI; bead+MN; seq-neut; FNA | 38/37; 14/15; 14/15; 13/14; 6/11 | trial_summary.md | read directly |
| D2 | Participants actually present in IgM file (mRNA-1010 / Fluarix) | 14 / 15 (not 38/37) | igm_fold_change.csv | 03_elisa_igm.py |
| D3 | Plasmablast file: participants (mRNA-1010/Fluarix); participants outside FNA cohort; timepoints | 13/15; 11 (7 mRNA-1010, 4 Fluarix); wk0, wk2, wk8, wk17, wk26 (blood schedule is d0, d7, d29, d121, d181) | plasmablast_frequencies.csv + trial_summary.md | 08_repertoire_cellular.py |
| D4 | GC file structure | 156 rows = two 78-row blocks, identical header pct_ha_specific_igg_gc; includes wk0 (not an FNA visit) and lacks wk1/wk4 (FNA visits) | gc_frequencies.csv + trial_summary.md | 08_repertoire_cellular.py |
| D5 | Repertoire / CDR-H3 / serum clonotype files | 8 per arm, no participant identifiers | repertoire_clonotype_counts.csv, cdrh3_diversity_index.csv, serum_igg_clonotypes.csv | read directly |
| D6 | HAI/MN participants absent from seq-neut: MN titres wk0 -> wk4 (homologous; heterologous) | 397-014 (mRNA-1010): 15->10; 10->10. 397-019 (Fluarix): 80->1280; 80->1280 | microneutralization.csv + neutralization_seqbased.csv | 13_backward_shift_and_panel_identity.py |
| H1 | HAI A/H1N1 Fluarix: GMT d0/wk4/late; GMFR wk4; SCR wk4; seroprotected(>=40) wk0 | 39.0 / 87.7 / 81.8; 2.25; 5/15; 9/15 | hai_titers.csv | 01_hai.py (late = wk17 or wk26 visit; SCR = >=4-fold rise [>=3.9 on rounded GM titres] or <10 to >=40) |
| H2 | HAI A/H1N1 mRNA-1010: GMT d0/wk4/late; GMFR wk4; SCR wk4; seroprotected(>=40) wk0 | 50.0 / 138.0 / 72.6; 2.76; 7/14; 12/14 | hai_titers.csv | 01_hai.py (late = wk17 or wk26 visit; SCR = >=4-fold rise [>=3.9 on rounded GM titres] or <10 to >=40) |
| H3 | HAI A/H3N2 Fluarix: GMT d0/wk4/late; GMFR wk4; SCR wk4; seroprotected(>=40) wk0 | 34.8 / 57.9 / 44.8; 1.66; 3/15; 10/15 | hai_titers.csv | 01_hai.py (late = wk17 or wk26 visit; SCR = >=4-fold rise [>=3.9 on rounded GM titres] or <10 to >=40) |
| H4 | HAI A/H3N2 mRNA-1010: GMT d0/wk4/late; GMFR wk4; SCR wk4; seroprotected(>=40) wk0 | 32.8 / 56.4 / 39.1; 1.72; 2/14; 6/14 | hai_titers.csv | 01_hai.py (late = wk17 or wk26 visit; SCR = >=4-fold rise [>=3.9 on rounded GM titres] or <10 to >=40) |
| H5 | HAI B/Vic Fluarix: GMT d0/wk4/late; GMFR wk4; SCR wk4; seroprotected(>=40) wk0 | 49.3 / 51.6 / 51.6; 1.05; 1/15; 12/15 | hai_titers.csv | 01_hai.py (late = wk17 or wk26 visit; SCR = >=4-fold rise [>=3.9 on rounded GM titres] or <10 to >=40) |
| H6 | HAI B/Vic mRNA-1010: GMT d0/wk4/late; GMFR wk4; SCR wk4; seroprotected(>=40) wk0 | 52.2 / 56.5 / 56.5; 1.08; 0/13; 8/13 | hai_titers.csv | 01_hai.py (late = wk17 or wk26 visit; SCR = >=4-fold rise [>=3.9 on rounded GM titres] or <10 to >=40) |
| H7 | HAI B/Yam Fluarix: GMT d0/wk4/late; GMFR wk4; SCR wk4; seroprotected(>=40) wk0 | 76.4 / 98.6 / 91.3; 1.29; 1/15; 14/15 | hai_titers.csv | 01_hai.py (late = wk17 or wk26 visit; SCR = >=4-fold rise [>=3.9 on rounded GM titres] or <10 to >=40) |
| H8 | HAI B/Yam mRNA-1010: GMT d0/wk4/late; GMFR wk4; SCR wk4; seroprotected(>=40) wk0 | 65.5 / 88.3 / 72.5; 1.35; 0/14; 11/14 | hai_titers.csv | 01_hai.py (late = wk17 or wk26 visit; SCR = >=4-fold rise [>=3.9 on rounded GM titres] or <10 to >=40) |
| H9 | HAI A/H1N1 wk4 GMT ratio mRNA-1010/Fluarix, baseline-adjusted | 1.54 (95% CI 0.87-2.71), p=0.13, n=29 | hai_titers.csv | 01_hai.py ANCOVA log2(wk4) ~ arm + log2(wk0) |
| H10 | HAI A/H3N2 wk4 GMT ratio mRNA-1010/Fluarix, baseline-adjusted | 1.06 (95% CI 0.67-1.65), p=0.80, n=29 | hai_titers.csv | 01_hai.py ANCOVA log2(wk4) ~ arm + log2(wk0) |
| H11 | HAI B/Vic wk4 GMT ratio mRNA-1010/Fluarix, baseline-adjusted | 1.05 (95% CI 0.71-1.56), p=0.80, n=28 | hai_titers.csv | 01_hai.py ANCOVA log2(wk4) ~ arm + log2(wk0) |
| H12 | HAI B/Yam wk4 GMT ratio mRNA-1010/Fluarix, baseline-adjusted | 1.01 (95% CI 0.73-1.40), p=0.95, n=29 | hai_titers.csv | 01_hai.py ANCOVA log2(wk4) ~ arm + log2(wk0) |
| M1 | MN heterologous panel Fluarix: GMT wk0/wk4/late; GMFR wk4; n at ULOQ 1280 wk0/wk4 | 121.3 / 367.6 / 320.0; 3.03; 1/3 of 15 | microneutralization.csv | 02_mn.py |
| M2 | MN heterologous panel mRNA-1010: GMT wk0/wk4/late; GMFR wk4; n at ULOQ 1280 wk0/wk4 | 57.0 / 234.9 / 126.0; 4.12; 0/1 of 14 | microneutralization.csv | 02_mn.py |
| M3 | MN homologous panel Fluarix: GMT wk0/wk4/late; GMFR wk4; n at ULOQ 1280 wk0/wk4 | 176.9 / 588.1 / 417.5; 3.32; 2/9 of 15 | microneutralization.csv | 02_mn.py |
| M4 | MN homologous panel mRNA-1010: GMT wk0/wk4/late; GMFR wk4; n at ULOQ 1280 wk0/wk4 | 130.8 / 325.4 / 217.2; 2.49; 1/4 of 14 | microneutralization.csv | 02_mn.py |
| M5 | MN heterologous wk4 GMT ratio mRNA-1010/Fluarix, baseline-adjusted | 1.17 (0.52-2.62), p=0.70 | microneutralization.csv | 02_mn.py |
| M6 | MN homologous wk4 GMT ratio mRNA-1010/Fluarix, baseline-adjusted | 0.68 (0.31-1.51), p=0.33 | microneutralization.csv | 02_mn.py |
| M7 | MN heterologous baseline GMT mRNA-1010 vs Fluarix (MWU p) | 57 vs 121 (p=0.057) | microneutralization.csv | 02_mn.py |
| M8 | MN titres at the 1280 ceiling at wk4, homologous panel: Fluarix / mRNA-1010; at baseline | 9/15 / 4/14; 2/15 / 1/14 | microneutralization.csv | 02_mn.py |
| E1 | ELISA IgG A/H1 Fluarix: GMT(EC50) wk0/wk4/late; GMFR wk4; n | 1647 / 3131 / 2311; 1.90; n=37 | elisa_igg_titers.csv | 03_elisa_igm.py |
| E2 | ELISA IgG A/H1 mRNA-1010: GMT(EC50) wk0/wk4/late; GMFR wk4; n | 1642 / 8329 / 3480; 5.07; n=38 | elisa_igg_titers.csv | 03_elisa_igm.py |
| E3 | ELISA IgG A/H3 Fluarix: GMT(EC50) wk0/wk4/late; GMFR wk4; n | 1311 / 2610 / 1989; 1.99; n=37 | elisa_igg_titers.csv | 03_elisa_igm.py |
| E4 | ELISA IgG A/H3 mRNA-1010: GMT(EC50) wk0/wk4/late; GMFR wk4; n | 1044 / 7936 / 3628; 7.60; n=38 | elisa_igg_titers.csv | 03_elisa_igm.py |
| E5 | ELISA IgG B/Vic Fluarix: GMT(EC50) wk0/wk4/late; GMFR wk4; n | 1172 / 2691 / 1832; 2.30; n=37 | elisa_igg_titers.csv | 03_elisa_igm.py |
| E6 | ELISA IgG B/Vic mRNA-1010: GMT(EC50) wk0/wk4/late; GMFR wk4; n | 1123 / 3550 / 1758; 3.16; n=38 | elisa_igg_titers.csv | 03_elisa_igm.py |
| E7 | ELISA IgG B/Yam Fluarix: GMT(EC50) wk0/wk4/late; GMFR wk4; n | 1500 / 3038 / 2113; 2.03; n=37 | elisa_igg_titers.csv | 03_elisa_igm.py |
| E8 | ELISA IgG B/Yam mRNA-1010: GMT(EC50) wk0/wk4/late; GMFR wk4; n | 1669 / 4449 / 2431; 2.67; n=38 | elisa_igg_titers.csv | 03_elisa_igm.py |
| E9 | ELISA IgG A/H1 GMT ratio mRNA-1010/Fluarix, baseline-adjusted: wk4; late | 2.66 (2.01-3.53); 1.51 (1.19-1.91) | elisa_igg_titers.csv | 03_elisa_igm.py |
| E10 | ELISA IgG A/H3 GMT ratio mRNA-1010/Fluarix, baseline-adjusted: wk4; late | 3.31 (2.47-4.43); 2.06 (1.57-2.70) | elisa_igg_titers.csv | 03_elisa_igm.py |
| E11 | ELISA IgG B/Vic GMT ratio mRNA-1010/Fluarix, baseline-adjusted: wk4; late | 1.35 (1.04-1.75); 0.99 (0.78-1.26) | elisa_igg_titers.csv | 03_elisa_igm.py |
| E12 | ELISA IgG B/Yam GMT ratio mRNA-1010/Fluarix, baseline-adjusted: wk4; late | 1.38 (1.11-1.71); 1.06 (0.88-1.29) | elisa_igg_titers.csv | 03_elisa_igm.py |
| G1 | IgM fold-change (timepoint not stated in file) B/Vic Fluarix: GMFR (n); between-arm MWU p | 4.40 (n=15); p=0.038 | igm_fold_change.csv | 03_elisa_igm.py |
| G2 | IgM fold-change (timepoint not stated in file) B/Vic mRNA-1010: GMFR (n); between-arm MWU p | 1.55 (n=14); p=0.038 | igm_fold_change.csv | 03_elisa_igm.py |
| G3 | IgM fold-change (timepoint not stated in file) B/Yam Fluarix: GMFR (n); between-arm MWU p | 5.77 (n=15); p=0.049 | igm_fold_change.csv | 03_elisa_igm.py |
| G4 | IgM fold-change (timepoint not stated in file) B/Yam mRNA-1010: GMFR (n); between-arm MWU p | 1.94 (n=14); p=0.049 | igm_fold_change.csv | 03_elisa_igm.py |
| G5 | IgM fold-change (timepoint not stated in file) H1 Fluarix: GMFR (n); between-arm MWU p | 3.99 (n=15); p=0.340 | igm_fold_change.csv | 03_elisa_igm.py |
| G6 | IgM fold-change (timepoint not stated in file) H1 mRNA-1010: GMFR (n); between-arm MWU p | 2.11 (n=14); p=0.340 | igm_fold_change.csv | 03_elisa_igm.py |
| G7 | IgM fold-change (timepoint not stated in file) H3 Fluarix: GMFR (n); between-arm MWU p | 5.53 (n=15); p=0.013 | igm_fold_change.csv | 03_elisa_igm.py |
| G8 | IgM fold-change (timepoint not stated in file) H3 mRNA-1010: GMFR (n); between-arm MWU p | 1.83 (n=14); p=0.013 | igm_fold_change.csv | 03_elisa_igm.py |
| B1 | Bead-array binding log2 fold-change A/Brisbane/2/2018 (H1): mRNA-1010 mean vs Fluarix mean (MWU p) | 1.15 vs 0.77 (p=0.047) | binding_breadth_h1.csv | 06_binding_vs_neut.py -> bead_array_summary.csv |
| B2 | Bead-array binding log2 fold-change A/California/04/2009 (H1): mRNA-1010 mean vs Fluarix mean (MWU p) | 1.40 vs 0.78 (p=0.015) | binding_breadth_h1.csv | 06_binding_vs_neut.py -> bead_array_summary.csv |
| B3 | Bead-array binding log2 fold-change A/Guangdong-Maonan/SWL1536/2019 (H1): mRNA-1010 mean vs Fluarix mean (MWU p) | 1.47 vs 0.80 (p=0.015) | binding_breadth_h1.csv | 06_binding_vs_neut.py -> bead_array_summary.csv |
| B4 | Bead-array binding log2 fold-change A/Hawaii/70/2019 (H1): mRNA-1010 mean vs Fluarix mean (MWU p) | 1.14 vs 0.81 (p=0.102) | binding_breadth_h1.csv | 06_binding_vs_neut.py -> bead_array_summary.csv |
| B5 | Bead-array binding log2 fold-change A/Michigan/45/2015 (H1): mRNA-1010 mean vs Fluarix mean (MWU p) | 1.80 vs 0.93 (p=0.009) | binding_breadth_h1.csv | 06_binding_vs_neut.py -> bead_array_summary.csv |
| B6 | Bead-array binding log2 fold-change A/Puerto Rico/8/1934 (H1): mRNA-1010 mean vs Fluarix mean (MWU p) | 1.54 vs 0.10 (p=0.000) | binding_breadth_h1.csv | 06_binding_vs_neut.py -> bead_array_summary.csv |
| B7 | Bead-array binding log2 fold-change A/Sydney/5/2021 (H1): mRNA-1010 mean vs Fluarix mean (MWU p) | 2.21 vs 0.87 (p=0.003) | binding_breadth_h1.csv | 06_binding_vs_neut.py -> bead_array_summary.csv |
| B8 | Bead-array binding log2 fold-change A/Wisconsin/588/2019 (H1): mRNA-1010 mean vs Fluarix mean (MWU p) | 1.98 vs 0.96 (p=0.008) | binding_breadth_h1.csv | 06_binding_vs_neut.py -> bead_array_summary.csv |
| B9 | Bead-array binding log2 fold-change A/Wisconsin/67/2022 (H1): mRNA-1010 mean vs Fluarix mean (MWU p) | 2.03 vs 0.62 (p=0.001) | binding_breadth_h1.csv | 06_binding_vs_neut.py -> bead_array_summary.csv |
| B10 | Bead-array binding log2 fold-change A/Brisbane/10/2007 (H3): mRNA-1010 mean vs Fluarix mean (MWU p) | 2.03 vs 0.22 (p=0.000) | binding_breadth_h3.csv | 06_binding_vs_neut.py -> bead_array_summary.csv |
| B11 | Bead-array binding log2 fold-change A/Cambodia/e0826360/2020 (H3): mRNA-1010 mean vs Fluarix mean (MWU p) | 3.58 vs 1.03 (p=0.000) | binding_breadth_h3.csv | 06_binding_vs_neut.py -> bead_array_summary.csv |
| B12 | Bead-array binding log2 fold-change A/Darwin/6/2021 (H3): mRNA-1010 mean vs Fluarix mean (MWU p) | 4.71 vs 2.10 (p=0.002) | binding_breadth_h3.csv | 06_binding_vs_neut.py -> bead_array_summary.csv |
| B13 | Bead-array binding log2 fold-change A/Hong Kong/1/1968 (H3): mRNA-1010 mean vs Fluarix mean (MWU p) | 3.45 vs 0.20 (p=0.000) | binding_breadth_h3.csv | 06_binding_vs_neut.py -> bead_array_summary.csv |
| B14 | Bead-array binding log2 fold-change A/Hong Kong/2671/2019 (H3): mRNA-1010 mean vs Fluarix mean (MWU p) | 2.43 vs 0.47 (p=0.000) | binding_breadth_h3.csv | 06_binding_vs_neut.py -> bead_array_summary.csv |
| B15 | Bead-array binding log2 fold-change A/Perth/16/2009 (H3): mRNA-1010 mean vs Fluarix mean (MWU p) | 2.23 vs 0.39 (p=0.000) | binding_breadth_h3.csv | 06_binding_vs_neut.py -> bead_array_summary.csv |
| B16 | Bead-array binding log2 fold-change A/Singapore/INFIMH-16-0019/2016 (H3): mRNA-1010 mean vs Fluarix mean (MWU p) | 4.32 vs 0.99 (p=0.000) | binding_breadth_h3.csv | 06_binding_vs_neut.py -> bead_array_summary.csv |
| B17 | Bead-array binding log2 fold-change A/South Australia/34/2019 (H3): mRNA-1010 mean vs Fluarix mean (MWU p) | 3.95 vs 1.10 (p=0.001) | binding_breadth_h3.csv | 06_binding_vs_neut.py -> bead_array_summary.csv |
| B18 | Bead-array binding log2 fold-change A/Switzerland/8060/2017 (H3): mRNA-1010 mean vs Fluarix mean (MWU p) | 4.46 vs 1.17 (p=0.000) | binding_breadth_h3.csv | 06_binding_vs_neut.py -> bead_array_summary.csv |
| B19 | Bead-array binding log2 fold-change A/Texas/50/2012 (H3): mRNA-1010 mean vs Fluarix mean (MWU p) | 2.37 vs 0.45 (p=0.000) | binding_breadth_h3.csv | 06_binding_vs_neut.py -> bead_array_summary.csv |
| B20 | Bead-array binding log2 fold-change A/Thailand/8/2022 (H3): mRNA-1010 mean vs Fluarix mean (MWU p) | 4.99 vs 1.75 (p=0.001) | binding_breadth_h3.csv | 06_binding_vs_neut.py -> bead_array_summary.csv |
| B21 | Bead-array binding log2 fold-change A/Victoria/361/2011 (H3): mRNA-1010 mean vs Fluarix mean (MWU p) | 2.17 vs 0.55 (p=0.001) | binding_breadth_h3.csv | 06_binding_vs_neut.py -> bead_array_summary.csv |
| B22 | Bead-array panels: strains (H1 / H3); strains isolated after 2021 | 9 / 12; H1: A/Wisconsin/67/2022 only; H3: A/Thailand/8/2022 only | binding_breadth_h1.csv, binding_breadth_h3.csv | strain lists read directly (bead_array_summary.csv) |
| Q1 | Seq-neut H1N1 Fluarix(2022-23) strain-matched (1 viruses): d29 GMT mRNA vs Fluarix; GMFR; adj ratio d29 (95%CI); adj ratio late (95%CI) | 1073 vs 506; 6.15 vs 2.34; 2.44 (1.18-5.05) p=0.019; 1.17 (0.62-2.23) p=0.62 | neutralization_seqbased.csv | 04/05_seqneut*.py; participant-level means over viruses in category; ANCOVA on baseline |
| Q2 | Seq-neut H1N1 contemporary 2022-24 wild-type (6 viruses): d29 GMT mRNA vs Fluarix; GMFR; adj ratio d29 (95%CI); adj ratio late (95%CI) | 478 vs 257; 4.07 vs 1.95; 2.06 (1.23-3.46) p=0.008; 1.17 (0.77-1.77) p=0.44 | neutralization_seqbased.csv | 04/05_seqneut*.py; participant-level means over viruses in category; ANCOVA on baseline |
| Q3 | Seq-neut H1N1 historical (<=2021) wild-type (4 viruses): d29 GMT mRNA vs Fluarix; GMFR; adj ratio d29 (95%CI); adj ratio late (95%CI) | 2533 vs 1687; 3.59 vs 1.97; 1.69 (0.91-3.13) p=0.091; 1.11 (0.61-2.03) p=0.73 | neutralization_seqbased.csv | 04/05_seqneut*.py; participant-level means over viruses in category; ANCOVA on baseline |
| Q4 | Seq-neut H1N1 mRNA-1010 strain-matched (2 viruses): d29 GMT mRNA vs Fluarix; GMFR; adj ratio d29 (95%CI); adj ratio late (95%CI) | 996 vs 537; 3.73 vs 2.03; 1.84 (1.17-2.90) p=0.011; 1.15 (0.76-1.72) p=0.50 | neutralization_seqbased.csv | 04/05_seqneut*.py; participant-level means over viruses in category; ANCOVA on baseline |
| Q5 | Seq-neut H3N2 Fluarix(2022-23) strain-matched (1 viruses): d29 GMT mRNA vs Fluarix; GMFR; adj ratio d29 (95%CI); adj ratio late (95%CI) | 1009 vs 1539; 4.78 vs 4.49; 0.81 (0.35-1.87) p=0.610; 0.57 (0.25-1.27) p=0.16 | neutralization_seqbased.csv | 04/05_seqneut*.py; participant-level means over viruses in category; ANCOVA on baseline |
| Q6 | Seq-neut H3N2 contemporary 2022-24 wild-type (68 viruses): d29 GMT mRNA vs Fluarix; GMFR; adj ratio d29 (95%CI); adj ratio late (95%CI) | 402 vs 467; 2.80 vs 2.17; 1.17 (0.64-2.12) p=0.598; 1.05 (0.65-1.68) p=0.85 | neutralization_seqbased.csv | 04/05_seqneut*.py; participant-level means over viruses in category; ANCOVA on baseline |
| Q7 | Seq-neut H3N2 historical (<=2021) wild-type (8 viruses): d29 GMT mRNA vs Fluarix; GMFR; adj ratio d29 (95%CI); adj ratio late (95%CI) | 1524 vs 1273; 3.70 vs 1.79; 1.63 (0.99-2.68) p=0.056; 1.44 (0.87-2.40) p=0.15 | neutralization_seqbased.csv | 04/05_seqneut*.py; participant-level means over viruses in category; ANCOVA on baseline |
| Q8 | Seq-neut H3N2 historical egg/reassortant (5 viruses): d29 GMT mRNA vs Fluarix; GMFR; adj ratio d29 (95%CI); adj ratio late (95%CI) | 4751 vs 3345; 2.43 vs 1.54; 1.54 (1.05-2.27) p=0.029; 1.37 (0.85-2.21) p=0.18 | neutralization_seqbased.csv | 04/05_seqneut*.py; participant-level means over viruses in category; ANCOVA on baseline |
| Q9 | Seq-neut H3N2 mRNA-1010 strain-matched (1 viruses): d29 GMT mRNA vs Fluarix; GMFR; adj ratio d29 (95%CI); adj ratio late (95%CI) | 244 vs 482; 2.24 vs 2.74; 0.62 (0.34-1.12) p=0.109; 0.72 (0.40-1.31) p=0.27 | neutralization_seqbased.csv | 04/05_seqneut*.py; participant-level means over viruses in category; ANCOVA on baseline |
| Q10 | Seq-neut A/Thailand/8/2022_H3N2: d29 GMT mRNA vs Fluarix; adj ratio; >=4-fold risers | 480 vs 695; 0.82 (p=0.63); 1/13 vs 4/14 | neutralization_seqbased.csv | 05_seqneut_bysubtype.py |
| Q11 | Seq-neut A/Massachusetts/18/2022_H3N2: d29 GMT mRNA vs Fluarix; adj ratio; >=4-fold risers | 381 vs 550; 0.90 (p=0.76); 1/12 vs 4/13 | neutralization_seqbased.csv | 05_seqneut_bysubtype.py |
| Q12 | Seq-neut A/Darwin/6/2021_H3N2: d29 GMT mRNA vs Fluarix; adj ratio; >=4-fold risers | 244 vs 482; 0.62 (p=0.11); 2/13 vs 4/14 | neutralization_seqbased.csv | 05_seqneut_bysubtype.py |
| Q13 | Seq-neut A/Darwin/9/2021_H3N2: d29 GMT mRNA vs Fluarix; adj ratio; >=4-fold risers | 1009 vs 1539; 0.81 (p=0.61); 7/13 vs 5/14 | neutralization_seqbased.csv | 05_seqneut_bysubtype.py |
| Q14 | Seq-neut A/Wisconsin/67/2022_H1N1: d29 GMT mRNA vs Fluarix; adj ratio; >=4-fold risers | 431 vs 197; 2.07 (p=0.01); 6/13 vs 1/14 | neutralization_seqbased.csv | 05_seqneut_bysubtype.py |
| Q15 | Seq-neut A/Wisconsin/588/2019_H1N1: d29 GMT mRNA vs Fluarix; adj ratio; >=4-fold risers | 1073 vs 506; 2.44 (p=0.02); 9/13 vs 2/14 | neutralization_seqbased.csv | 05_seqneut_bysubtype.py |
| Q16 | Seq-neut A/Victoria/4897/2022_IVR-238_H1N1: d29 GMT mRNA vs Fluarix; adj ratio; >=4-fold risers | 2300 vs 1467; 1.60 (p=0.09); 7/13 vs 3/14 | neutralization_seqbased.csv | 05_seqneut_bysubtype.py |
| Q17 | Contemporary H3N2 viruses: per-virus adj ratio median (range); n with nominal p<0.05 | 1.15 (0.82-1.51); 0 of 68 | neutralization_seqbased.csv | 05_seqneut_bysubtype.py |
| Q18 | Contemporary H1N1 viruses: per-virus adj ratio range; n nominal p<0.05 | 1.93-2.29; 6 of 6 | neutralization_seqbased.csv | 05_seqneut_bysubtype.py |
| Q19 | Seq-neut H1N1 decline d29 -> d121/181 (fold): mRNA-1010 vs Fluarix (MWU p) | 2.16 vs 1.28 (p=0.0005) | neutralization_seqbased.csv | 10_egg_pairs_and_decay.py |
| Q20 | Seq-neut H3N2 decline d29 -> d121/181 (fold): mRNA-1010 vs Fluarix (MWU p) | 1.57 vs 1.45 (p=0.42) | neutralization_seqbased.csv | 10_egg_pairs_and_decay.py |
| Q21 | Egg/reassortant vs matched wild-type d29 titre ratio, range across 6 pairs and both arms | 1.38-7.46x higher for egg/reassortant | neutralization_seqbased.csv | 10_egg_pairs_and_decay.py |
| Q22 | Contemporary H3N2 d29: participant-level mixed model ratio vs naive virus-level OLS | 1.06 (0.62-1.82), p=0.82 vs 1.13 (1.05-1.21), p=0.0018 | neutralization_seqbased.csv | 12_seqneut_sensitivity.py |
| Q23 | Mean log2 ratio of 2023 H1N1 isolate titres to A/Wisconsin/67/2022 (cell equivalent of mRNA-1010 H1) at d0 / d29: mRNA-1010; Fluarix | -0.07 / 0.15; 0.18 / 0.38 (i.e., within 1.3-fold: antigenically equivalent to the mRNA-1010 H1) | neutralization_seqbased.csv | 13_backward_shift_and_panel_identity.py (d) |
| Q24 | Seq-neut panel composition (categories assigned a priori in 04_seqneut.py) | 96 = 68 + 6 contemporary; 8 + 4 historical wild-type; 5 historical egg/reassortant H3N2; 3 mRNA-1010-matched (A/Wisconsin/67/2022, A/Victoria/4897/2022 IVR-238 [egg reassortant], A/Darwin/6/2021); 2 Fluarix-matched (A/Wisconsin/588/2019, A/Darwin/9/2021); 0 influenza B | neutralization_seqbased.csv | 04_seqneut.py (seqneut_virus_categories.csv) |
| Q25 | Seq-neut titres outside quantifiable range (of 7,719): below LOD (reported as upper bound, mostly 40); above ULOQ (lower bound, mostly 17,300) | 171; 70 | neutralization_seqbased.csv | 04_seqneut.py (titer_bound counts) |
| Q26 | Malformed virus name in seq-neut panel | A/SOUTHAFRICA/R07876/202023_H3N2 (treated as a 2023 isolate) | neutralization_seqbased.csv | 04_seqneut.py |
| Q27 | Seq-neut late visit: participants sampled at d121 vs d181 (Fluarix + mRNA-1010) | d121: 4 + 2; d181: 10 + 11 | neutralization_seqbased.csv | 15_build_ledger.py (serum name parsing) |
| Q28 | Screen for intercurrent infection: max number of viruses with >=4-fold rise from d29 to late visit in any participant | 2 of 83 H3N2 viruses (Fluarix 397-024); all other participants 0 | neutralization_seqbased.csv | 09_intercurrent.py |
| V1 | A/Brisbane/2/2018: binding log2FC diff (mRNA-Flu) vs neutralisation log2FC diff (mRNA-Flu); Spearman r binding~neut | 0.72 vs 0.92; r=0.72 | binding_breadth_h1/h3.csv + neutralization_seqbased.csv | 06_binding_vs_neut.py |
| V2 | A/Hawaii/70/2019: binding log2FC diff (mRNA-Flu) vs neutralisation log2FC diff (mRNA-Flu); Spearman r binding~neut | 0.69 vs 0.87; r=0.71 | binding_breadth_h1/h3.csv + neutralization_seqbased.csv | 06_binding_vs_neut.py |
| V3 | A/Michigan/45/2015: binding log2FC diff (mRNA-Flu) vs neutralisation log2FC diff (mRNA-Flu); Spearman r binding~neut | 1.19 vs 0.88; r=0.72 | binding_breadth_h1/h3.csv + neutralization_seqbased.csv | 06_binding_vs_neut.py |
| V4 | A/Wisconsin/588/2019: binding log2FC diff (mRNA-Flu) vs neutralisation log2FC diff (mRNA-Flu); Spearman r binding~neut | 1.30 vs 1.39; r=0.75 | binding_breadth_h1/h3.csv + neutralization_seqbased.csv | 06_binding_vs_neut.py |
| V5 | A/Wisconsin/67/2022: binding log2FC diff (mRNA-Flu) vs neutralisation log2FC diff (mRNA-Flu); Spearman r binding~neut | 1.56 vs 1.05; r=0.48 | binding_breadth_h1/h3.csv + neutralization_seqbased.csv | 06_binding_vs_neut.py |
| V6 | A/California/04/2009: binding log2FC diff (mRNA-Flu) vs neutralisation log2FC diff (mRNA-Flu); Spearman r binding~neut | 0.97 vs 0.77; r=0.56 | binding_breadth_h1/h3.csv + neutralization_seqbased.csv | 06_binding_vs_neut.py |
| V7 | A/Darwin/6/2021: binding log2FC diff (mRNA-Flu) vs neutralisation log2FC diff (mRNA-Flu); Spearman r binding~neut | 2.85 vs -0.29; r=0.48 | binding_breadth_h1/h3.csv + neutralization_seqbased.csv | 06_binding_vs_neut.py |
| V8 | A/Thailand/8/2022: binding log2FC diff (mRNA-Flu) vs neutralisation log2FC diff (mRNA-Flu); Spearman r binding~neut | 3.57 vs -0.17; r=0.33 | binding_breadth_h1/h3.csv + neutralization_seqbased.csv | 06_binding_vs_neut.py |
| V9 | A/Texas/50/2012: binding log2FC diff (mRNA-Flu) vs neutralisation log2FC diff (mRNA-Flu); Spearman r binding~neut | 2.14 vs 0.95; r=0.70 | binding_breadth_h1/h3.csv + neutralization_seqbased.csv | 06_binding_vs_neut.py |
| V10 | A/Hong Kong/2671/2019: binding log2FC diff (mRNA-Flu) vs neutralisation log2FC diff (mRNA-Flu); Spearman r binding~neut | 2.07 vs 1.12; r=0.67 | binding_breadth_h1/h3.csv + neutralization_seqbased.csv | 06_binding_vs_neut.py |
| V11 | A/Singapore/INFIMH-16-0019/2016: binding log2FC diff (mRNA-Flu) vs neutralisation log2FC diff (mRNA-Flu); Spearman r binding~neut | 3.43 vs 1.33; r=0.72 | binding_breadth_h1/h3.csv + neutralization_seqbased.csv | 06_binding_vs_neut.py |
| V12 | A/Cambodia/e0826360/2020: binding log2FC diff (mRNA-Flu) vs neutralisation log2FC diff (mRNA-Flu); Spearman r binding~neut | 2.67 vs 0.90; r=0.61 | binding_breadth_h1/h3.csv + neutralization_seqbased.csv | 06_binding_vs_neut.py |
| V13 | Binding-minus-neutralisation log2FC gap (mean of paired strains) H3: mRNA-1010 vs Fluarix; H1 | H3: 2.21 vs 0.03 (MWU p=0.0001); H1: -0.41 vs -0.50 (p=0.87) | binding_breadth_h1/h3.csv + neutralization_seqbased.csv | 06_binding_vs_neut.py |
| R1 | H1: 5a.2a.1 (mRNA-1010 H1, cell-equivalent) vs 5a.2 (Fluarix-equivalent/prior season) / Fluarix: log2(new/old) d0 -> d29; shift (paired p); between-arm p | -0.89 -> -1.36; -0.47 (p=0.358); 0.049 | neutralization_seqbased.csv | 13_backward_shift_and_panel_identity.py |
| R2 | H1: 5a.2a.1 (mRNA-1010 H1, cell-equivalent) vs 5a.2 (Fluarix-equivalent/prior season) / mRNA-1010: log2(new/old) d0 -> d29; shift (paired p); between-arm p | -0.50 -> -1.31; -0.81 (p=0.003); 0.049 | neutralization_seqbased.csv | 13_backward_shift_and_panel_identity.py |
| R3 | H3: Darwin/6/2021 (mRNA-1010 H3) vs Cambodia/2020 (2021-22 vaccine strain) / Fluarix: log2(new/old) d0 -> d29; shift (paired p); between-arm p | -0.59 -> -0.30; 0.28 (p=0.358); 0.022 | neutralization_seqbased.csv | 13_backward_shift_and_panel_identity.py |
| R4 | H3: Darwin/6/2021 (mRNA-1010 H3) vs Cambodia/2020 (2021-22 vaccine strain) / mRNA-1010: log2(new/old) d0 -> d29; shift (paired p); between-arm p | -0.32 -> -1.33; -1.01 (p=0.021); 0.022 | neutralization_seqbased.csv | 13_backward_shift_and_panel_identity.py |
| R5 | Spearman correlation of MN homologous titres with seq-neut mean of all H1N1 viruses | levels 0.11; fold-rise -0.19 | microneutralization.csv / hai_titers.csv + neutralization_seqbased.csv | 13_backward_shift_and_panel_identity.py |
| R6 | Spearman correlation of MN homologous titres with seq-neut mean of all H3N2 viruses | levels 0.54; fold-rise 0.52 | microneutralization.csv / hai_titers.csv + neutralization_seqbased.csv | 13_backward_shift_and_panel_identity.py |
| R7 | Spearman correlation of MN heterologous titres with seq-neut mean of all H1N1 viruses | levels 0.15; fold-rise 0.08 | microneutralization.csv / hai_titers.csv + neutralization_seqbased.csv | 13_backward_shift_and_panel_identity.py |
| R8 | Spearman correlation of MN heterologous titres with seq-neut mean of all H3N2 viruses | levels 0.52; fold-rise 0.61 | microneutralization.csv / hai_titers.csv + neutralization_seqbased.csv | 13_backward_shift_and_panel_identity.py |
| R9 | Spearman correlation of HAI A/H1N1 titres with seq-neut A/Victoria/4897/2022_IVR-238_H1N1 | levels 0.78; fold-rise 0.60 | microneutralization.csv / hai_titers.csv + neutralization_seqbased.csv | 13_backward_shift_and_panel_identity.py |
| R10 | Spearman correlation of HAI A/H1N1 titres with seq-neut A/Wisconsin/588/2019_H1N1 | levels 0.74; fold-rise 0.58 | microneutralization.csv / hai_titers.csv + neutralization_seqbased.csv | 13_backward_shift_and_panel_identity.py |
| R11 | Spearman correlation of HAI A/H1N1 titres with seq-neut A/Wisconsin/67/2022_H1N1 | levels 0.68; fold-rise 0.39 | microneutralization.csv / hai_titers.csv + neutralization_seqbased.csv | 13_backward_shift_and_panel_identity.py |
| A1 | mAbs group_I donor 05 (Fluarix): n mAbs; % binding forward strain(s); % cross-subtype (>10x over control) | 61; 93.4%; 4.9% | mab_binding_panels.csv | 07_mabs.py |
| A2 | mAbs group_I donor 09 (Fluarix): n mAbs; % binding forward strain(s); % cross-subtype (>10x over control) | 9; 77.8%; 0.0% | mab_binding_panels.csv | 07_mabs.py |
| A3 | mAbs group_I donor 22 (Fluarix): n mAbs; % binding forward strain(s); % cross-subtype (>10x over control) | 4; 50.0%; 0.0% | mab_binding_panels.csv | 07_mabs.py |
| A4 | mAbs group_I donor 06 (mRNA-1010): n mAbs; % binding forward strain(s); % cross-subtype (>10x over control) | 122; 93.4%; 9.0% | mab_binding_panels.csv | 07_mabs.py |
| A5 | mAbs group_I donor 17 (mRNA-1010): n mAbs; % binding forward strain(s); % cross-subtype (>10x over control) | 51; 94.1%; 2.0% | mab_binding_panels.csv | 07_mabs.py |
| A6 | mAbs group_I donor 28 (mRNA-1010): n mAbs; % binding forward strain(s); % cross-subtype (>10x over control) | 25; 84.0%; 0.0% | mab_binding_panels.csv | 07_mabs.py |
| A7 | mAbs group_I donor 29 (mRNA-1010): n mAbs; % binding forward strain(s); % cross-subtype (>10x over control) | 66; 86.4%; 1.5% | mab_binding_panels.csv | 07_mabs.py |
| A8 | mAbs group_II donor 05 (Fluarix): n mAbs; % binding forward strain(s); % cross-subtype (>10x over control) | 25; 48.0%; 0.0% | mab_binding_panels.csv | 07_mabs.py |
| A9 | mAbs group_II donor 09 (Fluarix): n mAbs; % binding forward strain(s); % cross-subtype (>10x over control) | 2; 0.0%; 0.0% | mab_binding_panels.csv | 07_mabs.py |
| A10 | mAbs group_II donor 22 (Fluarix): n mAbs; % binding forward strain(s); % cross-subtype (>10x over control) | 7; 0.0%; 0.0% | mab_binding_panels.csv | 07_mabs.py |
| A11 | mAbs group_II donor 06 (mRNA-1010): n mAbs; % binding forward strain(s); % cross-subtype (>10x over control) | 89; 61.8%; 21.3% | mab_binding_panels.csv | 07_mabs.py |
| A12 | mAbs group_II donor 17 (mRNA-1010): n mAbs; % binding forward strain(s); % cross-subtype (>10x over control) | 113; 35.4%; 8.0% | mab_binding_panels.csv | 07_mabs.py |
| A13 | mAbs group_II donor 28 (mRNA-1010): n mAbs; % binding forward strain(s); % cross-subtype (>10x over control) | 31; 67.7%; 6.5% | mab_binding_panels.csv | 07_mabs.py |
| A14 | mAbs group_II donor 29 (mRNA-1010): n mAbs; % binding forward strain(s); % cross-subtype (>10x over control) | 116; 43.1%; 2.6% | mab_binding_panels.csv | 07_mabs.py |
| A15 | mAbs per arm (donors) | mRNA-1010 589 (4 donors: 06, 17, 28, 29); Fluarix 106 (3 donors: 05, 09, 22); group II (H3) mAbs from Fluarix donors 09 and 22: 2 and 7 | mab_binding_panels.csv | 07_mabs.py |
| A16 | SARS-CoV-2 RBD control value for every mAb | exactly 1.0 (it is the normaliser, not an independent negative control) | mab_binding_panels.csv | 07_mabs.py (control check) |
| A17 | Median ratio of binding to A/Victoria/4897/2022 (mRNA-1010 H1) over A/Wisconsin/588/2019 among group I mAbs, mRNA-1010 donors | 0.24-0.54 (i.e., mAbs bind the older 5a.2 HA better than the vaccine HA); 1 of 264 mRNA-1010 group I mAbs binds Vic/4897 but not Wisc/588 | mab_binding_panels.csv | 07_mabs.py -> mab_h1_vic_vs_wisc.csv |
| A18 | Smallest attainable exact two-sided Mann-Whitney p with 4 vs 3 donors | 2/C(7,3) = 2/35 = 0.057 | computed | combinatorial |
| C1 | HA-specific IgG GC B cells (%), week 2, median mRNA-1010 vs Fluarix (n; MWU p) | 24.2 (n=6) vs 2.3 (n=11); p=0.037 | gc_frequencies.csv (first block) | 08_repertoire_cellular.py |
| C2 | HA-specific GC B cells (%) median wk17 / wk26, mRNA-1010 vs Fluarix | wk17 16.0 vs 2.3 (p=0.083); wk26 18.9 vs 1.6 (p=0.34) | gc_frequencies.csv (first block) | 08_repertoire_cellular.py |
| C3 | % of GC B-cell clones overlapping week-1 plasmablast clones (mRNA-1010 donors 06/17/28/29; Fluarix 05/09/22) | 92 / 90.9 / 83.3 / 73.0; Fluarix 100 / 20 / 0 (GC clones 7 / 5 / 1) | pb_gc_clonal_overlap.csv | read directly |
| C4 | Serum IgG abundance from pre-existing clonotypes, mean %, mRNA-1010 vs Fluarix (n=8 each) | 83.9 vs 86.2 (p=0.72) | repertoire_clonotype_counts.csv | 08_repertoire_cellular.py |
| C5 | Vaccine-elicited serum clonotypes, mean, mRNA-1010 vs Fluarix | 32.0 vs 20.1 (p=0.066) | repertoire_clonotype_counts.csv | 08_repertoire_cellular.py |
| C6 | CDR-H3 diversity index wk4 mean, mRNA-1010 vs Fluarix (n=8 each) | 71.2 vs 24.9 (p=0.010) | cdrh3_diversity_index.csv | 08_repertoire_cellular.py |
| P1 | Residual SD (log2) of participant-level breadth score at d29 (ANCOVA), contemporary H1N1 / H3N2; raw SD | 0.94 / 1.03; raw 1.65 / 1.21 | neutralization_seqbased.csv | 11_sample_size.py |
| P2 | Evaluable n/arm for GMT ratio 1.5, 90% power, two-sided alpha 0.0125, SD 1.0 / 1.25 / 1.5 | 84 / 131 / 188 | computed | 11_sample_size.py |
| P3 | Evaluable n/arm for LB of GMT ratio > 1.5 (true 2.0, 90% power), SD 1.0 / 1.25: alpha 0.05 two-sided; alpha 0.0125 | 122 / 191; 166 / 260 | computed | 11_sample_size.py |
| P4 | Evaluable n/arm for HAI GMT-ratio non-inferiority (LB > 0.667, true 1.0, 90% power), SD 1.0 / 1.25 / 1.36 | 63 / 99 / 117 | computed (SDs from hai_titers.csv) | 11_sample_size.py |
| P5 | True GMT ratio detectable with 80% power by WU397-sized arms (n=14), SD 1.03 | ~2.13 | computed | 11_sample_size.py |
| P6 | Raw SD of log2 HAI titre at wk4 (H1 / H3 / B-Vic / B-Yam) | 1.02 / 1.36 / 1.03 / 0.86 | hai_titers.csv | 11_sample_size.py |
| P7 | CHIM n/arm: infection 50% vs 25% (80%/90% power); 50% vs 20%; 40% vs 20% | 58/77; 39/52; 82/109 | assumed attack rates | 11_sample_size.py |
| P8 | Cases for rVE 25% (90% power, 1-sided 0.025); participants at 2% attack; if 40% of cases mismatched | ~508 cases; ~29,000; ~72,600 | assumed attack rates | 11_sample_size.py |
| P9 | Cases for rVE 20% / 30% (same assumptions) | ~845 / ~331 | assumed | 11_sample_size.py |
| P10 | Planned n=150 evaluable/arm, GMT ratio 1.5, alpha 0.0125: per-comparison power (SD 1.0 / 1.25); joint power of 4 comparisons if independent | >0.99 / 0.94; 0.98 / 0.78 (joint power is higher because the comparisons share participants) | computed | 11_sample_size.py |
| X1 | WHO 2022-23 NH composition, egg-based (Fluarix): H1 / H3 / B-Vic / B-Yam | A/Victoria/2570/2019 / A/Darwin/9/2021 / B/Austria/1359417/2021 / B/Phuket/3073/2013 (cell/recombinant equivalents: A/Wisconsin/588/2019, A/Darwin/6/2021) | EXTERNAL (not in data package) - verify against source | WHO recommendation Feb 2022; confirm against the Fluarix lot labelling |
| X2 | WHO 2021-22 NH egg-based composition (H1; H3) | A/Victoria/2570/2019 (identical to 2022-23); A/Cambodia/e0826360/2020 | EXTERNAL (not in data package) - verify against source | WHO recommendation Feb 2021 |
| X3 | First WHO recommendation of A/Victoria/4897/2022 (egg) / A/Wisconsin/67/2022 (cell) H1 | 2023-24 NH (Feb 2023) | EXTERNAL (not in data package) - verify against source | WHO recommendation Feb 2023 |
| X4 | B/Yamagata lineage | no confirmed circulation since March 2020; WHO advised removal; trivalent vaccines from 2024-25 NH | EXTERNAL (not in data package) - verify against source | WHO 2023-24 statements; FDA VRBPAC Mar 2024 |
| X5 | FDA immunogenicity non-inferiority criteria (seasonal IIV accelerated approval) | UB 95% CI GMT ratio (comparator/new) <=1.5; UB SCR difference (comparator-new) <=10 percentage points | EXTERNAL (not in data package) - verify against source | FDA guidance 2007 |
| X6 | Superiority criteria used for high-dose IIV HAI claim | LB 95% CI GMT ratio >1.5 and LB SCR difference >10 percentage points | EXTERNAL (not in data package) - verify against source | Falsey et al., J Infect Dis 2009 |
| X7 | US preferential recommendation for >=65 y | HD-IIV, RIV or adjuvanted IIV (ACIP, 2022) | EXTERNAL (not in data package) - verify against source | ACIP 2022 |
| X8 | NA-inhibiting antibody | independent correlate of protection from HAI (human cohort and challenge studies) | EXTERNAL (not in data package) - verify against source | e.g., Monto 2015 JID; Memoli 2016 mBio |
| X9 | HAI >=1:40 | conventional seroprotection threshold (~50% protection vs homologous strain) | EXTERNAL (not in data package) - verify against source | Hobson 1972 |
| X10 | mRNA-1010 antigen format | understood to encode membrane-anchored HA only (no NA); the trial summary does not state this - confirm | EXTERNAL (not in data package) - verify against source | sponsor documentation |
| X11 | WHO 2024-25 NH H3N2 components | A/Thailand/8/2022 (egg-based) and A/Massachusetts/18/2022 (cell/recombinant) | EXTERNAL (not in data package) - verify against source | WHO recommendation Feb 2024 |
| X12 | HA clade assignments used in the text | A/Victoria/4897/2022 and A/Wisconsin/67/2022: 6B.1A.5a.2a.1; A/Victoria/2570/2019 and A/Wisconsin/588/2019: 6B.1A.5a.2 | EXTERNAL (not in data package) - verify against source | WHO/CDC strain characterisation reports |
| X13 | Origin of early (week-1) plasmablasts after seasonal influenza vaccination in adults | predominantly pre-existing memory B cells; GC clones shared with them indicate memory recruitment into germinal centres | EXTERNAL (not in data package) - verify against source | e.g., Turner et al., Nature 2020 (human lymph-node FNA after influenza vaccination) |
