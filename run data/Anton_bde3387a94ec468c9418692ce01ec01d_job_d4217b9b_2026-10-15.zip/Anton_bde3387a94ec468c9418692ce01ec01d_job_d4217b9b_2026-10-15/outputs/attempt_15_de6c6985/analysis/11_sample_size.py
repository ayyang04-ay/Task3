"""Variance inputs from WU397 for sizing the next immunogenicity study, plus illustrative sizing for challenge and efficacy studies.
Sources: seqneut_participant_category.csv / seqneut_wide.csv (from neutralization_seqbased.csv), hai_wide.csv (from hai_titers.csv)"""
import pandas as pd, numpy as np
from scipy import stats
import statsmodels.formula.api as smf
w = pd.read_csv('/tmp/outputs/analysis/seqneut_wide.csv')
ps = w.groupby(['arm','pid','subtype','category']).agg(l0=('d0','mean'), l29=('d29','mean'), ll=('late','mean')).reset_index()
out=[]
for (st,c),g in ps.groupby(['subtype','category']):
    g=g.copy(); g['mrna']=(g.arm=='mRNA-1010').astype(int)
    m=smf.ols('l29 ~ mrna + l0', g).fit()
    m2=smf.ols('ll ~ mrna + l0', g.dropna(subset=['ll'])).fit()
    out.append(dict(subtype=st, category=c, sd_log2_d29_raw=g.groupby('arm').l29.std().mean(), resid_sd_log2_d29_ANCOVA=np.sqrt(m.scale), resid_sd_log2_late_ANCOVA=np.sqrt(m2.scale)))
O=pd.DataFrame(out); print(O.round(2).to_string())
h=pd.read_csv('/tmp/outputs/analysis/hai_wide.csv')
for ag,g in h.groupby('antigen'):
    g=g.dropna(subset=['wk0','wk4']).copy(); g['l0']=np.log2(g.wk0); g['l4']=np.log2(g.wk4); g['mrna']=(g.arm=='mRNA-1010').astype(int)
    m=smf.ols('l4 ~ mrna + l0', g).fit()
    print(f'HAI {ag}: raw SD log2 wk4 = {g.groupby("arm").l4.std().mean():.2f}; ANCOVA residual SD = {np.sqrt(m.scale):.2f}')
def n_per_arm(sd, ratio, alpha=0.05, power=0.9):
    d=np.log2(ratio); za=stats.norm.ppf(1-alpha/2); zb=stats.norm.ppf(power)
    return int(np.ceil(2*(za+zb)**2*sd**2/d**2))
print('\nn per arm (two-sided alpha 0.05, 90% power) to detect a GMT ratio, by assumed log2 SD:')
for sd in [1.0,1.25,1.5,2.0]:
    print(f'  SD {sd}: ratio 1.5 -> {n_per_arm(sd,1.5)}; ratio 2.0 -> {n_per_arm(sd,2.0)}; ratio 1.3 -> {n_per_arm(sd,1.3)}')
# Alpha split for 4 hypotheses (2 subtypes x 2 timepoints) Bonferroni 0.0125
print('With alpha 0.0125 (4 breadth hypotheses):', {sd: n_per_arm(sd,1.5,alpha=0.0125) for sd in [1.0,1.25,1.5,2.0]})
# HAI non-inferiority: GMT ratio margin 0.67, assume true ratio 1.0, SD 1.5 log2, one-sided alpha 0.025, 90% power
def n_ni_gmt(sd, margin=0.67, true=1.0, alpha=0.025, power=0.9):
    d=np.log2(true)-np.log2(margin); za=stats.norm.ppf(1-alpha); zb=stats.norm.ppf(power)
    return int(np.ceil(2*(za+zb)**2*sd**2/d**2))
print('HAI NI (margin 0.67, true ratio 1, 90% power) n/arm per strain: SD1.5 ->', n_ni_gmt(1.5), '; SD2.0 ->', n_ni_gmt(2.0))
# SCR NI margin -10%, assume SCR 40% both arms
def n_ni_prop(p=0.4, margin=0.10, alpha=0.025, power=0.9):
    za=stats.norm.ppf(1-alpha); zb=stats.norm.ppf(power)
    return int(np.ceil((za+zb)**2*2*p*(1-p)/margin**2))
print('SCR NI (margin -10%, SCR 40%/40%) n/arm:', n_ni_prop(0.4), ' (SCR 20%/20%):', n_ni_prop(0.2))
# Challenge study: infection rate in comparator arm 50% vs 25%, two-sided 0.05, 80/90% power
def n_two_prop(p1,p2,alpha=0.05,power=0.8):
    za=stats.norm.ppf(1-alpha/2); zb=stats.norm.ppf(power); pb=(p1+p2)/2
    return int(np.ceil((za*np.sqrt(2*pb*(1-pb))+zb*np.sqrt(p1*(1-p1)+p2*(1-p2)))**2/(p1-p2)**2))
for p1,p2 in [(0.5,0.25),(0.5,0.2),(0.4,0.2),(0.6,0.3)]:
    print(f'CHIM: infection {p1:.0%} vs {p2:.0%}: n/arm 80% power = {n_two_prop(p1,p2)}, 90% = {n_two_prop(p1,p2,power=0.9)}')
# Efficacy: events for rVE (1:1), Schoenfeld-type
def events(rve, alpha=0.025, power=0.9, null=0.0):
    za=stats.norm.ppf(1-alpha); zb=stats.norm.ppf(power)
    return int(np.ceil(4*(za+zb)**2/(np.log(1-rve)-np.log(1-null))**2))
for rve in [0.15,0.2,0.25,0.3]:
    e=events(rve)
    print(f'rVE {rve:.0%} vs 0 (superiority), 90% power: ~{e} total cases; if attack rate in comparator 2% -> ~{int(e/((0.02+0.02*(1-rve))/2)):,} participants total; if only 40% of cases are antigenically mismatched, mismatched-strain-specific test needs ~{int(e/0.4/((0.02+0.02*(1-rve))/2)):,}')
print('NI (rVE lower bound > -10%), true rVE 0.15, 90% power:', events(0.15, null=-0.10), 'cases')
# Additional variants cited in answer.md
def n_sup_lb(sd, true_ratio, lb_ratio, alpha_two_sided=0.05, power=0.9):
    d=np.log2(true_ratio)-np.log2(lb_ratio); za=stats.norm.ppf(1-alpha_two_sided/2); zb=stats.norm.ppf(power)
    return int(np.ceil(2*(za+zb)**2*sd**2/d**2))
print('\nDifferentiation bar (LB of GMT ratio > 1.5), true ratio 2.0, 90% power:')
for sd in [1.0,1.25]:
    print(f'  SD {sd}: alpha 0.05 two-sided -> {n_sup_lb(sd,2.0,1.5)}; alpha 0.0125 -> {n_sup_lb(sd,2.0,1.5,alpha_two_sided=0.0125)}')
print('HAI GMT NI (LB of new/comparator > 0.667; true 1.0; 90% power; one-sided 0.025) at WU397-like SDs:', {sd: n_ni_gmt(sd) for sd in [1.0,1.25,1.36]})
print('Power check: what true GMT ratio would WU397-sized arms (n=14) detect at 80% power, SD 1.03 (H3 contemporary residual)?',
      round(2**((stats.norm.ppf(0.975)+stats.norm.ppf(0.8))*1.03*np.sqrt(2/14)),2))
# Per-comparison power at the planned n=150 evaluable/arm (GMT ratio 1.5, alpha 0.0125 two-sided), and joint power for 4 comparisons
def power(n, sd, ratio, alpha=0.0125):
    return stats.norm.cdf(np.log2(ratio)/(sd*np.sqrt(2/n)) - stats.norm.ppf(1-alpha/2))
for sd in [1.0,1.25]:
    p=power(150,sd,1.5)
    print(f'n=150/arm, SD {sd}: per-comparison power {p:.3f}; joint power for 4 comparisons if independent (lower bound) {p**4:.3f}')
