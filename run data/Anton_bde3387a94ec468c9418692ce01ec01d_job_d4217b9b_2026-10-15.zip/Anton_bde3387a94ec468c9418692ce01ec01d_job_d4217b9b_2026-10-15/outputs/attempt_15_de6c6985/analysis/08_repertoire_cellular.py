"""Serum IgG repertoire (Ig-seq), CDR-H3 diversity, lymph-node GC and plasmablast data.
Sources: repertoire_clonotype_counts.csv, serum_igg_clonotypes.csv, cdrh3_diversity_index.csv, gc_frequencies.csv,
plasmablast_frequencies.csv, pb_gc_clonal_overlap.csv"""
import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width',250); pd.set_option('display.max_rows',500); pd.set_option('display.max_columns',60)
F='/tmp/world/filesystem/'
r = pd.read_csv(F+'repertoire_clonotype_counts.csv')
print('Repertoire metrics (no participant IDs in file; rows alternate by arm):')
for m,g in r.groupby('metric'):
    x=g[g.arm=='mRNA-1010'].value; y=g[g.arm=='Fluarix'].value
    print(f'  {m}: mRNA n={len(x)} mean {x.mean():.1f} median {x.median():.1f} [{x.min():.1f}-{x.max():.1f}] | Fluarix n={len(y)} mean {y.mean():.1f} median {y.median():.1f} [{y.min():.1f}-{y.max():.1f}] | MWU p={stats.mannwhitneyu(x,y).pvalue:.3f}')
s = pd.read_csv(F+'serum_igg_clonotypes.csv')
print('\nSerum IgG clonotypes by timepoint (no participant IDs -> pairing across timepoints not possible):')
print(s.groupby(['timepoint','arm']).n_clonotypes.agg(['count','mean','median','min','max']).round(1))
for tp in ['wk0','wk4','wk26']:
    x=s[(s.timepoint==tp)&(s.arm=='mRNA-1010')].n_clonotypes; y=s[(s.timepoint==tp)&(s.arm=='Fluarix')].n_clonotypes
    print(f'  {tp}: MWU p={stats.mannwhitneyu(x,y).pvalue:.3f}')
# check whether n_pre_existing equals wk0 clonotypes (consistency)
pre = r[r.metric=='n_pre_existing_clonotypes']
for arm in ['mRNA-1010','Fluarix']:
    print(arm, 'n_pre_existing list:', list(pre[pre.arm==arm].value.astype(int)), ' wk0 clonotypes list:', list(s[(s.timepoint=='wk0')&(s.arm==arm)].n_clonotypes))
c = pd.read_csv(F+'cdrh3_diversity_index.csv')
print('\nCDR-H3 diversity index:')
print(c.groupby(['timepoint','arm']).diversity_index.agg(['count','mean','median','min','max']).round(1))
for tp in ['wk0','wk4','wk26']:
    x=c[(c.timepoint==tp)&(c.arm=='mRNA-1010')].diversity_index; y=c[(c.timepoint==tp)&(c.arm=='Fluarix')].diversity_index
    print(f'  {tp}: MWU p={stats.mannwhitneyu(x,y).pvalue:.3f}')
# GC file: two stacked blocks with identical header
gc = pd.read_csv(F+'gc_frequencies.csv', dtype={'participant':str})
gc['block'] = (gc.index >= gc.index[(gc.timepoint=='wk0')&(gc.arm=='Fluarix')&(gc.participant=='001')][1]).astype(int)+1
print('\nGC file blocks:', gc.groupby('block').size().to_dict())
for b,g in gc.groupby('block'):
    print(f' Block {b}:')
    print(g.groupby(['timepoint','arm']).pct_ha_specific_igg_gc.agg(['count','median','mean','max']).round(2).unstack('arm'))
for b in [1,2]:
    g=gc[gc.block==b]
    for tp in ['wk2','wk8','wk17','wk26']:
        x=g[(g.timepoint==tp)&(g.arm=='mRNA-1010')].pct_ha_specific_igg_gc; y=g[(g.timepoint==tp)&(g.arm=='Fluarix')].pct_ha_specific_igg_gc
        print(f'  block{b} {tp}: mRNA median {x.median():.2f} (n={len(x)}) vs Flu {y.median():.2f} (n={len(y)}), MWU p={stats.mannwhitneyu(x,y).pvalue:.3f}')
pb = pd.read_csv(F+'plasmablast_frequencies.csv', dtype={'participant':str})
print('\nPlasmablast file participants:', pb.groupby('arm').participant.unique().apply(sorted).to_dict())
print(pb.groupby(['timepoint','arm']).pct_plasmablast.agg(['count','median','mean','max']).round(3).unstack('arm'))
for tp in ['wk2','wk8','wk17','wk26']:
    x=pb[(pb.timepoint==tp)&(pb.arm=='mRNA-1010')].pct_plasmablast; y=pb[(pb.timepoint==tp)&(pb.arm=='Fluarix')].pct_plasmablast
    print(f'  {tp}: mRNA median {x.median():.3f} (n={len(x)}) vs Flu {y.median():.3f} (n={len(y)}), MWU p={stats.mannwhitneyu(x,y).pvalue:.3f}')
ov = pd.read_csv(F+'pb_gc_clonal_overlap.csv')
print('\nPB-GC clonal overlap:'); print(ov.to_string())
