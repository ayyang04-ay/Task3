"""Concordance of bead-array binding fold-change with seqneut neutralisation fold-change for the same strains, same participants.
Sources: binding_breadth_h1.csv, binding_breadth_h3.csv, neutralization_seqbased.csv"""
import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width',250); pd.set_option('display.max_rows',500)
b = pd.concat([pd.read_csv('/tmp/world/filesystem/binding_breadth_h1.csv').assign(st='H1'), pd.read_csv('/tmp/world/filesystem/binding_breadth_h3.csv').assign(st='H3')])
w = pd.read_csv('/tmp/outputs/analysis/seqneut_wide.csv')
pairs = {'A/Brisbane/2/2018':'A/Brisbane/02/2018_H1N1','A/Hawaii/70/2019':'A/Hawaii/70/2019_H1N1','A/Michigan/45/2015':'A/Michigan/45/2015_H1N1',
         'A/Wisconsin/588/2019':'A/Wisconsin/588/2019_H1N1','A/Wisconsin/67/2022':'A/Wisconsin/67/2022_H1N1','A/California/04/2009':'A/California/07/2009_H1N1',
         'A/Darwin/6/2021':'A/Darwin/6/2021_H3N2','A/Thailand/8/2022':'A/Thailand/8/2022_H3N2','A/Texas/50/2012':'A/Texas/50/2012_H3N2',
         'A/Hong Kong/2671/2019':'A/HongKong/2671/2019_H3N2','A/Singapore/INFIMH-16-0019/2016':'A/Singapore/INFIMH-16-0019/2016_H3N2',
         'A/Cambodia/e0826360/2020':'A/Cambodia/e0826360/2020_H3N2'}
rows=[]; allm=[]
for bs, ns in pairs.items():
    bb = b[b.strain==bs][['participant','arm','log2_fold_change_mfi']]
    nn = w[w.virus==ns][['pid','arm','lfc29']].rename(columns={'pid':'participant'})
    m = bb.merge(nn, on=['participant','arm']).dropna()
    m['pair']=bs; allm.append(m)
    r,p = stats.spearmanr(m.log2_fold_change_mfi, m.lfc29)
    ra = {arm: g.log2_fold_change_mfi.mean()-g.lfc29.mean() for arm,g in m.groupby('arm')}
    rows.append(dict(strain=bs, n=len(m), spearman_r=r, p=p,
        bind_log2FC_mRNA=m[m.arm=='mRNA-1010'].log2_fold_change_mfi.mean(), bind_log2FC_Flu=m[m.arm=='Fluarix'].log2_fold_change_mfi.mean(),
        neut_log2FC_mRNA=m[m.arm=='mRNA-1010'].lfc29.mean(), neut_log2FC_Flu=m[m.arm=='Fluarix'].lfc29.mean()))
R=pd.DataFrame(rows)
R['bind_diff(mRNA-Flu)']=R.bind_log2FC_mRNA-R.bind_log2FC_Flu
R['neut_diff(mRNA-Flu)']=R.neut_log2FC_mRNA-R.neut_log2FC_Flu
print(R.round(2).to_string())
R.to_csv('/tmp/outputs/analysis/binding_vs_neut_concordance.csv', index=False)
# Binding-to-neutralisation ratio per participant (log2FC binding minus log2FC neut) by arm and subtype
M=pd.concat(allm); M['st']=np.where(M.pair.isin(['A/Darwin/6/2021','A/Thailand/8/2022','A/Texas/50/2012','A/Hong Kong/2671/2019','A/Singapore/INFIMH-16-0019/2016','A/Cambodia/e0826360/2020']),'H3','H1')
M['gap']=M.log2_fold_change_mfi-M.lfc29
pp=M.groupby(['st','arm','participant']).gap.mean().reset_index()
for st,g in pp.groupby('st'):
    x=g[g.arm=='mRNA-1010'].gap; y=g[g.arm=='Fluarix'].gap
    print(st, f'binding-minus-neutralisation log2FC gap: mRNA {x.mean():.2f} vs Fluarix {y.mean():.2f}; MWU p={stats.mannwhitneyu(x,y).pvalue:.4f}')
# Bead-array per-strain summary (ledger B1-B21)
rows=[]
for s,g in b.groupby('strain'):
    x=g[g.arm=='mRNA-1010'].log2_fold_change_mfi; y=g[g.arm=='Fluarix'].log2_fold_change_mfi
    rows.append(dict(strain=s, subtype=g.st.iloc[0], mean_log2FC_mRNA=x.mean(), mean_log2FC_Flu=y.mean(), MWU_p=stats.mannwhitneyu(x,y).pvalue, n_mRNA=len(x), n_Flu=len(y)))
B=pd.DataFrame(rows); B.to_csv('/tmp/outputs/analysis/bead_array_summary.csv', index=False); print(B.round(3).to_string())
