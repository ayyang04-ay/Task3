"""Seqneut by subtype x category, and per-virus table (participant = unit).
Source: /tmp/world/filesystem/neutralization_seqbased.csv (via 04_seqneut.py outputs)"""
import pandas as pd, numpy as np
from scipy import stats
import statsmodels.formula.api as smf
pd.set_option('display.width',250); pd.set_option('display.max_rows',500); pd.set_option('display.max_columns',60)
w = pd.read_csv('/tmp/outputs/analysis/seqneut_wide.csv')
ps = w.groupby(['arm','pid','subtype','category']).agg(l0=('d0','mean'), l29=('d29','mean'), llate=('late','mean'), fc29=('lfc29','mean'), fclate=('lfclate','mean'), f4=('rise4','mean'), nv=('virus','nunique')).reset_index()
rows=[]
for (st,c),g in ps.groupby(['subtype','category']):
    a=g[g.arm=='mRNA-1010']; b=g[g.arm=='Fluarix']
    d=g.copy(); d['mrna']=(d.arm=='mRNA-1010').astype(int)
    m=smf.ols('l29 ~ mrna + l0', d).fit(); ci=m.conf_int().loc['mrna']
    d2=d.dropna(subset=['llate']); m2=smf.ols('llate ~ mrna + l0', d2).fit(); ci2=m2.conf_int().loc['mrna']
    rows.append(dict(subtype=st, category=c, n_virus=int(g.nv.max()),
        GMT_d29_mRNA=2**a.l29.mean(), GMT_d29_Flu=2**b.l29.mean(), GMFR29_mRNA=2**a.fc29.mean(), GMFR29_Flu=2**b.fc29.mean(),
        adj_ratio_d29=2**m.params.mrna, lo=2**ci[0], hi=2**ci[1], p=m.pvalues.mrna,
        adj_ratio_late=2**m2.params.mrna, lo_late=2**ci2[0], hi_late=2**ci2[1], p_late=m2.pvalues.mrna,
        frac4x_mRNA=a.f4.mean(), frac4x_Flu=b.f4.mean()))
R=pd.DataFrame(rows); print(R.round(3).to_string())
R.to_csv('/tmp/outputs/analysis/seqneut_subtype_category_tests.csv', index=False)
# per-virus
rows=[]
for (v,st,c),g in w.groupby(['virus','subtype','category']):
    a=g[g.arm=='mRNA-1010']; b=g[g.arm=='Fluarix']
    d=g.dropna(subset=['d0','d29']).copy(); d['mrna']=(d.arm=='mRNA-1010').astype(int)
    try:
        m=smf.ols('d29 ~ mrna + d0', d).fit(); ar=2**m.params.mrna; p=m.pvalues.mrna
    except Exception: ar=np.nan; p=np.nan
    rows.append(dict(virus=v, subtype=st, category=c, n_mRNA=a.d29.notna().sum(), n_Flu=b.d29.notna().sum(),
        GMT0_mRNA=2**a.d0.mean(), GMT0_Flu=2**b.d0.mean(), GMT29_mRNA=2**a.d29.mean(), GMT29_Flu=2**b.d29.mean(),
        GMFR_mRNA=2**a.lfc29.mean(), GMFR_Flu=2**b.lfc29.mean(), adj_ratio=ar, p=p,
        SC4_mRNA=f'{int(a.rise4.sum())}/{int(a.rise4.notna().sum())}', SC4_Flu=f'{int(b.rise4.sum())}/{int(b.rise4.notna().sum())}'))
V=pd.DataFrame(rows).sort_values(['category','subtype','virus'])
V.to_csv('/tmp/outputs/analysis/seqneut_per_virus.csv', index=False)
print(V[V.category!='contemporary 2022-24 wild-type'].round(2).to_string())
C=V[V.category=='contemporary 2022-24 wild-type']
print('\nContemporary viruses: n=',len(C), ' adj ratio median', C.adj_ratio.median().round(2), ' range', C.adj_ratio.min().round(2), C.adj_ratio.max().round(2))
print('n with nominal p<0.05:', (C.p<0.05).sum(), ' favouring mRNA:', ((C.p<0.05)&(C.adj_ratio>1)).sum())
print(C[C.subtype=='H1N1'].round(2).to_string())
