"""Assemble the evidence ledger (every number cited in answer.md) directly from analysis outputs, to avoid transcription error."""
import pandas as pd, numpy as np
A='/tmp/outputs/analysis/'; F='/tmp/world/filesystem/'
L=[]
def add(i, what, value, source, how):
    L.append(dict(id=i, quantity=what, value=value, source_files=source, derivation=how))
# HAI
h=pd.read_csv(A+'hai_summary.csv')
for _,r in h.iterrows():
    add(f"HAI-{r.antigen}-{r.arm}", f"HAI {r.antigen} {r.arm}: GMT d0/wk4/late; GMFR wk4; SCR wk4; seroprotected(>=40) wk0",
        f"{r.GMT_wk0:.1f} / {r.GMT_wk4:.1f} / {r.GMT_late:.1f}; {r.GMFR_wk4:.2f}; {r.SCR_wk4}; {r.SP_wk0}", 'hai_titers.csv', '01_hai.py (late = wk17 or wk26 visit; SCR = >=4-fold rise [>=3.9 on rounded GM titres] or <10 to >=40)')
# HAI ANCOVA (recompute quickly)
import statsmodels.formula.api as smf
hw=pd.read_csv(A+'hai_wide.csv')
for ag,g in hw.groupby('antigen'):
    d=g.dropna(subset=['wk0','wk4']).copy(); d['l0']=np.log2(d.wk0); d['l4']=np.log2(d.wk4); d['mrna']=(d.arm=='mRNA-1010').astype(int)
    m=smf.ols('l4 ~ mrna + l0', d).fit(); ci=m.conf_int().loc['mrna']
    add(f"HAI-ANCOVA-{ag}", f"HAI {ag} wk4 GMT ratio mRNA-1010/Fluarix, baseline-adjusted", f"{2**m.params.mrna:.2f} (95% CI {2**ci[0]:.2f}-{2**ci[1]:.2f}), p={m.pvalues.mrna:.2f}, n={len(d)}", 'hai_titers.csv', '01_hai.py ANCOVA log2(wk4) ~ arm + log2(wk0)')
# MN
mn=pd.read_csv(A+'mn_summary.csv')
for _,r in mn.iterrows():
    add(f"MN-{r.panel}-{r.arm}", f"MN {r.panel} panel {r.arm}: GMT wk0/wk4/late; GMFR wk4; n at ULOQ 1280 wk0/wk4",
        f"{r.GMT_wk0:.1f} / {r.GMT_wk4:.1f} / {r.GMT_late:.1f}; {r.GMFR_wk4:.2f}; {r.n_at_ceiling_wk0}/{r.n_at_ceiling_wk4} of {r.n}", 'microneutralization.csv', '02_mn.py')
mw=pd.read_csv(A+'mn_wide.csv')
for p,g in mw.groupby('panel'):
    d=g.copy(); d['l0']=np.log2(d.wk0); d['l4']=np.log2(d.wk4); d['mrna']=(d.arm=='mRNA-1010').astype(int)
    m=smf.ols('l4 ~ mrna + l0', d).fit(); ci=m.conf_int().loc['mrna']
    add(f"MN-ANCOVA-{p}", f"MN {p} wk4 GMT ratio mRNA-1010/Fluarix, baseline-adjusted", f"{2**m.params.mrna:.2f} ({2**ci[0]:.2f}-{2**ci[1]:.2f}), p={m.pvalues.mrna:.2f}", 'microneutralization.csv', '02_mn.py')
from scipy import stats
g=mw[mw.panel=='heterologous']
add('MN-baseline-imbalance', 'MN heterologous baseline GMT mRNA-1010 vs Fluarix (MWU p)', f"{np.exp(np.log(g[g.arm=='mRNA-1010'].wk0).mean()):.0f} vs {np.exp(np.log(g[g.arm=='Fluarix'].wk0).mean()):.0f} (p={stats.mannwhitneyu(np.log(g[g.arm=='mRNA-1010'].wk0),np.log(g[g.arm=='Fluarix'].wk0)).pvalue:.3f})", 'microneutralization.csv', '02_mn.py')
# ELISA
e=pd.read_csv(A+'elisa_summary.csv')
for _,r in e.iterrows():
    add(f"ELISA-{r.antigen}-{r.arm}", f"ELISA IgG {r.antigen} {r.arm}: GMT(EC50) wk0/wk4/late; GMFR wk4; n", f"{r.GMT_wk0:.0f} / {r.GMT_wk4:.0f} / {r.GMT_late:.0f}; {r.GMFR_wk4:.2f}; n={r.n}", 'elisa_igg_titers.csv', '03_elisa_igm.py')
ew=pd.read_csv(F+'elisa_igg_titers.csv'); ew=ew[ew.measure=='ec50']; ew['tp']=ew.timepoint.replace({'wk17':'late','wk26':'late'})
ew=ew.pivot_table(index=['antigen','arm','participant'],columns='tp',values='value').reset_index()
for ag,g in ew.groupby('antigen'):
    d=g.copy(); d['l0']=np.log2(d.wk0); d['l4']=np.log2(d.wk4); d['ll']=np.log2(d.late); d['mrna']=(d.arm=='mRNA-1010').astype(int)
    m=smf.ols('l4 ~ mrna + l0', d).fit(); ci=m.conf_int().loc['mrna']
    m2=smf.ols('ll ~ mrna + l0', d.dropna(subset=['ll'])).fit(); ci2=m2.conf_int().loc['mrna']
    add(f"ELISA-ANCOVA-{ag}", f"ELISA IgG {ag} GMT ratio mRNA-1010/Fluarix, baseline-adjusted: wk4; late", f"{2**m.params.mrna:.2f} ({2**ci[0]:.2f}-{2**ci[1]:.2f}); {2**m2.params.mrna:.2f} ({2**ci2[0]:.2f}-{2**ci2[1]:.2f})", 'elisa_igg_titers.csv', '03_elisa_igm.py')
ig=pd.read_csv(A+'igm_summary.csv')
for _,r in ig.iterrows():
    add(f"IgM-{r.antigen}-{r.arm}", f"IgM fold-change (timepoint not stated in file) {r.antigen} {r.arm}: GMFR (n); between-arm MWU p", f"{r.GMFR:.2f} (n={r.n}); p={r.MWU_p_between_arms:.3f}", 'igm_fold_change.csv', '03_elisa_igm.py')
# Bead array
for f,st in [('binding_breadth_h1.csv','H1'),('binding_breadth_h3.csv','H3')]:
    b=pd.read_csv(F+f)
    for s,g in b.groupby('strain'):
        a=g[g.arm=='mRNA-1010'].log2_fold_change_mfi; c=g[g.arm=='Fluarix'].log2_fold_change_mfi
        add(f"BEAD-{s}", f"Bead-array binding log2 fold-change {s} ({st}): mRNA-1010 mean vs Fluarix mean (MWU p)", f"{a.mean():.2f} vs {c.mean():.2f} (p={stats.mannwhitneyu(a,c).pvalue:.3f})", f, '06_binding_vs_neut.py -> bead_array_summary.csv')
# Seqneut categories
T=pd.read_csv(A+'seqneut_subtype_category_tests.csv')
for _,r in T.iterrows():
    add(f"SEQ-{r.subtype}-{r.category}", f"Seq-neut {r.subtype} {r.category} ({r.n_virus} viruses): d29 GMT mRNA vs Fluarix; GMFR; adj ratio d29 (95%CI); adj ratio late (95%CI)",
        f"{r.GMT_d29_mRNA:.0f} vs {r.GMT_d29_Flu:.0f}; {r.GMFR29_mRNA:.2f} vs {r.GMFR29_Flu:.2f}; {r.adj_ratio_d29:.2f} ({r.lo:.2f}-{r.hi:.2f}) p={r.p:.3f}; {r.adj_ratio_late:.2f} ({r.lo_late:.2f}-{r.hi_late:.2f}) p={r.p_late:.2f}",
        'neutralization_seqbased.csv', '04/05_seqneut*.py; participant-level means over viruses in category; ANCOVA on baseline')
V=pd.read_csv(A+'seqneut_per_virus.csv')
for v in ['A/Thailand/8/2022_H3N2','A/Massachusetts/18/2022_H3N2','A/Darwin/6/2021_H3N2','A/Darwin/9/2021_H3N2','A/Wisconsin/67/2022_H1N1','A/Wisconsin/588/2019_H1N1','A/Victoria/4897/2022_IVR-238_H1N1']:
    r=V[V.virus==v].iloc[0]
    add(f"SEQV-{v}", f"Seq-neut {v}: d29 GMT mRNA vs Fluarix; adj ratio; >=4-fold risers", f"{r.GMT29_mRNA:.0f} vs {r.GMT29_Flu:.0f}; {r.adj_ratio:.2f} (p={r.p:.2f}); {r.SC4_mRNA} vs {r.SC4_Flu}", 'neutralization_seqbased.csv', '05_seqneut_bysubtype.py')
C=V[(V.category=='contemporary 2022-24 wild-type')&(V.subtype=='H3N2')]
add('SEQ-H3-contemp-pervirus', 'Contemporary H3N2 viruses: per-virus adj ratio median (range); n with nominal p<0.05', f"{C.adj_ratio.median():.2f} ({C.adj_ratio.min():.2f}-{C.adj_ratio.max():.2f}); {(C.p<0.05).sum()} of {len(C)}", 'neutralization_seqbased.csv','05_seqneut_bysubtype.py')
C1=V[(V.category=='contemporary 2022-24 wild-type')&(V.subtype=='H1N1')]
add('SEQ-H1-contemp-pervirus', 'Contemporary H1N1 viruses: per-virus adj ratio range; n nominal p<0.05', f"{C1.adj_ratio.min():.2f}-{C1.adj_ratio.max():.2f}; {(C1.p<0.05).sum()} of {len(C1)}", 'neutralization_seqbased.csv','05_seqneut_bysubtype.py')
# binding vs neut
R=pd.read_csv(A+'binding_vs_neut_concordance.csv')
for _,r in R.iterrows():
    add(f"BvN-{r.strain}", f"{r.strain}: binding log2FC diff (mRNA-Flu) vs neutralisation log2FC diff (mRNA-Flu); Spearman r binding~neut", f"{r['bind_diff(mRNA-Flu)']:.2f} vs {r['neut_diff(mRNA-Flu)']:.2f}; r={r.spearman_r:.2f}", 'binding_breadth_h1/h3.csv + neutralization_seqbased.csv', '06_binding_vs_neut.py')
add('BvN-gap', 'Binding-minus-neutralisation log2FC gap (mean of paired strains) H3: mRNA-1010 vs Fluarix; H1', 'H3: 2.21 vs 0.03 (MWU p=0.0001); H1: -0.41 vs -0.50 (p=0.87)', 'binding_breadth_h1/h3.csv + neutralization_seqbased.csv', '06_binding_vs_neut.py')
bs=pd.read_csv(A+'backward_shift.csv')
for _,r in bs.iterrows():
    add(f"SHIFT-{r.comparison[:2]}-{r.arm}", f"{r.comparison} | {r.arm}: log2(new/old) d0 -> d29; shift (paired p); between-arm p", f"{r.log2_new_over_old_d0:.2f} -> {r.log2_new_over_old_d29:.2f}; {r.shift_d29_minus_d0:.2f} (p={r.paired_wilcoxon_p:.3f}); {r.between_arm_MWU_p:.3f}", 'neutralization_seqbased.csv', '13_backward_shift_and_panel_identity.py')
add('WANE-H1', 'Seq-neut H1N1 decline d29 -> d121/181 (fold): mRNA-1010 vs Fluarix (MWU p)', '2.16 vs 1.28 (p=0.0005)', 'neutralization_seqbased.csv', '10_egg_pairs_and_decay.py')
add('WANE-H3', 'Seq-neut H3N2 decline d29 -> d121/181 (fold): mRNA-1010 vs Fluarix (MWU p)', '1.57 vs 1.45 (p=0.42)', 'neutralization_seqbased.csv', '10_egg_pairs_and_decay.py')
add('EGG', 'Egg/reassortant vs matched wild-type d29 titre ratio, range across 6 pairs and both arms', '1.38-7.46x higher for egg/reassortant', 'neutralization_seqbased.csv', '10_egg_pairs_and_decay.py')
add('MIXED', 'Contemporary H3N2 d29: participant-level mixed model ratio vs naive virus-level OLS', '1.06 (0.62-1.82), p=0.82 vs 1.13 (1.05-1.21), p=0.0018', 'neutralization_seqbased.csv', '12_seqneut_sensitivity.py')
P=pd.read_csv(A+'panel_identity_inference.csv')
for _,r in P.iterrows():
    add(f"IDENT-{r.readout}-{r.seqneut_reference}", f"Spearman correlation of {r.readout} titres with seq-neut {r.seqneut_reference}", f"levels {r.spearman_levels:.2f}; fold-rise {r.spearman_foldrise:.2f}", 'microneutralization.csv / hai_titers.csv + neutralization_seqbased.csv', '13_backward_shift_and_panel_identity.py')
# mAbs
mb=pd.read_csv(A+'mab_breadth_by_donor.csv', dtype={'donor':str}); mb=mb[mb.thr==10]
for _,r in mb.iterrows():
    add(f"MAB-{r.panel}-{r.donor}", f"mAbs {r.panel} donor {r.donor} ({r.arm}): n mAbs; % binding forward strain(s); % cross-subtype (>10x over control)", f"{r.n_mabs}; {r.pct_bind_forward:.1f}%; {r.pct_cross_subtype:.1f}%", 'mab_binding_panels.csv', '07_mabs.py')
# cellular / repertoire (from logs)
add('GC-wk2', 'HA-specific IgG GC B cells (%), week 2, median mRNA-1010 vs Fluarix (n; MWU p)', '24.2 (n=6) vs 2.3 (n=11); p=0.037', 'gc_frequencies.csv (first block)', '08_repertoire_cellular.py')
add('GC-late', 'HA-specific GC B cells (%) median wk17 / wk26, mRNA-1010 vs Fluarix', 'wk17 16.0 vs 2.3 (p=0.083); wk26 18.9 vs 1.6 (p=0.34)', 'gc_frequencies.csv (first block)', '08_repertoire_cellular.py')
add('OVERLAP', '% of GC B-cell clones overlapping week-1 plasmablast clones (mRNA-1010 donors 06/17/28/29; Fluarix 05/09/22)', '92 / 90.9 / 83.3 / 73.0; Fluarix 100 / 20 / 0 (GC clones 7 / 5 / 1)', 'pb_gc_clonal_overlap.csv', 'read directly')
add('REP-pre', 'Serum IgG abundance from pre-existing clonotypes, mean %, mRNA-1010 vs Fluarix (n=8 each)', '83.9 vs 86.2 (p=0.72)', 'repertoire_clonotype_counts.csv', '08_repertoire_cellular.py')
add('REP-new', 'Vaccine-elicited serum clonotypes, mean, mRNA-1010 vs Fluarix', '32.0 vs 20.1 (p=0.066)', 'repertoire_clonotype_counts.csv', '08_repertoire_cellular.py')
add('CDRH3', 'CDR-H3 diversity index wk4 mean, mRNA-1010 vs Fluarix (n=8 each)', '71.2 vs 24.9 (p=0.010)', 'cdrh3_diversity_index.csv', '08_repertoire_cellular.py')
# sample size
add('SS-SD', 'Residual SD (log2) of participant-level breadth score at d29 (ANCOVA), contemporary H1N1 / H3N2; raw SD', '0.94 / 1.03; raw 1.65 / 1.21', 'neutralization_seqbased.csv', '11_sample_size.py')
add('SS-n', 'Evaluable n/arm for GMT ratio 1.5, 90% power, two-sided alpha 0.0125, SD 1.0 / 1.25 / 1.5', '84 / 131 / 188', 'computed', '11_sample_size.py')
add('SS-diff', 'Evaluable n/arm for LB of GMT ratio > 1.5 (true 2.0, 90% power), SD 1.0 / 1.25: alpha 0.05 two-sided; alpha 0.0125', '122 / 191; 166 / 260', 'computed', '11_sample_size.py')
add('SS-HAI', 'Evaluable n/arm for HAI GMT-ratio non-inferiority (LB > 0.667, true 1.0, 90% power), SD 1.0 / 1.25 / 1.36', '63 / 99 / 117', 'computed (SDs from hai_titers.csv)', '11_sample_size.py')
add('SS-WU397power', 'True GMT ratio detectable with 80% power by WU397-sized arms (n=14), SD 1.03', '~2.13', 'computed', '11_sample_size.py')
add('SS-HAIsd', 'Raw SD of log2 HAI titre at wk4 (H1 / H3 / B-Vic / B-Yam)', '1.02 / 1.36 / 1.03 / 0.86', 'hai_titers.csv', '11_sample_size.py')
add('SS-CHIM', 'CHIM n/arm: infection 50% vs 25% (80%/90% power); 50% vs 20%; 40% vs 20%', '58/77; 39/52; 82/109', 'assumed attack rates', '11_sample_size.py')
add('SS-VE', 'Cases for rVE 25% (90% power, 1-sided 0.025); participants at 2% attack; if 40% of cases mismatched', '~508 cases; ~29,000; ~72,600', 'assumed attack rates', '11_sample_size.py')
add('SS-VE2', 'Cases for rVE 20% / 30% (same assumptions)', '~845 / ~331', 'assumed', '11_sample_size.py')
add('SS-power150', 'Planned n=150 evaluable/arm, GMT ratio 1.5, alpha 0.0125: per-comparison power (SD 1.0 / 1.25); joint power of 4 comparisons if independent', '>0.99 / 0.94; 0.98 / 0.78 (joint power is higher because the comparisons share participants)', 'computed', '11_sample_size.py')
H=pd.read_csv(A+'h1_2023_vs_vaccine_equivalents.csv')
add('H1-2023-equiv', 'Mean log2 ratio of 2023 H1N1 isolate titres to A/Wisconsin/67/2022 (cell equivalent of mRNA-1010 H1) at d0 / d29: mRNA-1010; Fluarix', f"{H.iloc[0].log2_2023H1_over_Wisc67_d0:.2f} / {H.iloc[0].log2_2023H1_over_Wisc67_d29:.2f}; {H.iloc[1].log2_2023H1_over_Wisc67_d0:.2f} / {H.iloc[1].log2_2023H1_over_Wisc67_d29:.2f} (i.e., within 1.3-fold: antigenically equivalent to the mRNA-1010 H1)", 'neutralization_seqbased.csv', '13_backward_shift_and_panel_identity.py (d)')
# ---- cohort / data-integrity facts (read directly from files) ----
add('COH-summary', 'Assay cohorts stated in trial summary (mRNA-1010 / Fluarix): ELISA+IgM; HAI; bead+MN; seq-neut; FNA', '38/37; 14/15; 14/15; 13/14; 6/11', 'trial_summary.md', 'read directly')
add('COH-IgM', 'Participants actually present in IgM file (mRNA-1010 / Fluarix)', '14 / 15 (not 38/37)', 'igm_fold_change.csv', '03_elisa_igm.py')
add('COH-PB', 'Plasmablast file: participants (mRNA-1010/Fluarix); participants outside FNA cohort; timepoints', '13/15; 11 (7 mRNA-1010, 4 Fluarix); wk0, wk2, wk8, wk17, wk26 (blood schedule is d0, d7, d29, d121, d181)', 'plasmablast_frequencies.csv + trial_summary.md', '08_repertoire_cellular.py')
add('COH-GC', 'GC file structure', '156 rows = two 78-row blocks, identical header pct_ha_specific_igg_gc; includes wk0 (not an FNA visit) and lacks wk1/wk4 (FNA visits)', 'gc_frequencies.csv + trial_summary.md', '08_repertoire_cellular.py')
add('COH-REP', 'Repertoire / CDR-H3 / serum clonotype files', '8 per arm, no participant identifiers', 'repertoire_clonotype_counts.csv, cdrh3_diversity_index.csv, serum_igg_clonotypes.csv', 'read directly')
add('COH-SEQ-missing', 'HAI/MN participants absent from seq-neut: MN titres wk0 -> wk4 (homologous; heterologous)', '397-014 (mRNA-1010): 15->10; 10->10. 397-019 (Fluarix): 80->1280; 80->1280', 'microneutralization.csv + neutralization_seqbased.csv', '13_backward_shift_and_panel_identity.py')
add('SEQ-panel', 'Seq-neut panel composition (categories assigned a priori in 04_seqneut.py)', '96 = 68 + 6 contemporary; 8 + 4 historical wild-type; 5 historical egg/reassortant H3N2; 3 mRNA-1010-matched (A/Wisconsin/67/2022, A/Victoria/4897/2022 IVR-238 [egg reassortant], A/Darwin/6/2021); 2 Fluarix-matched (A/Wisconsin/588/2019, A/Darwin/9/2021); 0 influenza B', 'neutralization_seqbased.csv', '04_seqneut.py (seqneut_virus_categories.csv)')
add('SEQ-censor', 'Seq-neut titres outside quantifiable range (of 7,719): below LOD (reported as upper bound, mostly 40); above ULOQ (lower bound, mostly 17,300)', '171; 70', 'neutralization_seqbased.csv', '04_seqneut.py (titer_bound counts)')
add('SEQ-malformed', 'Malformed virus name in seq-neut panel', "A/SOUTHAFRICA/R07876/202023_H3N2 (treated as a 2023 isolate)", 'neutralization_seqbased.csv', '04_seqneut.py')
add('BEAD-panel', 'Bead-array panels: strains (H1 / H3); strains isolated after 2021', '9 / 12; H1: A/Wisconsin/67/2022 only; H3: A/Thailand/8/2022 only', 'binding_breadth_h1.csv, binding_breadth_h3.csv', 'strain lists read directly (bead_array_summary.csv)')
add('MAB-n', 'mAbs per arm (donors)', 'mRNA-1010 589 (4 donors: 06, 17, 28, 29); Fluarix 106 (3 donors: 05, 09, 22); group II (H3) mAbs from Fluarix donors 09 and 22: 2 and 7', 'mab_binding_panels.csv', '07_mabs.py')
add('MAB-ctrl', 'SARS-CoV-2 RBD control value for every mAb', 'exactly 1.0 (it is the normaliser, not an independent negative control)', 'mab_binding_panels.csv', '07_mabs.py (control check)')
add('MAB-H1-old', 'Median ratio of binding to A/Victoria/4897/2022 (mRNA-1010 H1) over A/Wisconsin/588/2019 among group I mAbs, mRNA-1010 donors', '0.24-0.54 (i.e., mAbs bind the older 5a.2 HA better than the vaccine HA); 1 of 264 mRNA-1010 group I mAbs binds Vic/4897 but not Wisc/588', 'mab_binding_panels.csv', '07_mabs.py -> mab_h1_vic_vs_wisc.csv')
add('MAB-exactp', 'Smallest attainable exact two-sided Mann-Whitney p with 4 vs 3 donors', '2/C(7,3) = 2/35 = 0.057', 'computed', 'combinatorial')
add('MN-ceiling', 'MN titres at the 1280 ceiling at wk4, homologous panel: Fluarix / mRNA-1010; at baseline', '9/15 / 4/14; 2/15 / 1/14', 'microneutralization.csv', '02_mn.py')
# ---- external facts (not in the data package) ----
ext='EXTERNAL (not in data package) - verify against source'
add('EXT-1', 'WHO 2022-23 NH composition, egg-based (Fluarix): H1 / H3 / B-Vic / B-Yam', 'A/Victoria/2570/2019 / A/Darwin/9/2021 / B/Austria/1359417/2021 / B/Phuket/3073/2013 (cell/recombinant equivalents: A/Wisconsin/588/2019, A/Darwin/6/2021)', ext, 'WHO recommendation Feb 2022; confirm against the Fluarix lot labelling')
add('EXT-2', 'WHO 2021-22 NH egg-based composition (H1; H3)', 'A/Victoria/2570/2019 (identical to 2022-23); A/Cambodia/e0826360/2020', ext, 'WHO recommendation Feb 2021')
add('EXT-3', 'First WHO recommendation of A/Victoria/4897/2022 (egg) / A/Wisconsin/67/2022 (cell) H1', '2023-24 NH (Feb 2023)', ext, 'WHO recommendation Feb 2023')
add('EXT-4', 'B/Yamagata lineage', 'no confirmed circulation since March 2020; WHO advised removal; trivalent vaccines from 2024-25 NH', ext, 'WHO 2023-24 statements; FDA VRBPAC Mar 2024')
add('EXT-5', 'FDA immunogenicity non-inferiority criteria (seasonal IIV accelerated approval)', 'UB 95% CI GMT ratio (comparator/new) <=1.5; UB SCR difference (comparator-new) <=10 percentage points', ext, 'FDA guidance 2007')
add('EXT-6', 'Superiority criteria used for high-dose IIV HAI claim', 'LB 95% CI GMT ratio >1.5 and LB SCR difference >10 percentage points', ext, 'Falsey et al., J Infect Dis 2009')
add('EXT-7', 'US preferential recommendation for >=65 y', 'HD-IIV, RIV or adjuvanted IIV (ACIP, 2022)', ext, 'ACIP 2022')
add('EXT-8', 'NA-inhibiting antibody', 'independent correlate of protection from HAI (human cohort and challenge studies)', ext, 'e.g., Monto 2015 JID; Memoli 2016 mBio')
add('EXT-9', 'HAI >=1:40', 'conventional seroprotection threshold (~50% protection vs homologous strain)', ext, 'Hobson 1972')
add('EXT-10', 'mRNA-1010 antigen format', 'understood to encode membrane-anchored HA only (no NA); the trial summary does not state this - confirm', ext, 'sponsor documentation')
add('EXT-11', 'WHO 2024-25 NH H3N2 components', 'A/Thailand/8/2022 (egg-based) and A/Massachusetts/18/2022 (cell/recombinant)', ext, 'WHO recommendation Feb 2024')
add('EXT-12', 'HA clade assignments used in the text', 'A/Victoria/4897/2022 and A/Wisconsin/67/2022: 6B.1A.5a.2a.1; A/Victoria/2570/2019 and A/Wisconsin/588/2019: 6B.1A.5a.2', ext, 'WHO/CDC strain characterisation reports')
add('EXT-13', 'Origin of early (week-1) plasmablasts after seasonal influenza vaccination in adults', 'predominantly pre-existing memory B cells; GC clones shared with them indicate memory recruitment into germinal centres', ext, 'e.g., Turner et al., Nature 2020 (human lymph-node FNA after influenza vaccination)')
sq=pd.read_csv(F+'neutralization_seqbased.csv'); sq['arm']=sq.serum.str.split('_').str[0]; sq['pid']=sq.serum.str.split('_').str[1]; sq['day']=sq.serum.str.split('_').str[2]
late=sq[sq.day.isin(['d121','d181'])].groupby(['day','arm']).pid.nunique()
add('SEQ-late-days', 'Seq-neut late visit: participants sampled at d121 vs d181 (Fluarix + mRNA-1010)', f"d121: {late.get(('d121','Fluarix'),0)} + {late.get(('d121','mRNA-1010'),0)}; d181: {late.get(('d181','Fluarix'),0)} + {late.get(('d181','mRNA-1010'),0)}", 'neutralization_seqbased.csv', '15_build_ledger.py (serum name parsing)')
wq=pd.read_csv(A+'seqneut_wide.csv'); wq['lr']=wq.late-wq.d29
ic=wq.groupby(['arm','pid','subtype']).agg(n=('virus','count'), n4=('lr', lambda x: int((x>=2).sum()))).reset_index()
mx=ic.sort_values('n4',ascending=False).iloc[0]
add('SEQ-intercurrent', 'Screen for intercurrent infection: max number of viruses with >=4-fold rise from d29 to late visit in any participant', f"{int(mx.n4)} of {int(mx.n)} {mx.subtype} viruses ({mx.arm} {mx.pid}); all other participants 0", 'neutralization_seqbased.csv', '09_intercurrent.py')
Ldf=pd.DataFrame(L); Ldf.to_csv('/tmp/outputs/numbers_provenance.csv', index=False)
print(len(Ldf),'ledger rows written')
print(Ldf.to_string(max_colwidth=120))
