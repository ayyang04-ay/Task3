#!/usr/bin/env bash
# Re-runs every analysis used in /tmp/outputs/answer.md. Inputs: /tmp/world/filesystem (read-only). Env: micromamba 'core'.
set -euo pipefail
cd /tmp/outputs/analysis
for s in 01_hai.py 02_mn.py 03_elisa_igm.py 04_seqneut.py 05_seqneut_bysubtype.py 06_binding_vs_neut.py 07_mabs.py \
         08_repertoire_cellular.py 09_intercurrent.py 10_egg_pairs_and_decay.py 11_sample_size.py 12_seqneut_sensitivity.py \
         13_backward_shift_and_panel_identity.py 14_figures.py 15_build_ledger.py 16_ledger_markdown.py; do
  echo "== $s"; micromamba run -n core python "$s" > "log_${s%.py}.txt" 2>&1
done

# Assemble answer.md = narrative body + auto-generated evidence ledger
cat /tmp/outputs/analysis/answer_body.md /tmp/outputs/analysis/ledger_table.md > /tmp/outputs/answer.md
echo "answer.md assembled"
