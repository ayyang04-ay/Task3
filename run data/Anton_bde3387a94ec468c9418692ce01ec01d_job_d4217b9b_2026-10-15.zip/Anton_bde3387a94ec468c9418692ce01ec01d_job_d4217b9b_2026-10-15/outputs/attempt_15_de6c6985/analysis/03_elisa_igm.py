"""ELISA IgG (EC50) and IgM fold-change analysis.
Sources: /tmp/world/filesystem/elisa_igg_titers.csv, igm_fold_change.csv"""
import pandas as pd, numpy as np
from scipy import stats
import statsmodels.formula.api as smf
pd.set_option('display.width',250); pd.set_option('display.max_rows',500); pd.set_option('display.max_columns',50)
df = pd.read_csv('/tmp/world/filesystem/elisa_igg_titers.csv')
e = df[df.measure=='ec50'].copy()
e['tp'] = e.timepoint.replace({'wk17':'late','wk26':'late'})
dup = e.groupby(['antigen','arm','participant','tp']).size()
print('duplicate late entries (both wk17 & wk26):', (dup>1).sum())
print(dup[dup>1])
w = e.pivot_table(index=['antigen','arm','participant'], columns='tp', values='value', aggfunc='first').reset_index(); w.columns.name=None
gm = lambda x: np.exp(np.mean(np.log(x.dropna())))
rows=[]
for (ag,arm),g in w.groupby(['antigen','arm']):
    rows.append(dict(antigen=ag, arm=arm, n=len(g), GMT_wk0=gm(g.wk0), GMT_wk4=gm(g.wk4), GMT_late=gm(g.late), n_late=g.late.notna().sum(),
                     GMFR_wk4=gm(g.wk4/g.wk0), GMFR_late=gm((g.late/g.wk0).dropna()), n_4fold_wk4=int(((g.wk4/g.wk0)>=4).sum())))
res=pd.DataFrame(rows); print(res.round(2).to_string())
res.to_csv('/tmp/outputs/analysis/elisa_summary.csv', index=False)
print('\nBetween-arm, log2 diff (mRNA-Flu); MWU p; ANCOVA adj ratio wk4')
for ag,g in w.groupby('antigen'):
    a=g[g.arm=='mRNA-1010']; b=g[g.arm=='Fluarix']
    out=[ag]
    for col in ['wk0','wk4','late']:
        x=np.log2(a[col].dropna()); y=np.log2(b[col].dropna())
        out.append(f'{col}: ratio {2**(x.mean()-y.mean()):.2f} p={stats.mannwhitneyu(x,y).pvalue:.3f}')
    x=np.log2((a.wk4/a.wk0)); y=np.log2((b.wk4/b.wk0))
    out.append(f'GMFR4 ratio {2**(x.mean()-y.mean()):.2f} p={stats.mannwhitneyu(x,y).pvalue:.4f}')
    d=g.copy(); d['l0']=np.log2(d.wk0); d['l4']=np.log2(d.wk4); d['mrna']=(d.arm=='mRNA-1010').astype(int)
    m=smf.ols('l4 ~ mrna + l0', d).fit(); ci=m.conf_int().loc['mrna']
    out.append(f'ANCOVA wk4 ratio {2**m.params.mrna:.2f} ({2**ci[0]:.2f}-{2**ci[1]:.2f}) p={m.pvalues.mrna:.2g}')
    d2=d.dropna(subset=['late']).copy(); d2['ll']=np.log2(d2.late)
    m=smf.ols('ll ~ mrna + l0', d2).fit(); ci=m.conf_int().loc['mrna']
    out.append(f'ANCOVA late ratio {2**m.params.mrna:.2f} ({2**ci[0]:.2f}-{2**ci[1]:.2f}) p={m.pvalues.mrna:.2g}')
    print(' | '.join(out))
# provided fold changes consistency
fc = df[df.measure=='fold_change'].pivot_table(index=['antigen','arm','participant'], columns='timepoint', values='value').reset_index(); fc.columns.name=None
m = w.merge(fc.rename(columns={'wk4':'fc4','wk17/26':'fclate'}), on=['antigen','arm','participant'])
m['fc4c']=m.wk4/m.wk0; m['fclc']=m.late/m.wk0
bad4 = m[~np.isclose(m.fc4, m.fc4c, rtol=0.02)]
badl = m[~np.isclose(m.fclate, m.fclc, rtol=0.02, equal_nan=True)]
print('\nELISA fold-change file vs recomputed: wk4 mismatches', len(bad4), '; late mismatches', len(badl))
print(badl[['antigen','arm','participant','wk0','wk4','late','fclate','fclc']].head(30).to_string())
# participants list
print('\nELISA participants per arm:')
for arm,g in w.groupby('arm'): print(arm, sorted(g.participant.unique()))
# IgM
igm = pd.read_csv('/tmp/world/filesystem/igm_fold_change.csv', dtype={'participant':str})
print('\nIgM participant IDs:', sorted(igm.participant.unique()))
igm['pid']=igm.participant.str.zfill(3)
rows=[]
for (ag,arm),g in igm.groupby(['antigen','arm']):
    rows.append(dict(antigen=ag, arm=arm, n=len(g), GMFR=gm(g.fold_change), median=g.fold_change.median(), n_gt1=int((g.fold_change>1).sum()), n_ge4=int((g.fold_change>=4).sum())))
r=pd.DataFrame(rows)
pv={ag: stats.mannwhitneyu(np.log2(g[g.arm=='mRNA-1010'].fold_change), np.log2(g[g.arm=='Fluarix'].fold_change)).pvalue for ag,g in igm.groupby('antigen')}
r['MWU_p_between_arms']=r.antigen.map(pv)
print(r.round(3).to_string())
for ag,g in igm.groupby('antigen'):
    x=np.log2(g[g.arm=='mRNA-1010'].fold_change); y=np.log2(g[g.arm=='Fluarix'].fold_change)
    print(ag, f'IgM GMFR ratio mRNA/Flu {2**(x.mean()-y.mean()):.2f}, MWU p={stats.mannwhitneyu(x,y).pvalue:.3f}')
r.to_csv('/tmp/outputs/analysis/igm_summary.csv', index=False)
