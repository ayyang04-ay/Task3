**Recommendation: WU397 does not support a heterologous-protection claim, so the next study should be a randomised, observer-blind, antigen-matched trial (mRNA-1010 vs egg-based and recombinant-HA vaccines carrying identical WHO strains, in adults 18–64 and ≥65, stratified by prior-season vaccination) gated on neutralising breadth against a locked forward-drift virus panel at day 29 and day 181 (plus NA inhibition); commit to a drifted-strain human-challenge study and a strain-characterised relative-efficacy trial only if it passes.**

---

Bracketed IDs such as [Q6] point to the evidence ledger in Appendix A (machine-readable copy: `/tmp/outputs/numbers_provenance.csv`). Each one gives the value, the source file in `/tmp/world/filesystem/` and the script that produced it. Every analysis can be re-run with `/tmp/outputs/analysis/run_all.sh`. Facts that do not come from the data package are tagged [X#]; please check them against their sources before the committee meets.

## 1. Bottom line

WU397 shows that mRNA-1010 gives higher **binding** antibody and larger lymph-node germinal-centre responses than Fluarix. It does not show heterologous protection, and the way it was designed means it could not have shown it. It also does not show functional breadth that can be credited to the platform.

1. **The two arms got different antigens.**
   - The mRNA-1010 H1 was A/Victoria/4897/2022 (trial summary). WHO first recommended that strain for the 2023–24 season [X3].
   - Fluarix 2022–23 contained A/Victoria/2570/2019 H1 and an egg-derived A/Darwin/9/2021 H3 [X1].
   - Every "homologous/heterologous" label in the package is defined against the mRNA-1010 antigens only (trial summary).
2. **The only functional advantage is in H1, and it is not heterologous for the mRNA arm.**
   - Day-29 neutralisation of 2023 H1N1 isolates was 2.06× higher (95% CI 1.23–3.46) [Q2].
   - Those isolates are neutralised within 1.3-fold of A/Wisconsin/67/2022, the cell-based equivalent of the mRNA-1010 H1 [Q23]. In effect they are the mRNA arm's own antigen.
   - The advantage had gone by day 121/181 (1.17, 0.77–1.77) [Q2], because H1 titres in the mRNA arm fell 2.16-fold versus 1.28-fold [Q19].
3. **H3N2, the subtype that drives most antigenic drift, shows no functional advantage.**
   - Across 68 contemporary H3N2 viruses the adjusted ratio was 1.17 (0.64–2.12) at day 29 and 1.05 (0.65–1.68) at day 121/181 [Q6].
   - None of the 68 viruses individually favoured mRNA-1010 at p<0.05 [Q17].
   - Against its own H3 (A/Darwin/6/2021), mRNA-1010 was lower: 0.62 (0.34–1.12) [Q9].
4. **Binding breadth is not functional breadth.**
   - mRNA-1010 raised H3 binding on the bead array by 2.0–5.0 log2, against 0.2–2.1 for Fluarix [B10–B21].
   - In the same participants and strains, the extra H3 binding did not neutralise. The binding-minus-neutralisation gap was 2.21 log2 for mRNA-1010 versus 0.03 for Fluarix (p=0.0001) [V13].
5. **The breadth that is there points backwards.**
   - mRNA-1010 shifted neutralisation toward older strains that participants had probably been primed with: −0.81 log2 for H1 (p=0.003) and −1.01 log2 for H3 (p=0.021) [R2, R4].
   - Its H1 monoclonals bind the older 5a.2 HA more strongly than the vaccine HA [A17].
   - In both arms, 84–86% of serum IgG after vaccination comes from clonotypes that were already present [C4].
6. **HAI, the only accepted correlate, shows no difference.** Baseline-adjusted ratios were 1.01–1.54 and every 95% CI includes 1 [H9–H12]. Microneutralisation GMTs were numerically higher with Fluarix (325 vs 588 and 235 vs 368). After baseline adjustment the ratios are 0.68 and 1.17, both with wide CIs [M1–M6].
7. **Nothing in the package measures protection.**
   - There was no randomisation and no infection or clinical endpoint.
   - There is no NA readout and no influenza-B breadth readout (0 B viruses in the sequencing-based neutralisation panel [Q24]).
   - With about 14 per arm, only differences of roughly 2-fold or more could be detected [P5].
   - Several data-integrity problems are unresolved (§2.8).

## 2. What the WU397 package does and does not show

### 2.1 The comparison is confounded by design

| Issue | Evidence | Consequence for the claim |
|---|---|---|
| The arms received different antigens | mRNA-1010: A/Victoria/4897/2022 H1 and A/Darwin/6/2021 H3 (trial summary). Fluarix 2022–23: A/Victoria/2570/2019 H1 and egg-based A/Darwin/9/2021 H3 [X1]. A/Victoria/4897/2022 was first recommended for 2023–24 [X3]. | Any H1 or H3 difference mixes platform with antigen choice, so it cannot be credited to mRNA. |
| Panel labels are defined against mRNA-1010 only | Trial summary, "Notes on the virus panels". | A "homologous" virus for mRNA-1010 is heterologous for Fluarix (clearly so for H1), so the "breadth" comparisons are lopsided. |
| The antigens used in the core serology are not identified | HAI, ELISA and IgM files name only subtype or lineage; the MN panels are unlabelled. By correlation, MN titres track H3N2 (ρ 0.52–0.61) rather than H1N1 (ρ −0.19 to 0.15) [R5–R8]. HAI H1 tracks A/Victoria/4897/2022 IVR-238 most closely (ρ 0.78, against 0.74 and 0.68 for the two A/Wisconsin H1 viruses) [R9–R11]. | We cannot tell whether Fluarix recipients were ever tested against their own vaccine strains. |
| Allocation was by site, not randomised, and there are no demographics or vaccination histories | Trial summary. Baseline MN "heterologous" GMT was 57 vs 121 (p=0.057) [M7]. | Differences between arms may be differences between populations. Prior vaccination is a likely effect modifier: the Fluarix 2022–23 H1 was identical to the 2021–22 H1 [X2]. |
| Assay subsets are small and overlap selectively | 13–15 per arm for the functional assays [D1]. Seq-neut leaves out 397-014 (mRNA-1010; MN 15→10) and 397-019 (Fluarix; MN 80→1280) [D6]. | Only differences of about 2-fold or more are detectable [P5]. The two omissions bias the comparison toward mRNA-1010. |
| Readout range and panel artefacts | MN ceiling of 1280: 9/15 Fluarix participants at the ceiling at week 4 [M8]. Seq-neut: 171 results below the limit of detection and 70 above the upper limit of quantitation (ULOQ) [Q25]. Egg or reassortant viruses titrate 1.38–7.46× above their wild-type counterparts [Q21]. | Fold-rises are truncated, mostly in the Fluarix arm. Egg-derived viruses inflate apparent "breadth". |
| No protection readout | No surveillance for infection and no clinical endpoint. | This is immunogenicity only. HAI is the only accepted correlate, and only for matched strains [X9]. |

### 2.2 Functional antibody by HAI and microneutralisation: no advantage

| Readout | mRNA-1010 | Fluarix | mRNA/Fluarix, baseline-adjusted (95% CI) |
|---|---|---|---|
| HAI H1N1: GMT at week 4; seroconversion | 138; 7/14 | 88; 5/15 | 1.54 (0.87–2.71) [H1, H2, H9] |
| HAI H3N2 | 56; 2/14 | 58; 3/15 | 1.06 (0.67–1.65) [H3, H4, H10] |
| HAI B/Victoria | 57; 0/13 | 52; 1/15 | 1.05 (0.71–1.56) [H5, H6, H11] |
| HAI B/Yamagata | 88; 0/14 | 99; 1/15 | 1.01 (0.73–1.40) [H7, H8, H12] |
| MN "homologous": GMT at week 4 | 325 | 588 | 0.68 (0.31–1.51) [M3, M4, M6] |
| MN "heterologous": GMT at week 4 | 235 | 368 | 1.17 (0.52–2.62) [M1, M2, M5] |

- Both arms are heavily pre-immune. At baseline, 12/14 vs 9/15 were at HAI ≥40 for H1 and 11/14 vs 14/15 for B/Yamagata [H1–H8].
- HAI geometric mean fold-rises were only 1.05–2.76 [H1–H8].
- Nothing distinguishes the arms on functional antibody against what are presumed to be the vaccine strains.

### 2.3 Binding antibody favours mRNA-1010, most where the antigens differ

| ELISA IgG | Fold-rise at week 4, mRNA vs Fluarix | Adjusted ratio, week 4 | Adjusted ratio, week 17/26 |
|---|---|---|---|
| H1 | 5.07 vs 1.90 | 2.66 (2.01–3.53) | 1.51 (1.19–1.91) [E1, E2, E9] |
| H3 | 7.60 vs 1.99 | 3.31 (2.47–4.43) | 2.06 (1.57–2.70) [E3, E4, E10] |
| B/Victoria | 3.16 vs 2.30 | 1.35 (1.04–1.75) | 0.99 (0.78–1.26) [E5, E6, E11] |
| B/Yamagata | 2.67 vs 2.03 | 1.38 (1.11–1.71) | 1.06 (0.88–1.29) [E7, E8, E12] |

- **Where the advantage is large.** It is large only for H1 and H3, the two components whose antigens differ between the products (a different H1 strain; a cell-like versus egg-derived H3 [X1]). For the B components, where the antigens are identical, it is modest and has disappeared by the late visit.
- **IgM.** IgM rose more in the Fluarix arm (geometric mean fold-rise 3.99–5.77 vs 1.55–2.11; p=0.013–0.34) [G1–G8]. The IgM file gives no timepoint and covers 14 and 15 participants, not the 38 and 37 stated in the summary [D2].
- **Bead array.** Binding was higher with mRNA-1010 for 20 of 21 strains at p<0.05; the exception was A/Hawaii/70/2019, p=0.10 [B1–B21]. That includes A/Puerto Rico/8/1934 (log2 fold-rise 1.54 vs 0.10) [B6] and A/Hong Kong/1/1968 (3.45 vs 0.20) [B13], whose HA heads share little with the vaccine. That pattern usually means conserved, often non-neutralising, epitopes or recall of older memory.
- **Bead-array panels look backwards.** Only two strains were isolated after 2021: one H1 (A/Wisconsin/67/2022, itself the cell-based equivalent of the mRNA-1010 H1) and one H3 (A/Thailand/8/2022). All the others are historical [B22].

### 2.4 Neutralisation breadth on the sequencing-based panel: the only readout that speaks to the claim

Participant-level analysis: 13 mRNA-1010 and 14 Fluarix participants. Viruses were grouped before analysis by their relationship to each arm's vaccine strains. The panel has 96 viruses, 0 of them influenza B [Q24].

| Subtype | Virus category (n viruses) | Day-29 GMT, mRNA vs Fluarix | Adjusted ratio, day 29 | Adjusted ratio, day 121/181 |
|---|---|---|---|---|
| H1N1 | mRNA-1010-matched (2) | 996 vs 537 | 1.84 (1.17–2.90) | 1.15 (0.76–1.72) [Q4] |
| H1N1 | Fluarix-matched, A/Wisconsin/588/2019 (1) | 1073 vs 506 | 2.44 (1.18–5.05) | 1.17 (0.62–2.23) [Q1] |
| H1N1 | Contemporary 2023 isolates (6) | 478 vs 257 | 2.06 (1.23–3.46) | 1.17 (0.77–1.77) [Q2] |
| H1N1 | Historical (4) | 2533 vs 1687 | 1.69 (0.91–3.13) | 1.11 (0.61–2.03) [Q3] |
| H3N2 | mRNA-1010-matched, A/Darwin/6/2021 (1) | 244 vs 482 | 0.62 (0.34–1.12) | 0.72 (0.40–1.31) [Q9] |
| H3N2 | Fluarix-matched, A/Darwin/9/2021 (1) | 1009 vs 1539 | 0.81 (0.35–1.87) | 0.57 (0.25–1.27) [Q5] |
| H3N2 | Contemporary 2022–24 isolates (68) | 402 vs 467 | 1.17 (0.64–2.12) | 1.05 (0.65–1.68) [Q6] |
| H3N2 | Historical wild-type (8) | 1524 vs 1273 | 1.63 (0.99–2.68) | 1.44 (0.87–2.40) [Q7] |
| H3N2 | Historical egg/reassortant (5) | 4751 vs 3345 | 1.54 (1.05–2.27) | 1.37 (0.85–2.21) [Q8] |

**H1N1: about 2× higher at day 29 across the board, but neither heterologous nor durable.**
- The 2023 isolates are antigenically the mRNA arm's own antigen: in both arms their titres sit within 1.3-fold of A/Wisconsin/67/2022 [Q23]. All six favour mRNA-1010 individually (per-virus ratios 1.93–2.29) [Q18], just as A/Wisconsin/67/2022 does (2.07; ≥4-fold rises 6/13 vs 1/14) [Q14]. No virus in the panel is heterologous to the mRNA-1010 H1. (The mRNA-matched category also contains the egg reassortant A/Victoria/4897/2022 IVR-238, ratio 1.60 [Q16].)
- The advantage also covers Fluarix's own H1 equivalent, A/Wisconsin/588/2019 (2.44×; ≥4-fold rises 9/13 vs 2/14) [Q1, Q15]. A simple antigen-match explanation cannot produce that. Two other explanations can:
  - antigen novelty: Fluarix recipients would have been re-exposed to an unchanged H1 [X2];
  - platform potency.
- WU397 cannot tell these apart.
- By day 121/181 the ratios are 1.11–1.17 [Q1–Q4], because H1 titres in the mRNA arm fell 2.16-fold against 1.28-fold in Fluarix (p=0.0005) [Q19].
- These conclusions hold when censored values are handled differently and when the late visit is restricted to day 181 (`analysis/seqneut_sensitivity.csv`).

**H3N2: no advantage against current or next-season viruses.**
- The contemporary panel shows no difference at either timepoint [Q6]. The median per-virus ratio was 1.15, and 0/68 viruses favoured mRNA-1010 at p<0.05 [Q17].
- A/Thailand/8/2022 and A/Massachusetts/18/2022, later chosen as the 2024–25 H3N2 vaccine strains [X11], gave ratios of 0.82 and 0.90. ≥4-fold rises were seen in 1/13 and 1/12 mRNA-1010 recipients versus 4/14 and 4/13 Fluarix recipients [Q10, Q11].
- For the vaccine H3 strains, ≥4-fold rises were 2/13 vs 4/14 against A/Darwin/6/2021 and 7/13 vs 5/14 against A/Darwin/9/2021 [Q12, Q13]. H3 waning was similar in the two arms (1.57- vs 1.45-fold, p=0.42) [Q20].
- The only H3 categories leaning toward mRNA-1010 are historical strains [Q7, Q8].

**How much weight these results can bear.**
- These are 13 versus 14 people. WU397 was powered only for differences of about 2-fold [P5], and its contemporary-H3N2 interval (0.64–2.12) still allows up to a 2-fold advantage [Q6]. "No evidence of an advantage" is not evidence that there is none, and that gap is why Study 1 is needed.
- **Statistical hygiene matters here.** If the 1,808 virus × participant H3N2 observations are treated as independent, the result is a spuriously "significant" 1.13× (p=0.0018). The correct participant-level model gives 1.06 (0.62–1.82), p=0.82 [Q22]. Any internal material claiming significant breadth from pooled virus-level tests should be withdrawn.

### 2.5 For H3, binding breadth is not functional breadth

Twelve strains were measured by both bead-array binding and seq-neut in the same 27 participants (Figure 1; per-strain values [V1–V12]).
- **H1.** Binding and neutralisation gains agree: the binding-minus-neutralisation gap is −0.41 vs −0.50 log2 [V13].
- **H3.** mRNA-1010's binding gain exceeds its neutralisation gain by 2.21 log2 (about 4.6-fold). In Fluarix the gap is 0.03 (p=0.0001) [V13]. Relative to Fluarix:
  - for the vaccine H3, A/Darwin/6/2021, mRNA-1010's binding was +2.85 log2 but neutralisation was −0.29 log2 [V7];
  - for A/Thailand/8/2022, binding was +3.57 and neutralisation −0.17 [V8].
- **Implications:**
  - The bead-array panels and the binding-only monoclonal data cannot be used as evidence of heterologous protection for H3.
  - Whether the surplus binding antibodies protect in some other way (for example through Fc-mediated functions) has not been tested. Studies 1 and 2 ask that question explicitly.

### 2.6 The response is pulled backwards toward imprinted strains, not forwards

- **H1.** The mRNA-1010 antigen is clade 5a.2a.1 [X12].
  - In mRNA-1010 recipients, the log2 ratio of titres against A/Wisconsin/67/2022 (5a.2a.1) to A/Wisconsin/588/2019 (5a.2) moved from −0.50 to −1.31 (shift −0.81, p=0.003) [R2].
  - In Fluarix recipients it moved by −0.47 (p=0.36). Between-arm p=0.049 [R1, R2].
- **H3.** Titres against A/Darwin/6/2021 relative to A/Cambodia/e0826360/2020 (the 2021–22 vaccine strain [X2]) moved −1.01 log2 with mRNA-1010 (p=0.021) and +0.28 with Fluarix (p=0.36). Between-arm p=0.022 [R3, R4].
- **Monoclonals.** H1 monoclonals from all four mRNA-1010 donors bind A/Wisconsin/588/2019 more strongly than their own vaccine HA (median signal ratio 0.24–0.54). Only 1 of 264 binds the vaccine HA without also binding the older HA [A17].
- **Repertoire.**
  - 83.9% versus 86.2% of serum IgG after vaccination comes from clonotypes that were already present [C4].
  - 73–92% of germinal-centre clones in mRNA-1010 donors are shared with week-1 plasmablasts [C3], which come mainly from pre-existing memory B cells [X13].
- **Implication.** The pattern is consistent with recall of imprinted memory toward older strains, i.e. backward breadth. A heterologous-protection claim is about forward breadth: viruses that emerge after strain selection.

### 2.7 Cellular, repertoire and monoclonal antibody data

- **Germinal-centre responses are larger and longer-lived with mRNA-1010.**
  - At week 2, 24.2% vs 2.3% of germinal-centre B cells were HA-specific (n=6 vs 11; p=0.037) [C1]. The responses persisted at weeks 17 and 26 (16.0 vs 2.3, p=0.083; 18.9 vs 1.6, p=0.34) [C2].
  - That is a plausible route to affinity maturation. However, the clones are largely recalled memory [C3, X13], and the Fluarix germinal-centre sample was tiny (7, 5 and 1 clones in three donors) [C3].
  - Serum breadth at the late visit did not improve [Q6].
- **Repertoire.** mRNA-1010 produced more vaccine-elicited serum clonotypes (32.0 vs 20.1, p=0.066) [C5] and higher CDR-H3 diversity at week 4 (71.2 vs 24.9, p=0.010) [C6]. These are 8 per arm and cannot be linked to other assays [D5].
- **Monoclonal antibodies: sampling is very unequal.**
  - There are 589 monoclonals from 4 mRNA-1010 donors and 106 from 3 Fluarix donors. Two of the Fluarix donors contributed only 2 and 7 H3-panel monoclonals [A15].
  - **H3 panel:** breadth at donor level favours mRNA-1010. Forward-strain binding is 35–68% vs 0–48%, and H7 cross-binding 2.6–21.3% vs 0% [A8–A14].
  - **Limits of the H3 finding:**
    - With 4 versus 3 donors, the smallest exact two-sided p that can be reached is 0.057 [A18].
    - The monoclonals were tested for binding only.
    - The control antigen is the normaliser (it equals 1.0 for every monoclonal), so there is no empirical positivity cut-off. We used >10-fold and checked 5-fold as a sensitivity analysis [A16].
  - **H1 panel:** forward binding does not differ (84–94% vs 50–93%) [A1–A7].

### 2.8 Data-integrity problems to resolve before the committee

1. The IgM file covers 14 and 15 participants, not the 38 and 37 stated. It has no timepoint, and it uses the ID "20" instead of "020" [D2].
2. `plasmablast_frequencies.csv` covers 13 and 15 participants. Eleven of them are outside the FNA cohort, and the data are at weeks 2 and 8, which are not blood-draw visits [D3]. It is unclear whether these are blood or lymph-node measurements.
3. `gc_frequencies.csv` contains two 78-row blocks under the same column name. It includes week 0, which is not an FNA visit, and lacks weeks 1 and 4, which are [D4]. The second block cannot be used until it is labelled.
4. The repertoire, CDR-H3 and serum clonotype files have no participant identifiers [D5].
5. Participant ID formats differ between files (397-0NN, NN, 397-NN and "20"). The virus name A/SOUTHAFRICA/R07876/202023 is malformed [Q26].
6. **Timepoints are unclear or pooled:**
   - the bead-array fold-change timepoint is not stated;
   - "wk17/26" pools visits two months apart;
   - late seq-neut sera are day 121 for 6 participants and day 181 for 21 [Q27].
7. There is no documented reason for leaving 397-014 and 397-019 out of the seq-neut cohort [D6].
8. The antigens used for HAI, ELISA, IgM and MN are not identified. The Fluarix lot composition and the mRNA-1010 dose are not recorded.

### 2.9 What can be said now

- **Supportable, with the non-randomised caveat:** "In a small non-randomised study, mRNA-1010 elicited higher HA-binding IgG than Fluarix (H1 2.66×, H3 3.31× at week 4) [E9, E10] and larger, more persistent lymph-node germinal-centre responses, with similar HAI and microneutralisation titres."
- **Not supportable:** "broader", "cross-protective", "heterologous protection", "durable breadth" or "superior neutralisation of drifted strains".

## 3. Recommended next studies

| # | Study | Question it settles | Timing |
|---|---|---|---|
| 0 | WU397 close-out (records plus banked samples; no new enrolment) | Makes the existing package interpretable and adds NA and Fc readouts | Now, before the committee where possible |
| 1 | **Randomised, antigen-matched immunogenicity and functional-breadth trial (the gate)** | Does the mRNA platform, not antigen choice, give better forward functional breadth that lasts through the season? | Next Northern Hemisphere season |
| 2 | Human-challenge study with a drifted strain | Does vaccination protect against an antigenically distinct virus, by any mechanism? | Not tied to a season; alongside or after Study 1 |
| 3 | Relative-efficacy trial with strain-characterised endpoints | Does it reduce influenza caused by mismatched strains in the target population? | Only after Study 1 (± Study 2) passes |

### Study 0 — WU397 close-out

**Records to obtain:**
- the Fluarix lot and its strain composition;
- the mRNA-1010 dose and lot;
- the antigen identity (strain; egg- or cell-derived) used for HAI, ELISA, IgM and each MN panel;
- age, sex, site and enrolment date for each participant;
- influenza vaccinations in the three prior seasons;
- any influenza-like illness or confirmed influenza during follow-up.

**Fix the file problems** listed in §2.8.

**Add readouts on banked sera** (same participants and visits, consent permitting):
- **NA-inhibition titres** (N1, N2) at day 0, 29 and 181. The summary lists only HA-strain antigens for mRNA-1010 [X10], whereas a split-virion vaccine contains NA, and NA inhibition is an independent correlate of protection [X8].
- **Neutralisation** against:
  - each product's own vaccine strains (A/Victoria/2570/2019-like H1 for Fluarix);
  - the viruses that actually circulated at the sites in 2022–23;
  - H1N1 viruses heterologous to A/Victoria/4897/2022 (none are in the current panel);
  - B/Victoria viruses (none are in the current panel).
- **Fc-effector function** against forward H3N2 viruses, to test whether the H3 binding surplus does anything.
- **Neutralisation, not just binding, for the broadly binding monoclonals.**

**Re-analyse:**
- with the participant as the unit;
- with homologous and heterologous defined symmetrically for each arm;
- reporting egg-derived viruses separately.

Study 0 can sharpen the hypotheses and the Study 1 panel. It cannot establish the claim, because WU397 is non-randomised, antigen-mismatched and about 14 per arm [D1].

### Study 1 — Randomised, observer-blind, antigen-matched immunogenicity and functional-breadth trial (the gate)

**Conditions**
- **Randomisation and blinding:** individual, central randomisation, stratified by site, age band and prior-season vaccination. Observer-blind, with laboratories blinded to arm.
- **Dose and timing:** a single dose at the intended commercial mRNA-1010 dose (record it; WU397 does not). One season, with vaccination finished before local influenza activity begins.
- **Identical strain composition in every arm.**
  - Use the WHO-recommended composition for the season: trivalent H1N1pdm09, H3N2 and B/Victoria, since B/Yamagata has been dropped [X4].
  - mRNA-1010 encodes the HA sequences recommended for cell or recombinant production.
  - Record each comparator's actual seed or reassortant and its sequence differences.
- **Surveillance:** active surveillance for influenza-like illness with RT-PCR through day 181. Samples taken after a confirmed infection are excluded from the primary breadth and durability analyses and reported separately.

**In whom**
- **Cohort A:** adults 18–64. **Cohort B:** adults ≥65.
- Medically stable and not yet vaccinated in the current season.
- Enrol at least 30% per cohort who were not vaccinated in the prior season, so the effect of prior vaccination can be estimated. This is the competing explanation for WU397's H1 result [X2].
- Record birth year and the prior three seasons' vaccines.

**Against what**
- **Comparators:**
  - **Cohort A:** egg-based standard-dose inactivated vaccine (Fluarix: continuity with WU397 and standard of care), and a recombinant-HA vaccine. The recombinant vaccine carries the same non-egg HA sequences as mRNA-1010, which separates the platform from egg adaptation.
  - **Cohort B:** the enhanced vaccine that is standard of care at ≥65 [X7]. Recombinant HA is preferred because its sequences match; add high-dose inactivated vaccine where that is the local standard.
- **Virus panels:** lock the selection rules in the SAP before any post-vaccination sample is tested, and finalise panel membership by those rules, blind to arm. The panels are the same for every arm because the compositions are the same.
  - **P-0 (vaccine strains):** the wild-type sequence, plus each comparator's egg-derived version, reported separately.
  - **P-1 (forward-drift panel; primary):** wild-type H3N2, H1N1 and B/Victoria viruses covering:
    - every HA subclade at ≥5% global frequency in the 6 months before and during the season;
    - viruses that WHO collaborating centres report as antigenically distinct from the vaccine strain;
    - the strain WHO later selects for the following season, added by rule when announced.
    - Balance the panel across subtypes. WU397's was 68 H3N2, 6 H1N1 and 0 B [Q24].
  - **P-2 (backward panel; secondary):** the previous 3–5 vaccine strains and older strains. Never pool it with P-1.
  - Keep egg-adapted or reassortant viruses out of all breadth scores, because they titrate 1.38–7.46× above their wild-type counterparts [Q21].

**Readouts**

| What is measured | In whom | Against | When | Role |
|---|---|---|---|---|
| Neutralising titre, quantitative across the full expected range (WU397's MN ceiling truncated 9/15 Fluarix samples [M8]). Breadth score = participant-level geometric-mean titre across P-1, per subtype. | All | P-1 | Days 0, 29, 91, 181 | **Primary** at days 29 and 181; day 91 key secondary |
| HAI titre: GMT and seroconversion | All | P-0 (plus P-1 representatives for H1N1 and B) | Days 0, 29, 181 | Key secondary: non-inferiority on vaccine strains |
| NA-inhibition titre | All | N1 and N2 of the vaccine strains plus one drifted NA each; B NA | Days 0, 29, 181 | Key secondary [X8] |
| Binding IgG to HA head and stem; binding:neutralisation ratio | All | P-0 and P-1 representatives | Days 0, 29, 181 | Secondary: checks whether the non-neutralising H3 binding excess recurs [V13] |
| Fc-effector function | Subset of about 50 per arm | P-1 representatives | Days 0, 29 | Secondary / exploratory |
| Neutralising titre | All | P-2 | Days 0, 29 | Secondary: backward breadth, reported separately |
| Memory B-cell breadth; HA-specific CD4 T cells; mucosal IgA | Subset | P-0 and P-1 representatives | Days 0, 29, 181 | Exploratory |
| Lymph-node germinal-centre responses (only if mechanistic data are still wanted; randomised, at least 10 per arm) | Subset | P-0 and P-1 representatives | Weeks 1–26 | Exploratory |
| Neutralising titre | All who consent | The following season's WHO strains, plus P-1 | Day 365, before revaccination | Exploratory: protection carried into the next season |
| RT-PCR-confirmed influenza, with HA sequence | All participants with influenza-like illness | — | Days 0–181 | Descriptive; used to censor samples |
| Reactogenicity and safety | All | — | Solicited reactions 7 days; unsolicited 28 days; SAEs and AESIs to day 181 | Safety |

**Primary endpoints and success criteria**
- **Endpoint:** breadth-score GMT ratio, mRNA-1010 / comparator, at day 29 and at day 181. It is adjusted (ANCOVA) for baseline titre, age band and prior vaccination. Test in a fixed sequence: H3N2 first, then H1N1, then B/Victoria.
- **Criteria for a heterologous-breadth claim (all must hold):**
  - the lower bound of the 95% CI is above 1.0 at both day 29 and day 181, against **both** comparators in the cohort;
  - HAI is non-inferior on the vaccine strains (upper bound of the comparator/new GMT ratio ≤1.5; upper bound of the seroconversion difference ≤10 points) [X5];
  - there is no uncompensated NA-inhibition deficit.
- **Differentiation threshold:** if a superiority claim will be marketed, pre-specify a lower bound above 1.5, by analogy with the high-dose vaccine HAI bar [X6].
- **Analysis rules:**
  - The unit is the participant, not the virus [Q22].
  - Handling of values outside the assay range is pre-specified.
  - The panel is locked before unblinding.

**Size**
- **Variability from WU397:** the participant-level breadth-score residual SD is 0.94–1.03 log2 (raw 1.21–1.65) [P1].
- **Primary endpoints:** detecting a true GMT ratio of 1.5 with 90% power, at a conservative two-sided α of 0.0125 per comparison (2 comparators × 2 timepoints), needs 84–131 evaluable per arm for SD 1.0–1.25 [P2].
- **Plan:** about 150 evaluable (about 175 randomised) per arm. That is about 525 in Cohort A and about 350 in Cohort B. At that size each comparison has 94% to >99% power, and the chance that all four succeed together is at least 78–98% [P10].
- **Differentiation bar:** a lower bound above 1.5 (true ratio 2.0) needs 166–260 per arm [P3].
- **HAI:** the plan also covers HAI GMT non-inferiority, which needs 63–117 per arm at WU397's SDs [P4, P6]. Seroconversion non-inferiority is descriptive at this size.

**How to read the result**

| Day-181 forward breadth | Interpretation | Next step |
|---|---|---|
| mRNA-1010 beats both comparators | Platform effect | Proceed to Study 3 (Study 2 supportive) |
| mRNA-1010 beats the egg-based vaccine but roughly equals recombinant HA | The advantage comes from avoiding egg adaptation, not from mRNA | No mRNA-specific heterologous claim |
| Neutralisation roughly equal, but mRNA-1010 better on Fc or binding | Unresolved | Study 2 decides |
| Anything else | No advantage | Drop the heterologous claim; pursue standard non-inferiority and relative-efficacy labelling |

### Study 2 — Human-challenge study with an antigenically drifted virus

**Conditions**
- Randomised, double-blind, 1:1:1: mRNA-1010 : licensed comparator with the same composition (recombinant HA preferred) : placebo.
- Challenge about 4–6 weeks after vaccination, at peak response.
- If the first cohort is positive, add a second cohort challenged at about 5–6 months to test durability, since WU397's H1 advantage had gone by then [Q19].

**In whom**
- Healthy adults 18–45 with no high-risk conditions.
- Screened as susceptible: low baseline HAI and neutralising titre against the challenge virus.
- Stratified by prior-season vaccination.

**Against what**
- An established, manufactured challenge virus, H3N2 first because WU397 shows no H3 signal.
- It must be antigenically distinct from the vaccine H3 by a pre-specified criterion: a different subclade and ≥8-fold reduced reactivity with vaccine-strain reference antiserum.
- It must be wild-type, not an egg-adapted vaccine variant.
- Challenge with H1N1 second, only if the H3N2 result is positive.

**Readouts**
- **Primary:** laboratory-confirmed symptomatic influenza.
- **Secondary:**
  - laboratory-confirmed infection of any kind (virus shedding, or seroconversion to challenge-virus antigens absent from the vaccine);
  - viral-load AUC, peak and duration of shedding;
  - symptom-score AUC.
- **Correlates:**
  - pre-challenge neutralising, HAI, NA-inhibition and Fc titres against the challenge virus;
  - mucosal IgA;
  - T cells.

**Size**
- With about 50% illness in controls, 39–77 per arm detects a reduction to 20–25% versus placebo at 80–90% power [P7].
- mRNA-1010 versus the licensed vaccine is an estimate only, unless the study has about 82–109 per arm (40% vs 20%) [P7].

**Value and limits**
- This is the only direct test of whether non-neutralising binding breadth protects.
- It is supportive evidence, not licensure-enabling, because it uses characterised older challenge viruses in young, susceptible adults.

### Study 3 — Relative-efficacy trial with strain-characterised endpoints

**Conditions**
- Randomised 1:1, observer-blind and multi-country.
- Run over at least two seasons and/or both hemispheres, so that mismatch events actually happen.
- Identical WHO strains in both arms, with vaccination before the season starts.

**In whom**
- Adults ≥50, stratified 50–64 and ≥65 and by prior vaccination.

**Against what**
- Standard-dose inactivated vaccine at 50–64, and the enhanced vaccine that is standard of care at ≥65 [X7].

**Readouts**
- **Primary:** first RT-PCR-confirmed, protocol-defined influenza-like illness caused by any influenza A or B, from 14 days after vaccination to the end of the season. Report relative vaccine efficacy, testing non-inferiority first and then superiority.
- **Key secondary that defines the claim:** the same endpoint, restricted to antigenically mismatched viruses.
  - Every positive specimen is HA-sequenced centrally, blinded to arm.
  - "Mismatched" is defined in advance: a subclade different from the vaccine strain, plus WHO collaborating-centre antigenic data showing ≥8-fold reduced reactivity with vaccine-strain antiserum.
  - Report relative efficacy against mismatched viruses with its 95% CI, and test the mismatched-versus-matched interaction.
- **Other secondaries:**
  - relative efficacy by subtype;
  - influenza-associated hospitalisation or pneumonia;
  - relative efficacy early versus late in the season;
  - relative efficacy by age band and prior vaccination.
- **Correlates subset (case-cohort):**
  - sera at days 0, 29 and 181;
  - HAI and neutralisation against the vaccine strains and against isolates from the trial itself;
  - NA inhibition.
  - These would form the basis for immunobridging later strain updates.

**Size**
- About 508 cases are needed for 25% relative efficacy at 90% power (one-sided α 0.025, 1:1 allocation). At an assumed 2% seasonal attack rate, that is about 29,000 participants [P8].
- A fully powered test restricted to mismatched viruses needs about 508 mismatched cases. If 40% of cases are mismatched, that is about 72,600 participant-seasons [P8].
- So pool across seasons, or treat the mismatched-virus result as an estimate.
- For 20% or 30% relative efficacy, about 845 or 331 cases are needed [P9].

### Decision logic and an alternative claim

- **Sequence.** Do Study 0 now. Study 1 is the gate. Study 2 can run alongside Study 1, and is mandatory if Study 1 shows only Fc or binding advantages. Study 3 goes ahead only if Study 1 passes (and ideally Study 2 as well).
- **Alternative claim.** A plausible and economical reading of WU397's H1 result is that mRNA-1010 carried a newer strain, a season ahead of the comparator's. If the programme wants to claim the benefit of later strain selection or faster updating, that is a different claim: better antigenic match, not heterologous protection.
  - It needs its own design: a pre-specified late-selection rule, compared against the WHO-timed composition and the comparator.
  - The endpoint would be match to, and neutralisation of, the viruses that actually circulate.

## 4. Assumptions and limits of this analysis

- **Virus categories.** These were assigned before analysis from virus names and isolation years. The package contains no sequences or antigenic-distance data. A/SOUTHAFRICA/R07876/202023 was treated as a 2023 isolate [Q26].
- **External facts.** Strain compositions, clade assignments, WHO timing, regulatory criteria and general immunology are external to the package [X1–X13] and should be checked.
- **Statistics.** All between-arm statistics use about 14 per arm [D1] and are not adjusted for multiplicity. Treat them as exploratory. ANCOVA adjusts for baseline titre only, because no covariates were supplied.
- **Censored seq-neut values** were used at their reported bounds. Alternative handling did not change any conclusion (`analysis/seqneut_sensitivity.csv`).
- **Infection during follow-up.** We found no serological sign of it in the seq-neut cohort: no participant showed a consistent ≥4-fold late rise, and the most was 2 of 83 H3N2 viruses in one participant [Q28]. Without surveillance, it cannot be ruled out.
- **Sample-size assumptions.** The calculations rest on assumed effect sizes and attack rates, stated at each use. Only the variance inputs come from WU397.

## 5. Files

- `/tmp/outputs/answer.md`: this document.
- `/tmp/outputs/numbers_provenance.csv`: every number cited, with its source file and derivation.
- `/tmp/outputs/figures/`:
  - `fig1_binding_vs_neutralisation.png`: H3 binding gains not matched by neutralisation;
  - `fig2_seqneut_ratios_by_category.png`: adjusted GMT ratios by virus category, day 29 and day 121/181;
  - `fig3_contemporary_panel_trajectories.png`.
- `/tmp/outputs/analysis/`:
  - scripts `01_hai.py` … `16_ledger_markdown.py`;
  - `run_all.sh` (re-runs everything and re-assembles this file from `answer_body.md` plus the auto-generated `ledger_table.md`);
  - intermediate tables (`*_summary.csv`, `seqneut_*.csv`, `backward_shift.csv`, `mab_breadth_by_donor.csv`, etc.);
  - logs (`log_*.txt`).

## Appendix A. Evidence ledger (every number cited, with its source)

Source files are in `/tmp/world/filesystem/`. Scripts are in `/tmp/outputs/analysis/`. "late" means the wk17 or wk26 visit (HAI, MN, ELISA) or day 121 or day 181 (seq-neut). Ratios are mRNA-1010 / Fluarix unless stated otherwise.

