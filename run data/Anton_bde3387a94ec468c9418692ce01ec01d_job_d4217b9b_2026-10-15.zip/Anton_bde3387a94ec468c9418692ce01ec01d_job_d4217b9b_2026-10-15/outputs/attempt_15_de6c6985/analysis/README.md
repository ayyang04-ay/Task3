# WU397 re-analysis: scripts and intermediate outputs

Re-run everything (about 1 minute): `bash /tmp/outputs/analysis/run_all.sh`. This uses the micromamba env `core` and reads `/tmp/world/filesystem/` read-only. At the end it regenerates `/tmp/outputs/answer.md` from `answer_body.md` plus the auto-generated `ledger_table.md`.

| Script | Input file(s) | What it does | Main outputs |
|---|---|---|---|
| 01_hai.py | hai_titers.csv | Computes GMT, fold-rise, seroconversion and seroprotection, plus a baseline-adjusted ANCOVA GMT ratio. | hai_summary.csv, hai_wide.csv |
| 02_mn.py | microneutralization.csv | Computes GMT, fold-rise, ceiling counts and ANCOVA, and checks the file's fold-change column for consistency. | mn_summary.csv, mn_wide.csv |
| 03_elisa_igm.py | elisa_igg_titers.csv, igm_fold_change.csv | ELISA GMT and fold-rise with ANCOVA (week 4 and late); IgM geometric mean fold-rise. | elisa_summary.csv, igm_summary.csv |
| 04_seqneut.py | neutralization_seqbased.csv | Assigns each virus to a category in advance, then compares arms at participant level within each category. | seqneut_wide.csv, seqneut_virus_categories.csv, seqneut_category_*.csv |
| 05_seqneut_bysubtype.py | (output of 04) | Subtype × category ANCOVA and a per-virus table. | seqneut_subtype_category_tests.csv, seqneut_per_virus.csv |
| 06_binding_vs_neut.py | binding_breadth_h1/h3.csv, seq-neut | Binding versus neutralisation concordance in the same participants and strains; bead-array summary. | binding_vs_neut_concordance.csv, bead_array_summary.csv |
| 07_mabs.py | mab_binding_panels.csv | Monoclonal breadth with donor as the unit; control check; H1 binding to the vaccine HA versus the older HA. | mab_breadth_by_donor.csv, mab_h1_vic_vs_wisc.csv |
| 08_repertoire_cellular.py | repertoire, CDR-H3, clonotype, GC, plasmablast and overlap files | Compares arms and checks the file structure. | log only |
| 09_intercurrent.py | (outputs of 01–04) | Screens for late rises (possible intercurrent infection). | log only |
| 10_egg_pairs_and_decay.py | (output of 04) | Egg or reassortant versus wild-type pairs; waning from day 29 to the late visit. | log only |
| 11_sample_size.py | (outputs of 01 and 04) | Variance inputs and sample-size and power calculations for Studies 1–3. | log only |
| 12_seqneut_sensitivity.py | neutralization_seqbased.csv | Alternative handling of censored values, a day-181-only analysis, a mixed model, and a naive pooled model for contrast. | seqneut_sensitivity.csv |
| 13_backward_shift_and_panel_identity.py | (outputs of 01, 02, 04) | Backward shift toward older strains; inference of which viruses the unlabelled MN and HAI antigens behave like; seq-neut cohort gaps; how the 2023 H1 isolates relate to the vaccine equivalents. | backward_shift.csv, panel_identity_inference.csv, h1_2023_vs_vaccine_equivalents.csv |
| 14_figures.py | outputs above | Figures 1–3. | ../figures/*.png |
| 15_build_ledger.py | outputs above plus source files | Evidence ledger of every number cited; external facts are flagged. | ../numbers_provenance.csv |
| 16_ledger_markdown.py | numbers_provenance.csv | Renders the ledger with short IDs (H1, Q6, and so on). | ledger_table.md, ledger_short_ids.csv |
