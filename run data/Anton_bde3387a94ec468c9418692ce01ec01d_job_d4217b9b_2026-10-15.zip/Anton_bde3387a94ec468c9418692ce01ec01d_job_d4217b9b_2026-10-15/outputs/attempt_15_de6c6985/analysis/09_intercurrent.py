"""Screen for possible intercurrent infection / late boosting (late titre >= 4x the week-4/day-29 titre), which would confound durability and breadth.
Sources: hai_titers.csv, microneutralization.csv, elisa_igg_titers.csv, neutralization_seqbased.csv"""
import pandas as pd, numpy as np
pd.set_option('display.width',250); pd.set_option('display.max_rows',500); pd.set_option('display.max_columns',60)
h = pd.read_csv('/tmp/outputs/analysis/hai_wide.csv', dtype={'participant':str})
h['late_over_wk4']=h.late/h.wk4
print('HAI late >= 2x wk4:'); print(h[h.late_over_wk4>=2][['antigen','arm','participant','wk0','wk4','late','late_over_wk4']].to_string())
m = pd.read_csv('/tmp/outputs/analysis/mn_wide.csv')
m['late_over_wk4']=m.late/m.wk4
print('\nMN late >= 2x wk4:'); print(m[m.late_over_wk4>=2][['panel','arm','participant','wk0','wk4','late']].to_string())
e = pd.read_csv('/tmp/world/filesystem/elisa_igg_titers.csv'); e=e[e.measure=='ec50']
e['tp']=e.timepoint.replace({'wk17':'late','wk26':'late'})
ew=e.pivot_table(index=['antigen','arm','participant'],columns='tp',values='value').reset_index(); ew.columns.name=None
ew['r']=ew.late/ew.wk4
print('\nELISA late >= 2x wk4:'); print(ew[ew.r>=2].to_string())
w = pd.read_csv('/tmp/outputs/analysis/seqneut_wide.csv')
w['late_minus_29']=w.late-w.d29
ps=w.groupby(['arm','pid','subtype']).agg(n=('virus','count'), n_late_4x=('late_minus_29', lambda x: int((x>=2).sum())), mean_late_minus_29=('late_minus_29','mean')).reset_index()
print('\nSeqneut: per participant/subtype number of viruses with late titre >=4x d29, and mean log2(late/d29):')
print(ps[(ps.n_late_4x>0)|(ps.mean_late_minus_29>0.5)].round(2).to_string())
print('\nAll participants, mean log2(late/d29) by subtype:')
print(ps.pivot_table(index=['arm','pid'],columns='subtype',values='mean_late_minus_29').round(2).to_string())
