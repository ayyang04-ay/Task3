"""Sensitivity analyses for the seqneut between-arm comparisons:
 (1) censored values: below-LOD set to LOD/2, above-ULOQ set to 2xULOQ (vs. reported bound in main analysis)
 (2) late timepoint restricted to day 181 only (drop d121 contributors)
 (3) linear mixed model on virus-level log2 titres (participant random intercept), contemporary H3N2 and H1N1
Source: /tmp/world/filesystem/neutralization_seqbased.csv"""
import pandas as pd, numpy as np, re
import statsmodels.formula.api as smf
import warnings; warnings.filterwarnings('ignore')
pd.set_option('display.width',250)
cat = pd.read_csv('/tmp/outputs/analysis/seqneut_virus_categories.csv')
df = pd.read_csv('/tmp/world/filesystem/neutralization_seqbased.csv')
df['arm']=df.serum.str.split('_').str[0]; df['pid']=df.serum.str.split('_').str[1]; df['day']=df.serum.str.split('_').str[2]
df=df.merge(cat[['virus','subtype','category']], on='virus')
def run(d, label, late_days=('d121','d181')):
    d=d.copy(); d['lt']=np.log2(d.t)
    d=d[d.day.isin(['d0','d29']+list(late_days))]
    d['tp']=d.day.replace({x:'late' for x in late_days})
    w=d.pivot_table(index=['arm','pid','virus','subtype','category'],columns='tp',values='lt').reset_index(); w.columns.name=None
    ps=w.groupby(['arm','pid','subtype','category']).agg(l0=('d0','mean'),l29=('d29','mean'),ll=('late','mean')).reset_index()
    rows=[]
    for (st,c),g in ps.groupby(['subtype','category']):
        if c not in ('contemporary 2022-24 wild-type','mRNA-1010 strain-matched','Fluarix(2022-23) strain-matched'): continue
        g=g.copy(); g['mrna']=(g.arm=='mRNA-1010').astype(int)
        m=smf.ols('l29 ~ mrna + l0',g).fit(); ci=m.conf_int().loc['mrna']
        g2=g.dropna(subset=['ll']); m2=smf.ols('ll ~ mrna + l0',g2).fit(); ci2=m2.conf_int().loc['mrna']
        rows.append(dict(analysis=label, subtype=st, category=c, d29_ratio=f'{2**m.params.mrna:.2f} ({2**ci[0]:.2f}-{2**ci[1]:.2f})', late_ratio=f'{2**m2.params.mrna:.2f} ({2**ci2[0]:.2f}-{2**ci2[1]:.2f})', n_late=len(g2)))
    return pd.DataFrame(rows)
base=df.copy(); base['t']=base.titer
s1=df.copy(); s1['t']=np.where(s1.titer_bound=='upper', s1.titer/2, np.where(s1.titer_bound=='lower', s1.titer*2, s1.titer))
R=pd.concat([run(base,'main (reported bounds)'), run(s1,'censored: LOD/2, 2xULOQ'), run(base,'late = d181 only', late_days=('d181',))])
print(R.to_string())
R.to_csv('/tmp/outputs/analysis/seqneut_sensitivity.csv', index=False)
# mixed model, virus-level
d=base.copy(); d['lt']=np.log2(d.t)
w=d.pivot_table(index=['arm','pid','virus','subtype','category'],columns='day',values='lt').reset_index(); w.columns.name=None
for st in ['H3N2','H1N1']:
    g=w[(w.subtype==st)&(w.category=='contemporary 2022-24 wild-type')].dropna(subset=['d0','d29']).copy()
    g['mrna']=(g.arm=='mRNA-1010').astype(int)
    m=smf.mixedlm('d29 ~ mrna + d0 + C(virus)', g, groups=g['pid']).fit()
    ci=m.conf_int().loc['mrna']
    print(f'Mixed model (participant random intercept, virus fixed effects), contemporary {st}: d29 ratio {2**m.params.mrna:.2f} ({2**ci[0]:.2f}-{2**ci[1]:.2f}), p={m.pvalues.mrna:.3f}, n obs={len(g)}, n participants={g.pid.nunique()}')
    # naive OLS treating virus-participant pairs as independent (to show pseudo-replication)
    o=smf.ols('d29 ~ mrna + d0 + C(virus)', g).fit(); ci=o.conf_int().loc['mrna']
    print(f'   naive OLS ignoring clustering (inappropriate): ratio {2**o.params.mrna:.2f} ({2**ci[0]:.2f}-{2**ci[1]:.2f}), p={o.pvalues.mrna:.2g}')
