"""Figures for the committee. Inputs are outputs of scripts 04-06 (derived from neutralization_seqbased.csv, binding_breadth_h1/h3.csv)."""
import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
A='/tmp/outputs/analysis/'; FIG='/tmp/outputs/figures/'
# Fig 1 binding vs neutralisation
R=pd.read_csv(A+'binding_vs_neut_concordance.csv')
R['st']=np.where(R.strain.isin(['A/Darwin/6/2021','A/Thailand/8/2022','A/Texas/50/2012','A/Hong Kong/2671/2019','A/Singapore/INFIMH-16-0019/2016','A/Cambodia/e0826360/2020']),'H3','H1')
R=R.sort_values(['st','strain'])
fig,ax=plt.subplots(figsize=(9,5.2))
y=np.arange(len(R))
ax.barh(y-0.2, R['bind_diff(mRNA-Flu)'], height=0.4, color='#999999', label='Binding (bead array) log2 fold-rise, mRNA-1010 minus Fluarix')
ax.barh(y+0.2, R['neut_diff(mRNA-Flu)'], height=0.4, color=np.where(R.st=='H3','#c0392b','#2471a3'), label='Neutralisation (seq-based, d29/d0) log2 fold-rise, mRNA-1010 minus Fluarix')
ax.set_yticks(y); ax.set_yticklabels([f"{s} ({t})" for s,t in zip(R.strain,R.st)], fontsize=8)
ax.axvline(0,color='k',lw=0.8); ax.set_xlabel('Between-arm difference in mean log2 fold-rise (positive favours mRNA-1010)')
ax.set_title('Same participants, same strains: H3 binding gains are not matched by neutralisation\n(H3 binding-minus-neutralisation gap: mRNA-1010 2.21 vs Fluarix 0.03 log2, p=0.0001)', fontsize=10)
ax.legend(fontsize=7.5, loc='lower right'); plt.tight_layout(); plt.savefig(FIG+'fig1_binding_vs_neutralisation.png', dpi=160); plt.close()
# Fig 2 seqneut adjusted ratios
T=pd.read_csv(A+'seqneut_subtype_category_tests.csv')
order=['mRNA-1010 strain-matched','Fluarix(2022-23) strain-matched','contemporary 2022-24 wild-type','historical (<=2021) wild-type','historical egg/reassortant']
T['o']=T.category.map({c:i for i,c in enumerate(order)}); T=T.sort_values(['subtype','o'])
fig,axs=plt.subplots(1,2,figsize=(13,4.8),sharey=True)
from matplotlib.ticker import NullFormatter, FixedLocator, FixedFormatter
for ax,(tp,col,lo,hi) in zip(axs,[('Day 29','adj_ratio_d29','lo','hi'),('Day 121/181','adj_ratio_late','lo_late','hi_late')]):
    yy=np.arange(len(T))
    for i,(_,r) in enumerate(T.iterrows()):
        c='#c0392b' if r.subtype=='H3N2' else '#2471a3'
        ax.errorbar([r[col]], [i], xerr=[[r[col]-r[lo]],[r[hi]-r[col]]], fmt='o', color=c, ecolor=c, capsize=3)
    ax.axvline(1,color='grey',ls='--'); ax.set_xscale('log'); ax.set_xlim(0.15,6)
    ax.xaxis.set_major_locator(FixedLocator([0.25,0.5,1,2,4])); ax.xaxis.set_major_formatter(FixedFormatter(['0.25','0.5','1','2','4'])); ax.xaxis.set_minor_formatter(NullFormatter())
    ax.set_title(f'{tp}: baseline-adjusted GMT ratio mRNA-1010/Fluarix', fontsize=9)
    ax.set_yticks(yy); ax.set_yticklabels([f"{s} | {c} ({n} virus{'es' if n>1 else ''})" for s,c,n in zip(T.subtype,T.category,T.n_virus)], fontsize=8)
axs[0].invert_yaxis()
plt.suptitle('Sequencing-based neutralisation, participant-level ANCOVA (13 vs 14 participants); bars = 95% CI', fontsize=10)
plt.tight_layout(rect=(0,0,1,0.95)); plt.savefig(FIG+'fig2_seqneut_ratios_by_category.png', dpi=160, bbox_inches='tight'); plt.close()
# Fig 3 trajectories for contemporary panels
ps=pd.read_csv(A+'seqneut_wide.csv')
g=ps[ps.category=='contemporary 2022-24 wild-type'].groupby(['arm','pid','subtype'])[['d0','d29','late']].mean().reset_index()
fig,axs=plt.subplots(1,2,figsize=(9,4))
for ax,st in zip(axs,['H1N1','H3N2']):
    for arm,c in [('mRNA-1010','#8e44ad'),('Fluarix','#27ae60')]:
        d=g[(g.subtype==st)&(g.arm==arm)]
        m=[2**d[t].mean() for t in ['d0','d29','late']]
        se=[d[t].std()/np.sqrt(d[t].notna().sum()) for t in ['d0','d29','late']]
        ax.errorbar([0,1,2], m, yerr=[[m[i]-2**(np.log2(m[i])-se[i]) for i in range(3)],[2**(np.log2(m[i])+se[i])-m[i] for i in range(3)]], marker='o', color=c, label=f'{arm} (n={len(d)})', capsize=3)
    ax.set_xticks([0,1,2]); ax.set_xticklabels(['Day 0','Day 29','Day 121/181']); ax.set_yscale('log')
    nv=ps[(ps.category=='contemporary 2022-24 wild-type')&(ps.subtype==st)].virus.nunique()
    ax.set_title(f'{st}: contemporary 2022-24 wild-type panel\n(n viruses = {nv}); GMT ± 1 SE', fontsize=9); ax.legend(fontsize=8)
plt.tight_layout(); plt.savefig(FIG+'fig3_contemporary_panel_trajectories.png', dpi=160); plt.close()
print('figures written')
