"""(a) Direction of the neutralisation response: does vaccination shift titres toward the vaccine strain (forward) or toward
previously-encountered strains (backward / imprinting)?  Participant-level paired comparisons.
(b) Which viruses do the unlabelled MN 'homologous'/'heterologous' panels and the HAI 'A/H1N1' antigen behave like?
(c) Cohort membership check: who is missing from the seqneut cohort relative to the HAI/MN cohort?
Sources: neutralization_seqbased.csv (via seqneut_wide.csv), microneutralization.csv (mn_wide.csv), hai_titers.csv (hai_wide.csv)"""
import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width',250)
w=pd.read_csv('/tmp/outputs/analysis/seqneut_wide.csv')
def shift(new, old, label):
    a=w[w.virus==new].set_index(['arm','pid'])[['d0','d29','late']]
    b=w[w.virus==old].set_index(['arm','pid'])[['d0','d29','late']]
    r=(a-b).dropna(subset=['d0','d29']); out=[]
    for arm,g in r.groupby(level=0):
        s=g.d29-g.d0
        out.append(dict(comparison=label, arm=arm, n=len(g), log2_new_over_old_d0=g.d0.mean(), log2_new_over_old_d29=g.d29.mean(),
                        log2_new_over_old_late=g.late.mean(), shift_d29_minus_d0=s.mean(), paired_wilcoxon_p=stats.wilcoxon(s).pvalue))
    x=(r.loc['mRNA-1010'].d29-r.loc['mRNA-1010'].d0); y=(r.loc['Fluarix'].d29-r.loc['Fluarix'].d0)
    for o in out: o['between_arm_MWU_p']=stats.mannwhitneyu(x,y).pvalue
    return out
rows=[]
rows+=shift('A/Wisconsin/67/2022_H1N1','A/Wisconsin/588/2019_H1N1','H1: 5a.2a.1 (mRNA-1010 H1, cell-equivalent) vs 5a.2 (Fluarix-equivalent/prior season)')
rows+=shift('A/Darwin/6/2021_H3N2','A/Cambodia/e0826360/2020_H3N2','H3: Darwin/6/2021 (mRNA-1010 H3) vs Cambodia/2020 (2021-22 vaccine strain)')
R=pd.DataFrame(rows); print(R.round(3).to_string()); R.to_csv('/tmp/outputs/analysis/backward_shift.csv', index=False)
# (b) panel identity
m=pd.read_csv('/tmp/outputs/analysis/mn_wide.csv')
ps=w.groupby(['pid','subtype']).agg(d0=('d0','mean'),d29=('d29','mean')).reset_index()
rows=[]
for panel in ['homologous','heterologous']:
    mm_=m[m.panel==panel][['participant','wk0','wk4']].rename(columns={'participant':'pid'})
    for st in ['H1N1','H3N2']:
        j=ps[ps.subtype==st].merge(mm_,on='pid')
        x=np.concatenate([j.d0,j.d29]); y=np.log2(np.concatenate([j.wk0,j.wk4]))
        rows.append(dict(readout=f'MN {panel}', seqneut_reference=f'mean of all {st} viruses', spearman_levels=stats.spearmanr(x,y)[0], spearman_foldrise=stats.spearmanr(j.d29-j.d0, np.log2(j.wk4/j.wk0))[0], n=len(j)))
h=pd.read_csv('/tmp/outputs/analysis/hai_wide.csv',dtype={'participant':str}); h['pid']='397-'+h.participant
for v in ['A/Victoria/4897/2022_IVR-238_H1N1','A/Wisconsin/588/2019_H1N1','A/Wisconsin/67/2022_H1N1']:
    j=w[w.virus==v].merge(h[h.antigen=='A/H1N1'][['pid','wk0','wk4']],on='pid').dropna(subset=['d0','d29','wk0','wk4'])
    x=np.concatenate([j.d0,j.d29]); y=np.log2(np.concatenate([j.wk0,j.wk4]))
    rows.append(dict(readout='HAI A/H1N1', seqneut_reference=v, spearman_levels=stats.spearmanr(x,y)[0], spearman_foldrise=stats.spearmanr(j.lfc29,np.log2(j.wk4/j.wk0))[0], n=len(j)))
P=pd.DataFrame(rows); print(P.round(2).to_string()); P.to_csv('/tmp/outputs/analysis/panel_identity_inference.csv', index=False)
# (c) cohort membership
mn=set(m.participant); sq=set(w.pid)
print('\nIn MN/HAI cohort but not in seqneut cohort:', sorted(mn-sq))
print(m[m.participant.isin(sorted(mn-sq))][['panel','arm','participant','wk0','wk4','late']].to_string())
# (d) Are the 2023 H1N1 isolates heterologous to the mRNA-1010 H1? Compare with A/Wisconsin/67/2022 (cell equivalent of A/Victoria/4897/2022)
c=w[(w.subtype=='H1N1')&(w.category=='contemporary 2022-24 wild-type')].groupby(['arm','pid'])[['d0','d29']].mean()
a=w[w.virus=='A/Wisconsin/67/2022_H1N1'].set_index(['arm','pid'])[['d0','d29']]
b=w[w.virus=='A/Wisconsin/588/2019_H1N1'].set_index(['arm','pid'])[['d0','d29']]
rows=[]
for arm in ['mRNA-1010','Fluarix']:
    d1=(c.loc[arm]-a.loc[arm]); d2=(c.loc[arm]-b.loc[arm])
    rows.append(dict(arm=arm, log2_2023H1_over_Wisc67_d0=d1.d0.mean(), log2_2023H1_over_Wisc67_d29=d1.d29.mean(), log2_2023H1_over_Wisc588_d0=d2.d0.mean(), log2_2023H1_over_Wisc588_d29=d2.d29.mean()))
D=pd.DataFrame(rows); print('\n(d) 2023 H1N1 isolates vs A/Wisconsin/67/2022 and A/Wisconsin/588/2019 (mean log2 ratio):'); print(D.round(2).to_string())
D.to_csv('/tmp/outputs/analysis/h1_2023_vs_vaccine_equivalents.csv', index=False)
