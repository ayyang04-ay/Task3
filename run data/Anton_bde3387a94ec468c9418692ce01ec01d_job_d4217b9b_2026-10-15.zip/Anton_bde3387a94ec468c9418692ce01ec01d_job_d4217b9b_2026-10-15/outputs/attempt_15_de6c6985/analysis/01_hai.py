"""HAI analysis: GMT, GMFR, seroconversion, seroprotection by arm/antigen; baseline imbalance.
Source: /tmp/world/filesystem/hai_titers.csv"""
import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width',250); pd.set_option('display.max_rows',500); pd.set_option('display.max_columns',50)
df = pd.read_csv('/tmp/world/filesystem/hai_titers.csv', dtype={'participant':str})
# combine wk17 and wk26 as late timepoint (as in trial's wk17/26 convention)
df['tp'] = df.timepoint.replace({'wk17':'late','wk26':'late'})
w = df.pivot_table(index=['antigen','arm','participant'], columns='tp', values='hai_titer').reset_index()
w['fr4'] = w.wk4/w.wk0
w['frlate'] = w.late/w.wk0
# seroconversion: pre<10 & post>=40, or pre>=10 & >=4-fold rise (FDA definition)
def sc(pre, post):
    # Titres such as 28, 57, 113, 226 are rounded geometric means of replicate 2-fold titres
    # (e.g. 56.6 -> 57, 226.3 -> 226), so an exact 4-fold rise can compute as 3.96; use >=3.9.
    if np.isnan(pre) or np.isnan(post): return np.nan
    if pre < 10: return float(post >= 40)
    return float(post/pre >= 3.9)
w['sc4'] = [sc(a,b) for a,b in zip(w.wk0,w.wk4)]
w['sp0'] = (w.wk0>=40).astype(float)
w['sp4'] = (w.wk4>=40).astype(float).where(w.wk4.notna())
w['splate'] = (w.late>=40).astype(float).where(w.late.notna())
gm = lambda x: np.exp(np.nanmean(np.log(x.dropna()))) if x.notna().sum() else np.nan
rows=[]
for (ag,arm),g in w.groupby(['antigen','arm']):
    rows.append(dict(antigen=ag, arm=arm, n=len(g), GMT_wk0=gm(g.wk0), GMT_wk4=gm(g.wk4), GMT_late=gm(g.late), n_late=g.late.notna().sum(),
                     GMFR_wk4=gm(g.fr4), GMFR_late=gm(g.frlate), SCR_wk4=f'{int(g.sc4.sum())}/{g.sc4.notna().sum()}',
                     SP_wk0=f'{int(g.sp0.sum())}/{g.wk0.notna().sum()}', SP_wk4=f'{int(g.sp4.sum())}/{g.sp4.notna().sum()}', SP_late=f'{int(g.splate.sum())}/{g.splate.notna().sum()}'))
res = pd.DataFrame(rows)
print(res.round(1).to_string())
# tests
print('\nBetween-arm tests (Mann-Whitney on log titres / fold rises; Fisher on SCR)')
rows=[]
for ag,g in w.groupby('antigen'):
    a=g[g.arm=='mRNA-1010']; b=g[g.arm=='Fluarix']
    r = dict(antigen=ag)
    for col in ['wk0','wk4','late','fr4']:
        x=np.log2(a[col].dropna()); y=np.log2(b[col].dropna())
        r[f'{col}_log2diff(mRNA-Flu)'] = x.mean()-y.mean()
        r[f'{col}_p'] = stats.mannwhitneyu(x,y).pvalue
    t = [[int(a.sc4.sum()), int(a.sc4.notna().sum()-a.sc4.sum())],[int(b.sc4.sum()), int(b.sc4.notna().sum()-b.sc4.sum())]]
    r['SCR_fisher_p'] = stats.fisher_exact(t).pvalue
    rows.append(r)
print(pd.DataFrame(rows).round(3).to_string())
# ANCOVA: log2 wk4 ~ arm + log2 wk0
import statsmodels.formula.api as smf
print('\nANCOVA log2(wk4) ~ arm + log2(wk0): GMT ratio mRNA/Fluarix adjusted for baseline')
for ag,g in w.groupby('antigen'):
    d = g.dropna(subset=['wk0','wk4']).copy()
    d['l0']=np.log2(d.wk0); d['l4']=np.log2(d.wk4); d['mrna']=(d.arm=='mRNA-1010').astype(int)
    m = smf.ols('l4 ~ mrna + l0', d).fit()
    ci = m.conf_int().loc['mrna']
    print(f'{ag}: adj GMT ratio = {2**m.params.mrna:.2f} (95% CI {2**ci[0]:.2f}-{2**ci[1]:.2f}), p={m.pvalues.mrna:.3f}, n={len(d)}')
w.to_csv('/tmp/outputs/analysis/hai_wide.csv', index=False)
res.to_csv('/tmp/outputs/analysis/hai_summary.csv', index=False)
