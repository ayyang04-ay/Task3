"""Render numbers_provenance.csv as a markdown table with short IDs (used for in-text citations in answer.md)."""
import pandas as pd
L=pd.read_csv('/tmp/outputs/numbers_provenance.csv')
def prefix(i):
    if i.startswith('HAI'): return 'H'
    if i.startswith('MN'): return 'M'
    if i.startswith('ELISA'): return 'E'
    if i.startswith('IgM'): return 'G'
    if i.startswith('BEAD'): return 'B'
    if i.startswith('SEQ') or i.startswith('H1-2023') or i in ('WANE-H1','WANE-H3','EGG','MIXED'): return 'Q'
    if i.startswith('BvN'): return 'V'
    if i.startswith('SHIFT') or i.startswith('IDENT'): return 'R'
    if i.startswith('MAB'): return 'A'
    if i in ('GC-wk2','GC-late','OVERLAP','REP-pre','REP-new','CDRH3'): return 'C'
    if i.startswith('SS'): return 'P'
    if i.startswith('COH'): return 'D'
    if i.startswith('EXT'): return 'X'
    return 'Z'
L['p']=L.id.apply(prefix)
L['short']=L.groupby('p').cumcount()+1
L['short']=L.p+L.short.astype(str)
L[['short','id']].to_csv('/tmp/outputs/analysis/ledger_short_ids.csv', index=False)
order=['D','H','M','E','G','B','Q','V','R','A','C','P','X','Z']
L['o']=L.p.map({k:i for i,k in enumerate(order)})
L=L.sort_values(['o','short'], key=lambda s: s if s.name=='o' else s.str[1:].astype(int) if s.name=='short' else s)
L=L.sort_values(['o']).reset_index(drop=True)
lines=['| ID | Quantity | Value | Source file(s) | Derivation |','|---|---|---|---|---|']
for _,r in L.iterrows():
    q=str(r.quantity).replace('|','/'); v=str(r.value).replace('|','/'); s=str(r.source_files).replace('|','/'); d=str(r.derivation).replace('|','/')
    lines.append(f'| {r.short} | {q} | {v} | {s} | {d} |')
open('/tmp/outputs/analysis/ledger_table.md','w').write('\n'.join(lines)+'\n')
print(L[['short','id','value']].to_string(max_colwidth=110))
