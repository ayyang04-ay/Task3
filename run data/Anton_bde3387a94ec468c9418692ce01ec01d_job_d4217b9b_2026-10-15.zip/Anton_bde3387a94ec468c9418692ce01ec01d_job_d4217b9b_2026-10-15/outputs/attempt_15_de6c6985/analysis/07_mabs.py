"""Monoclonal antibody binding panels: per-donor breadth with donor as the unit; sensitivity to positivity threshold.
Source: /tmp/world/filesystem/mab_binding_panels.csv (fold_over_control normalised to SARS-CoV-2 RBD = 1 for every mAb)"""
import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width',250); pd.set_option('display.max_rows',500); pd.set_option('display.max_columns',60)
df = pd.read_csv('/tmp/world/filesystem/mab_binding_panels.csv')
df['donor']=df.mab_id.str.split('.').str[1]
df=df[df.antigen!='SARS-CoV-2 RBD']
W = df.pivot_table(index=['panel','arm','donor','mab_id'], columns='antigen', values='fold_over_control').reset_index()
W.columns.name=None
g1=['A/Puerto Rico/8/1934','A/New Caledonia/20/1999','A/California/04/2009','A/Wisconsin/588/2019','A/Victoria/4897/2022','A/Netherlands/01317/2025','A/Hubei/1/2010 (H5)']
g2=['A/Hong Kong/1/1968','A/Fujian/411/2002','A/Texas/50/2012','A/Darwin/6/2021','A/Thailand/8/2022','A/Croatia/10136RV/2023','A/Shanghai/1/2013 (H7)']
out=[]
for thr in [5,10]:
    for panel,ags,vac_m,vac_f,fwd,xsub in [('group_I',g1,'A/Victoria/4897/2022','A/Wisconsin/588/2019',['A/Netherlands/01317/2025'],'A/Hubei/1/2010 (H5)'),
                                             ('group_II',g2,'A/Darwin/6/2021',None,['A/Thailand/8/2022','A/Croatia/10136RV/2023'],'A/Shanghai/1/2013 (H7)')]:
        P=W[W.panel==panel].copy()
        pos=P[ags]>thr
        P['n_strains_bound']=pos.drop(columns=[xsub]).sum(axis=1)
        P['binds_mRNA_vaccine_strain']=pos[vac_m]
        P['binds_all_intrasubtype']=pos.drop(columns=[xsub]).all(axis=1)
        P['binds_forward']=pos[fwd].all(axis=1)
        P['binds_cross_subtype']=pos[xsub]
        P['binds_oldest']=pos[ags[0]]
        for (arm,donor),g in P.groupby(['arm','donor']):
            out.append(dict(thr=thr, panel=panel, arm=arm, donor=donor, n_mabs=len(g), pct_bind_mRNA_vacc=100*g.binds_mRNA_vaccine_strain.mean(),
              pct_bind_forward=100*g.binds_forward.mean(), pct_bind_all_intrasubtype=100*g.binds_all_intrasubtype.mean(),
              pct_cross_subtype=100*g.binds_cross_subtype.mean(), pct_bind_oldest=100*g.binds_oldest.mean(), mean_n_strains=g.n_strains_bound.mean()))
O=pd.DataFrame(out)
print(O.round(1).to_string())
O.to_csv('/tmp/outputs/analysis/mab_breadth_by_donor.csv', index=False)
print('\nDonor-level comparison (donor = unit; n donors mRNA 4 vs Fluarix 3), threshold 10x:')
for panel in ['group_I','group_II']:
    S=O[(O.thr==10)&(O.panel==panel)]
    for col in ['pct_bind_forward','pct_bind_all_intrasubtype','pct_cross_subtype','pct_bind_oldest','mean_n_strains']:
        x=S[S.arm=='mRNA-1010'][col]; y=S[S.arm=='Fluarix'][col]
        p=stats.mannwhitneyu(x,y).pvalue if len(x)>1 and len(y)>1 else np.nan
        print(panel, col, f'mRNA donors {list(x.round(1))} vs Fluarix donors {list(y.round(1))}, MWU p={p:.3f}')
# pooled (mAb as unit) - to show how pooling would mislead
print('\nPooled (mAb as unit, NOT appropriate) for comparison, thr 10:')
for panel,ags,fwd in [('group_I',g1,['A/Netherlands/01317/2025']),('group_II',g2,['A/Thailand/8/2022','A/Croatia/10136RV/2023'])]:
    P=W[W.panel==panel]
    for arm,g in P.groupby('arm'):
        print(panel, arm, len(g), 'forward-binding %:', round(100*(g[fwd]>10).all(axis=1).mean(),1))
# Control antigen and H1 'older-strain' preference (ledger A16, A17)
raw = pd.read_csv('/tmp/world/filesystem/mab_binding_panels.csv'); raw['donor']=raw.mab_id.str.split('.').str[1]
rbd = raw[raw.antigen=='SARS-CoV-2 RBD'].fold_over_control
print('\nSARS-CoV-2 RBD control: n =', len(rbd), ' unique values =', sorted(rbd.unique()))
G1 = raw[raw.panel=='group_I'].pivot_table(index=['arm','donor','mab_id'], columns='antigen', values='fold_over_control').reset_index()
G1['ratio_vic_over_wisc'] = G1['A/Victoria/4897/2022']/G1['A/Wisconsin/588/2019']
out = G1.groupby(['arm','donor']).agg(n=('mab_id','count'), median_ratio_Vic4897_over_Wisc588=('ratio_vic_over_wisc','median'),
        n_bind_Vic_not_Wisc=('mab_id', lambda x: int(((G1.loc[x.index,'A/Victoria/4897/2022']>10)&(G1.loc[x.index,'A/Wisconsin/588/2019']<=10)).sum())))
print(out.round(3).to_string()); out.to_csv('/tmp/outputs/analysis/mab_h1_vic_vs_wisc.csv')
