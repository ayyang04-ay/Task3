"""Microneutralisation analysis (homologous/heterologous panels, as labelled relative to mRNA-1010 antigens).
Source: /tmp/world/filesystem/microneutralization.csv"""
import pandas as pd, numpy as np
from scipy import stats
import statsmodels.formula.api as smf
pd.set_option('display.width',250); pd.set_option('display.max_rows',500); pd.set_option('display.max_columns',50)
df = pd.read_csv('/tmp/world/filesystem/microneutralization.csv')
t = df[df.measure=='titer'].copy()
t['tp'] = t.timepoint.replace({'wk17':'late','wk26':'late'})
w = t.pivot_table(index=['panel','arm','participant'], columns='tp', values='value').reset_index()
w.columns.name=None
print('Unique titre values:', sorted(t.value.unique()))
ULOQ = t.value.max(); LLOQ = t.value.min()
print('max titre', ULOQ, 'min', LLOQ)
gm = lambda x: np.exp(np.mean(np.log(x.dropna())))
rows=[]
for (p,arm),g in w.groupby(['panel','arm']):
    rows.append(dict(panel=p, arm=arm, n=len(g), GMT_wk0=gm(g.wk0), GMT_wk4=gm(g.wk4), GMT_late=gm(g.late), n_late=g.late.notna().sum(),
      GMFR_wk4=gm(g.wk4/g.wk0), GMFR_late=gm((g.late/g.wk0).dropna()),
      n_at_ceiling_wk0=int((g.wk0>=ULOQ).sum()), n_at_ceiling_wk4=int((g.wk4>=ULOQ).sum()), n_at_floor_wk4=int((g.wk4<=LLOQ).sum()),
      n_4fold_wk4=int(((g.wk4/g.wk0)>=4).sum()),
      n_4fold_late=int(((g.late/g.wk0)>=4).sum())))
res=pd.DataFrame(rows); print(res.round(1).to_string())
res.to_csv('/tmp/outputs/analysis/mn_summary.csv', index=False)
# check provided fold_change vs recomputed
fc = df[df.measure=='fold_change'].pivot_table(index=['panel','arm','participant'], columns='timepoint', values='value').reset_index()
fc.columns.name=None
fc = fc.rename(columns={'wk4':'fc4_file','wk17/26':'fclate_file'})
m = w.merge(fc, on=['panel','arm','participant'])
m['fc4_calc'] = m.wk4/m.wk0
m['fclate_calc'] = m.late/m.wk0
m['ok4'] = np.isclose(m.fc4_calc, m.fc4_file, rtol=0.02)
m['oklate'] = np.isclose(m.fclate_calc, m.fclate_file, rtol=0.02)
print('\nFold-change consistency check (file vs recomputed from titres):')
print(m[~(m.ok4 & m.oklate)][['panel','arm','participant','wk0','wk4','late','fc4_file','fc4_calc','fclate_file','fclate_calc']].to_string())
print('n mismatches wk4:', (~m.ok4).sum(), ' late:', (~m.oklate).sum(), ' of', len(m))
# between-arm comparisons
print('\nBetween-arm (mRNA minus Fluarix), log2 scale; MWU p')
for p,g in w.groupby('panel'):
    a=g[g.arm=='mRNA-1010']; b=g[g.arm=='Fluarix']
    for col in ['wk0','wk4','late']:
        x=np.log2(a[col].dropna()); y=np.log2(b[col].dropna())
        print(p, col, f'diff={x.mean()-y.mean():.2f} log2 (ratio {2**(x.mean()-y.mean()):.2f}), p={stats.mannwhitneyu(x,y).pvalue:.3f}')
    d=g.copy(); d['l0']=np.log2(d.wk0); d['l4']=np.log2(d.wk4); d['mrna']=(d.arm=='mRNA-1010').astype(int)
    mm_=smf.ols('l4 ~ mrna + l0', d).fit(); ci=mm_.conf_int().loc['mrna']
    print(p, f'ANCOVA adj GMT ratio wk4 mRNA/Flu = {2**mm_.params.mrna:.2f} ({2**ci[0]:.2f}-{2**ci[1]:.2f}) p={mm_.pvalues.mrna:.3f}')
    # excluding anyone at ceiling at baseline
    d2=d[d.wk0<ULOQ]
    mm2=smf.ols('l4 ~ mrna + l0', d2).fit(); ci=mm2.conf_int().loc['mrna']
    print(p, f'  excl. baseline-at-ceiling (n={len(d2)}): adj ratio {2**mm2.params.mrna:.2f} ({2**ci[0]:.2f}-{2**ci[1]:.2f}) p={mm2.pvalues.mrna:.3f}')
w.to_csv('/tmp/outputs/analysis/mn_wide.csv', index=False)
