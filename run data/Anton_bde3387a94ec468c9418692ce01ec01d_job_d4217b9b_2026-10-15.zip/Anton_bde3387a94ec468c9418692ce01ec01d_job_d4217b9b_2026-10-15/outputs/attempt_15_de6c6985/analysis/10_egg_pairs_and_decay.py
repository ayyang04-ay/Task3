"""(a) Egg/reassortant vs wild-type pairs: does the panel's inclusion of egg-adapted viruses change conclusions?
(b) Waning: d29 -> late (d121/d181) decline by arm and subtype (participant-level).
Source: seqneut (via seqneut_wide.csv)"""
import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width',250)
w = pd.read_csv('/tmp/outputs/analysis/seqneut_wide.csv')
pairs=[('A/Texas/50/2012_H3N2','A/Texas/50/2012X-223A_H3N2'),('A/Switzerland/9715293/2013_H3N2','A/Switzerland/9715293/2013NIB-88_H3N2'),
       ('A/HongKong/4801/2014_H3N2','A/HongKong/4801/2014egg_H3N2'),('A/Singapore/INFIMH-16-0019/2016_H3N2','A/Singapore/INFIMH-16-0019/2016X-307A_H3N2'),
       ('A/Cambodia/e0826360/2020_H3N2','A/Cambodia/e0826360/2020egg_H3N2'),('A/Wisconsin/67/2022_H1N1','A/Victoria/4897/2022_IVR-238_H1N1')]
rows=[]
for wt,egg in pairs:
    a=w[w.virus==wt].set_index(['arm','pid']); b=w[w.virus==egg].set_index(['arm','pid'])
    j=a[['d0','d29','lfc29']].join(b[['d0','d29','lfc29']], lsuffix='_wt', rsuffix='_egg').dropna()
    for arm,g in j.groupby(level=0):
        rows.append(dict(pair=wt.split('_')[0]+' vs egg/reassortant', arm=arm, n=len(g), GMT29_wt=2**g.d29_wt.mean(), GMT29_egg=2**g.d29_egg.mean(),
          egg_over_wt_d29=2**(g.d29_egg-g.d29_wt).mean(), GMFR_wt=2**g.lfc29_wt.mean(), GMFR_egg=2**g.lfc29_egg.mean()))
print(pd.DataFrame(rows).round(2).to_string())
print('\nNote: egg/reassortant titres are systematically higher (often at ULOQ 17300), compressing fold-rise.')
print('ULOQ-censored (lower-bound) results by virus category:')
df = pd.read_csv('/tmp/world/filesystem/neutralization_seqbased.csv')
print(df[df.titer_bound=='lower'].virus.value_counts().to_string())
print('LOD-censored (upper-bound) results count by arm:')
df['arm']=df.serum.str.split('_').str[0]
print(df[df.titer_bound=='upper'].groupby('arm').size())
# (b) waning
ps = w.dropna(subset=['late']).groupby(['arm','pid','subtype']).agg(l29=('d29','mean'), ll=('late','mean')).reset_index()
ps['decline']=ps.l29-ps.ll
print('\nWaning d29 -> late (log2 units; fold = 2^x), participant-level:')
for st,g in ps.groupby('subtype'):
    x=g[g.arm=='mRNA-1010'].decline; y=g[g.arm=='Fluarix'].decline
    print(st, f'mRNA mean decline {x.mean():.2f} log2 ({2**x.mean():.2f}-fold, n={len(x)}) vs Fluarix {y.mean():.2f} log2 ({2**y.mean():.2f}-fold, n={len(y)}); MWU p={stats.mannwhitneyu(x,y).pvalue:.4f}')
