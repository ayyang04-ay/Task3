"""Sequencing-based neutralisation analysis.
Source: /tmp/world/filesystem/neutralization_seqbased.csv
Unit of analysis = participant. Viruses grouped a priori by relationship to each arm's vaccine strains."""
import pandas as pd, numpy as np, re
from scipy import stats
import statsmodels.formula.api as smf
pd.set_option('display.width',250); pd.set_option('display.max_rows',500); pd.set_option('display.max_columns',60)
df = pd.read_csv('/tmp/world/filesystem/neutralization_seqbased.csv')
df['arm']=df.serum.str.split('_').str[0]
df['pid']=df.serum.str.split('_').str[1]
df['day']=df.serum.str.split('_').str[2]
df['subtype']=df.virus.str.extract(r'_(H\dN\d)$')[0]
def year(v):
    m = re.search(r'/(\d{4,6})(?:[A-Za-z_-]|$)', v.split('_')[0] if '_IVR' not in v else v)
    y = re.findall(r'/(\d+)', v)
    return int(y[-1][:4]) if y else None
df['year']=df.virus.apply(year)
# Data-quality fix: 'A/SOUTHAFRICA/R07876/202023_H3N2' has a malformed year ('202023'); the parser would read 2020.
# Its neighbours in the panel are 2023 South African isolates, so it is treated as a 2023 isolate (flagged in answer.md).
df.loc[df.virus=='A/SOUTHAFRICA/R07876/202023_H3N2','year']=2023
df['egg_or_reassortant']=df.virus.str.contains(r'egg|X-\d|NIB-|IVR-', regex=True)
# a-priori categories
mrna_match = {'A/Wisconsin/67/2022_H1N1','A/Victoria/4897/2022_IVR-238_H1N1','A/Darwin/6/2021_H3N2'}
flu_match  = {'A/Wisconsin/588/2019_H1N1','A/Darwin/9/2021_H3N2'}
def cat(r):
    v=r.virus
    if v in mrna_match: return 'mRNA-1010 strain-matched'
    if v in flu_match: return 'Fluarix(2022-23) strain-matched'
    if r.egg_or_reassortant: return 'historical egg/reassortant'
    if r.year<=2021: return 'historical (<=2021) wild-type'
    return 'contemporary 2022-24 wild-type'
df['category']=df.apply(cat, axis=1)
vc = df[['virus','subtype','year','category']].drop_duplicates().sort_values(['category','subtype','year'])
print(vc.groupby(['category','subtype']).size())
vc.to_csv('/tmp/outputs/analysis/seqneut_virus_categories.csv', index=False)
# censoring: use reported value (upper-bound values at LOD=40 treated as 40; lower-bound at ULOQ as reported) and flag
df['ltiter']=np.log2(df.titer)
df['tp']=df.day.replace({'d121':'late','d181':'late'})
w = df.pivot_table(index=['arm','pid','virus','subtype','category'], columns='tp', values='ltiter').reset_index(); w.columns.name=None
w['lfc29']=w.d29-w.d0
w['lfclate']=w.late-w.d0
w['rise4']=(w.lfc29>=2).astype(float).where(w.lfc29.notna())
cens = df.pivot_table(index=['arm','pid','virus'], columns='tp', values='titer_bound', aggfunc='first').reset_index(); cens.columns.name=None
w = w.merge(cens.rename(columns={'d0':'b0','d29':'b29','late':'blate'}), on=['arm','pid','virus'])
w.to_csv('/tmp/outputs/analysis/seqneut_wide.csv', index=False)
# participant-level summaries per category
ps = w.groupby(['arm','pid','category']).agg(mean_l0=('d0','mean'), mean_l29=('d29','mean'), mean_llate=('late','mean'),
        mean_lfc29=('lfc29','mean'), mean_lfclate=('lfclate','mean'), frac_rise4=('rise4','mean'), nvir=('virus','nunique')).reset_index()
ps.to_csv('/tmp/outputs/analysis/seqneut_participant_category.csv', index=False)
print('\nParticipant-level (unit = participant) category means; GMT = 2^mean(log2); GMFR; fraction of strains with >=4-fold rise at d29')
rows=[]
for (c,arm),g in ps.groupby(['category','arm']):
    rows.append(dict(category=c, arm=arm, n=len(g), GMT_d0=2**g.mean_l0.mean(), GMT_d29=2**g.mean_l29.mean(), GMT_late=2**g.mean_llate.mean(),
                     GMFR_d29=2**g.mean_lfc29.mean(), GMFR_late=2**g.mean_lfclate.mean(), mean_frac_4x=g.frac_rise4.mean()))
R=pd.DataFrame(rows); print(R.round(2).to_string())
R.to_csv('/tmp/outputs/analysis/seqneut_category_summary.csv', index=False)
print('\nBetween-arm tests on participant-level means (MWU) and ANCOVA (d29 ~ arm + d0)')
rows=[]
for c,g in ps.groupby('category'):
    a=g[g.arm=='mRNA-1010']; b=g[g.arm=='Fluarix']
    r=dict(category=c)
    for col,lab in [('mean_l0','d0'),('mean_l29','d29'),('mean_llate','late'),('mean_lfc29','FR29'),('mean_lfclate','FRlate'),('frac_rise4','frac4x')]:
        x=a[col].dropna(); y=b[col].dropna()
        r[f'{lab}_diff']= x.mean()-y.mean(); r[f'{lab}_p']=stats.mannwhitneyu(x,y).pvalue
    d=g.copy(); d['mrna']=(d.arm=='mRNA-1010').astype(int)
    m=smf.ols('mean_l29 ~ mrna + mean_l0', d).fit(); ci=m.conf_int().loc['mrna']
    r['ANCOVA_d29_ratio']=2**m.params.mrna; r['ci_lo']=2**ci[0]; r['ci_hi']=2**ci[1]; r['ANCOVA_p']=m.pvalues.mrna
    d2=d.dropna(subset=['mean_llate'])
    m=smf.ols('mean_llate ~ mrna + mean_l0', d2).fit(); ci=m.conf_int().loc['mrna']
    r['ANCOVA_late_ratio']=2**m.params.mrna; r['late_ci_lo']=2**ci[0]; r['late_ci_hi']=2**ci[1]; r['ANCOVA_late_p']=m.pvalues.mrna
    rows.append(r)
T=pd.DataFrame(rows); print(T.round(3).T.to_string())
T.to_csv('/tmp/outputs/analysis/seqneut_category_tests.csv', index=False)
# Censoring counts (ledger Q25)
print('\nCensoring (titer_bound):', df.titer_bound.value_counts().to_dict(), ' total', len(df))
print('Upper-bound (below LOD) value range:', df[df.titer_bound=="upper"].titer.min(), '-', df[df.titer_bound=="upper"].titer.max(),
      '; lower-bound (above ULOQ) value range:', df[df.titer_bound=="lower"].titer.min(), '-', df[df.titer_bound=="lower"].titer.max())
