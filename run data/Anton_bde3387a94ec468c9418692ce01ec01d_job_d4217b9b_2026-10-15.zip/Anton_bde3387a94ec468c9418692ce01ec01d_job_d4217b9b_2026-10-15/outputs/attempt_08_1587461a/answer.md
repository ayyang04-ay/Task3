**Recommendation: do not take a heterologous-protection claim into a confirmatory trial on WU397 — next run a randomised, observer-blind, strain-matched trivalent Phase 2 with a day-29 forward-drift H3N2 neutralisation co-primary as a go/no-go gate, and only if it passes a heterologous challenge study plus a multi-season, event-driven rVE trial powered on antigenically mismatched cases, because WU397's only strain-matched influenza A comparison (H3N2) shows no forward-drift neutralisation advantage (1.16×, 95% CI 0.64–2.11) and its H1 advantage is confounded by strain choice and no longer detectable by day 121–181.**

---

## 1. Summary for the committee

**What WU397 supports**
- **More binding antibody than Fluarix.** Baseline-adjusted wk4 IgG ratios (mRNA-1010/Fluarix) are 3.31× for H3 and 2.66× for H1 (n=38/37).
- **Larger, longer-lasting lymph-node germinal-centre (GC) responses.** Peak HA-specific GC B cells: median 24.7% vs 4.7% (n=6/11; p=0.001).

These are real mechanistic signals, but neither is a measure of protection or of functional breadth.

**What WU397 does not support**
1. **Functional breadth on H3N2.** H3N2 is the subtype where drift and vaccine mismatch matter most, and it is the only influenza A subtype where both vaccines carried the same antigen (Darwin/2021-like). On H3N2, mRNA-1010 gave:
   - 1.16× (0.64–2.11) neutralisation of 68 drifted 2022–2024 viruses;
   - 0.71× (0.36–1.38) against the vaccine strain itself.
   
   Its only H3 advantage is against *historical* strains (2012–14 isolates 1.84×, 1.10–3.08). That is back-boosting, not forward breadth. (The B strains were also matched, but neither arm mounted a meaningful B HAI response.)
2. **A platform-driven H1 advantage.** mRNA-1010 gives about 2× neutralisation of six 2023 H1N1 viruses (2.06×, 1.23–3.46), but:
   - It is a uniform magnitude shift, not extra breadth: the 2023-strain ÷ vaccine-strain titre ratio is 0.48 in both arms.
   - mRNA-1010 carried a newer H1 (A/Victoria/4897/2022) than 2022–23 Fluarix (A/Victoria/2570/2019-like), so strain choice and platform are confounded.
   - By day 121/181 it has shrunk to 1.17× (0.77–1.77).
3. **Protection.** The study had no clinical endpoint and no infection surveillance, and I found no serological sign of infection during follow-up.
4. **Any HAI difference.** HAI rises were small in both arms (H3N2 seroconversion 2/14 vs 3/15), no between-arm HAI difference is significant, and the B/Vic HAI data fail QC.

**Why WU397 cannot answer the question**
- Allocation was non-randomised (by site) and the study was open-label.
- The H1 antigens differ between arms, and the antigens are egg-derived (Fluarix) vs wild-type (mRNA).
- "Homologous/heterologous" labels are defined only relative to mRNA-1010.
- Functional assays have n=13–15 per arm; wk17 and wk26 are pooled.
- B/Yamagata is an obsolete component.
- There are data-integrity defects (§3.7).

**Next studies**

| # | Study | Question it settles | Role |
|---|---|---|---|
| 0 | WU397 data remediation and pre-specified re-analysis (no new subjects) | Are the WU397 signals real and correctly labelled? | Before protocol lock |
| 1 | Phase 2: randomised, observer-blind, strain-matched, trivalent; 18–64 and ≥65 | With strain choice equalised, does mRNA give superior forward-drift neutralisation (H3N2 first) without losing homologous HAI? | **Go/no-go** for 2 and 3 |
| 1b | Year-2 re-randomised revaccination extension of Study 1 | Does any advantage survive annual revaccination? | Informs Phase 3 design |
| 2 | Heterologous controlled human infection study (CHIM) | Does the vaccine protect against a mismatched strain, and which pre-challenge readout tracks that protection? | Proof of concept; correlate discovery |
| 3 | Phase 3 event-driven rVE trial over ≥2 seasons, with a mismatched-strain key endpoint and a correlates sub-study | The claim itself | Pivotal |

---

## 2. What the claim requires

The claim needs to be written down in the protocol. A workable version: *"superior protection against RT-PCR-confirmed influenza caused by viruses antigenically distinct from the vaccine strains, versus a licensed comparator."*

Three consequences follow:
- **No validated correlate exists for it.** The only accepted immune marker, HAI ≈1:40 (≈50% protection), is strain-specific. No validated correlate exists for protection against drifted strains, so immunogenicity can at most support a "broader neutralising response" claim. "Protection" needs a clinical endpoint with strain-level characterisation of every case, or a correlate derived from one (Studies 2–3).
- **Platform must be separated from strain choice.** If the arms carry different strains, any heterologous difference can't be credited to the product. WU397 did not match strains (§3.1).
- **"Heterologous" must be defined symmetrically and forward.** It has to be defined relative to *each* arm's own vaccine strain, and mean *forward* drift: viruses that circulate after strain selection. Older strains don't count, because back-boosting makes historical-strain readouts flatter the vaccine (§3.3).

---

## 3. What the WU397 data show

All analyses are in `/tmp/outputs/analysis/` and are reproducible with `run_all.sh`.
- Between-arm ratios are ANCOVA-adjusted for baseline (log titre ~ arm + log baseline) unless stated.
- Per-number provenance is in §6 and in `numbers_ledger.csv` (130 rows).

### 3.1 Design facts that limit interpretation

| Issue | Evidence | Consequence |
|---|---|---|
| H1 antigen differs between arms | mRNA-1010: A/Victoria/4897/2022 (trial_summary.md). Fluarix 2022–23: A/Victoria/2570/2019-like (WHO egg-based recommendation for 2022–23; external, §7). | Any "homologous H1" readout is homologous for mRNA-1010 but drifted for Fluarix. The H1 advantage can't be attributed to the platform. |
| Labels are one-sided | The summary says panel designations "refer to the mRNA-1010 antigens". | A "heterologous" virus for mRNA-1010 can be near-homologous for Fluarix, e.g. A/Wisconsin/588/2019 (the cell counterpart of Fluarix's H1). |
| Egg-derived vs wild-type antigen | Fluarix's H3 is egg-based Darwin/9/2021; mRNA-1010 uses Darwin/6/2021. Panels mix egg reassortants with wild-type viruses. | This biases readouts measurably (§3.5). |
| Non-randomised, open-label, by site | trial_summary.md. IDs suggest sequential enrolment: Fluarix 033–059, then mRNA 064–102 (elisa_igg_titers.csv). | Confounded by site, population and calendar. No demographics or vaccination dates are in the package, so balance can't be checked. Baseline heterologous MN was already 0.47× in the mRNA arm (0.22–1.00, p=0.05). |
| Small functional cohorts, convenience subsets | HAI/MN 14/15; seq-neut 13/14; FNA 6/11; mAbs 4 vs 3 donors. All functional sub-cohorts are the earliest enrollees (IDs ≤032). | Wide CIs. Selection by consent and sample availability. |
| B/Yamagata component | B/Phuket/3073/2013 is in both vaccines. | B/Yamagata has had no confirmed circulation since 2020 and has been dropped from recommended compositions (§7). B/Yam readouts are irrelevant going forward. |
| Late visits pooled | wk17 (d121) and wk26 (d181) are pooled as "wk17/26". | For two participants (F-007, F-011), seq-neut used d121 while HAI/MN/ELISA used wk26. Durability is blurred. |
| No infection surveillance | No illness data. No participant shows ≥4-fold seq-neut rises between d29 and d121/181 on ≥25% of viruses (`10_…py`). | No protection information at all. |

### 3.2 Binding antibody: a large advantage that, for H3, is mostly non-neutralising

ELISA IgG, n=38 mRNA / 37 Fluarix (`04_elisa.py`):

| Antigen | wk4 ratio | wk17/26 ratio | ≥4-fold rises (mRNA vs Fluarix) |
|---|---|---|---|
| H1 | 2.66× (2.01–3.53) | 1.51× (1.19–1.91) | 22/38 vs 3/37 |
| H3 | 3.31× (2.47–4.43) | 2.06× (1.57–2.70) | 27/38 vs 5/37 |
| B/Vic | 1.35× (1.04–1.75) | 0.99× (0.78–1.26) | — |
| B/Yam | 1.38× (1.11–1.71) | 1.06× (0.88–1.29) | — |

- **The mRNA response decays faster.** Titre at wk17/26 ÷ wk4 for H1 is 0.42 (mRNA) vs 0.74 (Fluarix); for H3 it is 0.46 vs 0.76.
- **Bead-array breadth** (`05_…py`). Mean fold-rise in MFI, mRNA vs Fluarix:
  - H3 A/Hong Kong/1/1968: 10.9× vs 1.15×.
  - H3 A/Thailand/8/2022: 31.9× vs 3.4×.
  - H1 A/Puerto Rico/8/1934: 2.9× vs 1.08×.
  - All 12 H3 strains have Holm-adjusted p≤0.0013.
  
  Binding to strains from 1934 and 1968 implies conserved (likely stem-type) epitopes.
- **Binding without neutralisation** (`14_…py`; same participants). The binding fold-rise ÷ neutralisation fold-rise was compared by arm:
  - H3: 2.45–2.86 for mRNA vs 0.63–1.01 for Fluarix (p<0.001).
  - H1: 1.21–1.32 vs 1.02–1.06 (p=0.16–0.49).
  
  The H3 binding signal therefore is not neutralising antibody. Binding breadth cannot stand in for heterologous protection. At most it motivates Fc-effector and stem readouts as exploratory endpoints.

### 3.3 Functional antibody, by subtype

**Sequencing-based neutralisation** (96 viruses, n=13 mRNA / 14 Fluarix; `06_…py`, `12_…py`). Viruses are classified relative to each arm's own vaccine strain.

| Virus category (n viruses) | GMFR d29 mRNA / Fluarix | d29 ratio (95% CI) | d121/181 ratio (95% CI) |
|---|---|---|---|
| H3 vaccine strains, Darwin/6 and /9 (2) | 3.27 / 3.51 | **0.71 (0.36–1.38)** | 0.63 (0.33–1.20) |
| H3 forward-drift, 2022–2024 (68) | 2.80 / 2.17 | **1.16 (0.64–2.11), p=0.60** | 1.04 (0.65–1.67) |
| H3 historical, 2012–2020 (13) | 3.13 / 1.69 | 1.60 (1.03–2.49) | 1.41 (0.88–2.26) |
| H1 mRNA-1010 strain (Wisconsin/67/2022, Victoria/4897/2022 IVR-238) (2) | 3.73 / 2.03 | 1.84 (1.17–2.90) | 1.15 (0.76–1.72) |
| H1 Fluarix strain, cell analogue (Wisconsin/588/2019) (1) | 6.15 / 2.34 | 2.44 (1.18–5.05) | 1.17 (0.62–2.23) |
| H1 contemporary, 2023 (6) | 4.07 / 1.95 | **2.06 (1.23–3.46)** | 1.17 (0.77–1.77) |

**H3N2, the strain-matched comparison: no forward advantage.**
- Per virus, 53 of 68 forward-drift ratios exceed 1 (median 1.15, IQR 1.02–1.23). None is nominally significant.
- Absolute d29 forward-drift GMTs are 401 (mRNA) vs 465 (Fluarix). The unadjusted ratio is 0.86 (0.44–1.68).
- By isolation year (`fig2_h3_breadth_by_year.png`):

| Isolation years | d29 ratio (95% CI) |
|---|---|
| 2012–14 | 1.84 (1.10–3.08) |
| 2016–17 | 1.50 |
| 2019–20 | 1.58 |
| 2021 (vaccine strains) | 0.71 |
| 2022 | 1.03 |
| 2023 (61 viruses) | 1.18 (0.66–2.12) |
| 2024 | 0.98 |

The advantage points backward.

**Microneutralisation agrees independently** (`03_mn.py`). The package doesn't say which viruses the MN panels used. By correlation with the seq-neut panel, both panels behave as H3N2 readouts:
- "homologous" best matches Darwin/9/2021 (titre ρ=0.73);
- "heterologous" best matches 2023 H3N2 viruses.

This needs confirming from lab records (`17_…py`). The MN results are:

| MN panel | wk4 ratio (95% CI) | Notes |
|---|---|---|
| "Homologous" | 0.68 (0.31–1.51) | 9/15 Fluarix vs 4/14 mRNA sera hit the 1280 ceiling at wk4, so Fluarix is if anything under-estimated. |
| "Heterologous" | 1.17 (0.52–2.62) | The raw ≥4-fold rates (9/14 vs 6/15) are inflated by the mRNA arm's lower baseline. |

**H1N1: magnitude, not breadth, and confounded.**
- All six 2023 H1 viruses show ratios of 1.93–2.29.
- Relative breadth is identical in the two arms: 2023 ÷ vaccine-strain d29 titre ratio is 0.48 vs 0.48 (`13_…py`).
- H1 neutralisation wanes faster after mRNA-1010: GM late/d29 is 0.49 vs 0.82 (`10_…py`).

**HAI** (n=14/15; `02_hai.py`):

| Subtype | Arm | GMFR | Seroconversion | Ratio (95% CI) |
|---|---|---|---|---|
| H1N1 | mRNA | 2.76 | 7/14 | 1.54 (0.87–2.71) |
| H1N1 | Fluarix | 2.25 | 5/15 | |
| H3N2 | mRNA | 1.72 | 2/14 | 1.06 (0.67–1.65) |
| H3N2 | Fluarix | 1.66 | 3/15 | |
| B/Vic | mRNA | 1.08 | 0/13 | QC fail |
| B/Vic | Fluarix | 1.05 | 1/15 | QC fail |
| B/Yam | mRNA | 1.35 | 0/14 | 1.01 (0.73–1.40) |
| B/Yam | Fluarix | 1.29 | 1/15 | |

- No seroconversion lower 95% bound reaches 40% in either arm (the best is 27%, mRNA H1).
- Non-inferiority on seroconversion is not estimable at this n. The upper bounds of Fluarix−mRNA are 17–33 points against a 10-point margin.

### 3.4 Durability

- By d121–181 no functional readout differs between arms. All late ratios have CIs spanning 1: HAI 0.83–1.06, MN 0.64–0.73, seq-neut 0.63–1.41.
- The binding advantage shrinks by then, to 1.51× (H1) and 2.06× (H3).
- Heterologous protection matters most late in the season, when drifted clades tend to take over. Durability must therefore be a key endpoint, at fixed visits, not pooled.

### 3.5 Egg adaptation biases the readout panels

Five H3 wild-type/egg-reassortant pairs were compared (`07_…py`):
- **Baseline:** sera neutralise the egg-adapted versions 1.4–10.9× better.
- **mRNA-1010:** fold-rises against egg reassortants are 0.60× those against the matching wild-type viruses (p<0.001).
- **Fluarix:** 0.90× (p=0.23).
- **Between arms:** p=0.005.

Egg-adapted readout viruses therefore systematically under-read mRNA responses relative to egg-based vaccine responses. This is why every comparative readout must use wild-type viruses.

### 3.6 Cellular and monoclonal data: mechanism, not protection

- **GC responses** (`08_…py`, GC file block A). The HA-specific GC response is larger and persists to wk17/26: median 24.9% vs 2.3% (n=5/9; p=0.004). Block B shows the same direction.
- **The mRNA GCs mostly recycle pre-existing memory.** 73–92% of GC clones in each mRNA donor are clonally related to wk1 plasmablasts. That fits the backward-directed serum breadth in §3.3.
- **More serum clonotypes and CDRH3 diversity after mRNA-1010** (n=8/arm, no participant IDs):
  - wk4 serum clonotypes 97.5 vs 76.0 (p=0.009);
  - vaccine-elicited clonotypes 32 vs 17.5 (p=0.066);
  - CDRH3 diversity at wk4 70.8 vs 24.5 (p=0.010).
- **IgM rose more with Fluarix:** H3 geometric mean 5.53 vs 1.83 (p=0.013).
- **mAb binding** (`09_…py`). There are 589 mAbs from 4 mRNA donors and 106 from 3 Fluarix donors, 84 of which come from one donor. The table shows the donor-mean share of mAbs binding at ≥3-fold over control:

| Antigen | mRNA-1010 | Fluarix |
|---|---|---|
| H3 A/Hong Kong/1/1968 | 0.51 | 0.05 |
| H3 A/Thailand/8/2022 | 0.89 | 0.35 |
| H3 A/Croatia/10136RV/2023 | 0.77 | 0.25 |
| H7 | 0.13 | 0.00 |
| H5 | 0.21 | 0.37 |

  With 4 vs 3 donors the smallest attainable p-value is 0.057. These are binding data only, with no neutralisation.

### 3.7 Data-integrity findings: fix before WU397 is cited as protocol rationale

| # | Finding | Evidence |
|---|---|---|
| 1 | **The B/Vic HAI block is misassigned to participants** | In the B/Vic rows, the wk17 attendees are {F007, F016, M008, M021}. The other three HAI antigens, MN and ELISA all say {F009, F018, M010, M023}. Each is exactly one position earlier in participant order. Fluarix has 15 B/Vic values and mRNA 13, consistent with data crossing the arm boundary. B/Vic HAI doesn't track B/Vic ELISA (wk4 ρ=−0.01, vs 0.73 for H1). Treat it as unusable until source-verified. |
| 2 | The GC file has two unlabelled blocks | 156 rows = 2 × 78 participant-timepoint sets, with no column to tell them apart (probe or specificity?). They were analysed separately and must not be averaged. |
| 3 | FNA timepoints in the files don't match the protocol | Protocol: wk1, 2, 4, 8, 17, 26. Files: wk0, 2, 8, 17, 26. |
| 4 | The plasmablast file matches neither the blood nor the FNA schedule | It has 28 participants (11 outside the FNA cohort) at wk2 and wk8. Blood draws were d0/7/29/121/181. |
| 5 | The IgM cohort doesn't match the summary | 15/14 participants in the file vs 37/38 stated. One ID is "20"; the file gives no timepoint. |
| 6 | Assay strains are unspecified | HAI, MN and ELISA strains are not given, nor the bead-array timepoint. |
| 7 | MN has a ceiling at 1280 | See §3.3. |
| 8 | Repertoire files lack participant IDs | They can't be linked to other data. |
| 9 | A virus name has a typo | "A/SOUTHAFRICA/R07876/202023". |

---

## 4. Recommended studies: conditions and readouts

### Study 0: WU397 remediation and re-analysis (before the protocol goes to committee)

**Conditions:** no new subjects. Source-data verification and a pre-specified re-analysis.

**Fix**
- Verify the B/Vic HAI participant mapping, or re-test.
- Identify the two GC blocks and correct the FNA and plasmablast timepoint labels.
- Reconcile the IgM cohort and IDs.
- Document the strain behind every HAI, MN, ELISA and bead antigen.
- Re-read MN sera censored at 1280 on an uncensored range.

**Add**
- Baseline characteristics and vaccination dates by arm and site: age, sex, prior-season vaccination, prior infection.

**Readouts on stored sera** (hypothesis-generating, to choose Study 1 endpoints):
- NA-inhibition (NAI) titres against N1 and N2. The summary lists four antigens, one per strain, presumably HA-only, so mRNA-1010 would induce no NA antibody, whereas split Fluarix contains some NA.
- HA-stem-directed antibody.
- Fc-effector function.

**Output:** a corrected data package. If any correction changes §3, the protocol rationale changes with it.

### Study 1: Phase 2 randomised, observer-blind, strain-matched breadth trial (the decision gate)

| Element | Specification |
|---|---|
| **Design** | Multicentre, one Northern-Hemisphere season. Central randomisation stratified by age band, site and prior-season vaccination. Observer-blind, with laboratories blinded to arm. All vaccinations in one fixed pre-season window. Active RT-PCR surveillance for influenza-like illness throughout. |
| **In whom** | Adults in two strata: 18–64 and ≥65. Prior 2–3 seasons' vaccination history documented. Excludes current-season vaccination and confirmed influenza in the prior 6 months. Immunogenicity is measured in all participants or in a *random* subset pre-specified in size, not a convenience subset. |
| **Conditions (arms)** | **A.** mRNA vaccine, **trivalent** (B/Yamagata dropped), encoding the season's WHO/FDA-recommended wild-type strains (the cell/recombinant set), at the intended dose. The WU397 summary doesn't state a dose; if dose isn't fixed by prior dose-ranging, add a second dose level. **B.** Licensed egg-based trivalent standard-dose IIV (Fluarix): the standard-of-care comparator, carrying the WHO egg-based strain set for the same season. **C.** Licensed non-egg vaccine carrying the *same* wild-type (cell/recombinant) strains as A. For 18–64 this is cell-culture IIV: it has the same standard HA dose as Fluarix, so it isolates the egg-adaptation effect (§3.5) from the platform effect. Recombinant HA has 3× the HA dose, which would confound the comparison. For ≥65, use recombinant HA, which is also a preferentially recommended vaccine; add high-dose or adjuvanted IIV if that is the intended label comparator. |
| **Against what: comparators** | Arms B and C (and the ≥65 preferential comparator). Every comparison is strain-matched by WHO definition. |
| **Against what: virus panels** | Panels are fixed and locked before unblinding, and identical for all arms. Every comparative readout uses wild-type, non-egg-adapted, sequence-confirmed viruses. **(i) Vaccine strains:** the wild-type strain for each component. The egg-based version is tested only as a sensitivity readout. **(ii) Forward-drift panel:** viruses from antigenically distinct clades/subclades circulating at and after strain selection, weighted by prevalence, for H3N2 (primary), H1N1 and B/Victoria. **(iii) Historical panel:** reported separately, never pooled with forward drift. |
| **Primary endpoint 1: breadth, superiority** | Day-29 neutralising GMT ratio (mRNA/comparator), with each person's titre summarised as the geometric mean across the **H3N2 forward-drift panel**. |
| **Primary endpoint 2: HAI non-inferiority** | Day-29 HAI GMT ratio and seroconversion difference against each vaccine strain, using FDA 2007 margins: upper 95% bound of comparator/mRNA GMT ratio ≤1.5, and of the seroconversion difference ≤10 points. This ensures breadth isn't bought with homologous immunity. |
| **Key secondary** | The same breadth endpoint for H1N1 and B/Victoria. Breadth at **day 91 and day 181** (fixed windows, no pooling). NAI titres (N1, N2). Forward-drift ÷ vaccine-strain titre ratio (breadth independent of magnitude). Proportion with ≥4-fold rise to each panel virus. All titres on uncensored ranges. Participants with confirmed infection are censored from post-infection immunogenicity. |
| **Exploratory (mechanism)** | HA-stem antibody. Fc-effector function. Binding IgG, explicitly *not* a surrogate. FNA/GC sub-study in a pre-specified, randomly selected subset of consenting participants (≥15/arm) at fixed visits, to test whether persistent GCs shift serum neutralisation *forward* by day 181. |
| **Size** | Residual SD of the H3 forward-drift endpoint in WU397 was 1.02 log2 (raw 1.20). At 90% power and two-sided α 0.05, evaluable participants per arm per stratum: ratio 1.3 needs 154–213; ratio 1.5 needs 65–89. HAI seroconversion NI needs 268–526/arm (true seroconversion rate 15–50%). If the true H3 effect is WU397's 1.16×, 480/arm are needed, and an effect that small is of doubtful clinical value. |
| **Go/no-go** (pre-specify) | **Go** requires all of: H3N2 forward-drift day-29 ratio lower 95% bound >1.0 against each strain-matched comparator, with point estimate ≥1.3; day-181 point estimate ≥1.2; HAI NI met. If only H1 passes, the claim must be narrowed to H1. **No-go:** drop the heterologous-protection claim for this construct and pursue standard licensure endpoints, or redesign the antigen before more clinical spend. |

**A strategic choice to make explicitly.** WU397's H1 result may reflect *strain choice*: the sponsor picked a newer H1 than the licensed vaccine contained. "Better match through later or forward strain selection" is a different claim from "platform-intrinsic heterologous breadth". It would need its own design and a regulatory strain-selection pathway. Study 1 tests only the platform claim.

### Study 1b: year-2 revaccination extension

- **Design:** Study 1 participants are re-randomised in season 2 in a 2×2 design: mRNA→mRNA, comparator→comparator, comparator→mRNA, mRNA→comparator. Both arms get the season-2 strain-matched compositions.
- **Readouts:** the Study 1 breadth and HAI endpoints at day 29 and day 181 of year 2, against a forward-drift panel updated for season 2.
- **Why:** annual revaccination is the real-world use, and repeat vaccination is known to blunt H3N2 responses. A year-1-only breadth signal wouldn't support a label.

### Study 2: heterologous controlled human infection study (proof of concept and correlate discovery)

| Element | Specification |
|---|---|
| **In whom** | Healthy adults 18–49 with low pre-existing HAI/neutralising antibody to the challenge virus (pre-specified cut-off). |
| **Conditions** | Randomised, double-blind: mRNA vs licensed non-egg comparator carrying the same strains (cell-culture IIV or recombinant HA) vs placebo. Vaccination 4–8 weeks before challenge. |
| **Challenge virus** | A GMP wild-type H3N2 challenge strain that is antigenically mismatched to the vaccine antigen by a pre-specified antigenic-distance criterion. Preferably it should be *forward*-drifted relative to the vaccine antigen. This can be achieved by formulating both vaccine arms with an identical, antigenically older ("back-dated") strain. If only older challenge strains are usable against current-season vaccines, the study tests **backward** cross-protection. That flatters mRNA-1010 (§3.3, 2012–14 ratio 1.84×) and must not be extrapolated to forward drift. |
| **Readouts** | **Primary:** RT-PCR-confirmed symptomatic influenza (infection plus symptoms). **Secondary:** viral-shedding AUC, symptom-score AUC, infection by shedding or seroconversion. **Correlates:** pre-challenge HAI, neutralisation, NAI, stem antibody and Fc function *against the challenge virus*, related to outcome. |
| **Size** (planning assumptions, not data) | Vaccine vs placebo, assuming 50% vs 25% disease: 58/arm (80% power). Head-to-head mRNA vs comparator, assuming 35% vs 20%: 138/arm. If 30% vs 20%: 294/arm. Primary inference is vs placebo; head-to-head is secondary unless sized for it. |

### Study 3: Phase 3 event-driven relative-efficacy (rVE) trial, the pivotal test of the claim

| Element | Specification |
|---|---|
| **In whom** | Adults ≥50, stratified 50–64 and ≥65 (or the intended label population). Multinational, including both hemispheres if needed, so that diverse clades are captured. |
| **Conditions** | 1:1 randomised, observer-blind. mRNA trivalent, updated each season to the WHO/FDA composition, vs licensed comparator: standard-dose IIV for 50–64; the preferentially recommended vaccine (high-dose, adjuvanted or recombinant) for ≥65. **≥2 consecutive seasons**, with re-vaccination each season. |
| **Primary endpoint** | rVE against RT-PCR-confirmed protocol-defined influenza-like illness, any strain. |
| **Key secondary (multiplicity-controlled): the heterologous claim** | rVE against RT-PCR-confirmed illness caused by **antigenically mismatched** strains. Every positive specimen is sequenced. A committee blinded to arm classifies each case as matched or mismatched using genetic (clade) and antigenic criteria pre-specified against the vaccine strain. |
| **Other secondary** | rVE by subtype. Severe outcomes (hospitalisation, pneumonia). rVE by time since vaccination (early vs late season), because WU397 advantages waned by d121–181. |
| **Correlates sub-study** | Case-cohort design with day-29 and pre-season sera. HAI, neutralisation and NAI measured against each case's *own infecting virus*. Aim: a correlate that allows immunobridging for future strain updates. |
| **Size** | Event-driven. At 90% power and one-sided α 0.025, an rVE of 30% / 25% / 20% needs 334 / 511 / 847 cases of the endpoint. For the mismatched-strain endpoint this means roughly 39,000–195,000 participant-seasons. That figure rests on planning assumptions (§7): 1–2% comparator attack rate and 30–50% mismatched share. Hence ≥2 seasons, with the mismatched endpoint as a hierarchically tested key secondary or an estimation objective with a pre-set precision, unless the pooled case count supports a primary. |

**Sequence and gates.** Study 0 comes first. Study 1's day-29 and day-181 results gate both Study 2 and Study 3. Study 1b (year 2) runs in parallel with Study 2 and informs the re-vaccination design of Study 3. Study 2's correlate results feed Study 3's case-cohort analysis plan.

---

## 5. Readout rules for every study (derived from WU397's failure modes)

1. Define "homologous" and "heterologous" relative to **each arm's own** vaccine strain. Report forward drift and historical strains separately (§3.3).
2. Use wild-type viruses for comparative readouts. Egg reassortants are sensitivity analyses only (§3.5).
3. Primary endpoints are functional (neutralisation, HAI, NAI). Binding antibody is supportive only (§3.2).
4. Titre ranges must be uncensored (§3.3 MN ceiling). Visits are fixed and never pooled (§3.1).
5. Immunogenicity subsets are random and pre-specified. Surveillance for intercurrent infection is active. Laboratories are blinded to arm.
6. Lock the strain identity behind every antigen in the SAP (§3.7 #6). Keep participant IDs consistent across all files (§3.7 #1, #5, #8).

---

## 6. Numbers relied on, and their sources

The inputs are `/tmp/world/filesystem/*.csv` and `trial_summary.md`. Scripts are in `/tmp/outputs/analysis/`. The full ledger (130 rows: value, source file, script) is in `/tmp/outputs/numbers_ledger.csv`.

| Number | Value | Source file → script |
|---|---|---|
| H3 forward-drift neutralisation, d29 ratio | 1.16 (0.64–2.11), p=0.60; 68 viruses; n=13/14 | neutralization_seqbased.csv → 06_seqneut.py |
| H3 forward-drift, d121/181 ratio | 1.04 (0.65–1.67) | same |
| H3 vaccine-strain neutralisation, d29 ratio | 0.71 (0.36–1.38) | same |
| H3 forward-drift d29 GMT, mRNA vs Fluarix | 401 vs 465; unadjusted ratio 0.86 (0.44–1.68) | same → 06, 12 |
| H3 by isolation year, 2012–14 / 2023 / 2024 | 1.84 (1.10–3.08) / 1.18 (0.66–2.12) / 0.98 | same → 12_seqneut_robustness.py |
| H1 2023 viruses, d29 ratio | 2.06 (1.23–3.46); d121/181 1.17 (0.77–1.77) | same → 06 |
| H1 Fluarix-strain analogue (Wisconsin/588/2019) | 2.44 (1.18–5.05) | same → 06 |
| Relative breadth (2023 ÷ vaccine-strain titre) | H1: 0.48 vs 0.48; H3: 0.81 vs 0.54 | same → 13_relative_breadth.py |
| H1 neutralisation waning, late/d29 | 0.49 (mRNA) vs 0.82 (Fluarix) | same → 10_… |
| Censoring sensitivity (titres below LOD set to LOD/2) | H3 forward drift 1.18; H1 2023 1.95 | same → 12 |
| ELISA IgG wk4 ratio, H3 / H1 / B/Vic / B/Yam | 3.31 / 2.66 / 1.35 / 1.38 | elisa_igg_titers.csv → 04_elisa.py |
| ELISA IgG wk17/26 ratio, same order | 2.06 / 1.51 / 0.99 / 1.06 | same |
| ELISA decay (wk17/26 ÷ wk4), mRNA vs Fluarix | H1 0.42 vs 0.74; H3 0.46 vs 0.76 | same |
| Binding ÷ neutralisation fold-rise, H3 | 2.45–2.86 (mRNA) vs 0.63–1.01 (Fluarix), p<0.001 | elisa + seq-neut → 14_… |
| Bead-array fold-rise, H3 HK/1968 and Thailand/2022 | 10.9× vs 1.15×; 31.9× vs 3.4× | binding_breadth_h3.csv → 05_… |
| HAI H1N1 | GMFR 2.76 vs 2.25; SCR 7/14 vs 5/15; ratio 1.54 (0.87–2.71) | hai_titers.csv → 02_hai.py |
| HAI H3N2 | GMFR 1.72 vs 1.66; SCR 2/14 vs 3/15; ratio 1.06 (0.67–1.65) | same |
| HAI SCR-difference upper bounds (Fluarix − mRNA) | 17.4 / 32.9 / 29.8 / 29.8 points (H1/H3/BVic/BYam) | same |
| MN "homologous" | ratio 0.68 (0.31–1.51); at ceiling wk4 9/15 vs 4/14 | microneutralization.csv → 03_mn.py |
| MN "heterologous" | ratio 1.17 (0.52–2.62); baseline ratio 0.47 (0.22–1.00) | same |
| MN identity (inferred) | ρ with H3N2 0.41–0.42 vs H1N1 0.12–0.19; best match Darwin/9/2021 ρ=0.73 | MN + seq-neut → 17_… |
| Egg vs wild-type fold-rise | mRNA 0.60× (p<0.001); Fluarix 0.90× (p=0.23); arm difference p=0.005 | neutralization_seqbased.csv → 07_egg_pairs.py |
| GC peak / late median | 24.7% vs 4.7% (p=0.001) / 24.9% vs 2.3% (p=0.004) | gc_frequencies.csv rows 1–78 → 08_cellular.py |
| PB–GC clonal overlap (mRNA donors) | 92 / 91 / 83 / 73% of GC clones | pb_gc_clonal_overlap.csv → 08 |
| Serum clonotypes wk4; vaccine-elicited; CDRH3 wk4 | 97.5 vs 76.0; 32 vs 17.5; 70.8 vs 24.5 | serum_igg_clonotypes, repertoire_clonotype_counts, cdrh3_diversity_index → 08 |
| mAb donor-mean binding (HK68 / Thailand22 / H7 / H5) | 0.51 vs 0.05 / 0.89 vs 0.35 / 0.13 vs 0.00 / 0.21 vs 0.37; min. attainable p 0.057 | mab_binding_panels.csv → 09_mabs.py |
| B/Vic HAI misalignment | wk17 sets {007, 016, 008, 021} vs {009, 018, 010, 023}; 15 vs 13 values; ρ −0.01 vs 0.73 | hai_titers.csv, MN, ELISA → 01_… |
| Sample size, breadth endpoint | SD 1.02 log2 → 154–213/arm (ratio 1.3), 65–89/arm (1.5), 480/arm (1.16) | derived → 11_sample_size.py |
| rVE cases needed | 334 / 511 / 847 for rVE 30 / 25 / 20% | formula → 11 |

Analysis conventions:
- Seroconversion is counted as ≥4-fold with a 3.9 tolerance, because HAI titres are rounded geometric midpoints (57→226 is a true 4-fold rise). This reclassified one participant (Fluarix 027, H3N2).
- Seq-neut censored values are kept at their reported bound, with the LOD/2 sensitivity shown above.

---

## 7. External facts and planning assumptions (not from the data package)

- **Fluarix 2022–23 strains.** Per the WHO egg-based recommendation for the 2022–23 Northern Hemisphere season: A/Victoria/2570/2019 (H1N1)pdm09-like, A/Darwin/9/2021 (H3N2)-like, B/Austria/1359417/2021-like, B/Phuket/3073/2013-like.
- **Cell/recombinant counterparts** used to classify panel viruses: A/Wisconsin/588/2019 (2022–23 H1), A/Darwin/6/2021 (H3), and A/Wisconsin/67/2022 (counterpart of A/Victoria/4897/2022, the H1 from 2023–24 on).
- **Recent H3N2 components.** A/Thailand/8/2022 (egg) was the H3N2 component for 2024–25. For 2025–26 the H3N2 component moved to A/Croatia/10136RV/2023 (egg) and A/District of Columbia/27/2023 (cell); both are already in the program's panels. Confirm the composition for the season of conduct at protocol lock.
- **B/Yamagata.** No confirmed natural circulation since March 2020. WHO (2023) advised the B/Yamagata component is no longer warranted, and US vaccines moved to trivalent from 2024–25.
- **FDA guidance (2007) on seasonal inactivated vaccines.** Non-inferiority: upper 95% bound of the comparator/new GMT ratio ≤1.5, and of the seroconversion difference ≤10 points. Accelerated-approval seroconversion lower bound ≥40% (<65) or ≥30% (≥65).
- **HAI ≈1:40** is associated with roughly 50% protection against homologous strains.
- **≥65 comparator.** ACIP prefers high-dose, adjuvanted or recombinant vaccine for ≥65 (since 2022–23).
- **NAI antibody** has been independently associated with protection in challenge and cohort studies.
- **Planning assumptions (mine, to be replaced with program estimates):**
  - comparator attack rate 1–2% per season;
  - mismatched share of cases 30–50%;
  - challenge-model disease rates 30–50%;
  - target ratios 1.3–1.5 and go thresholds 1.3 / 1.2. These are proposals for the committee to ratify, not derived from data.

---

## 8. Files

- `/tmp/outputs/answer.md`: this document.
- `/tmp/outputs/numbers_ledger.csv`: every number, its value, source file and script.
- `/tmp/outputs/figures/`:
  - `fig1_forest_binding_vs_function.png`: all between-arm ratios, peak and late;
  - `fig2_h3_breadth_by_year.png`;
  - `fig3_gc_kinetics.png`.
- `/tmp/outputs/analysis/`: scripts `01`–`17` plus `common.py`, their CSV outputs, `logs/`, and `run_all.sh`, which reproduces everything from the read-only inputs.
