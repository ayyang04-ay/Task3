import sys; sys.path.insert(0, '/tmp/outputs/analysis')
from common import *
import statsmodels.formula.api as smf
from scipy.stats import norm
za2 = norm.ppf(0.975); zb90 = norm.ppf(0.90); zb80 = norm.ppf(0.80)
out = []
# (a) Breadth endpoint: participant-level mean log2 titre at d29 across forward-drift H3 viruses (and 2023 H1), baseline-adjusted residual SD
P = pd.read_csv(OUT + '06_seqneut_participant_category.csv')
for cat in ['H3 forward-drift (2022-2024)', 'H1 contemporary (2023)', 'H3 vaccine strain (Darwin/6 or /9)']:
    d = P[P.category == cat].assign(t=lambda x: (x.arm == 'mRNA-1010').astype(int))
    m = smf.ols('mean_l2_d29 ~ t + mean_l2_d0', data=d).fit()
    sd_res = np.sqrt(m.mse_resid); sd_raw = d.mean_l2_d29.std(ddof=1)
    for R in [1.3, 1.5, 2.0]:
        delta = np.log2(R)
        n90 = 2 * (za2 + zb90) ** 2 * sd_res ** 2 / delta ** 2
        out.append(dict(endpoint=f'seq-neut d29 GMT, {cat}', sd_log2_resid=sd_res, sd_log2_raw=sd_raw, target_ratio=R, n_per_arm_90pct=int(np.ceil(n90)),
                        n_per_arm_90pct_raw_sd=int(np.ceil(2 * (za2 + zb90) ** 2 * sd_raw ** 2 / delta ** 2))))
# (b) HAI NI on GMT ratio: margin 1.5 (comparator/new), true ratio 1.0, one-sided alpha 0.025, power 90% per strain
h = pd.read_csv(OUT + '02_hai_participant_level.csv', dtype={'participant': str})
for ag, d in h.groupby('antigen'):
    d = d.dropna(subset=['wk0', 'wk4']).assign(t=lambda x: (x.arm == 'mRNA-1010').astype(int), y=lambda x: np.log2(x.wk4), x0=lambda x: np.log2(x.wk0))
    m = smf.ols('y ~ t + x0', data=d).fit(); sd_res = np.sqrt(m.mse_resid); sd_raw = d.y.std(ddof=1)
    delta = np.log2(1.5)
    n = 2 * (za2 + zb90) ** 2 * sd_raw ** 2 / delta ** 2
    out.append(dict(endpoint=f'HAI d29 GMT NI (margin 1.5), {ag}', sd_log2_resid=sd_res, sd_log2_raw=sd_raw, target_ratio=1.0, n_per_arm_90pct=int(np.ceil(2 * (za2 + zb90) ** 2 * sd_res ** 2 / delta ** 2)),
                    n_per_arm_90pct_raw_sd=int(np.ceil(n))))
res = pd.DataFrame(out); res.to_csv(OUT + '11_sample_size_continuous.csv', index=False)
print(res.round(3).to_string(index=False))
# (c) HAI SCR NI: margin 10 points, assume equal true SCR p; one-sided 0.025; 90% power
print('\nHAI seroconversion NI (margin 10 percentage points, equal true rates, 1-sided alpha 0.025, 90% power):')
for p in [0.15, 0.30, 0.50]:
    n = (za2 + zb90) ** 2 * 2 * p * (1 - p) / 0.10 ** 2
    print(f'  true SCR {p:.2f}: n/arm = {int(np.ceil(n))}')
# (d) rVE event-driven (case-split): H0 rVE<=0 vs H1 rVE = x; one-sided alpha 0.025; power 90%
print('\nrVE trial, events needed (case-split binomial, 1:1 randomisation, H0: rVE<=0, 1-sided 0.025, 90% power):')
for rve in [0.20, 0.25, 0.30, 0.40]:
    p0 = 0.5; p1 = (1 - rve) / (2 - rve)
    E = (za2 * np.sqrt(p0 * (1 - p0)) + zb90 * np.sqrt(p1 * (1 - p1))) ** 2 / (p0 - p1) ** 2
    print(f'  true rVE {rve:.0%}: total cases needed ~ {int(np.ceil(E))}')
# illustrate N for a mismatched-strain-only endpoint under stated planning assumptions (NOT from the data package)
print('\nIllustrative enrolment for the mismatched-strain endpoint (planning assumptions, not data):')
for ar in [0.01, 0.02]:
    for fm in [0.3, 0.5]:
        for rve in [0.25, 0.30]:
            p0 = 0.5; p1 = (1 - rve) / (2 - rve)
            E = (za2 * np.sqrt(p0 * (1 - p0)) + zb90 * np.sqrt(p1 * (1 - p1))) ** 2 / (p0 - p1) ** 2
            avg_rate = ar * fm * (1 + (1 - rve)) / 2
            print(f'  comparator-arm attack rate {ar:.0%}/season, mismatched fraction {fm:.0%}, rVE {rve:.0%}: events {int(np.ceil(E))}, total N (1 season, no dropout) ~ {int(np.ceil(E / avg_rate)):,}')

print('\nIf the true H3 forward-drift advantage equals the WU397 point estimate (1.16x), residual SD 1.02 log2:')
for R in [1.16, 1.2]:
    n = 2 * (za2 + zb90) ** 2 * 1.023 ** 2 / np.log2(R) ** 2
    print(f'  ratio {R}: n/arm (90% power, 2-sided 0.05) = {int(np.ceil(n))}')
print('\nChallenge-study sizing (two-proportion, 2-sided alpha 0.05, 80% power) -- PLANNING ASSUMPTIONS, not data:')
def n2p(p1, p2, a=0.05, pw=0.8):
    za = norm.ppf(1 - a / 2); zb = norm.ppf(pw); pb = (p1 + p2) / 2
    return (za * np.sqrt(2 * pb * (1 - pb)) + zb * np.sqrt(p1 * (1 - p1) + p2 * (1 - p2))) ** 2 / (p1 - p2) ** 2
for lab, p1, p2 in [('placebo 50% vs mRNA 25% (vaccine vs placebo)', 0.50, 0.25), ('placebo 40% vs mRNA 20%', 0.40, 0.20),
                    ('comparator 35% vs mRNA 20% (head-to-head)', 0.35, 0.20), ('comparator 30% vs mRNA 20% (head-to-head)', 0.30, 0.20)]:
    print(f'  {lab}: n/arm = {int(np.ceil(n2p(p1, p2)))}')
