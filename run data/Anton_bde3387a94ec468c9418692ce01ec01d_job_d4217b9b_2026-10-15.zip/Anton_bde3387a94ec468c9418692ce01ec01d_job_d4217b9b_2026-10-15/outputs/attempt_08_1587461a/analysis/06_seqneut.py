import sys, re; sys.path.insert(0, '/tmp/outputs/analysis')
from common import *
s = pd.read_csv(FS + 'neutralization_seqbased.csv')
s['arm'] = s.serum.str.split('_').str[0]; s['pid'] = s.serum.str.split('_').str[1]; s['day'] = s.serum.str.split('_').str[2]
s['subtype'] = s.virus.str[-4:]
s['egg_or_reassortant'] = s.virus.str.contains(r'egg_|X-\d|NIB-|IVR-', regex=True)
def year(v):
    name = v.rsplit('_', 1)[0]
    m = re.search(r'/(\d{4})(egg|X-\d+A?|NIB-\d+|_IVR-\d+)?$', name.replace('_IVR-238', ''))
    y = re.findall(r'/(\d{4,6})', name)
    yr = int(str(y[-1])[:4]) if y else np.nan
    if yr == 2020 and '202023' in name: yr = 2023  # typo in source: A/SOUTHAFRICA/R07876/202023
    return yr
s['year'] = s.virus.apply(year)
# category relative to each arm's vaccine (public WHO composition; mRNA-1010 composition from trial_summary.md)
H1_mRNA_match = ['A/Wisconsin/67/2022_H1N1', 'A/Victoria/4897/2022_IVR-238_H1N1']
H1_Flu_match = ['A/Wisconsin/588/2019_H1N1']   # cell analogue of A/Victoria/2570/2019 (Fluarix 2022-23 H1, egg)
H3_match = ['A/Darwin/6/2021_H3N2', 'A/Darwin/9/2021_H3N2']
def cat(r):
    v = r.virus
    if v in H1_mRNA_match: return 'H1 mRNA-1010 vaccine strain'
    if v in H1_Flu_match: return 'H1 Fluarix vaccine strain (cell analogue)'
    if v in H3_match: return 'H3 vaccine strain (Darwin/6 or /9)'
    if r.subtype == 'H1N1': return 'H1 historical (2009-2019)' if r.year <= 2019 else 'H1 contemporary (2023)'
    if r.year <= 2020: return 'H3 historical (2012-2020)'
    return 'H3 forward-drift (2022-2024)'
s['category'] = s.apply(cat, axis=1)
s['censor'] = s.titer_bound
print(s.drop_duplicates('virus').groupby(['category']).virus.apply(list).to_string())
print(s.drop_duplicates('virus').groupby('category').size())
# wide: per participant x virus
W = s.pivot_table(index=['arm', 'pid', 'virus', 'category', 'subtype', 'egg_or_reassortant'], columns='day', values='titer').reset_index()
B = s.pivot_table(index=['arm', 'pid', 'virus'], columns='day', values='titer_bound', aggfunc='first').reset_index()
W = W.merge(B, on=['arm', 'pid', 'virus'], suffixes=('', '_bound'))
W['late'] = W['d121'].fillna(W['d181'])
W['l2fc29'] = np.log2(W.d29 / W.d0)
W['l2fcL'] = np.log2(W.late / W.d0)
W['ge4x'] = (W.d29 / W.d0 >= 4).astype(float).where(W.d29.notna() & W.d0.notna())
# a 4-fold rise cannot be claimed if d0 is 'lower'-censored (>= ULOQ) -- flag
W.to_csv(OUT + '06_seqneut_long_wide.csv', index=False)

# per-virus arm comparison (baseline-adjusted ANCOVA on log2)
import statsmodels.formula.api as smf
rows = []
for (v, c), d in W.groupby(['virus', 'category']):
    d = d.dropna(subset=['d0', 'd29'])
    a = d[d.arm == 'mRNA-1010']; f = d[d.arm == 'Fluarix']
    if len(a) < 3 or len(f) < 3: continue
    dd = d.assign(t=(d.arm == 'mRNA-1010').astype(int), y=np.log2(d.d29), x=np.log2(d.d0))
    m = smf.ols('y ~ t + x', data=dd).fit()
    rows.append(dict(virus=v, category=c, n_m=len(a), n_f=len(f),
                     GMT_d0_m=2 ** np.log2(a.d0).mean(), GMT_d0_f=2 ** np.log2(f.d0).mean(),
                     GMT_d29_m=2 ** np.log2(a.d29).mean(), GMT_d29_f=2 ** np.log2(f.d29).mean(),
                     GMFR_m=2 ** a.l2fc29.mean(), GMFR_f=2 ** f.l2fc29.mean(),
                     pct4x_m=a.ge4x.mean(), pct4x_f=f.ge4x.mean(),
                     adj_ratio=2 ** m.params['t'], adj_lo=2 ** m.conf_int().loc['t', 0], adj_hi=2 ** m.conf_int().loc['t', 1], adj_p=m.pvalues['t']))
pv = pd.DataFrame(rows).sort_values(['category', 'virus'])
from statsmodels.stats.multitest import multipletests
pv['adj_p_BH'] = multipletests(pv.adj_p, method='fdr_bh')[1]
pv.to_csv(OUT + '06_seqneut_per_virus.csv', index=False)
print('\nPer-virus summary, vaccine-strain and selected rows:')
print(pv[pv.category.str.contains('vaccine|historical \\(2009')].round(3).to_string(index=False))

# category-level summary per arm: mean over viruses of per-virus GMFR, fraction of participant-virus pairs >=4x
print('\nCategory-level (participant-level means across viruses in category, then arm means):')
P = W.dropna(subset=['d0', 'd29']).groupby(['arm', 'pid', 'category']).agg(
    mean_l2fc29=('l2fc29', 'mean'), frac_ge4x=('ge4x', 'mean'), mean_l2_d29=('d29', lambda x: np.log2(x).mean()),
    mean_l2_d0=('d0', lambda x: np.log2(x).mean()), nvir=('virus', 'nunique')).reset_index()
PL = W.dropna(subset=['d0', 'late']).groupby(['arm', 'pid', 'category']).agg(mean_l2fcL=('l2fcL', 'mean'), mean_l2_late=('late', lambda x: np.log2(x).mean())).reset_index()
P = P.merge(PL, on=['arm', 'pid', 'category'], how='left')
P.to_csv(OUT + '06_seqneut_participant_category.csv', index=False)
out = []
for c, d in P.groupby('category'):
    a = d[d.arm == 'mRNA-1010']; f = d[d.arm == 'Fluarix']
    t1 = stats.ttest_ind(a.mean_l2fc29, f.mean_l2fc29, equal_var=False)
    t2 = stats.ttest_ind(a.frac_ge4x, f.frac_ge4x, equal_var=False)
    dd = d.assign(t=(d.arm == 'mRNA-1010').astype(int))
    m = smf.ols('mean_l2_d29 ~ t + mean_l2_d0', data=dd).fit()
    dl = dd.dropna(subset=['mean_l2_late'])
    ml = smf.ols('mean_l2_late ~ t + mean_l2_d0', data=dl).fit()
    out.append(dict(category=c, nvir=int(d.nvir.max()), n_m=len(a), n_f=len(f),
                    GMT_d0_m=2 ** a.mean_l2_d0.mean(), GMT_d0_f=2 ** f.mean_l2_d0.mean(),
                    GMT_d29_m=2 ** a.mean_l2_d29.mean(), GMT_d29_f=2 ** f.mean_l2_d29.mean(),
                    GMFR_m=2 ** a.mean_l2fc29.mean(), GMFR_f=2 ** f.mean_l2fc29.mean(), GMFR_ratio=2 ** (a.mean_l2fc29.mean() - f.mean_l2fc29.mean()), p_GMFR=t1.pvalue,
                    frac4x_m=a.frac_ge4x.mean(), frac4x_f=f.frac_ge4x.mean(), p_frac4x=t2.pvalue,
                    adj_d29_ratio=2 ** m.params['t'], adj_lo=2 ** m.conf_int().loc['t', 0], adj_hi=2 ** m.conf_int().loc['t', 1], adj_p=m.pvalues['t'],
                    GMFR_late_m=2 ** a.mean_l2fcL.mean(), GMFR_late_f=2 ** f.mean_l2fcL.mean(),
                    adj_late_ratio=2 ** ml.params['t'], adj_late_lo=2 ** ml.conf_int().loc['t', 0], adj_late_hi=2 ** ml.conf_int().loc['t', 1], adj_late_p=ml.pvalues['t']))
cs = pd.DataFrame(out); cs.to_csv(OUT + '06_seqneut_category_summary.csv', index=False)
print(cs.round(3).T.to_string())
