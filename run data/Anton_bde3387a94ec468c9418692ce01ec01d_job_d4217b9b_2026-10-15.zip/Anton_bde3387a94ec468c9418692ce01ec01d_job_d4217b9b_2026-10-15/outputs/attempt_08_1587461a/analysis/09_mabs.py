import sys; sys.path.insert(0, '/tmp/outputs/analysis')
from common import *
m = pd.read_csv(FS + 'mab_binding_panels.csv')
m['donor'] = m.mab_id.str.split('.').str[1]
m = m[m.antigen != 'SARS-CoV-2 RBD']   # RBD is the normaliser (all values exactly 1.0)
print('mAbs per arm:', m.groupby('arm').mab_id.nunique().to_dict(), '; per donor:', m.groupby(['arm', 'donor']).mab_id.nunique().to_dict())
targets = {'group_I': ['A/Hubei/1/2010 (H5)', 'A/Puerto Rico/8/1934', 'A/New Caledonia/20/1999', 'A/Netherlands/01317/2025', 'A/Victoria/4897/2022', 'A/Wisconsin/588/2019', 'A/California/04/2009'],
           'group_II': ['A/Shanghai/1/2013 (H7)', 'A/Hong Kong/1/1968', 'A/Croatia/10136RV/2023', 'A/Thailand/8/2022', 'A/Darwin/6/2021', 'A/Texas/50/2012', 'A/Fujian/411/2002']}
rows = []
for thr in [3, 10]:
    for panel, ags in targets.items():
        for ag in ags:
            d = m[(m.panel == panel) & (m.antigen == ag)].copy(); d['b'] = d.fold_over_control >= thr
            pooled = d.groupby('arm').b.mean()
            donor = d.groupby(['arm', 'donor']).b.mean()
            # donor-weighted (each donor counts once)
            dw = donor.groupby(level=0).mean()
            rows.append(dict(threshold=thr, panel=panel, antigen=ag,
                             Flu_pooled=pooled.get('Fluarix'), mRNA_pooled=pooled.get('mRNA-1010'),
                             Flu_donor_mean=dw.get('Fluarix'), mRNA_donor_mean=dw.get('mRNA-1010'),
                             Flu_by_donor=' / '.join(f'{k[1]}:{v:.2f}' for k, v in donor.items() if k[0] == 'Fluarix'),
                             mRNA_by_donor=' / '.join(f'{k[1]}:{v:.2f}' for k, v in donor.items() if k[0] == 'mRNA-1010')))
res = pd.DataFrame(rows); res.to_csv(OUT + '09_mab_binding_by_donor.csv', index=False)
print(res[res.threshold == 3].round(2).to_string(index=False))
# donor-level Mann-Whitney for the headline heterologous antigens at thr 3 (n=3 vs 4 donors)
print('\nDonor-level test (each donor = 1 observation), threshold 3:')
for panel, ags in targets.items():
    for ag in ags:
        d = m[(m.panel == panel) & (m.antigen == ag)].assign(b=lambda x: x.fold_over_control >= 3)
        dd = d.groupby(['arm', 'donor']).b.mean()
        a = dd.loc['mRNA-1010'].values; f = dd.loc['Fluarix'].values
        print(f'{ag:28s} mRNA donors {np.round(a, 2)} Flu donors {np.round(f, 2)} MW p={stats.mannwhitneyu(a, f).pvalue:.3f}')
print('\nminimum attainable two-sided exact Mann-Whitney p with 4 vs 3 donors = %.3f' % (2 / 35))
