import sys; sys.path.insert(0, '/tmp/outputs/analysis')
from common import *
# strain annotation (public WHO vaccine-composition history; used only to order/label strains, not as data)
ann_h1 = {
 'A/Puerto Rico/8/1934': ('pre-pandemic lab strain', 1934),
 'A/California/04/2009': ('pdm09 prototype', 2009),
 'A/Michigan/45/2015': ('6B.1 (vaccine 2017-19)', 2015),
 'A/Brisbane/2/2018': ('6B.1A.1 (vaccine 2019-20)', 2018),
 'A/Guangdong-Maonan/SWL1536/2019': ('6B.1A.5a.1 (egg vaccine 2020-21)', 2019),
 'A/Hawaii/70/2019': ('6B.1A.5a.1 (cell vaccine 2020-21)', 2019),
 'A/Wisconsin/588/2019': ('6B.1A.5a.2 = cell analogue of FLUARIX 2022-23 H1 (A/Victoria/2570/2019)', 2019.5),
 'A/Sydney/5/2021': ('6B.1A.5a.2a', 2021),
 'A/Wisconsin/67/2022': ('6B.1A.5a.2a.1 = cell analogue of mRNA-1010 H1 (A/Victoria/4897/2022)', 2022),
}
ann_h3 = {
 'A/Hong Kong/1/1968': ('1968 pandemic', 1968), 'A/Brisbane/10/2007': ('vaccine 2008-10', 2007), 'A/Perth/16/2009': ('vaccine 2010-12', 2009),
 'A/Victoria/361/2011': ('vaccine 2012-13', 2011), 'A/Texas/50/2012': ('vaccine 2013-15', 2012),
 'A/Singapore/INFIMH-16-0019/2016': ('vaccine 2018-19', 2016), 'A/Switzerland/8060/2017': ('vaccine SH2019', 2017),
 'A/South Australia/34/2019': ('vaccine SH2020', 2019), 'A/Hong Kong/2671/2019': ('vaccine 2020-21', 2019.5),
 'A/Cambodia/e0826360/2020': ('vaccine 2021-22', 2020), 'A/Darwin/6/2021': ('mRNA-1010 H3 (cell); Fluarix = A/Darwin/9/2021 egg, same clade', 2021),
 'A/Thailand/8/2022': ('2a.3a.1 (vaccine 2024-25) = forward drift', 2022),
}
out = []
for fn, ann in [('binding_breadth_h1.csv', ann_h1), ('binding_breadth_h3.csv', ann_h3)]:
    b = pd.read_csv(FS + fn, dtype={'participant': str})
    sub = 'H1' if 'h1' in fn else 'H3'
    for strain, d in b.groupby('strain'):
        a = d[d.arm == 'mRNA-1010'].log2_fold_change_mfi; f = d[d.arm == 'Fluarix'].log2_fold_change_mfi
        tt = stats.ttest_ind(a, f, equal_var=False); mw = stats.mannwhitneyu(a, f)
        diff = a.mean() - f.mean()
        se = np.sqrt(a.var(ddof=1) / len(a) + f.var(ddof=1) / len(f))
        dfw = se ** 4 / ((a.var(ddof=1) / len(a)) ** 2 / (len(a) - 1) + (f.var(ddof=1) / len(f)) ** 2 / (len(f) - 1))
        tq = stats.t.ppf(.975, dfw)
        out.append(dict(subtype=sub, strain=strain, note=ann[strain][0], year=ann[strain][1],
                        mRNA_mean_log2FC=a.mean(), mRNA_fold=2 ** a.mean(), Flu_mean_log2FC=f.mean(), Flu_fold=2 ** f.mean(),
                        diff_log2=diff, diff_lo=diff - tq * se, diff_hi=diff + tq * se, ratio_fold=2 ** diff, welch_p=tt.pvalue, mw_p=mw.pvalue,
                        mRNA_n_ge2fold=int((a >= 1).sum()), Flu_n_ge2fold=int((f >= 1).sum()), n_mRNA=len(a), n_Flu=len(f)))
res = pd.DataFrame(out).sort_values(['subtype', 'year'])
# Holm correction within subtype
from statsmodels.stats.multitest import multipletests
res['welch_p_holm'] = np.nan
for s, d in res.groupby('subtype'):
    res.loc[d.index, 'welch_p_holm'] = multipletests(d.welch_p, method='holm')[1]
res.to_csv(OUT + '05_binding_breadth_by_strain.csv', index=False)
print(res[['subtype', 'strain', 'year', 'mRNA_fold', 'Flu_fold', 'ratio_fold', 'diff_lo', 'diff_hi', 'welch_p', 'welch_p_holm', 'mRNA_n_ge2fold', 'n_mRNA', 'Flu_n_ge2fold', 'n_Flu']].round(3).to_string(index=False))

# participant-level breadth: number of strains with >=2-fold rise; mean log2FC across heterologous (non-vaccine) strains
print('\nParticipant-level breadth (count of panel strains with >=2-fold MFI rise)')
for fn, ann, vacc in [('binding_breadth_h1.csv', ann_h1, ['A/Wisconsin/67/2022', 'A/Wisconsin/588/2019']), ('binding_breadth_h3.csv', ann_h3, ['A/Darwin/6/2021'])]:
    b = pd.read_csv(FS + fn, dtype={'participant': str})
    p = b.pivot_table(index=['arm', 'participant'], columns='strain', values='log2_fold_change_mfi')
    het = [c for c in p.columns if c not in vacc]
    p['n_ge2fold_all'] = (p[[c for c in p.columns]] >= 1).sum(axis=1)
    p['mean_log2FC_nonvaccine'] = p[het].mean(axis=1)
    for arm, d in p.groupby(level=0):
        print(fn, arm, 'median n strains >=2x: %.1f of %d' % (d.n_ge2fold_all.median(), len(ann)), '; mean log2FC non-vaccine strains: %.2f (fold %.2f)' % (d.mean_log2FC_nonvaccine.mean(), 2 ** d.mean_log2FC_nonvaccine.mean()))
    a = p.loc['mRNA-1010', 'mean_log2FC_nonvaccine']; f = p.loc['Fluarix', 'mean_log2FC_nonvaccine']
    print('   Welch p (non-vaccine mean log2FC)', round(stats.ttest_ind(a, f, equal_var=False).pvalue, 4))
