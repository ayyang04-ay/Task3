import sys; sys.path.insert(0, '/tmp/outputs/analysis')
from common import *
# ---- GC: two unlabelled blocks (rows 1-78 = block A, rows 79-156 = block B)
g = pd.read_csv(FS + 'gc_frequencies.csv', dtype={'participant': str})
g['block'] = np.where(np.arange(len(g)) < 78, 'A', 'B')
print('GC rows per block:', g.groupby('block').size().to_dict())
tps = ['wk0', 'wk2', 'wk8', 'wk17', 'wk26']
for blk, d in g.groupby('block'):
    w = d.pivot_table(index=['arm', 'participant'], columns='timepoint', values='pct_ha_specific_igg_gc')[tps]
    w['peak_post'] = w[['wk2', 'wk8', 'wk17', 'wk26']].max(axis=1)
    w['late_wk17_26'] = w[['wk17', 'wk26']].max(axis=1)
    print(f'\n== GC block {blk}: % HA-specific among IgG GC B cells (median [range]) ==')
    for arm, x in w.groupby(level=0):
        print(arm, 'n=%d' % len(x), ' '.join(f'{c}: {x[c].median():.2f} [{x[c].min():.2f}-{x[c].max():.2f}] (n={x[c].notna().sum()})' for c in tps + ['peak_post', 'late_wk17_26']))
    for c in ['wk2', 'wk8', 'peak_post', 'late_wk17_26']:
        a = w.loc['mRNA-1010', c].dropna(); f = w.loc['Fluarix', c].dropna()
        print(f'  {c}: Mann-Whitney p = {stats.mannwhitneyu(a, f).pvalue:.4f} (n {len(a)} vs {len(f)})')
    w.to_csv(OUT + f'08_gc_block{blk}_wide.csv')
# ---- PB
p = pd.read_csv(FS + 'plasmablast_frequencies.csv', dtype={'participant': str})
w = p.pivot_table(index=['arm', 'participant'], columns='timepoint', values='pct_plasmablast')[tps]
w['peak_post'] = w[['wk2', 'wk8', 'wk17', 'wk26']].max(axis=1)
print('\n== plasmablast_frequencies.csv (timepoints as labelled: wk0, wk2, wk8, wk17, wk26) ==')
for arm, x in w.groupby(level=0):
    print(arm, 'n=%d' % len(x), ' '.join(f'{c}: {x[c].median():.4f}' for c in tps + ['peak_post']))
for c in ['wk2', 'wk8', 'wk17', 'wk26', 'peak_post']:
    a = w.loc['mRNA-1010', c].dropna(); f = w.loc['Fluarix', c].dropna()
    print(f'  {c}: MW p = {stats.mannwhitneyu(a, f).pvalue:.4f} (n {len(a)} vs {len(f)})')
fna_ids = set(g.participant)
print('PB participants not in FNA cohort:', sorted(set(w.index.get_level_values(1)) - fna_ids))
# ---- PB-GC overlap
o = pd.read_csv(FS + 'pb_gc_clonal_overlap.csv')
o['arm'] = o.Participant.map(lambda x: 'mRNA-1010' if x in ['397-06', '397-17', '397-28', '397-29'] else 'Fluarix')
o['pct_PBclones_in_GC'] = o['Percentage of overlapping clones out of wk1 PB clones'].str.rstrip('%').astype(float)
o['pct_GCclones_from_PB'] = o['Percentage of overlapping clones out of GC B cell clones'].str.rstrip('%').astype(float)
o['chk1'] = 100 * o['Number of overlapping clones spanning wk1 PB and GC B cell'] / o['Number of wk1 PB clones']
o['chk2'] = 100 * o['Number of overlapping clones spanning wk1 PB and GC B cell'] / o['Number of GC B cell clones']
print('\n== PB-GC clonal overlap ==')
print(o[['Participant', 'arm', 'Number of wk1 PB clones', 'Number of GC B cell sequences', 'Number of GC B cell clones', 'Number of overlapping clones spanning wk1 PB and GC B cell', 'pct_PBclones_in_GC', 'chk1', 'pct_GCclones_from_PB', 'chk2']].round(2).to_string(index=False))
# ---- repertoire / serum clonotypes / CDRH3 (no participant IDs)
r = pd.read_csv(FS + 'repertoire_clonotype_counts.csv')
print('\n== repertoire_clonotype_counts (no participant IDs; n=8/arm) ==')
for mtr, d in r.groupby('metric'):
    a = d[d.arm == 'mRNA-1010'].value; f = d[d.arm == 'Fluarix'].value
    print(f'{mtr}: mRNA median {a.median():.1f} (IQR {a.quantile(.25):.1f}-{a.quantile(.75):.1f}); Fluarix median {f.median():.1f} (IQR {f.quantile(.25):.1f}-{f.quantile(.75):.1f}); MW p={stats.mannwhitneyu(a, f).pvalue:.3f}')
sc = pd.read_csv(FS + 'serum_igg_clonotypes.csv')
print('\n== serum_igg_clonotypes ==')
for tp, d in sc.groupby('timepoint', sort=False):
    a = d[d.arm == 'mRNA-1010'].n_clonotypes; f = d[d.arm == 'Fluarix'].n_clonotypes
    print(f'{tp}: mRNA median {a.median()} (n={len(a)}), Fluarix median {f.median()} (n={len(f)})' + (f' MW p={stats.mannwhitneyu(a, f).pvalue:.3f}' if len(a) > 2 else ''))
print('check: wk0 serum clonotypes equal n_pre_existing_clonotypes ->',
      sorted(sc[sc.timepoint == 'wk0'].n_clonotypes.tolist()) == sorted(r[r.metric == 'n_pre_existing_clonotypes'].value.astype(int).tolist()))
cd = pd.read_csv(FS + 'cdrh3_diversity_index.csv')
print('\n== CDRH3 diversity index ==')
for tp, d in cd.groupby('timepoint', sort=False):
    a = d[d.arm == 'mRNA-1010'].diversity_index; f = d[d.arm == 'Fluarix'].diversity_index
    print(f'{tp}: mRNA median {a.median():.1f} (n={len(a)}), Fluarix median {f.median():.1f} (n={len(f)})' + (f' MW p={stats.mannwhitneyu(a, f).pvalue:.3f}' if len(a) > 2 else ''))
# ---- IgM
i = pd.read_csv(FS + 'igm_fold_change.csv', dtype={'participant': str})
print('\n== IgM fold change (timepoint not specified in file) ==')
print('participant IDs not 3-digit:', i[i.participant.str.len() != 3].participant.unique().tolist())
for ag, d in i.groupby('antigen'):
    a = d[d.arm == 'mRNA-1010'].fold_change; f = d[d.arm == 'Fluarix'].fold_change
    print(f'{ag}: mRNA GM {gmt_ci(a)[0]:.2f}, n>1: {(a > 1).sum()}/{len(a)}; Fluarix GM {gmt_ci(f)[0]:.2f}, n>1: {(f > 1).sum()}/{len(f)}; MW p={stats.mannwhitneyu(a, f).pvalue:.3f}')
