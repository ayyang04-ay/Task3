import sys; sys.path.insert(0, '/tmp/outputs/analysis')
from common import *
mn = pd.read_csv(FS + 'microneutralization.csv', dtype={'participant': str})
t = mn[mn.measure == 'titer'].pivot_table(index=['panel', 'arm', 'participant'], columns='timepoint', values='value').reset_index()
t['late'] = t['wk17'].fillna(t['wk26'])
ULOQ = 1280
t['fr4'] = t.wk4 / t.wk0; t['frL'] = t.late / t.wk0
t['ge4x'] = (t.fr4 >= 4).astype(float)
t['cens_wk0'] = (t.wk0 >= ULOQ); t['cens_wk4'] = (t.wk4 >= ULOQ)
# maximum possible fold-rise given ceiling
t['max_possible_fr'] = ULOQ / t.wk0
t['cannot_reach_4x'] = t.max_possible_fr < 4
rows = []
for (panel, arm), d in t.groupby(['panel', 'arm']):
    r = dict(panel=panel, arm=arm, n=len(d))
    for tp in ['wk0', 'wk4', 'late']:
        g, lo, hi, n = gmt_ci(d[tp]); r.update({f'GMT_{tp}': g, f'{tp}_lo': lo, f'{tp}_hi': hi})
    g, lo, hi, n = gmt_ci(d.fr4); r.update(GMFR4=g, GMFR4_lo=lo, GMFR4_hi=hi)
    g, lo, hi, n = gmt_ci(d.frL); r.update(GMFRlate=g, GMFRlate_lo=lo, GMFRlate_hi=hi)
    r.update(n_ge4x=int(d.ge4x.sum()), n_at_ULOQ_wk0=int(d.cens_wk0.sum()), n_at_ULOQ_wk4=int(d.cens_wk4.sum()),
             n_cannot_reach_4x=int(d.cannot_reach_4x.sum()))
    rows.append(r)
res = pd.DataFrame(rows); res.to_csv(OUT + '03_mn_summary.csv', index=False)
print(res.round(2).to_string(index=False))
cmp = []
for panel, d in t.groupby('panel'):
    a = d[d.arm == 'mRNA-1010']; b = d[d.arm == 'Fluarix']
    r0 = ratio_ci(a.wk0.values, b.wk0.values); adj = ancova_ratio(d, 'wk4', 'wk0'); adjl = ancova_ratio(d, 'late', 'wk0')
    rf = ratio_ci(a.fr4.values, b.fr4.values)
    mw = stats.mannwhitneyu(a.fr4, b.fr4)
    ka, na, kb, nb = int(a.ge4x.sum()), len(a), int(b.ge4x.sum()), len(b)
    dd, lo, hi = newcombe_diff(ka, na, kb, nb)
    cmp.append(dict(panel=panel, baseline_ratio=r0[0], bl_lo=r0[1], bl_hi=r0[2], bl_p=r0[3],
                    wk4_adj_ratio=adj[0], lo=adj[1], hi=adj[2], p=adj[3], GMFR_ratio=rf[0], GMFR_lo=rf[1], GMFR_hi=rf[2], GMFR_p=rf[3], MW_p_fold=mw.pvalue,
                    late_adj_ratio=adjl[0], late_lo=adjl[1], late_hi=adjl[2], late_p=adjl[3],
                    ge4x_mRNA=f'{ka}/{na}', ge4x_Flu=f'{kb}/{nb}', diff=dd, diff_lo=lo, diff_hi=hi))
cmp = pd.DataFrame(cmp); cmp.to_csv(OUT + '03_mn_between_arm.csv', index=False)
print(cmp.round(3).T.to_string())
# Sensitivity: exclude participants whose baseline makes a 4-fold rise impossible (wk0 > 320)
print('\nSensitivity: restrict to wk0 <= 320 (4-fold rise observable)')
for panel, d in t[t.wk0 <= 320].groupby('panel'):
    a = d[d.arm == 'mRNA-1010']; b = d[d.arm == 'Fluarix']
    rf = ratio_ci(a.fr4.values, b.fr4.values)
    print(panel, 'n', len(a), len(b), 'GMFR mRNA %.2f Flu %.2f ratio %.2f (%.2f-%.2f) p=%.2f' % (gmt_ci(a.fr4)[0], gmt_ci(b.fr4)[0], *rf),
          '>=4x', int(a.ge4x.sum()), '/', len(a), 'vs', int(b.ge4x.sum()), '/', len(b))
t.to_csv(OUT + '03_mn_participant_level.csv', index=False)
# within-arm heterologous vs homologous fold rise
print('\nWithin-participant heterologous/homologous fold-rise ratio (wk4)')
p = t.pivot_table(index=['arm', 'participant'], columns='panel', values='fr4')
p['het_over_hom'] = p.heterologous / p.homologous
for arm, d in p.groupby(level=0):
    g, lo, hi, n = gmt_ci(d.het_over_hom); print(arm, 'GM ratio het/hom fold-rise %.2f (%.2f-%.2f) n=%d' % (g, lo, hi, n))
