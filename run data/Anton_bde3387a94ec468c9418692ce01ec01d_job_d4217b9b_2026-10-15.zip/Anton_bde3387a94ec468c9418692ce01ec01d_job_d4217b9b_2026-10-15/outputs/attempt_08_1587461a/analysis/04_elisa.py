import sys; sys.path.insert(0, '/tmp/outputs/analysis')
from common import *
el = pd.read_csv(FS + 'elisa_igg_titers.csv')
t = el[el.measure == 'ec50'].pivot_table(index=['antigen', 'arm', 'participant'], columns='timepoint', values='value').reset_index()
t['late'] = t['wk17'].fillna(t['wk26'])
t['fr4'] = t.wk4 / t.wk0; t['frL'] = t.late / t.wk0; t['decay'] = t.late / t.wk4
rows = []
for (ag, arm), d in t.groupby(['antigen', 'arm']):
    r = dict(antigen=ag, arm=arm, n=len(d))
    for c in ['wk0', 'wk4', 'late', 'fr4', 'frL', 'decay']:
        g, lo, hi, n = gmt_ci(d[c]); r.update({c: g, c + '_lo': lo, c + '_hi': hi})
    r['n_ge4x'] = int((d.fr4 >= 4).sum())
    rows.append(r)
res = pd.DataFrame(rows); res.to_csv(OUT + '04_elisa_summary.csv', index=False)
print(res.round(2).to_string(index=False))
cmp = []
for ag, d in t.groupby('antigen'):
    a = d[d.arm == 'mRNA-1010']; b = d[d.arm == 'Fluarix']
    r0 = ratio_ci(a.wk0.values, b.wk0.values); adj = ancova_ratio(d, 'wk4', 'wk0'); adjl = ancova_ratio(d, 'late', 'wk0')
    rf = ratio_ci(a.fr4.values, b.fr4.values); rd = ratio_ci(a.decay.values, b.decay.values)
    ka, na, kb, nb = int((a.fr4 >= 4).sum()), len(a), int((b.fr4 >= 4).sum()), len(b)
    dd, lo, hi = newcombe_diff(ka, na, kb, nb)
    cmp.append(dict(antigen=ag, baseline_ratio=r0[0], bl_lo=r0[1], bl_hi=r0[2], bl_p=r0[3],
                    wk4_adj=adj[0], wk4_adj_lo=adj[1], wk4_adj_hi=adj[2], wk4_adj_p=adj[3],
                    GMFR_ratio=rf[0], GMFR_lo=rf[1], GMFR_hi=rf[2], GMFR_p=rf[3],
                    late_adj=adjl[0], late_adj_lo=adjl[1], late_adj_hi=adjl[2], late_adj_p=adjl[3],
                    decay_ratio=rd[0], decay_lo=rd[1], decay_hi=rd[2], decay_p=rd[3],
                    ge4x_mRNA=f'{ka}/{na}', ge4x_Flu=f'{kb}/{nb}', ge4x_diff=dd, ge4x_lo=lo, ge4x_hi=hi))
cmp = pd.DataFrame(cmp); cmp.to_csv(OUT + '04_elisa_between_arm.csv', index=False)
print(cmp.round(3).T.to_string())
t.to_csv(OUT + '04_elisa_participant_level.csv', index=False)
# sub-cohort check: are the 29 serology-subcohort participants representative of the 75?
sub_ids = set(pd.read_csv(FS + 'hai_titers.csv', dtype={'participant': str}).participant.astype(int))
t['in_HAI_subcohort'] = t.participant.isin(sub_ids)
print('\nGMFR wk4 by sub-cohort membership (HAI/MN subset vs remainder)')
for (ag, arm), d in t.groupby(['antigen', 'arm']):
    s1 = d[d.in_HAI_subcohort]; s2 = d[~d.in_HAI_subcohort]
    print(f'{ag:6s} {arm:9s} subset n={len(s1)} GMFR={gmt_ci(s1.fr4)[0]:.2f} | rest n={len(s2)} GMFR={gmt_ci(s2.fr4)[0]:.2f}')
