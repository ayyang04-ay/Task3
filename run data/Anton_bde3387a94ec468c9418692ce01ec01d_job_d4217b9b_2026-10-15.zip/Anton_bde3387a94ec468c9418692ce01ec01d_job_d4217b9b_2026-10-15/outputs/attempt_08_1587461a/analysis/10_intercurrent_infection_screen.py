import sys; sys.path.insert(0, '/tmp/outputs/analysis')
from common import *
# Seq-neut: per participant, per subtype, count viruses with >=4-fold rise from d29 to late (d121/d181)
W = pd.read_csv(OUT + '06_seqneut_long_wide.csv')
W = W.dropna(subset=['d29', 'late'])
W['late_over_d29'] = W.late / W.d29
W['rise4'] = W.late_over_d29 >= 4
W['sub'] = W.virus.str[-4:]
S = W.groupby(['arm', 'pid', 'sub']).agg(n=('virus', 'size'), n_rise4=('rise4', 'sum'), gm_late_over_d29=('late_over_d29', lambda x: np.exp(np.log(x).mean()))).reset_index()
S['frac_rise4'] = S.n_rise4 / S.n
print('Seq-neut: participants with >=25% of viruses of a subtype rising >=4-fold between d29 and d121/d181:')
print(S[S.frac_rise4 >= 0.25].round(2).to_string(index=False))
print('\nDistribution of GM late/d29 by subtype:')
print(S.groupby(['sub', 'arm']).gm_late_over_d29.describe().round(2))
# HAI: >=4-fold rise from wk4 to late
h = pd.read_csv(OUT + '02_hai_participant_level.csv', dtype={'participant': str})
h['late_over_wk4'] = h.late / h.wk4
print('\nHAI: >=4-fold rise wk4 -> wk17/26:'); print(h[h.late_over_wk4 >= 4][['antigen', 'arm', 'participant', 'wk0', 'wk4', 'late']].to_string(index=False))
print('HAI: >=2-fold rise wk4 -> wk17/26 (count by antigen/arm):'); print(h[h.late_over_wk4 >= 2].groupby(['antigen', 'arm']).participant.apply(list))
# MN
mn = pd.read_csv(OUT + '03_mn_participant_level.csv', dtype={'participant': str})
mn['late_over_wk4'] = mn.late / mn.wk4
print('\nMN: >=2-fold rise wk4 -> late:'); print(mn[mn.late_over_wk4 >= 2][['panel', 'arm', 'participant', 'wk0', 'wk4', 'late']].to_string(index=False))
# ELISA
e = pd.read_csv(OUT + '04_elisa_participant_level.csv')
e['late_over_wk4'] = e.late / e.wk4
print('\nELISA: >=2-fold rise wk4 -> late:'); print(e[e.late_over_wk4 >= 2][['antigen', 'arm', 'participant', 'wk0', 'wk4', 'late']].round(0).to_string(index=False))
S.to_csv(OUT + '10_seqneut_late_rise_screen.csv', index=False)
