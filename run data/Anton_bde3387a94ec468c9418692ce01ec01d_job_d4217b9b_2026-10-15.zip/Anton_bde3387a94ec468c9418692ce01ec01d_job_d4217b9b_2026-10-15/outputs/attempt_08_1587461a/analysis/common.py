import pandas as pd, numpy as np
from scipy import stats
FS = '/tmp/world/filesystem/'
OUT = '/tmp/outputs/analysis/'
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 1000); pd.set_option('display.max_columns', 60)

def gmt_ci(x):
    """geometric mean with t-based 95% CI on log scale"""
    x = np.asarray(x, float); x = x[~np.isnan(x)]
    n = len(x)
    if n == 0: return np.nan, np.nan, np.nan, 0
    l = np.log(x); m = l.mean()
    if n < 2: return np.exp(m), np.nan, np.nan, n
    se = l.std(ddof=1) / np.sqrt(n); t = stats.t.ppf(0.975, n - 1)
    return np.exp(m), np.exp(m - t * se), np.exp(m + t * se), n

def ratio_ci(a, b):
    """GM ratio a/b with Welch 95% CI on log scale"""
    a = np.log(np.asarray(a, float)[~np.isnan(a)]); b = np.log(np.asarray(b, float)[~np.isnan(b)])
    d = a.mean() - b.mean()
    va, vb = a.var(ddof=1) / len(a), b.var(ddof=1) / len(b)
    se = np.sqrt(va + vb)
    df = (va + vb) ** 2 / (va ** 2 / (len(a) - 1) + vb ** 2 / (len(b) - 1))
    t = stats.t.ppf(0.975, df)
    p = 2 * stats.t.sf(abs(d / se), df)
    return np.exp(d), np.exp(d - t * se), np.exp(d + t * se), p

def ancova_ratio(df, y, x0, armcol='arm', treat='mRNA-1010'):
    """log-scale ANCOVA: log(y) ~ arm + log(baseline); returns adjusted GM ratio treat/other + 95% CI + p"""
    import statsmodels.formula.api as smf
    d = df[[y, x0, armcol]].dropna().copy()
    d['ly'] = np.log(d[y]); d['lx'] = np.log(d[x0]); d['t'] = (d[armcol] == treat).astype(int)
    m = smf.ols('ly ~ t + lx', data=d).fit()
    b = m.params['t']; lo, hi = m.conf_int().loc['t']
    return np.exp(b), np.exp(lo), np.exp(hi), m.pvalues['t'], len(d)

def newcombe_diff(k1, n1, k2, n2, z=1.959964):
    """Newcombe hybrid score CI for p1 - p2 (method 10)"""
    def wilson(k, n):
        p = k / n; den = 1 + z ** 2 / n
        c = (p + z ** 2 / (2 * n)) / den; h = z * np.sqrt(p * (1 - p) / n + z ** 2 / (4 * n ** 2)) / den
        return c - h, c + h
    p1, p2 = k1 / n1, k2 / n2
    l1, u1 = wilson(k1, n1); l2, u2 = wilson(k2, n2)
    d = p1 - p2
    lo = d - np.sqrt((p1 - l1) ** 2 + (u2 - p2) ** 2)
    hi = d + np.sqrt((u1 - p1) ** 2 + (p2 - l2) ** 2)
    return d, lo, hi

def wilson(k, n, z=1.959964):
    p = k / n; den = 1 + z ** 2 / n
    c = (p + z ** 2 / (2 * n)) / den; h = z * np.sqrt(p * (1 - p) / n + z ** 2 / (4 * n ** 2)) / den
    return p, c - h, c + h
