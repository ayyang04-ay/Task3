import sys; sys.path.insert(0, '/tmp/outputs/analysis')
from common import *
P = pd.read_csv(OUT + '06_seqneut_participant_category.csv')
w29 = P.pivot_table(index=['arm', 'pid'], columns='category', values='mean_l2_d29')
w0 = P.pivot_table(index=['arm', 'pid'], columns='category', values='mean_l2_d0')
rows = []
for lab, fwd, vac in [('H3: forward-drift vs own vaccine strain', 'H3 forward-drift (2022-2024)', 'H3 vaccine strain (Darwin/6 or /9)'),
                      ('H1: 2023 strains vs mRNA-1010 H1 strain', 'H1 contemporary (2023)', 'H1 mRNA-1010 vaccine strain'),
                      ('H1: 2023 strains vs Fluarix H1 strain (cell analogue)', 'H1 contemporary (2023)', 'H1 Fluarix vaccine strain (cell analogue)')]:
    for tp, w in [('d0', w0), ('d29', w29)]:
        r = (w[fwd] - w[vac])
        for arm, x in r.groupby(level=0):
            rows.append(dict(comparison=lab, timepoint=tp, arm=arm, GM_ratio_fwd_over_vaccine=2 ** x.mean(), n=x.notna().sum()))
R = pd.DataFrame(rows); R.to_csv(OUT + '13_relative_breadth.csv', index=False)
print(R.pivot_table(index=['comparison', 'timepoint'], columns='arm', values='GM_ratio_fwd_over_vaccine').round(2).to_string())
# Absolute forward-drift titres at d29 (what matters for protection)
for c in ['H3 forward-drift (2022-2024)', 'H1 contemporary (2023)']:
    for arm in ['Fluarix', 'mRNA-1010']:
        x = w29.loc[arm, c]; print(f'{c} d29 GMT {arm}: {2 ** x.mean():.0f}')
