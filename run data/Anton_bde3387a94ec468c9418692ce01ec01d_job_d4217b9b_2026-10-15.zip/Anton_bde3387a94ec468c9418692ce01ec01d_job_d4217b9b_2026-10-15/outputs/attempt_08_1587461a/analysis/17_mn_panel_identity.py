import sys; sys.path.insert(0, '/tmp/outputs/analysis')
from common import *
mn = pd.read_csv(OUT + '03_mn_participant_level.csv', dtype={'participant': str})
W = pd.read_csv(OUT + '06_seqneut_long_wide.csv')
res = []
for panel in ['homologous', 'heterologous']:
    m = mn[mn.panel == panel].set_index('participant')
    for v, d in W.groupby('virus'):
        d = d.set_index('pid')
        ids = m.index.intersection(d.index)
        x = []; y = []
        for tp_m, tp_s in [('wk0', 'd0'), ('wk4', 'd29')]:
            a = np.log2(m.loc[ids, tp_m]); b = np.log2(d.loc[ids, tp_s]); ok = a.notna() & b.notna()
            x += list(a[ok]); y += list(b[ok])
        # also fold-rise concordance
        fa = np.log2(m.loc[ids, 'fr4']); fb = d.loc[ids, 'l2fc29']; ok = fa.notna() & fb.notna()
        res.append(dict(panel=panel, virus=v, rho_titres=stats.spearmanr(x, y)[0], rho_foldrise=stats.spearmanr(fa[ok], fb[ok])[0], n=int(ok.sum())))
R = pd.DataFrame(res); R.to_csv(OUT + '17_mn_panel_identity.csv', index=False)
for panel, d in R.groupby('panel'):
    print(f'\n{panel}: top 6 by fold-rise concordance'); print(d.sort_values('rho_foldrise', ascending=False).head(6).round(3).to_string(index=False))
    print(f'{panel}: top 6 by titre concordance (wk0+wk4 pooled)'); print(d.sort_values('rho_titres', ascending=False).head(6).round(3).to_string(index=False))
    d = d.assign(sub=d.virus.str[-4:])
    print(d.groupby('sub')[['rho_titres', 'rho_foldrise']].median().round(3))
