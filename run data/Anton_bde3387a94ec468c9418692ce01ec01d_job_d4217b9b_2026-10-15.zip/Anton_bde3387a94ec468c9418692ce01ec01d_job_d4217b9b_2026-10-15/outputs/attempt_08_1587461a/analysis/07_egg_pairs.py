import sys; sys.path.insert(0, '/tmp/outputs/analysis')
from common import *
W = pd.read_csv(OUT + '06_seqneut_long_wide.csv')
pairs = [('A/Cambodia/e0826360/2020_H3N2', 'A/Cambodia/e0826360/2020egg_H3N2'),
         ('A/HongKong/4801/2014_H3N2', 'A/HongKong/4801/2014egg_H3N2'),
         ('A/Singapore/INFIMH-16-0019/2016_H3N2', 'A/Singapore/INFIMH-16-0019/2016X-307A_H3N2'),
         ('A/Switzerland/9715293/2013_H3N2', 'A/Switzerland/9715293/2013NIB-88_H3N2'),
         ('A/Texas/50/2012_H3N2', 'A/Texas/50/2012X-223A_H3N2'),
         ('A/Wisconsin/67/2022_H1N1', 'A/Victoria/4897/2022_IVR-238_H1N1')]   # last: same clade cell vs egg reassortant (not identical strain)
rows = []
for wt, egg in pairs:
    for arm in ['Fluarix', 'mRNA-1010']:
        a = W[(W.virus == wt) & (W.arm == arm)].set_index('pid'); b = W[(W.virus == egg) & (W.arm == arm)].set_index('pid')
        ids = a.index.intersection(b.index)
        # within-participant: log2(d29 titre egg / d29 titre wt) and difference in fold-rise
        r29 = np.log2(b.loc[ids, 'd29'] / a.loc[ids, 'd29']).dropna()
        r0 = np.log2(b.loc[ids, 'd0'] / a.loc[ids, 'd0']).dropna()
        dfr = (b.loc[ids, 'l2fc29'] - a.loc[ids, 'l2fc29']).dropna()
        rows.append(dict(pair=wt.split('_')[0] + ' vs ' + egg.split('/')[-1], arm=arm, n=len(dfr),
                         egg_over_wt_titre_d0=2 ** r0.mean(), egg_over_wt_titre_d29=2 ** r29.mean(),
                         egg_minus_wt_log2FR=dfr.mean(), egg_over_wt_FR=2 ** dfr.mean(),
                         p_paired=stats.ttest_1samp(dfr, 0).pvalue if len(dfr) > 2 else np.nan,
                         GMFR_wt=2 ** a.loc[ids, 'l2fc29'].mean(), GMFR_egg=2 ** b.loc[ids, 'l2fc29'].mean()))
res = pd.DataFrame(rows); res.to_csv(OUT + '07_egg_vs_wt_pairs.csv', index=False)
print(res.round(3).to_string(index=False))
# pooled across the 5 H3 identical-strain pairs: per participant mean of (egg - wt) log2FR, compare arms
P = []
for wt, egg in pairs[:5]:
    a = W[W.virus == wt].set_index(['arm', 'pid']).l2fc29; b = W[W.virus == egg].set_index(['arm', 'pid']).l2fc29
    P.append((b - a).rename(wt))
P = pd.concat(P, axis=1); P['mean'] = P.mean(axis=1)
for arm, d in P.groupby(level=0):
    print(arm, 'mean (egg - wt) log2 fold-rise across 5 H3 pairs: %.3f -> ratio %.2f, n=%d, one-sample p=%.3f' % (d['mean'].mean(), 2 ** d['mean'].mean(), d['mean'].notna().sum(), stats.ttest_1samp(d['mean'].dropna(), 0).pvalue))
x = P.loc['Fluarix', 'mean'].dropna(); y = P.loc['mRNA-1010', 'mean'].dropna()
print('Fluarix vs mRNA difference in egg-preference: Welch p = %.3f' % stats.ttest_ind(x, y, equal_var=False).pvalue)
