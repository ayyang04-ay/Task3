import sys; sys.path.insert(0, '/tmp/outputs/analysis')
from common import *
hai = pd.read_csv(FS + 'hai_titers.csv', dtype={'participant': str})
w = hai.pivot_table(index=['antigen', 'arm', 'participant'], columns='timepoint', values='hai_titer').reset_index()
w['late'] = w['wk17'].fillna(w['wk26'])
# HAI: titers <10 are reported as 7 (half of... ) -> treat 7 as '<10' ; FDA SCR definition: >=4-fold rise, or from <10 to >=40
def scr(r):
    if np.isnan(r.wk0) or np.isnan(r.wk4): return np.nan
    if r.wk0 < 10: return float(r.wk4 >= 40)
    # titres include geometric midpoints reported rounded (28=20*sqrt2, 57=40*sqrt2, 113, 226=160*sqrt2 ...);
    # a true 4-fold rise such as 57->226 computes as 3.96, so use a rounding tolerance of 3.9
    return float(r.wk4 / r.wk0 >= 3.9)
w['scr4'] = w.apply(scr, axis=1)
w['sp40_wk0'] = (w.wk0 >= 40).astype(float).where(w.wk0.notna())
w['sp40_wk4'] = (w.wk4 >= 40).astype(float).where(w.wk4.notna())
w['gmfr4'] = w.wk4 / w.wk0
w['fr_late'] = w.late / w.wk0
rows = []
for (ag, arm), d in w.groupby(['antigen', 'arm']):
    r = dict(antigen=ag, arm=arm)
    for tp in ['wk0', 'wk4', 'late']:
        g, lo, hi, n = gmt_ci(d[tp]); r.update({f'GMT_{tp}': g, f'GMT_{tp}_lo': lo, f'GMT_{tp}_hi': hi, f'n_{tp}': n})
    g, lo, hi, n = gmt_ci(d.gmfr4); r.update(GMFR_wk4=g, GMFR_wk4_lo=lo, GMFR_wk4_hi=hi)
    g, lo, hi, n = gmt_ci(d.fr_late); r.update(GMFR_late=g, GMFR_late_lo=lo, GMFR_late_hi=hi)
    k = int(d.scr4.sum()); n = int(d.scr4.notna().sum()); p, lo, hi = wilson(k, n)
    r.update(SCR_k=k, SCR_n=n, SCR=p, SCR_lo=lo, SCR_hi=hi)
    k = int(d.sp40_wk4.sum()); n = int(d.sp40_wk4.notna().sum()); p, lo, hi = wilson(k, n)
    r.update(SP40_wk4_k=k, SP40_wk4_n=n, SP40_wk4=p, SP40_wk4_lo=lo)
    k = int(d.sp40_wk0.sum()); n = int(d.sp40_wk0.notna().sum()); r.update(SP40_wk0_k=k, SP40_wk0_n=n)
    rows.append(r)
res = pd.DataFrame(rows)
res.to_csv(OUT + '02_hai_summary_by_arm.csv', index=False)
cols = ['antigen', 'arm', 'n_wk0', 'GMT_wk0', 'GMT_wk4', 'GMT_wk4_lo', 'GMT_wk4_hi', 'GMFR_wk4', 'GMFR_wk4_lo', 'GMFR_wk4_hi', 'SCR_k', 'SCR_n', 'SCR', 'SCR_lo', 'SCR_hi', 'SP40_wk0_k', 'SP40_wk4_k', 'SP40_wk4_n', 'GMT_late', 'n_late', 'GMFR_late']
print(res[cols].round(2).to_string(index=False))

# Between-arm comparisons
cmp = []
for ag, d in w.groupby('antigen'):
    a = d[d.arm == 'mRNA-1010']; b = d[d.arm == 'Fluarix']
    r0 = ratio_ci(a.wk0.values, b.wk0.values)
    r4 = ratio_ci(a.wk4.values, b.wk4.values)
    adj = ancova_ratio(d, 'wk4', 'wk0')
    rf = ratio_ci(a.gmfr4.values, b.gmfr4.values)
    rl = ratio_ci(a.late.values, b.late.values)
    adjl = ancova_ratio(d, 'late', 'wk0')
    ka, na = int(a.scr4.sum()), int(a.scr4.notna().sum()); kb, nb = int(b.scr4.sum()), int(b.scr4.notna().sum())
    dd, dlo, dhi = newcombe_diff(ka, na, kb, nb)
    cmp.append(dict(antigen=ag, base_ratio=r0[0], base_lo=r0[1], base_hi=r0[2], base_p=r0[3],
                    wk4_ratio_unadj=r4[0], wk4_lo=r4[1], wk4_hi=r4[2], wk4_p=r4[3],
                    wk4_ratio_adj=adj[0], wk4_adj_lo=adj[1], wk4_adj_hi=adj[2], wk4_adj_p=adj[3],
                    GMFR_ratio=rf[0], GMFR_lo=rf[1], GMFR_hi=rf[2], GMFR_p=rf[3],
                    late_ratio_adj=adjl[0], late_adj_lo=adjl[1], late_adj_hi=adjl[2], late_adj_p=adjl[3],
                    SCR_mRNA=f'{ka}/{na}', SCR_Flu=f'{kb}/{nb}', SCR_diff_mRNA_minus_Flu=dd, SCR_diff_lo=dlo, SCR_diff_hi=dhi,
                    NI_GMTratio_Flu_over_mRNA_upper95=1 / adj[1], NI_SCRdiff_Flu_minus_mRNA_upper95=-dlo))
cmp = pd.DataFrame(cmp)
cmp.to_csv(OUT + '02_hai_between_arm.csv', index=False)
print('\nBetween-arm (mRNA-1010 / Fluarix); adj = ANCOVA on log titre adjusting for log baseline')
print(cmp.round(3).T.to_string())
w.to_csv(OUT + '02_hai_participant_level.csv', index=False)
