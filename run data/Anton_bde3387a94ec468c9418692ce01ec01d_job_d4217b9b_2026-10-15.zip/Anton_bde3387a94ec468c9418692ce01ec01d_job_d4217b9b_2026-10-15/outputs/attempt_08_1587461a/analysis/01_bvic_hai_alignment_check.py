"""
QC check: is the B/Vic block of hai_titers.csv participant-aligned with the other antigens?
Evidence 1: visit attendance (wk17 vs wk26) must be a participant-level attribute, identical across antigens
            and across assay files (MN, ELISA).
Evidence 2: per-participant HAI should correlate with same-antigen ELISA IgG EC50 from the same participant.
            Compare correlation under the file's labels vs under a +1 positional shift.
"""
import pandas as pd, numpy as np
from scipy import stats
FS = '/tmp/world/filesystem/'
hai = pd.read_csv(FS+'hai_titers.csv', dtype={'participant': str})
mn = pd.read_csv(FS+'microneutralization.csv', dtype={'participant': str})
el = pd.read_csv(FS+'elisa_igg_titers.csv')
el['participant'] = el.participant.astype(int).map(lambda x: f'{x:03d}')

print('--- Evidence 1: wk17 attendees by source ---')
for ag in hai.antigen.unique():
    print('HAI', ag, sorted(hai[(hai.antigen == ag) & (hai.timepoint == 'wk17')].participant))
print('MN ', sorted(set(mn[mn.timepoint == 'wk17'].participant.str[-3:])))
print('ELISA', sorted(set(el[el.timepoint == 'wk17'].participant)))

# canonical participant order (as listed in the file: Fluarix then mRNA, ascending)
order = (hai[(hai.antigen == 'A/H1N1') & (hai.timepoint == 'wk0')]
         .sort_values(['arm', 'participant'])[['arm', 'participant']].values.tolist())
ids = [p for _, p in order]
arm_of = {p: a for a, p in order}
print('\ncanonical order (n=%d):' % len(ids), ids)

def ellookup(ag, tp):
    d = el[(el.antigen == ag) & (el.timepoint == tp) & (el.measure == 'ec50')]
    return dict(zip(d.participant, d.value))

print('\n--- Evidence 2: Spearman rho, log HAI vs log ELISA EC50, same antigen, same participant ---')
pairs = {'A/H1N1': 'A/H1', 'A/H3N2': 'A/H3', 'B/Yam': 'B/Yam', 'B/Vic': 'B/Vic'}
rows = []
for hag, eag in pairs.items():
    for tp in ['wk0', 'wk4']:
        h = hai[(hai.antigen == hag) & (hai.timepoint == tp)]
        hv = dict(zip(h.participant, h.hai_titer))
        ev = ellookup(eag, tp)
        for shift in [0, 1, -1]:
            xs, ys = [], []
            for i, p in enumerate(ids):
                if p not in hv: continue
                j = i + shift
                if j < 0 or j >= len(ids): continue
                q = ids[j]            # hypothesis: value labelled p actually belongs to participant q
                if q in ev:
                    xs.append(np.log2(hv[p])); ys.append(np.log2(ev[q]))
            r, pval = stats.spearmanr(xs, ys)
            rows.append(dict(hai_antigen=hag, timepoint=tp, shift=shift, n=len(xs), rho=round(r, 3), p=round(pval, 4)))
res = pd.DataFrame(rows)
print(res.pivot_table(index=['hai_antigen', 'timepoint'], columns='shift', values='rho').to_string())
res.to_csv('/tmp/outputs/analysis/01_bvic_alignment_correlations.csv', index=False)

# wk4/wk0 fold-rise concordance (HAI vs ELISA) under each alignment
print('\n--- fold-rise concordance (wk4/wk0), Spearman rho ---')
for hag, eag in pairs.items():
    h = hai[hai.antigen == hag].pivot_table(index='participant', columns='timepoint', values='hai_titer')
    hfr = (h.wk4 / h.wk0).dropna().to_dict()
    e0, e4 = ellookup(eag, 'wk0'), ellookup(eag, 'wk4')
    for shift in [0, 1]:
        xs, ys = [], []
        for i, p in enumerate(ids):
            if p not in hfr: continue
            j = i + shift
            if j >= len(ids): continue
            q = ids[j]
            if q in e0 and q in e4:
                xs.append(np.log2(hfr[p])); ys.append(np.log2(e4[q] / e0[q]))
        r, pval = stats.spearmanr(xs, ys)
        print(f'{hag:7s} shift={shift:+d} n={len(xs)} rho={r:.3f} p={pval:.4f}')

print('\n--- Late-visit-only hypothesis: B/Vic wk17/wk26 labels swapped within pairs (007<->009, 016<->018, 008<->010, 021<->023) ---')
swap = {'007': '009', '009': '007', '016': '018', '018': '016', '008': '010', '010': '008', '021': '023', '023': '021'}
el_late = el[(el.measure == 'ec50') & (el.timepoint.isin(['wk17', 'wk26']))]
el_late = dict(zip(el_late[el_late.antigen == 'B/Vic'].participant, el_late[el_late.antigen == 'B/Vic'].value))
h = hai[(hai.antigen == 'B/Vic') & (hai.timepoint.isin(['wk17', 'wk26']))]
for name, mapping in [('as labelled', {}), ('pairs swapped', swap)]:
    xs, ys = [], []
    for p, v in zip(h.participant, h.hai_titer):
        q = mapping.get(p, p)
        if q in el_late:
            xs.append(np.log2(v)); ys.append(np.log2(el_late[q]))
    r, pval = stats.spearmanr(xs, ys)
    print(f'{name:15s} n={len(xs)} rho={r:.3f} p={pval:.3f}')
# reference: other antigens, late visit, as labelled
for hag, eag in [('A/H1N1', 'A/H1'), ('A/H3N2', 'A/H3'), ('B/Yam', 'B/Yam')]:
    e2 = el[(el.measure == 'ec50') & (el.timepoint.isin(['wk17', 'wk26'])) & (el.antigen == eag)]
    e2 = dict(zip(e2.participant, e2.value))
    h2 = hai[(hai.antigen == hag) & (hai.timepoint.isin(['wk17', 'wk26']))]
    xs = [np.log2(v) for p, v in zip(h2.participant, h2.hai_titer) if p in e2]
    ys = [np.log2(e2[p]) for p in h2.participant if p in e2]
    r, pval = stats.spearmanr(xs, ys)
    print(f'reference {hag:7s} late n={len(xs)} rho={r:.3f} p={pval:.3f}')
