import sys; sys.path.insert(0, '/tmp/outputs/analysis')
from common import *
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import NullFormatter, NullLocator
FIG = '/tmp/outputs/figures/'; import os; os.makedirs(FIG, exist_ok=True)
# ---------- Figure 1: forest of baseline-adjusted mRNA-1010 / Fluarix ratios, peak (wk4/d29) and late (wk17/26 or d121/181)
el = pd.read_csv(OUT + '04_elisa_between_arm.csv'); hai = pd.read_csv(OUT + '02_hai_between_arm.csv'); mn = pd.read_csv(OUT + '03_mn_between_arm.csv')
sq = pd.read_csv(OUT + '06_seqneut_category_summary.csv')
rows = []
for _, r in el.iterrows():
    rows.append(('Binding IgG ELISA (n=38/37)', f'{r.antigen}', r.wk4_adj, r.wk4_adj_lo, r.wk4_adj_hi, r.late_adj, r.late_adj_lo, r.late_adj_hi))
for _, r in hai.iterrows():
    flag = ' [QC fail]' if r.antigen == 'B/Vic' else ''
    rows.append(('HAI (n=14/15)', r.antigen + flag, r.wk4_ratio_adj, r.wk4_adj_lo, r.wk4_adj_hi, r.late_ratio_adj, r.late_adj_lo, r.late_adj_hi))
for _, r in mn.iterrows():
    rows.append(('Microneutralisation (n=14/15)', f'"{r.panel}" panel', r.wk4_adj_ratio, r.lo, r.hi, r.late_adj_ratio, r.late_lo, r.late_hi))
order = ['H1 mRNA-1010 vaccine strain', 'H1 Fluarix vaccine strain (cell analogue)', 'H1 historical (2009-2019)', 'H1 contemporary (2023)',
         'H3 vaccine strain (Darwin/6 or /9)', 'H3 historical (2012-2020)', 'H3 forward-drift (2022-2024)']
for c in order:
    r = sq[sq.category == c].iloc[0]
    rows.append(('Seq-based neutralisation (n=13/14)', f'{c} [{int(r.nvir)} virus{"es" if r.nvir > 1 else ""}]', r.adj_d29_ratio, r.adj_lo, r.adj_hi, r.adj_late_ratio, r.adj_late_lo, r.adj_late_hi))
F = pd.DataFrame(rows, columns=['family', 'readout', 'peak', 'peak_lo', 'peak_hi', 'late', 'late_lo', 'late_hi'])
F.to_csv(OUT + '15_forest_data.csv', index=False)
fig, axes = plt.subplots(1, 2, figsize=(15, 9), sharey=True)
y = np.arange(len(F))[::-1]
for ax, (c, lo, hi, title) in zip(axes, [('peak', 'peak_lo', 'peak_hi', 'Peak: wk4 / day 29'), ('late', 'late_lo', 'late_hi', 'Late: wk17/26 or day 121/181')]):
    col = ['tab:blue' if f.startswith('Binding') else 'tab:red' for f in F.family]
    for yi, (_, r), cc in zip(y, F.iterrows(), col):
        ax.plot([r[lo], r[hi]], [yi, yi], color=cc, lw=2); ax.plot(r[c], yi, 'o', color=cc)
    ax.axvline(1, color='k', ls='--', lw=1); ax.set_xscale('log'); ax.set_xlim(0.2, 6)
    ax.xaxis.set_minor_locator(NullLocator()); ax.xaxis.set_minor_formatter(NullFormatter()); ax.set_xticks([0.25, 0.5, 1, 2, 4]); ax.set_xticklabels(['0.25', '0.5', '1', '2', '4'])
    ax.set_title(title); ax.set_xlabel('mRNA-1010 / Fluarix, baseline-adjusted GM ratio (95% CI)')
axes[0].set_yticks(y); axes[0].set_yticklabels([f'{r.family}: {r.readout}' for _, r in F.iterrows()], fontsize=8)
fig.suptitle('WU397: binding antibody (blue) vs functional antibody (red). Ratios >1 favour mRNA-1010.\nNon-randomised, open-label; H1 antigens differ between arms; assay strains for HAI/MN/ELISA not specified in the package', fontsize=10)
plt.tight_layout(); plt.savefig(FIG + 'fig1_forest_binding_vs_function.png', dpi=150); plt.close()
# ---------- Figure 2: H3 breadth landscape by isolation year
L = pd.read_csv(OUT + '12_h3_year_landscape.csv')
fig, ax = plt.subplots(figsize=(8, 4.5))
x = np.arange(len(L))
ax.errorbar(x, L.adj_d29_ratio, yerr=[L.adj_d29_ratio - L.lo, L.hi - L.adj_d29_ratio], fmt='o', color='tab:red', capsize=4)
ax.axhline(1, color='k', ls='--', lw=1); ax.set_yscale('log'); ax.yaxis.set_minor_locator(NullLocator()); ax.yaxis.set_minor_formatter(NullFormatter()); ax.set_yticks([0.33, 0.5, 1, 2, 3]); ax.set_yticklabels(['0.33', '0.5', '1', '2', '3'])
ax.set_xticks(x); ax.set_xticklabels([f'{a}\n({n} virus{"es" if n > 1 else ""})' for a, n in zip(L.isolation_years.str.replace(' (vaccine: Darwin/6, Darwin/9)', '\nvaccine strains'), L.n_viruses)], fontsize=8)
ax.set_ylabel('mRNA-1010 / Fluarix d29 neutralising GMT\n(baseline-adjusted, 95% CI)')
ax.set_title('H3N2 neutralisation by virus isolation year (wild-type viruses)\nmRNA-1010 advantage is backward (historical strains), not forward (drifted strains)', fontsize=10)
plt.tight_layout(); plt.savefig(FIG + 'fig2_h3_breadth_by_year.png', dpi=150); plt.close()
# ---------- Figure 3: GC block A kinetics
g = pd.read_csv(FS + 'gc_frequencies.csv', dtype={'participant': str}); g['block'] = np.where(np.arange(len(g)) < 78, 'A', 'B')
tps = ['wk0', 'wk2', 'wk8', 'wk17', 'wk26']
fig, axes = plt.subplots(1, 2, figsize=(11, 4), sharey=True)
for ax, blk in zip(axes, ['A', 'B']):
    d = g[g.block == blk]
    for (arm, pid), x in d.groupby(['arm', 'participant']):
        x = x.set_index('timepoint').reindex(tps)
        ax.plot(range(5), x.pct_ha_specific_igg_gc, '-o', ms=3, color='tab:blue' if arm == 'mRNA-1010' else 'tab:orange', alpha=.7, label=arm)
    h, l = ax.get_legend_handles_labels(); u = dict(zip(l, h)); ax.legend(u.values(), u.keys(), fontsize=8)
    ax.set_xticks(range(5)); ax.set_xticklabels(tps); ax.set_title(f'gc_frequencies.csv rows {"1-78" if blk == "A" else "79-156"} (unlabelled block {blk})', fontsize=9)
axes[0].set_ylabel('% HA-specific of IgG GC B cells')
fig.suptitle('Lymph-node GC responses (FNA; n=6 mRNA-1010, 11 Fluarix). Timepoint labels do not match protocol FNA schedule (wk1,2,4,8,17,26).', fontsize=9)
plt.tight_layout(); plt.savefig(FIG + 'fig3_gc_kinetics.png', dpi=150); plt.close()
print('figures written')
