import sys; sys.path.insert(0, '/tmp/outputs/analysis')
from common import *
e = pd.read_csv(OUT + '04_elisa_participant_level.csv')
e['pid'] = e.participant.map(lambda x: f'397-{int(x):03d}')
P = pd.read_csv(OUT + '06_seqneut_participant_category.csv')
rows = []
for ag, cat in [('A/H1', 'H1 mRNA-1010 vaccine strain'), ('A/H3', 'H3 vaccine strain (Darwin/6 or /9)'), ('A/H3', 'H3 forward-drift (2022-2024)'), ('A/H1', 'H1 contemporary (2023)')]:
    x = e[e.antigen == ag][['arm', 'pid', 'fr4']].merge(P[P.category == cat][['arm', 'pid', 'mean_l2fc29']], on=['arm', 'pid'])
    x['l2_bind_fr'] = np.log2(x.fr4)
    x['bind_minus_neut'] = x.l2_bind_fr - x.mean_l2fc29     # log2(binding fold-rise / neutralisation fold-rise)
    for arm, d in x.groupby('arm'):
        rows.append(dict(binding_antigen=ag, neut_category=cat, arm=arm, n=len(d), binding_GMFR=2 ** d.l2_bind_fr.mean(), neut_GMFR=2 ** d.mean_l2fc29.mean(),
                         binding_over_neut_foldrise=2 ** d.bind_minus_neut.mean(), spearman_bind_vs_neut=stats.spearmanr(d.l2_bind_fr, d.mean_l2fc29)[0]))
    a = x[x.arm == 'mRNA-1010'].bind_minus_neut; f = x[x.arm == 'Fluarix'].bind_minus_neut
    rows[-1]['p_arm_diff'] = stats.ttest_ind(a, f, equal_var=False).pvalue
R = pd.DataFrame(rows); R.to_csv(OUT + '14_binding_vs_neutralisation.csv', index=False)
print(R.round(3).to_string(index=False))
