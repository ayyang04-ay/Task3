import sys; sys.path.insert(0, '/tmp/outputs/analysis')
from common import *
L = []
def add(id_, claim, value, source, script):
    L.append(dict(id=id_, quantity=claim, value=value, source_files=source, computed_in=script))
f = lambda x, d=2: f'{x:.{d}f}'
# HAI
h = pd.read_csv(OUT + '02_hai_summary_by_arm.csv'); hc = pd.read_csv(OUT + '02_hai_between_arm.csv')
for _, r in h.iterrows():
    add(f'HAI-{r.antigen}-{r.arm}', f'HAI {r.antigen} {r.arm}: GMT wk0 / wk4 (95% CI); GMFR wk4; seroconversion k/n; >=1:40 at wk4',
        f'{f(r.GMT_wk0,1)} / {f(r.GMT_wk4,1)} ({f(r.GMT_wk4_lo,1)}-{f(r.GMT_wk4_hi,1)}); GMFR {f(r.GMFR_wk4)} ({f(r.GMFR_wk4_lo)}-{f(r.GMFR_wk4_hi)}); SCR {int(r.SCR_k)}/{int(r.SCR_n)}; SP40 {int(r.SP40_wk4_k)}/{int(r.SP40_wk4_n)}',
        'hai_titers.csv', '02_hai.py')
for _, r in hc.iterrows():
    add(f'HAI-{r.antigen}-cmp', f'HAI {r.antigen}: mRNA/Fluarix wk4 GMT ratio, ANCOVA-adjusted for baseline (95% CI, p); late (wk17/26) adjusted ratio; SCR difference (Newcombe 95% CI)',
        f'{f(r.wk4_ratio_adj)} ({f(r.wk4_adj_lo)}-{f(r.wk4_adj_hi)}, p={f(r.wk4_adj_p,3)}); late {f(r.late_ratio_adj)} ({f(r.late_adj_lo)}-{f(r.late_adj_hi)}); SCR diff {f(100*r.SCR_diff_mRNA_minus_Flu,1)} pts ({f(100*r.SCR_diff_lo,1)} to {f(100*r.SCR_diff_hi,1)})',
        'hai_titers.csv', '02_hai.py')
# MN
m = pd.read_csv(OUT + '03_mn_summary.csv'); mc = pd.read_csv(OUT + '03_mn_between_arm.csv')
for _, r in m.iterrows():
    add(f'MN-{r.panel}-{r.arm}', f'MN "{r.panel}" {r.arm}: GMT wk0 / wk4; GMFR wk4 (95% CI); n >=4-fold; n at 1280 ceiling at wk0 / wk4',
        f'{f(r.GMT_wk0,1)} / {f(r.GMT_wk4,1)}; GMFR {f(r.GMFR4)} ({f(r.GMFR4_lo)}-{f(r.GMFR4_hi)}); {int(r.n_ge4x)}/{int(r.n)}; ceiling {int(r.n_at_ULOQ_wk0)} / {int(r.n_at_ULOQ_wk4)}', 'microneutralization.csv', '03_mn.py')
for _, r in mc.iterrows():
    add(f'MN-{r.panel}-cmp', f'MN "{r.panel}": baseline GMT ratio mRNA/Fluarix (95% CI, p); wk4 adjusted ratio; late adjusted ratio',
        f'baseline {f(r.baseline_ratio)} ({f(r.bl_lo)}-{f(r.bl_hi)}, p={f(r.bl_p,3)}); wk4 {f(r.wk4_adj_ratio)} ({f(r.lo)}-{f(r.hi)}); late {f(r.late_adj_ratio)} ({f(r.late_lo)}-{f(r.late_hi)})', 'microneutralization.csv', '03_mn.py')
# ELISA
e = pd.read_csv(OUT + '04_elisa_summary.csv'); ec = pd.read_csv(OUT + '04_elisa_between_arm.csv')
for _, r in e.iterrows():
    add(f'ELISA-{r.antigen}-{r.arm}', f'ELISA IgG {r.antigen} {r.arm}: GMFR wk4; late/wk4 decay ratio; n >=4-fold',
        f'GMFR {f(r.fr4)} ({f(r.fr4_lo)}-{f(r.fr4_hi)}); decay {f(r.decay)}; {int(r.n_ge4x)}/{int(r.n)}', 'elisa_igg_titers.csv', '04_elisa.py')
for _, r in ec.iterrows():
    add(f'ELISA-{r.antigen}-cmp', f'ELISA IgG {r.antigen}: wk4 adjusted GMT ratio mRNA/Fluarix (95% CI); late adjusted; decay ratio',
        f'{f(r.wk4_adj)} ({f(r.wk4_adj_lo)}-{f(r.wk4_adj_hi)}); late {f(r.late_adj)} ({f(r.late_adj_lo)}-{f(r.late_adj_hi)}); decay ratio {f(r.decay_ratio)} ({f(r.decay_lo)}-{f(r.decay_hi)})', 'elisa_igg_titers.csv', '04_elisa.py')
# bead array
b = pd.read_csv(OUT + '05_binding_breadth_by_strain.csv')
for _, r in b.iterrows():
    add(f'BEAD-{r.strain}', f'Bead-array {r.subtype} {r.strain}: mean fold-rise MFI mRNA vs Fluarix; ratio; Welch p (Holm)',
        f'{f(r.mRNA_fold)} vs {f(r.Flu_fold)}; ratio {f(r.ratio_fold)}; p={r.welch_p:.2g} (Holm {r.welch_p_holm:.2g})', f'binding_breadth_{r.subtype.lower()}.csv', '05_binding_breadth.py')
# seq-neut categories
s = pd.read_csv(OUT + '06_seqneut_category_summary.csv')
for _, r in s.iterrows():
    add(f'SEQ-{r.category}', f'Seq-neut {r.category} ({int(r.nvir)} viruses): d0 GMT m/f; d29 GMT m/f; GMFR m/f; mean fraction >=4x m/f; d29 adjusted ratio (95% CI, p); late adjusted ratio',
        f'd0 {f(r.GMT_d0_m,0)}/{f(r.GMT_d0_f,0)}; d29 {f(r.GMT_d29_m,0)}/{f(r.GMT_d29_f,0)}; GMFR {f(r.GMFR_m)}/{f(r.GMFR_f)}; >=4x {f(100*r.frac4x_m,1)}%/{f(100*r.frac4x_f,1)}%; adj {f(r.adj_d29_ratio)} ({f(r.adj_lo)}-{f(r.adj_hi)}, p={f(r.adj_p,3)}); late {f(r.adj_late_ratio)} ({f(r.adj_late_lo)}-{f(r.adj_late_hi)})',
        'neutralization_seqbased.csv', '06_seqneut.py')
y = pd.read_csv(OUT + '12_h3_year_landscape.csv')
for _, r in y.iterrows():
    add(f'SEQ-H3-year-{r.isolation_years}', f'Seq-neut H3 wild-type viruses isolated {r.isolation_years}: d29 adjusted ratio mRNA/Fluarix',
        f'{f(r.adj_d29_ratio)} ({f(r.lo)}-{f(r.hi)}, p={f(r.p,3)}), {int(r.n_viruses)} viruses', 'neutralization_seqbased.csv', '12_seqneut_robustness.py')
eg = pd.read_csv(OUT + '07_egg_vs_wt_pairs.csv')
for _, r in eg.iterrows():
    add(f'EGG-{r.pair}-{r.arm}', f'Egg/WT pair {r.pair} {r.arm}: baseline titre egg/WT; fold-rise egg/WT (paired p)',
        f'{f(r.egg_over_wt_titre_d0)}; {f(r.egg_over_wt_FR)} (p={f(r.p_paired,3)})', 'neutralization_seqbased.csv', '07_egg_pairs.py')
bf = pd.read_csv(OUT + '14_binding_vs_neutralisation.csv')
for _, r in bf.iterrows():
    add(f'BIND/NEUT-{r.binding_antigen}-{r.neut_category}-{r.arm}', f'Binding fold-rise / neutralisation fold-rise, {r.binding_antigen} vs {r.neut_category}, {r.arm}',
        f'{f(r.binding_GMFR)} / {f(r.neut_GMFR)} = {f(r.binding_over_neut_foldrise)}' + (f' (arm difference p={r.p_arm_diff:.2g})' if not np.isnan(r.p_arm_diff) else ''), 'elisa_igg_titers.csv + neutralization_seqbased.csv', '14_binding_vs_function.py')
ss = pd.read_csv(OUT + '11_sample_size_continuous.csv')
for _, r in ss.iterrows():
    add(f'SS-{r.endpoint}-{r.target_ratio}', f'Sample size/arm (90% power, 2-sided 0.05): {r.endpoint}, target ratio {r.target_ratio}; residual SD (log2)',
        f'{int(r.n_per_arm_90pct)} (using raw SD: {int(r.n_per_arm_90pct_raw_sd)}); SD {f(r.sd_log2_resid)}', 'derived from HAI / seq-neut variance', '11_sample_size.py')
led = pd.DataFrame(L); led.to_csv('/tmp/outputs/numbers_ledger.csv', index=False)
print(len(led), 'rows written to /tmp/outputs/numbers_ledger.csv')
print(led[led.id.str.startswith(('HAI-A/H1N1-cmp', 'SEQ-H3 forward', 'SEQ-H1 contemporary', 'ELISA-A/H3-cmp'))].to_string(index=False))

# ---- cellular, mAb, QC, planning assumptions (values transcribed from script outputs 08, 09, 01, 11)
extra = [
 ('GC-A-peak', 'GC block A (gc_frequencies.csv rows 1-78): median peak post-vaccination % HA-specific of IgG GC B cells, mRNA (n=6) vs Fluarix (n=11); Mann-Whitney p', '24.7% (range 16.0-38.7) vs 4.7% (0.24-19.2); p=0.001', 'gc_frequencies.csv', '08_cellular.py'),
 ('GC-A-late', 'GC block A: median max(wk17, wk26), mRNA (n=5) vs Fluarix (n=9); p', '24.9% vs 2.3%; p=0.004', 'gc_frequencies.csv', '08_cellular.py'),
 ('GC-B-peak', 'GC block B (rows 79-156): median peak, mRNA vs Fluarix; p', '3.2% vs 0.01%; p=0.014', 'gc_frequencies.csv', '08_cellular.py'),
 ('PB-peak', 'plasmablast_frequencies.csv: median peak post-vaccination %, mRNA (n=13) vs Fluarix (n=15); p', '0.176 vs 0.032; p=0.21', 'plasmablast_frequencies.csv', '08_cellular.py'),
 ('PBGC-overlap', 'Share of GC B-cell clones also present among wk1 plasmablast clones: mRNA donors 06/17/28/29; Fluarix donors 05/09/22 (GC clones n=7/5/1)', '92% / 91% / 83% / 73%; 100% / 20% / 0%', 'pb_gc_clonal_overlap.csv', '08_cellular.py'),
 ('REP-vacc-clonotypes', 'Vaccine-elicited serum clonotypes, median mRNA vs Fluarix (n=8/arm; no participant IDs); p', '32.0 vs 17.5; p=0.066', 'repertoire_clonotype_counts.csv', '08_cellular.py'),
 ('REP-serum-wk4', 'Serum IgG clonotypes at wk4, median mRNA vs Fluarix (n=8/arm); p', '97.5 vs 76.0; p=0.009', 'serum_igg_clonotypes.csv', '08_cellular.py'),
 ('REP-CDRH3-wk4', 'CDRH3 diversity index wk4, median mRNA vs Fluarix (n=8/arm); p', '70.8 vs 24.5; p=0.010', 'cdrh3_diversity_index.csv', '08_cellular.py'),
 ('IGM-H3', 'IgM fold-change H3, GM mRNA vs Fluarix; p (timepoint not stated in file)', '1.83 vs 5.53; p=0.013', 'igm_fold_change.csv', '08_cellular.py'),
 ('MAB-n', 'mAbs: mRNA 589 from 4 donors (06:200, 17:162, 28:53, 29:174); Fluarix 106 from 3 donors (05:84, 09:11, 22:11)', '589 / 106', 'mab_binding_panels.csv', '09_mabs.py'),
 ('MAB-HK68', 'Donor-mean share of group-II mAbs binding A/Hong Kong/1/1968 (>=3-fold over control), mRNA vs Fluarix', '0.51 vs 0.05', 'mab_binding_panels.csv', '09_mabs.py'),
 ('MAB-Thai', 'Donor-mean share binding A/Thailand/8/2022, mRNA vs Fluarix', '0.89 vs 0.35', 'mab_binding_panels.csv', '09_mabs.py'),
 ('MAB-Croatia', 'Donor-mean share binding A/Croatia/10136RV/2023, mRNA vs Fluarix', '0.77 vs 0.25', 'mab_binding_panels.csv', '09_mabs.py'),
 ('MAB-H7', 'Donor-mean share binding H7 A/Shanghai/1/2013, mRNA vs Fluarix', '0.13 vs 0.00', 'mab_binding_panels.csv', '09_mabs.py'),
 ('MAB-H5', 'Donor-mean share binding H5 A/Hubei/1/2010, mRNA vs Fluarix', '0.21 vs 0.37', 'mab_binding_panels.csv', '09_mabs.py'),
 ('MAB-minp', 'Smallest attainable two-sided exact Mann-Whitney p with 4 vs 3 donors', '0.057 (=2/35)', 'combinatorial', '09_mabs.py'),
 ('QC-BVic-wk17', 'HAI wk17 attendees: B/Vic block vs H1N1/H3N2/B-Yam blocks, MN and ELISA', 'B/Vic {F007,F016,M008,M021}; all others {F009,F018,M010,M023}', 'hai_titers.csv; microneutralization.csv; elisa_igg_titers.csv', '01_bvic_hai_alignment_check.py'),
 ('QC-BVic-n', 'HAI B/Vic values per arm (wk0)', 'Fluarix 15, mRNA 13 (M-031 absent)', 'hai_titers.csv', '02_hai.py'),
 ('QC-BVic-rho', 'Spearman rho HAI vs ELISA same antigen, wk4: H1N1 / B-Yam / H3N2 / B-Vic', '0.73 / 0.46 / 0.29 / -0.01', 'hai_titers.csv; elisa_igg_titers.csv', '01_bvic_hai_alignment_check.py'),
 ('QC-GC-blocks', 'gc_frequencies.csv rows vs participant-timepoints', '156 rows = 2 x 78 unlabelled blocks (13 rows exact duplicates, mostly zeros)', 'gc_frequencies.csv', '08_cellular.py'),
 ('QC-FNA-tp', 'FNA timepoints: protocol vs file', 'protocol wk1,2,4,8,17,26; file wk0,2,8,17,26', 'trial_summary.md; gc_frequencies.csv', 'manual'),
 ('QC-PB', 'plasmablast_frequencies.csv participants / timepoints vs protocol blood schedule (d0,7,29,121,181)', '28 participants (11 outside FNA cohort) at wk0,2,8,17,26', 'plasmablast_frequencies.csv; trial_summary.md', '08_cellular.py'),
 ('QC-IgM', 'IgM cohort vs stated', '15 Fluarix / 14 mRNA in file vs 37/38 stated; one ID "20"', 'igm_fold_change.csv; trial_summary.md', '08_cellular.py'),
 ('QC-seq-late', 'Seq-neut late sample for F-007 and F-011', 'd121 (HAI/MN/ELISA used wk26 for both)', 'neutralization_seqbased.csv', 'manual'),
 ('QC-MN-ceiling', 'MN homologous panel at 1280 ceiling at wk4: Fluarix / mRNA', '9/15 / 4/14', 'microneutralization.csv', '03_mn.py'),
 ('QC-HAI-SCR-rule', 'HAI SCR definition: >=4-fold with rounding tolerance (ratio >=3.9) because 57/226 etc. are rounded geometric midpoints; reclassified', '1 participant (Fluarix 027 H3N2, 57->226)', 'hai_titers.csv', '02_hai.py'),
 ('PLAN-rVE-events', 'Cases needed, 1:1, H0 rVE<=0, 1-sided alpha 0.025, 90% power: rVE 20% / 25% / 30% / 40%', '847 / 511 / 334 / 164', 'formula (case-split binomial)', '11_sample_size.py'),
 ('PLAN-rVE-N', 'ASSUMPTION-BASED illustrative N for a mismatched-strain endpoint: comparator attack rate 1-2%/season, mismatched share 30-50%, rVE 25-30%', '~39,000 to ~195,000 participant-seasons', 'planning assumptions (not in data package)', '11_sample_size.py'),
 ('PLAN-H3-1.16', 'n/arm to detect the WU397 H3 forward-drift point estimate (1.16x) / 1.2x, 90% power, residual SD 1.02 log2', '480 / 318', 'derived from neutralization_seqbased.csv variance', '11_sample_size.py'),
 ('PLAN-CHIM', 'ASSUMPTION-BASED challenge-study n/arm (80% power): placebo 50% vs vaccine 25%; placebo 40% vs 20%; comparator 35% vs mRNA 20%; comparator 30% vs 20%', '58; 82; 138; 294', 'planning assumptions (not in data package)', '11_sample_size.py'),
 ('MN-identity', 'INFERRED (not documented) MN panel identity: median Spearman rho of MN with H3N2 vs H1N1 seq-neut viruses (titres), homologous / heterologous; best titre match homologous = A/Darwin/9/2021 (rho 0.73)', 'homologous 0.42 vs 0.12; heterologous 0.41 vs 0.19', 'microneutralization.csv; neutralization_seqbased.csv', '17_mn_panel_identity.py'),
 ('PLAN-SCR-NI', 'n/arm for HAI seroconversion NI (10-pt margin, equal true rates 15%/30%/50%)', '268 / 442 / 526', 'formula', '11_sample_size.py'),
]
for x in extra: add(*x)
led = pd.DataFrame(L); led.to_csv('/tmp/outputs/numbers_ledger.csv', index=False)
print(len(led), 'rows total')
