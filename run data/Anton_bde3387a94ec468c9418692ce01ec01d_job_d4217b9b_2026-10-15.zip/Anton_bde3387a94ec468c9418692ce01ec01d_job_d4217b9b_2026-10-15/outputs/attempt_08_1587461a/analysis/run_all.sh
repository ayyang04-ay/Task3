#!/usr/bin/env bash
# Reproduce every analysis in order. Inputs: /tmp/world/filesystem (read-only). Env: micromamba 'core'.
set -euo pipefail
cd "$(dirname "$0")"
for s in 01_bvic_hai_alignment_check 02_hai 03_mn 04_elisa 05_binding_breadth 06_seqneut 07_egg_pairs 08_cellular 09_mabs \
         10_intercurrent_infection_screen 11_sample_size 12_seqneut_robustness 13_relative_breadth 14_binding_vs_function \
         17_mn_panel_identity 15_figures 16_numbers_ledger; do
  echo "=== $s"; micromamba run -n core python "$s.py" > "logs/$s.log" 2>&1 && echo ok || { echo FAILED; exit 1; }
done
