import sys, re; sys.path.insert(0, '/tmp/outputs/analysis')
from common import *
import statsmodels.formula.api as smf
W = pd.read_csv(OUT + '06_seqneut_long_wide.csv')
# Sensitivity 1: 'upper'-censored (below LOD) values set to half the bound; 'lower'-censored unchanged
W2 = W.copy()
for dcol in ['d0', 'd29', 'd121', 'd181']:
    bcol = dcol + '_bound'
    W2.loc[W2[bcol] == 'upper', dcol] = W2.loc[W2[bcol] == 'upper', dcol] / 2
W2['late'] = W2['d121'].fillna(W2['d181'])
def cat_summary(W, label):
    rows = []
    P = W.dropna(subset=['d0', 'd29']).groupby(['arm', 'pid', 'category']).agg(l29=('d29', lambda x: np.log2(x).mean()), l0=('d0', lambda x: np.log2(x).mean())).reset_index()
    for c, d in P.groupby('category'):
        d = d.assign(t=(d.arm == 'mRNA-1010').astype(int)); m = smf.ols('l29 ~ t + l0', data=d).fit()
        rows.append(dict(analysis=label, category=c, adj_ratio=2 ** m.params['t'], lo=2 ** m.conf_int().loc['t', 0], hi=2 ** m.conf_int().loc['t', 1], p=m.pvalues['t']))
    return pd.DataFrame(rows)
r1 = cat_summary(W, 'primary (bounds as reported)')
r2 = cat_summary(W2, 'sensitivity (<LOD set to LOD/2)')
# Sensitivity 2: exclude egg/reassortant viruses
r3 = cat_summary(W[~W.egg_or_reassortant], 'sensitivity (wild-type viruses only)')
# Sensitivity 3: unadjusted (no baseline covariate) GMT ratio at d29
rows = []
P = W.dropna(subset=['d0', 'd29']).groupby(['arm', 'pid', 'category']).agg(l29=('d29', lambda x: np.log2(x).mean())).reset_index()
for c, d in P.groupby('category'):
    a = d[d.arm == 'mRNA-1010'].l29; f = d[d.arm == 'Fluarix'].l29
    r = ratio_ci(2 ** a.values, 2 ** f.values)
    rows.append(dict(analysis='unadjusted d29 GMT ratio', category=c, adj_ratio=r[0], lo=r[1], hi=r[2], p=r[3]))
r4 = pd.DataFrame(rows)
R = pd.concat([r1, r2, r3, r4]); R.to_csv(OUT + '12_seqneut_sensitivity.csv', index=False)
print(R.pivot_table(index='category', columns='analysis', values='adj_ratio').round(2).to_string())
print(R[R.category.str.contains('H3 forward|H1 contemporary|H3 vaccine')].round(3).to_string(index=False))
# per-virus consistency for forward-drift H3
pv = pd.read_csv(OUT + '06_seqneut_per_virus.csv')
fd = pv[pv.category == 'H3 forward-drift (2022-2024)']
print(f'\nH3 forward-drift viruses: n={len(fd)}; adj ratio >1: {(fd.adj_ratio > 1).sum()}; nominal p<0.05 favouring mRNA: {((fd.adj_p < 0.05) & (fd.adj_ratio > 1)).sum()}; favouring Fluarix: {((fd.adj_p < 0.05) & (fd.adj_ratio < 1)).sum()}; BH q<0.05: {(fd.adj_p_BH < 0.05).sum()}')
print('  median per-virus adj ratio %.2f (IQR %.2f-%.2f)' % (fd.adj_ratio.median(), fd.adj_ratio.quantile(.25), fd.adj_ratio.quantile(.75)))
h1c = pv[pv.category == 'H1 contemporary (2023)']
print(f'H1 2023 viruses: n={len(h1c)}; adj ratio >1: {(h1c.adj_ratio > 1).sum()}; range {h1c.adj_ratio.min():.2f}-{h1c.adj_ratio.max():.2f}')
print(h1c[['virus', 'GMFR_m', 'GMFR_f', 'adj_ratio', 'adj_lo', 'adj_hi', 'adj_p']].round(3).to_string(index=False))
# Year-resolved H3 landscape (wild-type only)
W['yr'] = W.virus.apply(lambda v: 2023 if '202023' in v else int(re.findall(r'/(\d{4})(?=egg|X-|NIB-|_|$)', v.rsplit('_', 1)[0])[-1]))
H3 = W[(W.subtype == 'H3N2') & (~W.egg_or_reassortant)].dropna(subset=['d0', 'd29'])
bins = [(2012, 2014, '2012-2014'), (2016, 2017, '2016-2017'), (2019, 2020, '2019-2020'), (2021, 2021, '2021 (vaccine: Darwin/6, Darwin/9)'), (2022, 2022, '2022'), (2023, 2023, '2023'), (2024, 2024, '2024')]
rows = []
for lo_, hi_, lab in bins:
    d = H3[(H3.yr >= lo_) & (H3.yr <= hi_)]
    P = d.groupby(['arm', 'pid']).agg(l2fc=('l2fc29', 'mean'), l29=('d29', lambda x: np.log2(x).mean()), l0=('d0', lambda x: np.log2(x).mean())).reset_index().assign(t=lambda x: (x.arm == 'mRNA-1010').astype(int))
    m = smf.ols('l29 ~ t + l0', data=P).fit()
    rows.append(dict(isolation_years=lab, n_viruses=d.virus.nunique(), GMFR_mRNA=2 ** P[P.t == 1].l2fc.mean(), GMFR_Flu=2 ** P[P.t == 0].l2fc.mean(),
                     adj_d29_ratio=2 ** m.params['t'], lo=2 ** m.conf_int().loc['t', 0], hi=2 ** m.conf_int().loc['t', 1], p=m.pvalues['t']))
L = pd.DataFrame(rows); L.to_csv(OUT + '12_h3_year_landscape.csv', index=False)
print('\nH3N2 (wild-type viruses) breadth landscape by isolation year:'); print(L.round(3).to_string(index=False))
