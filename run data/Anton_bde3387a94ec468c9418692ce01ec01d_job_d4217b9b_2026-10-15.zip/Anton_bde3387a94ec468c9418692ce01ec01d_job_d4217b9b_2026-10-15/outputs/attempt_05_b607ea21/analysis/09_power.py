"""Planning calculations for the next randomised immunogenicity study, using variance estimates from WU397.
These are planning numbers only; SDs from n=13-15/arm are imprecise, so the upper 80% confidence bound of SD is also used."""
import pandas as pd, numpy as np
from scipy import stats
import statsmodels.formula.api as smf
pp=pd.read_csv('/tmp/outputs/analysis/seqneut_participant_level_values.csv')
hai=pd.read_csv('/tmp/world/filesystem/hai_titers.csv',dtype={'participant':str})
def sd_upper(sd,n,conf=0.8):
    # one-sided upper confidence bound for SD (chi-square)
    return sd*np.sqrt((n-1)/stats.chi2.ppf(1-conf,n-1))
def n_per_arm(sd,ratio,alpha=0.05,power=0.9):
    d=np.log2(ratio); z=stats.norm.ppf(1-alpha/2)+stats.norm.ppf(power)
    return int(np.ceil(2*(z*sd/d)**2))
rows=[]
for grp in ['contemporary H3N2 (n=68)','contemporary H1N1 (n=6)','A/Darwin/6/2021 (mRNA-1010 H3)','A/Thailand/8/2022 (2024-25 H3 vaccine strain)']:
    g=pp[pp.group==grp].dropna(subset=['d0','d29']).copy(); g['mrna']=(g.arm=='mRNA-1010').astype(int)
    raw_sd=np.sqrt(g.groupby('arm').d29.var(ddof=1).mean())
    fit=smf.ols('d29 ~ mrna + d0',data=g).fit(); res_sd=np.sqrt(fit.mse_resid); n=len(g)
    for label,sd in [('raw SD log2 D29',raw_sd),('baseline-adjusted residual SD',res_sd),('residual SD, 80% upper bound',sd_upper(res_sd,n-3))]:
        rows.append(dict(readout=f'seqneut {grp}',sd_basis=label,sd_log2=round(sd,2),
                         n_per_arm_ratio1_5=n_per_arm(sd,1.5),n_per_arm_ratio2_0=n_per_arm(sd,2.0)))
h=hai.pivot_table(index=['antigen','arm','participant'],columns='timepoint',values='hai_titer').reset_index()
for ag,g in h.groupby('antigen'):
    g=g.dropna(subset=['wk0','wk4']).copy(); g['l0']=np.log2(g.wk0); g['l4']=np.log2(g.wk4); g['mrna']=(g.arm=='mRNA-1010').astype(int)
    raw_sd=np.sqrt(g.groupby('arm').l4.var(ddof=1).mean()); fit=smf.ols('l4 ~ mrna + l0',data=g).fit(); res_sd=np.sqrt(fit.mse_resid)
    for label,sd in [('raw SD log2 wk4',raw_sd),('baseline-adjusted residual SD',res_sd)]:
        rows.append(dict(readout=f'HAI {ag}',sd_basis=label,sd_log2=round(sd,2),n_per_arm_ratio1_5=n_per_arm(sd,1.5),n_per_arm_ratio2_0=n_per_arm(sd,2.0)))
res=pd.DataFrame(rows); print(res.to_string()); res.to_csv('/tmp/outputs/analysis/power_planning.csv',index=False)

# Non-inferiority (HAI, vaccine-matched strains): GMT ratio (comparator/new) upper 95% CI <= 1.5 ; assume true ratio 1.0
def n_ni(sd,margin=1.5,true=1.0,alpha=0.025,power=0.9):
    z=stats.norm.ppf(1-alpha)+stats.norm.ppf(power); d=np.log2(margin)-np.log2(true)
    return int(np.ceil(2*(z*sd/d)**2))
for ag,g in h.groupby('antigen'):
    g=g.dropna(subset=['wk4']); sd=np.sqrt(g.groupby('arm').wk4.apply(lambda x:np.log2(x).var(ddof=1)).mean())
    print(f'HAI {ag}: SD log2 wk4={sd:.2f}; n/arm for GMT-ratio NI (margin 1.5, true ratio 1.0, 90% power, one-sided 0.025)={n_ni(sd)}')
# SCR NI: difference margin 10 points; use observed SCRs
for p in [0.15,0.33,0.5]:
    z=stats.norm.ppf(0.975)+stats.norm.ppf(0.9)
    n=int(np.ceil(z**2*2*p*(1-p)/0.10**2))
    print(f'SCR NI, margin 10 pts, assumed SCR {p:.2f} both arms, 90% power: n/arm={n}')
