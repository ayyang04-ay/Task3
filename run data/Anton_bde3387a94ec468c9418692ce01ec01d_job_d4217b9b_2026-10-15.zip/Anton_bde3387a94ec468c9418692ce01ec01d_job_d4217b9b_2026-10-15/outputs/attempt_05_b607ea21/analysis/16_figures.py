import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from scipy import stats
import statsmodels.formula.api as smf
D='/tmp/world/filesystem'
# ---------- Fig 1: binding vs functional ratios (mRNA/Fluarix), same antigen family ----------
items=[]
el=pd.read_csv('/tmp/outputs/analysis/elisa_arm_comparisons.csv')
for ag,lab in [('A/H3','ELISA IgG H3 (GMFR wk4)'),('A/H1','ELISA IgG H1 (GMFR wk4)')]:
    r=el[(el.antigen==ag)&(el.quantity=='fc_wk4')].iloc[0]; items.append((lab,'binding',r.ratio_mRNA_over_Fluarix,r.lo,r.hi,ag[-2:]))
bb=pd.read_csv('/tmp/outputs/analysis/bead_breadth_by_strain.csv')
for s,lab,sub in [('A/Darwin/6/2021','Bead binding A/Darwin/6/2021 (H3 vaccine strain)','H3'),('A/Thailand/8/2022','Bead binding A/Thailand/8/2022 (H3, next-season)','H3'),
                  ('A/Hong Kong/1/1968','Bead binding A/Hong Kong/1/1968 (H3, historical)','H3'),('A/Wisconsin/67/2022','Bead binding A/Wisconsin/67/2022 (H1, mRNA-matched)','H1')]:
    r=bb[bb.strain==s].iloc[0]; items.append((lab,'binding',r.ratio_of_GMFR,r.lo,r.hi,sub))
hai=pd.read_csv('/tmp/outputs/analysis/hai_arm_comparisons.csv')
for ag,lab,sub in [('A/H3N2','HAI H3N2 (GMT wk4)','H3'),('A/H1N1','HAI H1N1 (GMT wk4)','H1')]:
    r=hai[(hai.antigen==ag)&(hai.comparison=='GMT ratio wk4')].iloc[0]; items.append((lab,'function',r.ratio,r.lo,r.hi,sub))
sn=pd.read_csv('/tmp/outputs/analysis/seqneut_participant_level_summary.csv')
def parse(s):
    a,b=s.split(' (');lo,hi=b.rstrip(')').split('-'); return float(a),float(lo),float(hi)
for g,lab,sub in [('A/Darwin/6/2021 (mRNA-1010 H3)','Neut A/Darwin/6/2021 (D29, baseline-adj.)','H3'),('A/Thailand/8/2022 (2024-25 H3 vaccine strain)','Neut A/Thailand/8/2022 (D29, baseline-adj.)','H3'),
                  ('contemporary H3N2 (n=68)','Neut 68 contemporary H3N2 (D29, baseline-adj.)','H3'),('historical H3N2 WT (n=8)','Neut 8 historical H3N2 (D29, baseline-adj.)','H3'),
                  ('contemporary H1N1 (n=6)','Neut 6 contemporary H1N1 (D29, baseline-adj.)','H1')]:
    r=sn[sn.group==g].iloc[0]; a,lo,hi=parse(r.ANCOVA_d29_ratio); items.append((lab,'function',a,lo,hi,sub))
mn=pd.read_csv('/tmp/outputs/analysis/mn_arm_comparisons.csv')
for p in ['homologous','heterologous']:
    r=mn[(mn.panel==p)&(mn.quantity=='wk4')].iloc[0]; items.append((f'MN {p} panel (GMT wk4; strain unspecified)','function',float(r.ratio),float(r.lo),float(r.hi),'?'))
fig,ax=plt.subplots(figsize=(8.5,7))
for i,(lab,kind,v,lo,hi,sub) in enumerate(items[::-1]):
    c='tab:orange' if kind=='binding' else 'tab:blue'
    ax.errorbar(v,i,xerr=[[v-lo],[hi-v]],fmt='o',color=c,capsize=3)
ax.set_yticks(range(len(items))); ax.set_yticklabels([x[0] for x in items[::-1]],fontsize=8)
ax.axvline(1,color='k',lw=0.8); ax.set_xscale('log',base=2)
ax.set_xlabel('mRNA-1010 / Fluarix ratio (95% CI), log2 scale')
ax.set_title('WU397: binding readouts (orange) vs functional readouts (blue)',fontsize=10)
plt.tight_layout(); plt.savefig('/tmp/outputs/figures/fig1_binding_vs_function.png',dpi=150)
# ---------- Fig 2: per-virus baseline-adjusted D29 ratio by category ----------
t=pd.read_csv('/tmp/outputs/analysis/seqneut_per_virus_ancova.csv')
order=['mRNA-1010 H3 strain','Fluarix H3 strain (egg-based analogue)','contemporary H3N2 (2022-24 isolate)','historical H3N2','historical H3N2 (egg reassortant)',
       'mRNA-1010 H1 strain (egg reassortant)','mRNA-1010-matched H1 (A/Victoria/4897/2022-like)','Fluarix-matched H1 (A/Victoria/2570/2019-like)','contemporary H1N1 (2022-24 isolate)','historical H1N1']
fig,ax=plt.subplots(figsize=(10,5.5))
for i,c in enumerate(order):
    x=t[t.category==c]
    jitter=np.random.default_rng(1).uniform(-0.25,0.25,len(x)) if len(x)>1 else [0]
    ax.scatter(np.log2(x.adj_ratio_d29),i+np.array(jitter),s=12,alpha=0.7)
    ax.plot([np.log2(x.adj_ratio_d29.median())]*2,[i-0.35,i+0.35],color='k',lw=2)
ax.axvline(0,color='grey',lw=0.8)
ax.set_yticks(range(len(order))); ax.set_yticklabels([f'{c} (n={int((t.category==c).sum())})' for c in order],fontsize=8)
ax.set_xlabel('Baseline-adjusted D29 neutralising GMT ratio, mRNA-1010 / Fluarix (one dot per virus; log2 axis)',fontsize=9)
ax.set_xticks(np.log2([0.5,0.71,1,1.41,2,2.83])); ax.set_xticklabels(['0.5','0.71','1','1.41','2','2.83'])
ax.set_title('Sequencing-based neutralisation (13 vs 14 participants, 96 viruses)\nbar = category median; no single virus significant after BH-FDR',fontsize=10)
plt.tight_layout(); plt.savefig('/tmp/outputs/figures/fig2_seqneut_per_virus_adjusted_ratio.png',dpi=150)
print('figures written')
