"""Bead-array binding breadth (log2 FC MFI, wk4/wk0 presumably) per strain; arm comparison.
Strain classification relative to EACH arm's actual vaccine antigen."""
import pandas as pd, numpy as np
from scipy import stats
D='/tmp/world/filesystem'
# Classification (annotation by us; clade labels from WHO/CDC vaccine-composition reports)
h1cls={
 'A/Puerto Rico/8/1934':('pre-2009 seasonal/lab (H1)','historical'),
 'A/California/04/2009':('pdm09 prototype','historical'),
 'A/Michigan/45/2015':('6B.1; 2017-19 vaccine','historical'),
 'A/Brisbane/2/2018':('6B.1A.1; 2019-20 vaccine','historical'),
 'A/Guangdong-Maonan/SWL1536/2019':('6B.1A.5a.1; 2020-21 egg vaccine','historical'),
 'A/Hawaii/70/2019':('6B.1A.5a.1; 2020-21 cell vaccine','historical'),
 'A/Wisconsin/588/2019':('6B.1A.5a.2; 2021-23 cell vaccine = A/Victoria/2570/2019-like (FLUARIX 2022-23 H1)','Fluarix-matched'),
 'A/Sydney/5/2021':('6B.1A.5a.2a; 2023 SH vaccine','drifted/contemporary'),
 'A/Wisconsin/67/2022':('6B.1A.5a.2a.1; 2023-25 cell vaccine = A/Victoria/4897/2022-like (mRNA-1010 H1)','mRNA-1010-matched'),
}
h3cls={
 'A/Hong Kong/1/1968':('1968 pandemic','historical'),
 'A/Brisbane/10/2007':('2008-10 vaccine','historical'),
 'A/Perth/16/2009':('2010-12 vaccine','historical'),
 'A/Victoria/361/2011':('2012-13 vaccine','historical'),
 'A/Texas/50/2012':('3C.1; 2013-15 vaccine','historical'),
 'A/Switzerland/8060/2017':('3C.2a2','historical'),
 'A/Singapore/INFIMH-16-0019/2016':('3C.2a1; 2018-19 vaccine','historical'),
 'A/Hong Kong/2671/2019':('3C.2a1b.1b; 2020-21 egg vaccine','historical'),
 'A/South Australia/34/2019':('3C.2a1b','historical'),
 'A/Cambodia/e0826360/2020':('3C.2a1b.2a.1; 2021-22 vaccine','historical'),
 'A/Darwin/6/2021':('3C.2a1b.2a.2; mRNA-1010 H3 (Fluarix: A/Darwin/9/2021-like egg analogue)','both-matched (nominal)'),
 'A/Thailand/8/2022':('2a.3a.1 (J.2); 2024-25 vaccine','drifted/contemporary'),
}
rows=[]
for sub,fn,cls in [('H1','binding_breadth_h1.csv',h1cls),('H3','binding_breadth_h3.csv',h3cls)]:
    b=pd.read_csv(f'{D}/{fn}')
    for s,g in b.groupby('strain'):
        a=g[g.arm=='mRNA-1010'].log2_fold_change_mfi; f=g[g.arm=='Fluarix'].log2_fold_change_mfi
        d=a.mean()-f.mean()
        va,vb=a.var(ddof=1)/len(a),f.var(ddof=1)/len(f); se=np.sqrt(va+vb)
        df=(va+vb)**2/(va**2/(len(a)-1)+vb**2/(len(f)-1)); tq=stats.t.ppf(.975,df)
        rows.append(dict(subtype=sub,strain=s,note=cls[s][0],category=cls[s][1],n_m=len(a),n_f=len(f),
            mean_log2FC_mRNA=round(a.mean(),2),mean_log2FC_Fluarix=round(f.mean(),2),
            GMFR_mRNA=round(2**a.mean(),2),GMFR_Fluarix=round(2**f.mean(),2),
            ratio_of_GMFR=round(2**d,2),lo=round(2**(d-tq*se),2),hi=round(2**(d+tq*se),2),
            p_welch=stats.ttest_ind(a,f,equal_var=False).pvalue,p_MWU=stats.mannwhitneyu(a,f).pvalue,
            pct_ge2fold_mRNA=round(100*(a>=1).mean(),0),pct_ge2fold_Fluarix=round(100*(f>=1).mean(),0)))
res=pd.DataFrame(rows)
# BH-FDR within the 21 strain tests
from statsmodels.stats.multitest import multipletests
res['q_BH']=multipletests(res.p_welch,method='fdr_bh')[1]
res['p_welch']=res.p_welch.map(lambda x:f'{x:.2g}'); res['p_MWU']=res.p_MWU.map(lambda x:f'{x:.2g}'); res['q_BH']=res.q_BH.map(lambda x:f'{x:.2g}')
pd.set_option('display.width',250)
print(res.drop(columns=['note']).to_string())
res.to_csv('/tmp/outputs/analysis/bead_breadth_by_strain.csv',index=False)
# Participant-level breadth: number of strains with >=2-fold rise; mean log2FC over heterologous (non-matched) strains
for sub,fn,cls in [('H1','binding_breadth_h1.csv',h1cls),('H3','binding_breadth_h3.csv',h3cls)]:
    b=pd.read_csv(f'{D}/{fn}')
    b['category']=b.strain.map(lambda s:cls[s][1])
    for label,sel in [('all strains',b.category.notna()),('excluding either arm-matched strain',~b.category.isin(['mRNA-1010-matched','Fluarix-matched','both-matched (nominal)'])),
                      ('historical only',b.category=='historical'),('drifted/contemporary only',b.category=='drifted/contemporary')]:
        pp=b[sel].groupby(['arm','participant']).log2_fold_change_mfi.agg(['mean',lambda x:(x>=1).sum(),'count']).reset_index()
        pp.columns=['arm','participant','mean_log2FC','n_strains_ge2fold','n_strains']
        a=pp[pp.arm=='mRNA-1010']; f=pp[pp.arm=='Fluarix']
        print(f'{sub} | {label}: n_strains={int(pp.n_strains.iloc[0])} | participant mean log2FC mRNA={a.mean_log2FC.mean():.2f} (GMFR {2**a.mean_log2FC.mean():.2f}) vs Fluarix={f.mean_log2FC.mean():.2f} (GMFR {2**f.mean_log2FC.mean():.2f}); '
              f'p_MWU={stats.mannwhitneyu(a.mean_log2FC,f.mean_log2FC).pvalue:.2g}; median #strains>=2fold mRNA={a.n_strains_ge2fold.median()} vs Fluarix={f.n_strains_ge2fold.median()}')
