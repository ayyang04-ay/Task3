# WU397 re-analysis: scripts and outputs

Inputs are read-only at `/tmp/world/filesystem/`. To reproduce everything, run `./run_all.sh`; it uses the `core` micromamba env, and logs go to `logs/`.

Ratios are always **mRNA-1010 / Fluarix**. "Adjusted" means an ANCOVA of log2 post-dose titre on arm, with log2 baseline titre as a covariate.

| Script | What it does | Main outputs |
|---|---|---|
| 00_integrity_checks.py | Arm consistency, file coverage, timepoints vs schedule, duplicate keys, ID anomalies | participant_arm_map.csv, participant_file_presence.csv |
| 01_hai.py | HAI GMT, fold-rise, seroconversion, seroprotection; arm ratios; baseline-adjusted wk4 | hai_summary.csv, hai_arm_comparisons.csv, hai_ancova_wk4.csv |
| 02_elisa.py | ELISA IgG GMT and fold-rise; arm ratios; ID-block check | elisa_summary.csv, elisa_arm_comparisons.csv |
| 03_mn.py | Microneutralisation homologous/heterologous; 1:1280 ceiling | mn_summary.csv, mn_arm_comparisons.csv |
| 04_bead_breadth.py | Bead-array binding fold-rise by strain, classified against each arm's actual antigen | bead_breadth_by_strain.csv |
| 05_seqneut.py | 96-virus sequencing-based neutralisation; virus classification; per-virus GMT and fold-rise | seqneut_virus_classification.csv, seqneut_per_virus.csv, seqneut_wide_log2.csv |
| 06_seqneut_participant.py | Participant-level panel GMTs (avoids pseudo-replication); adjusted ratios | seqneut_participant_level_summary.csv |
| 07_mab.py | mAb binding breadth by donor (donor = unit); thresholds 3×, 5×, 10× | mab_donor_level_breadth.csv |
| 08_cellular_repertoire.py | Germinal-centre, plasmablast and repertoire summaries (exploratory) | console |
| 09_power.py / 18_power_check.py | Study A sizing from WU397 variances | power_planning.csv |
| 10_backboost.py | Forward vs backward breadth: mixed model and within-person contrasts | console |
| 11_binding_vs_function.py | Same-participant comparison of binding vs functional readouts | binding_vs_function_same_participants.csv |
| 12_efficacy_planning.py | Study C event and size scenarios (external assumptions) | efficacy_planning_scenarios.csv |
| 13_igm.py | IgM fold-rise | igm_summary.csv |
| 14_seqneut_per_virus_ancova.py | Per-virus adjusted ratios with FDR correction | seqneut_per_virus_ancova.csv |
| 15_visit_label_crosscheck.py | Late-visit label conflicts across assay files | visit_label_inconsistencies.csv |
| 16_figures.py | Figures | ../figures/*.png |
| 17_key_numbers.py | All quoted numbers, with their sources | ../key_numbers.csv |
| 19_chim_sizing.py | Study B sizing (external assumptions) | console |
