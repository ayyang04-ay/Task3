"""Per-virus baseline-adjusted (ANCOVA) D29 GMT ratio mRNA-1010/Fluarix, plus D121/181 ratio, for every virus in the seqneut panel."""
import pandas as pd, numpy as np
import statsmodels.formula.api as smf
from statsmodels.stats.multitest import multipletests
w=pd.read_csv('/tmp/outputs/analysis/seqneut_wide_log2.csv')
rows=[]
for (v,cat),g in w.groupby(['virus','category']):
    g=g.dropna(subset=['d0','d29']).copy(); g['mrna']=(g.arm=='mRNA-1010').astype(int)
    f=smf.ols('d29 ~ mrna + d0',data=g).fit(); b=f.params['mrna']; lo,hi=f.conf_int().loc['mrna']
    rows.append(dict(virus=v,category=cat,n=len(g),adj_ratio_d29=2**b,lo=2**lo,hi=2**hi,p=f.pvalues['mrna']))
t=pd.DataFrame(rows); t['q_BH']=multipletests(t.p,method='fdr_bh')[1]
t=t.round(3).sort_values(['category','adj_ratio_d29'])
t.to_csv('/tmp/outputs/analysis/seqneut_per_virus_ancova.csv',index=False)
pd.set_option('display.width',200); pd.set_option('display.max_rows',200)
key=['A/Thailand/8/2022_H3N2','A/Massachusetts/18/2022_H3N2','A/DistrictOfColumbia/27/2023_H3N2','A/Darwin/6/2021_H3N2','A/Darwin/9/2021_H3N2',
     'A/Wisconsin/67/2022_H1N1','A/Wisconsin/588/2019_H1N1','A/Victoria/4897/2022_IVR-238_H1N1']
print(t[t.virus.isin(key)].to_string())
print('\nBy category: median adjusted ratio, n viruses with LB>1, n with UB<1, n q<0.05')
print(t.groupby('category').apply(lambda x: pd.Series({'n_viruses':len(x),'median_adj_ratio':round(x.adj_ratio_d29.median(),2),'n_LB_gt1':int((x.lo>1).sum()),'n_UB_lt1':int((x.hi<1).sum()),'n_q_lt_0.05':int((x.q_BH<0.05).sum())}),include_groups=False).to_string())
