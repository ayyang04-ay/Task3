"""ELISA IgG EC50 analysis by antigen/arm: GMT, GMFR (from provided fold_change and recomputed), arm comparison."""
import pandas as pd, numpy as np
from scipy import stats
import statsmodels.formula.api as smf
D='/tmp/world/filesystem'
e=pd.read_csv(f'{D}/elisa_igg_titers.csv')
ec=e[e.measure=='ec50'].pivot_table(index=['antigen','arm','participant'],columns='timepoint',values='value').reset_index()
fc=e[e.measure=='fold_change'].pivot_table(index=['antigen','arm','participant'],columns='timepoint',values='value').reset_index()
fc.columns=[c if c in ['antigen','arm','participant'] else 'fc_'+c for c in fc.columns]
m=ec.merge(fc,on=['antigen','arm','participant'],how='outer')
m['fc4_re']=m.wk4/m.wk0
# verify provided wk4 FC equals recomputed
m['fc4_diff']=np.log2(m['fc_wk4'])-np.log2(m['fc4_re'])
print('wk4 fold_change vs recomputed: max |log2 diff| =', np.nanmax(np.abs(m.fc4_diff)).round(3))
# wk17/26: which visit is used?
m['late']=m.wk26.fillna(m.wk17)
m['fc_late_re']=m.late/m.wk0
m['fcl_diff']=np.log2(m['fc_wk17/26'])-np.log2(m['fc_late_re'])
print('wk17/26 fold_change vs recomputed: max |log2 diff| =', np.nanmax(np.abs(m.fcl_diff)).round(3))
bad=m[np.abs(m.fcl_diff)>0.05]
print('rows where late FC disagrees:',len(bad)); print(bad[['antigen','arm','participant','wk0','wk17','wk26','fc_wk17/26','fc_late_re']].head(30).to_string())
# Participants with late FC but no late ec50
nolate=m[m['fc_wk17/26'].notna() & m.late.isna()]
print('late FC reported but no wk17/wk26 EC50:', len(nolate)); print(nolate[['antigen','arm','participant','fc_wk17/26']].to_string())
both=m[m.wk17.notna() & m.wk26.notna()]
print('participants with both wk17 and wk26:', both[['antigen','arm','participant']].to_string())
def gm(x): x=np.asarray(x); return 2**np.mean(np.log2(x))
def ci(lx):
    n=len(lx); mu=np.mean(lx); se=np.std(lx,ddof=1)/np.sqrt(n); t=stats.t.ppf(.975,n-1); return 2**mu,2**(mu-t*se),2**(mu+t*se)
rows=[]
for (ag,arm),g in m.groupby(['antigen','arm']):
    for tp in ['wk0','wk4','wk26']:
        x=g[tp].dropna(); a,lo,hi=ci(np.log2(x))
        rows.append(dict(antigen=ag,arm=arm,quantity=f'GM EC50 {tp}',n=len(x),value=round(a,1),lo=round(lo,1),hi=round(hi,1)))
    for c in ['fc_wk4','fc_wk17/26']:
        x=g[c].dropna(); a,lo,hi=ci(np.log2(x))
        rows.append(dict(antigen=ag,arm=arm,quantity=f'GMFR {c[3:]}',n=len(x),value=round(a,2),lo=round(lo,2),hi=round(hi,2)))
        rows.append(dict(antigen=ag,arm=arm,quantity=f'% >=2-fold {c[3:]}',n=len(x),value=round(100*(x>=2).mean(),1)))
        rows.append(dict(antigen=ag,arm=arm,quantity=f'% >=4-fold {c[3:]}',n=len(x),value=round(100*(x>=4).mean(),1)))
res=pd.DataFrame(rows); print(res.to_string()); res.to_csv('/tmp/outputs/analysis/elisa_summary.csv',index=False)
rows=[]
for ag,g in m.groupby('antigen'):
    for c in ['wk0','wk4','wk26','fc_wk4','fc_wk17/26']:
        a=np.log2(g[g.arm=='mRNA-1010'][c].dropna()); b=np.log2(g[g.arm=='Fluarix'][c].dropna())
        d=a.mean()-b.mean(); va,vb=a.var(ddof=1)/len(a),b.var(ddof=1)/len(b); se=np.sqrt(va+vb)
        df=(va+vb)**2/(va**2/(len(a)-1)+vb**2/(len(b)-1)); tq=stats.t.ppf(.975,df)
        p=stats.ttest_ind(a,b,equal_var=False).pvalue; u=stats.mannwhitneyu(a,b).pvalue
        rows.append(dict(antigen=ag,quantity=c,ratio_mRNA_over_Fluarix=round(2**d,2),lo=round(2**(d-tq*se),2),hi=round(2**(d+tq*se),2),p_welch=f'{p:.2g}',p_MWU=f'{u:.2g}',n_m=len(a),n_f=len(b)))
    gg=g.dropna(subset=['wk0','wk4']).copy(); gg['l0']=np.log2(gg.wk0); gg['l4']=np.log2(gg.wk4); gg['mrna']=(gg.arm=='mRNA-1010').astype(int)
    fit=smf.ols('l4 ~ mrna + l0',data=gg).fit(); b=fit.params['mrna']; lo,hi=fit.conf_int().loc['mrna']
    rows.append(dict(antigen=ag,quantity='wk4 EC50 adj. for wk0 (ANCOVA)',ratio_mRNA_over_Fluarix=round(2**b,2),lo=round(2**lo,2),hi=round(2**hi,2),p_welch=f'{fit.pvalues["mrna"]:.2g}',p_MWU='',n_m=int(gg.mrna.sum()),n_f=int((1-gg.mrna).sum())))
cmpr=pd.DataFrame(rows); print(cmpr.to_string()); cmpr.to_csv('/tmp/outputs/analysis/elisa_arm_comparisons.csv',index=False)
# Enrolment-block sensitivity: participant id <=32 (the subset shared with HAI/MN/seqneut) vs >32
m['block']=np.where(m.participant<=32,'ids_001-032','ids_033-102')
print(m.groupby(['antigen','arm','block']).apply(lambda g: pd.Series({'n':len(g),'GM_wk0':round(gm(g.wk0),0),'GMFR_wk4':round(gm(g.fc_wk4.dropna()),2)})).to_string())
m.to_csv('/tmp/outputs/analysis/elisa_merged.csv',index=False)
