"""Microneutralisation: homologous vs heterologous panels. Note ULOQ=1280 censoring."""
import pandas as pd, numpy as np
from scipy import stats
D='/tmp/world/filesystem'
mn=pd.read_csv(f'{D}/microneutralization.csv')
t=mn[mn.measure=='titer'].pivot_table(index=['panel','arm','participant'],columns='timepoint',values='value').reset_index()
f=mn[mn.measure=='fold_change'].pivot_table(index=['panel','arm','participant'],columns='timepoint',values='value').reset_index()
f.columns=[c if c in ['panel','arm','participant'] else 'fc_'+c for c in f.columns]
m=t.merge(f,on=['panel','arm','participant'])
m['late']=m.wk26.fillna(m.wk17)
m['fc4_re']=m.wk4/m.wk0; m['fcl_re']=m.late/m.wk0
print('wk4 FC consistency (max |log2 diff|):', np.max(np.abs(np.log2(m.fc_wk4/m.fc4_re))))
print('late FC consistency:', np.max(np.abs(np.log2(m['fc_wk17/26']/m.fcl_re))))
bad=m[np.abs(np.log2(m['fc_wk17/26']/m.fcl_re))>0.01]
print(bad[['panel','arm','participant','wk0','wk4','wk17','wk26','fc_wk17/26','fcl_re']].to_string())
ULOQ=1280
for c in ['wk0','wk4','late']:
    m[c+'_atULOQ']=m[c]>=ULOQ
print('\nN at ULOQ (1280):'); print(m.groupby(['panel','arm'])[['wk0_atULOQ','wk4_atULOQ','late_atULOQ']].sum())
print('N at/below LLOQ (<=10):'); print(m.groupby(['panel','arm'])[['wk0','wk4']].apply(lambda g:(g<=10).sum()))
def gm(x): return 2**np.mean(np.log2(np.asarray(x,dtype=float)))
rows=[]
for (p,a),g in m.groupby(['panel','arm']):
    rows.append(dict(panel=p,arm=a,n=len(g),GMT_wk0=round(gm(g.wk0),1),GMT_wk4=round(gm(g.wk4),1),GMT_late=round(gm(g.late.dropna()),1),
                     GMFR_wk4=round(gm(g.fc_wk4),2),GMFR_late=round(gm(g['fc_wk17/26']),2),
                     pct_4fold_wk4=round(100*(g.fc_wk4>=4).mean(),1),n_4fold_wk4=int((g.fc_wk4>=4).sum()),
                     n_baseline_at_ULOQ=int((g.wk0>=ULOQ).sum()),n_wk4_at_ULOQ=int((g.wk4>=ULOQ).sum()),
                     n_baseline_ge_320=int((g.wk0>=320).sum())))
res=pd.DataFrame(rows); print(res.to_string()); res.to_csv('/tmp/outputs/analysis/mn_summary.csv',index=False)
rows=[]
for p,g in m.groupby('panel'):
    for c in ['wk0','wk4','late','fc_wk4','fc_wk17/26']:
        a=np.log2(g[g.arm=='mRNA-1010'][c].dropna()); b=np.log2(g[g.arm=='Fluarix'][c].dropna())
        d=a.mean()-b.mean(); va,vb=a.var(ddof=1)/len(a),b.var(ddof=1)/len(b); se=np.sqrt(va+vb)
        df=(va+vb)**2/(va**2/(len(a)-1)+vb**2/(len(b)-1)); tq=stats.t.ppf(.975,df)
        rows.append(dict(panel=p,quantity=c,ratio=round(2**d,2),lo=round(2**(d-tq*se),2),hi=round(2**(d+tq*se),2),
                         p_welch=round(stats.ttest_ind(a,b,equal_var=False).pvalue,3),p_MWU=round(stats.mannwhitneyu(a,b).pvalue,3)))
    # 4-fold responders Fisher
    a=g[g.arm=='mRNA-1010'].fc_wk4>=4; b=g[g.arm=='Fluarix'].fc_wk4>=4
    rows.append(dict(panel=p,quantity='4-fold responders wk4 (Fisher)',ratio=f'{a.sum()}/{len(a)} vs {b.sum()}/{len(b)}',p_welch=round(stats.fisher_exact([[a.sum(),len(a)-a.sum()],[b.sum(),len(b)-b.sum()]])[1],3)))
cmpr=pd.DataFrame(rows); print(cmpr.to_string()); cmpr.to_csv('/tmp/outputs/analysis/mn_arm_comparisons.csv',index=False)
# Exclude participants with baseline at ULOQ (cannot show a rise)
mm_=m[m.wk0<ULOQ]
rows=[]
for (p,a),g in mm_.groupby(['panel','arm']):
    rows.append(dict(panel=p,arm=a,n_evaluable=len(g),GMFR_wk4=round(gm(g.fc_wk4),2),n_4fold=int((g.fc_wk4>=4).sum())))
print('\nExcluding baseline-at-ULOQ participants:'); print(pd.DataFrame(rows).to_string())
# heterologous/homologous ratio at wk4 per participant
w=m.pivot_table(index=['arm','participant'],columns='panel',values=['wk0','wk4','fc_wk4'])
w.columns=['_'.join(c) for c in w.columns]; w=w.reset_index()
w['het_over_hom_wk4']=w.wk4_heterologous/w.wk4_homologous
print(w.groupby('arm').het_over_hom_wk4.apply(gm))
m.to_csv('/tmp/outputs/analysis/mn_merged.csv',index=False)
