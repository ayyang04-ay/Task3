"""Is the mRNA-1010 neutralisation 'breadth' forward (drifted/newer strains) or backward (older strains)?
Within-participant contrasts of D29 log2 titre and D29/D0 log2 fold-rise: historical vs vaccine strain vs contemporary."""
import pandas as pd, numpy as np
from scipy import stats
import statsmodels.formula.api as smf
pp=pd.read_csv('/tmp/outputs/analysis/seqneut_participant_level_values.csv')
w=pp.pivot_table(index=['arm','pid'],columns='group',values=['d29','fr29','d0']).reset_index()
w.columns=['_'.join([c for c in col if c]) for col in w.columns]
def cmp(col,label):
    a=w[w.arm=='mRNA-1010'][col].dropna(); f=w[w.arm=='Fluarix'][col].dropna()
    print(f'{label}: mRNA mean {a.mean():.2f} log2 ({2**a.mean():.2f}x) vs Fluarix {f.mean():.2f} ({2**f.mean():.2f}x); diff {a.mean()-f.mean():.2f} log2; Welch p={stats.ttest_ind(a,f,equal_var=False).pvalue:.3f}; MWU p={stats.mannwhitneyu(a,f).pvalue:.3f}')
H='historical H3N2 WT (n=8)'; CC='contemporary H3N2 (n=68)'; V='A/Darwin/6/2021 (mRNA-1010 H3)'
w['fr_hist_minus_vacc']=w[f'fr29_{H}']-w[f'fr29_{V}']
w['fr_contemp_minus_vacc']=w[f'fr29_{CC}']-w[f'fr29_{V}']
w['fr_hist_minus_contemp']=w[f'fr29_{H}']-w[f'fr29_{CC}']
cmp('fr_hist_minus_vacc','Within-person fold-rise skew: historical H3 minus A/Darwin/6/2021')
cmp('fr_contemp_minus_vacc','Within-person fold-rise skew: contemporary H3 minus A/Darwin/6/2021')
cmp('fr_hist_minus_contemp','Within-person fold-rise skew: historical H3 minus contemporary H3')
# Mixed model on per-virus log2 titres (H3 only): d29 ~ arm*category + d0, random intercept per participant
sw=pd.read_csv('/tmp/outputs/analysis/seqneut_wide_log2.csv')
h3=sw[sw.category.isin(['contemporary H3N2 (2022-24 isolate)','historical H3N2','mRNA-1010 H3 strain'])].dropna(subset=['d0','d29']).copy()
h3['cat']=h3.category.map({'contemporary H3N2 (2022-24 isolate)':'b_contemporary','historical H3N2':'c_historical','mRNA-1010 H3 strain':'a_vaccine'})
h3['mrna']=(h3.arm=='mRNA-1010').astype(int)
m=smf.mixedlm('d29 ~ mrna*C(cat) + d0',h3,groups=h3.pid).fit()
print(m.summary().tables[1].to_string())
print('\nImplied baseline-adjusted mRNA/Fluarix D29 ratio by category (mixed model):')
b=m.params
for c,term in [('a_vaccine (A/Darwin/6/2021)',None),('b_contemporary',"mrna:C(cat)[T.b_contemporary]"),('c_historical',"mrna:C(cat)[T.c_historical]")]:
    est=b['mrna']+(b[term] if term else 0)
    print(f'  {c}: {2**est:.2f}')
