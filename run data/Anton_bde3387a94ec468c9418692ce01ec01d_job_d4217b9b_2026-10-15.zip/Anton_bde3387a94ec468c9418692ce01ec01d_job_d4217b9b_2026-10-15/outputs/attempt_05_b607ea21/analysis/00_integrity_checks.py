"""Data-integrity checks across the WU397 data package.
Run: mm core python 00_integrity_checks.py
"""
import pandas as pd, numpy as np, re, os
D = '/tmp/world/filesystem'
def pid3(x):
    s = str(x)
    s = s.replace('397-', '')
    return '397-' + s.zfill(3)

arms = {}  # pid -> set of (file, arm)
def reg(df, col_pid, col_arm, fname):
    for p, a in df[[col_pid, col_arm]].drop_duplicates().itertuples(index=False):
        arms.setdefault(pid3(p), set()).add((fname, a))

elisa = pd.read_csv(f'{D}/elisa_igg_titers.csv'); reg(elisa, 'participant', 'arm', 'elisa')
hai = pd.read_csv(f'{D}/hai_titers.csv', dtype={'participant': str}); reg(hai, 'participant', 'arm', 'hai')
mn = pd.read_csv(f'{D}/microneutralization.csv'); reg(mn, 'participant', 'arm', 'mn')
igm = pd.read_csv(f'{D}/igm_fold_change.csv', dtype={'participant': str}); reg(igm, 'participant', 'arm', 'igm')
gc = pd.read_csv(f'{D}/gc_frequencies.csv', dtype={'participant': str}); reg(gc, 'participant', 'arm', 'gc')
pb = pd.read_csv(f'{D}/plasmablast_frequencies.csv', dtype={'participant': str}); reg(pb, 'participant', 'arm', 'pb')
b1 = pd.read_csv(f'{D}/binding_breadth_h1.csv'); reg(b1, 'participant', 'arm', 'bead_h1')
b3 = pd.read_csv(f'{D}/binding_breadth_h3.csv'); reg(b3, 'participant', 'arm', 'bead_h3')
sq = pd.read_csv(f'{D}/neutralization_seqbased.csv')
sq['arm'] = sq.serum.str.split('_').str[0]; sq['pid'] = sq.serum.str.split('_').str[1]
reg(sq, 'pid', 'arm', 'seqneut')
mab = pd.read_csv(f'{D}/mab_binding_panels.csv')
mab['donor'] = '397-' + mab.mab_id.str.split('.').str[1]
reg(mab, 'donor', 'arm', 'mab')

print('=== Arm consistency per participant across files ===')
bad = 0
for p, s in sorted(arms.items()):
    a = {x[1] for x in s}
    if len(a) > 1:
        bad += 1
        print('INCONSISTENT', p, s)
print('participants:', len(arms), 'inconsistent:', bad)
armmap = {p: list({x[1] for x in s})[0] for p, s in arms.items()}
pd.Series(armmap).to_csv('/tmp/outputs/analysis/participant_arm_map.csv', header=['arm'])

print('\n=== Which files each participant appears in ===')
rows = []
for p, s in sorted(arms.items()):
    rows.append({'pid': p, 'arm': armmap[p], **{f: 1 for f, _ in s}})
pres = pd.DataFrame(rows).fillna(0)
print(pres.to_string())
pres.to_csv('/tmp/outputs/analysis/participant_file_presence.csv', index=False)

print('\n=== Timepoints present per file (schedule: blood d0,d7,d29,d121,d181; FNA wk1,2,4,8,17,26) ===')
for name, df, col in [('elisa', elisa, 'timepoint'), ('hai', hai, 'timepoint'), ('mn', mn, 'timepoint'),
                      ('gc', gc, 'timepoint'), ('pb', pb, 'timepoint')]:
    print(name, sorted(df[col].unique()))
sq['day'] = sq.serum.str.split('_').str[2]
print('seqneut', sorted(sq.day.unique()))

print('\n=== Duplicated keys ===')
k = gc.groupby(['timepoint', 'arm', 'participant']).size()
print('gc_frequencies: keys appearing twice =', (k == 2).sum(), 'of', len(k))
# split into the two blocks by order of appearance
gc['block'] = gc.groupby(['timepoint', 'arm', 'participant']).cumcount() + 1
print(gc.groupby(['block']).size())
print(gc.pivot_table(index=['timepoint','arm'], columns='block', values='pct_ha_specific_igg_gc', aggfunc='median'))

print('\n=== HAI: visit labels by antigen for wk17 ===')
print(hai[hai.timepoint == 'wk17'].groupby('antigen').participant.apply(lambda s: sorted(s)))
print('HAI wk26 participants by antigen:')
print(hai[hai.timepoint == 'wk26'].groupby(['antigen','arm']).participant.apply(lambda s: sorted(s)).to_string())

print('\n=== HAI: participants per antigen/timepoint ===')
print(hai.groupby(['antigen','timepoint','arm']).participant.nunique().unstack())

print('\n=== ID-format anomalies ===')
print('igm participants not 3-digit:', sorted(set(p for p in igm.participant if len(p) != 3)))
print('elisa participant ids (int):', sorted(elisa.participant.unique())[:5], '...')
print('seqneut virus names with odd years:', [v for v in sq.virus.unique() if re.search(r'/(\d{5,})', v)])

print('\n=== Seqneut: duplicated serum-virus rows? ===')
print(sq.duplicated(['serum','virus']).sum())
print('Seqneut sera per participant/day:')
print(sq.groupby(['arm','pid']).serum.unique().apply(lambda s: sorted(x.split('_')[2] for x in s)).to_string())
