import numpy as np
from scipy import stats
def power(n,sd,ratio,alpha):
    d=np.log2(ratio); se=sd*np.sqrt(2/n); z=stats.norm.ppf(1-alpha/2)
    return stats.norm.cdf(d/se - z)
for n in [150,200]:
    for sd in [1.03,1.19,1.52,1.76]:
        print(f'n/arm={n} SD={sd}: power ratio1.5 alpha0.05={power(n,sd,1.5,0.05):.2f}  alpha0.025={power(n,sd,1.5,0.025):.2f}')
# Precision: half-width of 95% CI for GMT ratio at n=200, SD=1.19
for n in [100,200]:
    for sd in [1.03,1.19]:
        hw=1.96*sd*np.sqrt(2/n); print(f'n={n} SD={sd}: 95% CI for GMT ratio = x/÷ {2**hw:.2f}')
