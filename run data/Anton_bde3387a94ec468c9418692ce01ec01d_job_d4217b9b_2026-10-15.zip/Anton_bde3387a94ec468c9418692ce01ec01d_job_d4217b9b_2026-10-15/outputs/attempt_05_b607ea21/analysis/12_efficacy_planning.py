"""Order-of-magnitude planning for a relative-efficacy trial with a mismatched-strain endpoint.
ALL INPUTS ARE EXTERNAL PLANNING ASSUMPTIONS (not from the WU397 package): attack rate, fraction of cases
caused by antigenically mismatched strains, and true relative VE. 1:1 randomisation, two-sided alpha 0.05, 90% power."""
import numpy as np, pandas as pd
from scipy import stats
z=stats.norm.ppf(0.975)+stats.norm.ppf(0.90)
rows=[]
for rve in [0.20,0.30]:
    for lb in [0.0,0.10]:
        # events needed to show rVE > lb when true rVE = rve (log relative-risk scale, equal allocation)
        d=4*z**2/(np.log(1-rve)-np.log(1-lb))**2
        for ar in [0.015,0.03]:
            for fmm in [0.3,0.6]:
                p=ar*fmm*(1+(1-rve))/2   # average per-participant probability of a mismatched-strain case across arms
                n=d/p
                rows.append(dict(true_rVE_mismatched=rve,null_margin_LB=lb,mismatched_events_needed=int(np.ceil(d)),
                                 comparator_attack_rate_per_season=ar,fraction_cases_mismatched=fmm,
                                 total_N_person_seasons=int(round(n,-3))))
t=pd.DataFrame(rows); print(t.to_string()); t.to_csv('/tmp/outputs/analysis/efficacy_planning_scenarios.csv',index=False)
