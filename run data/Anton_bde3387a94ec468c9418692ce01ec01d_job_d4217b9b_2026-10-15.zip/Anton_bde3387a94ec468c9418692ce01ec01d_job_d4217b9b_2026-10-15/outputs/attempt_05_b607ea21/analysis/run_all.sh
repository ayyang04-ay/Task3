#!/usr/bin/env bash
# Reproduce all analyses. Inputs: /tmp/world/filesystem ; outputs: this folder, ../figures, ../key_numbers.csv
set -euo pipefail
cd "$(dirname "$0")"
for s in 00_integrity_checks 01_hai 02_elisa 03_mn 04_bead_breadth 05_seqneut 06_seqneut_participant 07_mab \
         08_cellular_repertoire 09_power 10_backboost 11_binding_vs_function 12_efficacy_planning 13_igm \
         14_seqneut_per_virus_ancova 15_visit_label_crosscheck 16_figures 17_key_numbers 18_power_check 19_chim_sizing; do
  echo "=== $s"; micromamba run -n core python "$s.py" > "logs/$s.log" 2>&1 || { echo "FAILED $s"; exit 1; }
done
echo "all done"
