"""Same-participant comparison of binding vs functional readouts (participants with seqneut data, n=13 vs 14)."""
import pandas as pd, numpy as np
from scipy import stats
D='/tmp/world/filesystem'
sq=pd.read_csv('/tmp/outputs/analysis/seqneut_wide_log2.csv')
ids=sq[['arm','pid']].drop_duplicates()
ids['pnum']=ids.pid.str[-3:].astype(int)
el=pd.read_csv(f'{D}/elisa_igg_titers.csv'); el=el[(el.measure=='fold_change')&(el.timepoint=='wk4')]
hai=pd.read_csv(f'{D}/hai_titers.csv',dtype={'participant':str}); hw=hai.pivot_table(index=['antigen','participant'],columns='timepoint',values='hai_titer').reset_index(); hw['fr']=hw.wk4/hw.wk0; hw['pnum']=hw.participant.astype(int)
b1=pd.read_csv(f'{D}/binding_breadth_h1.csv'); b3=pd.read_csv(f'{D}/binding_breadth_h3.csv')
b=pd.concat([b1,b3]); b['pnum']=b.participant.str[-3:].astype(int)
mn=pd.read_csv(f'{D}/microneutralization.csv'); mn=mn[(mn.measure=='fold_change')&(mn.timepoint=='wk4')]; mn['pnum']=mn.participant.str[-3:].astype(int)
def gm(x): x=np.asarray(x,float); return 2**np.mean(np.log2(x))
rows=[]
for arm in ['mRNA-1010','Fluarix']:
    P=set(ids[ids.arm==arm].pnum)
    r={'arm':arm,'n':len(P)}
    r['ELISA A/H3 IgG GMFR wk4']=gm(el[(el.antigen=='A/H3')&el.participant.isin(P)].value)
    r['Bead A/Darwin/6/2021 binding GMFR']=2**b[(b.strain=='A/Darwin/6/2021')&b.pnum.isin(P)].log2_fold_change_mfi.mean()
    r['Bead A/Thailand/8/2022 binding GMFR']=2**b[(b.strain=='A/Thailand/8/2022')&b.pnum.isin(P)].log2_fold_change_mfi.mean()
    r['HAI A/H3N2 GMFR wk4']=gm(hw[(hw.antigen=='A/H3N2')&hw.pnum.isin(P)].fr)
    r['SeqNeut A/Darwin/6/2021 GMFR d29']=2**sq[(sq.virus=='A/Darwin/6/2021_H3N2')&(sq.arm==arm)].lfc29.mean()
    r['SeqNeut A/Thailand/8/2022 GMFR d29']=2**sq[(sq.virus=='A/Thailand/8/2022_H3N2')&(sq.arm==arm)].lfc29.mean()
    r['SeqNeut contemporary H3N2 (68) GMFR d29']=2**sq[(sq.category=='contemporary H3N2 (2022-24 isolate)')&(sq.arm==arm)].groupby('pid').lfc29.mean().mean()
    r['ELISA A/H1 IgG GMFR wk4']=gm(el[(el.antigen=='A/H1')&el.participant.isin(P)].value)
    r['Bead A/Wisconsin/67/2022 binding GMFR']=2**b[(b.strain=='A/Wisconsin/67/2022')&b.pnum.isin(P)].log2_fold_change_mfi.mean()
    r['HAI A/H1N1 GMFR wk4']=gm(hw[(hw.antigen=='A/H1N1')&hw.pnum.isin(P)].fr)
    r['SeqNeut A/Wisconsin/67/2022 GMFR d29']=2**sq[(sq.virus=='A/Wisconsin/67/2022_H1N1')&(sq.arm==arm)].lfc29.mean()
    r['SeqNeut contemporary H1N1 (6) GMFR d29']=2**sq[(sq.category=='contemporary H1N1 (2022-24 isolate)')&(sq.arm==arm)].groupby('pid').lfc29.mean().mean()
    r['MN homologous GMFR wk4']=gm(mn[(mn.panel=='homologous')&mn.pnum.isin(P)].value)
    r['MN heterologous GMFR wk4']=gm(mn[(mn.panel=='heterologous')&mn.pnum.isin(P)].value)
    rows.append(r)
t=pd.DataFrame(rows).set_index('arm').T
t['mRNA/Fluarix']=t['mRNA-1010']/t['Fluarix']
print(t.round(2).to_string()); t.round(3).to_csv('/tmp/outputs/analysis/binding_vs_function_same_participants.csv')
