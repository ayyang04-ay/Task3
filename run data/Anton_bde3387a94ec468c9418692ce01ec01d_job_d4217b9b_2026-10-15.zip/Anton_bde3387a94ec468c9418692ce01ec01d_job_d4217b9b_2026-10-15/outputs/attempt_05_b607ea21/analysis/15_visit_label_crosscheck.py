"""Cross-check which late visit (wk17=d121 vs wk26=d181) each participant's late sample is assigned to, per assay file."""
import pandas as pd, numpy as np
D='/tmp/world/filesystem'
rec={}
def add(pid,src,lab):
    rec.setdefault(pid,{}).setdefault(src,set()).add(lab)
hai=pd.read_csv(f'{D}/hai_titers.csv',dtype={'participant':str})
for (ag,p,tp),_ in hai[hai.timepoint.isin(['wk17','wk26'])].groupby(['antigen','participant','timepoint']): add('397-'+p.zfill(3),f'HAI {ag}',tp)
mn=pd.read_csv(f'{D}/microneutralization.csv')
for (pn,p,tp),_ in mn[mn.timepoint.isin(['wk17','wk26'])].groupby(['panel','participant','timepoint']): add(p,f'MN {pn}',tp)
el=pd.read_csv(f'{D}/elisa_igg_titers.csv')
for (ag,p,tp),_ in el[el.timepoint.isin(['wk17','wk26'])].groupby(['antigen','participant','timepoint']): add('397-'+str(p).zfill(3),f'ELISA {ag}',tp)
sq=pd.read_csv(f'{D}/neutralization_seqbased.csv'); sq['pid']=sq.serum.str.split('_').str[1]; sq['day']=sq.serum.str.split('_').str[2]
for (p,dd),_ in sq[sq.day.isin(['d121','d181'])].groupby(['pid','day']): add(p,'SeqNeut',{'d121':'wk17','d181':'wk26'}[dd])
rows=[]
for p,s in sorted(rec.items()):
    labs={k:'/'.join(sorted(v)) for k,v in s.items()}
    distinct=set(labs.values())
    if len(distinct)>1: rows.append(dict(pid=p,**labs))
t=pd.DataFrame(rows)
pd.set_option('display.width',250)
print('Participants whose late-visit label differs between assay files:',len(t))
print(t.fillna('-').to_string())
t.to_csv('/tmp/outputs/analysis/visit_label_inconsistencies.csv',index=False)
