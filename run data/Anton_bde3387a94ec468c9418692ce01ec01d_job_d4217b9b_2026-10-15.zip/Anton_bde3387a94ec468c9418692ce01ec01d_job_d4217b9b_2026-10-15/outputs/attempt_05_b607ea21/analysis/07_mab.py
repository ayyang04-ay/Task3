"""Monoclonal antibody binding panels: per-donor breadth profiles (donor = unit of replication).
fold_over_control is normalised to the SARS-CoV-2 RBD well (=1 by construction), so positivity
threshold is set from the distribution trough (~5x) with sensitivity at 3x and 10x."""
import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width',250)
m=pd.read_csv('/tmp/world/filesystem/mab_binding_panels.csv')
m['donor']='397-'+m.mab_id.str.split('.').str[1]
w=m.pivot_table(index=['arm','donor','mab_id'],columns='antigen',values='fold_over_control').reset_index()
g1_h1=['A/Puerto Rico/8/1934','A/New Caledonia/20/1999','A/California/04/2009','A/Wisconsin/588/2019','A/Victoria/4897/2022','A/Netherlands/01317/2025']
g2_h3=['A/Hong Kong/1/1968','A/Fujian/411/2002','A/Texas/50/2012','A/Darwin/6/2021','A/Thailand/8/2022','A/Croatia/10136RV/2023']
def summarize(thr):
    pos=w.copy()
    ags=[c for c in w.columns if c.startswith('A/')]
    for c in ags: pos[c]=w[c]>=thr
    tested_g1=w['A/Victoria/4897/2022'].notna(); tested_g2=w['A/Darwin/6/2021'].notna()
    pos['tested_g1']=tested_g1; pos['tested_g2']=tested_g2
    pos['H1_binder']=tested_g1 & pos[g1_h1].any(axis=1)
    pos['H3_binder']=tested_g2 & pos[g2_h3].any(axis=1)
    # among H1-binders
    pos['H1_n_strains']=pos[g1_h1].sum(axis=1).where(tested_g1)
    pos['H1_all6']=tested_g1 & pos[g1_h1].all(axis=1)
    pos['H5_cross']=tested_g1 & pos['A/Hubei/1/2010 (H5)']
    pos['H7_cross']=tested_g2 & pos['A/Shanghai/1/2013 (H7)']
    pos['H3_n_strains']=pos[g2_h3].sum(axis=1).where(tested_g2)
    pos['H3_all6']=tested_g2 & pos[g2_h3].all(axis=1)
    pos['Vic4897_only_not_Wis588']=tested_g1 & pos['A/Victoria/4897/2022'] & ~pos['A/Wisconsin/588/2019']
    pos['Wis588_only_not_Vic4897']=tested_g1 & pos['A/Wisconsin/588/2019'] & ~pos['A/Victoria/4897/2022']
    pos['binds_2025_H1']=tested_g1 & pos['A/Netherlands/01317/2025']
    pos['binds_2023_H3_Croatia']=tested_g2 & pos['A/Croatia/10136RV/2023']
    pos['binds_Thailand2022']=tested_g2 & pos['A/Thailand/8/2022']
    rows=[]
    for (arm,donor),g in pos.groupby(['arm','donor']):
        g1=g[g.tested_g1]; g2=g[g.tested_g2]
        g1b=g1[g1.H1_binder]; g2b=g2[g2.H3_binder]
        rows.append(dict(threshold=thr,arm=arm,donor=donor,n_mabs=len(g),n_groupI_tested=len(g1),n_H1_binders=len(g1b),
            pct_H1b_bind_Vic4897=round(100*g1b['A/Victoria/4897/2022'].mean(),0) if len(g1b) else np.nan,
            pct_H1b_bind_Wis588=round(100*g1b['A/Wisconsin/588/2019'].mean(),0) if len(g1b) else np.nan,
            pct_H1b_bind_Neth2025=round(100*g1b['A/Netherlands/01317/2025'].mean(),0) if len(g1b) else np.nan,
            pct_H1b_bind_PR8=round(100*g1b['A/Puerto Rico/8/1934'].mean(),0) if len(g1b) else np.nan,
            pct_H1b_all6_H1=round(100*g1b.H1_all6.mean(),0) if len(g1b) else np.nan,
            pct_H1b_H5=round(100*g1b.H5_cross.mean(),0) if len(g1b) else np.nan,
            n_groupII_tested=len(g2),n_H3_binders=len(g2b),
            pct_H3b_bind_Darwin6=round(100*g2b['A/Darwin/6/2021'].mean(),0) if len(g2b) else np.nan,
            pct_H3b_bind_Thai2022=round(100*g2b['A/Thailand/8/2022'].mean(),0) if len(g2b) else np.nan,
            pct_H3b_bind_Croatia2023=round(100*g2b['A/Croatia/10136RV/2023'].mean(),0) if len(g2b) else np.nan,
            pct_H3b_bind_HK1968=round(100*g2b['A/Hong Kong/1/1968'].mean(),0) if len(g2b) else np.nan,
            pct_H3b_all6_H3=round(100*g2b.H3_all6.mean(),0) if len(g2b) else np.nan,
            pct_H3b_H7=round(100*g2b.H7_cross.mean(),0) if len(g2b) else np.nan))
    return pd.DataFrame(rows), pos
allr=[]
for thr in [3,5,10]:
    r,pos=summarize(thr); allr.append(r)
    print(f'\n==== threshold {thr}x ====')
    print(r.drop(columns=['threshold']).to_string())
res=pd.concat(allr); res.to_csv('/tmp/outputs/analysis/mab_donor_level_breadth.csv',index=False)
# pooled vs donor-level contrast at 5x
r,pos=summarize(5)
for col,label,sub in [('H5_cross','H5 cross-reactive among H1 binders','H1_binder'),('H7_cross','H7 cross-reactive among H3 binders','H3_binder'),
                      ('binds_2025_H1','binds A/Netherlands/01317/2025 among H1 binders','H1_binder'),('binds_2023_H3_Croatia','binds A/Croatia/10136RV/2023 among H3 binders','H3_binder')]:
    s=pos[pos[sub]]
    pooled=s.groupby('arm')[col].agg(['sum','count'])
    donor=s.groupby(['arm','donor'])[col].mean().groupby('arm').agg(['mean','min','max','count'])
    print(f'\n{label}: pooled mAb-level\n{pooled}\n donor-level fraction (mean,min,max,n donors)\n{donor.round(2)}')
# Share of all mAbs contributed by the largest donor per arm
print(w.groupby(['arm','donor']).size().groupby(level=0).apply(lambda s:(s/s.sum()).round(2)))
