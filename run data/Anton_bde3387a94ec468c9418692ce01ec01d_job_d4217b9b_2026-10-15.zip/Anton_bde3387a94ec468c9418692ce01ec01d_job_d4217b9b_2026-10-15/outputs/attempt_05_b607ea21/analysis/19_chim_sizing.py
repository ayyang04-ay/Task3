"""Challenge-study sizing (planning; attack rates are external assumptions, not WU397 data)."""
import numpy as np
from scipy import stats
def n_two_prop(p1,p2,alpha=0.05,power=0.8):
    za=stats.norm.ppf(1-alpha/2); zb=stats.norm.ppf(power); pb=(p1+p2)/2
    return int(np.ceil((za*np.sqrt(2*pb*(1-pb))+zb*np.sqrt(p1*(1-p1)+p2*(1-p2)))**2/(p1-p2)**2))
for pp in [0.3,0.4,0.5]:
    for rr in [0.5,0.6]:
        pv=pp*(1-rr)
        print(f'placebo attack {pp:.0%}, vaccine reduces by {rr:.0%} -> {pv:.0%}: n/arm (80% power) = {n_two_prop(pp,pv)}; (90%) = {n_two_prop(pp,pv,power=0.9)}')
# head-to-head mRNA vs comparator: e.g., comparator 20% vs mRNA 10%
print('head-to-head 20% vs 10%:', n_two_prop(0.2,0.1), 'per arm (80% power)')
