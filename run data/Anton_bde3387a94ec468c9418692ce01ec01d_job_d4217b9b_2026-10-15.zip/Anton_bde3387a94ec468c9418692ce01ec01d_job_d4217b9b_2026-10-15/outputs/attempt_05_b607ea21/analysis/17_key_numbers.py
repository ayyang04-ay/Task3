"""Assemble every number quoted in answer.md from the analysis outputs (single source of truth)."""
import pandas as pd, numpy as np
A='/tmp/outputs/analysis'
rows=[]
def add(topic,quantity,value,source_file,script):
    rows.append(dict(topic=topic,quantity=quantity,value=value,source_data=source_file,derived_by=script))
# ELISA
e=pd.read_csv(f'{A}/elisa_summary.csv'); ec=pd.read_csv(f'{A}/elisa_arm_comparisons.csv')
for ag in ['A/H1','A/H3','B/Vic','B/Yam']:
    for arm in ['mRNA-1010','Fluarix']:
        r=e[(e.antigen==ag)&(e.arm==arm)&(e.quantity=='GMFR wk4')].iloc[0]
        add('ELISA IgG',f'{ag} GMFR wk4 {arm} (n={r.n})',f'{r.value} ({r.lo}-{r.hi})','elisa_igg_titers.csv','02_elisa.py')
    r=ec[(ec.antigen==ag)&(ec.quantity=='fc_wk4')].iloc[0]
    add('ELISA IgG',f'{ag} GMFR ratio mRNA/Fluarix wk4',f'{r.ratio_mRNA_over_Fluarix} ({r.lo}-{r.hi}), p={r.p_welch}','elisa_igg_titers.csv','02_elisa.py')
    r=ec[(ec.antigen==ag)&(ec.quantity=='fc_wk17/26')].iloc[0]
    add('ELISA IgG',f'{ag} GMFR ratio mRNA/Fluarix wk17/26',f'{r.ratio_mRNA_over_Fluarix} ({r.lo}-{r.hi})','elisa_igg_titers.csv','02_elisa.py')
# Bead
b=pd.read_csv(f'{A}/bead_breadth_by_strain.csv')
for s in ['A/Darwin/6/2021','A/Thailand/8/2022','A/Hong Kong/1/1968','A/Wisconsin/67/2022','A/Wisconsin/588/2019','A/Puerto Rico/8/1934','A/Sydney/5/2021']:
    r=b[b.strain==s].iloc[0]
    add('Bead-array binding',f'{s}: GMFR mRNA vs Fluarix; ratio (95% CI)',f'{r.GMFR_mRNA} vs {r.GMFR_Fluarix}; {r.ratio_of_GMFR} ({r.lo}-{r.hi}), q={r.q_BH}','binding_breadth_h1/h3.csv','04_bead_breadth.py')
# HAI
h=pd.read_csv(f'{A}/hai_summary.csv'); hc=pd.read_csv(f'{A}/hai_arm_comparisons.csv'); ha=pd.read_csv(f'{A}/hai_ancova_wk4.csv')
for ag in ['A/H1N1','A/H3N2','B/Vic','B/Yam']:
    for arm in ['mRNA-1010','Fluarix']:
        r4=h[(h.antigen==ag)&(h.arm==arm)&(h.timepoint=='wk4')].iloc[0]; r0=h[(h.antigen==ag)&(h.arm==arm)&(h.timepoint=='wk0')].iloc[0]
        add('HAI',f'{ag} {arm}: wk4 GMT; GMFR; seroconversion; %>=40 at wk0',f'{r4.GMT} ({r4.GMT_lo}-{r4.GMT_hi}); {r4.GMFR}; {int(r4.n_seroconv)}/{int(r4.n_paired)} ({r4.pct_seroconv}%); {r0.pct_ge40}%','hai_titers.csv','01_hai.py')
    r=hc[(hc.antigen==ag)&(hc.comparison=='GMT ratio wk4')].iloc[0]; ra=ha[ha.antigen==ag].iloc[0]
    add('HAI',f'{ag} wk4 GMT ratio mRNA/Fluarix; baseline-adjusted',f'{r.ratio} ({r.lo}-{r.hi}); {ra.adj_GMT_ratio_wk4} ({ra.lo}-{ra.hi})','hai_titers.csv','01_hai.py')
# MN
m=pd.read_csv(f'{A}/mn_summary.csv'); mc=pd.read_csv(f'{A}/mn_arm_comparisons.csv')
for p in ['homologous','heterologous']:
    for arm in ['mRNA-1010','Fluarix']:
        r=m[(m.panel==p)&(m.arm==arm)].iloc[0]
        add('Microneutralisation',f'{p} {arm}: GMT wk0; wk4; wk17/26; GMFR wk4; n at ULOQ(1280) wk4',f'{r.GMT_wk0}; {r.GMT_wk4}; {r.GMT_late}; {r.GMFR_wk4}; {r.n_wk4_at_ULOQ}/{r.n}','microneutralization.csv','03_mn.py')
    for q in ['wk0','wk4','late','fc_wk4']:
        r=mc[(mc.panel==p)&(mc.quantity==q)].iloc[0]
        add('Microneutralisation',f'{p} ratio mRNA/Fluarix {q}',f'{r.ratio} ({r.lo}-{r.hi}), p={r.p_welch}','microneutralization.csv','03_mn.py')
# Seqneut participant level
s=pd.read_csv(f'{A}/seqneut_participant_level_summary.csv')
for _,r in s.iterrows():
    add('Seq-based neutralisation',f'{r.group}: GMT d0 mRNA vs Flu; d29; ANCOVA d29 ratio; GMFR; late ratio',
        f'{r.mRNA_d0:.0f} vs {r.Flu_d0:.0f} ({r.ratio_d0}); {r.mRNA_d29:.0f} vs {r.Flu_d29:.0f} ({r.ratio_d29}, p={r.p_d29}); {r.ANCOVA_d29_ratio} p={r.p_ANCOVA}; {r.mRNA_fr29} vs {r.Flu_fr29} ({r.ratio_fr29}); {r.ratio_late}',
        'neutralization_seqbased.csv','05/06_seqneut*.py')
t=pd.read_csv(f'{A}/seqneut_per_virus_ancova.csv')
for v in ['A/Massachusetts/18/2022_H3N2','A/DistrictOfColumbia/27/2023_H3N2']:
    r=t[t.virus==v].iloc[0]; add('Seq-based neutralisation',f'{v} ANCOVA d29 ratio',f'{r.adj_ratio_d29} ({r.lo}-{r.hi})','neutralization_seqbased.csv','14_seqneut_per_virus_ancova.py')
add('Seq-based neutralisation','viruses with BH q<0.05 (per-virus ANCOVA)',f'{int((t.q_BH<0.05).sum())}/{len(t)}','neutralization_seqbased.csv','14_seqneut_per_virus_ancova.py')
c=t[t.category=='contemporary H3N2 (2022-24 isolate)']
add('Seq-based neutralisation','contemporary H3N2: median per-virus adjusted ratio; n with 95% LB>1',f'{c.adj_ratio_d29.median():.2f}; {int((c.lo>1).sum())}/{len(c)}','neutralization_seqbased.csv','14_seqneut_per_virus_ancova.py')
c=t[t.category=='contemporary H1N1 (2022-24 isolate)']
add('Seq-based neutralisation','contemporary H1N1: median per-virus adjusted ratio; n with 95% LB>1',f'{c.adj_ratio_d29.median():.2f}; {int((c.lo>1).sum())}/{len(c)}','neutralization_seqbased.csv','14_seqneut_per_virus_ancova.py')
out=pd.DataFrame(rows); out.to_csv('/tmp/outputs/key_numbers.csv',index=False)
pd.set_option('display.width',300); pd.set_option('display.max_colwidth',200); pd.set_option('display.max_rows',300)
print(out[['topic','quantity','value']].to_string())
