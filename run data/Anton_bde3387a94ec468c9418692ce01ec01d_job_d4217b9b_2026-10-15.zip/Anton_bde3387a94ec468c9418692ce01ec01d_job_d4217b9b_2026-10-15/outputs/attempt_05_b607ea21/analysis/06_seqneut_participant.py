"""Participant-level seqneut summaries (one value per participant per virus-category) to avoid
pseudo-replication across the 96 viruses; arm comparison by Welch t on log2, MWU, and ANCOVA (baseline-adjusted)."""
import pandas as pd, numpy as np
from scipy import stats
import statsmodels.formula.api as smf
pd.set_option('display.width',250)
w=pd.read_csv('/tmp/outputs/analysis/seqneut_wide_log2.csv')
groups={
 'contemporary H3N2 (n=68)':w.category=='contemporary H3N2 (2022-24 isolate)',
 'contemporary H1N1 (n=6)':w.category=='contemporary H1N1 (2022-24 isolate)',
 'historical H3N2 WT (n=8)':w.category=='historical H3N2',
 'historical H3N2 egg-reassortant (n=5)':w.category=='historical H3N2 (egg reassortant)',
 'historical H1N1 (n=4)':w.category=='historical H1N1',
 'A/Darwin/6/2021 (mRNA-1010 H3)':w.virus=='A/Darwin/6/2021_H3N2',
 'A/Darwin/9/2021 (Fluarix H3 analogue)':w.virus=='A/Darwin/9/2021_H3N2',
 'A/Victoria/4897/2022 IVR-238 (mRNA-1010 H1, egg)':w.virus=='A/Victoria/4897/2022_IVR-238_H1N1',
 'A/Wisconsin/67/2022 (mRNA-1010-like H1)':w.virus=='A/Wisconsin/67/2022_H1N1',
 'A/Wisconsin/588/2019 (Fluarix-like H1)':w.virus=='A/Wisconsin/588/2019_H1N1',
 'A/Thailand/8/2022 (2024-25 H3 vaccine strain)':w.virus=='A/Thailand/8/2022_H3N2',
}
rows=[]; pp_all=[]
for name,sel in groups.items():
    pp=w[sel].groupby(['arm','pid'])[['d0','d29','late']].mean().reset_index()   # mean log2 over viruses = log2 of per-participant GMT
    pp['fr29']=pp.d29-pp.d0; pp['group']=name; pp_all.append(pp)
    a=pp[pp.arm=='mRNA-1010']; f=pp[pp.arm=='Fluarix']
    r=dict(group=name,n_m=len(a),n_f=len(f))
    for c in ['d0','d29','late','fr29']:
        x=a[c].dropna(); y=f[c].dropna(); dd=x.mean()-y.mean()
        va,vb=x.var(ddof=1)/len(x),y.var(ddof=1)/len(y); se=np.sqrt(va+vb); df=(va+vb)**2/(va**2/(len(x)-1)+vb**2/(len(y)-1)); tq=stats.t.ppf(.975,df)
        r[f'mRNA_{c}']=round(2**x.mean(),2 if c=='fr29' else 0); r[f'Flu_{c}']=round(2**y.mean(),2 if c=='fr29' else 0)
        r[f'ratio_{c}']=f'{2**dd:.2f} ({2**(dd-tq*se):.2f}-{2**(dd+tq*se):.2f})'
        r[f'p_{c}']=round(stats.ttest_ind(x,y,equal_var=False).pvalue,3)
    g=pp.dropna(subset=['d0','d29']).copy(); g['mrna']=(g.arm=='mRNA-1010').astype(int)
    fit=smf.ols('d29 ~ mrna + d0',data=g).fit(); b=fit.params['mrna']; lo,hi=fit.conf_int().loc['mrna']
    r['ANCOVA_d29_ratio']=f'{2**b:.2f} ({2**lo:.2f}-{2**hi:.2f})'; r['p_ANCOVA']=round(fit.pvalues['mrna'],3)
    rows.append(r)
res=pd.DataFrame(rows)
print(res[['group','n_m','n_f','mRNA_d0','Flu_d0','ratio_d0','p_d0','mRNA_d29','Flu_d29','ratio_d29','p_d29','ANCOVA_d29_ratio','p_ANCOVA']].to_string())
print()
print(res[['group','mRNA_fr29','Flu_fr29','ratio_fr29','p_fr29','mRNA_late','Flu_late','ratio_late','p_late']].to_string())
res.to_csv('/tmp/outputs/analysis/seqneut_participant_level_summary.csv',index=False)
pd.concat(pp_all).to_csv('/tmp/outputs/analysis/seqneut_participant_level_values.csv',index=False)

# Cross-check: does the binding (bead) advantage predict neutralisation? participant-level correlation
b3=pd.read_csv('/tmp/world/filesystem/binding_breadth_h3.csv'); b1=pd.read_csv('/tmp/world/filesystem/binding_breadth_h1.csv')
for sub,b,vir_seq,strain in [('H3',b3,'A/Darwin/6/2021_H3N2','A/Darwin/6/2021'),('H3',b3,'A/Thailand/8/2022_H3N2','A/Thailand/8/2022'),('H1',b1,'A/Wisconsin/67/2022_H1N1','A/Wisconsin/67/2022'),('H1',b1,'A/Wisconsin/588/2019_H1N1','A/Wisconsin/588/2019')]:
    bb=b[b.strain==strain][['participant','arm','log2_fold_change_mfi']]
    nn=w[w.virus==vir_seq][['pid','lfc29']].rename(columns={'pid':'participant','lfc29':'neut_log2FR'})
    mm=bb.merge(nn,on='participant')
    rho=stats.spearmanr(mm.log2_fold_change_mfi,mm.neut_log2FR)
    print(f'{strain}: binding log2FC vs neut log2FR (d29/d0), n={len(mm)}, Spearman rho={rho.correlation:.2f}, p={rho.pvalue:.2g}; '
          f'binding GMFR mRNA={2**mm[mm.arm=="mRNA-1010"].log2_fold_change_mfi.mean():.1f} vs Flu={2**mm[mm.arm=="Fluarix"].log2_fold_change_mfi.mean():.1f}; '
          f'neut GMFR mRNA={2**mm[mm.arm=="mRNA-1010"].neut_log2FR.mean():.2f} vs Flu={2**mm[mm.arm=="Fluarix"].neut_log2FR.mean():.2f}')
