"""Sequencing-based neutralisation: per-virus GMT / GMFR by arm, virus classification relative to
EACH arm's actual vaccine antigen, participant-level breadth summaries, baseline balance.
Censored titers (titer_bound upper = '<=' value, lower = '>=' value) are kept at the bound (conservative)
and counted."""
import pandas as pd, numpy as np, re
from scipy import stats
from statsmodels.stats.multitest import multipletests
import statsmodels.formula.api as smf
pd.set_option('display.width',250); pd.set_option('display.max_rows',500)
D='/tmp/world/filesystem'
d=pd.read_csv(f'{D}/neutralization_seqbased.csv')
d['arm']=d.serum.str.split('_').str[0]; d['pid']=d.serum.str.split('_').str[1]; d['day']=d.serum.str.split('_').str[2]
d['subtype']=d.virus.str.extract(r'_(H\dN\d)$')[0]
d['year']=d.virus.str.extract(r'/(\d{4})(?:egg|X-\d+A|NIB-\d+|_IVR-\d+)?_H\dN\d$')[0]
d.loc[d.virus=='A/SOUTHAFRICA/R07876/202023_H3N2','year']='2023?'  # malformed year in source
reassort=lambda v: bool(re.search(r'(egg|X-\d+A|NIB-\d+|IVR-\d+)',v))
d['egg_reassortant']=d.virus.map(reassort)
def classify(v):
    s=v.rsplit('_',1)[1] if not 'IVR' in v else 'H1N1'
    if v=='A/Victoria/4897/2022_IVR-238_H1N1': return 'mRNA-1010 H1 strain (egg reassortant)'
    if v=='A/Wisconsin/67/2022_H1N1': return 'mRNA-1010-matched H1 (A/Victoria/4897/2022-like)'
    if v=='A/Wisconsin/588/2019_H1N1': return 'Fluarix-matched H1 (A/Victoria/2570/2019-like)'
    if v=='A/Darwin/6/2021_H3N2': return 'mRNA-1010 H3 strain'
    if v=='A/Darwin/9/2021_H3N2': return 'Fluarix H3 strain (egg-based analogue)'
    y=d.loc[d.virus==v,'year'].iloc[0]
    if reassort(v): return f'historical {s} (egg reassortant)'
    if y in ('2022','2023','2024','2023?'): return f'contemporary {s} (2022-24 isolate)'
    return f'historical {s}'
vc=pd.DataFrame({'virus':sorted(d.virus.unique())}); vc['category']=vc.virus.map(classify)
vc['subtype']=vc.virus.map(lambda v:'H1N1' if 'H1N1' in v else 'H3N2')
vc['egg_reassortant']=vc.virus.map(reassort)
d=d.merge(vc[['virus','category']],on='virus')
print(vc.category.value_counts().to_string())
vc.to_csv('/tmp/outputs/analysis/seqneut_virus_classification.csv',index=False)
print('\nCensoring by day:'); print(pd.crosstab([d.arm,d.day],d.titer_bound))
d['lt']=np.log2(d.titer)
w=d.pivot_table(index=['arm','pid','virus','category','subtype'],columns='day',values='lt').reset_index()
w['late']=w.d181.fillna(w.d121)
w['lfc29']=w.d29-w.d0; w['lfcl']=w.late-w.d0
rows=[]
for (v,cat),g in w.groupby(['virus','category']):
    a=g[g.arm=='mRNA-1010']; f=g[g.arm=='Fluarix']
    r=dict(virus=v,category=cat)
    for tag,col in [('d0','d0'),('d29','d29'),('late','late'),('FR29','lfc29'),('FRlate','lfcl')]:
        x=a[col].dropna(); y=f[col].dropna()
        r[f'mRNA_{tag}']=round(2**x.mean(),1 if tag[0]!='F' else 2); r[f'Flu_{tag}']=round(2**y.mean(),1 if tag[0]!='F' else 2)
        dd=x.mean()-y.mean(); r[f'ratio_{tag}']=round(2**dd,2)
        r[f'p_{tag}']=stats.mannwhitneyu(x,y).pvalue if len(x)>1 and len(y)>1 else np.nan
    r['n_m']=a.d29.notna().sum(); r['n_f']=f.d29.notna().sum()
    rows.append(r)
pv=pd.DataFrame(rows)
for tag in ['d0','d29','FR29']:
    pv[f'q_{tag}']=multipletests(pv[f'p_{tag}'].fillna(1),method='fdr_bh')[1]
pv.to_csv('/tmp/outputs/analysis/seqneut_per_virus.csv',index=False)
cols=['virus','category','n_m','n_f','mRNA_d0','Flu_d0','ratio_d0','mRNA_d29','Flu_d29','ratio_d29','q_d29','mRNA_FR29','Flu_FR29','ratio_FR29','q_FR29','ratio_late']
print(pv.sort_values(['category','virus'])[cols].to_string())
w.to_csv('/tmp/outputs/analysis/seqneut_wide_log2.csv',index=False)
