import pandas as pd, numpy as np
from scipy import stats
g=pd.read_csv('/tmp/world/filesystem/igm_fold_change.csv',dtype={'participant':str})
rows=[]
for (ag,arm),x in g.groupby(['antigen','arm']):
    rows.append(dict(antigen=ag,arm=arm,n=len(x),n_rise_gt1=int((x.fold_change>1).sum()),n_ge4=int((x.fold_change>=4).sum()),GMFR=round(2**np.log2(x.fold_change).mean(),2)))
t=pd.DataFrame(rows); print(t.to_string())
for ag,x in g.groupby('antigen'):
    a=x[x.arm=='mRNA-1010'].fold_change; f=x[x.arm=='Fluarix'].fold_change
    tab=[[int((a>=4).sum()),int((a<4).sum())],[int((f>=4).sum()),int((f<4).sum())]]
    print(ag,'>=4-fold IgM: mRNA',tab[0][0],'/',len(a),' Fluarix',tab[1][0],'/',len(f),' Fisher p=',round(stats.fisher_exact(tab)[1],3),' MWU p=',round(stats.mannwhitneyu(a,f).pvalue,3))
t.to_csv('/tmp/outputs/analysis/igm_summary.csv',index=False)
