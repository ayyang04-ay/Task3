"""HAI analysis: GMT, GMFR, seroconversion (>=4-fold & >=40 post, or 4-fold from <10),
seroprotection (>=40), per antigen/arm/timepoint; arm comparisons (Mann-Whitney on log titers,
GMT ratio with 95% CI by t-test on log2 scale). Also baseline balance.
"""
import pandas as pd, numpy as np
from scipy import stats
D='/tmp/world/filesystem'
h=pd.read_csv(f'{D}/hai_titers.csv',dtype={'participant':str})
h['lt']=np.log2(h.hai_titer)
out=[]
def gmt(x): return 2**np.mean(np.log2(x))
def gm_ci(lx):
    n=len(lx); m=np.mean(lx); se=np.std(lx,ddof=1)/np.sqrt(n); t=stats.t.ppf(.975,n-1)
    return 2**m, 2**(m-t*se), 2**(m+t*se)
w=h.pivot_table(index=['antigen','arm','participant'],columns='timepoint',values='hai_titer').reset_index()
rows=[]
for (ag,arm),g in w.groupby(['antigen','arm']):
    for tp in ['wk0','wk4','wk26']:
        x=g[tp].dropna()
        m,lo,hi=gm_ci(np.log2(x))
        r=dict(antigen=ag,arm=arm,timepoint=tp,n=len(x),GMT=round(m,1),GMT_lo=round(lo,1),GMT_hi=round(hi,1),
               pct_ge40=round(100*(x>=40).mean(),1))
        if tp!='wk0':
            gg=g[[ 'wk0',tp]].dropna()
            fr=gg[tp]/gg['wk0']
            m2,lo2,hi2=gm_ci(np.log2(fr))
            sc=((fr>=4)&(gg[tp]>=40))|((gg['wk0']<10)&(gg[tp]>=40))
            r.update(n_paired=len(gg),GMFR=round(m2,2),GMFR_lo=round(lo2,2),GMFR_hi=round(hi2,2),
                     n_seroconv=int(sc.sum()),pct_seroconv=round(100*sc.mean(),1))
        rows.append(r)
res=pd.DataFrame(rows)
print(res.to_string())
res.to_csv('/tmp/outputs/analysis/hai_summary.csv',index=False)

# Arm comparisons: GMT ratio mRNA/Fluarix at wk4, and GMFR ratio; baseline.
rows=[]
for ag,g in w.groupby('antigen'):
    for tp in ['wk0','wk4','wk26']:
        a=np.log2(g[g.arm=='mRNA-1010'][tp].dropna()); b=np.log2(g[g.arm=='Fluarix'][tp].dropna())
        t=stats.ttest_ind(a,b,equal_var=False); u=stats.mannwhitneyu(a,b)
        d=a.mean()-b.mean()
        se=np.sqrt(a.var(ddof=1)/len(a)+b.var(ddof=1)/len(b))
        # welch df
        df=(a.var(ddof=1)/len(a)+b.var(ddof=1)/len(b))**2/((a.var(ddof=1)/len(a))**2/(len(a)-1)+(b.var(ddof=1)/len(b))**2/(len(b)-1))
        tq=stats.t.ppf(.975,df)
        rows.append(dict(antigen=ag,comparison=f'GMT ratio {tp}',ratio=round(2**d,2),lo=round(2**(d-tq*se),2),hi=round(2**(d+tq*se),2),p_welch=round(t.pvalue,3),p_MWU=round(u.pvalue,3),n_m=len(a),n_f=len(b)))
    for tp in ['wk4','wk26']:
        gg=g.dropna(subset=['wk0',tp])
        fr=np.log2(gg[tp]/gg['wk0'])
        a=fr[gg.arm=='mRNA-1010']; b=fr[gg.arm=='Fluarix']
        t=stats.ttest_ind(a,b,equal_var=False); u=stats.mannwhitneyu(a,b)
        d=a.mean()-b.mean(); se=np.sqrt(a.var(ddof=1)/len(a)+b.var(ddof=1)/len(b))
        df=(a.var(ddof=1)/len(a)+b.var(ddof=1)/len(b))**2/((a.var(ddof=1)/len(a))**2/(len(a)-1)+(b.var(ddof=1)/len(b))**2/(len(b)-1))
        tq=stats.t.ppf(.975,df)
        rows.append(dict(antigen=ag,comparison=f'GMFR ratio {tp}/wk0',ratio=round(2**d,2),lo=round(2**(d-tq*se),2),hi=round(2**(d+tq*se),2),p_welch=round(t.pvalue,3),p_MWU=round(u.pvalue,3),n_m=len(a),n_f=len(b)))
cmp_=pd.DataFrame(rows)
print(cmp_.to_string())
cmp_.to_csv('/tmp/outputs/analysis/hai_arm_comparisons.csv',index=False)

# ANCOVA: log2 wk4 ~ arm + log2 wk0
import statsmodels.formula.api as smf
rows=[]
for ag,g in w.groupby('antigen'):
    gg=g.dropna(subset=['wk0','wk4']).copy()
    gg['l0']=np.log2(gg.wk0); gg['l4']=np.log2(gg.wk4); gg['mrna']=(gg.arm=='mRNA-1010').astype(int)
    m=smf.ols('l4 ~ mrna + l0',data=gg).fit()
    b=m.params['mrna']; lo,hi=m.conf_int().loc['mrna']
    rows.append(dict(antigen=ag,adj_GMT_ratio_wk4=round(2**b,2),lo=round(2**lo,2),hi=round(2**hi,2),p=round(m.pvalues['mrna'],3),n=len(gg)))
anc=pd.DataFrame(rows); print(anc.to_string()); anc.to_csv('/tmp/outputs/analysis/hai_ancova_wk4.csv',index=False)
