"""FNA GC/PB, serum IgG repertoire summaries. Exploratory; small n; provenance caveats noted."""
import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width',250)
D='/tmp/world/filesystem'
gc=pd.read_csv(f'{D}/gc_frequencies.csv',dtype={'participant':str})
gc['block']=gc.groupby(['timepoint','arm','participant']).cumcount()+1
print('GC file: two stacked blocks share one header; block sizes', gc.block.value_counts().to_dict())
for b in [1,2]:
    x=gc[gc.block==b]
    s=x.groupby(['timepoint','arm']).pct_ha_specific_igg_gc.agg(['count','median','mean','max']).round(2)
    print(f'\nBlock {b}:'); print(s.to_string())
    for tp in ['wk2','wk8','wk17','wk26']:
        a=x[(x.timepoint==tp)&(x.arm=='mRNA-1010')].pct_ha_specific_igg_gc; f=x[(x.timepoint==tp)&(x.arm=='Fluarix')].pct_ha_specific_igg_gc
        print(f'  {tp}: median mRNA {a.median():.2f} (n={len(a)}) vs Fluarix {f.median():.2f} (n={len(f)}); MWU p={stats.mannwhitneyu(a,f).pvalue:.3f}')
pb=pd.read_csv(f'{D}/plasmablast_frequencies.csv',dtype={'participant':str})
s=pb.groupby(['timepoint','arm']).pct_plasmablast.agg(['count','median','mean','max']).round(3)
print('\nPlasmablast file:'); print(s.to_string())
for tp in ['wk2','wk8','wk17','wk26']:
    a=pb[(pb.timepoint==tp)&(pb.arm=='mRNA-1010')].pct_plasmablast; f=pb[(pb.timepoint==tp)&(pb.arm=='Fluarix')].pct_plasmablast
    print(f'  {tp}: median mRNA {a.median():.3f} (n={len(a)}) vs Fluarix {f.median():.3f} (n={len(f)}); MWU p={stats.mannwhitneyu(a,f).pvalue:.3f}')
ov=pd.read_csv(f'{D}/pb_gc_clonal_overlap.csv'); print('\nPB-GC clonal overlap:'); print(ov.to_string())
cd=pd.read_csv(f'{D}/cdrh3_diversity_index.csv'); sc=pd.read_csv(f'{D}/serum_igg_clonotypes.csv'); rc=pd.read_csv(f'{D}/repertoire_clonotype_counts.csv')
print('\nCDRH3 diversity index:'); print(cd.groupby(['timepoint','arm']).diversity_index.agg(['count','median','mean']).round(1).to_string())
for tp in ['wk0','wk4','wk26']:
    a=cd[(cd.timepoint==tp)&(cd.arm=='mRNA-1010')].diversity_index; f=cd[(cd.timepoint==tp)&(cd.arm=='Fluarix')].diversity_index
    print(f'  {tp}: MWU p={stats.mannwhitneyu(a,f).pvalue:.3f}')
print('\nSerum IgG clonotypes:'); print(sc.groupby(['timepoint','arm']).n_clonotypes.agg(['count','median','mean']).round(1).to_string())
for tp in ['wk0','wk4','wk26']:
    a=sc[(sc.timepoint==tp)&(sc.arm=='mRNA-1010')].n_clonotypes; f=sc[(sc.timepoint==tp)&(sc.arm=='Fluarix')].n_clonotypes
    print(f'  {tp}: MWU p={stats.mannwhitneyu(a,f).pvalue:.3f}')
print('\nRepertoire clonotype counts:'); print(rc.groupby(['metric','arm']).value.agg(['count','median','mean','min','max']).round(1).to_string())
for met in rc.metric.unique():
    a=rc[(rc.metric==met)&(rc.arm=='mRNA-1010')].value; f=rc[(rc.metric==met)&(rc.arm=='Fluarix')].value
    print(f'  {met}: MWU p={stats.mannwhitneyu(a,f).pvalue:.3f}')
