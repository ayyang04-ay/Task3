**Recommendation in one line:** Don't build the protocol around heterologous protection yet — WU397's extra breadth is binding-only and its H1 comparison is antigen-confounded — so run a randomised, observer-blind, antigen-matched study with neutralisation against a locked panel of drifted wild-type strains as the primary go/no-go endpoint, and only if it passes run a multi-season relative-efficacy trial whose claim-defining endpoint is RT-PCR-confirmed illness from antigenically mismatched strains.

# WU397 (mRNA-1010 vs Fluarix, 2022–23): recommended next studies

## 1. The decision in brief

- **What WU397 shows:**
  - mRNA-1010 raises much more HA-**binding** antibody than Fluarix, and that binding covers many strains. For example, its bead-array binding fold-rise was about 9.5× Fluarix's against both A/Hong Kong/1/1968 and A/Thailand/8/2022.
  - mRNA-1010 also produced larger lymph-node germinal-centre responses in a small subset.
- **What WU397 doesn't show:** better **functional** antibody (HAI, microneutralisation, or the 96-virus sequencing-based neutralisation panel) against drifted strains.
  - Against 68 contemporary H3N2 isolates, the baseline-adjusted D29 neutralising GMT ratio (mRNA-1010/Fluarix) was **1.17 (95% CI 0.64–2.12)**.
  - Against mRNA-1010's own H3 strain (A/Darwin/6/2021) it was **0.62 (0.34–1.12)**.
  - H3N2 is the subtype where drift, and the case for a heterologous claim, matters most.
- **The one functional advantage is confounded and short-lived.** mRNA-1010 neutralised contemporary H1N1 about 2× better at D29 (adjusted ratio **2.06, 1.23–3.46**). But:
  - The two arms received **different H1 antigens**: mRNA-1010 had A/Victoria/4897/2022-like; the 2022–23 egg-based comparator had A/Victoria/2570/2019-like (per the 2022–23 recommendation; confirm against the lot label, §5).
  - The advantage was gone by D121/181 (ratio **1.06, 0.46–2.46**).
- **The breadth mRNA-1010 adds points backwards, not forwards** (in this small, non-randomised sample). After adjusting for baseline, its relative neutralising response rises steadily from its own vaccine strain (0.72), to contemporary drifted H3N2 (1.16), to historical H3N2 (1.80); the interaction p-values are 0.007 and <0.001.
  - This pattern looks like boosting of older memory (back-boosting), not protection against future drift.
- **WU397 can't settle the question either way.** The design blocks it:
  - allocation was non-randomised, by site;
  - the study was open-label;
  - the arms had different antigen compositions;
  - functional assays covered only 13–15 people per arm;
  - the package has no demographic, vaccination-history or infection data;
  - B/Yamagata is included, though it hasn't been confirmed in circulation since 2020.
- **The sequence I recommend:**

| Step | Purpose | Can support the claim? |
|---|---|---|
| 0. Reconcile data and add readouts on banked WU397 sera (before committee) | Fix data-integrity issues; identify missing strains; measure NA immunity, Fc function and each arm's *actual* vaccine strain | No – informs Study A |
| **A. Randomised, observer-blind, antigen-matched breadth study (Phase 2b)** | Test directly whether mRNA-1010 gives superior *neutralising* breadth against drifted strains when both arms carry the same strains. **Go/no-go.** | Immunological claim only: "higher neutralising titres against drifted strains" |
| B. Human challenge study with a drifted strain (optional) | Test whether the binding-dominated response protects | No – supportive/mechanistic only |
| **C. Multi-season relative-efficacy trial with a pre-specified mismatched-strain endpoint and a correlates sub-cohort** | Show protection against antigenically mismatched strains | **Yes – the only study that can carry "heterologous protection"** |

## 2. What the data package supports, and what it doesn't

### 2.1 Design features of WU397 that block a heterologous claim

1. **The arms received different H1 antigens, and "heterologous" was defined only from mRNA-1010's side.**
   - mRNA-1010 encoded A/Victoria/4897/2022 (H1N1)pdm09-like (`trial_summary.md`).
   - Fluarix was "as licensed and supplied for 2022–2023" (`trial_summary.md`). The egg-based 2022–23 formula is A/Victoria/2570/2019-like for H1 and A/Darwin/9/2021-like for H3 (external; §5). A/Victoria/4897/2022 only became the recommended H1 strain a season later.
   - The summary says the panel designations "refer to the mRNA-1010 antigens". As a result:
     - A/Wisconsin/67/2022 (the cell-based strain equivalent to A/Victoria/4897/2022) is in effect *homologous for mRNA-1010 and drifted for Fluarix*.
     - A/Wisconsin/588/2019 is in effect *homologous for Fluarix*.
     - A/Victoria/4897/2022_IVR-238 in the neutralisation panel is the egg-grown production strain of mRNA-1010's own H1, not a heterologous strain.
   - So **no H1 comparison in WU397 can separate platform from antigen choice.** H3 (A/Darwin/6/2021 vs A/Darwin/9/2021, which WHO treats as antigenically equivalent) and the B strains are the cleanest platform comparisons available, and neither shows a functional advantage.
2. **Allocation was non-randomised, by site, and open-label, and the arms start from different baselines.**
   - Participant IDs 033–059 are all Fluarix and 064–102 all mRNA-1010, which suggests separate enrolment blocks. Enrolment dates aren't in the package.
   - Baseline functional titres were lower in the mRNA-1010 arm:
     - contemporary H3N2 neutralisation GMT 143 vs 215 (ratio 0.66);
     - microneutralisation heterologous GMT 57 vs 121 (ratio 0.47, p=0.050).
   - That alone inflates mRNA-1010's fold-rises. For example, its heterologous microneutralisation fold-rise was higher (4.12 vs 3.03), yet its post-dose GMT was *lower* (235 vs 368; 126 vs 320 at wk17/26, ratio 0.39, 0.16–0.97).
   - **Fold-rise comparisons in this package are therefore not interpretable without baseline adjustment.**
3. **The functional cohorts are small:** HAI 14 vs 15; microneutralisation/bead array 14 vs 15; sequencing-based neutralisation 13 vs 14; lymph-node FNA 6 vs 11. Monoclonal antibodies came from 3 Fluarix donors (one donor, 397-05, supplied 84 of 106 Fluarix mAbs, 79%) and 4 mRNA-1010 donors.
4. **There is no protection readout at all:** no case surveillance and no infection serology. HAI, the only accepted surrogate, is accepted for vaccine-matched strains only.
5. **B/Yamagata is no longer relevant** (external; §5). B/Yam HAI and ELISA results have no bearing on protection, and the comparator itself is now trivalent.
6. **Assay ceiling.**
   - The microneutralisation upper limit (1:1280) capped **9 of 15** Fluarix homologous wk4 values (4 of 14 for mRNA-1010). This understates Fluarix's responses.
   - The assay files don't name the HAI and microneutralisation strains, or the ELISA antigens.

### 2.2 Binding does not equal neutralisation

In the same 13 vs 14 participants who have sequencing-based neutralisation data (`analysis/binding_vs_function_same_participants.csv`):

| Readout (fold-rise, D29/wk4 over baseline) | mRNA-1010 | Fluarix | Ratio |
|---|---|---|---|
| ELISA IgG, H3 | 8.01 | 2.20 | 3.64 |
| Bead binding, A/Darwin/6/2021 (H3 vaccine strain) | 27.19 | 3.78 | 7.19 |
| Bead binding, A/Thailand/8/2022 (a 2024–25 H3 vaccine strain) | 33.26 | 2.80 | 11.88 |
| HAI, H3N2 | 1.57 | 1.68 | 0.93 |
| Neutralisation, A/Darwin/6/2021 | 2.24 | 2.74 | 0.82 |
| Neutralisation, A/Thailand/8/2022 | 2.58 | 2.91 | 0.89 |

Full-cohort figures:

- **Binding:**
  - ELISA IgG fold-rise at wk4, H3: 7.60 vs 1.99 (ratio 3.82, 2.65–5.49; n=38 vs 37).
  - ELISA, H1: 5.07 vs 1.90 (ratio 2.67, 1.94–3.68).
  - The advantage is also present in the functional-assay subset (H3 fold-rise 8.79 vs 2.31 in IDs 001–032).
- **HAI at wk4 (GMT ratio, mRNA-1010/Fluarix):**
  - H3N2 0.97 (0.46–2.06); H1N1 1.57 (0.92–2.70); B/Vic 1.09; B/Yam 0.90.
  - Seroconversion: H3N2 14.3% vs 13.3%; B/Vic 0% vs 6.7%.
  - Neither vaccine moved B HAI titres.
- **Neutralisation at D29 (96-virus sequencing-based panel; no single virus significant after FDR correction, 0/96):**
  - 68 contemporary H3N2: adjusted ratio 1.17 (0.64–2.12). The median per-virus ratio is 1.15, and none of the 68 has a 95% lower bound above 1.
  - The 2024–25 and 2025–26 H3 vaccine strains in the panel:
    - A/Thailand/8/2022: 0.82 (0.35–1.91);
    - A/Massachusetts/18/2022: 0.90 (0.46–1.79);
    - A/District of Columbia/27/2023: 1.21 (0.68–2.16).
  - Unadjusted D29 GMT against A/Darwin/6/2021: 244 vs 482 (ratio 0.51, 0.27–0.95).
- **Durability (D121/181 neutralisation):** contemporary H3N2 ratio 0.82 (0.48–1.39). The persistent germinal centres seen with mRNA-1010 did not become better late neutralisation.

**Interpretation.** The most likely reading is that the extra binding antibody from mRNA-1010 is largely non-neutralising, or aimed at epitopes that don't neutralise the virus. It is heavily weighted to conserved or older epitopes: binding to A/Hong Kong/1/1968 rose 10.9× vs 1.15×, and to A/Puerto Rico/8/1934 2.90× vs 1.07×. Non-neutralising antibody may still protect through other mechanisms, but nothing in the package shows that. It is a hypothesis for Studies A–C to test, not evidence for a claim.

### 2.3 The direction of breadth (`analysis/10_backboost.py`)

- **Mixed model** of D29 H3N2 neutralisation (participant as random effect, adjusted for baseline per virus). The mRNA-1010/Fluarix ratio was:
  - 0.72 for the vaccine strain;
  - 1.16 for contemporary drifted H3N2 (interaction p=0.007);
  - 1.80 for historical H3N2 (p<0.001).
- **Within each participant,** the fold-rise against historical H3N2 relative to A/Darwin/6/2021 was 1.67× in the mRNA-1010 arm vs 0.66× in the Fluarix arm (p=0.001).
- **Implication:** the relative gain is backward-looking. This also means a challenge study using an older challenge strain could overstate protection against *future* drift (§3, Study B).

### 2.4 Cellular and monoclonal data: supportive, but not evidence for the claim

- **Germinal centres:** HA-specific germinal-centre B cells were higher with mRNA-1010 (wk2 median 24.2% vs 2.3%, p=0.037; wk26 18.9% vs 1.6%, n=5 vs 8, p=0.34).
- **Repertoire:** mRNA-1010 had more vaccine-elicited clonotypes (median 32 vs 17.5, p=0.066). In both arms, about 87–89% of serum IgG abundance came from pre-existing clonotypes, so both responses were mostly recall.
- **IgM:** rises were *larger* with Fluarix (H3 fold-rise 1.83 vs 5.53, p=0.013).
- **Monoclonal antibodies** (counted per donor; a binder means ≥5× over control):
  - Among H3-binding mAbs, 3–25% from mRNA-1010 donors cross-reacted with H7, vs 0 of 29 from Fluarix donors.
  - Binding to A/Croatia/10136RV/2023 was 64–90% per mRNA-1010 donor, vs 65%, 0% and 20% for the three Fluarix donors (23, 1 and 5 H3 binders respectively).
  - Only binding was measured, with 3 vs 4 donors. It says nothing about neutralisation or protection.

### 2.5 Data-integrity items to resolve before the protocol is finalised (`analysis/00_…`, `15_…`)

- **Visit labels:**
  - In the B/Victoria HAI data, the wk17/wk26 labels are swapped relative to the other three HAI antigens for **8 participants** (007, 008, 009, 010, 016, 018, 021, 023).
  - The sequencing-based neutralisation data label 397-007 and 397-011's late sample as d121, while every other assay says wk26.
- **`gc_frequencies.csv`:** contains **two stacked 78-row blocks with identical keys under one column name**. The second block is probably a different cell population, but it isn't labelled.
- **Timepoints that don't match the stated schedule:**
  - The germinal-centre file has "wk0", but lymph-node sampling started at wk1. It also has no wk1 or wk4 data.
  - The plasmablast file uses wk2 and wk8, which aren't blood-draw days, and includes 13/15 participants where the lymph-node cohort is 6/11.
- **IgM cohort size:** data exist for 14/15 participants, but the summary says 38/37.
- **Missing information:**
  - the strains used for HAI, microneutralisation, ELISA and the bead-array timepoint;
  - demographics, vaccination history and enrolment dates;
  - the mRNA-1010 dose;
  - any safety or reactogenicity data.
- **Minor:** a malformed virus name (`A/SOUTHAFRICA/R07876/202023`) and inconsistent ID formats (`20` vs `020`; integer IDs in the ELISA file).

### 2.6 What WU397 can legitimately support

This is descriptive and non-randomised: "mRNA-1010 induced higher HA-binding IgG, including to drifted and historical strains, and larger, more persistent lymph-node germinal-centre responses than Fluarix. Functional antibody responses (HAI and neutralisation) were broadly similar." It does not support any claim of superior neutralising breadth or of heterologous protection.

## 3. Recommended studies

### Step 0: before the committee (no new participants)

- **Reconcile the data:** fix the visit labels and the stacked germinal-centre block; record strain identities for every assay; add demographics, 5-season vaccination history, enrolment dates and site, and the mRNA-1010 dose.
- **Add readouts on banked WU397 sera:**
  - HAI and neutralisation against **each arm's actual vaccine strains**, including the comparator's H1;
  - **neuraminidase-inhibition (NAI) titres** (N1, N2). mRNA-1010 encodes only HA; the split-virion comparator contains NA.
  - B/Victoria neutralisation (the 96-virus panel had no B strains);
  - HA-stem-directed antibody and Fc-effector function against drifted H3 HAs, to characterise the non-neutralising binding excess.
- **Limits:** this sharpens the hypotheses and the go/no-go thresholds for Study A. It can't fix the non-randomised, antigen-mismatched design.
- **Claim scope:** if the program's real advantage is mRNA's *speed* (choosing strains later, as may explain the newer H1 in WU397), that is a **different claim** ("better match"), not "broader protection". It would need its own design and regulatory discussion of strain selection. Don't conflate the two.

### Study A: randomised, observer-blind, antigen-matched functional-breadth study (Phase 2b; go/no-go)

**Claim it can support:** "mRNA-1010 elicits higher neutralising antibody titres than [comparator] against antigenically drifted strains contained in neither vaccine." This is immunological; it is not a protection claim.

| Element | Specification |
|---|---|
| Design | Randomised within site (stratified by site, age band and prior-season vaccination), observer-blind, active-controlled, parallel. One season, plus a season-2 revaccination extension with identically updated strains. |
| **In whom** | Cohort 1: adults 18–64 (bands 18–49 and 50–64). Cohort 2: adults ≥65. Exclude: current-season vaccination; laboratory-confirmed influenza in the prior 6 months; immunosuppression. Dose before local influenza activity starts. Record birth year (imprinting cohort), 5-season vaccination history, prior confirmed influenza, sex and BMI as pre-specified covariates. |
| **Against what (arms)** | **All arms carry the identical WHO/VRBPAC trivalent composition for the season** (H1N1, H3N2, B/Victoria; no B/Yamagata). Arm 1: mRNA-1010 encoding the cell/recombinant-recommended wild-type HA sequences, at the dose intended for Phase 3 (add a second dose level only if dose isn't settled; no dose data are in the package). Arm 2 (18–64): licensed egg-based standard-dose inactivated vaccine (current Fluarix trivalent). Arm 3: licensed non-egg vaccine with wild-type-sequence HA (recombinant HA or cell-culture); this separates the platform effect from the egg-adaptation effect. In ≥65, the comparator must be a preferentially recommended vaccine (high-dose or adjuvanted inactivated, or recombinant). 1:1(:1) allocation. |
| Size | About **200 evaluable per arm per cohort** (≈230 randomised), ≈1,150–1,400 in total. Basis: the WU397 baseline-adjusted residual SD of log2 panel titre was 1.03 (80% upper bound 1.19), giving 65–87 per arm for a 1.5-fold GMT ratio at 90% power. Single-strain SDs of 1.52–1.76 need 143–191 per arm. At 200 per arm, power is ≥0.95 for the panel primary and 0.86 for the noisiest single strain (α=0.025 per comparator), and the 95% CI on the panel GMT ratio is ×/÷1.18. Formal non-inferiority on HAI seroconversion would need 268–526 per arm at the WU397 seroconversion rates (15–50%), so estimate it here and test it formally in Phase 3. |
| Samples | D0, D29 (primary), D91, D181 (end of season), D365 (before next season); then season-2 dose with D29 sampling after it. D8 optional (exploratory cellular readouts). |
| Intercurrent infection | Respiratory swabs (RT-PCR) triggered by influenza-like illness through D181, plus serology for infection-specific, non-vaccine influenza antigens at D181 and D365. Infected participants are handled by a pre-specified rule in durability analyses (both censored and included). |

**Readouts: what is measured, in whom, against what**

| Role | Readout | Against | In whom / when |
|---|---|---|---|
| **Primary** | Neutralising GMT, summarised per participant as the GMT across the panel | **Locked H3N2 drifted panel** | All randomised; D29; ANCOVA on log2 titre adjusted for D0 panel titre, age band, prior vaccination and site; mRNA-1010 vs each comparator (hierarchical, or α split) |
| Key secondary 1 | HAI GMT and seroconversion (non-inferiority: upper bound of the comparator/mRNA GMT ratio ≤1.5; upper bound of the seroconversion difference ≤10 points) plus neutralising GMT. For H3N2, neutralisation carries the result because HAI is unreliable for recent H3N2 viruses. | The season's vaccine strains (all three) | All; D29 |
| Key secondary 2 | Neutralising GMT against the panel | H1N1 drifted panel; B/Victoria drifted panel | All; D29 |
| Key secondary 3 | Durability: neutralising GMT | All drifted panels | All; D181 and D365 (censoring rule for intercurrent infection) |
| Key secondary 4 | NAI titres | N1 and N2 of the vaccine strains and of drifted strains | All; D0, D29, D181 |
| Secondary | Breadth: share of panel strains with ≥4-fold rise; **pre-specified forward-vs-backward contrast** (drifted/newer vs historical strains), to test the WU397 back-boosting pattern | Drifted panel vs historical set | All; D29 |
| Exploratory | Multi-strain binding breadth (same strains) and the **neutralising:binding ratio**; HA-stem and other conserved-epitope antibody; Fc-effector function; HA-specific T cells; optional lymph-node substudy (randomised, balanced, about 15 per arm; mechanistic only) | Same panels | Subsets |
| Safety | Solicited local and systemic reactions (7 days); unsolicited adverse events (28 days); serious adverse events and adverse events of special interest (to D365) | – | All |

**Panel specification (the "against what" for breadth).** All points apply identically to every arm:

- Lock the panel in the statistical analysis plan before any D29 sample is tested.
- Use **wild-type clinical isolates** (or sequence-identical equivalents).
- Exclude egg- or cell-adapted production reassortants and any strain antigenically equivalent to a vaccine strain from the breadth metrics. WU397 mixed these in: IVR-238, X-223A, NIB-88, X-307A and the "egg" strains. Report them separately as an egg-adaptation readout.
- The **drifted (forward) set** is isolates from the study season and the following season, classed as antigenically distinct from the vaccine strain by a pre-specified criterion. It covers every clade/subclade at ≥5% global prevalence: about 15–25 H3N2, 8–12 H1N1 and 5–8 B/Victoria. Add the next season's recommended strains as a pre-specified secondary set once announced.
- Keep a separate **historical set** (5–8 previous vaccine strains per subtype), used only for the forward/backward contrast.
- Analyse **by subtype**; no pooled all-subtype score. WU397's panel was 83/96 H3N2 with no B strains.
- **Assay specification:**
  - validated assays;
  - testing blinded to arm;
  - all of a participant's samples tested together;
  - a dynamic range wide enough that ≤5% of D29 values are censored;
  - a pre-specified rule for censored values.

**Go/no-go to Study C (pre-specified; assessed in the cohort that will be taken to Phase 3):**

- **GO** requires all of:
  1. H3N2 drifted-panel D29 GMT ratio vs the Phase 3 comparator ≥1.5, with 95% lower bound >1.0, and in the same direction vs the non-egg comparator;
  2. HAI non-inferiority met for all vaccine strains;
  3. D181 drifted-panel ratio ≥1.0;
  4. acceptable reactogenicity.
- The 1.5 threshold is used because FDA's own non-inferiority margin treats differences smaller than 1.5-fold as clinically unimportant.
- **NO-GO / redesign:** if the WU397 pattern recurs (binding advantage without a neutralising advantage, or breadth skewed to historical strains), the next step is antigen or formulation work, not an efficacy trial.

### Study B (optional): controlled human-infection study with a drifted challenge strain (supportive only)

- **In whom:** healthy adults 18–50 with low pre-existing HAI/neutralising titres to the challenge strain and no current-season vaccination.
- **Arms:** mRNA-1010 vs a licensed comparator with the same composition vs placebo; randomised, double-blind.
- **Size:** about 55–120 per arm. That is powered against placebo only, assuming a 30–50% placebo attack rate and a 50–60% reduction (external assumptions; `analysis/19_chim_sizing.py`). Detecting a 20% vs 10% head-to-head difference against the comparator would need about 200 per arm, so treat the comparator contrast as descriptive.
- **Challenge:** 4–8 weeks after dosing, with a GMP challenge strain of the same subtype that is antigenically distinct from the vaccine strain.
- **Endpoints:**
  - Primary: laboratory-confirmed symptomatic infection (RT-PCR-confirmed shedding plus symptoms).
  - Secondary: any laboratory-confirmed infection; viral load over time (area under the curve); symptom score over time.
  - Correlates: pre-challenge neutralising titre to the challenge strain, HAI, NAI, stem-directed antibody and Fc function.
- **Limitation:**
  - Available challenge strains are usually *older* than current vaccine strains, and WU397 suggests mRNA-1010's relative gains are largest against older strains (ratio 1.80 vs 0.72).
  - A positive result could therefore overstate protection against future drift.
  - This study can test the mechanism (does binding-dominated breadth protect?) but cannot carry the label claim.

### Study C: pivotal randomised, observer-blind, active-controlled relative-efficacy trial (the study that can support "heterologous protection")

| Element | Specification |
|---|---|
| Design | 1:1, observer-blind, event-driven, **multi-season** (≥2 Northern Hemisphere seasons, Southern Hemisphere seasons if needed), multinational. Annual revaccination with **identically updated compositions** in both arms. |
| **In whom** | Target age band(s), each powered separately: 18–64 vs standard-dose comparator and/or ≥65 vs a preferentially recommended comparator. Stratify by age, prior vaccination and region. |
| **Against what** | Licensed, age-appropriate comparator with the **same season composition**. |
| Case ascertainment | Active surveillance for protocol-defined influenza-like illness; RT-PCR on respiratory swabs; **every positive sequenced** and antigenically characterised centrally, blinded to arm. |
| Primary endpoint | First RT-PCR-confirmed protocol-defined influenza-like illness from any strain, ≥14 days after dosing to season end. Relative VE tested for non-inferiority (lower bound >−10%), then superiority (lower bound >0%). |
| **Claim-defining key secondary** | RT-PCR-confirmed illness caused by **antigenically mismatched strains**, by a pre-specified algorithm: isolate shows ≥8-fold reduced reactivity to post-infection ferret antiserum raised against the vaccine strain; genetic-clade rule where an isolate can't be characterised; sensitivity analysis using antigenic distance based on human sera. Relative VE must have a lower bound >0%, overall and for H3N2. |
| Supporting analyses | Relative VE as a function of the infecting strain's antigenic distance from the vaccine strain (sieve analysis; a heterologous claim needs relative VE that does not decline, or increases, with distance); medically attended and hospitalised influenza; results by age, prior vaccination and season number. |
| Correlates sub-cohort | Case-cohort design: a random 5–10% sub-cohort with D0, D29 and end-of-season sera, plus all cases. Measure neutralisation against vaccine strains and circulating drifted strains (including each case's own virus or its nearest panel strain), HAI, NAI and binding breadth. Aim: validate Study A's primary readout as a correlate of protection against mismatched strains, so future strain updates can be bridged by immunogenicity. |
| Safety | Full licensure safety database. |
| Size (planning; **assumptions are external, not from WU397**) | 90% power for the mismatched-strain endpoint needs **≈331 mismatched-strain cases if true relative VE is 30%, or ≈845 if 20%** (lower bound >0). At 1.5–3% attack rate per season and 30–60% of cases mismatched, that is **≈22,000–208,000 person-seasons** (`analysis/efficacy_planning_scenarios.csv`). Hence multi-season and event-driven, and the importance of the Study A gate. |

### What not to carry into the protocol

- Don't use WU397's binding-breadth, germinal-centre or mAb data as evidence of heterologous protection. They are hypothesis-generating.
- Don't compare arms with different strain compositions, and don't define "heterologous" relative to one arm only.
- Don't rank arms by fold-rise without baseline adjustment, and don't pool wk17 with wk26.
- Don't compare arms using pooled mAb counts; the donor is the unit.
- Don't retain B/Yamagata.

## 4. Numbers relied on, and where each came from

All source files are in `/tmp/world/filesystem/`. Derived values are in `/tmp/outputs/analysis/` (script → output). A machine-readable list is in `/tmp/outputs/key_numbers.csv`. Ratios are mRNA-1010/Fluarix with 95% CI.

| Number | Value | Source file → script / output |
|---|---|---|
| Cohort sizes (ELISA 38/37; HAI and bead/microneutralisation 14/15; sequencing-based neutralisation 13/14; lymph-node FNA 6/11) | as stated | `trial_summary.md`; confirmed by `00_integrity_checks.py` → `participant_file_presence.csv` |
| mRNA-1010 H1 antigen = A/Victoria/4897/2022; comparator "as licensed 2022–23, not set for this study"; designations relative to mRNA-1010 | text | `trial_summary.md` |
| ELISA wk4 fold-rise, H3: 7.60 (5.57–10.38) vs 1.99 (1.63–2.43); ratio 3.82 (2.65–5.49) | | `elisa_igg_titers.csv` → `02_elisa.py` → `elisa_summary.csv`, `elisa_arm_comparisons.csv` |
| ELISA wk4 fold-rise, H1: 5.07 vs 1.90; ratio 2.67 (1.94–3.68). B/Vic ratio 1.38 (1.01–1.88). wk17/26 ratios: H1 1.51, H3 2.29 | | same |
| ELISA H3 fold-rise by ID block: 8.79 vs 2.31 (IDs 001–032); 6.98 vs 1.80 (IDs ≥033) | | same (block printout) |
| Bead binding fold-rise, A/Darwin/6/2021: 26.18 vs 4.29 (ratio 6.10, 2.20–16.91) | | `binding_breadth_h3.csv` → `04_bead_breadth.py` → `bead_breadth_by_strain.csv` |
| Bead binding: A/Thailand/8/2022 31.87 vs 3.37 (9.45, 3.19–28.01); A/Hong Kong/1/1968 10.94 vs 1.15 (9.51, 5.49–16.48); A/Puerto Rico/8/1934 2.90 vs 1.07 (2.70); A/Wisconsin/67/2022 4.07 vs 1.54 (2.65); A/Wisconsin/588/2019 3.96 vs 1.94 (2.04) | | `binding_breadth_h1/h3.csv` → same |
| HAI wk4 GMT ratio: H1N1 1.57 (0.92–2.70), baseline-adjusted 1.54 (0.87–2.71); H3N2 0.97 (0.46–2.06), adjusted 1.06; B/Vic 1.09; B/Yam 0.90 | | `hai_titers.csv` → `01_hai.py` → `hai_arm_comparisons.csv`, `hai_ancova_wk4.csv` |
| HAI seroconversion: H1N1 7/14 (50.0%) vs 5/15 (33.3%); H3N2 2/14 (14.3%) vs 2/15 (13.3%); B/Vic 0/13 vs 1/15 (6.7%); B/Yam 0/14 vs 1/15. B/Vic fold-rise 1.08 vs 1.05 | | → `hai_summary.csv` |
| Microneutralisation heterologous GMT: wk0 57.0 vs 121.3 (0.47, p=0.050); wk4 234.9 vs 367.6 (0.64); wk17/26 126.0 vs 320.0 (0.39, 0.16–0.97); fold-rise 4.12 vs 3.03 | | `microneutralization.csv` → `03_mn.py` → `mn_summary.csv`, `mn_arm_comparisons.csv` |
| Microneutralisation homologous wk4 GMT 325.4 vs 588.1 (0.55, 0.22–1.40); at 1:1280 ceiling at wk4: 9/15 Fluarix vs 4/14 mRNA-1010 | | same |
| Neutralisation, 68 contemporary H3N2: D0 143 vs 215 (0.66); D29 402 vs 467 (0.86, 0.44–1.68); adjusted 1.17 (0.64–2.12), p=0.60; late 0.82 (0.48–1.39) | | `neutralization_seqbased.csv` → `05_seqneut.py`, `06_seqneut_participant.py` → `seqneut_participant_level_summary.csv` |
| Neutralisation, A/Darwin/6/2021: D29 244 vs 482 (0.51, 0.27–0.95); adjusted 0.62 (0.34–1.12); fold-rise 2.24 vs 2.74 | | same |
| Neutralisation, A/Thailand/8/2022 adjusted 0.82 (0.35–1.91); A/Massachusetts/18/2022 0.90 (0.46–1.79); A/District of Columbia/27/2023 1.21 (0.68–2.16) | | → `14_seqneut_per_virus_ancova.py` → `seqneut_per_virus_ancova.csv` |
| Neutralisation, 6 contemporary H1N1: D29 478 vs 257; adjusted 2.06 (1.23–3.46); late 1.06 (0.46–2.46). A/Wisconsin/588/2019 adjusted 2.44 (1.18–5.05); A/Wisconsin/67/2022 adjusted 2.07 (1.26–3.38) | | `06_…` |
| Per-virus: 0/96 with FDR q<0.05; contemporary H3N2 median adjusted ratio 1.15 with 0/68 lower bounds >1; contemporary H1N1 median 2.01 with 6/6 nominal | | `14_…` |
| Panel composition: 96 viruses (83 H3N2, 13 H1N1, 0 B); 6 reassortant/egg strains; 171 values below and 70 above the assay limits (of 7,719) | | `05_seqneut.py` → `seqneut_virus_classification.csv` |
| Mixed-model adjusted ratios: vaccine strain 0.72, contemporary 1.16 (p=0.007), historical 1.80 (p<0.001); within-person skew 1.67× vs 0.66× (p=0.001) | | `10_backboost.py` |
| Same-participant binding vs function table (§2.2) | | `11_binding_vs_function.py` → `binding_vs_function_same_participants.csv` |
| Germinal-centre B cells (block 1): wk2 24.2% vs 2.3% (p=0.037); wk26 18.9% vs 1.6% (p=0.34) | | `gc_frequencies.csv` → `08_cellular_repertoire.py` |
| Vaccine-elicited clonotypes 32 vs 17.5 (p=0.066); pre-existing share of serum IgG 87.0% vs 88.7% | | `repertoire_clonotype_counts.csv` → `08_…` |
| IgM H3 fold-rise 1.83 vs 5.53 (p=0.013) | | `igm_fold_change.csv` → `13_igm.py` |
| mAbs: 695 unique; Fluarix 106 (397-05 = 84, 79%), mRNA-1010 589; H7 cross-reactivity 40/333 vs 0/29; A/Croatia/10136RV/2023 binding by donor as in §2.4 | | `mab_binding_panels.csv` → `07_mab.py` → `mab_donor_level_breadth.csv` |
| Data-integrity counts (8 B/Vic label swaps; 2 sequencing-neutralisation label mismatches; 2×78 germinal-centre blocks) | | `00_integrity_checks.py`, `15_visit_label_crosscheck.py` → `visit_label_inconsistencies.csv` |
| Power: residual SD 1.03 (80% upper bound 1.19) → 65–87 per arm; single strain 143–191; HAI seroconversion non-inferiority 268–526; power at 200 per arm and CI ×/÷1.18 | | `09_power.py` → `power_planning.csv`; `18_power_check.py` |
| Efficacy events and size: 331/845 events; 22k–208k person-seasons | external assumptions | `12_efficacy_planning.py` → `efficacy_planning_scenarios.csv` |
| Challenge-study size: 55–120 per arm vs placebo; about 200 per arm head-to-head (20% vs 10%) | external assumptions | `19_chim_sizing.py` |

## 5. External reference points (not in the package; please confirm against current documents)

- **WHO 2022–23 Northern Hemisphere recommendations:**
  - egg-based: A/Victoria/2570/2019 (H1N1)pdm09-like, A/Darwin/9/2021 (H3N2)-like;
  - cell/recombinant: A/Wisconsin/588/2019-like, A/Darwin/6/2021-like;
  - B for both: B/Austria/1359417/2021-like and B/Phuket/3073/2013-like.
  - **Check the actual Fluarix lot label.**
- **H1 change:** A/Victoria/4897/2022-like (egg) and A/Wisconsin/67/2022-like (cell) became the H1 recommendation from 2023–24.
- **Later H3N2 vaccine strains in the panels:** A/Thailand/8/2022 and A/Massachusetts/18/2022 (2024–25); A/Croatia/10136RV/2023 and A/District of Columbia/27/2023 (2025–26).
- **B/Yamagata:** no confirmed detections since March 2020. WHO advised removing it, and US vaccines became trivalent from 2024–25.
- **FDA/CBER 2007 guidance, immunogenicity criteria for accelerated approval:**
  - comparative: upper bound of the comparator/new-vaccine GMT ratio ≤1.5; upper bound of the seroconversion difference ≤10 percentage points;
  - single-arm: seroconversion lower bound ≥40% (<65 years) / ≥30% (≥65); lower bound for HAI ≥1:40 of ≥70% / ≥60%.
- **ACIP:** preferentially recommends high-dose, recombinant or adjuvanted vaccine for people ≥65.
- **WHO antigenic-characterisation convention:** a ≥8-fold reduction in titre against post-infection ferret antiserum indicates antigenic difference.
- **Planning assumptions (not data):** attack rate 1.5–3% per season; 30–60% of cases mismatched; true relative VE 20–30%; challenge-study placebo attack rate 30–50%.

## 6. Files

- **Analysis scripts and outputs:** `/tmp/outputs/analysis/`, scripts `00`–`19`, all run with `mm core python <script>`.
- **Figures:**
  - `figures/fig1_binding_vs_function.png`: binding vs functional ratios;
  - `figures/fig2_seqneut_per_virus_adjusted_ratio.png`: per-virus adjusted neutralisation ratios by strain category.
- **Key numbers:** `key_numbers.csv`.

## 7. Limitations of this analysis

- WU397 is small and non-randomised, so every between-arm estimate above is confounded to an unknown degree. Treat the estimates as descriptive, including the "negative" H3N2 ones; the CIs allow up to about 2× in either direction.
- Baseline-adjusted (ANCOVA) estimates reduce, but don't remove, regression-to-the-mean and site effects.
- I assigned strain categories (vaccine-matched, contemporary, historical, reassortant) from virus names and WHO designations; they should be checked against the program's antigenic data.
- Censored neutralisation titres were kept at their bound. That is conservative, and the censoring rate is low (241 of 7,719 values).
- The germinal-centre "block 1" was assumed to be germinal-centre B cells, because the second block is unlabelled.
