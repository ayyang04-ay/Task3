**Recommendation:** WU397 doesn't support a heterologous-protection claim; next, run a randomised, observer-blind, composition-matched trial (mRNA vs same-season egg-based and non-egg licensed vaccines) with baseline-adjusted neutralisation of a locked wild-type drifted-strain panel as the primary endpoint, and proceed to a heterologous-challenge study and an event-driven, strain-typed relative-efficacy trial only if H3 breadth meets pre-set criteria.

---

## 1. The reasoning in brief

1. **The claim is about protection, and WU397 measured none.** There were no infection or illness endpoints. There is also no accepted immune correlate for protection against heterologous strains. The best immunogenicity can do is make the claim plausible; only clinical-endpoint data can establish it.
2. **WU397 cannot separate the platform from other differences between the arms.**
   - Allocation was by site, not randomised, and the study was open-label.
   - The arms received different H1 antigens:
     - mRNA-1010: A/Victoria/4897/2022.
     - 2022–23 Northern Hemisphere Fluarix: A/Victoria/2570/2019, a different clade and the same H1 as the 2021–22 vaccine.
   - The H3 antigens came from different lineages: cell-derived A/Darwin/6/2021 (mRNA-1010) vs egg-derived A/Darwin/9/2021 (Fluarix).
   - The summary itself says "homologous/heterologous" refers only to the mRNA-1010 antigens.
3. **The pattern is more binding antibody, not more neutralisation where the antigens match.**
   - mRNA-1010 raised much more binding IgG (adjusted GMR 2.7 for H1, 3.3 for H3) and broader binding in the bead-array and mAb data.
   - HAI was the same for all four antigens.
   - Neutralisation was better only for **H1, the antigen that differed between arms.**
   - For **H3, where the antigens were nearly matched and drift matters most**, there was no heterologous advantage: adjusted GMR 1.17 (95% CI 0.64–2.12) across 68 wild-type 2022–24 isolates.
   - Day-29 titres against the mRNA vaccine's *own* H3 strain were half of Fluarix's (GMR 0.51, 0.27–0.95).
4. **The H1 signal is about magnitude rather than breadth, and it does not last the season.**
   - A similar advantage (1.7–2.4×) appears against 2009–2019 H1 strains, against Fluarix's own lineage, and against 2023 drift strains.
   - It is gone by day 121/181 (1.17, 0.77–1.77).
   - It fits an "updated / novel H1 antigen" effect as well as a platform effect. Only a trial with matched composition can tell them apart.
5. **The apparent "heterologous" fold-rise advantage in microneutralisation (MN) comes from unequal baselines.** The mRNA arm started at half the titre (57 vs 121), ended lower (235 vs 368), and the adjusted GMR is 1.17 (0.52–2.62).
6. **Recall of existing immunity (imprinting) dominates both arms, and baseline immunity is biased toward egg-adapted virus.** Any breadth effect will depend on the population's vaccination history, so the next trial must stratify on it. Its reference viruses must be wild-type.

Figures: `forest_arm_contrasts.png` (every readout on one scale) and `seqneut_per_virus_contrasts.png` (all 96 viruses).

---

## 2. What the data package shows

All contrasts are mRNA-1010 / Fluarix. "Adjusted" means an ANCOVA of log₂ post-vaccination titre on arm plus log₂ baseline titre. p-values are not corrected for multiple comparisons and are descriptive only, because the study was not randomised. Sources are in §5.

### 2.1 Key contrasts

| Readout (n mRNA/Fluarix) | Day 29 (adjusted GMR, 95% CI) | Week 17/26 | Comment |
|---|---|---|---|
| HAI A/H1N1 (14/15) | 1.54 (0.87–2.71) | 0.83 (0.47–1.46) | SCR 7/14 vs 5/15 |
| HAI A/H3N2 (14/15) | 1.06 (0.67–1.65) | 0.92 (0.60–1.41) | GMFR 1.7 in both arms; SCR 2/14 vs 2/15 |
| HAI B/Vic (13/15), B/Yam (14/15) | 1.05 (0.71–1.56), 1.01 (0.73–1.40) | 1.06, 0.91 | Neither arm really responded (GMFR 1.0–1.3) |
| MN "homologous" panel (14/15) | 0.68 (0.31–1.51) | – | d29 GMT 325 vs 588; 9/15 Fluarix vs 4/14 mRNA hit the 1:1280 ceiling |
| MN "heterologous" panel (14/15) | 1.17 (0.52–2.62) | – | GMFR 4.1 vs 3.0 looks favourable, but baseline GMR was 0.47 (p=0.05) |
| Seq-neut, 6 wild-type 2023 H1N1 (13/14) | **2.06 (1.23–3.46)** | 1.17 (0.77–1.77) | ≥4× rise on 53% vs 13% of strains |
| Seq-neut, A/Wisconsin/588/2019 (Fluarix H1 lineage) | 2.44 (1.18–5.05) | – | Advantage equally large on the comparator's own lineage |
| Seq-neut, 4 historical H1 (2009–19) | 1.69 (0.91–3.13) | – | So H1 shows magnitude, not breadth |
| Seq-neut, A/Darwin/6/2021 (mRNA's own H3) | 0.62 (0.34–1.12); unadjusted **0.51 (0.27–0.95)** | 0.72 | GMT 244 vs 482 |
| Seq-neut, 68 wild-type 2022–24 H3N2 | **1.17 (0.64–2.12)**; unadjusted 0.86 | 1.05 (0.65–1.68) | Baseline GMR 0.66; ≥4× rise on 28% vs 24% of strains |
| ELISA IgG H1 / H3 (38/37) | **2.66 (2.01–3.53) / 3.31 (2.47–4.43)** | GMFR ratio 1.51 / 2.29 | mRNA keeps 42–46% of its d29 level vs 74–76% for Fluarix |
| ELISA IgG B/Vic / B/Yam | 1.35 / 1.38 | 1.00 / 1.03 | Small, and gone by week 17/26 |

### 2.2 Binding breadth does not translate into neutralising breadth

- **Bead array:** mRNA gave much larger binding rises to old and non-circulating HAs:
  - A/Hong Kong/1/1968 H3: mean log₂ fold-change 3.45 vs 0.20.
  - A/Puerto Rico/8/1934 H1: 1.54 vs 0.10.
  - The per-participant mean across H3 strains was 3.39 vs 0.87.
- **mAbs:** more mRNA-arm mAbs bound A/Hong Kong/1/1968 (48% vs 5%), A/Croatia/10136RV/2023 (72% vs 25%) and H7 (11% vs 0%).
  - H5 binding was rare in both arms (3% vs 2%).
  - The Fluarix mAb set is effectively one person: 84 of its 106 mAbs (79%) come from donor 397-05, whose IgM rose 166–212× against every antigen.
- **Same participants, binding vs neutralisation.** For H3, the ELISA fold-rise was **3.6×** the neutralisation fold-rise against A/Darwin/6/2021 in the mRNA arm, vs 0.8× in the Fluarix arm (p=6×10⁻⁵). For H1 the two arms were similar (1.4 vs 1.2).
  - So the extra H3 antibody from mRNA is mostly non-neutralising.
  - Whether it protects (for example through Fc-mediated functions) is untested.

### 2.3 Evidence that recall and imprinting dominate

- In the mRNA arm, neutralisation rose more against older or other-lineage strains than against the strains it encodes:
  - A/Wisconsin/588/2019: 6.2× vs A/Wisconsin/67/2022: 3.5×.
  - A/Darwin/9/2021: 4.8× vs A/Darwin/6/2021: 2.2×.
- 78% of mRNA-arm group-1 mAbs bound A/Wisconsin/588/2019 more strongly than the immunogen A/Victoria/4897/2022 (median about 4×).
- **Germinal centres (GC):** mRNA responses were larger and lasted longer (HA⁺ GC B cells at week 2: median 24% vs 2.3%, p=0.04, n=6/11). But 73–92% of GC clones in the four mRNA donors were already present among week-1 plasmablasts, i.e. recalled memory.
- Pre-existing clonotypes accounted for a median 87% vs 89% of serum IgG clonotype abundance (n=8 per arm; the file does not state the timepoint or participant IDs).
- **Egg-adaptation bias in baseline immunity:**
  - Before vaccination, sera neutralised egg-reassortant H3s 1.4–10.9× better than the matching wild-type virus.
  - They neutralised the only form of the mRNA H1 immunogen in the panel (IVR-238, an egg reassortant) about 5× better than its WHO cell-based counterpart, A/Wisconsin/67/2022.
  - mRNA reduced this bias for two historical pairs (2.1–2.2× more than Fluarix, p≈0.02–0.03), but the mRNA arm also started with more of it.

### 2.4 Why the H1 signal is not evidence for the claim

- **It is confounded by composition.**
  - mRNA gave a *new* H1 clade.
  - Fluarix gave the same H1 as the previous season, and repeating an antigen is expected to blunt responses.
  - For H3, both arms received a new antigen of the same antigenic type, and there was no difference.
- **It is uniform across old and new strains**, so it reflects a bigger response, not broader coverage.
- **It had waned by 4–6 months**, whereas protection through a season is the point of the claim.

### 2.5 Power

- WU397's functional subsets had 32–37% power to detect a 1.5× GMR and 72–79% for 2×.
- The H3 null result is therefore inconclusive in both directions: the CI runs from 0.64 to 2.12.
- The residual SDs from WU397 (0.94–1.03 log₂ on the contemporary panels) are used to size Study 1.

---

## 3. Recommended next studies, in order and gated

```
Study 0 (now, banked WU397 sera + records)  ─┐
                                             ├─► Study 1: randomised, composition-matched Phase 2  ──GO?──► Study 2: heterologous challenge (proof of protection)
                                             │                                                         └──► Study 3: event-driven rVE trial (registrational basis + correlates)
```

### Study 0 – Fix and re-test the WU397 package (no new enrolment, weeks)

**Purpose:** resolve the confounders that are cheap to resolve, and sharpen the hypothesis that Study 1 will test.

**In whom:** all WU397 participants with banked d0, d29 and d181 sera (13–15 per arm for functional assays; 37–38 per arm for binding).

**Against what** (each arm's own antigens, treated symmetrically):
- Fluarix's 2022–23 H1 (A/Victoria/2570/2019) and H3 (A/Darwin/9/2021).
- mRNA-1010's H1 (A/Victoria/4897/2022) and H3 (A/Darwin/6/2021).
- Each in **wild-type** form, with egg forms reported separately.

**Readouts:**
- Neutralising titre and HAI against the strains above.
- NAI titre against N1 and N2. Split-virion Fluarix carries some NA. The package describes mRNA-1010 only as encoding "four antigens"; if these are HA-only, it induces no anti-NA, which matters for protection against drifted strains.
- Infection-specific serology (a marker neither vaccine induces, e.g. anti-NS1) to flag infections during follow-up.

**Records to retrieve:**
- Age, sex and birth year.
- Site and enrolment date.
- Influenza vaccination history for ≥5 seasons, including product type.
- The Fluarix lot composition.
- The strain identities used in the HAI, MN and ELISA readouts.
- Resolution of the issues in `data_issues_register.md`: the two unlabelled GC blocks, plasmablast provenance, IgM values floored at 1, and mislabelled visits.

**Analysis:**
- Baseline-adjusted contrasts, stratified by whether the participant was vaccinated in 2021–22.
- Pre-specified question: does the H1 advantage persist against Fluarix's own wild-type H1 *and* among people not vaccinated in 2021–22?
- This does not replace Study 1. It decides whether H1 stays in Study 1's hierarchy as a confirmatory or an exploratory hypothesis.

### Study 1 – Randomised, observer-blind, composition-matched Phase 2 (the protocol for the committee)

**Conditions**

| Element | Specification |
|---|---|
| Design | Randomised 1:1:1, observer-blind, active-controlled, multicentre. Randomise within site, and enrol all arms at the same time before the season starts. The laboratory is blinded to arm. |
| Composition | One upcoming season. **All arms contain that season's WHO-recommended strains.** Trivalent: A/H1N1pdm09, A/H3N2, B/Victoria. B/Yamagata is dropped; the WU397 quadrivalent with B/Phuket/3073/2013 is no longer recommended. |
| Arm A | mRNA vaccine encoding the WHO cell/recombinant-recommended (wild-type-sequence) HAs, at the intended commercial dose. The dose used in WU397 is not stated in the package and needs confirming. |
| Arm B | Licensed egg-based standard-dose inactivated vaccine, same season (Fluarix). This is standard of care and carries egg-adapted HA. |
| Arm C | Licensed **non-egg** vaccine with wild-type-sequence HA, same season (recombinant HA or cell-culture). This separates the platform effect from egg adaptation. |
| ≥65 cohort | Arm B becomes the age-preferred comparator (high-dose or adjuvanted). Keep recombinant as arm C. Standard-dose Fluarix is not an acceptable sole comparator at this age. |
| Population | Two separately randomised cohorts: 18–64 and ≥65. The WU397 age range is unknown, so state the intended label population. |
| Stratification | Prior-season vaccination (yes/no) and number of vaccinations in the past 5 seasons (0 / 1–2 / ≥3). Record birth year as a marker of imprinting cohort. |
| Exclusions | Influenza vaccination within 6 months; laboratory-confirmed influenza in the current season before enrolment; immunosuppression. |
| Visits | d0, d29, d181 (end of season), d365. |

**Readouts** (what is measured, in whom, against what)

| Tier | Readout | In whom | Against what | When | Endpoint |
|---|---|---|---|---|---|
| **Primary** | Neutralising antibody titre | Immunogenicity set: a random subset chosen at enrolment, ≥150 evaluable per arm per cohort. Not selected by sample availability, as WU397 was. | **Locked wild-type H3N2 heterologous panel**; H1N1 and B/Vic panels follow in a fixed testing hierarchy | d0, d29 | Baseline-adjusted GMR: A vs C first, then A vs B |
| Key secondary | Same | Same | Same panels | d181 | Baseline-adjusted GMR (durability through the season) |
| Key secondary | HAI | All participants | Each vaccine strain, in both wild-type and egg-derived reference forms | d0, d29 | GMT ratio and SCR difference against non-inferiority margins: comparator/mRNA GMT-ratio upper bound ≤1.5; comparator-minus-mRNA SCR upper bound ≤10 percentage points |
| Secondary | Breadth metrics | Immunogenicity set | Heterologous panel vs homologous reference | d29, d181 | Heterologous/homologous titre ratio (separates breadth from magnitude); % of strains with ≥4× rise; % of participants reaching a pre-set titre against ≥50% of strains |
| Secondary | NAI titre | Immunogenicity set | N1 and N2 of vaccine and panel strains | d0, d29, d181 | GMR. A deficit here could offset any HA breadth. |
| Secondary | Infection during the season | All participants | RT-PCR-confirmed influenza-like illness (active surveillance) plus infection-specific serology | Whole season | Censor infected participants from durability analyses; descriptive relative efficacy |
| Exploratory | Stem/cross-group binding; Fc-effector function | Random subset of about 50 per arm | Group 1 and group 2 HAs, including H5 and H7 | d0, d29 | Tests whether the binding breadth seen in WU397 has any functional counterpart |
| Safety | Reactogenicity and adverse events | All participants | – | 7 days / 28 days / 6–12 months | Standard |

Deliberately left out of the confirmatory endpoints: fold-rise as the comparative measure, binding assays, lymph-node fine-needle aspiration, and egg reassortants used as "homologous" reference viruses.

**Defining the heterologous panel ("against what")**

- The panel is locked before unblinding by a committee independent of the study team, using WHO Collaborating Centre and GISAID surveillance data.
- Only wild-type viruses (cell-propagated or sequence-built). Egg-adapted viruses are reported separately and never pooled.
- Three tiers:
  1. **Contemporary:** antigenically distinct strains circulating in the trial season (e.g. ≥8-fold loss of reactivity to ferret antiserum against the vaccine strain, or a distinct subclade), weighted by prevalence.
  2. **Forward drift:** strains that emerge within 12 months of vaccination, chosen by a rule fixed in advance (e.g. each subclade reaching ≥5% of global sequences) and tested on banked d29 and d181 sera. In WU397 these would be the 2023–24 H3 isolates; the lowest-titre ones were A/BritishColumbia/RV00920/2023, A/DistrictOfColumbia/27/2023, A/Lisboa/124/2024 and A/Shaanxi-Yuyang/1204/2024.
  3. **Historical (short list):** to tell back-boosting apart from forward breadth.
- Include B/Victoria drift strains. WU397 had no B neutralisation panel.

**Size**

| Target | Evaluable n per arm |
|---|---|
| GMR 1.5; two comparisons at α=0.025 two-sided each; 90% power; residual SD 1.0–1.3 log₂ (WU397 observed 0.94–1.03 on contemporary panels, up to 1.48 on single strains) | 73–123 |
| Same design, GMR 1.25 | 240–405 |

- **Recommended:** 150 evaluable per arm per cohort, about 170 randomised per arm, so about 510 per cohort.
- That gives 79–95% power to detect a 1.5× GMR within a 50% prior-vaccination subgroup.
- A formal HAI non-inferiority test on SCR (10-point margin) would need 268–526 per arm (at SCR 15–50%). So either keep HAI descriptive here and test it formally in Study 3, or increase the sample size if the committee wants that test in Phase 2.

**Decision rules (fix these before unblinding)**

- **GO** to Studies 2 and 3 *with* a heterologous claim only if all of the following hold:
  - H3 panel adjusted GMR vs arm C is ≥1.5 with lower bound >1.0 at d29, **and** lower bound >1.0 at d181.
  - Lower bound >1.0 vs arm B.
  - HAI to the vaccine strains is non-inferior to both comparators.
  - NAI is not more than 1.5× lower (or the programme commits to adding NA to the vaccine).
- **H1 only:** the claim is limited to one subtype; revisit the antigen design before spending on efficacy.
- **NO-GO:** drop the heterologous claim. The platform can still pursue a standard seasonal (non-inferiority) indication. It can also test, as a *separate* hypothesis, whether mRNA's later strain selection gives a better match, which is the interpretation the WU397 H1 data fit best. That would need its own design and must not be mixed into Study 1.

### Study 2 – Heterologous-challenge study (only if Study 1 is GO)

| | |
|---|---|
| Conditions | Randomised, double-blind, three arms: mRNA, licensed non-egg comparator, placebo. Vaccinate with the current season's composition. Challenge about 4–6 weeks later with a GMP challenge strain of the same subtype (H3N2 preferred) whose antigenic distance from the vaccine strain is documented and pre-specified. Optional second cohort challenged at about 6 months to test durability. |
| In whom | Healthy adults 18–50 with low pre-existing HAI and neutralising titres against the challenge strain. Stratify by prior vaccination. |
| Readouts | **Primary:** RT-PCR-confirmed symptomatic influenza (mild-to-moderate disease). **Secondary:** any laboratory-confirmed infection (shedding and/or seroconversion); nasal viral-load AUC; symptom-score AUC; duration of shedding. **Immunology:** HAI, neutralisation and NAI against the challenge strain before challenge, as an early estimate of what predicts heterologous protection. |
| Size (illustrative) | 49 per arm for 40%→15% vs placebo; about 80 per arm for 30%→12% head-to-head (80% power, α=0.05). |
| Limitation | Challenge studies select young, low-titre adults, the opposite of the repeatedly vaccinated, imprinted population where WU397 responses were dominated by recall. This is proof of concept, not a substitute for Study 3. |

### Study 3 – Event-driven relative-efficacy (rVE) trial (the registrational basis for the claim)

| | |
|---|---|
| Conditions | Randomised 1:1, observer-blind, against the licensed age-appropriate vaccine for the same season. At least 2 seasons and both hemispheres, because whether a mismatched season occurs can't be controlled. |
| In whom | The intended label population (e.g. ≥50 or ≥65, and 18–64 if sought). |
| Primary | rVE against RT-PCR-confirmed, protocol-defined influenza-like illness from any strain, from ≥14 days after vaccination to the end of the season. Test non-inferiority (lower bound > −10%, margin to be agreed with regulators), then superiority. |
| Key secondary (the claim) | rVE against cases caused by strains **antigenically different from the vaccine strains**. Every case specimen is sequenced and antigenically characterised by a blinded central laboratory, using a classification algorithm locked before unblinding. Multiplicity is controlled. |
| Other | rVE by subtype or lineage; hospitalisation or pneumonia; rVE against matched strains, for contrast. |
| Correlates | A case-cohort immunogenicity subset (random subcohort plus all cases). Measure pre-season HAI and neutralisation against the vaccine strains *and the infecting strain*, plus NAI. This builds the correlate needed to support the claim with immunogenicity data in later seasons. |
| Size (illustrative) | Superiority needs 511 cases at a true rVE of 25%, or 847 at 20% (90% power). The heterologous endpoint needs a similar number of *mismatched-strain* cases. At a 1–2% seasonal attack rate, that is about 29,000–57,000 participant-seasons per 500 cases. |

---

## 4. Limits of this analysis

- The functional cohorts are small: 13–15 per arm (6 vs 11 for lymph-node sampling).
- There are many contrasts and no correction for multiple comparisons.
- No covariates are available, so unmeasured confounding cannot be addressed.
- The strains used for HAI, MN and ELISA are not named.
- Late timepoints mix day 121 and day 181.
- GC results use block 1 of a file that contains two unlabelled blocks.
- Handling of censored values in seq-neut was tested three ways; conclusions unchanged (H1 1.95–2.31; H3 1.16–1.18).
- Excluding the implausible MN participant 397-014 does not change the MN conclusions (heterologous 1.22, homologous 0.77).

**Facts taken from outside the package** (verify against the lot label and current guidance):
- WHO 2022–23 NH egg-based composition: A/Victoria/2570/2019 H1 (unchanged from 2021–22) and A/Darwin/9/2021 H3.
- A/Victoria/4897/2022 was first recommended for 2023–24.
- WHO no longer recommends a B/Yamagata component, and trivalent vaccines are recommended from 2024–25.
- US ACIP prefers high-dose, adjuvanted or recombinant vaccines for people ≥65.
- FDA seasonal-vaccine non-inferiority margins: comparator/new GMT ratio upper bound ≤1.5; comparator-minus-new SCR difference upper bound ≤10 percentage points.

---

## 5. Numbers relied on and where each came from

Input files are in `/tmp/world/filesystem/`; scripts and intermediate tables are in `/tmp/outputs/analysis/`. The same ledger is available as a CSV (`numbers_ledger.csv`).

| Quantity | Value (mRNA-1010 vs Fluarix) | Source file | Computed by |
|---|---|---|---|
| HAI A/H1N1 GMT d0→d29 (n 14/15) | 50.0→138.0 vs 39.0→87.7 | hai_titers.csv | 01_hai.py → hai_summary.csv |
| HAI A/H1N1 GMFR; SCR (≥4× and ≥1:40) | 2.76 vs 2.25; 7/14 vs 5/15 | hai_titers.csv | 01_hai.py |
| HAI A/H1N1 adjusted GMR d29; wk17/26 | 1.54 (0.87–2.71) p=0.13; 0.83 (0.47–1.46) | hai_titers.csv | 01_hai.py; 20_hai_late.py |
| HAI A/H3N2 GMT d0→d29; GMFR; SCR | 32.8→56.4 vs 34.8→57.9; 1.72 vs 1.66; 2/14 vs 2/15 | hai_titers.csv | 01_hai.py |
| HAI A/H3N2 adjusted GMR d29; wk17/26 | 1.06 (0.67–1.65); 0.92 (0.60–1.41) | hai_titers.csv | 01_hai.py; 20_hai_late.py |
| HAI B/Vic (13/15) GMT; GMFR; SCR; adjusted GMR | 52.2→56.5 vs 49.3→51.6; 1.08 vs 1.05; 0/13 vs 1/15; 1.05 (0.71–1.56) | hai_titers.csv | 01_hai.py |
| HAI B/Yam GMT; GMFR; SCR; adjusted GMR | 65.5→88.3 vs 76.4→98.6; 1.35 vs 1.29; 0/14 vs 1/15; 1.01 (0.73–1.40) | hai_titers.csv | 01_hai.py |
| MN heterologous GMT d0→d29; GMFR | 57→235 vs 121→368; 4.12 vs 3.03 | microneutralization.csv | 02_mn.py → mn_summary.csv |
| MN heterologous baseline GMR; adjusted GMR; excluding 397-014 | 0.47 (0.22–1.00) p=0.05; 1.17 (0.52–2.62); 1.22 (0.57–2.62) | microneutralization.csv | 02_mn.py; 17_mn_sensitivity.py |
| MN homologous GMT d0→d29; GMFR; adjusted GMR; excluding 397-014 | 131→325 vs 177→588; 2.49 vs 3.32; 0.68 (0.31–1.51); 0.77 (0.37–1.60) | microneutralization.csv | 02_mn.py; 17_mn_sensitivity.py |
| MN at 1:1280 ceiling, d29, homologous / heterologous | 4/14 vs 9/15 / 1/14 vs 3/15 | microneutralization.csv | 02_mn.py |
| MN participant 397-014: MN titre vs HAI H1N1 and ELISA H1 | MN 10–15 at all visits; HAI 57→320; ELISA 908→32,602 | microneutralization.csv, hai_titers.csv, elisa_igg_titers.csv | 16_blocks_outliers.py |
| ELISA IgG H1 GMFR; % retained at wk17/26 (n 38/37) | 5.07 vs 1.90; 42% vs 74% | elisa_igg_titers.csv | 03_elisa.py → elisa_summary.csv |
| ELISA IgG H1 adjusted GMR d29; wk17/26 GMFR ratio | 2.66 (2.01–3.53); 1.51 (1.14–2.00) | elisa_igg_titers.csv | 03_elisa.py |
| ELISA IgG H3 GMFR; retained; adjusted GMR; late ratio | 7.60 vs 1.99; 46% vs 76%; 3.31 (2.47–4.43); 2.29 (1.67–3.14) | elisa_igg_titers.csv | 03_elisa.py |
| ELISA IgG B/Vic, B/Yam adjusted GMR; late ratio | 1.35 (1.04–1.75), 1.38 (1.11–1.71); 1.00, 1.03 | elisa_igg_titers.csv | 03_elisa.py |
| Fluarix B/Vic, B/Yam baseline by ID block (1–32 vs 33–59) | 1794 vs 877 (p=0.006); 2247 vs 1139 (p=0.037) | elisa_igg_titers.csv | 16_blocks_outliers.py |
| IgM GMFR H1 / H3 / B/Vic / B/Yam (14/15) | 2.11 vs 3.99 / 1.83 vs 5.53 / 1.55 vs 4.40 / 1.94 vs 5.77 | igm_fold_change.csv | 04_igm.py |
| IgM values equal to 1.0; below 1 | 61 of 116; 0 | igm_fold_change.csv | 23_mab_imprint_and_counts.py |
| Seq-neut H1 contemporary (6 wild-type 2023): GMT d0; d29; GMFR | 117 vs 132; 478 vs 257; 4.07 vs 1.95 | neutralization_seqbased.csv | 07_seqneut_participant.py |
| Same: adjusted GMR d29; unadjusted d29; d121/181 | 2.06 (1.23–3.46) p=0.008; 1.86 (0.75–4.62); 1.17 (0.77–1.77) | neutralization_seqbased.csv | 07_seqneut_participant.py |
| Same: % of strains with ≥4× rise per participant | 53% vs 13% (p=0.006) | neutralization_seqbased.csv | 13_breadth_seqneut.py |
| Seq-neut A/Wisconsin/588/2019: GMFR; adjusted GMR | 6.15 vs 2.34; 2.44 (1.18–5.05) | neutralization_seqbased.csv | 07_seqneut_participant.py |
| Seq-neut A/Wisconsin/67/2022: GMFR; adjusted GMR | 3.51 vs 1.69; 2.07 (1.26–3.38) | neutralization_seqbased.csv | 07_seqneut_participant.py |
| Seq-neut H1 historical (4): adjusted GMR | 1.69 (0.91–3.13) | neutralization_seqbased.csv | 07_seqneut_participant.py |
| Seq-neut A/Darwin/6/2021: GMT d29; GMFR; GMR unadjusted; adjusted | 244 vs 482; 2.24 vs 2.74; 0.51 (0.27–0.95) p=0.035; 0.62 (0.34–1.12) | neutralization_seqbased.csv | 07_seqneut_participant.py |
| Seq-neut A/Darwin/9/2021: GMFR; adjusted GMR | 4.78 vs 4.49; 0.81 (0.35–1.87) | neutralization_seqbased.csv | 07_seqneut_participant.py |
| Seq-neut H3 contemporary (68 wild-type 2022–24): GMT d0; d29; GMFR | 143 vs 215; 402 vs 467; 2.82 vs 2.17 | neutralization_seqbased.csv | 07_seqneut_participant.py |
| Same: baseline GMR; unadjusted d29; adjusted d29; adjusted d121/181 | 0.66 (0.40–1.11); 0.86 (0.44–1.68); 1.17 (0.64–2.12) p=0.60; 1.05 (0.65–1.68) | neutralization_seqbased.csv | 07_seqneut_participant.py |
| Same: % of strains with ≥4× rise | 28% vs 24% (p=0.36) | neutralization_seqbased.csv | 13_breadth_seqneut.py |
| Seq-neut H3 historical (8): adjusted GMR | 1.63 (0.99–2.68) | neutralization_seqbased.csv | 07_seqneut_participant.py |
| Censoring sensitivity: H1 / H3 contemporary adjusted GMR (3 rules) | 2.06 / 1.95 / 2.31; 1.17 / 1.18 / 1.16 | neutralization_seqbased.csv | 15_sensitivity.py |
| Lowest-titre contemporary H3 (median titre across all sera) | BritishColumbia/RV00920/2023 62; Lisboa/124/2024 68; Shaanxi-Yuyang/1204/2024 69; DistrictOfColumbia/27/2023 83 | neutralization_seqbased.csv | 23_mab_imprint_and_counts.py |
| Egg/wild-type titre ratio at baseline, 5 historical H3 pairs | 1.44–10.88× | neutralization_seqbased.csv | 12_egg_pairs.py |
| A/HongKong/4801/2014 and A/Singapore/INFIMH-16-0019/2016 egg/wild-type change, arm difference | 2.17× (p=0.021); 2.10× (p=0.028) | neutralization_seqbased.csv | 12_egg_pairs.py |
| IVR-238 vs A/Wisconsin/67/2022 titre ratio at d0 | 4.7 (mRNA), 5.2 (Fluarix) | neutralization_seqbased.csv | 12_egg_pairs.py |
| H3 ELISA fold-rise / A/Darwin/6/2021 neutralisation fold-rise | 3.58 vs 0.80 (p=6.4×10⁻⁵) | elisa_igg_titers.csv + neutralization_seqbased.csv | 15_sensitivity.py |
| Seq-neut censored values; missing serum×virus cells | 171 upper-bound (d0: 85 mRNA vs 47 Fluarix), 70 lower-bound; 57 missing | neutralization_seqbased.csv | 23_mab_imprint_and_counts.py |
| Bead-array mean log₂ FC: A/Hong Kong/1/1968; A/Darwin/6/2021; A/Thailand/8/2022 | 3.45 vs 0.20; 4.71 vs 2.10; 4.99 vs 1.75 | binding_breadth_h3.csv | 05_breadth.py |
| Bead-array mean log₂ FC: A/Puerto Rico/8/1934; A/Wisconsin/67/2022 | 1.54 vs 0.10; 2.03 vs 0.62 | binding_breadth_h1.csv | 05_breadth.py |
| Bead-array per-participant mean log₂ FC, H1 / H3 | 1.64 vs 0.74 (p=0.007) / 3.39 vs 0.87 (p<0.001) | binding_breadth_h*.csv | 05_breadth.py |
| mAbs binding ≥5× control (average across donors): HK/1968; Croatia/2023; Darwin/6; H7; H5; Netherlands/01317/2025 | 48 vs 5%; 72 vs 25%; 92 vs 44%; 11 vs 0%; 3 vs 2%; 93 vs 82% | mab_binding_panels.csv | 09_mab_breadth.py |
| Unique mAbs; Fluarix mAbs from donor 397-05 | 589 (4 donors) vs 106 (3 donors); 84/106 (79%) | mab_binding_panels.csv | 23_mab_imprint_and_counts.py |
| Group-1 mRNA mAbs binding A/Wisconsin/588/2019 more strongly than A/Victoria/4897/2022 | 78%, median log₂ ratio 1.99 | mab_binding_panels.csv | 23_mab_imprint_and_counts.py |
| IgM in donor 397-05 | 166–212× for all four antigens | igm_fold_change.csv | 04_igm.py |
| HA⁺ IgG GC B cells, median, week 2 (n 6/11); week 26 (n 5/8) | 24.2% vs 2.3% (p=0.037); 18.9% vs 1.6% (p=0.34) | gc_frequencies.csv (block 1) | 10_cellular.py |
| GC clones also found among week-1 plasmablasts (mRNA donors 06/17/28/29) | 92%, 91%, 83%, 73% | pb_gc_clonal_overlap.csv | read directly |
| Vaccine-elicited serum IgG clonotypes; share of abundance from pre-existing clonotypes (n 8/8) | 32 vs 17.5 (p=0.066); 87% vs 89% | repertoire_clonotype_counts.csv | 11_repertoire.py |
| CDRH3 diversity at week 4 | 70.8 vs 24.5 (p=0.010) | cdrh3_diversity_index.csv | 11_repertoire.py |
| Residual SD of log₂ d29 titre: H1 / H3 contemporary panels | 0.94 / 1.03 | neutralization_seqbased.csv | 14_sample_size.py |
| WU397 power for 1.5× / 2× GMR | H3 32% / 72%; H1 37% / 79% | neutralization_seqbased.csv | 14_sample_size.py |
| Study 1 n per arm (GMR 1.5 / 1.25; SD 1.0–1.3) | 73–123 / 240–405 | derived | 19_design_sizes.py |
| HAI SCR non-inferiority n per arm (10-point margin; SCR 15–50%) | 268–526 | derived | 19_design_sizes.py |
| Study 2 n per arm (40%→15%; 30%→12%) | 49; 80 | derived | 19_design_sizes.py |
| Study 3 cases (rVE 25% / 20%, superiority) | 511 / 847 | derived | 19_design_sizes.py |
| Cohort sizes (trial_summary.md) | ELISA/IgM 38/37; HAI 14/15; bead/MN 14/15; seq-neut 13/14; FNA 6/11 | trial_summary.md | as stated (IgM actually 14/15) |

---

## 6. Data-package issues that need resolving

Full register: `data_issues_register.md` (17 items).

- **Arms are not comparable:** the antigens differ between arms (#1); allocation was non-randomised with no covariates (#2); enrolment-block heterogeneity (#3).
- **Readouts are incompletely specified:** the strains behind HAI, MN and ELISA are not named (#4); egg-reassortant reference viruses (#5); MN capped at 1:1280 (#6); an implausible MN participant (#7).
- **Files are internally inconsistent:**
  - gc_frequencies.csv contains two unlabelled blocks (#8).
  - Cellular timepoints match neither schedule (#9).
  - Plasmablast data include 11 participants outside the documented lymph-node subset, with values at lower precision (#10).
  - IgM is floored at 1 and its cohort doesn't match the documentation (#11).
  - Late visits are mislabelled (#12).
  - Identifiers come in five formats (#13).
  - Repertoire files carry no IDs (#14).
  - The Fluarix mAbs come mostly from one donor (#15).
- **No infection surveillance**, so week 17/26 "durability" cannot be separated from infection during the season (#17).

---

## 7. Files in /tmp/outputs

- `answer.md`: this document.
- `forest_arm_contrasts.png`: baseline-adjusted contrasts for every readout.
- `seqneut_per_virus_contrasts.png`: per-virus baseline and adjusted contrasts for all 96 viruses.
- `numbers_ledger.csv`: the number-to-source ledger.
- `data_issues_register.md`: the integrity register.
- `analysis/`: 23 scripts (README lists run order and outputs), intermediate tables, and logs.
