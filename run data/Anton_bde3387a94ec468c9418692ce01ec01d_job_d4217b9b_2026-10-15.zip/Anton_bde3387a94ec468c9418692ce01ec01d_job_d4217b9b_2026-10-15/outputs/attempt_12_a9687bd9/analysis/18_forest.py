import sys; sys.path.insert(0,'/tmp/outputs/analysis')
from common import *
import statsmodels.formula.api as smf
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
rows=[]
def anc(df,pre,post,label,kind,n_note=''):
    d=df.dropna(subset=[pre,post]).copy(); d['l0']=np.log2(d[pre]); d['l1']=np.log2(d[post]); d['m']=(d.arm=='mRNA-1010').astype(int)
    fit=smf.ols('l1~m+l0',data=d).fit(); ci=2**fit.conf_int().loc['m'].values
    rows.append(dict(readout=label,kind=kind,GMR=2**fit.params['m'],lo=ci[0],hi=ci[1],p=fit.pvalues['m'],n_mRNA=d.m.sum(),n_Flu=(1-d.m).sum()))
# HAI
h=pd.read_csv(f'{DATA}/hai_titers.csv',dtype={'participant':str}); h['pid']=h.participant.map(pid)
w=h.pivot_table(index=['antigen','arm','pid'],columns='timepoint',values='hai_titer').reset_index()
for ag in ['A/H1N1','A/H3N2','B/Vic','B/Yam']: anc(w[w.antigen==ag],'wk0','wk4',f'HAI {ag} (d29)','Functional: HAI')
# MN
m=pd.read_csv(f'{DATA}/microneutralization.csv'); m['pid']=m.participant.map(pid)
t=m[m.measure=='titer'].pivot_table(index=['panel','arm','pid'],columns='timepoint',values='value').reset_index()
for p in ['homologous','heterologous']: anc(t[t.panel==p],'wk0','wk4',f'MN {p} panel (d29)','Functional: MN')
# seq neut
pp=pd.read_csv('seqneut_participant_panel_means.csv')
for g in ['H1 contemporary 2023 (6 WT isolates)','H1 A/Wisconsin/67/2022 (~mRNA H1, cell)','H1 A/Wisconsin/588/2019 (~Fluarix H1, cell)','H3 A/Darwin/6/2021 (mRNA H3 strain)','H3 A/Darwin/9/2021 (Fluarix H3 CVV)','H3 contemporary 2022-24 WT (68)','H3 historical 2012-2020 WT (8)']:
    d=pp[pp.group==g].copy(); d['d0']=2**d.l0; d['d29']=2**d.l29; d['late']=2**d.llate
    anc(d,'d0','d29',f'SeqNeut {g} (d29)','Functional: seq-neut')
for g in ['H1 contemporary 2023 (6 WT isolates)','H3 contemporary 2022-24 WT (68)']:
    d=pp[pp.group==g].copy(); d['d0']=2**d.l0; d['late']=2**d.llate
    anc(d,'d0','late',f'SeqNeut {g} (d121/181)','Functional: seq-neut')
# ELISA
e=pd.read_csv(f'{DATA}/elisa_igg_titers.csv'); e=e[e.measure=='ec50']
te=e.pivot_table(index=['antigen','arm','participant'],columns='timepoint',values='value').reset_index(); te['late']=te[['wk17','wk26']].max(axis=1)
for ag in ['A/H1','A/H3','B/Vic','B/Yam']: anc(te[te.antigen==ag],'wk0','wk4',f'ELISA IgG {ag} (d29)','Binding: ELISA')
for ag in ['A/H1','A/H3']: anc(te[te.antigen==ag],'wk0','late',f'ELISA IgG {ag} (wk17/26)','Binding: ELISA')
r=pd.DataFrame(rows); r.to_csv('forest_ancova_all_readouts.csv',index=False)
pd.set_option('display.width',250); print(r.round(3).to_string(index=False))
# plot
col={'Functional: HAI':'tab:blue','Functional: MN':'tab:cyan','Functional: seq-neut':'tab:green','Binding: ELISA':'tab:red'}
fig,ax=plt.subplots(figsize=(12,0.38*len(r)+2))
y=np.arange(len(r))[::-1]
for i,(yy,row) in enumerate(zip(y,r.itertuples())):
    ax.plot([row.lo,row.hi],[yy,yy],color=col[row.kind],lw=2); ax.plot(row.GMR,yy,'o',color=col[row.kind])
ax.axvline(1,color='k',lw=0.8); ax.set_xscale('log',base=2)
ax.set_yticks(y); ax.set_yticklabels([f'{a}  [n={b}/{c}]' for a,b,c in zip(r.readout,r.n_mRNA,r.n_Flu)],fontsize=8)
ax.set_xlabel('Baseline-adjusted GMR, mRNA-1010 / Fluarix\n(ANCOVA on log2 titre, 95% CI)',fontsize=9)
for k,c in col.items(): ax.plot([],[],color=c,lw=3,label=k)
ax.legend(fontsize=7,loc='upper left',bbox_to_anchor=(1.01,1)); ax.set_title('WU397 arm contrasts by readout\n(non-randomised; H1 composition differs between arms)',fontsize=9)
plt.tight_layout(); plt.savefig('/tmp/outputs/forest_arm_contrasts.png',dpi=150)
