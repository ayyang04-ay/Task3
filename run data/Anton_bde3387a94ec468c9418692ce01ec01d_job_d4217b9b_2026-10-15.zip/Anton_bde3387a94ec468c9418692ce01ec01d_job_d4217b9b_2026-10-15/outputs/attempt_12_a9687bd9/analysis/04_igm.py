import sys; sys.path.insert(0,'/tmp/outputs/analysis')
from common import *
i=pd.read_csv(f'{DATA}/igm_fold_change.csv',dtype={'participant':str}); i['pid']=i.participant.map(pid)
rows=[]
for (ag,arm),g in i.groupby(['antigen','arm']):
    rows.append(dict(antigen=ag,arm=arm,n=len(g),GMFR=gmt(g.fold_change),median=g.fold_change.median(),n_rise=f'{(g.fold_change>1).sum()}/{len(g)}', n_ge4=f'{(g.fold_change>=4).sum()}/{len(g)}'))
r=pd.DataFrame(rows); print(r.round(2).to_string(index=False)); r.to_csv('igm_summary.csv',index=False)
for ag,g in i.groupby('antigen'):
    a=g[g.arm=='mRNA-1010'].fold_change; f=g[g.arm=='Fluarix'].fold_change
    print(ag, 'MW p=%.3f'%stats.mannwhitneyu(a,f).pvalue, 'GMR mRNA/Flu=%.2f'%(gmt(a)/gmt(f)))
# excluding participant 005 outlier
print('\nexcluding Fluarix 005 (IgM FC >160 on all 4 antigens):')
for ag,g in i[i.pid!=5].groupby('antigen'):
    a=g[g.arm=='mRNA-1010'].fold_change; f=g[g.arm=='Fluarix'].fold_change
    print(ag, 'GMFR mRNA %.2f Flu %.2f MW p=%.3f'%(gmt(a),gmt(f),stats.mannwhitneyu(a,f).pvalue))
print(sorted(i.fold_change.round(4).unique()))
