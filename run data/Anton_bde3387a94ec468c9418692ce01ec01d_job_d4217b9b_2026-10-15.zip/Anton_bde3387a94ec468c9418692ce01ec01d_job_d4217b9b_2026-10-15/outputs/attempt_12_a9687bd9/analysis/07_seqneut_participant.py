import sys; sys.path.insert(0,'/tmp/outputs/analysis')
from common import *
import statsmodels.formula.api as smf
pd.set_option('display.width',250); pd.set_option('display.max_rows',500)
w=pd.read_csv('seqneut_wide.csv')
# Category groupings for participant-level summaries
grp={
 'H1 contemporary 2023 (6 WT isolates)': w.cat=='H1_contemporary_2023',
 'H1 historical 2009-2019 (4)': w.cat=='H1_historical',
 'H1 A/Wisconsin/67/2022 (~mRNA H1, cell)': w.cat=='H1_vaccine-like_mRNA(5a.2a.1)',
 'H1 A/Wisconsin/588/2019 (~Fluarix H1, cell)': w.cat=='H1_vaccine-like_Fluarix(5a.2)',
 'H1 A/Victoria/4897/2022 IVR-238 (egg reassortant)': w.virus=='A/Victoria/4897/2022_IVR-238_H1N1',
 'H3 A/Darwin/6/2021 (mRNA H3 strain)': w.cat=='H3_mRNA_vaccine_strain(cell)',
 'H3 A/Darwin/9/2021 (Fluarix H3 CVV)': w.cat=='H3_Fluarix_vaccine_strain(egg-based CVV)',
 'H3 contemporary 2022-24 WT (68)': w.cat=='H3_contemporary_2022-24',
 'H3 historical 2012-2020 WT (8)': w.cat=='H3_historical',
 'H3 egg reassortants (5)': (w.cat=='egg_reassortant')&(w.subtype=='H3N2'),
}
rows=[]; pp_all=[]
for name,mask in grp.items():
    d=w[mask].copy()
    for c in ['d0','d29','late']: d['l'+c]=np.log2(d[c])
    pp=d.groupby(['arm','pid']).agg(l0=('ld0','mean'),l29=('ld29','mean'),llate=('llate','mean'),nv=('virus','nunique')).reset_index()
    pp['lfc']=pp.l29-pp.l0; pp['lfclate']=pp.llate-pp.l0; pp['group']=name
    pp_all.append(pp)
    a=pp[pp.arm=='mRNA-1010']; f=pp[pp.arm=='Fluarix']
    def mdiff(x,y):
        x=x.dropna(); y=y.dropna()
        tt=stats.ttest_ind(x,y,equal_var=False)
        se=np.sqrt(x.var()/len(x)+y.var()/len(y)); d=x.mean()-y.mean()
        return 2**d, 2**(d-stats.t.ppf(.975,tt.df)*se), 2**(d+stats.t.ppf(.975,tt.df)*se), tt.pvalue
    pp['m']=(pp.arm=='mRNA-1010').astype(int)
    fit=smf.ols('l29~m+l0',data=pp).fit(); ci=2**fit.conf_int().loc['m'].values
    ppl=pp.dropna(subset=['llate']); fitl=smf.ols('llate~m+l0',data=ppl).fit(); cil=2**fitl.conf_int().loc['m'].values
    b=mdiff(a.l0,f.l0); p29=mdiff(a.l29,f.l29); fr=mdiff(a.lfc,f.lfc); frl=mdiff(a.lfclate,f.lfclate)
    rows.append({'panel':name,'n (mRNA/Flu)':f'{len(a)}/{len(f)}',
      'GMT d0 mRNA':2**a.l0.mean(),'GMT d0 Flu':2**f.l0.mean(),'GMT d29 mRNA':2**a.l29.mean(),'GMT d29 Flu':2**f.l29.mean(),
      'GMFR d29 mRNA':2**a.lfc.mean(),'GMFR d29 Flu':2**f.lfc.mean(),
      'baseline GMR (m/F)':f'{b[0]:.2f} ({b[1]:.2f}-{b[2]:.2f}) p={b[3]:.3f}',
      'd29 GMR (m/F)':f'{p29[0]:.2f} ({p29[1]:.2f}-{p29[2]:.2f}) p={p29[3]:.3f}',
      'GMFR ratio (m/F)':f'{fr[0]:.2f} ({fr[1]:.2f}-{fr[2]:.2f}) p={fr[3]:.3f}',
      'ANCOVA d29 GMR adj. baseline':f'{2**fit.params["m"]:.2f} ({ci[0]:.2f}-{ci[1]:.2f}) p={fit.pvalues["m"]:.3f}',
      'GMFR late mRNA':2**a.lfclate.mean(),'GMFR late Flu':2**f.lfclate.mean(),
      'ANCOVA late GMR adj. baseline':f'{2**fitl.params["m"]:.2f} ({cil[0]:.2f}-{cil[1]:.2f}) p={fitl.pvalues["m"]:.3f}'})
r=pd.DataFrame(rows)
print(r.round(1).T.to_string())
r.to_csv('seqneut_by_panel_participant_level.csv',index=False)
pd.concat(pp_all).to_csv('seqneut_participant_panel_means.csv',index=False)
