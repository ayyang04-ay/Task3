"""mAb imprinting signature + inline counts cited in answer.md"""
import sys; sys.path.insert(0,'/tmp/outputs/analysis')
from common import *
w=pd.read_csv('mab_wide.csv')
rows=[]
for p,a,b in [('group_I','A/Wisconsin/588/2019','A/Victoria/4897/2022'),('group_II','A/Texas/50/2012','A/Darwin/6/2021')]:
    for arm in ['mRNA-1010','Fluarix']:
        d=w[(w.panel==p)&(w.arm==arm)].dropna(subset=[a,b]); d=d[(d[a]>=5)|(d[b]>=5)]
        r=np.log2(d[a].clip(lower=0.5)/d[b].clip(lower=0.5))
        rows.append(dict(panel=p,arm=arm,older=a,immunogen=b,n=len(d),pct_bind_older_more=100*(r>0).mean(),median_log2_ratio=r.median(),
                         donor_medians=d.assign(r=r).groupby('donor').r.median().round(2).to_dict()))
o=pd.DataFrame(rows); print(o.round(2).to_string(index=False)); o.to_csv('mab_imprinting.csv',index=False)
m=pd.read_csv(f'{DATA}/mab_binding_panels.csv'); m['donor']=m.mab_id.str.split('.').str[1]
u=m.drop_duplicates('mab_id'); print('\nunique mAbs by arm:',u.groupby('arm').mab_id.nunique().to_dict()); print(u.groupby(['arm','donor']).mab_id.nunique().to_dict())
i=pd.read_csv(f'{DATA}/igm_fold_change.csv'); print('\nIgM values ==1:',(i.fold_change==1).sum(),'of',len(i),'; <1:',(i.fold_change<1).sum())
s=pd.read_csv(f'{DATA}/neutralization_seqbased.csv'); s['arm']=s.serum.str.split('_').str[0]; s['day']=s.serum.str.split('_d').str[-1]
print('\ncensoring by arm/day:'); print(pd.crosstab([s.arm,s.day],s.titer_bound))
full=pd.MultiIndex.from_product([s.serum.unique(),s.virus.unique()]); miss=full.difference(pd.MultiIndex.from_frame(s[['serum','virus']]))
print('missing serum x virus:',len(miss))
med=s.groupby('virus').titer.median().sort_values(); print('\nlowest median-titre viruses:'); print(med.head(6).round(1))
