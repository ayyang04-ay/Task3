import sys; sys.path.insert(0,'/tmp/outputs/analysis')
from common import *
import statsmodels.formula.api as smf
m=pd.read_csv(f'{DATA}/microneutralization.csv'); m['pid']=m.participant.map(pid)
t=m[m.measure=='titer'].pivot_table(index=['panel','arm','pid'],columns='timepoint',values='value').reset_index()
rows=[]
for excl,lab in [([], 'all'),([14],'excluding mRNA 397-014 (MN at floor despite HAI/ELISA response)')]:
    for pan,g in t[~t.pid.isin(excl)].groupby('panel'):
        g=g.copy(); a=g[g.arm=='mRNA-1010']; f=g[g.arm=='Fluarix']
        g['l0']=np.log2(g.wk0); g['l4']=np.log2(g.wk4); g['m']=(g.arm=='mRNA-1010').astype(int)
        fit=smf.ols('l4~m+l0',data=g).fit(); ci=2**fit.conf_int().loc['m'].values
        b=gmr_ci(a.wk0,f.wk0); p4=gmr_ci(a.wk4,f.wk4); fr=gmr_ci(a.wk4/a.wk0,f.wk4/f.wk0)
        rows.append(dict(set=lab,panel=pan,n=f'{len(a)}/{len(f)}',GMT0=f'{gmt(a.wk0):.0f} vs {gmt(f.wk0):.0f}',GMT4=f'{gmt(a.wk4):.0f} vs {gmt(f.wk4):.0f}',
           GMFR=f'{gmt(a.wk4/a.wk0):.2f} vs {gmt(f.wk4/f.wk0):.2f}',baseline_GMR=f'{b[0]:.2f} p={b[3]:.3f}',GMFR_ratio=f'{fr[0]:.2f} ({fr[1]:.2f}-{fr[2]:.2f}) p={fr[3]:.2f}',
           ANCOVA=f'{2**fit.params["m"]:.2f} ({ci[0]:.2f}-{ci[1]:.2f}) p={fit.pvalues["m"]:.2f}'))
r=pd.DataFrame(rows); pd.set_option('display.width',250); print(r.to_string(index=False)); r.to_csv('mn_sensitivity.csv',index=False)
