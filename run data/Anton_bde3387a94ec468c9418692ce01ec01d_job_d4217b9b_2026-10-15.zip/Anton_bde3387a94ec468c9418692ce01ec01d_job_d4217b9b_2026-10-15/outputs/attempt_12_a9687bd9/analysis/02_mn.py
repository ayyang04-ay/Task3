import sys; sys.path.insert(0,'/tmp/outputs/analysis')
from common import *
import statsmodels.formula.api as smf
m=pd.read_csv(f'{DATA}/microneutralization.csv'); m['pid']=m.participant.map(pid)
t=m[m.measure=='titer'].pivot_table(index=['panel','arm','pid'],columns='timepoint',values='value').reset_index()
fc=m[m.measure=='fold_change'].pivot_table(index=['panel','arm','pid'],columns='timepoint',values='value').reset_index()
t['late']=t[['wk17','wk26']].max(axis=1)
pd.set_option('display.width',250)
print('max titre observed:', m[m.measure=='titer'].value.max(), ' min:', m[m.measure=='titer'].value.min())
rows=[]
for (pan,arm),g in t.groupby(['panel','arm']):
    f=g.wk4/g.wk0
    rows.append(dict(panel=pan,arm=arm,n=len(g),GMT0=gmt(g.wk0),GMT4=gmt(g.wk4),GMTlate=gmt(g.late.dropna()),
      GMFR4=gmt(f), n4fold=f'{(f>=4).sum()}/{len(g)}',
      at_ceiling_wk0=f'{(g.wk0>=1280).sum()}/{len(g)}', at_ceiling_wk4=f'{(g.wk4>=1280).sum()}/{len(g)}'))
r=pd.DataFrame(rows); print(r.round(1).to_string(index=False)); r.to_csv('mn_summary.csv',index=False)
# check provided fold-change vs computed
mm_=t.merge(fc,on=['panel','arm','pid'],suffixes=('','_fc'))
mm_['calc4']=mm_.wk4/mm_.wk0
mm_['calclate']=mm_.late/mm_.wk0
bad=mm_[(abs(np.log2(mm_.calc4)-np.log2(mm_['wk4_fc']))>0.01)]
print('\nwk4 provided FC != computed:'); print(bad[['panel','arm','pid','wk0','wk4','calc4','wk4_fc']].to_string(index=False))
bad2=mm_[(abs(np.log2(mm_.calclate)-np.log2(mm_['wk17/26']))>0.01)]
print('\nwk17/26 provided FC != computed:'); print(bad2[['panel','arm','pid','wk0','late','calclate','wk17/26']].to_string(index=False))
# arm comparison
out=[]
for pan,g in t.groupby('panel'):
    a=g[g.arm=='mRNA-1010']; f=g[g.arm=='Fluarix']
    b=gmr_ci(a.wk0,f.wk0); p4=gmr_ci(a.wk4,f.wk4); fr=gmr_ci(a.wk4/a.wk0,f.wk4/f.wk0)
    g=g.copy(); g['l0']=np.log2(g.wk0); g['l4']=np.log2(g.wk4); g['m']=(g.arm=='mRNA-1010').astype(int)
    fit=smf.ols('l4~m+l0',data=g).fit(); ci=2**fit.conf_int().loc['m'].values
    # excluding ceiling at baseline
    g2=g[g.wk0<1280]; a2=g2[g2.arm=='mRNA-1010']; f2=g2[g2.arm=='Fluarix']
    fr2=gmr_ci(a2.wk4/a2.wk0,f2.wk4/f2.wk0)
    out.append(dict(panel=pan,baseline_GMR=f'{b[0]:.2f} ({b[1]:.2f}-{b[2]:.2f}) p={b[3]:.2f}',wk4_GMR=f'{p4[0]:.2f} ({p4[1]:.2f}-{p4[2]:.2f}) p={p4[3]:.2f}',
       GMFR_ratio=f'{fr[0]:.2f} ({fr[1]:.2f}-{fr[2]:.2f}) p={fr[3]:.2f}',ANCOVA=f'{2**fit.params["m"]:.2f} ({ci[0]:.2f}-{ci[1]:.2f}) p={fit.pvalues["m"]:.2f}',
       GMFR_ratio_excl_baseline_ceiling=f'{fr2[0]:.2f} ({fr2[1]:.2f}-{fr2[2]:.2f}) p={fr2[3]:.2f} (n={len(a2)}/{len(f2)})'))
o=pd.DataFrame(out); print(o.to_string(index=False)); o.to_csv('mn_arm_comparison.csv',index=False)
# participant 014
print(t[t.pid==14])
