import pandas as pd, numpy as np, re
from scipy import stats
DATA='/tmp/world/filesystem'
def pid(x):
    s=str(x)
    s=s.replace('397-','').replace('397.','')
    m=re.search(r'(\d+)$', s)
    return int(m.group(1))
def gmt(x):
    x=np.asarray(x,float); x=x[~np.isnan(x)]
    return float(np.exp(np.mean(np.log(x)))) if len(x) else np.nan
def gm_ci(x, alpha=0.05):
    x=np.log(np.asarray(x,float)); x=x[~np.isnan(x)]
    n=len(x); m=x.mean(); se=x.std(ddof=1)/np.sqrt(n)
    t=stats.t.ppf(1-alpha/2,n-1)
    return np.exp(m), np.exp(m-t*se), np.exp(m+t*se)
def gmr_ci(a,b,alpha=0.05):
    """GMR a/b with Welch t CI on log scale"""
    a=np.log(np.asarray(a,float)); b=np.log(np.asarray(b,float))
    a=a[~np.isnan(a)]; b=b[~np.isnan(b)]
    d=a.mean()-b.mean()
    va=a.var(ddof=1)/len(a); vb=b.var(ddof=1)/len(b)
    se=np.sqrt(va+vb)
    df=(va+vb)**2/(va**2/(len(a)-1)+vb**2/(len(b)-1))
    t=stats.t.ppf(1-alpha/2,df)
    p=2*stats.t.sf(abs(d/se),df)
    return np.exp(d), np.exp(d-t*se), np.exp(d+t*se), p
def wilson(k,n,alpha=0.05):
    if n==0: return (np.nan,np.nan,np.nan)
    z=stats.norm.ppf(1-alpha/2); p=k/n
    den=1+z*z/n; c=(p+z*z/(2*n))/den; h=z*np.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
    return p, c-h, c+h
def newcombe_diff(k1,n1,k2,n2,alpha=0.05):
    p1,l1,u1=wilson(k1,n1,alpha); p2,l2,u2=wilson(k2,n2,alpha)
    d=p1-p2
    lo=d-np.sqrt((p1-l1)**2+(u2-p2)**2); hi=d+np.sqrt((u1-p1)**2+(p2-l2)**2)
    return d,lo,hi
