import sys; sys.path.insert(0,'/tmp/outputs/analysis')
from common import *
import statsmodels.formula.api as smf
pd.set_option('display.width',250); pd.set_option('display.max_rows',500)
s=pd.read_csv(f'{DATA}/neutralization_seqbased.csv')
s['arm']=s.serum.str.split('_').str[0]; s['pid']=s.serum.str.split('_').str[1].map(pid); s['day']=s.serum.str.split('_d').str[-1].astype(int)
s['tp']=s.day.map({0:'d0',29:'d29',121:'late',181:'late'})
s['subtype']=s.virus.str.extract(r'_(H\dN\d)$')[0]
s['vname']=s.virus.str.replace(r'_(H\dN\d)$','',regex=True)
EGG=['X-223A','X-307A','NIB-88','IVR-238','egg']
s['egg']=s.vname.apply(lambda v:any(k in v for k in EGG))
def year(v):
    m=re.search(r'/(\d{4})(?:egg|X-\w+|NIB-\d+|_IVR-\d+)?$',v)
    y=int(m.group(1)) if m else None
    if v.startswith('A/SOUTHAFRICA/R07876/202023'): y=2023
    return y
s['year']=s.vname.map(year)
print(s[s.year.isna()].vname.unique())
# categories
def cat(r):
    v=r.vname
    if r.egg: return 'egg_reassortant'
    if r.subtype=='H1N1':
        if v in ['A/Victoria/4897/2022_IVR-238']: return 'egg_reassortant'
        if v=='A/Wisconsin/67/2022': return 'H1_vaccine-like_mRNA(5a.2a.1)'
        if v=='A/Wisconsin/588/2019': return 'H1_vaccine-like_Fluarix(5a.2)'
        if r.year<=2019: return 'H1_historical'
        return 'H1_contemporary_2023'
    else:
        if v=='A/Darwin/6/2021': return 'H3_mRNA_vaccine_strain(cell)'
        if v=='A/Darwin/9/2021': return 'H3_Fluarix_vaccine_strain(egg-based CVV)'
        if r.year<=2020: return 'H3_historical'
        return 'H3_contemporary_2022-24'
s['cat']=s.apply(cat,axis=1)
print(s.groupby('cat').vname.nunique())
# substitution for censored
s['t']=s.titer
s.to_csv('seqneut_annotated.csv',index=False)
w=s.pivot_table(index=['arm','pid','virus','vname','subtype','cat','egg','year'],columns='tp',values='t').reset_index()
w['lfc29']=np.log2(w.d29/w.d0); w['lfclate']=np.log2(w.late/w.d0)
w.to_csv('seqneut_wide.csv',index=False)
# per-virus comparison
rows=[]
for v,g in w.groupby('virus'):
    g=g.dropna(subset=['d0','d29'])
    a=g[g.arm=='mRNA-1010']; f=g[g.arm=='Fluarix']
    if len(a)<3 or len(f)<3: continue
    fr=gmr_ci(a.d29/a.d0,f.d29/f.d0); p29=gmr_ci(a.d29,f.d29); b0=gmr_ci(a.d0,f.d0)
    gg=g.copy(); gg['l0']=np.log2(gg.d0); gg['l29']=np.log2(gg.d29); gg['m']=(gg.arm=='mRNA-1010').astype(int)
    fit=smf.ols('l29~m+l0',data=gg).fit()
    rows.append(dict(virus=v,cat=g.cat.iloc[0],n_m=len(a),n_f=len(f),GMT0_m=gmt(a.d0),GMT0_f=gmt(f.d0),GMT29_m=gmt(a.d29),GMT29_f=gmt(f.d29),
        GMFR_m=gmt(a.d29/a.d0),GMFR_f=gmt(f.d29/f.d0),GMFR_ratio=fr[0],GMFR_ratio_p=fr[3],d29_GMR=p29[0],d29_GMR_p=p29[3],baseline_GMR=b0[0],
        ANCOVA_GMR=2**fit.params['m'],ANCOVA_p=fit.pvalues['m']))
r=pd.DataFrame(rows).sort_values(['cat','virus'])
print(r.round(2).to_string(index=False))
r.to_csv('seqneut_per_virus.csv',index=False)
