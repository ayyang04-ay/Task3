import sys; sys.path.insert(0,'/tmp/outputs/analysis')
from common import *
import statsmodels.formula.api as smf
h=pd.read_csv(f'{DATA}/hai_titers.csv',dtype={'participant':str})
h['pid']=h.participant.map(pid)
w=h.pivot_table(index=['antigen','arm','pid'],columns='timepoint',values='hai_titer').reset_index()
rows=[]
for (ag,arm),g in w.groupby(['antigen','arm']):
    g0=g.dropna(subset=['wk0','wk4'])
    fr=g0.wk4/g0.wk0
    sc=((fr>=4)&(g0.wk4>=40)).sum()
    sp0=(g0.wk0>=40).sum(); sp4=(g0.wk4>=40).sum()
    late=g[['wk17','wk26']].max(axis=1) if 'wk17' in g else g.wk26
    rows.append(dict(antigen=ag,arm=arm,n=len(g0),GMT_wk0=gmt(g0.wk0),GMT_wk4=gmt(g0.wk4),GMFR_wk4=gmt(fr),
        SCR=f'{sc}/{len(g0)}',SCR_pct=100*sc/len(g0),SP_wk0=f'{sp0}/{len(g0)}',SP_wk4=f'{sp4}/{len(g0)}',
        GMT_late=gmt(late.dropna()), n_late=late.notna().sum()))
res=pd.DataFrame(rows)
pd.set_option('display.width',250); pd.set_option('display.precision',1)
print(res.to_string(index=False))
res.to_csv('hai_summary.csv',index=False)
# arm comparisons
out=[]
for ag,g in w.groupby('antigen'):
    g=g.dropna(subset=['wk0','wk4']).copy()
    a=g[g.arm=='mRNA-1010']; f=g[g.arm=='Fluarix']
    b=gmr_ci(a.wk0,f.wk0); p4=gmr_ci(a.wk4,f.wk4); fr=gmr_ci(a.wk4/a.wk0, f.wk4/f.wk0)
    g['l0']=np.log2(g.wk0); g['l4']=np.log2(g.wk4); g['m']=(g.arm=='mRNA-1010').astype(int)
    fit=smf.ols('l4 ~ m + l0',data=g).fit()
    adj=2**fit.params['m']; ci=2**fit.conf_int().loc['m'].values
    ka=((a.wk4/a.wk0>=4)&(a.wk4>=40)).sum(); kf=((f.wk4/f.wk0>=4)&(f.wk4>=40)).sum()
    d=newcombe_diff(ka,len(a),kf,len(f))
    fisher=stats.fisher_exact([[ka,len(a)-ka],[kf,len(f)-kf]])[1]
    mw=stats.mannwhitneyu(a.wk4/a.wk0, f.wk4/f.wk0).pvalue
    out.append(dict(antigen=ag, baseline_GMR=f'{b[0]:.2f} ({b[1]:.2f}-{b[2]:.2f}) p={b[3]:.2f}',
        wk4_GMR=f'{p4[0]:.2f} ({p4[1]:.2f}-{p4[2]:.2f}) p={p4[3]:.2f}',
        GMFR_ratio=f'{fr[0]:.2f} ({fr[1]:.2f}-{fr[2]:.2f}) p={fr[3]:.2f}; MW p={mw:.2f}',
        ANCOVA_wk4_GMR_adj=f'{adj:.2f} ({ci[0]:.2f}-{ci[1]:.2f}) p={fit.pvalues["m"]:.2f}',
        SCR_diff=f'{100*d[0]:.0f}% ({100*d[1]:.0f} to {100*d[2]:.0f}) Fisher p={fisher:.2f}'))
o=pd.DataFrame(out); print(o.to_string(index=False)); o.to_csv('hai_arm_comparison.csv',index=False)
# baseline >=40 and ceiling/floor
print('\nBaseline titre distribution (share >=40):')
print(w.groupby(['antigen','arm']).apply(lambda g: f"{(g.wk0>=40).sum()}/{g.wk0.notna().sum()}"))
