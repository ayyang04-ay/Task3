import sys; sys.path.insert(0,'/tmp/outputs/analysis')
from common import *
pd.set_option('display.width',250)
r=pd.read_csv(f'{DATA}/repertoire_clonotype_counts.csv')
for met,g in r.groupby('metric'):
    a=g[g.arm=='mRNA-1010'].value; f=g[g.arm=='Fluarix'].value
    print(f'{met:35s} mRNA median {a.median():.1f} (IQR {a.quantile(.25):.1f}-{a.quantile(.75):.1f}) n={len(a)} | Fluarix median {f.median():.1f} (IQR {f.quantile(.25):.1f}-{f.quantile(.75):.1f}) n={len(f)} | MW p={stats.mannwhitneyu(a,f).pvalue:.3f}')
s=pd.read_csv(f'{DATA}/serum_igg_clonotypes.csv')
print(s.groupby(['timepoint','arm']).n_clonotypes.agg(['count','median','min','max']))
# check: wk0 serum clonotypes == n_pre_existing clonotypes?
pre=r[r.metric=='n_pre_existing_clonotypes'].reset_index(drop=True)
w0=s[s.timepoint=='wk0'].reset_index(drop=True)
print('pre-existing (repertoire file) by arm:', pre.groupby('arm').value.apply(list).to_dict())
print('wk0 serum clonotypes by arm:', w0.groupby('arm').n_clonotypes.apply(list).to_dict())
c=pd.read_csv(f'{DATA}/cdrh3_diversity_index.csv')
print(c.groupby(['timepoint','arm']).diversity_index.agg(['count','median','min','max']).round(1))
for tp in ['wk0','wk4','wk26']:
    d=c[c.timepoint==tp]; print(tp,'MW p=%.3f'%stats.mannwhitneyu(d[d.arm=='mRNA-1010'].diversity_index,d[d.arm=='Fluarix'].diversity_index).pvalue)
o=pd.read_csv(f'{DATA}/pb_gc_clonal_overlap.csv'); print(o.iloc[:,[0,2,4,5,8,9]].to_string(index=False))
