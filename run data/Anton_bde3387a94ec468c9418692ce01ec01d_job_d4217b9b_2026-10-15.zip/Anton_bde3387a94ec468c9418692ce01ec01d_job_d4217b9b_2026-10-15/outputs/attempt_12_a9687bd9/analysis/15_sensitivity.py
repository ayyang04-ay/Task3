import sys; sys.path.insert(0,'/tmp/outputs/analysis')
from common import *
import statsmodels.formula.api as smf
pd.set_option('display.width',250)
s=pd.read_csv('seqneut_annotated.csv')
res=[]
for label,f in {'bound value (main)':lambda r:r.titer,
                'LOD/2 for <40, x2 for >=upper':lambda r: r.titer/2 if r.titer_bound=='upper' else (r.titer*2 if r.titer_bound=='lower' else r.titer),
                'exclude censored':lambda r: r.titer if r.titer_bound=='interpolated' else np.nan}.items():
    s['t']=s.apply(f,axis=1)
    w=s.pivot_table(index=['arm','pid','virus','cat'],columns='tp',values='t').reset_index()
    for grp in ['H1_contemporary_2023','H3_contemporary_2022-24']:
        d=w[w.cat==grp].copy(); d['l0']=np.log2(d.d0); d['l29']=np.log2(d.d29)
        pp=d.groupby(['arm','pid'])[['l0','l29']].mean().reset_index(); pp['m']=(pp.arm=='mRNA-1010').astype(int); pp['lfc']=pp.l29-pp.l0
        fit=smf.ols('l29~m+l0',data=pp).fit(); ci=2**fit.conf_int().loc['m'].values
        a=pp[pp.m==1].lfc; fl=pp[pp.m==0].lfc
        res.append(dict(handling=label,panel=grp,GMFR_mRNA=2**a.mean(),GMFR_Flu=2**fl.mean(),ANCOVA_GMR=f'{2**fit.params["m"]:.2f} ({ci[0]:.2f}-{ci[1]:.2f}) p={fit.pvalues["m"]:.3f}'))
print(pd.DataFrame(res).round(2).to_string(index=False))
pd.DataFrame(res).to_csv('seqneut_censoring_sensitivity.csv',index=False)
# Binding vs neutralisation discordance, same participants (H3: ELISA A/H3 vs seq-neut A/Darwin/6/2021 and contemporary H3)
e=pd.read_csv(f'{DATA}/elisa_igg_titers.csv'); e=e[(e.measure=='ec50')&(e.timepoint.isin(['wk0','wk4']))]
e=e.pivot_table(index=['antigen','arm','participant'],columns='timepoint',values='value').reset_index(); e['elisa_lfc']=np.log2(e.wk4/e.wk0); e['pid']=e.participant
pp=pd.read_csv('seqneut_participant_panel_means.csv')
out=[]
for ag,grp in [('A/H3','H3 A/Darwin/6/2021 (mRNA H3 strain)'),('A/H3','H3 contemporary 2022-24 WT (68)'),('A/H1','H1 A/Wisconsin/67/2022 (~mRNA H1, cell)'),('A/H1','H1 contemporary 2023 (6 WT isolates)')]:
    j=e[e.antigen==ag][['arm','pid','elisa_lfc']].merge(pp[pp.group==grp][['arm','pid','lfc']],on=['arm','pid'])
    for arm,g in j.groupby('arm'):
        out.append(dict(ELISA=ag,neut_panel=grp,arm=arm,n=len(g),ELISA_GMFR=2**g.elisa_lfc.mean(),Neut_GMFR=2**g.lfc.mean(),ratio_binding_to_neut_rise=2**(g.elisa_lfc-g.lfc).mean()))
    a=j[j.arm=='mRNA-1010']; f=j[j.arm=='Fluarix']
    out.append(dict(ELISA=ag,neut_panel=grp,arm='Welch p (ratio)',n=np.nan,ratio_binding_to_neut_rise=stats.ttest_ind(a.elisa_lfc-a.lfc,f.elisa_lfc-f.lfc,equal_var=False).pvalue))
o=pd.DataFrame(out); print(o.round(3).to_string(index=False)); o.to_csv('binding_vs_neutralisation.csv',index=False)
