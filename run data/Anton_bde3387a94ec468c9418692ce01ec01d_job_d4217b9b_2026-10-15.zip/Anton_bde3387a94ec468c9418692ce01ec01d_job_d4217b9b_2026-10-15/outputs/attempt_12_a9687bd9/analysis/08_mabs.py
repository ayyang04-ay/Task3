import sys; sys.path.insert(0,'/tmp/outputs/analysis')
from common import *
pd.set_option('display.width',250); pd.set_option('display.max_rows',500)
m=pd.read_csv(f'{DATA}/mab_binding_panels.csv')
m['donor']=m.mab_id.str.split('.').str[1]
both=m.groupby('mab_id').panel.nunique(); both=both[both>1].index
print('mAbs in both panels:',len(both)); print(m[m.mab_id.isin(both)].groupby(['arm','donor']).mab_id.nunique())
x=m[m.mab_id.isin(both)].pivot_table(index=['mab_id','arm'],columns='antigen',values='fold_over_control')
print(x.round(1).to_string())
w=m.pivot_table(index=['panel','arm','donor','mab_id'],columns='antigen',values='fold_over_control').reset_index()
w.to_csv('mab_wide.csv',index=False)
