import numpy as np
from scipy import stats
out=[]
def n_gmr(sd,gmr,power=0.9,alpha2=0.05):
    za=stats.norm.ppf(1-alpha2/2); zb=stats.norm.ppf(power)
    return int(np.ceil(2*(za+zb)**2*sd**2/np.log2(gmr)**2))
print('--- Study 1: neutralisation-breadth superiority, per-arm evaluable n (two comparisons, Bonferroni alpha 0.025 two-sided each, 90% power) ---')
for sd in [1.0,1.3]:
    for g in [1.5,1.3,1.25]:
        print(f'residual SD {sd} log2, target GMR {g}: n/arm = {n_gmr(sd,g,0.9,0.025)}')
# subgroup power
for n in [150,200]:
    for sd in [1.0,1.3]:
        se=sd*np.sqrt(2/(n/2)); pw=stats.norm.cdf(np.log2(1.5)/se-stats.norm.ppf(0.975))
        print(f'n/arm {n}: power within a 50% subgroup for GMR 1.5 (SD {sd}) = {pw:.2f}')
# HAI NI on SCR
def n_ni_prop(p,margin=0.10,power=0.9,alpha=0.025):
    za=stats.norm.ppf(1-alpha); zb=stats.norm.ppf(power)
    return int(np.ceil((za+zb)**2*2*p*(1-p)/margin**2))
for p in [0.15,0.3,0.5]: print(f'HAI SCR NI margin 10pp, true SCR {p}: n/arm = {n_ni_prop(p)}')
print('\n--- Study 2: CHIM, per-arm n, two-sided alpha 0.05, 80% power (Fisher/normal approx) ---')
def n_two_prop(p0,p1,power=0.8,alpha=0.05):
    za=stats.norm.ppf(1-alpha/2); zb=stats.norm.ppf(power); pb=(p0+p1)/2
    return int(np.ceil((za*np.sqrt(2*pb*(1-pb))+zb*np.sqrt(p0*(1-p0)+p1*(1-p1)))**2/(p0-p1)**2))
for p0,p1 in [(0.40,0.15),(0.40,0.20),(0.30,0.12),(0.30,0.15)]:
    print(f'infection/illness {p0:.0%} vs {p1:.0%}: n/arm = {n_two_prop(p0,p1)}')
print('\n--- Study 3: events needed (1:1, conditional binomial), one-sided alpha 0.025, 90% power ---')
def events(rve_true,rve_null):
    th1=(1-rve_true)/(2-rve_true); th0=(1-rve_null)/(2-rve_null)
    za=stats.norm.ppf(0.975); zb=stats.norm.ppf(0.9)
    return int(np.ceil((za*np.sqrt(th0*(1-th0))+zb*np.sqrt(th1*(1-th1)))**2/(th0-th1)**2))
for rt in [0.15,0.20,0.25,0.30]:
    print(f'true rVE {rt:.0%}: events for superiority (H0 rVE<=0) = {events(rt,0.0)}; for NI (H0 rVE<=-10%) = {events(rt,-0.10)}')
for ev in [500,1000]:
    for ar in [0.01,0.02]:
        print(f'{ev} events at {ar:.0%} attack rate in the comparator arm (~{ar*(1-0.25/2):.3%} pooled) -> ~{int(ev/(ar*(1-0.125))):,} participant-seasons')
