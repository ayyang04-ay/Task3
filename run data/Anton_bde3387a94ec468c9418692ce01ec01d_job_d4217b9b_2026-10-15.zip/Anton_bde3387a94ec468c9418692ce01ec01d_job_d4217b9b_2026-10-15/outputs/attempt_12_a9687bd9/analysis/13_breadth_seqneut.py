import sys; sys.path.insert(0,'/tmp/outputs/analysis')
from common import *
pd.set_option('display.width',250)
w=pd.read_csv('seqneut_wide.csv')
out=[]
for name,mask in {'H1 contemporary 2023 WT (6)':w.cat=='H1_contemporary_2023','H3 contemporary 2022-24 WT (68)':w.cat=='H3_contemporary_2022-24'}.items():
    d=w[mask].dropna(subset=['d0','d29']).copy()
    d['r4']=(d.d29/d.d0)>=4
    pp=d.groupby(['arm','pid']).r4.mean().reset_index()
    for arm,g in pp.groupby('arm'):
        out.append(dict(panel=name,arm=arm,n=len(g),mean_pct_strains_4fold=100*g.r4.mean(),median=100*g.r4.median(),
            n_participants_4fold_on_majority=f'{(g.r4>0.5).sum()}/{len(g)}'))
    a=pp[pp.arm=='mRNA-1010'].r4; f=pp[pp.arm=='Fluarix'].r4
    out.append(dict(panel=name,arm='MW p',n=np.nan,mean_pct_strains_4fold=stats.mannwhitneyu(a,f).pvalue))
o=pd.DataFrame(out); print(o.round(3).to_string(index=False)); o.to_csv('seqneut_4fold_breadth.csv',index=False)
# baseline vs fold-rise relationship (antibody ceiling / feedback)
pp=pd.read_csv('seqneut_participant_panel_means.csv')
for grp in ['H1 contemporary 2023 (6 WT isolates)','H3 contemporary 2022-24 WT (68)']:
    d=pp[pp.group==grp]
    r=stats.spearmanr(d.l0,d.lfc); print(grp,'baseline log2 vs log2 fold-rise: Spearman rho=%.2f p=%.3f'%(r.correlation,r.pvalue))
# Individual participants: show d0 / d29 mean titres per participant for H3 contemporary
d=pp[pp.group=='H3 contemporary 2022-24 WT (68)'].copy(); d['GMT0']=2**d.l0; d['GMT29']=2**d.l29; d['GMFR']=2**d.lfc
print(d[['arm','pid','GMT0','GMT29','GMFR']].sort_values(['arm','pid']).round(0).to_string(index=False))
