import sys; sys.path.insert(0,'/tmp/outputs/analysis')
from common import *
pd.set_option('display.width',250)
w=pd.read_csv('seqneut_wide.csv')
pairs=[('A/Texas/50/2012X-223A_H3N2','A/Texas/50/2012_H3N2'),
       ('A/Switzerland/9715293/2013NIB-88_H3N2','A/Switzerland/9715293/2013_H3N2'),
       ('A/HongKong/4801/2014egg_H3N2','A/HongKong/4801/2014_H3N2'),
       ('A/Singapore/INFIMH-16-0019/2016X-307A_H3N2','A/Singapore/INFIMH-16-0019/2016_H3N2'),
       ('A/Cambodia/e0826360/2020egg_H3N2','A/Cambodia/e0826360/2020_H3N2'),
       ('A/Darwin/9/2021_H3N2','A/Darwin/6/2021_H3N2'),
       ('A/Victoria/4897/2022_IVR-238_H1N1','A/Wisconsin/67/2022_H1N1')]
rows=[]
for egg,wt in pairs:
    e=w[w.virus==egg].set_index(['arm','pid']); t=w[w.virus==wt].set_index(['arm','pid'])
    j=e[['d0','d29']].join(t[['d0','d29']],lsuffix='_egg',rsuffix='_wt').dropna()
    j['r0']=np.log2(j.d0_egg/j.d0_wt); j['r29']=np.log2(j.d29_egg/j.d29_wt); j['dr']=j.r29-j.r0
    for arm in ['mRNA-1010','Fluarix']:
        jj=j.loc[arm]
        rows.append(dict(pair=f'{egg.split("_")[0]} vs {wt.split("_")[0]}',arm=arm,n=len(jj),
            egg_over_wt_d0=2**jj.r0.mean(),egg_over_wt_d29=2**jj.r29.mean(),change_in_ratio=2**jj.dr.mean(),
            p_change=stats.ttest_1samp(jj.dr,0).pvalue))
    a=j.loc['mRNA-1010'].dr; f=j.loc['Fluarix'].dr
    rows.append(dict(pair='  -> arm difference in change of egg/WT ratio (Flu minus mRNA, fold)',arm='',n=np.nan,egg_over_wt_d0=np.nan,egg_over_wt_d29=np.nan,change_in_ratio=2**(f.mean()-a.mean()),p_change=stats.ttest_ind(f,a,equal_var=False).pvalue))
r=pd.DataFrame(rows); print(r.round(3).to_string(index=False)); r.to_csv('egg_vs_wt_pairs.csv',index=False)
