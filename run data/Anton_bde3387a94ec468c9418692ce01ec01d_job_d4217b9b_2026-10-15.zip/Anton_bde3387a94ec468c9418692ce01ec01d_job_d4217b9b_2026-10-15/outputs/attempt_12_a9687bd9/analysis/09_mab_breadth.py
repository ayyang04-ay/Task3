import sys; sys.path.insert(0,'/tmp/outputs/analysis')
from common import *
pd.set_option('display.width',280); pd.set_option('display.max_rows',500); pd.set_option('display.max_columns',50)
m=pd.read_csv(f'{DATA}/mab_binding_panels.csv'); m['donor']=m.mab_id.str.split('.').str[1]
m=m[m.antigen!='SARS-CoV-2 RBD']
order={'group_I':['A/Victoria/4897/2022','A/Wisconsin/588/2019','A/Netherlands/01317/2025','A/California/04/2009','A/New Caledonia/20/1999','A/Puerto Rico/8/1934','A/Hubei/1/2010 (H5)'],
       'group_II':['A/Darwin/6/2021','A/Thailand/8/2022','A/Croatia/10136RV/2023','A/Texas/50/2012','A/Fujian/411/2002','A/Hong Kong/1/1968','A/Shanghai/1/2013 (H7)']}
out=[]
for thr in [3,5,10]:
    m['bind']=m.fold_over_control>=thr
    for p in ['group_I','group_II']:
        d=m[m.panel==p]
        t=d.pivot_table(index=['arm','donor','mab_id'],columns='antigen',values='bind').reset_index()
        # donor level
        dl=t.groupby(['arm','donor'])[order[p]].mean().mul(100).round(0)
        dl.insert(0,'n_mAbs',t.groupby(['arm','donor']).size())
        al=t.groupby(['arm'])[order[p]].mean().mul(100).round(0); al.insert(0,'n_mAbs',t.groupby('arm').size())
        if thr==5:
            print(f'\n== {p}, threshold >= {thr}x: % of mAbs binding (donor level) =='); print(dl.to_string())
            print('pooled by arm:'); print(al.to_string())
        for arm in ['mRNA-1010','Fluarix']:
            for ag in order[p]:
                dd=t[t.arm==arm].groupby('donor')[ag].mean()
                out.append(dict(threshold=thr,panel=p,arm=arm,antigen=ag,pooled_pct=100*t[t.arm==arm][ag].mean(),donor_mean_pct=100*dd.mean(),donor_min=100*dd.min(),donor_max=100*dd.max()))
o=pd.DataFrame(out); o.to_csv('mab_binding_pct_by_arm_threshold.csv',index=False)
print('\nDonor-averaged % binding, thresholds 3/5/10:')
print(o.pivot_table(index=['panel','antigen'],columns=['threshold','arm'],values='donor_mean_pct').round(0).to_string())
