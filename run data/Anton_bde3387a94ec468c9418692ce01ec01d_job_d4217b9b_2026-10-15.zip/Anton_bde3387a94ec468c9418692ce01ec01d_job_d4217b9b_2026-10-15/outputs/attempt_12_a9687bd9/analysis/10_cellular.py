import sys; sys.path.insert(0,'/tmp/outputs/analysis')
from common import *
pd.set_option('display.width',250); pd.set_option('display.max_rows',500)
g=pd.read_csv(f'{DATA}/gc_frequencies.csv',dtype={'participant':str})
g['pid']=g.participant.map(pid)
# detect the two blocks
g['block']=(g.index>=g[(g.timepoint=='wk0')&(g.pid==1)].index[1]).astype(int)+1 if len(g[(g.timepoint=='wk0')&(g.pid==1)])>1 else 1
print('rows per block:',g.block.value_counts().to_dict())
print('block boundary row index:', g[(g.timepoint=='wk0')&(g.pid==1)].index.tolist())
for b,gb in g.groupby('block'):
    print(f'\n-- GC block {b}: median (IQR) % HA-specific IgG GC, n --')
    s=gb.groupby(['timepoint','arm']).pct_ha_specific_igg_gc.agg(['count','median',lambda x:x.quantile(.25),lambda x:x.quantile(.75),'max'])
    s.columns=['n','median','q1','q3','max']
    print(s.round(2).to_string())
    for tp in ['wk2','wk8','wk17','wk26']:
        d=gb[gb.timepoint==tp]
        a=d[d.arm=='mRNA-1010'].pct_ha_specific_igg_gc; f=d[d.arm=='Fluarix'].pct_ha_specific_igg_gc
        print(tp,'MW p=%.3f'%stats.mannwhitneyu(a,f).pvalue, f'n={len(a)}/{len(f)}')
g.to_csv('gc_with_block_label.csv',index=False)
# plasmablasts
p=pd.read_csv(f'{DATA}/plasmablast_frequencies.csv',dtype={'participant':str}); p['pid']=p.participant.map(pid)
fna={1,5,9,11,18,20,22,24,26,27,32,6,17,21,28,29,30}
p['in_FNA_subset']=p.pid.isin(fna)
def ndec(x):
    s=repr(float(x)); return len(s.split('.')[1]) if '.' in s else 0
p['sig']=p.pct_plasmablast.map(lambda v: len(('%g'%v).replace('0.','').lstrip('0')) if v>0 else 0)
print('\nPB participants not in the documented FNA subset:', sorted(set(p.pid)-fna))
print('precision (significant digits of non-zero values) by FNA-subset membership:')
print(p[p.pct_plasmablast>0].groupby('in_FNA_subset').sig.describe())
s=p.groupby(['timepoint','arm']).pct_plasmablast.agg(['count','median','max'])
print(s.round(3).to_string())
for tp in ['wk2','wk8','wk17','wk26']:
    d=p[p.timepoint==tp]; a=d[d.arm=='mRNA-1010'].pct_plasmablast; f=d[d.arm=='Fluarix'].pct_plasmablast
    print(tp,'MW p=%.3f'%stats.mannwhitneyu(a,f).pvalue)
