import pandas as pd, numpy as np
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
r=pd.read_csv('seqneut_per_virus.csv')
w=pd.read_csv('seqneut_wide.csv')[['virus','subtype']].drop_duplicates()
r=r.merge(w,on='virus')
cmap={'H1_contemporary_2023':'tab:green','H1_historical':'lightgreen','H1_vaccine-like_mRNA(5a.2a.1)':'darkgreen','H1_vaccine-like_Fluarix(5a.2)':'olive',
      'H3_contemporary_2022-24':'tab:orange','H3_historical':'navajowhite','H3_mRNA_vaccine_strain(cell)':'red','H3_Fluarix_vaccine_strain(egg-based CVV)':'darkred','egg_reassortant':'grey'}
fig,axes=plt.subplots(1,2,figsize=(13,5),sharey=True)
for ax,col,title in [(axes[0],'baseline_GMR','Baseline (d0) GMT ratio'),(axes[1],'ANCOVA_GMR','Day-29 GMT ratio adjusted for baseline')]:
    for i,(c,g) in enumerate(r.groupby('cat')):
        x=np.random.default_rng(1).normal(0,0.06,len(g))+np.where(g.subtype.values=='H1N1',0,1)
        ax.scatter(x+(0.25 if c=='egg_reassortant' else 0),g[col],c=cmap[c],s=22,label=c,edgecolor='k',lw=0.3)
    ax.axhline(1,color='k',lw=0.8); ax.set_yscale('log',base=2); ax.set_xticks([0,1]); ax.set_xticklabels(['H1N1 viruses','H3N2 viruses'])
    ax.set_title(title,fontsize=10); ax.set_ylabel('mRNA-1010 / Fluarix')
axes[1].legend(fontsize=7,loc='upper left',bbox_to_anchor=(1.01,1))
fig.suptitle('Sequencing-based neutralisation, per virus (n=13 mRNA-1010, 14 Fluarix): mRNA arm starts lower on H3; adjusted H3 contrast ~1',fontsize=10)
plt.tight_layout(); plt.savefig('/tmp/outputs/seqneut_per_virus_contrasts.png',dpi=150)
print(r.groupby('cat')[['baseline_GMR','ANCOVA_GMR']].median().round(2))
