import sys; sys.path.insert(0,'/tmp/outputs/analysis')
from common import *
import statsmodels.formula.api as smf
h=pd.read_csv(f'{DATA}/hai_titers.csv',dtype={'participant':str}); h['pid']=h.participant.map(pid)
w=h.pivot_table(index=['antigen','arm','pid'],columns='timepoint',values='hai_titer').reset_index()
w['late']=w[['wk17','wk26']].max(axis=1)
rows=[]
for ag,d in w.groupby('antigen'):
    d=d.dropna(subset=['wk0','late']).copy(); d['l0']=np.log2(d.wk0); d['l1']=np.log2(d.late); d['m']=(d.arm=='mRNA-1010').astype(int)
    fit=smf.ols('l1~m+l0',data=d).fit(); ci=2**fit.conf_int().loc['m'].values
    a=d[d.m==1]; f=d[d.m==0]
    sp_a=(a.late>=40).mean(); sp_f=(f.late>=40).mean()
    rows.append(dict(antigen=ag,n=f'{len(a)}/{len(f)}',GMT_late=f'{gmt(a.late):.1f} vs {gmt(f.late):.1f}',ANCOVA_GMR=f'{2**fit.params["m"]:.2f} ({ci[0]:.2f}-{ci[1]:.2f}) p={fit.pvalues["m"]:.2f}',
        pct_ge40_late=f'{100*sp_a:.0f}% vs {100*sp_f:.0f}%'))
r=pd.DataFrame(rows); print(r.to_string(index=False)); r.to_csv('hai_late.csv',index=False)
