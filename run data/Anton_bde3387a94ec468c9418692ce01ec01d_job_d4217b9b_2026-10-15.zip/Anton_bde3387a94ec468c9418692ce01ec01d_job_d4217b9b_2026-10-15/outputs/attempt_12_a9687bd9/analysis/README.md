# Analysis scripts (run with: micromamba run -n core python <script>)
Input: /tmp/world/filesystem/*.csv.  All outputs are written to this folder unless noted.

| Script | What it does | Main outputs |
|---|---|---|
| common.py | helpers: ID normalisation, GMT, GMR with Welch CI, Wilson/Newcombe CIs | – |
| 01_hai.py | HAI GMT/GMFR/seroconversion; arm contrasts incl. baseline-adjusted ANCOVA | hai_summary.csv, hai_arm_comparison.csv |
| 02_mn.py | Microneutralisation summaries, ceiling counts, check of provided fold-changes, contrasts | mn_summary.csv, mn_arm_comparison.csv |
| 03_elisa.py | ELISA IgG EC50 summaries, durability, contrasts | elisa_summary.csv, elisa_arm_comparison.csv |
| 04_igm.py | IgM fold-change summaries | igm_summary.csv |
| 05_breadth.py | Bead-array binding breadth (H1, H3) by strain and per participant | breadth_h1_by_strain.csv, breadth_h3_by_strain.csv, breadth_per_participant.csv |
| 06_seqneut.py | Sequencing-based neutralisation: virus annotation (subtype, year, egg/WT, category), per-virus contrasts | seqneut_annotated.csv, seqneut_wide.csv, seqneut_per_virus.csv |
| 07_seqneut_participant.py | Participant-level panel means (avoids pseudo-replication across viruses), contrasts d29 and d121/181 | seqneut_by_panel_participant_level.csv, seqneut_participant_panel_means.csv |
| 08_mabs.py / 09_mab_breadth.py | mAb panel structure; % binding by antigen, donor and arm at 3/5/10x thresholds | mab_wide.csv, mab_binding_pct_by_arm_threshold.csv |
| 10_cellular.py | GC (two unlabelled blocks) and plasmablast frequencies; provenance checks | gc_with_block_label.csv |
| 11_repertoire.py | Serum IgG clonotypes, CDRH3 diversity, PB-GC clonal overlap | (printed) |
| 12_egg_pairs.py | Egg-reassortant vs wild-type titre ratios by arm, d0 and d29 | egg_vs_wt_pairs.csv |
| 13_breadth_seqneut.py | % of strains with >=4-fold rise per participant; baseline vs rise | seqneut_4fold_breadth.csv |
| 14_sample_size.py | Residual SDs from WU397, power of WU397, per-arm n for future GMR targets | sample_size_inputs.csv |
| 15_sensitivity.py | Censoring-rule sensitivity; binding-vs-neutralisation discordance | seqneut_censoring_sensitivity.csv, binding_vs_neutralisation.csv |
| 16_blocks_outliers.py | Enrolment-block heterogeneity (ID blocks), outlier participants | elisa_enrolment_block_heterogeneity.csv |
| 17_mn_sensitivity.py | MN contrasts excluding participant 397-014 | mn_sensitivity.csv |
| 18_forest.py | Forest plot of baseline-adjusted contrasts for all readouts | ../forest_arm_contrasts.png, forest_ancova_all_readouts.csv |
| 19_design_sizes.py | Sample-size/event calculations for the recommended studies | design_sizes.txt |
| 20_hai_late.py | HAI at wk17/26 | hai_late.csv |
| 21_pervirus_fig.py | Per-virus baseline and adjusted contrasts figure | ../seqneut_per_virus_contrasts.png |
| 23_mab_imprint_and_counts.py | mAb imprinting signature (older strain vs immunogen), unique mAb counts, IgM floor count, seq-neut censoring/missingness, lowest-titre viruses | mab_imprinting.csv, log_23_*.txt |
| 24_ledger.py | Builds the numbers ledger from the outputs above (run last) | ../numbers_ledger.csv |

log_*.txt files hold the printed output of each script.

Conventions: GMR = mRNA-1010 / Fluarix. "Adjusted" = ANCOVA of log2 post-vaccination titre on arm + log2 baseline titre.
p-values are unadjusted for multiplicity and are descriptive only (non-randomised study).
Censored seq-neut titres are set at the reported bound in the main analysis (two alternatives in 15_sensitivity.py).
