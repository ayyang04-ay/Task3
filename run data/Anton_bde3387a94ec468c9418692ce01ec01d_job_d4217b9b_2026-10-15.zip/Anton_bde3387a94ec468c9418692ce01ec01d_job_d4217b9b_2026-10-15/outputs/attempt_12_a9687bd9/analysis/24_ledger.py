import pandas as pd, numpy as np
L=[]
def add(id_,claim,value,source,method): L.append(dict(id=id_,quantity=claim,value=value,source_file=source,computed_by=method))
F='/tmp/world/filesystem/'
# HAI
hs=pd.read_csv('hai_summary.csv'); hc=pd.read_csv('hai_arm_comparison.csv'); hl=pd.read_csv('hai_late.csv')
for ag in ['A/H1N1','A/H3N2','B/Vic','B/Yam']:
    a=hs[(hs.antigen==ag)&(hs.arm=='mRNA-1010')].iloc[0]; f=hs[(hs.antigen==ag)&(hs.arm=='Fluarix')].iloc[0]
    add(f'HAI-{ag}-GMT',f'HAI {ag}: GMT d0 -> d29, mRNA-1010 vs Fluarix (n {a.n}/{f.n})',f'{a.GMT_wk0:.1f}->{a.GMT_wk4:.1f} vs {f.GMT_wk0:.1f}->{f.GMT_wk4:.1f}',F+'hai_titers.csv','01_hai.py -> hai_summary.csv')
    add(f'HAI-{ag}-GMFR',f'HAI {ag}: GMFR d29 and seroconversion (>=4x and >=1:40)',f'GMFR {a.GMFR_wk4:.2f} vs {f.GMFR_wk4:.2f}; SCR {a.SCR} vs {f.SCR}',F+'hai_titers.csv','01_hai.py -> hai_summary.csv')
    c=hc[hc.antigen==ag].iloc[0]
    add(f'HAI-{ag}-ANCOVA',f'HAI {ag}: d29 GMR mRNA/Fluarix adjusted for baseline (95% CI)',c.ANCOVA_wk4_GMR_adj,F+'hai_titers.csv','01_hai.py -> hai_arm_comparison.csv')
    l=hl[hl.antigen==ag].iloc[0]
    add(f'HAI-{ag}-late',f'HAI {ag}: wk17/26 GMT and adjusted GMR',f'{l.GMT_late}; {l.ANCOVA_GMR}',F+'hai_titers.csv','20_hai_late.py -> hai_late.csv')
# MN
ms=pd.read_csv('mn_summary.csv'); mc=pd.read_csv('mn_arm_comparison.csv'); mse=pd.read_csv('mn_sensitivity.csv')
for p in ['heterologous','homologous']:
    a=ms[(ms.panel==p)&(ms.arm=='mRNA-1010')].iloc[0]; f=ms[(ms.panel==p)&(ms.arm=='Fluarix')].iloc[0]
    add(f'MN-{p}-GMT',f'MN {p} panel: GMT d0 -> d29, mRNA vs Fluarix',f'{a.GMT0:.0f}->{a.GMT4:.0f} vs {f.GMT0:.0f}->{f.GMT4:.0f}; GMFR {a.GMFR4:.2f} vs {f.GMFR4:.2f}',F+'microneutralization.csv','02_mn.py -> mn_summary.csv')
    c=mc[mc.panel==p].iloc[0]
    add(f'MN-{p}-base',f'MN {p}: baseline GMR mRNA/Fluarix',c.baseline_GMR,F+'microneutralization.csv','02_mn.py -> mn_arm_comparison.csv')
    add(f'MN-{p}-ANCOVA',f'MN {p}: d29 GMR adjusted for baseline',c.ANCOVA,F+'microneutralization.csv','02_mn.py -> mn_arm_comparison.csv')
    add(f'MN-{p}-ceiling',f'MN {p}: participants at the 1:1280 assay ceiling at d29',f'{a.at_ceiling_wk4} mRNA vs {f.at_ceiling_wk4} Fluarix',F+'microneutralization.csv','02_mn.py -> mn_summary.csv')
    s=mse[(mse.panel==p)&(mse.set.str.startswith('excluding'))].iloc[0]
    add(f'MN-{p}-excl014',f'MN {p}: adjusted GMR excluding mRNA 397-014',s.ANCOVA,F+'microneutralization.csv','17_mn_sensitivity.py -> mn_sensitivity.csv')
# ELISA
es=pd.read_csv('elisa_summary.csv'); ec=pd.read_csv('elisa_arm_comparison.csv'); eb=pd.read_csv('elisa_enrolment_block_heterogeneity.csv')
for ag in ['A/H1','A/H3','B/Vic','B/Yam']:
    a=es[(es.antigen==ag)&(es.arm=='mRNA-1010')].iloc[0]; f=es[(es.antigen==ag)&(es.arm=='Fluarix')].iloc[0]
    add(f'ELISA-{ag}-GMFR',f'ELISA IgG {ag}: GMFR d29; % of d29 level retained at wk17/26 (n {a.n}/{f.n})',f'GMFR {a.GMFR4:.2f} vs {f.GMFR4:.2f}; retained {a.retained_pct:.0f}% vs {f.retained_pct:.0f}%',F+'elisa_igg_titers.csv','03_elisa.py -> elisa_summary.csv')
    c=ec[ec.antigen==ag].iloc[0]
    add(f'ELISA-{ag}-ANCOVA',f'ELISA IgG {ag}: d29 GMR adjusted for baseline; wk17/26 GMFR ratio',f'{c.ANCOVA_wk4}; late {c.GMFRlate_ratio}',F+'elisa_igg_titers.csv','03_elisa.py -> elisa_arm_comparison.csv')
for ag in ['B/Vic','B/Yam']:
    b=eb[(eb.antigen==ag)&(eb.arm=='Fluarix')].iloc[0]
    add(f'ELISA-block-{ag}',f'Fluarix arm, ELISA {ag} baseline GMT: IDs 1-32 vs IDs 33-59',f'{b.GMT0_early:.0f} vs {b.GMT0_late:.0f} (p={b.p_baseline:.3f})',F+'elisa_igg_titers.csv','16_blocks_outliers.py -> elisa_enrolment_block_heterogeneity.csv')
# IgM
ig=pd.read_csv('igm_summary.csv')
for ag in ['H1','H3','B/Vic','B/Yam']:
    a=ig[(ig.antigen==ag)&(ig.arm=='mRNA-1010')].iloc[0]; f=ig[(ig.antigen==ag)&(ig.arm=='Fluarix')].iloc[0]
    add(f'IgM-{ag}',f'IgM {ag}: GMFR mRNA vs Fluarix',f'{a.GMFR:.2f} vs {f.GMFR:.2f}',F+'igm_fold_change.csv','04_igm.py -> igm_summary.csv')
# Seq-neut panels
sp=pd.read_csv('seqneut_by_panel_participant_level.csv')
for _,r in sp.iterrows():
    add('SEQ-'+r.panel[:25],f'Seq-neut {r.panel}: GMT d0 / d29 mRNA vs Fluarix; GMFR',f"d0 {r['GMT d0 mRNA']:.0f} vs {r['GMT d0 Flu']:.0f}; d29 {r['GMT d29 mRNA']:.0f} vs {r['GMT d29 Flu']:.0f}; GMFR {r['GMFR d29 mRNA']:.2f} vs {r['GMFR d29 Flu']:.2f}",F+'neutralization_seqbased.csv','07_seqneut_participant.py -> seqneut_by_panel_participant_level.csv')
    add('SEQ-'+r.panel[:25]+'-GMR',f'Seq-neut {r.panel}: baseline GMR; unadjusted d29 GMR; baseline-adjusted d29 GMR; adjusted d121/181 GMR',f"base {r['baseline GMR (m/F)']}; d29 {r['d29 GMR (m/F)']}; adj d29 {r['ANCOVA d29 GMR adj. baseline']}; adj late {r['ANCOVA late GMR adj. baseline']}",F+'neutralization_seqbased.csv','07_seqneut_participant.py -> seqneut_by_panel_participant_level.csv')
b4=pd.read_csv('seqneut_4fold_breadth.csv')
for p in b4.panel.unique():
    a=b4[(b4.panel==p)&(b4.arm=='mRNA-1010')].iloc[0]; f=b4[(b4.panel==p)&(b4.arm=='Fluarix')].iloc[0]; pv=b4[(b4.panel==p)&(b4.arm=='MW p')].iloc[0]
    add('SEQ-4x-'+p[:10],f'{p}: mean % of strains with >=4-fold rise per participant',f'{a.mean_pct_strains_4fold:.0f}% vs {f.mean_pct_strains_4fold:.0f}% (MW p={pv.mean_pct_strains_4fold:.3f})',F+'neutralization_seqbased.csv','13_breadth_seqneut.py -> seqneut_4fold_breadth.csv')
eg=pd.read_csv('egg_vs_wt_pairs.csv')
rows=eg[eg.arm.isin(['mRNA-1010','Fluarix'])]
add('EGG-base','Baseline egg-reassortant / wild-type titre ratio, 5 historical H3 pairs (range across pairs and arms)',f'{rows[~rows.pair.str.contains("Darwin|Victoria")].egg_over_wt_d0.min():.2f}-{rows[~rows.pair.str.contains("Darwin|Victoria")].egg_over_wt_d0.max():.2f}x',F+'neutralization_seqbased.csv','12_egg_pairs.py -> egg_vs_wt_pairs.csv')
for key in ['HongKong/4801','Singapore']:
    pr=eg[eg.pair.str.contains(key)]
    a=pr[pr.arm=='mRNA-1010'].iloc[0]; f=pr[pr.arm=='Fluarix'].iloc[0]
    idx=eg.index[eg.pair.str.contains(key)][-1]+1; d=eg.loc[idx]
    add('EGG-'+key,f'{key} egg/WT ratio d0 -> d29 (mRNA; Fluarix); arm difference in change',f'{a.egg_over_wt_d0:.1f}->{a.egg_over_wt_d29:.1f}; {f.egg_over_wt_d0:.1f}->{f.egg_over_wt_d29:.1f}; diff {d.change_in_ratio:.2f}x p={d.p_change:.3f}',F+'neutralization_seqbased.csv','12_egg_pairs.py -> egg_vs_wt_pairs.csv')
pr=eg[eg.pair.str.contains('Victoria/4897')]
add('EGG-IVR238','A/Victoria/4897/2022 IVR-238 (egg) / A/Wisconsin/67/2022 (cell) titre ratio at d0 (mRNA; Fluarix)',f'{pr.iloc[0].egg_over_wt_d0:.1f}; {pr.iloc[1].egg_over_wt_d0:.1f}',F+'neutralization_seqbased.csv','12_egg_pairs.py -> egg_vs_wt_pairs.csv')
bn=pd.read_csv('binding_vs_neutralisation.csv')
x=bn[(bn.ELISA=='A/H3')&(bn.neut_panel.str.contains('Darwin'))]
add('BIND-NEUT-H3','H3: ELISA-IgG fold-rise / A/Darwin/6/2021 neutralisation fold-rise (mRNA; Fluarix)',f'{x.iloc[1].ratio_binding_to_neut_rise:.2f}; {x.iloc[0].ratio_binding_to_neut_rise:.2f} (p={x.iloc[2].ratio_binding_to_neut_rise:.1e})',F+'elisa_igg_titers.csv + neutralization_seqbased.csv','15_sensitivity.py -> binding_vs_neutralisation.csv')
cs=pd.read_csv('seqneut_censoring_sensitivity.csv')
for p in cs.panel.unique():
    add('SEQ-cens-'+p[:8],f'{p}: adjusted GMR under 3 censoring rules',' / '.join(cs[cs.panel==p].ANCOVA_GMR),F+'neutralization_seqbased.csv','15_sensitivity.py -> seqneut_censoring_sensitivity.csv')
# bead array
bh=pd.read_csv('breadth_h3_by_strain.csv'); b1=pd.read_csv('breadth_h1_by_strain.csv')
for df,s in [(bh,'A/Hong Kong/1/1968'),(bh,'A/Darwin/6/2021'),(bh,'A/Thailand/8/2022'),(b1,'A/Puerto Rico/8/1934'),(b1,'A/Wisconsin/67/2022')]:
    r=df[df.strain==s].iloc[0]
    add('BEAD-'+s,f'Bead-array mean log2 fold-change MFI, {s}: mRNA vs Fluarix',f'{r.mRNA_mean_log2FC:.2f} vs {r.Flu_mean_log2FC:.2f} (Welch p={r.welch_p:.1e})',F+'binding_breadth_h1.csv / binding_breadth_h3.csv','05_breadth.py -> breadth_h*_by_strain.csv')
# mAbs
mb=pd.read_csv('mab_binding_pct_by_arm_threshold.csv'); mb=mb[mb.threshold==5]
for ag in ['A/Hong Kong/1/1968','A/Croatia/10136RV/2023','A/Darwin/6/2021','A/Shanghai/1/2013 (H7)','A/Hubei/1/2010 (H5)','A/Netherlands/01317/2025']:
    a=mb[(mb.antigen==ag)&(mb.arm=='mRNA-1010')].iloc[0]; f=mb[(mb.antigen==ag)&(mb.arm=='Fluarix')].iloc[0]
    add('MAB-'+ag,f'mAbs binding {ag} at >=5x control, donor-averaged %',f'{a.donor_mean_pct:.0f}% vs {f.donor_mean_pct:.0f}%',F+'mab_binding_panels.csv','09_mab_breadth.py -> mab_binding_pct_by_arm_threshold.csv')
add('MAB-n','Unique mAbs per arm; share of Fluarix mAbs from donor 397-05','589 (4 donors) vs 106 (3 donors); 84/106 = 79%',F+'mab_binding_panels.csv','23_mab_imprint_and_counts.py')
mi=pd.read_csv('mab_imprinting.csv'); r=mi[(mi.panel=='group_I')&(mi.arm=='mRNA-1010')].iloc[0]
add('MAB-imprint','Group-1 mRNA-arm mAbs with higher binding to A/Wisconsin/588/2019 than to immunogen A/Victoria/4897/2022; median log2 ratio',f'{r.pct_bind_older_more:.0f}%; {r.median_log2_ratio:.2f}',F+'mab_binding_panels.csv','23_mab_imprint_and_counts.py -> mab_imprinting.csv')
add('IgM-floor','IgM fold-change values exactly 1.0; values below 1','61 of 116; 0',F+'igm_fold_change.csv','23_mab_imprint_and_counts.py')
add('SEQ-censor','Seq-neut censored values (upper-bound <=40; lower-bound) and missing serum x virus cells; d0 upper-bound by arm','171; 70; 57 missing; d0 85 mRNA vs 47 Fluarix',F+'neutralization_seqbased.csv','23_mab_imprint_and_counts.py')
add('SEQ-lowest','Lowest median-titre contemporary H3 viruses (all sera)','BritishColumbia/RV00920/2023 62; Lisboa/124/2024 68; Shaanxi-Yuyang/1204/2024 69; DistrictOfColumbia/27/2023 83',F+'neutralization_seqbased.csv','23_mab_imprint_and_counts.py')
add('OUT-014','mRNA 397-014: MN titre range; HAI H1N1 d0->d29; ELISA H1 d0->d29','MN 10-15 all visits; HAI 57->320; ELISA 908->32,602',F+'microneutralization.csv, hai_titers.csv, elisa_igg_titers.csv','16_blocks_outliers.py')
add('IgM-005','IgM fold-change, Fluarix donor 397-05, all four antigens','166-212x',F+'igm_fold_change.csv','04_igm.py')
add('SIZE-S1','Study 1 evaluable n/arm: GMR 1.5 / 1.25, residual SD 1.0-1.3, two comparisons, 90% power','73-123 / 240-405','derived','19_design_sizes.py -> design_sizes.txt')
add('SIZE-HAI','HAI SCR non-inferiority n/arm (10 pp margin; SCR 15-50%)','268-526','derived','19_design_sizes.py')
add('SIZE-S2','Study 2 n/arm: 40%->15%; 30%->12% (80% power)','49; 80','derived','19_design_sizes.py')
add('SIZE-S3','Study 3 cases for superiority at true rVE 25% / 20% (90% power)','511 / 847','derived','19_design_sizes.py')
# GC / repertoire
add('GC-wk2','HA-specific IgG GC B cells, wk2 median (block 1 of gc file), mRNA vs Fluarix (n 6/11)','24.2% vs 2.3% (MW p=0.037)',F+'gc_frequencies.csv','10_cellular.py')
add('GC-wk26','Same, wk26 (n 5/8)','18.9% vs 1.6% (MW p=0.34)',F+'gc_frequencies.csv','10_cellular.py')
add('OVL','GC clones overlapping wk1 plasmablast clones, mRNA donors 06/17/28/29','92%, 91%, 83%, 73%',F+'pb_gc_clonal_overlap.csv','read directly')
add('REP-vacc','Vaccine-elicited serum IgG clonotypes, median (n 8/8)','32 vs 17.5 (MW p=0.066)',F+'repertoire_clonotype_counts.csv','11_repertoire.py')
add('REP-pre','Share of serum IgG abundance from pre-existing clonotypes, median','87% vs 89% (MW p=0.72)',F+'repertoire_clonotype_counts.csv','11_repertoire.py')
add('CDRH3','CDRH3 diversity index wk4 median','70.8 vs 24.5 (MW p=0.010)',F+'cdrh3_diversity_index.csv','11_repertoire.py')
# power
ss=pd.read_csv('sample_size_inputs.csv')
for g in ['seq-neut H3 contemporary 2022-24 WT (68)','seq-neut H1 contemporary 2023 (6 WT isolates)']:
    r=ss[ss.readout==g].iloc[0]
    add('SD-'+g[9:20],f'{g}: residual SD of log2 d29 titre after baseline adjustment',f'{r.residual_SD_ANCOVA:.2f}',F+'neutralization_seqbased.csv','14_sample_size.py -> sample_size_inputs.csv')
add('POWER','Power of WU397 (13 vs 14) to detect a 1.5x / 2x adjusted GMR, H3 and H1 contemporary panels','H3 32%/72%; H1 37%/79%',F+'neutralization_seqbased.csv','14_sample_size.py')
led=pd.DataFrame(L); led.to_csv('/tmp/outputs/numbers_ledger.csv',index=False)
print(len(led)); print(led.to_string(index=False)[:6000])
