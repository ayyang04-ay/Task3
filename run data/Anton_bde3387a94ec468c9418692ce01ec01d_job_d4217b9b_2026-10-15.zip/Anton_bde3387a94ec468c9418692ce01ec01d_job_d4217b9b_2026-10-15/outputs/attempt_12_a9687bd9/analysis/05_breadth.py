import sys; sys.path.insert(0,'/tmp/outputs/analysis')
from common import *
pd.set_option('display.width',250)
yr=lambda s:int(re.search(r'/(\d{4})$',s).group(1))
allr=[]
for sub in ['h1','h3']:
    b=pd.read_csv(f'{DATA}/binding_breadth_{sub}.csv'); b['pid']=b.participant.map(pid); b['sub']=sub.upper()
    allr.append(b)
    rows=[]
    for s,g in b.groupby('strain'):
        a=g[g.arm=='mRNA-1010'].log2_fold_change_mfi; f=g[g.arm=='Fluarix'].log2_fold_change_mfi
        tt=stats.ttest_ind(a,f,equal_var=False); mw=stats.mannwhitneyu(a,f)
        rows.append(dict(strain=s,year=yr(s),mRNA_mean_log2FC=a.mean(),Flu_mean_log2FC=f.mean(),diff=a.mean()-f.mean(),
            ci_lo=(a.mean()-f.mean())-stats.t.ppf(.975,tt.df)*np.sqrt(a.var()/len(a)+f.var()/len(f)),
            ci_hi=(a.mean()-f.mean())+stats.t.ppf(.975,tt.df)*np.sqrt(a.var()/len(a)+f.var()/len(f)),
            welch_p=tt.pvalue,mw_p=mw.pvalue,n_m=len(a),n_f=len(f)))
    r=pd.DataFrame(rows).sort_values('year')
    print(sub.upper()); print(r.round(3).to_string(index=False)); r.to_csv(f'breadth_{sub}_by_strain.csv',index=False)
b=pd.concat(allr)
# per-participant breadth: mean log2FC across non-vaccine-like strains, count of strains with >=2-fold (log2>=1) rise
b['yr']=b.strain.map(yr)
b['is_vaccine_like']=b.strain.isin(['A/Wisconsin/67/2022','A/Darwin/6/2021'])
pp=b.groupby(['sub','arm','pid']).apply(lambda g: pd.Series(dict(
    mean_all=g.log2_fold_change_mfi.mean(),
    mean_nonvacc=g[~g.is_vaccine_like].log2_fold_change_mfi.mean(),
    mean_pre2009=g[g.yr<2009].log2_fold_change_mfi.mean() if (g.yr<2009).any() else np.nan,
    n_2fold=(g.log2_fold_change_mfi>=1).sum(), n_strains=len(g))),include_groups=False).reset_index()
for sub,g in pp.groupby('sub'):
    a=g[g.arm=='mRNA-1010']; f=g[g.arm=='Fluarix']
    for col in ['mean_all','mean_nonvacc','n_2fold']:
        print(sub,col,'mRNA %.2f vs Flu %.2f, MW p=%.3f, Welch p=%.3f'%(a[col].mean(),f[col].mean(),stats.mannwhitneyu(a[col],f[col]).pvalue,stats.ttest_ind(a[col],f[col],equal_var=False).pvalue))
pp.to_csv('breadth_per_participant.csv',index=False)
