import sys; sys.path.insert(0,'/tmp/outputs/analysis')
from common import *
pd.set_option('display.width',250)
e=pd.read_csv(f'{DATA}/elisa_igg_titers.csv'); e=e[e.measure=='ec50']
t=e.pivot_table(index=['antigen','arm','participant'],columns='timepoint',values='value').reset_index()
t['block']=np.where(t.participant<=32,'IDs 1-32 (interleaved)', np.where(t.arm=='Fluarix','IDs 33-59 (Fluarix only)','IDs 64-102 (mRNA only)'))
t['lfc']=np.log2(t.wk4/t.wk0)
rows=[]
for (ag,arm),g in t.groupby(['antigen','arm']):
    a=g[g.participant<=32]; b=g[g.participant>32]
    rows.append(dict(antigen=ag,arm=arm,n_early=len(a),n_late=len(b),GMT0_early=gmt(a.wk0),GMT0_late=gmt(b.wk0),p_baseline=gmr_ci(a.wk0,b.wk0)[3],
        GMFR_early=2**a.lfc.mean(),GMFR_late=2**b.lfc.mean(),p_GMFR=stats.ttest_ind(a.lfc,b.lfc,equal_var=False).pvalue))
r=pd.DataFrame(rows); print(r.round(3).to_string(index=False)); r.to_csv('elisa_enrolment_block_heterogeneity.csv',index=False)
# outlier 014 across assays
h=pd.read_csv(f'{DATA}/hai_titers.csv',dtype={'participant':str}); h['pid']=h.participant.map(pid)
print('\nParticipant mRNA 397-014:')
print('HAI:'); print(h[h.pid==14].pivot_table(index='antigen',columns='timepoint',values='hai_titer'))
print('ELISA:'); print(t[t.participant==14][['antigen','wk0','wk4','wk26']])
m=pd.read_csv(f'{DATA}/microneutralization.csv'); m['pid']=m.participant.map(pid)
print('MN:'); print(m[(m.pid==14)&(m.measure=='titer')].pivot_table(index='panel',columns='timepoint',values='value'))
# Fluarix 005 (dominant Fluarix mAb donor; IgM >160x on all antigens)
print('\nParticipant Fluarix 397-005:')
print(h[h.pid==5].pivot_table(index='antigen',columns='timepoint',values='hai_titer'))
print(t[t.participant==5][['antigen','wk0','wk4','wk26']])
