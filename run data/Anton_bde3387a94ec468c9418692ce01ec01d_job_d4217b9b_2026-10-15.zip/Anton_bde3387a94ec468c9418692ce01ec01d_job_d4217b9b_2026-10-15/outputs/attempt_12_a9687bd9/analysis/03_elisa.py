import sys; sys.path.insert(0,'/tmp/outputs/analysis')
from common import *
import statsmodels.formula.api as smf
e=pd.read_csv(f'{DATA}/elisa_igg_titers.csv'); e['pid']=e.participant.astype(int)
t=e[e.measure=='ec50'].pivot_table(index=['antigen','arm','pid'],columns='timepoint',values='value').reset_index()
fc=e[e.measure=='fold_change'].pivot_table(index=['antigen','arm','pid'],columns='timepoint',values='value').reset_index()
t['late']=t[['wk17','wk26']].max(axis=1)
x=t.merge(fc,on=['antigen','arm','pid'],suffixes=('','_fc'))
x['c4']=x.wk4/x.wk0; x['clate']=x.late/x.wk0
print('FC mismatches wk4:', (abs(np.log(x.c4/x['wk4_fc']))>0.02).sum(), ' late:', (abs(np.log(x.clate/x['wk17/26']))>0.02).sum(), ' late FC present but no late titre:', (x['wk17/26'].notna()&x.late.isna()).sum())
print(x[(abs(np.log(x.clate/x['wk17/26']))>0.02)|(x['wk17/26'].notna()&x.late.isna())][['antigen','arm','pid','wk0','wk4','late','wk4_fc','wk17/26']].head(40).to_string())
pd.set_option('display.width',250)
rows=[]
for (ag,arm),g in t.groupby(['antigen','arm']):
    g4=g.dropna(subset=['wk0','wk4']); gl=g.dropna(subset=['wk0','late'])
    rows.append(dict(antigen=ag,arm=arm,n=len(g4),GMT0=gmt(g4.wk0),GMT4=gmt(g4.wk4),GMFR4=gmt(g4.wk4/g4.wk0),
        n_late=len(gl),GMTlate=gmt(gl.late),GMFRlate=gmt(gl.late/gl.wk0), retained_pct=100*gmt(gl.late/gl.wk4) if 'wk4' in gl else np.nan))
r=pd.DataFrame(rows); print(r.round(2).to_string(index=False)); r.to_csv('elisa_summary.csv',index=False)
out=[]
for ag,g in t.groupby('antigen'):
    g=g.dropna(subset=['wk0','wk4']).copy()
    a=g[g.arm=='mRNA-1010']; f=g[g.arm=='Fluarix']
    b=gmr_ci(a.wk0,f.wk0); p4=gmr_ci(a.wk4,f.wk4); fr=gmr_ci(a.wk4/a.wk0,f.wk4/f.wk0)
    g['l0']=np.log2(g.wk0); g['l4']=np.log2(g.wk4); g['m']=(g.arm=='mRNA-1010').astype(int)
    fit=smf.ols('l4~m+l0',data=g).fit(); ci=2**fit.conf_int().loc['m'].values
    gl=g.dropna(subset=['late']); al=gl[gl.arm=='mRNA-1010']; fl=gl[gl.arm=='Fluarix']
    frl=gmr_ci(al.late/al.wk0, fl.late/fl.wk0)
    out.append(dict(antigen=ag,baseline_GMR=f'{b[0]:.2f} ({b[1]:.2f}-{b[2]:.2f}) p={b[3]:.3f}',wk4_GMR=f'{p4[0]:.2f} ({p4[1]:.2f}-{p4[2]:.2f}) p={p4[3]:.1e}',
        GMFR4_ratio=f'{fr[0]:.2f} ({fr[1]:.2f}-{fr[2]:.2f}) p={fr[3]:.1e}',ANCOVA_wk4=f'{2**fit.params["m"]:.2f} ({ci[0]:.2f}-{ci[1]:.2f}) p={fit.pvalues["m"]:.1e}',
        GMFRlate_ratio=f'{frl[0]:.2f} ({frl[1]:.2f}-{frl[2]:.2f}) p={frl[3]:.1e}'))
o=pd.DataFrame(out); print(o.to_string(index=False)); o.to_csv('elisa_arm_comparison.csv',index=False)
# subset restricted to the 29 participants with HAI/MN data vs extra participants
core={1,2,5,7,9,11,16,18,19,20,22,24,26,27,32,3,6,8,10,14,15,17,21,23,25,28,29,30,31}
t['core']=t.pid.isin(core)
print('\nGMFR wk4 by core (HAI/MN cohort) vs extra participants:')
print(t.dropna(subset=['wk0','wk4']).groupby(['antigen','arm','core']).apply(lambda g: pd.Series(dict(n=len(g),GMT0=gmt(g.wk0),GMFR=gmt(g.wk4/g.wk0))),include_groups=False).round(2))
