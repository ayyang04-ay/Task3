import sys; sys.path.insert(0,'/tmp/outputs/analysis')
from common import *
import statsmodels.formula.api as smf
pd.set_option('display.width',250)
za=stats.norm.ppf(0.975)
def n_gmr(sd,gmr,power=0.9,alpha=0.05):
    zb=stats.norm.ppf(power); za=stats.norm.ppf(1-alpha/2)
    return int(np.ceil(2*(za+zb)**2*sd**2/np.log2(gmr)**2))
def n_ni_gmr(sd,margin=1.5,true=1.0,power=0.9,alpha=0.025):
    zb=stats.norm.ppf(power); za=stats.norm.ppf(1-alpha)
    return int(np.ceil(2*(za+zb)**2*sd**2/(np.log2(margin)-np.log2(true))**2))
rows=[]
# seq-neut participant-level
pp=pd.read_csv('seqneut_participant_panel_means.csv')
for grp,d in pp.groupby('group'):
    d=d.dropna(subset=['l0','l29']).copy(); d['m']=(d.arm=='mRNA-1010').astype(int)
    fit=smf.ols('l29~m+l0',data=d).fit(); rsd=np.sqrt(fit.mse_resid)
    sd29=np.sqrt(((d[d.m==1].l29.var()*(d.m.sum()-1))+(d[d.m==0].l29.var()*((1-d.m).sum()-1)))/(len(d)-2))
    rows.append(dict(readout='seq-neut '+grp,SD_log2_d29=sd29,residual_SD_ANCOVA=rsd,
        n_per_arm_GMR1_5_unadj=n_gmr(sd29,1.5),n_per_arm_GMR1_5_ANCOVA=n_gmr(rsd,1.5),n_per_arm_GMR1_25_ANCOVA=n_gmr(rsd,1.25),n_per_arm_GMR2_ANCOVA=n_gmr(rsd,2.0)))
# HAI
h=pd.read_csv(f'{DATA}/hai_titers.csv',dtype={'participant':str}); h['pid']=h.participant.map(pid)
w=h.pivot_table(index=['antigen','arm','pid'],columns='timepoint',values='hai_titer').reset_index()
for ag,d in w.groupby('antigen'):
    d=d.dropna(subset=['wk0','wk4']).copy(); d['l0']=np.log2(d.wk0); d['l4']=np.log2(d.wk4); d['m']=(d.arm=='mRNA-1010').astype(int)
    fit=smf.ols('l4~m+l0',data=d).fit(); rsd=np.sqrt(fit.mse_resid)
    sd4=np.sqrt(((d[d.m==1].l4.var()*(d.m.sum()-1))+(d[d.m==0].l4.var()*((1-d.m).sum()-1)))/(len(d)-2))
    rows.append(dict(readout='HAI '+ag,SD_log2_d29=sd4,residual_SD_ANCOVA=rsd,n_per_arm_GMR1_5_unadj=n_gmr(sd4,1.5),n_per_arm_GMR1_5_ANCOVA=n_gmr(rsd,1.5),n_per_arm_GMR1_25_ANCOVA=n_gmr(rsd,1.25),n_per_arm_GMR2_ANCOVA=n_gmr(rsd,2.0),
        n_per_arm_NI_margin1_5_unadj=n_ni_gmr(sd4)))
r=pd.DataFrame(rows); print(r.round(2).to_string(index=False)); r.to_csv('sample_size_inputs.csv',index=False)
# Seroconversion NI (margin 10%) with SCR from data: use pooled SCR
from math import ceil
def n_ni_prop(p1,p2,margin=0.10,power=0.9,alpha=0.025):
    zb=stats.norm.ppf(power); za=stats.norm.ppf(1-alpha)
    return ceil((za+zb)**2*(p1*(1-p1)+p2*(1-p2))/(margin-(p2-p1))**2) if margin>(p2-p1) else None
for p in [0.15,0.30,0.50]:
    print(f'SCR NI (margin 10%, equal true SCR {p:.0%}, 90% power, 1-sided 0.025): n/arm = {n_ni_prop(p,p)}')
# power of the current study to detect GMR 2 on H3 contemporary panel with n=13/14
for grp in ['H3 contemporary 2022-24 WT (68)','H1 contemporary 2023 (6 WT isolates)']:
    rsd=r[r.readout=='seq-neut '+grp].residual_SD_ANCOVA.iloc[0]
    for gm in [1.5,2.0]:
        se=rsd*np.sqrt(1/13+1/14); z=np.log2(gm)/se
        print(grp, f'power of current study (13 vs 14) for true GMR {gm}: {stats.norm.cdf(z-za):.2f}')
