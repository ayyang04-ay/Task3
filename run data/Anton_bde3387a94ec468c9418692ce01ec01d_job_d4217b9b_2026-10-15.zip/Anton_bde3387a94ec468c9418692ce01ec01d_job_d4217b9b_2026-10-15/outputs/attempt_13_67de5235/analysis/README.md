# WU397 re-analysis: files

Run the scripts in this order; each one is `micromamba run -n core python <script>`. They read `/tmp/world/filesystem` and write to `tables/` and `figures/`.

1. `wu397_analysis.py` covers:
   - cohort reconciliation and data-integrity flags;
   - HAI, microneutralisation (MN), ELISA and bead-array analyses;
   - sequencing-based neutralisation: virus classification, per-virus and participant-level composites, mixed model, pseudo-replication demonstration, egg vs wild-type comparison, H1 immunogen-identity check;
   - binding vs function;
   - mAbs analysed by donor;
   - cellular and repertoire files;
   - sample-size parameters;
   - figures 1–3.

   Writes `analysis_log.txt`.
2. `wu397_sensitivity.py` covers:
   - permutation tests (20,000) and alternative panel definitions for the key composites;
   - responder breadth;
   - HAI vs CBER benchmarks.

   Slow, about 13 minutes. Writes `sensitivity_log.txt`.
3. `wu397_sensitivity_outliers.py` — leave-one-out and median regression. Log: `outliers_log.txt`.
4. `wu397_breadth_index.py` — within-participant drift penalty ("broader" vs "more"). Log: `breadth_index_log.txt`.
5. `wu397_planning.py` — planning arithmetic for Studies A–C, with assumptions labelled. Log: `planning_log.txt`.

Conventions:
- Titres are analysed on the log2 scale.
- The unit of analysis is the participant for serology and the donor for mAbs.
- Panel strains are classified against both arms' vaccine strains (`tables/07_seqneut_virus_classification.csv`).
