#!/usr/bin/env python
"""
Sensitivity / robustness analyses for the key sequencing-based neutralisation
results (participant-level composites), complementing wu397_analysis.py.

Run: micromamba run -n core python wu397_sensitivity.py
"""
import os, re, io
import numpy as np, pandas as pd
from scipy import stats
import statsmodels.formula.api as smf

IN = "/tmp/world/filesystem"
TAB = "/tmp/outputs/analysis/tables"
LOG = io.StringIO()
def log(*a):
    s = " ".join(str(x) for x in a); print(s); LOG.write(s + "\n")
pd.set_option("display.width", 250); pd.set_option("display.max_columns", 40)

sn = pd.read_csv(f"{IN}/neutralization_seqbased.csv")
sn[["arm", "pidraw", "dstr"]] = sn.serum.str.split("_", expand=True)
sn["pid"] = sn.pidraw.str.replace("397-", "")
sn["day"] = sn.dstr.str[1:].astype(int)
sn["tp"] = sn.day.map({0: "d0", 29: "d29", 121: "late", 181: "late"})
vir = pd.read_csv(f"{TAB}/07_seqneut_virus_classification.csv")
sn = sn.merge(vir, on="virus")
sn["lt"] = np.log2(sn.titer)
W = sn.pivot_table(index=["arm", "pid", "virus", "subtype", "class_"], columns="tp", values="lt").reset_index()
W["m"] = (W.arm == "mRNA-1010").astype(int)
W["year"] = W.virus.str.extract(r"/(\d{4,6})(?:[A-Za-z\-0-9]*)?_")[0].str[-4:].astype(float)

def comp(df, label):
    pp = df.dropna(subset=["d0", "d29"]).groupby(["pid", "m"])[["d0", "d29"]].mean().reset_index()
    f = smf.ols("d29 ~ m + d0", pp).fit()
    b = f.params["m"]; lo, hi = f.conf_int().loc["m"]
    # permutation test on the ANCOVA arm coefficient
    rng = np.random.default_rng(397)
    obs = b; cnt = 0; B = 20000
    X = pp.copy()
    for _ in range(B):
        X["mp"] = rng.permutation(X.m.values)
        bb = smf.ols("d29 ~ mp + d0", X).fit().params["mp"]
        cnt += abs(bb) >= abs(obs) - 1e-12
    fc = pp.d29 - pp.d0
    return dict(analysis=label, n_viruses=df.virus.nunique(), n_mRNA=int((pp.m == 1).sum()), n_Fluarix=int((pp.m == 0).sum()),
                GMFR_mRNA=2 ** fc[pp.m == 1].mean(), GMFR_Fluarix=2 ** fc[pp.m == 0].mean(),
                adjGMR=2 ** b, lo=2 ** lo, hi=2 ** hi, p_ancova=f.pvalues["m"], p_permutation=(cnt + 1) / (B + 1))

rows = []
H3c = W[(W.subtype == "H3") & (W.class_ == "contemporary drifted isolate (2022-24)")]
H1c = W[(W.subtype == "H1") & (W.class_ == "contemporary drifted isolate (2022-24)")]
rows.append(comp(H3c, "H3 contemporary (primary, 68 strains)"))
rows.append(comp(H3c[~H3c.virus.isin(["A/Thailand/8/2022_H3N2", "A/Massachusetts/18/2022_H3N2"])], "H3 contemporary excl. later WHO references (Thailand/8/2022, Massachusetts/18/2022)"))
rows.append(comp(H3c[H3c.year >= 2023], "H3 isolates from 2023-2024 only"))
rows.append(comp(H3c[H3c.virus.isin(["A/DistrictOfColumbia/27/2023_H3N2"])], "H3 A/District of Columbia/27/2023 only (later 2025-26 cell-based reference)"))
rows.append(comp(H1c, "H1 contemporary (primary, 6 strains)"))
rows.append(comp(W[(W.subtype == "H1") & (W.virus.isin(["A/Wisconsin/588/2019_H1N1"]))], "H1 A/Wisconsin/588/2019 only (Fluarix-H1 counterpart)"))
rows.append(comp(W[(W.subtype == "H1") & (W.class_ == "historical wild-type")], "H1 historical (2009-2019)"))
rows.append(comp(W[(W.subtype == "H3") & (W.class_ == "historical wild-type")], "H3 historical wild-type (2012-2020)"))
res = pd.DataFrame(rows)
log(res.round(4).to_string(index=False))
res.round(4).to_csv(f"{TAB}/12_seqneut_sensitivity_permutation.csv", index=False)

# responder breadth: share of contemporary strains with >=4-fold rise at d29, per participant
rb = []
for sub, d in [("H3", H3c), ("H1", H1c)]:
    d = d.dropna(subset=["d0", "d29"]).copy()
    d["r4"] = (d.d29 - d.d0) >= 2 - 1e-9
    pp = d.groupby(["pid", "m"]).r4.mean().reset_index()
    a, b = pp[pp.m == 1].r4, pp[pp.m == 0].r4
    rb.append(dict(subtype=sub, metric="share of contemporary panel strains with >=4-fold d29 rise (per participant)",
                   median_mRNA=a.median(), median_Fluarix=b.median(), mean_mRNA=a.mean(), mean_Fluarix=b.mean(),
                   MWU_p=stats.mannwhitneyu(a, b).pvalue))
    pp.assign(subtype=sub).to_csv(f"{TAB}/12_responder_breadth_{sub}_participants.csv", index=False)
rb = pd.DataFrame(rb)
log(rb.round(4).to_string(index=False))
rb.round(4).to_csv(f"{TAB}/12_responder_breadth.csv", index=False)

# per-participant H1/H3 contemporary composite values (for transparency)
pp = []
for sub, d in [("H1", H1c), ("H3", H3c)]:
    q = d.groupby(["arm", "pid"])[["d0", "d29", "late"]].mean().reset_index()
    q["subtype"] = sub
    pp.append(q)
pp = pd.concat(pp)
for c in ["d0", "d29", "late"]:
    pp["GMT_" + c] = 2 ** pp[c]
pp["fold_d29"] = 2 ** (pp.d29 - pp.d0)
pp["fold_late"] = 2 ** (pp.late - pp.d0)
pp[["subtype", "arm", "pid", "GMT_d0", "GMT_d29", "GMT_late", "fold_d29", "fold_late"]].round(2).to_csv(f"{TAB}/12_participant_contemporary_composites.csv", index=False)
log(pp[["subtype", "arm", "pid", "GMT_d0", "GMT_d29", "GMT_late", "fold_d29", "fold_late"]].round(1).to_string(index=False))

# HAI: how far the observed SCR/SPR are from conventional benchmarks (external: FDA CBER 2007 guidance, adults <65:
#  lower 95% CI bound of SCR >= 40% and of SPR(HI>=40) >= 70%)
hai = pd.read_csv(f"{TAB}/03_hai_by_arm.csv")
hai["meets_SCR_LB40"] = hai.SCR_lo >= 0.40
def wilson_lo(k, n, z=1.96):
    p = k / n; den = 1 + z ** 2 / n; c = (p + z ** 2 / (2 * n)) / den; h = z * np.sqrt(p * (1 - p) / n + z ** 2 / (4 * n ** 2)) / den
    return c - h
hai["SPR_wk4_lo"] = [wilson_lo(k, n) for k, n in zip(hai.SPR_wk4_n, hai.n)]
hai["meets_SPR_LB70"] = hai.SPR_wk4_lo >= 0.70
log(hai[["antigen", "arm", "n", "SCR", "SCR_lo", "meets_SCR_LB40", "SPR_wk4", "SPR_wk4_lo", "meets_SPR_LB70"]].round(3).to_string(index=False))
hai[["antigen", "arm", "n", "SCR", "SCR_lo", "meets_SCR_LB40", "SPR_wk4", "SPR_wk4_lo", "meets_SPR_LB70"]].round(4).to_csv(f"{TAB}/12_hai_vs_cber_benchmarks.csv", index=False)

open("/tmp/outputs/analysis/sensitivity_log.txt", "w").write(LOG.getvalue())
