#!/usr/bin/env python
"""Influence of single participants on the participant-level contemporary-strain composites
(leave-one-out) + median regression. Run: micromamba run -n core python wu397_sensitivity_outliers.py"""
import numpy as np, pandas as pd
import statsmodels.formula.api as smf
TAB = "/tmp/outputs/analysis/tables"
pp = pd.read_csv(f"{TAB}/12_participant_contemporary_composites.csv", dtype={"pid": str})
pp["m"] = (pp.arm == "mRNA-1010").astype(int)
for c in ["GMT_d0", "GMT_d29", "GMT_late"]:
    pp["l" + c] = np.log2(pp[c])
rows = []
for sub in ["H1", "H3"]:
    d = pp[pp.subtype == sub]
    f = smf.ols("lGMT_d29 ~ m + lGMT_d0", d).fit(); lo, hi = f.conf_int().loc["m"]
    rows.append(dict(subtype=sub, analysis="all participants (OLS ANCOVA)", n=len(d), adjGMR=2 ** f.params["m"], lo=2 ** lo, hi=2 ** hi, p=f.pvalues["m"]))
    q = smf.quantreg("lGMT_d29 ~ m + lGMT_d0", d).fit(q=0.5); lo, hi = q.conf_int().loc["m"]
    rows.append(dict(subtype=sub, analysis="median regression", n=len(d), adjGMR=2 ** q.params["m"], lo=2 ** lo, hi=2 ** hi, p=q.pvalues["m"]))
    loo = []
    for pid in d.pid:
        dd = d[d.pid != pid]
        g = smf.ols("lGMT_d29 ~ m + lGMT_d0", dd).fit(); lo, hi = g.conf_int().loc["m"]
        loo.append((pid, d[d.pid == pid].arm.iloc[0], 2 ** g.params["m"], 2 ** lo, 2 ** hi, g.pvalues["m"]))
    loo = pd.DataFrame(loo, columns=["dropped", "arm", "adjGMR", "lo", "hi", "p"])
    mn, mx = loo.loc[loo.adjGMR.idxmin()], loo.loc[loo.adjGMR.idxmax()]
    rows.append(dict(subtype=sub, analysis=f"leave-one-out minimum (drop {mn.dropped}, {mn.arm})", n=len(d) - 1, adjGMR=mn.adjGMR, lo=mn.lo, hi=mn.hi, p=mn.p))
    rows.append(dict(subtype=sub, analysis=f"leave-one-out maximum (drop {mx.dropped}, {mx.arm})", n=len(d) - 1, adjGMR=mx.adjGMR, lo=mx.lo, hi=mx.hi, p=mx.p))
    rows.append(dict(subtype=sub, analysis="leave-one-out: number of drops with p<0.05", n=len(d) - 1, adjGMR=np.nan, lo=np.nan, hi=np.nan, p=float((loo.p < 0.05).sum())))
out = pd.DataFrame(rows)
print(out.round(3).to_string(index=False))
out.round(4).to_csv(f"{TAB}/13_seqneut_leave_one_out.csv", index=False)
