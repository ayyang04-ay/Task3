#!/usr/bin/env python
"""'Magnitude vs breadth': within-participant drift penalty at day 29 =
log2(mean titer vs contemporary drifted panel) - log2(titer vs vaccine-reference strain).
A platform that broadens (rather than just amplifies) the response should show a smaller penalty.
Run: micromamba run -n core python wu397_breadth_index.py"""
import numpy as np, pandas as pd
from scipy import stats
IN = "/tmp/world/filesystem"; TAB = "/tmp/outputs/analysis/tables"
sn = pd.read_csv(f"{IN}/neutralization_seqbased.csv")
sn[["arm", "pidraw", "dstr"]] = sn.serum.str.split("_", expand=True)
sn["pid"] = sn.pidraw.str.replace("397-", ""); sn["day"] = sn.dstr.str[1:].astype(int)
vir = pd.read_csv(f"{TAB}/07_seqneut_virus_classification.csv")
sn = sn.merge(vir, on="virus"); sn["log2t"] = np.log2(sn.titer)
d29 = sn[sn.day == 29]
def ref(v):
    return d29[d29.virus == v].set_index("pid")["log2t"]
drift = {s: d29[(d29.subtype == s) & (d29.class_ == "contemporary drifted isolate (2022-24)")].groupby("pid")["log2t"].mean() for s in ["H1", "H3"]}
arm = d29.groupby("pid").arm.first()
defs = {
    "H3: drifted panel minus A/Darwin/6/2021 (cell reference, both arms)": (drift["H3"], ref("A/Darwin/6/2021_H3N2")),
    "H3: drifted panel minus A/Darwin/9/2021 (egg reference, both arms)": (drift["H3"], ref("A/Darwin/9/2021_H3N2")),
    "H1: drifted panel minus A/Wisconsin/588/2019 (both arms)": (drift["H1"], ref("A/Wisconsin/588/2019_H1N1")),
    "H1: drifted panel minus A/Wisconsin/67/2022 (both arms)": (drift["H1"], ref("A/Wisconsin/67/2022_H1N1")),
}
rows = []
for k, (a, b) in defs.items():
    pen = (a - b).dropna()
    g = pd.concat([pen.rename("pen"), arm], axis=1).dropna()
    x, y = g[g.arm == "mRNA-1010"].pen, g[g.arm == "Fluarix"].pen
    t = stats.ttest_ind(x, y, equal_var=False)
    rows.append(dict(index=k, n_mRNA=len(x), n_Fluarix=len(y),
                     drifted_over_reference_mRNA=2 ** x.mean(), drifted_over_reference_Fluarix=2 ** y.mean(),
                     ratio_mRNA_over_Fluarix=2 ** (x.mean() - y.mean()), p_welch=t.pvalue))
out = pd.DataFrame(rows)
pd.set_option("display.width", 250)
print(out.round(3).to_string(index=False))
out.round(4).to_csv(f"{TAB}/14_breadth_index_drift_penalty.csv", index=False)
