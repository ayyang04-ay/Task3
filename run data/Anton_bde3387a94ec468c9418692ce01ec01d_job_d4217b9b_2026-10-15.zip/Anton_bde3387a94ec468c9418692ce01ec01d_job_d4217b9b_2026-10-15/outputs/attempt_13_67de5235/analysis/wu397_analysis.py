#!/usr/bin/env python
"""
WU397 data-package re-analysis (mRNA-1010 vs Fluarix, 2022-23 NH season).

Purpose: interpret the existing data package for the claim the program wants to
pursue (heterologous protection) and derive planning parameters for the next
studies.  Statistical/interpretive analysis only.

Run:  micromamba run -n core python wu397_analysis.py
Inputs : /tmp/world/filesystem/*.csv, trial_summary.md
Outputs: /tmp/outputs/analysis/tables/*.csv, figures/*.png, analysis_log.txt

Conventions
- Titers are analysed on the log2 scale; GMT/GMFR = 2**mean(log2).
- Unit of analysis is the PARTICIPANT (serology) or the DONOR (mAbs); viruses
  and mAbs are repeated measures within a participant/donor, not replicates.
- "Homologous/heterologous" in the source files refer to the mRNA-1010
  antigens only (trial_summary.md).  Here every panel strain is re-classified
  against BOTH arms' vaccine strains (see VIRUS CLASSIFICATION below).
"""
import os, re, sys, io, json, math, warnings
import numpy as np
import pandas as pd
from scipy import stats, optimize
import statsmodels.formula.api as smf
import statsmodels.api as sm

warnings.filterwarnings("ignore")
IN = "/tmp/world/filesystem"
OUT = "/tmp/outputs/analysis"
TAB = os.path.join(OUT, "tables")
FIG = os.path.join(OUT, "figures")
os.makedirs(TAB, exist_ok=True)
os.makedirs(FIG, exist_ok=True)
pd.set_option("display.width", 250)
pd.set_option("display.max_columns", 60)
pd.set_option("display.max_rows", 500)

LOG = io.StringIO()


def log(*a):
    s = " ".join(str(x) for x in a)
    print(s)
    LOG.write(s + "\n")


def section(t):
    log("\n" + "=" * 100 + "\n" + t + "\n" + "=" * 100)


def save(df, name, index=False):
    p = os.path.join(TAB, name)
    df.to_csv(p, index=index)
    log(f"[saved] tables/{name}")


def pid3(x):
    """normalise participant ids ('397-005', '005', '5', '20', '397-05') -> '005'"""
    s = str(x).strip()
    s = s.replace("397-", "")
    return f"{int(s):03d}"


def gm(x):
    x = np.asarray(x, float)
    x = x[~np.isnan(x)]
    return 2 ** x.mean() if len(x) else np.nan


def gm_ci(logvals):
    """GMT (or GMFR) with t-based 95% CI from log2 values"""
    v = np.asarray(logvals, float)
    v = v[~np.isnan(v)]
    n = len(v)
    if n < 2:
        return (2 ** v.mean() if n else np.nan, np.nan, np.nan)
    m, se = v.mean(), v.std(ddof=1) / np.sqrt(n)
    t = stats.t.ppf(0.975, n - 1)
    return 2 ** m, 2 ** (m - t * se), 2 ** (m + t * se)


def welch_ratio(a, b):
    """ratio of geometric means (a/b) from log2 values, Welch 95% CI and p"""
    a = np.asarray(a, float); a = a[~np.isnan(a)]
    b = np.asarray(b, float); b = b[~np.isnan(b)]
    d = a.mean() - b.mean()
    va, vb = a.var(ddof=1) / len(a), b.var(ddof=1) / len(b)
    se = np.sqrt(va + vb)
    df_ = (va + vb) ** 2 / (va ** 2 / (len(a) - 1) + vb ** 2 / (len(b) - 1))
    t = stats.t.ppf(0.975, df_)
    p = 2 * stats.t.sf(abs(d / se), df_)
    return 2 ** d, 2 ** (d - t * se), 2 ** (d + t * se), p


def wilson(k, n, z=1.96):
    if n == 0:
        return (np.nan, np.nan, np.nan)
    p = k / n
    den = 1 + z ** 2 / n
    c = (p + z ** 2 / (2 * n)) / den
    h = z * np.sqrt(p * (1 - p) / n + z ** 2 / (4 * n ** 2)) / den
    return p, c - h, c + h


def newcombe_diff(k1, n1, k2, n2):
    """Newcombe hybrid score CI for p1-p2"""
    p1, l1, u1 = wilson(k1, n1)
    p2, l2, u2 = wilson(k2, n2)
    d = p1 - p2
    lo = d - np.sqrt((p1 - l1) ** 2 + (u2 - p2) ** 2)
    hi = d + np.sqrt((u1 - p1) ** 2 + (p2 - l2) ** 2)
    return d, lo, hi


def ancova(df, post, pre, armcol="m"):
    """log2(post) ~ arm + log2(pre); returns adjusted GMR (mRNA/Fluarix), CI, p, resid SD"""
    d = df[[post, pre, armcol]].dropna()
    f = smf.ols(f"{post} ~ {armcol} + {pre}", data=d).fit()
    b = f.params[armcol]
    lo, hi = f.conf_int().loc[armcol]
    return dict(adj_GMR=2 ** b, adj_GMR_lo=2 ** lo, adj_GMR_hi=2 ** hi, p=f.pvalues[armcol],
                resid_sd_log2=np.sqrt(f.scale), n=int(f.nobs))


def tobit_right(y, X, c):
    """right-censored normal regression (censoring at c, log2 scale). returns beta, se, sigma"""
    y = np.asarray(y, float); X = np.asarray(X, float)
    cens = y >= c - 1e-9
    def nll(theta):
        b = theta[:-1]; s = np.exp(theta[-1])
        mu = X @ b
        ll = np.where(cens, stats.norm.logsf((c - mu) / s), stats.norm.logpdf((y - mu) / s) - np.log(s))
        return -ll.sum()
    b0 = np.linalg.lstsq(X, y, rcond=None)[0]
    th0 = np.r_[b0, np.log(np.std(y - X @ b0) + 1e-3)]
    r = optimize.minimize(nll, th0, method="BFGS")
    cov = r.hess_inv
    return r.x[:-1], np.sqrt(np.diag(cov))[:-1], np.exp(r.x[-1])


# ----------------------------------------------------------------------------
# Load
# ----------------------------------------------------------------------------
hai = pd.read_csv(f"{IN}/hai_titers.csv", dtype={"participant": str})
mn = pd.read_csv(f"{IN}/microneutralization.csv", dtype={"participant": str})
eli = pd.read_csv(f"{IN}/elisa_igg_titers.csv", dtype={"participant": str})
igm = pd.read_csv(f"{IN}/igm_fold_change.csv", dtype={"participant": str})
bb1 = pd.read_csv(f"{IN}/binding_breadth_h1.csv", dtype={"participant": str})
bb3 = pd.read_csv(f"{IN}/binding_breadth_h3.csv", dtype={"participant": str})
sn = pd.read_csv(f"{IN}/neutralization_seqbased.csv")
mab = pd.read_csv(f"{IN}/mab_binding_panels.csv")
gc_raw = pd.read_csv(f"{IN}/gc_frequencies.csv", dtype={"participant": str})
pb = pd.read_csv(f"{IN}/plasmablast_frequencies.csv", dtype={"participant": str})
ovl = pd.read_csv(f"{IN}/pb_gc_clonal_overlap.csv")
rep = pd.read_csv(f"{IN}/repertoire_clonotype_counts.csv")
cdr = pd.read_csv(f"{IN}/cdrh3_diversity_index.csv")
sic = pd.read_csv(f"{IN}/serum_igg_clonotypes.csv")

for d in (hai, mn, eli, igm, bb1, bb3, gc_raw, pb):
    d["pid"] = d.participant.map(pid3)
sn[["arm", "pid_raw", "daystr"]] = sn.serum.str.split("_", expand=True)
sn["pid"] = sn.pid_raw.map(pid3)
sn["day"] = sn.daystr.str[1:].astype(int)
sn["subtype"] = sn.virus.str.split("_").str[-1]
mab["donor"] = mab.mab_id.str.split(".").str[1]

# ============================================================================
section("1. COHORT RECONCILIATION (data files vs trial_summary.md assay-cohort table)")
# ============================================================================
stated = {  # from trial_summary.md 'Assay cohorts' table
    "ELISA IgG (elisa_igg_titers.csv)": (38, 37),
    "IgM (igm_fold_change.csv)": (38, 37),
    "HAI (hai_titers.csv)": (14, 15),
    "Bead-array H1 (binding_breadth_h1.csv)": (14, 15),
    "Bead-array H3 (binding_breadth_h3.csv)": (14, 15),
    "Microneutralisation (microneutralization.csv)": (14, 15),
    "Seq-based neutralisation (neutralization_seqbased.csv)": (13, 14),
    "LN FNA: GC B cells (gc_frequencies.csv)": (6, 11),
    "'Plasmablast' file (plasmablast_frequencies.csv)": (6, 11),
}
obs = {
    "ELISA IgG (elisa_igg_titers.csv)": eli,
    "IgM (igm_fold_change.csv)": igm,
    "HAI (hai_titers.csv)": hai,
    "Bead-array H1 (binding_breadth_h1.csv)": bb1,
    "Bead-array H3 (binding_breadth_h3.csv)": bb3,
    "Microneutralisation (microneutralization.csv)": mn,
    "Seq-based neutralisation (neutralization_seqbased.csv)": sn,
    "LN FNA: GC B cells (gc_frequencies.csv)": gc_raw,
    "'Plasmablast' file (plasmablast_frequencies.csv)": pb,
}
rows = []
for k, d in obs.items():
    nm = d[d.arm == "mRNA-1010"].pid.nunique()
    nf = d[d.arm == "Fluarix"].pid.nunique()
    sm_, sf_ = stated[k]
    rows.append(dict(assay=k, stated_mRNA=sm_, stated_Fluarix=sf_, observed_mRNA=nm, observed_Fluarix=nf,
                     matches=(nm == sm_ and nf == sf_)))
rec = pd.DataFrame(rows)
log(rec.to_string(index=False))
save(rec, "01_cohort_reconciliation.csv")

# arm consistency across files
arms = {}
for k, d in obs.items():
    for p, a in d.groupby("pid").arm.unique().items():
        arms.setdefault(p, set()).update(a)
bad = {p: a for p, a in arms.items() if len(a) > 1}
log(f"participants assigned to >1 arm across files: {len(bad)} {bad}")

# extra participants in 'plasmablast' file not in FNA subset
fna = set(gc_raw.pid)
pb_extra = sorted(set(pb.pid) - fna)
log(f"'plasmablast' file participants NOT in the LN-FNA subset ({len(pb_extra)}): {pb_extra}")
log(f"timepoints in gc file: {sorted(gc_raw.timepoint.unique())}; in 'plasmablast' file: {sorted(pb.timepoint.unique())}")
log("protocol blood draws: d0,d7,d29,d121,d181 (wk0,1,4,17,26); protocol FNA: wk1,2,4,8,17,26 (trial_summary.md)")

# ============================================================================
section("2. DATA-INTEGRITY CHECKS")
# ============================================================================
flags = []
# 2a. HAI B/Vic late-visit labels vs other antigens
late_vis = hai[hai.timepoint.isin(["wk17", "wk26"])].groupby(["antigen", "pid"]).timepoint.first().unstack("antigen")
incons = late_vis[late_vis.nunique(axis=1) > 1]
log("HAI late visit label by antigen (participants whose label differs between antigens):")
log(incons.to_string())
flags.append(dict(file="hai_titers.csv", issue="Late-visit label for B/Vic differs from the other 3 antigens in the same participants "
                  "(same serum draw cannot be both wk17 and wk26)", detail="; ".join(f"{p}: " + ", ".join(f"{a}={v}" for a, v in r.dropna().items()) for p, r in incons.iterrows())))
miss031 = hai[(hai.pid == "031") & (hai.antigen == "B/Vic")]
flags.append(dict(file="hai_titers.csv", issue="Participant 031 (mRNA) has no B/Vic HAI at any visit", detail=f"rows={len(miss031)}"))
# 2b. seq-neut late-visit labels vs HAI/MN/ELISA
sn_late = sn[sn.day.isin([121, 181])].groupby("pid").day.first()
mn_late = mn[mn.timepoint.isin(["wk17", "wk26"])].groupby("pid").timepoint.first()
cmp_ = pd.concat([sn_late.rename("seqneut_day"), mn_late.rename("MN_visit")], axis=1).dropna()
cmp_["consistent"] = ((cmp_.seqneut_day == 121) & (cmp_.MN_visit == "wk17")) | ((cmp_.seqneut_day == 181) & (cmp_.MN_visit == "wk26"))
log("Seq-neut late day vs MN late visit, inconsistent rows:")
log(cmp_[~cmp_.consistent].to_string())
flags.append(dict(file="neutralization_seqbased.csv", issue="Late sample labelled d121 for participants whose HAI/MN/ELISA late sample is wk26",
                  detail=", ".join(cmp_[~cmp_.consistent].index)))
# 2c. gc file duplicated key blocks
dup = gc_raw.duplicated(["timepoint", "arm", "pid"], keep=False)
log(f"gc_frequencies.csv: {dup.sum()} of {len(gc_raw)} rows share (timepoint, arm, participant) with another row -> two unlabeled blocks")
flags.append(dict(file="gc_frequencies.csv", issue="File contains two stacked blocks with identical keys and the same column name; "
                  "the second block is not identified (values not a subset of block 1, e.g. 028 wk2 41.8 vs 30.5)", detail=f"{dup.sum()} duplicated-key rows"))
flags.append(dict(file="gc_frequencies.csv", issue="Contains a 'wk0' FNA visit that is not in the protocol FNA schedule; protocol visits wk1 and wk4 are absent", detail=str(sorted(gc_raw.timepoint.unique()))))
flags.append(dict(file="plasmablast_frequencies.csv", issue="Timepoints (wk2, wk8) are FNA visits, not blood visits (blood: wk0,1,4,17,26) and wk1 (the usual blood plasmablast peak) is absent; "
                  f"includes {len(pb_extra)} participants outside the FNA subset (6 vs 11); tissue/denominator undefined",
                  detail=",".join(pb_extra)))
# precision of values for extra participants
def ndec(v):
    s = f"{v:.10g}"
    return len(s.split(".")[1]) if "." in s else 0
pb["sig"] = pb.pct_plasmablast.map(lambda v: len(re.sub(r"^0\.0*", "", f"{v:.10g}").replace(".", "")) if v > 0 else np.nan)
sig_tab = pb.assign(extra=pb.pid.isin(pb_extra)).groupby("extra").sig.median()
log(f"median significant digits of non-zero 'plasmablast' values: core FNA participants={sig_tab.get(False)}, extra participants={sig_tab.get(True)}")
flags.append(dict(file="plasmablast_frequencies.csv", issue="Values for the extra participants are recorded at lower precision than the FNA-subset participants",
                  detail=f"median significant digits {sig_tab.get(False)} vs {sig_tab.get(True)}"))
# 2d. IgM cohort
flags.append(dict(file="igm_fold_change.csv", issue="IgM cohort is 14 mRNA / 15 Fluarix, not 38/37 as stated in trial_summary.md; timepoint of the fold-change not stated",
                  detail="participant '20' written without zero padding"))
# 2e. seq-neut typos / missing
flags.append(dict(file="neutralization_seqbased.csv", issue="Virus name with malformed year", detail="A/SOUTHAFRICA/R07876/202023_H3N2"))
nv = sn.groupby("serum").virus.nunique()
flags.append(dict(file="neutralization_seqbased.csv", issue="Not every serum was titrated against all 96 viruses",
                  detail=f"viruses per serum min={nv.min()} max={nv.max()}; e.g. mRNA-1010_397-030 sera {nv.filter(like='397-030').to_dict()}"))
cens = sn.titer_bound.value_counts().to_dict()
flags.append(dict(file="neutralization_seqbased.csv", issue="Censored titers present (upper = at/below lower limit 40; lower = at/above 17300)", detail=str(cens)))
# 2f. MN ceiling
ceil = mn[(mn.measure == "titer") & (mn.value >= 1280)].groupby(["panel", "timepoint", "arm"]).size().unstack("arm")
log("MN titers at the 1:1280 upper limit:\n" + ceil.to_string())
flags.append(dict(file="microneutralization.csv", issue="Upper limit of 1280 reached by many samples -> fold-rises truncated; panel strains not identified",
                  detail=ceil.fillna(0).astype(int).to_string().replace("\n", " | ")))
# 2g. bead array negative across-the-board fold changes
flags.append(dict(file="binding_breadth_h1/h3.csv", issue="Timepoint of the fold-change not stated; several participants show uniform decreases across all strains (e.g. 002, 011, 027 in H3) suggestive of sample-level/batch effects", detail=""))
# 2h. mAb panel
flags.append(dict(file="mab_binding_panels.csv", issue="mAbs come from 4 mRNA donors (589 mAbs) vs 3 Fluarix donors (106 mAbs; one donor = 84); source compartment/timepoint not stated; binding threshold not defined", detail=""))
# 2i. Pooled wk17/26
flags.append(dict(file="HAI/MN/ELISA fold-change tables", issue="wk17 and wk26 pooled as 'wk17/26' (2 Fluarix + 2 mRNA at wk17 in HAI/MN; 3 + 4 in ELISA)", detail="durability cannot be read at a fixed time"))
# 2j. documented antigen composition
flags.append(dict(file="trial_summary.md", issue="Documented mRNA-1010 H1 (A/Victoria/4897/2022) is not the 2022-23 NH H1; Fluarix 2022-23 H1 is A/Victoria/2570/2019 (IVR-215) (external: WHO Feb-2022 recommendation / product label). Arms therefore differ in H1 antigen; H3 reference is the same (Darwin/6 cell vs Darwin/9 egg)", detail="see section 7 for serological evidence on which H1 the mRNA arm responded to"))
flags.append(dict(file="neutralization_seqbased.csv", issue="Serum identifiers embed the arm name (e.g. 'Fluarix_397-001_d0'), i.e. the testing laboratory was not blinded to allocation or visit", detail="next studies: coded, arm- and visit-blinded samples"))
flags.append(dict(file="whole package", issue="No participant-level age, sex, site, prior-season vaccination or prior-infection data; mRNA dose (ug per HA) not stated; no neuraminidase-inhibition, T-cell or infection-surveillance data", detail="baseline comparability can only be judged from pre-vaccination titres"))
flags.append(dict(file="whole package", issue="No readouts against influenza B beyond HAI/ELISA (sequencing-based neutralisation and mAb panels are H1/H3 only); B/Yamagata component is obsolete for future formulations", detail=""))
fl = pd.DataFrame(flags)
save(fl, "02_data_integrity_flags.csv")

# ============================================================================
section("3. HAEMAGGLUTINATION INHIBITION (hai_titers.csv)")
# ============================================================================
h = hai.pivot_table(index=["antigen", "arm", "pid"], columns="timepoint", values="hai_titer").reset_index()
h["late"] = h["wk26"].fillna(h["wk17"])
for c in ["wk0", "wk4", "late"]:
    h["l" + c] = np.log2(h[c])
h["m"] = (h.arm == "mRNA-1010").astype(int)
h["sc"] = ((h.wk4 / h.wk0 >= 4) & (h.wk4 >= 40)).astype(int)
rows = []
for (ag, arm), g in h.groupby(["antigen", "arm"]):
    g = g.dropna(subset=["wk0", "wk4"])
    gmt0 = gm_ci(g.lwk0); gmt4 = gm_ci(g.lwk4); gmfr = gm_ci(g.lwk4 - g.lwk0); gmtl = gm_ci(g.llate)
    k = g.sc.sum(); n = len(g)
    scr = wilson(k, n)
    rows.append(dict(antigen=ag, arm=arm, n=n, GMT_d0=gmt0[0], GMT_wk4=gmt4[0], GMT_wk4_lo=gmt4[1], GMT_wk4_hi=gmt4[2],
                     GMFR_wk4=gmfr[0], GMFR_lo=gmfr[1], GMFR_hi=gmfr[2], n_seroconv=k, SCR=scr[0], SCR_lo=scr[1], SCR_hi=scr[2],
                     SPR_d0=(g.wk0 >= 40).mean(), SPR_wk4=(g.wk4 >= 40).mean(), SPR_wk4_n=int((g.wk4 >= 40).sum()),
                     GMT_wk17_26=gmtl[0], n_late=int(g.llate.notna().sum())))
hai_sum = pd.DataFrame(rows)
cmp_rows = []
for ag, g in h.groupby("antigen"):
    g = g.dropna(subset=["wk0", "wk4"])
    a = ancova(g, "lwk4", "lwk0")
    al = ancova(g.dropna(subset=["llate"]), "llate", "lwk0")
    k1, n1 = g[g.m == 1].sc.sum(), (g.m == 1).sum()
    k0, n0 = g[g.m == 0].sc.sum(), (g.m == 0).sum()
    d, lo, hi = newcombe_diff(k1, n1, k0, n0)
    fis = stats.fisher_exact([[k1, n1 - k1], [k0, n0 - k0]]).pvalue
    b = welch_ratio(g[g.m == 1].lwk0, g[g.m == 0].lwk0)
    cmp_rows.append(dict(antigen=ag, baseline_GMT_ratio=b[0], baseline_p=b[3],
                         wk4_adjGMR_mRNA_over_Fluarix=a["adj_GMR"], lo=a["adj_GMR_lo"], hi=a["adj_GMR_hi"], p=a["p"], resid_sd_log2=a["resid_sd_log2"],
                         late_adjGMR=al["adj_GMR"], late_lo=al["adj_GMR_lo"], late_hi=al["adj_GMR_hi"], late_p=al["p"],
                         SCR_diff_mRNA_minus_Fluarix=d, SCR_diff_lo=lo, SCR_diff_hi=hi, SCR_fisher_p=fis))
hai_cmp = pd.DataFrame(cmp_rows)
log(hai_sum.round(3).to_string(index=False))
log(hai_cmp.round(3).to_string(index=False))
save(hai_sum.round(4), "03_hai_by_arm.csv")
save(hai_cmp.round(4), "03_hai_arm_comparison.csv")

# ============================================================================
section("4. MICRONEUTRALISATION (microneutralization.csv) - panel strains not identified in the package")
# ============================================================================
t = mn[mn.measure == "titer"].pivot_table(index=["panel", "arm", "pid"], columns="timepoint", values="value").reset_index()
t["late"] = t["wk26"].fillna(t["wk17"])
for c in ["wk0", "wk4", "late"]:
    t["l" + c] = np.log2(t[c])
t["m"] = (t.arm == "mRNA-1010").astype(int)
rows = []
for (pn, arm), g in t.groupby(["panel", "arm"]):
    rows.append(dict(panel=pn, arm=arm, n=len(g), GMT_d0=gm(g.lwk0), GMT_wk4=gm(g.lwk4), GMFR_wk4=gm(g.lwk4 - g.lwk0),
                     GMT_late=gm(g.llate), GMFR_late=gm(g.llate - g.lwk0),
                     n_at_ULOQ_d0=int((g.wk0 >= 1280).sum()), n_at_ULOQ_wk4=int((g.wk4 >= 1280).sum()),
                     n_4fold_wk4=int((g.wk4 / g.wk0 >= 4).sum())))
mn_sum = pd.DataFrame(rows)
cmp_rows = []
CEIL = np.log2(1280)
for pn, g in t.groupby("panel"):
    a = ancova(g, "lwk4", "lwk0")
    X = np.c_[np.ones(len(g)), g.m, g.lwk0]
    b, se, s = tobit_right(g.lwk4.values, X, CEIL)
    r = welch_ratio((g.lwk4 - g.lwk0)[g.m == 1], (g.lwk4 - g.lwk0)[g.m == 0])
    r0 = welch_ratio(g[g.m == 1].lwk0, g[g.m == 0].lwk0)
    r4 = welch_ratio(g[g.m == 1].lwk4, g[g.m == 0].lwk4)
    cmp_rows.append(dict(panel=pn, baseline_GMT_ratio=r0[0], baseline_p=r0[3], wk4_unadj_GMT_ratio=r4[0], wk4_unadj_p=r4[3],
                         n4fold_mRNA=int(((g.lwk4 - g.lwk0) >= 2 - 1e-9)[g.m == 1].sum()), n_mRNA=int((g.m == 1).sum()),
                         n4fold_Fluarix=int(((g.lwk4 - g.lwk0) >= 2 - 1e-9)[g.m == 0].sum()), n_Fluarix=int((g.m == 0).sum()),
                         GMFR_ratio=r[0], GMFR_ratio_lo=r[1], GMFR_ratio_hi=r[2], GMFR_p=r[3],
                         ancova_adjGMR=a["adj_GMR"], lo=a["adj_GMR_lo"], hi=a["adj_GMR_hi"], p=a["p"],
                         tobit_adjGMR=2 ** b[1], tobit_lo=2 ** (b[1] - 1.96 * se[1]), tobit_hi=2 ** (b[1] + 1.96 * se[1]),
                         tobit_p=2 * stats.norm.sf(abs(b[1] / se[1]))))
mn_cmp = pd.DataFrame(cmp_rows)
log(mn_sum.round(2).to_string(index=False))
log(mn_cmp.round(3).to_string(index=False))
save(mn_sum.round(3), "04_mn_by_arm.csv")
save(mn_cmp.round(4), "04_mn_arm_comparison.csv")

# ============================================================================
section("5. ELISA IgG (elisa_igg_titers.csv) - largest cohort (38 vs 37)")
# ============================================================================
e = eli[eli.measure == "ec50"].pivot_table(index=["antigen", "arm", "pid"], columns="timepoint", values="value").reset_index()
e["late"] = e["wk26"].fillna(e["wk17"])
for c in ["wk0", "wk4", "late"]:
    e["l" + c] = np.log2(e[c])
e["m"] = (e.arm == "mRNA-1010").astype(int)
rows = []
for (ag, arm), g in e.groupby(["antigen", "arm"]):
    rows.append(dict(antigen=ag, arm=arm, n=len(g), GMT_d0=gm(g.lwk0), GMT_wk4=gm(g.lwk4), GMFR_wk4=gm(g.lwk4 - g.lwk0),
                     GMT_late=gm(g.llate), GMFR_late=gm(g.llate - g.lwk0)))
el_sum = pd.DataFrame(rows)
cmp_rows = []
for ag, g in e.groupby("antigen"):
    a = ancova(g, "lwk4", "lwk0"); al = ancova(g, "llate", "lwk0")
    b = welch_ratio(g[g.m == 1].lwk0, g[g.m == 0].lwk0)
    cmp_rows.append(dict(antigen=ag, baseline_ratio=b[0], baseline_p=b[3], wk4_adjGMR=a["adj_GMR"], lo=a["adj_GMR_lo"], hi=a["adj_GMR_hi"], p=a["p"],
                         late_adjGMR=al["adj_GMR"], late_lo=al["adj_GMR_lo"], late_hi=al["adj_GMR_hi"], late_p=al["p"]))
el_cmp = pd.DataFrame(cmp_rows)
log(el_sum.round(2).to_string(index=False))
log(el_cmp.round(4).to_string(index=False))
save(el_sum.round(3), "05_elisa_by_arm.csv")
save(el_cmp.round(4), "05_elisa_arm_comparison.csv")
# site/ID-block heterogeneity within arm (allocation was by site)
e["idblock"] = np.where(e.pid.astype(int) <= 32, "IDs 001-032", "IDs 033-102")
het = []
for (ag, arm), g in e.groupby(["antigen", "arm"]):
    a_, b_ = g[g.idblock == "IDs 001-032"], g[g.idblock != "IDs 001-032"]
    het.append(dict(antigen=ag, arm=arm, n_core=len(a_), n_other=len(b_), GMT0_core=gm(a_.lwk0), GMT0_other=gm(b_.lwk0),
                    p_baseline=stats.mannwhitneyu(a_.lwk0, b_.lwk0).pvalue,
                    GMFR_core=gm(a_.lwk4 - a_.lwk0), GMFR_other=gm(b_.lwk4 - b_.lwk0),
                    p_GMFR=stats.mannwhitneyu(a_.lwk4 - a_.lwk0, b_.lwk4 - b_.lwk0).pvalue))
het = pd.DataFrame(het)
log("Within-arm heterogeneity by participant-ID block (IDs 033-059 are all Fluarix, 064-102 all mRNA -> consistent with site blocks):")
log(het.round(3).to_string(index=False))
save(het.round(4), "05_elisa_within_arm_idblock_heterogeneity.csv")

# ============================================================================
section("6. BEAD-ARRAY BINDING BREADTH (binding_breadth_h1/h3.csv; log2 fold-change MFI, timepoint not stated)")
# ============================================================================
# Strain classes relative to BOTH arms (external knowledge: WHO recommendations)
bead_class = {
    # H1
    "A/Wisconsin/67/2022": ("H1", "mRNA-1010 H1 counterpart (cell-based A/Victoria/4897/2022-like; 2023-24 reference)"),
    "A/Wisconsin/588/2019": ("H1", "Fluarix H1 counterpart (cell-based A/Victoria/2570/2019-like; 2022-23 reference)"),
    "A/Sydney/5/2021": ("H1", "contemporaneous non-vaccine strain (2021)"),
    "A/Hawaii/70/2019": ("H1", "historical"), "A/Guangdong-Maonan/SWL1536/2019": ("H1", "historical"),
    "A/Brisbane/2/2018": ("H1", "historical"), "A/Michigan/45/2015": ("H1", "historical"),
    "A/California/04/2009": ("H1", "historical"), "A/Puerto Rico/8/1934": ("H1", "historical"),
    # H3
    "A/Darwin/6/2021": ("H3", "vaccine reference (both arms: Darwin/6 cell in mRNA-1010, Darwin/9 egg in Fluarix)"),
    "A/Thailand/8/2022": ("H3", "forward-drifted (later WHO reference)"),
    "A/Cambodia/e0826360/2020": ("H3", "historical"), "A/Hong Kong/2671/2019": ("H3", "historical"),
    "A/South Australia/34/2019": ("H3", "historical"), "A/Switzerland/8060/2017": ("H3", "historical"),
    "A/Singapore/INFIMH-16-0019/2016": ("H3", "historical"), "A/Texas/50/2012": ("H3", "historical"),
    "A/Victoria/361/2011": ("H3", "historical"), "A/Perth/16/2009": ("H3", "historical"),
    "A/Brisbane/10/2007": ("H3", "historical"), "A/Hong Kong/1/1968": ("H3", "historical"),
}
bb = pd.concat([bb1, bb3])
bb["sub"] = bb.strain.map(lambda s: bead_class[s][0])
bb["cls"] = bb.strain.map(lambda s: bead_class[s][1])
rows = []
for s, g in bb.groupby("strain"):
    a = g[g.arm == "mRNA-1010"].log2_fold_change_mfi; b = g[g.arm == "Fluarix"].log2_fold_change_mfi
    r = welch_ratio(a, b)
    rows.append(dict(subtype=bead_class[s][0], strain=s, class_=bead_class[s][1], n_mRNA=len(a), n_Fluarix=len(b),
                     mean_log2FC_mRNA=a.mean(), mean_log2FC_Fluarix=b.mean(), fold_mRNA=2 ** a.mean(), fold_Fluarix=2 ** b.mean(),
                     ratio_of_fold_rises=r[0], lo=r[1], hi=r[2], p_welch=r[3], p_mwu=stats.mannwhitneyu(a, b).pvalue))
bead_tab = pd.DataFrame(rows).sort_values(["subtype", "class_", "strain"])
log(bead_tab.round(3).to_string(index=False))
save(bead_tab.round(4), "06_bead_binding_per_strain.csv")
# participant composites
comp = bb.groupby(["sub", "arm", "pid"]).log2_fold_change_mfi.mean().reset_index()
rows = []
for sub, g in comp.groupby("sub"):
    r = welch_ratio(g[g.arm == "mRNA-1010"].log2_fold_change_mfi, g[g.arm == "Fluarix"].log2_fold_change_mfi)
    rows.append(dict(subtype=sub, metric="mean log2FC across all panel strains", mRNA=2 ** g[g.arm == "mRNA-1010"].log2_fold_change_mfi.mean(),
                     Fluarix=2 ** g[g.arm == "Fluarix"].log2_fold_change_mfi.mean(), ratio=r[0], lo=r[1], hi=r[2], p=r[3]))
bead_comp = pd.DataFrame(rows)
log(bead_comp.round(3).to_string(index=False))
save(bead_comp.round(4), "06_bead_binding_composites.csv")

# ============================================================================
section("7. SEQUENCING-BASED NEUTRALISATION (neutralization_seqbased.csv) - 96 viruses, 13 mRNA vs 14 Fluarix")
# ============================================================================
def classify_virus(v):
    name, sub = v.rsplit("_", 1)[0], v.rsplit("_", 1)[1]
    if sub == "H1N1":
        if "4897/2022" in name:
            return "H1", "mRNA-1010 H1 (documented immunogen, egg reassortant IVR-238)"
        if name == "A/Wisconsin/67/2022":
            return "H1", "mRNA-1010 H1 counterpart (cell-based, same 2023-24 recommendation)"
        if name == "A/Wisconsin/588/2019":
            return "H1", "Fluarix H1 counterpart (cell-based 2022-23 reference)"
        if name.endswith("/2023"):
            return "H1", "contemporary drifted isolate (2022-24)"
        return "H1", "historical wild-type"
    # H3N2
    if name in ("A/Darwin/6/2021",):
        return "H3", "vaccine reference, cell (mRNA-1010 immunogen)"
    if name in ("A/Darwin/9/2021",):
        return "H3", "vaccine reference, egg-based (Fluarix 2022-23 reference)"
    if re.search(r"(X-\d+A|NIB-\d+|IVR-\d+|egg)$", name) or "egg" in name or "X-307A" in name or "X-223A" in name or "NIB-88" in name:
        return "H3", "production/egg reassortant of historical strain"
    yr = re.search(r"/(\d{4,6})$", name)
    y = int(yr.group(1)[-4:]) if yr else None
    if name in ("A/Thailand/8/2022", "A/Massachusetts/18/2022"):
        return "H3", "contemporary drifted isolate (2022-24)"
    if y is not None and y >= 2022:
        return "H3", "contemporary drifted isolate (2022-24)"
    return "H3", "historical wild-type"

vir = pd.DataFrame({"virus": sorted(sn.virus.unique())})
vir[["subtype", "class_"]] = vir.virus.apply(lambda v: pd.Series(classify_virus(v)))
log(vir.groupby(["subtype", "class_"]).size().to_string())
save(vir, "07_seqneut_virus_classification.csv")
sn = sn.merge(vir[["virus", "class_"]], on="virus")
sn["tp"] = sn.day.map({0: "d0", 29: "d29", 121: "late", 181: "late"})

def seq_wide(df, upper_sub=None):
    d = df.copy()
    if upper_sub is not None:
        d.loc[d.titer_bound == "upper", "titer"] = upper_sub
    d["lt"] = np.log2(d.titer)
    w = d.pivot_table(index=["arm", "pid", "virus", "subtype", "class_"], columns="tp", values="lt").reset_index()
    w["m"] = (w.arm == "mRNA-1010").astype(int)
    return w

W = seq_wide(sn)
# per-virus table
rows = []
for (v, sub, cl), g in W.groupby(["virus", "subtype", "class_"]):
    g2 = g.dropna(subset=["d0", "d29"])
    a, b = g2[g2.m == 1], g2[g2.m == 0]
    r = welch_ratio(a.d29 - a.d0, b.d29 - b.d0)
    anc = ancova(g2, "d29", "d0")
    rows.append(dict(virus=v, subtype=sub, class_=cl, n_mRNA=len(a), n_Fluarix=len(b),
                     GMT_d0_mRNA=gm(a.d0), GMT_d0_Fluarix=gm(b.d0), GMT_d29_mRNA=gm(a.d29), GMT_d29_Fluarix=gm(b.d29),
                     GMFR_mRNA=gm(a.d29 - a.d0), GMFR_Fluarix=gm(b.d29 - b.d0), GMFR_ratio=r[0], GMFR_ratio_p=r[3],
                     d29_adjGMR=anc["adj_GMR"], d29_adjGMR_lo=anc["adj_GMR_lo"], d29_adjGMR_hi=anc["adj_GMR_hi"], d29_adj_p=anc["p"],
                     GMT_late_mRNA=gm(g[g.m == 1].late), GMT_late_Fluarix=gm(g[g.m == 0].late)))
pv = pd.DataFrame(rows)
from statsmodels.stats.multitest import multipletests
pv["d29_adj_q_BH"] = multipletests(pv.d29_adj_p, method="fdr_bh")[1]
pv["GMFR_q_BH"] = multipletests(pv.GMFR_ratio_p, method="fdr_bh")[1]
pv = pv.sort_values(["subtype", "class_", "virus"])
save(pv.round(4), "07_seqneut_per_virus.csv")
log(pv[["virus", "class_", "GMT_d0_mRNA", "GMT_d0_Fluarix", "GMT_d29_mRNA", "GMT_d29_Fluarix", "GMFR_mRNA", "GMFR_Fluarix", "d29_adjGMR", "d29_adj_q_BH", "GMFR_q_BH"]].round(2).to_string(index=False))
log(f"viruses with BH q<0.05 for baseline-adjusted d29 difference: {(pv.d29_adj_q_BH < 0.05).sum()} of {len(pv)}")
log(f"viruses with BH q<0.05 for GMFR difference: {(pv.GMFR_q_BH < 0.05).sum()} of {len(pv)}")

# participant-level composites
def composites(w):
    rows = []
    for (sub, cl), g in w.groupby(["subtype", "class_"]):
        pp = g.dropna(subset=["d0", "d29"]).groupby(["arm", "pid", "m"])[["d0", "d29"]].mean().reset_index()
        pl = g.dropna(subset=["d0", "late"]).groupby(["arm", "pid", "m"])[["d0", "late"]].mean().reset_index()
        a, b = pp[pp.m == 1], pp[pp.m == 0]
        r = welch_ratio(a.d29 - a.d0, b.d29 - b.d0)
        r0 = welch_ratio(a.d0, b.d0)
        r29 = welch_ratio(a.d29, b.d29)
        anc = ancova(pp, "d29", "d0")
        ancl = ancova(pl, "late", "d0")
        rows.append(dict(subtype=sub, class_=cl, n_viruses=g.virus.nunique(), n_mRNA=len(a), n_Fluarix=len(b),
                         GMT_d0_mRNA=2 ** a.d0.mean(), GMT_d0_Fluarix=2 ** b.d0.mean(), baseline_ratio=r0[0], baseline_p=r0[3],
                         GMT_d29_mRNA=2 ** a.d29.mean(), GMT_d29_Fluarix=2 ** b.d29.mean(), unadj_d29_ratio=r29[0], unadj_d29_p=r29[3],
                         GMFR_mRNA=2 ** (a.d29 - a.d0).mean(), GMFR_Fluarix=2 ** (b.d29 - b.d0).mean(),
                         GMFR_ratio=r[0], GMFR_ratio_lo=r[1], GMFR_ratio_hi=r[2], GMFR_p=r[3],
                         d29_adjGMR=anc["adj_GMR"], d29_adj_lo=anc["adj_GMR_lo"], d29_adj_hi=anc["adj_GMR_hi"], d29_adj_p=anc["p"], d29_resid_sd=anc["resid_sd_log2"],
                         late_adjGMR=ancl["adj_GMR"], late_adj_lo=ancl["adj_GMR_lo"], late_adj_hi=ancl["adj_GMR_hi"], late_adj_p=ancl["p"],
                         GMFR_late_mRNA=2 ** (pl[pl.m == 1].late - pl[pl.m == 1].d0).mean(), GMFR_late_Fluarix=2 ** (pl[pl.m == 0].late - pl[pl.m == 0].d0).mean()))
    return pd.DataFrame(rows)

compA = composites(W)
log("\nParticipant-level composites (titers as reported; 'upper'-censored values kept at 40):")
log(compA.round(3).to_string(index=False))
save(compA.round(4), "07_seqneut_composites_primary.csv")
compB = composites(seq_wide(sn, upper_sub=20))
save(compB.round(4), "07_seqneut_composites_sens_censored_at_20.csv")
log("\nSensitivity: 'upper'-censored values set to 20:")
log(compB[["subtype", "class_", "GMFR_ratio", "GMFR_p", "d29_adjGMR", "d29_adj_lo", "d29_adj_hi", "d29_adj_p"]].round(3).to_string(index=False))

# Mixed model across contemporary viruses (participant random intercept, virus fixed effects)
mm_rows = []
for sub in ["H1N1", "H3N2"]:
    g = W[(W.subtype == sub) & (W.class_ == "contemporary drifted isolate (2022-24)")].dropna(subset=["d0", "d29"]).copy()
    g["d0c"] = g.d0 - g.groupby("virus").d0.transform("mean")
    md = smf.mixedlm("d29 ~ m + d0c + C(virus)", g, groups=g["pid"]).fit(reml=True)
    b = md.params["m"]; lo, hi = md.conf_int().loc["m"]
    mm_rows.append(dict(subtype=sub, panel="contemporary drifted (2022-24)", n_obs=len(g), n_participants=g.pid.nunique(),
                        adjGMR=2 ** b, lo=2 ** lo, hi=2 ** hi, p=md.pvalues["m"]))
    # naive pooled (pseudo-replicated) test for contrast
    fc = g.d29 - g.d0
    tt = stats.ttest_ind(fc[g.m == 1], fc[g.m == 0])
    mm_rows.append(dict(subtype=sub, panel="NAIVE pooled virus x participant t-test on log2 fold-rise (WRONG unit)", n_obs=len(g), n_participants=g.pid.nunique(),
                        adjGMR=2 ** (fc[g.m == 1].mean() - fc[g.m == 0].mean()), lo=np.nan, hi=np.nan, p=tt.pvalue))
mmdf = pd.DataFrame(mm_rows)
log(mmdf.to_string(index=False))
save(mmdf, "07_seqneut_mixed_model_and_pseudoreplication.csv")

# egg reassortant vs wild-type baseline titres
pairs = [("A/Texas/50/2012_H3N2", "A/Texas/50/2012X-223A_H3N2"), ("A/Switzerland/9715293/2013_H3N2", "A/Switzerland/9715293/2013NIB-88_H3N2"),
         ("A/HongKong/4801/2014_H3N2", "A/HongKong/4801/2014egg_H3N2"), ("A/Singapore/INFIMH-16-0019/2016_H3N2", "A/Singapore/INFIMH-16-0019/2016X-307A_H3N2"),
         ("A/Cambodia/e0826360/2020_H3N2", "A/Cambodia/e0826360/2020egg_H3N2"), ("A/Darwin/6/2021_H3N2", "A/Darwin/9/2021_H3N2")]
rows = []
for wt, egg in pairs:
    a = W[W.virus == wt].set_index(["arm", "pid"]); b = W[W.virus == egg].set_index(["arm", "pid"])
    j = a[["d0", "d29"]].join(b[["d0", "d29"]], lsuffix="_wt", rsuffix="_egg").dropna()
    rows.append(dict(wild_type=wt, egg_or_reassortant=egg, n=len(j), GMT_d0_wt=gm(j.d0_wt), GMT_d0_egg=gm(j.d0_egg),
                     paired_ratio_egg_over_wt_d0=2 ** (j.d0_egg - j.d0_wt).mean(),
                     p_paired=stats.ttest_rel(j.d0_egg, j.d0_wt).pvalue,
                     n_lower_censored_egg=int((sn[(sn.virus == egg)].titer_bound == "lower").sum())))
eggt = pd.DataFrame(rows)
log(eggt.round(4).to_string(index=False))
save(eggt.round(4), "07_seqneut_egg_vs_wildtype.csv")

# H1 immunogen-identity check: within-participant rise to W588 vs W67 vs IVR-238
h1 = W[W.virus.isin(["A/Wisconsin/588/2019_H1N1", "A/Wisconsin/67/2022_H1N1", "A/Victoria/4897/2022_IVR-238_H1N1"])].copy()
h1["fc"] = h1.d29 - h1.d0
pvt = h1.pivot_table(index=["arm", "pid"], columns="virus", values="fc")
rows = []
for arm, g in pvt.groupby(level=0):
    d1 = g["A/Wisconsin/588/2019_H1N1"] - g["A/Wisconsin/67/2022_H1N1"]
    d2 = g["A/Wisconsin/588/2019_H1N1"] - g["A/Victoria/4897/2022_IVR-238_H1N1"]
    rows.append(dict(arm=arm, n=len(g), GMFR_W588=gm(g["A/Wisconsin/588/2019_H1N1"]), GMFR_W67=gm(g["A/Wisconsin/67/2022_H1N1"]),
                     GMFR_Vic4897_IVR238=gm(g["A/Victoria/4897/2022_IVR-238_H1N1"]),
                     paired_ratio_W588_over_W67=2 ** d1.mean(), p_W588_vs_W67=stats.ttest_rel(g["A/Wisconsin/588/2019_H1N1"], g["A/Wisconsin/67/2022_H1N1"]).pvalue,
                     n_partic_W588_gt_W67=int((d1 > 0).sum()),
                     paired_ratio_W588_over_IVR238=2 ** d2.mean(), p_W588_vs_IVR238=stats.ttest_rel(g["A/Wisconsin/588/2019_H1N1"], g["A/Victoria/4897/2022_IVR-238_H1N1"]).pvalue))
h1id = pd.DataFrame(rows)
log("H1 immunogen-identity check (d29/d0 fold-rise, paired within participant):")
log(h1id.round(4).to_string(index=False))
save(h1id.round(4), "07_seqneut_H1_immunogen_identity_check.csv")

# ============================================================================
section("8. BINDING vs FUNCTION (same participants, same strain A/Darwin/6/2021 or subtype)")
# ============================================================================
bd = bb3[bb3.strain == "A/Darwin/6/2021"].set_index("pid").log2_fold_change_mfi.rename("bead_Darwin6_log2FC")
bd1 = bb1[bb1.strain == "A/Wisconsin/588/2019"].set_index("pid").log2_fold_change_mfi.rename("bead_W588_log2FC")
el3 = e[e.antigen == "A/H3"].set_index("pid"); el3 = (el3.lwk4 - el3.lwk0).rename("ELISA_H3_log2FC")
el1 = e[e.antigen == "A/H1"].set_index("pid"); el1 = (el1.lwk4 - el1.lwk0).rename("ELISA_H1_log2FC")
hh3 = h[h.antigen == "A/H3N2"].set_index("pid"); hh3 = (hh3.lwk4 - hh3.lwk0).rename("HAI_H3_log2FC")
hh1 = h[h.antigen == "A/H1N1"].set_index("pid"); hh1 = (hh1.lwk4 - hh1.lwk0).rename("HAI_H1_log2FC")
s6 = W[W.virus == "A/Darwin/6/2021_H3N2"].set_index("pid"); s6 = (s6.d29 - s6.d0).rename("NEUT_Darwin6_log2FC")
s588 = W[W.virus == "A/Wisconsin/588/2019_H1N1"].set_index("pid"); s588 = (s588.d29 - s588.d0).rename("NEUT_W588_log2FC")
armmap = pd.concat([bb3.drop_duplicates("pid").set_index("pid").arm])
BF = pd.concat([armmap, bd, el3, hh3, s6, bd1, el1, hh1, s588], axis=1).dropna(subset=["arm"])
rows = []
for col in BF.columns[1:]:
    a = BF[BF.arm == "mRNA-1010"][col].dropna(); b = BF[BF.arm == "Fluarix"][col].dropna()
    r = welch_ratio(a, b)
    rows.append(dict(readout=col, n_mRNA=len(a), n_Fluarix=len(b), fold_mRNA=2 ** a.mean(), fold_Fluarix=2 ** b.mean(), ratio=r[0], lo=r[1], hi=r[2], p=r[3]))
bf = pd.DataFrame(rows)
log(bf.round(3).to_string(index=False))
save(bf.round(4), "08_binding_vs_function_same_participants.csv")
BF.to_csv(os.path.join(TAB, "08_binding_vs_function_participant_level.csv"))
cr = []
for a_, g_ in BF.groupby("arm"):
    cm = g_.drop(columns="arm").corr(method="spearman")
    for r_ in ["HAI_H3_log2FC", "HAI_H1_log2FC"]:
        for c_ in cm.columns:
            if c_ != r_:
                cr.append(dict(arm=a_, readout_1=r_, readout_2=c_, spearman_rho=cm.loc[r_, c_]))
cr = pd.DataFrame(cr)
log("Spearman correlations of HAI fold-rise with the other readouts, within arm:")
log(cr.round(2).to_string(index=False))
save(cr.round(3), "08_hai_correlation_with_other_readouts.csv")

# ============================================================================
section("9. MONOCLONAL ANTIBODY PANELS (mab_binding_panels.csv) - donor is the unit")
# ============================================================================
M = mab[mab.antigen != "SARS-CoV-2 RBD"].copy()
cnt = mab.groupby(["arm", "donor", "panel"]).mab_id.nunique().unstack("panel").fillna(0).astype(int)
cnt["total_unique"] = mab.groupby(["arm", "donor"]).mab_id.nunique()
log(cnt.to_string())
save(cnt.reset_index(), "09_mab_counts_per_donor.csv")
med = M.groupby(["panel", "antigen", "arm", "donor"]).fold_over_control.median().unstack(["arm", "donor"])
log("Median fold-over-control per donor:")
log(med.round(1).to_string())
save(med.round(2).reset_index(), "09_mab_median_binding_per_donor.csv")
rows = []
for thr in [5, 10]:
    M["bind"] = M.fold_over_control >= thr
    dl = M.groupby(["panel", "antigen", "arm", "donor"]).bind.mean().reset_index()
    for (pn, ag), g in dl.groupby(["panel", "antigen"]):
        a = g[g.arm == "mRNA-1010"].bind; b = g[g.arm == "Fluarix"].bind
        pooled = M[(M.panel == pn) & (M.antigen == ag)]
        k1 = pooled[pooled.arm == "mRNA-1010"].bind.sum(); n1 = (pooled.arm == "mRNA-1010").sum()
        k0 = pooled[pooled.arm == "Fluarix"].bind.sum(); n0 = (pooled.arm == "Fluarix").sum()
        rows.append(dict(threshold=thr, panel=pn, antigen=ag,
                         donor_props_mRNA=";".join(f"{x:.2f}" for x in a), donor_props_Fluarix=";".join(f"{x:.2f}" for x in b),
                         mean_donor_prop_mRNA=a.mean(), mean_donor_prop_Fluarix=b.mean(),
                         donor_level_MWU_p=stats.mannwhitneyu(a, b, method="exact").pvalue,
                         pooled_mAb_prop_mRNA=k1 / n1, pooled_mAb_prop_Fluarix=k0 / n0,
                         pooled_mAb_fisher_p_WRONG_UNIT=stats.fisher_exact([[k1, n1 - k1], [k0, n0 - k0]]).pvalue))
mabt = pd.DataFrame(rows)
log(mabt[mabt.threshold == 10].round(3).to_string(index=False))
save(mabt.round(4), "09_mab_breadth_donor_vs_pooled.csv")
log("Minimum attainable two-sided exact Mann-Whitney p with 4 vs 3 donors = 2/35 = %.3f" % (2 / math.comb(7, 3)))

# ============================================================================
section("10. CELLULAR / REPERTOIRE FILES (mechanistic; small, unbalanced subsets)")
# ============================================================================
gc_raw["block"] = np.where(gc_raw.duplicated(["timepoint", "arm", "pid"], keep="first"), "block2_unlabelled", "block1")
rows = []
for (blk, tp, arm), g in gc_raw.groupby(["block", "timepoint", "arm"]):
    rows.append(dict(block=blk, timepoint=tp, arm=arm, n=len(g), median=g.pct_ha_specific_igg_gc.median(),
                     mean=g.pct_ha_specific_igg_gc.mean(), min=g.pct_ha_specific_igg_gc.min(), max=g.pct_ha_specific_igg_gc.max()))
gct = pd.DataFrame(rows)
tp_order = {"wk0": 0, "wk2": 2, "wk8": 8, "wk17": 17, "wk26": 26}
gct["o"] = gct.timepoint.map(tp_order); gct = gct.sort_values(["block", "o", "arm"]).drop(columns="o")
log(gct.round(3).to_string(index=False))
save(gct.round(4), "10_gc_by_timepoint.csv")
g1 = gc_raw[gc_raw.block == "block1"]
pk = []
for tp in ["wk2", "wk8", "wk17", "wk26"]:
    a = g1[(g1.timepoint == tp) & (g1.arm == "mRNA-1010")].pct_ha_specific_igg_gc
    b = g1[(g1.timepoint == tp) & (g1.arm == "Fluarix")].pct_ha_specific_igg_gc
    pk.append(dict(timepoint=tp, n_mRNA=len(a), n_Fluarix=len(b), median_mRNA=a.median(), median_Fluarix=b.median(),
                   MWU_p=stats.mannwhitneyu(a, b).pvalue))
pk = pd.DataFrame(pk)
log(pk.round(4).to_string(index=False))
save(pk.round(4), "10_gc_block1_arm_comparison.csv")

pbt = []
pb["in_FNA_subset"] = pb.pid.isin(fna)
for tp in ["wk0", "wk2", "wk8", "wk17", "wk26"]:
    for subset, d in [("all rows", pb), ("FNA-subset participants only", pb[pb.in_FNA_subset])]:
        a = d[(d.timepoint == tp) & (d.arm == "mRNA-1010")].pct_plasmablast
        b = d[(d.timepoint == tp) & (d.arm == "Fluarix")].pct_plasmablast
        pbt.append(dict(timepoint=tp, subset=subset, n_mRNA=len(a), n_Fluarix=len(b), median_mRNA=a.median(), median_Fluarix=b.median(),
                        MWU_p=stats.mannwhitneyu(a, b).pvalue if len(a) and len(b) else np.nan))
pbt = pd.DataFrame(pbt)
log(pbt.round(4).to_string(index=False))
save(pbt.round(5), "10_plasmablast_file_summary.csv")

rp = []
for met, g in rep.groupby("metric"):
    a = g[g.arm == "mRNA-1010"].value; b = g[g.arm == "Fluarix"].value
    rp.append(dict(metric=met, n_mRNA=len(a), n_Fluarix=len(b), median_mRNA=a.median(), median_Fluarix=b.median(),
                   MWU_p=stats.mannwhitneyu(a, b).pvalue))
for tp, g in sic.groupby("timepoint"):
    a = g[g.arm == "mRNA-1010"].n_clonotypes; b = g[g.arm == "Fluarix"].n_clonotypes
    rp.append(dict(metric=f"serum IgG clonotypes {tp}", n_mRNA=len(a), n_Fluarix=len(b), median_mRNA=a.median(), median_Fluarix=b.median(),
                   MWU_p=stats.mannwhitneyu(a, b).pvalue if len(a) > 1 and len(b) > 1 else np.nan))
for tp, g in cdr.groupby("timepoint"):
    a = g[g.arm == "mRNA-1010"].diversity_index; b = g[g.arm == "Fluarix"].diversity_index
    rp.append(dict(metric=f"CDR-H3 diversity index {tp}", n_mRNA=len(a), n_Fluarix=len(b), median_mRNA=a.median(), median_Fluarix=b.median(),
                   MWU_p=stats.mannwhitneyu(a, b).pvalue if len(a) > 1 and len(b) > 1 else np.nan))
for ag, g in igm.groupby("antigen"):
    a = g[g.arm == "mRNA-1010"].fold_change; b = g[g.arm == "Fluarix"].fold_change
    rp.append(dict(metric=f"IgM fold-change {ag}", n_mRNA=len(a), n_Fluarix=len(b), median_mRNA=a.median(), median_Fluarix=b.median(),
                   MWU_p=stats.mannwhitneyu(a, b).pvalue))
rp = pd.DataFrame(rp)
log(rp.round(4).to_string(index=False))
save(rp.round(4), "10_repertoire_igm_summary.csv")
ovl["arm"] = ovl.Participant.map(lambda p: "mRNA-1010" if p in ("397-06", "397-17", "397-28", "397-29") else "Fluarix")
log(ovl.to_string(index=False))

# ============================================================================
section("11. PLANNING PARAMETERS FOR THE NEXT STUDIES")
# ============================================================================
z = stats.norm.ppf
def n_per_arm(sd, gmr, alpha=0.05, power=0.9):
    d = np.log2(gmr)
    return math.ceil(2 * sd ** 2 * (z(1 - alpha / 2) + z(power)) ** 2 / d ** 2)
sds = {
    "seq-neut H3 contemporary composite, d29 ANCOVA residual SD": float(compA[(compA.subtype == "H3N2") & (compA.class_.str.startswith("contemporary"))].d29_resid_sd.iloc[0]),
    "seq-neut H1 contemporary composite, d29 ANCOVA residual SD": float(compA[(compA.subtype == "H1N1") & (compA.class_.str.startswith("contemporary"))].d29_resid_sd.iloc[0]),
    "HAI A/H1N1 wk4 ANCOVA residual SD": float(hai_cmp[hai_cmp.antigen == "A/H1N1"].resid_sd_log2.iloc[0]),
    "HAI A/H3N2 wk4 ANCOVA residual SD": float(hai_cmp[hai_cmp.antigen == "A/H3N2"].resid_sd_log2.iloc[0]),
}
# single-virus SD (median across contemporary viruses)
sv = []
for v, g in W[W.class_.str.startswith("contemporary")].groupby("virus"):
    g2 = g.dropna(subset=["d0", "d29"])
    sv.append(ancova(g2, "d29", "d0")["resid_sd_log2"])
sds["seq-neut single contemporary virus, d29 ANCOVA residual SD (median over viruses)"] = float(np.median(sv))
rows = []
for k, sd in sds.items():
    for gmr in [1.25, 1.5, 2.0]:
        rows.append(dict(variance_source=k, resid_SD_log2=round(sd, 3), target_GMR=gmr,
                         n_per_arm_90pct_power_2sided_a05=n_per_arm(sd, gmr),
                         n_per_arm_80pct_power=n_per_arm(sd, gmr, power=0.8)))
ss = pd.DataFrame(rows)
log(ss.to_string(index=False))
save(ss, "11_sample_size_immunogenicity.csv")
# detectable GMR in WU397 (n=13/14, 80% power)
mde = []
for k, sd in sds.items():
    n = 13.5
    d = (z(0.975) + z(0.8)) * sd * np.sqrt(2 / n)
    mde.append(dict(variance_source=k, resid_SD_log2=round(sd, 3), WU397_min_detectable_GMR_80pct=round(2 ** d, 2)))
mde = pd.DataFrame(mde)
log(mde.to_string(index=False))
save(mde, "11_wu397_minimum_detectable_effect.csv")

# event-driven efficacy: cases needed for rVE (1:1), conditional binomial, two-sided alpha 0.05
def events_needed(rve, power=0.9, alpha=0.05, lb=0.0):
    # H0: rVE = lb ; H1: rVE = rve. p = share of cases in the mRNA arm = (1-rVE)/(2-rVE)
    p0 = (1 - lb) / (2 - lb); p1 = (1 - rve) / (2 - rve)
    za, zb = z(1 - alpha / 2), z(power)
    n = ((za * np.sqrt(p0 * (1 - p0)) + zb * np.sqrt(p1 * (1 - p1))) / (p0 - p1)) ** 2
    return math.ceil(n)
ev = []
for rve in [0.15, 0.20, 0.25, 0.30, 0.40]:
    for frac in [1.0, 0.5, 0.3]:
        e_ = events_needed(rve)
        ev.append(dict(true_rVE=rve, power=0.9, alpha_2sided=0.05, H0_rVE=0.0, cases_needed_in_stratum=e_,
                       assumed_share_of_cases_that_are_antigenically_mismatched=frac,
                       total_cases_needed_for_mismatched_stratum=math.ceil(e_ / frac)))
ev = pd.DataFrame(ev)
log(ev.to_string(index=False))
save(ev, "11_events_needed_efficacy.csv")

# ----------------------------------------------------------------------------
# Figures
# ----------------------------------------------------------------------------
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# Fig 1: participant-level composites (the primary interpretation)
cls_order = [("H3N2", "vaccine reference, cell (mRNA-1010 immunogen)", "H3 vaccine ref. A/Darwin/6/2021 (cell)"),
             ("H3N2", "vaccine reference, egg-based (Fluarix 2022-23 reference)", "H3 vaccine ref. A/Darwin/9/2021 (egg)"),
             ("H3N2", "contemporary drifted isolate (2022-24)", "H3 drifted 2022-24 isolates (68)"),
             ("H3N2", "historical wild-type", "H3 historical 2012-2020 (8)"),
             ("H1N1", "Fluarix H1 counterpart (cell-based 2022-23 reference)", "H1 A/Wisconsin/588/2019 (Fluarix-H1-like)"),
             ("H1N1", "mRNA-1010 H1 counterpart (cell-based, same 2023-24 recommendation)", "H1 A/Wisconsin/67/2022 (doc. mRNA-H1-like)"),
             ("H1N1", "mRNA-1010 H1 (documented immunogen, egg reassortant IVR-238)", "H1 A/Victoria/4897/2022 IVR-238"),
             ("H1N1", "contemporary drifted isolate (2022-24)", "H1 drifted 2023 isolates (6)"),
             ("H1N1", "historical wild-type", "H1 historical 2009-2019 (4)")]
fig, ax = plt.subplots(figsize=(9, 5.5))
yl = []
for i, (sub, cl, lab) in enumerate(cls_order):
    r = compA[(compA.subtype == sub) & (compA.class_ == cl)].iloc[0]
    y = len(cls_order) - i
    ax.errorbar(r.d29_adjGMR, y + 0.12, xerr=[[r.d29_adjGMR - r.d29_adj_lo], [r.d29_adj_hi - r.d29_adjGMR]], fmt="o", color="C0", label="day 29" if i == 0 else None)
    ax.errorbar(r.late_adjGMR, y - 0.12, xerr=[[r.late_adjGMR - r.late_adj_lo], [r.late_adj_hi - r.late_adjGMR]], fmt="s", color="C1", label="day 121/181" if i == 0 else None)
    yl.append((y, lab))
ax.axvline(1, color="k", lw=0.8)
ax.set_xscale("log", base=2)
ax.set_yticks([a for a, b in yl]); ax.set_yticklabels([b for a, b in yl], fontsize=8)
ax.set_xlabel("Baseline-adjusted neutralising GMT ratio, mRNA-1010 / Fluarix (95% CI)\nparticipant-level composite; 13 vs 14 participants")
ax.set_title("Sequencing-based neutralisation: H3N2 (shared reference strain) shows no advantage;\nH1N1 ~2-fold at day 29 (antigen-confounded), not sustained", fontsize=9)
ax.legend(fontsize=8, loc="upper right")
plt.tight_layout(); plt.savefig(os.path.join(FIG, "fig1_seqneut_composites.png"), dpi=150); plt.close()

# Fig 2: per-virus
order = ["historical wild-type", "production/egg reassortant of historical strain", "Fluarix H1 counterpart (cell-based 2022-23 reference)",
         "mRNA-1010 H1 (documented immunogen, egg reassortant IVR-238)", "mRNA-1010 H1 counterpart (cell-based, same 2023-24 recommendation)",
         "vaccine reference, cell (mRNA-1010 immunogen)", "vaccine reference, egg-based (Fluarix 2022-23 reference)", "contemporary drifted isolate (2022-24)"]
fig, axes = plt.subplots(1, 2, figsize=(16, 11), gridspec_kw=dict(width_ratios=[1, 1]))
for ax, sub in zip(axes, ["H1N1", "H3N2"]):
    d = pv[pv.subtype == sub].copy()
    d["o"] = d.class_.map({c: i for i, c in enumerate(order)})
    d = d.sort_values(["o", "d29_adjGMR"])
    y = np.arange(len(d))
    cols = plt.cm.tab10(d.o.values)
    ax.errorbar(d.d29_adjGMR, y, xerr=[d.d29_adjGMR - d.d29_adjGMR_lo, d.d29_adjGMR_hi - d.d29_adjGMR], fmt="none", ecolor="grey", lw=0.6)
    ax.scatter(d.d29_adjGMR, y, c=cols, s=16, zorder=3)
    ax.axvline(1, color="k", lw=0.8)
    ax.set_xscale("log", base=2)
    ax.set_yticks(y); ax.set_yticklabels(d.virus.str.replace("_H3N2", "").str.replace("_H1N1", ""), fontsize=5.5 if sub == "H3N2" else 8)
    ax.set_xlabel("Baseline-adjusted d29 neutralising GMT ratio, mRNA-1010 / Fluarix (95% CI)")
    ax.set_title(f"{sub}: per virus (13 vs 14 participants; no virus significant after BH correction)", fontsize=9)
handles = [plt.Line2D([], [], marker="o", ls="", color=plt.cm.tab10(i), label=c) for i, c in enumerate(order)]
fig.legend(handles=handles, loc="lower center", ncol=3, fontsize=8)
plt.tight_layout(rect=(0, 0.06, 1, 1)); plt.savefig(os.path.join(FIG, "fig2_seqneut_per_virus_adjGMR.png"), dpi=150); plt.close()

# Fig 3: binding vs function, same 27-29 participants
fig, ax = plt.subplots(figsize=(8, 5))
lab = ["bead_Darwin6_log2FC", "ELISA_H3_log2FC", "HAI_H3_log2FC", "NEUT_Darwin6_log2FC", "bead_W588_log2FC", "ELISA_H1_log2FC", "HAI_H1_log2FC", "NEUT_W588_log2FC"]
nice = ["H3 bead binding\n(A/Darwin/6/2021)", "H3 ELISA IgG", "H3 HAI", "H3 neutralisation\n(A/Darwin/6/2021)",
        "H1 bead binding\n(A/Wisconsin/588/2019)", "H1 ELISA IgG", "H1 HAI", "H1 neutralisation\n(A/Wisconsin/588/2019)"]
b2 = bf.set_index("readout").loc[lab]
colors = ["C3", "C3", "C0", "C0", "C3", "C3", "C0", "C0"]
for i, (r, c) in enumerate(zip(b2.itertuples(), colors)):
    ax.errorbar(i, r.ratio, yerr=[[r.ratio - r.lo], [r.hi - r.ratio]], fmt="o", color=c)
ax.axhline(1, color="k", lw=0.8); ax.set_yscale("log", base=2); ax.axvline(3.5, color="grey", lw=0.5, ls=":")
ax.set_xticks(range(len(lab))); ax.set_xticklabels(nice, rotation=45, ha="right", fontsize=7)
ax.set_ylabel("Ratio of fold-rises (wk4/d29 over d0), mRNA-1010 / Fluarix (95% CI)\n[bead-array timepoint not stated in package]", fontsize=8)
ax.set_title("Same participants: H3 binding rises 4-6x more with mRNA-1010 but H3 function does not;\nH1 binding and neutralisation rise together (red = binding, blue = functional)", fontsize=8)
plt.tight_layout(); plt.savefig(os.path.join(FIG, "fig3_binding_vs_function.png"), dpi=150); plt.close()
for f_ in ["seqneut_per_virus_adjGMR.png", "binding_vs_function.png"]:
    if os.path.exists(os.path.join(FIG, f_)):
        os.remove(os.path.join(FIG, f_))

with open(os.path.join(OUT, "analysis_log.txt"), "w") as f:
    f.write(LOG.getvalue())
print("done")
