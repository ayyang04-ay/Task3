#!/usr/bin/env python
"""Planning arithmetic for the recommended next studies (design-level only).
All inputs are either WU397-derived variances (tables/11_sample_size_immunogenicity.csv)
or explicitly labelled ASSUMPTIONS. Run: micromamba run -n core python wu397_planning.py"""
import math
import numpy as np, pandas as pd
from scipy import stats
z = stats.norm.ppf
TAB = "/tmp/outputs/analysis/tables"
rows = []

def n_arm(sd, gmr, power=0.9, alpha=0.05):
    return math.ceil(2 * sd ** 2 * (z(1 - alpha / 2) + z(power)) ** 2 / np.log2(gmr) ** 2)

def det_gmr(sd, n, power=0.9, alpha=0.05):
    return 2 ** ((z(1 - alpha / 2) + z(power)) * sd * np.sqrt(2 / n))

# Study A: immunogenicity breadth, composite neutralisation endpoint
for sd, src in [(1.023, "WU397 H3 drifted-panel composite residual SD (tables/11)"),
                (0.938, "WU397 H1 drifted-panel composite residual SD (tables/11)"),
                (1.3, "ASSUMPTION: inflated SD for a multi-site, mixed-age, mixed-history population")]:
    for g in [1.25, 1.4, 1.5, 2.0]:
        rows.append(dict(study="A", quantity="evaluable n per arm, 90% power, 2-sided alpha 0.05", sd_log2=sd, sd_source=src, target_GMR=g, value=n_arm(sd, g)))
    rows.append(dict(study="A", quantity="GMR detectable with 90% power at 150 evaluable per arm", sd_log2=sd, sd_source=src, target_GMR=np.nan, value=round(det_gmr(sd, 150), 2)))
rows.append(dict(study="A", quantity="randomised per arm for 150 evaluable at 15% non-evaluable (ASSUMPTION)", sd_log2=np.nan, sd_source="", target_GMR=np.nan, value=math.ceil(150 / 0.85)))
# observed WU397 H3 point estimate: what n would be needed to confirm it
rows.append(dict(study="A", quantity="n per arm to confirm the WU397 H3 point estimate (GMR 1.17) with 90% power", sd_log2=1.023, sd_source="WU397", target_GMR=1.17, value=n_arm(1.023, 1.17)))

# Study B: efficacy, conditional-binomial events for rVE vs H0 rVE=0, 1:1
def events(rve, power=0.9, alpha=0.05):
    p0, p1 = 0.5, (1 - rve) / (2 - rve)
    return math.ceil(((z(1 - alpha / 2) * np.sqrt(p0 * (1 - p0)) + z(power) * np.sqrt(p1 * (1 - p1))) / (p0 - p1)) ** 2)
for rve in [0.2, 0.25, 0.3]:
    for pw in [0.8, 0.9]:
        rows.append(dict(study="B", quantity=f"mismatched-strain cases needed (rVE {rve:.0%}, power {pw:.0%})", sd_log2=np.nan, sd_source="", target_GMR=np.nan, value=events(rve, pw)))
e = events(0.25, 0.9)
for share in [0.5, 0.3]:
    tot = math.ceil(e / share)
    rows.append(dict(study="B", quantity=f"total cases if {share:.0%} of cases are mismatched (ASSUMPTION)", sd_log2=np.nan, sd_source="", target_GMR=np.nan, value=tot))
    for ar in [0.02, 0.03]:
        n = math.ceil(tot / (ar / 2 * (1 + 0.75)))
        rows.append(dict(study="B", quantity=f"participant-seasons for {tot} cases at comparator-arm attack rate {ar:.0%}/season, rVE 25% (ASSUMPTIONS)", sd_log2=np.nan, sd_source="", target_GMR=np.nan, value=n))

# Study C: CHIM, two-proportion comparison (ASSUMPTIONS: 50% vs 20% symptomatic infection)
def n_two_prop(p1, p2, power=0.8, alpha=0.05):
    pb = (p1 + p2) / 2
    return math.ceil(((z(1 - alpha / 2) * np.sqrt(2 * pb * (1 - pb)) + z(power) * np.sqrt(p1 * (1 - p1) + p2 * (1 - p2))) / (p1 - p2)) ** 2)
rows.append(dict(study="C", quantity="per arm, 80% power: 50% vs 20% lab-confirmed symptomatic infection (ASSUMPTIONS)", sd_log2=np.nan, sd_source="", target_GMR=np.nan, value=n_two_prop(0.5, 0.2)))
rows.append(dict(study="C", quantity="per arm, 80% power: 40% vs 20% (ASSUMPTIONS)", sd_log2=np.nan, sd_source="", target_GMR=np.nan, value=n_two_prop(0.4, 0.2)))
out = pd.DataFrame(rows)
pd.set_option("display.width", 250); pd.set_option("display.max_colwidth", 120)
print(out.to_string(index=False))
out.to_csv(f"{TAB}/15_planning_numbers.csv", index=False)
