**Recommendation:** Don't build the heterologous-protection claim on WU397 (no neutralising-breadth gain on the one strain-matched subtype, H3N2; the ~2-fold H1N1 gain is antigen-confounded and gone by day 121–181) — next, run a randomised, observer-blind, strain-matched breadth study (mRNA vs same-season egg-based and non-egg licensed vaccines, adults 18–64 and ≥65; primary endpoint day-29 neutralising titre against a pre-specified drifted-strain panel), and only if it shows a ≥1.5-fold advantage lasting to day 181, an event-driven active-controlled efficacy trial with relative efficacy against sequence-confirmed mismatched influenza as the claim-carrying endpoint.

---

## 1. The short version for the committee

1. **The package contains no evidence of protection.** There are no clinical endpoints, and there is no accepted correlate of protection against drifted strains. Even a clean immunogenicity advantage would not support a claim that uses the word "protection" (section 3, Study B).
2. **The two arms did not get the same antigens, and "heterologous" was defined against one arm only.**
   - mRNA-1010's documented H1 is A/Victoria/4897/2022, a strain WHO recommended for 2023–24. Fluarix 2022–23 contains A/Victoria/2570/2019 [TS; EXT].
   - The package labels strains homologous or heterologous relative to the mRNA antigens only [TS]. So A/Wisconsin/588/2019 counts as "heterologous", even though it is the cell-based counterpart of **Fluarix's own** H1.
3. **Where the comparison is fair (H3N2: A/Darwin/6/2021 cell vs A/Darwin/9/2021 egg), mRNA-1010 showed no neutralising-breadth advantage.**
   - Against 68 drifted 2022–24 H3N2 isolates, the baseline-adjusted day-29 GMT ratio (mRNA/Fluarix) was **1.17 (95% CI 0.64–2.11)**. At day 121/181 it was 1.04 (0.65–1.67) [T07].
   - Against its own H3 immunogen, A/Darwin/6/2021, the mRNA arm was numerically lower: 0.62 (0.34–1.12) [T07].
4. **The H1N1 advantage is real in this dataset but can't carry the claim.**
   - The adjusted ratio against six drifted 2023 H1N1 isolates was **2.06 (1.23–3.46)**, robust to every sensitivity check [T07, T12, T13].
   - It is (a) confounded by antigen choice and by uncertainty over which H1 was actually given; (b) a uniform rise in magnitude, not breadth — the drop-off from vaccine-like to drifted strains was the same in both arms (ratio 0.88, p=0.53) [T14]; and (c) gone by day 121/181: 1.17 (0.78–1.77) [T07].
5. **Much of the extra H3 antibody from mRNA-1010 binds but does not neutralise.** In the same participants:
   - H3 binding rose 3.8–6.1× more in the mRNA arm.
   - H3 HAI rose 1.03× more and H3 neutralisation 0.82× as much [T08].
   - The striking bead-array "breadth" (e.g. 9.5× more binding to A/Hong Kong/1/1968) [T06] is not evidence of protective breadth.
6. **WU397 is built to generate hypotheses, not test them.**
   - Allocation was by site, not randomised, and the trial was open-label [TS]. Serum IDs in the neutralisation file carry the arm name, so the testing lab was probably not blinded [T02].
   - There are no data on age, prior vaccination or infection [T02].
   - The functional assays had 13–15 participants per arm, so the smallest detectable GMT ratio was about 1.9–2.3 [T11].
   - Labels and cohorts are inconsistent across several files (section 2.6).
7. **The mechanistic signal is real but upstream of protection.** mRNA-1010 gave larger, longer-lasting germinal-centre (GC) responses: week-2 median 24.2% vs 2.3% HA-specific GC B cells [T10]. It also produced more new serum clonotypes: 32 vs 17.5 [T10]. That is a reason to run Study A, not a substitute for it.

---

## 2. What the WU397 package shows

### 2.1 Antigen composition: the arms are not matched, and "heterologous" is one-sided

| Component | mRNA-1010 (trial_summary.md) [TS] | Fluarix 2022–23 NH (WHO egg-based recommendation / label) [EXT] | Consequence |
|---|---|---|---|
| H1N1 | A/Victoria/4897/2022-like (a WHO 2023–24 strain; cell counterpart A/Wisconsin/67/2022) | A/Victoria/2570/2019-like (cell counterpart A/Wisconsin/588/2019) | **Different antigens.** Drifted 2023 H1 isolates sit in the antigenic group WHO went on to represent with A/Victoria/4897/2022 [EXT], which favours mRNA. A/Wisconsin/588/2019 is "heterologous" in the package but homologous to Fluarix. |
| H3N2 | A/Darwin/6/2021 (cell) | A/Darwin/9/2021 (egg) | Same WHO antigenic reference (A/Darwin/…/2021-like); cell isolate vs egg isolate. **This is the cleanest platform comparison.** |
| B/Victoria | B/Austria/1359417/2021 | same | Matched, but no breadth panel exists for B. |
| B/Yamagata | B/Phuket/3073/2013 | same | Lineage no longer circulating; drop it from future formulations [EXT]. |

**The administered H1 needs checking before any H1 strain is called "heterologous".**
- The documented H1 was recommended by WHO only in February 2023 for 2023–24, after the 2022–23 vaccinations [EXT].
- In the serology, the mRNA arm's largest H1 rise was against A/Wisconsin/588/2019: geometric mean fold-rise (GMFR) **6.15**. The rise was smaller against the documented immunogen's counterparts: A/Wisconsin/67/2022 3.51 and A/Victoria/4897/2022 IVR-238 3.97.
- Within participants, the A/Wisconsin/588/2019 rise was 1.75× the A/Wisconsin/67/2022 rise (p=0.005), and was larger in 12 of 13 participants [T07].
- mAbs from mRNA donors also bind A/Wisconsin/588/2019 more strongly than A/Victoria/4897/2022: median fold-over-control about 207–288 vs 48–99 across donors [T09].
- So either the administered H1 was A/Wisconsin/588/2019-like, or the response was dominated by memory B cells primed by earlier A/Wisconsin/588/2019-like exposure. The lot records must settle this (Gate 0).

### 2.2 Functional breadth: sequencing-based neutralisation

This file has 96 H1/H3 viruses; 13 mRNA and 14 Fluarix participants; sampled at day 0, day 29 and day 121/181.

I re-classified every panel strain against **both** arms' vaccine strains [T07, virus classification table]. Five production or egg reassortants were kept out of the drifted panels. Their baseline titres run 1.6–7.1× higher than their wild-type counterparts (paired p<0.001) [T07 egg-vs-wild-type table], so including them would inflate any breadth index.

The participant is the unit of analysis throughout. Ratios are mRNA/Fluarix, adjusted for baseline by ANCOVA [T07 composites table].

| Panel (no. of viruses) | GMT d0 mRNA / Flu | GMT d29 mRNA / Flu | GMFR mRNA / Flu | **Adj. GMT ratio, d29 (95% CI)** | Adj. GMT ratio, d121/181 (95% CI) |
|---|---|---|---|---|---|
| H3N2 drifted 2022–24 isolates (68) | 143 / 214 | 401 / 465 | 2.80 / 2.17 | **1.17 (0.64–2.11), p=0.60** | 1.04 (0.65–1.67) |
| H3N2 A/Darwin/6/2021 (mRNA immunogen) (1) | 109 / 176 | 244 / 482 | 2.24 / 2.74 | 0.62 (0.34–1.12) | 0.72 (0.40–1.31) |
| H3N2 A/Darwin/9/2021 (Fluarix reference) (1) | 211 / 343 | 1009 / 1539 | 4.78 / 4.49 | 0.81 (0.35–1.87) | 0.57 (0.25–1.27) |
| H3N2 historical 2012–2020 (8) | 410 / 708 | 1520 / 1268 | 3.70 / 1.79 | 1.63 (0.99–2.69), p=0.056 | 1.45 (0.88–2.39) |
| H1N1 drifted 2023 isolates (6) | 117 / 132 | 478 / 257 | 4.07 / 1.95 | **2.06 (1.23–3.46), p=0.008** | 1.17 (0.78–1.77) |
| H1N1 A/Wisconsin/588/2019 (Fluarix-H1-like) (1) | 175 / 216 | 1073 / 506 | 6.15 / 2.34 | 2.44 (1.18–5.05) | 1.17 (0.62–2.23) |
| H1N1 A/Wisconsin/67/2022 (documented mRNA-H1-like) (1) | 123 / 116 | 431 / 197 | 3.51 / 1.69 | 2.07 (1.26–3.39) | 1.23 (0.83–1.84) |
| H1N1 A/Victoria/4897/2022 IVR-238 (1) | 580 / 601 | 2300 / 1467 | 3.97 / 2.44 | 1.60 (0.92–2.78) | 1.05 (0.60–1.83) |
| H1N1 historical 2009–2019 (4) | 706 / 855 | 2533 / 1687 | 3.59 / 1.97 | 1.69 (0.91–3.13) | 1.11 (0.61–2.03) |

How to read the table:

- **The mRNA arm's H3 fold-rise advantage comes from its lower baseline.**
  - Its baseline against the drifted H3 panel was 0.67× Fluarix's (p=0.12).
  - Its day-29 titre was actually lower: 401 vs 465, an unadjusted ratio of 0.86.
  - After baseline adjustment, the GMFR ratio of 1.29 (0.74–2.26) shrinks to 1.17 [T07].
- **The H3 null result holds up in every sensitivity analysis:**
  - permutation p=0.60;
  - excluding the later WHO reference strains: 1.18;
  - 2023–24 isolates only: 1.17 [T12];
  - leave-one-out range 1.03–1.33, never significant;
  - median regression 1.30 (0.63–2.66) [T13];
  - censored titres set to half the limit: 1.18 (0.65–2.14) [T07 censoring-sensitivity table].
  - Against A/District of Columbia/27/2023, later the 2025–26 cell-based H3 reference [EXT], day-29 GMTs were 122 vs 150 and the adjusted ratio was 1.21 (0.68–2.16) [T07 per-virus table; T12].
- **The H3 advantage that does appear is backward, towards strains from 2012–2020 (back-boosting).** It is not forward drift: the historical GMFR ratio was 2.07 (1.10–3.88) [T07].
- **The mRNA H3 profile is "flatter" only because its vaccine-strain titre is lower.** Drifted-panel titre relative to A/Darwin/6/2021 was 1.65 vs 0.97 (ratio 1.71, p=0.014). Absolute titres against the drifted strains were no higher [T14].
- **The H1 advantage is robust within this dataset:**
  - permutation p=0.011 [T12];
  - all 27 leave-one-out fits p<0.05, range 1.90–2.31 [T13];
  - censored titres set to half the limit: 1.95 (1.19–3.20) [T07 censoring-sensitivity table];
  - median share of drifted H1 strains with a ≥4-fold rise: 50% vs 0% (p=0.006) [T12].
- **But it is uniform across H1 strains (1.60–2.44×), including the Fluarix-like A/Wisconsin/588/2019.** The drift penalty was not smaller with mRNA (ratio 0.88, p=0.53; or 0.85, p=0.29, using A/Wisconsin/67/2022) [T14].
- **The H1 advantage had waned by day 121/181 (1.17, 0.78–1.77).** Caveat: the late samples pool day 121 (2 mRNA, 4 Fluarix participants) with day 181.
- **No single virus differed after Benjamini–Hochberg correction (0 of 96)** [T07 per-virus table].
- **Treating virus × participant pairs as independent would manufacture a result.** For H3 that gives p=2.5×10⁻¹⁰, against p=0.82 with the participant as the unit (mixed model) [T07 mixed-model table].

### 2.3 Binding is not function

| Readout (same 27–29 participants) [T08] | Ratio of fold-rises, mRNA/Fluarix (95% CI) |
|---|---|
| H3 bead-array binding, A/Darwin/6/2021 | 6.10 (2.20–16.9) |
| H3 ELISA IgG | 3.81 (2.07–7.02) |
| H3 HAI | 1.03 (0.65–1.66) |
| H3 neutralisation, A/Darwin/6/2021 | 0.82 (0.41–1.62) |
| H1 bead-array binding, A/Wisconsin/588/2019 | 2.04 (1.01–4.10) |
| H1 ELISA IgG | 2.29 (1.18–4.43) |
| H1 HAI | 1.23 (0.63–2.41) |
| H1 neutralisation, A/Wisconsin/588/2019 | 2.62 (1.19–5.78) |

- **Full ELISA cohort (38 vs 37)** [T05]. Week-4 baseline-adjusted ratios:
  - H1 2.66 (2.01–3.53); H3 3.31 (2.47–4.43); B/Vic 1.35 (1.04–1.76); B/Yam 1.38 (1.11–1.71).
  - At week 17/26: H1 1.51, H3 2.06, B/Vic 0.99, B/Yam 1.06.
- **Bead array** (timepoint not stated) [T06]:
  - The mRNA/Fluarix ratio of fold-rises was 5.75 (2.87–11.5) for the H3 composite and 1.86 (1.06–3.28) for the H1 composite.
  - The largest H3 ratios were against A/Hong Kong/1/1968 (9.51) and A/Thailand/8/2022 (9.45).
  - For H3, this binding excess is not matched by neutralisation in the same people. It may have Fc-mediated activity, but that was not measured.

### 2.4 Conventional endpoints

**HAI (14 vs 15)** [T03]:
- Week-4 adjusted GMT ratios: H1 1.54 (0.87–2.71); H3 1.06 (0.67–1.66); B/Vic 1.05 (0.71–1.56); B/Yam 1.01 (0.73–1.40).
- GMFRs were 1.05–2.76 in both arms.
- Seroconversion, mRNA vs Fluarix: H1 50% vs 33%; H3 14% vs 13%; B/Vic 0% vs 7%; B/Yam 0% vs 7%.
- No arm met the conventional CBER bar of a lower 95% confidence bound ≥40% for seroconversion, for any antigen [T12; EXT]. The mRNA arm's H3 seroprotection was 64% (lower bound 39%).
- HAI is known to be unreliable for recent H3N2 [EXT]. It was uncorrelated with the other H3 readouts here (Spearman |ρ| ≤0.24 within either arm) [T08].

**Microneutralisation (14 vs 15; the panel strains are not identified anywhere in the package)** [T04]:
- "Heterologous" panel:
  - The mRNA arm started at half the Fluarix titre: baseline ratio 0.47 (p=0.050).
  - Its higher GMFR (4.12 vs 3.03) and 4-fold responder rate (9/14 vs 6/15) reflect that low baseline.
  - Its week-4 GMT was lower (235 vs 368), and the adjusted ratio was 1.17 (0.52–2.62).
- "Homologous" panel: adjusted ratio 0.68 (0.31–1.51); Tobit model 0.47 (0.15–1.50).
- At week 4, 9/15 Fluarix and 4/14 mRNA homologous titres sat at the 1:1280 ceiling.

### 2.5 Mechanistic data: a plausible mechanism, not evidence of protection

- **Lymph-node GC B cells** (first of two unlabelled blocks in gc_frequencies.csv; 6 vs 11 participants) [T10]. Median % HA-specific IgG GC B cells, mRNA vs Fluarix:

  | Week | mRNA | Fluarix | p |
  |---|---|---|---|
  | 2 | 24.2% | 2.3% | 0.037 |
  | 8 | 8.3% | 1.7% | 0.17 |
  | 17 | 16.0% | 2.3% | 0.083 |
  | 26 | 18.9% | 1.6% | 0.34 |

  The second block points the same way, but what it measures is unidentified.
- **Serum repertoire (8 vs 8; no participant IDs, so it can't be linked to serology)** [T10]:
  - Vaccine-elicited clonotypes: 32 vs 17.5 (p=0.066).
  - About 87–89% of post-vaccination clonotype abundance was pre-existing in both arms (p=0.72): responses are dominated by recall in both.
  - CDR-H3 diversity at week 4: 70.8 vs 24.5 (p=0.010).
- **Clonal overlap.** 73–92% of GC clones overlapped week-1 plasmablast clones in the 4 mRNA donors (raw: pb_gc_clonal_overlap.csv).
- **mAbs** [T09]:
  - 589 mAbs came from 4 mRNA donors; 106 from 3 Fluarix donors, 84 of them from one donor.
  - With donor as the unit, the smallest attainable p-value is 0.057.
  - Example: mAbs binding A/Hong Kong/1/1968 averaged 45.7% vs 5.3% of a donor's mAbs. That is p=0.057 by donor, versus p=0.001 if mAbs are wrongly pooled.
  - Cross-subtype binding was rare: H5 3.1% vs 1.6%; H7 9.6% vs 0%. There is no basis for any cross-subtype claim.
- **IgM.** Rises were larger with Fluarix (median fold-rise 2.96 vs 1.0 for H3 and both B lineages; p=0.013–0.049) [T10].

### 2.6 Design and data-integrity limitations

Details are in [T01] and [T02].

| Issue | Evidence | Consequence |
|---|---|---|
| Not randomised; allocation by site; open-label | [TS]. IDs 033–059 are all Fluarix and 064–102 all mRNA. Within Fluarix, baseline B titres differ by ID block (p=0.011 B/Vic, 0.030 B/Yam) [T05] | Arm is confounded with site and population |
| Testing lab probably not blinded | Serum IDs in neutralization_seqbased.csv contain the arm name [T02] | Possible detection bias |
| No demographics, prior vaccination, prior infection or dose data | Whole package [T02] | The main drivers of breadth can't be adjusted for |
| Baseline imbalance | Drifted H3 neutralisation 0.67×; MN heterologous 0.47× [T07, T04] | Fold-rise comparisons favour mRNA |
| Underpowered | 13–15 per arm; smallest detectable GMT ratio 1.9–2.3 at 80% power [T11] | Realistic effects (1.25–1.5) could not be detected |
| Cohort table wrong for IgM | 14/15 in the file vs 38/37 stated [T01] | Misreported cohort |
| Visit labels inconsistent | HAI B/Vic week-17/26 labels clash with the other three antigens for 8 participants; seq-neut marks 007 and 011 as day 121 where the other assays have week 26; week 17 and week 26 pooled [T02] | Durability can't be read at a fixed time |
| GC file | Two unlabelled blocks with identical keys; a week-0 FNA that the protocol doesn't include; protocol weeks 1 and 4 absent [T02] | Can't verify what was measured |
| "Plasmablast" file | FNA-only timepoints (weeks 2 and 8); 11 participants outside the 6 + 11 FNA subset; values at lower precision [T01, T02] | Provenance unclear; not relied on |
| MN and bead array | MN strains never identified; 1:1280 ceiling; bead-array timepoint not stated; uniform falls across all strains in some participants [T02, T04] | Can't be used for a breadth claim |
| No influenza B breadth data | Seq-neut and mAb panels cover H1/H3 only | B breadth unknown |

### 2.7 What the package does and does not support

**Supported (hypothesis-generating):**
- mRNA-1010 is immunogenic.
- It induces more HA-binding IgG.
- It drives larger and more persistent GC responses.
- It gave about 2-fold higher H1N1 neutralisation at day 29, confounded as described above.

**Not supported:**
- Heterologous protection of any kind.
- Broader neutralisation of drifted H3N2.
- A neutralisation advantage lasting through the season.
- Any influenza B breadth.
- Any cross-subtype (H5/H7) breadth.

---

## 3. Recommended next studies

### Gate 0 — fix the data package before the protocol goes to committee (no new participants)

1. **Verify composition from lot records for both arms.** Resolve the H1 question: documented A/Victoria/4897/2022 vs a serology pattern favouring A/Wisconsin/588/2019 (section 2.1).
2. **Fill the gaps and correct the labels:**
   - Identify the MN strains and the bead-array timepoint.
   - Label the GC blocks.
   - Document the plasmablast file: tissue, denominator, participants.
   - Correct the IgM cohort.
   - Fix the HAI B/Vic and seq-neut visit labels, and report week 17 and week 26 separately.
3. **Retrieve participant data and re-run the adjusted analyses.** Get age, sex, site, vaccination history for the past 3 or more seasons, and any influenza-like illness (ILI) history for the WU397 participants.
4. **Present WU397 to the committee as hypothesis-generating.** No "heterologous" or "protection" language.

### Study A — randomised, observer-blind, strain-matched breadth study (Phase 2b)

*This is the study that tests whether the platform, given the same strains, broadens functional immunity.*

| Element | Specification |
|---|---|
| **Question** | Given the same HA strains, does the mRNA vaccine produce higher neutralising titres against antigenically drifted strains than licensed vaccines, and does that last through the season? |
| **Design** | Multicentre. Individual randomisation within site, stratified by age band and prior-season vaccination. Observer-blind: participants, assessors and laboratories blinded. Active-controlled. One season, plus extension (Study D). |
| **In whom** | **Cohort 1:** adults 18–64, stratified 18–49 and 50–64. **Cohort 2:** adults ≥65. Vaccination history documented for 3 or more prior seasons. Exclude anyone vaccinated against influenza, or with confirmed influenza, in the past 6 months. Record age, sex, comorbidities and site. Measure baseline titres as covariates, not as eligibility criteria. |
| **Against what (comparators)** | **Cohort 1, 1:1:1:** mRNA vs egg-based standard-dose inactivated vaccine (Fluarix) vs non-egg licensed vaccine (cell-culture or recombinant HA). The third arm separates a platform effect from an egg-adaptation effect. **Cohort 2, 1:1:** mRNA vs the vaccine preferentially recommended for ≥65 (high-dose, adjuvanted or recombinant) [EXT]. All products from the same season and hemisphere, trivalent (no B/Yamagata). The mRNA encodes the same WHO-recommended antigenic components as the comparators (cell/wild-type reference sequences), verified from lot records. If more than one mRNA dose is under consideration, add dose arms (WU397 does not state the dose). |
| **Primary readout (co-primary; both must succeed)** | Day-29 neutralising antibody titre against the pre-specified drifted-strain panel, summarised per participant as the geometric mean across panel strains. Tested separately for **(a) H3N2** and **(b) H1N1**. Estimand: baseline-adjusted GMT ratio, mRNA/comparator. |
| **Go criterion** | For each co-primary endpoint, within each cohort against its own comparator (egg-based vaccine in Cohort 1; enhanced vaccine in Cohort 2): point estimate ≥1.5 **and** lower 95% CI >1.0. In Cohort 1, report the same against the non-egg comparator. If the advantage holds only against egg-based vaccine, word the claim "vs egg-based vaccine". |
| **Key secondary readouts** | **Durability:** same composites at day 181 and day 365; lower CI >1.0 at day 181 is required for a season-long claim. **Breadth index:** drifted-panel titre ÷ vaccine-strain titre, to separate "broader" from merely "more". **Responders:** proportion with ≥4-fold rise against ≥50% of panel strains. **Homologous response:** HAI (H1, B) and neutralisation (H3N2) against each vaccine strain at day 29 — GMT ratio and seroconversion difference, estimated against the conventional margins of 1.5 and 10 percentage points [EXT]. **NA-inhibition titres** against vaccine and drifted N1/N2; the package implies HA-only antigens, whereas split vaccine carries NA. **B/Victoria** drifted panel. |
| **Exploratory readouts** | HA-binding IgG, to quantify the binding-to-neutralisation gap. Fc-effector activity against drifted HAs. HA-specific CD4 T-cell responses. A randomised mechanistic subset (about 20 per arm) for lymph-node GC and B-cell repertoire, analysed by donor. |
| **Panel: "against what" for the assays** | Fixed in the statistical analysis plan before unblinding, by an independent committee blinded to results. Wild-type isolates only; production/egg reassortants excluded from the index. Strains must be drifted relative to **both** arms' vaccine strains. Cover the clades circulating in the study season and the following one, weighted by frequency, and include next season's reference strains. Report historical strains separately: back-boosting is not heterologous protection. |
| **Timepoints** | Day 0, day 29 (primary), day 181, day 365. Fixed visit windows; no pooling of visits. |
| **Conduct** | Coded samples, with laboratories blind to arm and visit. PCR-confirmed ILI surveillance throughout. Participants with confirmed influenza are excluded from immunogenicity analyses after the infection and analysed separately. |
| **Analysis** | Participant is the unit. ANCOVA on log titres, adjusting for baseline and strata. Mixed model across panel strains as a sensitivity analysis. Censored titres handled explicitly. No pooled virus-level or mAb-level inference. |
| **Size** | About 150 evaluable per arm per cohort, roughly 177 randomised at 15% non-evaluable. That detects a GMT ratio of 1.40 with 90% power if the log₂ SD is 1.3. WU397 composite SDs were 0.94 (H1) and 1.02 (H3); 1.3 is an assumed inflation for a broader population. Total about 885 (5 arms × 177) [T15]. For scale: confirming WU397's H3 point estimate of 1.17 would need about 429 per arm [T15]. |
| **Decision** | Go to Study B only if the go criteria are met in the cohort(s) that match Study B's population. If H3N2 fails, don't pursue a general heterologous claim; an H1N1-only claim would need its own justification. |

### Study B — event-driven, active-controlled efficacy trial (Phase 3)

*This is the only study that can carry the word "protection".*

| Element | Specification |
|---|---|
| **Question** | Does the mRNA vaccine prevent more influenza caused by antigenically mismatched strains than a strain-matched licensed vaccine? |
| **Design** | Randomised 1:1, observer-blind, active-controlled. Multinational across both hemispheres; event-driven across as many seasons as needed. Composition updated each season in both arms. |
| **In whom** | Adults ≥50, stratified 50–64 and ≥65, by prior-season vaccination, and by region. Restrict to the cohort(s) that passed Study A. |
| **Against what** | A licensed, strain-matched, age-appropriate vaccine: standard-dose for 50–64; the preferentially recommended enhanced vaccine for ≥65. If standard-dose is used in ≥65, limit the ≥65 claim accordingly. |
| **Primary endpoint** | First episode of RT-PCR-confirmed, protocol-defined ILI (any strain), from day 15 to end of season. Relative vaccine efficacy (rVE): non-inferiority, then superiority. |
| **Claim-carrying key secondary** | The same endpoint, restricted to cases caused by **antigenically mismatched strains**. Every case virus is sequenced (HA, and NA where possible). Each case is classified as matched or mismatched to that season's vaccine strains, using a pre-specified rule based on clade and antigenic distance. Classification is done by a committee blinded to arm, before unblinding. |
| **Other secondaries** | rVE by subtype/lineage; rVE against matched strains; medically attended illness; hospitalisation or pneumonia; rVE by time since vaccination (waning within season). |
| **Correlates sub-study** | Case-cohort design: a random subcohort plus all cases. Measure day-29 neutralising titres against the strains actually circulating, plus HAI and NA inhibition. Analyse risk against titre, and whether the vaccine effect runs through drifted-strain neutralisation. This would make Study A-type data bridgeable in future seasons. |
| **Size (assumptions stated)** | 511 mismatched-strain cases for 90% power if the true rVE is 25% (383 for 80%). If about 50% of cases are mismatched, that means about 1,022 total cases: roughly 58,400 participant-seasons at a 2% comparator-arm attack rate, or 38,900 at 3%. If only 30% of cases are mismatched, about 1,704 cases are needed [T15]. |

### Study C (optional de-risking) — controlled human infection with a drifted challenge strain

| Element | Specification |
|---|---|
| **Question** | Before committing to Study B, does the mRNA vaccine protect better against a strain drifted away from the vaccine strain? |
| **In whom** | Healthy adults 18–45 eligible for challenge studies, with low baseline neutralising titre against the challenge strain. |
| **Against what** | mRNA vs strain-matched licensed comparator, with or without placebo. The challenge strain is a characterised wild-type strain of the same subtype, antigenically drifted from both arms' vaccine strains. |
| **Readouts** | **Primary:** laboratory-confirmed symptomatic infection. **Secondary:** viral shedding (amount and duration), symptom score, and pre-challenge neutralising titre against the challenge strain as a correlate. |
| **Size** | About 39 per arm if symptomatic infection falls from 50% to 20%; about 82 per arm if it falls from 40% to 20% (80% power; assumptions) [T15]. |
| **Limits** | One strain, young healthy adults, mild disease. Supportive only; it can't replace Study B. |

### Study D — durability and revaccination (extension of Study A)

| Element | Specification |
|---|---|
| **Question** | Does any breadth advantage survive the season and annual revaccination, and does it cover next season's drift? |
| **In whom** | Study A participants, staying in the same arm and revaccinated with next season's strain-matched composition. Optionally add a randomised comparator→mRNA switch arm. |
| **Readouts** | Neutralising titres against the season-2 drifted panel at day 365 (before revaccination) and day 29 after revaccination, using the same composites and indices. Continued ILI surveillance. |

### Rules that apply to all of these studies

These come directly from WU397's failure modes.

1. **Define the claim before the trial.** Protection against antigenically drifted strains of the vaccine subtypes and lineages, relative to a strain-matched licensed comparator. Cross-subtype (H5/H7) protection is a different claim and is not supported here.
2. **Match the strains.** Same-season composition in all arms, confirmed from lot records. Trivalent formulation.
3. **Define "heterologous" against every arm's vaccine strains.** Fix the panel in advance. Use wild-type isolates only.
4. **Compare baseline-adjusted post-vaccination titres, not fold-rises alone.**
5. **Analyse by participant (or by donor for mAbs).** Never by virus or mAb.
6. **Report every visit separately.**
7. **Blind the laboratories.** Collect demographics and exposure history. Run infection surveillance. Measure NA.

---

## 4. Where the numbers come from

Every number above is tagged with one of these keys. Tables are in `/tmp/outputs/analysis/tables/`.

| Key | Input file(s) in /tmp/world/filesystem | Output table(s) |
|---|---|---|
| [TS] | trial_summary.md | — (read directly: composition, design, cohort table, schedule) |
| [T01] | all CSVs vs trial_summary.md | 01_cohort_reconciliation.csv |
| [T02] | all files | 02_data_integrity_flags.csv |
| [T03] | hai_titers.csv | 03_hai_by_arm.csv, 03_hai_arm_comparison.csv |
| [T04] | microneutralization.csv | 04_mn_by_arm.csv, 04_mn_arm_comparison.csv |
| [T05] | elisa_igg_titers.csv | 05_elisa_by_arm.csv, 05_elisa_arm_comparison.csv, 05_elisa_within_arm_idblock_heterogeneity.csv |
| [T06] | binding_breadth_h1.csv, binding_breadth_h3.csv | 06_bead_binding_per_strain.csv, 06_bead_binding_composites.csv |
| [T07] | neutralization_seqbased.csv | 07_seqneut_virus_classification.csv, 07_seqneut_per_virus.csv, 07_seqneut_composites_primary.csv, 07_seqneut_composites_sens_censored_at_20.csv, 07_seqneut_mixed_model_and_pseudoreplication.csv, 07_seqneut_egg_vs_wildtype.csv, 07_seqneut_H1_immunogen_identity_check.csv |
| [T08] | hai, elisa, bead-array, seq-neut files (same participants) | 08_binding_vs_function_same_participants.csv, 08_binding_vs_function_participant_level.csv, 08_hai_correlation_with_other_readouts.csv |
| [T09] | mab_binding_panels.csv | 09_mab_counts_per_donor.csv, 09_mab_median_binding_per_donor.csv, 09_mab_breadth_donor_vs_pooled.csv (binding threshold ≥10-fold over control; ≥5 as sensitivity) |
| [T10] | gc_frequencies.csv, plasmablast_frequencies.csv, repertoire_clonotype_counts.csv, serum_igg_clonotypes.csv, cdrh3_diversity_index.csv, igm_fold_change.csv | 10_gc_by_timepoint.csv, 10_gc_block1_arm_comparison.csv, 10_plasmablast_file_summary.csv, 10_repertoire_igm_summary.csv |
| [T11] | derived from T03/T07 residual SDs | 11_sample_size_immunogenicity.csv, 11_wu397_minimum_detectable_effect.csv, 11_events_needed_efficacy.csv |
| [T12] | neutralization_seqbased.csv; T03 | 12_seqneut_sensitivity_permutation.csv (20,000 permutations), 12_responder_breadth*.csv, 12_participant_contemporary_composites.csv, 12_hai_vs_cber_benchmarks.csv |
| [T13] | T12 participant composites | 13_seqneut_leave_one_out.csv |
| [T14] | neutralization_seqbased.csv | 14_breadth_index_drift_penalty.csv |
| [T15] | T11 plus labelled assumptions | 15_planning_numbers.csv |
| raw | pb_gc_clonal_overlap.csv | read directly (overlap percentages as reported in the file) |

**External reference points (not in the package).** These come from my own knowledge and should be checked against the source documents:

- **WHO 2022–23 NH recommendation.** Egg-based: A/Victoria/2570/2019 (H1N1)pdm09-like; A/Darwin/9/2021 (H3N2)-like; B/Austria/1359417/2021; B/Phuket/3073/2013. Cell-based: A/Wisconsin/588/2019 and A/Darwin/6/2021. Fluarix is egg-based.
- **WHO 2023–24 NH.** H1 changed to A/Victoria/4897/2022 (egg) / A/Wisconsin/67/2022 (cell).
- **WHO 2024–25 NH.** H3 became A/Thailand/8/2022 (egg) / A/Massachusetts/18/2022 (cell); B/Yamagata no longer warranted.
- **WHO 2025–26 NH.** H3 became A/Croatia/10136RV/2023 (egg) / A/District of Columbia/27/2023 (cell).
- **FDA CBER 2007 seasonal inactivated influenza vaccine guidance.** Accelerated-approval bar for adults <65: lower 95% bound ≥40% for seroconversion and ≥70% for HI ≥1:40. Non-inferiority margins: GMT ratio 1.5 and seroconversion difference 10 percentage points.
- **US ACIP.** Preferential recommendation of high-dose, adjuvanted or recombinant vaccine for ≥65.
- **HAI for recent H3N2.** Known to be unreliable.

Check the Fluarix lot's labelled strain and reassortant names against the 2022–23 package insert.

**Assumptions (mine, labelled in [T15]):**
- A log₂ SD of 1.3 for Study A.
- 15% non-evaluable.
- A true rVE of 25%.
- A 30–50% share of mismatched cases.
- Comparator-arm attack rates of 2–3% per season.
- CHIM symptomatic-infection rates of 50% or 40% vs 20%.

**Design parameters (my recommendations, not derived from the data):**
- The ≥1.5 go threshold.
- The 6-month exclusion window.
- Vaccination history for 3 or more seasons.
- About 20 per arm for the mechanistic subset.
- Counting cases from day 15.
- The visit schedule.

Methods: titres were analysed on the log₂ scale. Censored values were kept at their bound, with sensitivity checks (section 2.2). Confidence intervals are Welch or ANCOVA based; seroconversion CIs are Wilson/Newcombe; cellular and mAb comparisons use Mann–Whitney. Benjamini–Hochberg was applied across the 96 per-virus tests.

**Files in `/tmp/outputs/analysis/`:**
- **Scripts:**
  - `wu397_analysis.py` (main analysis; run with `micromamba run -n core python …`);
  - `wu397_sensitivity.py`;
  - `wu397_sensitivity_outliers.py`;
  - `wu397_breadth_index.py`;
  - `wu397_planning.py`.
- **Logs:** `analysis_log.txt`, `sensitivity_log.txt`, `outliers_log.txt`, `breadth_index_log.txt`, `planning_log.txt`.
- **Figures** in `figures/`:
  - `fig1_seqneut_composites.png` — the key result;
  - `fig2_seqneut_per_virus_adjGMR.png`;
  - `fig3_binding_vs_function.png`.

## 5. What would change this recommendation

- **If lot records show the administered H1 was A/Wisconsin/588/2019-like**, the H1 result becomes a genuine platform signal. It would still be non-randomised, transient, a rise in magnitude rather than breadth, and absent for H3. That strengthens the case for Study A; it does not replace it.
- **If Study A shows a durable, at least 1.5-fold drifted-strain advantage in both subtypes against both comparators**, go to Study B with the full claim. If the advantage holds only against egg-based vaccine, narrow the claim. If H3N2 fails, stop pursuing a general heterologous claim and position on standard non-inferiority.
