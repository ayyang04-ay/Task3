"""11 - Presentation figures (re-drawn from tables written by 03/04)."""
import numpy as np
import pandas as pd
import statsmodels.formula.api as smf
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import TAB, FIG

ORDER = ["H1 mRNA-1010 strain (egg reassortant only)", "H1 mRNA-1010 clade analogue (5a.2a.1, cell)",
         "H1 Fluarix clade analogue (5a.2, cell)", "H1 2023 isolates", "H1 historical (2009-2019)",
         "H3 mRNA-1010 strain (Darwin/6)", "H3 Fluarix-like strain (Darwin/9)",
         "H3 later vaccine strains (2024-25 picks)", "H3 2022-24 isolates",
         "H3 historical (2012-2020)", "H3 egg/reassortant (historical)"]
cols = {c: plt.cm.tab20(i) for i, c in enumerate(ORDER)}

# ---- per-virus forest, grouped by category, legend outside
pv = pd.read_csv(f"{TAB}/seqneut_per_virus.csv")
pv["cat_i"] = pv.category.map({c: i for i, c in enumerate(ORDER)})
pv = pv.sort_values(["cat_i", "ancova_ratio"], ascending=[False, True]).reset_index(drop=True)
fig, ax = plt.subplots(figsize=(11, 13))
y = np.arange(len(pv))
ax.hlines(y, pv.ancova_lo, pv.ancova_hi, color="grey", alpha=.45)
ax.scatter(pv.ancova_ratio, y, c=[cols[c] for c in pv.category], s=20, zorder=3)
ax.set_xscale("log", base=2); ax.axvline(1, color="k", lw=1)
ax.set_yticks(y); ax.set_yticklabels(pv.virus.str.replace("_H3N2", "").str.replace("_H1N1", ""), fontsize=5)
ax.set_xlabel("d29 neutralising titre ratio, mRNA-1010 / Fluarix (ANCOVA on baseline; 95% CI)")
for c in ORDER:
    ax.scatter([], [], color=cols[c], label=c)
ax.legend(fontsize=7, loc="upper left", bbox_to_anchor=(1.01, 1.0), frameon=False)
ax.set_title("Sequencing-based neutralisation, per virus (13 mRNA-1010 vs 14 Fluarix)\n12/96 nominal p<0.05, 0/96 after BH-FDR", fontsize=9)
plt.tight_layout(); plt.savefig(f"{FIG}/seqneut_per_virus_forest.png", dpi=150); plt.close()

# ---- category-level forest, d29 and late
ps = pd.read_csv(f"{TAB}/seqneut_category_participant.csv", dtype={"pid": str})
rows = []
for c in ORDER:
    g = ps[ps.category == c].assign(trt=lambda d: (d.arm == "mRNA-1010").astype(int))
    for tp in ["d29", "late"]:
        f = smf.ols(f"{tp} ~ trt + d0", g.dropna(subset=[tp])).fit()
        lo, hi = f.conf_int().loc["trt"]
        rows.append(dict(category=c, tp=tp, r=2 ** f.params.trt, lo=2 ** lo, hi=2 ** hi, p=f.pvalues.trt))
cf = pd.DataFrame(rows)
cf.to_csv(f"{TAB}/seqneut_category_forest.csv", index=False)
fig, ax = plt.subplots(figsize=(9, 6))
for j, tp in enumerate(["d29", "late"]):
    d = cf[cf.tp == tp].reset_index(drop=True)
    yy = np.arange(len(d))[::-1] + (0.18 if tp == "d29" else -0.18)
    ax.hlines(yy, d.lo, d.hi, color=("tab:purple" if tp == "d29" else "tab:orange"))
    ax.scatter(d.r, yy, color=("tab:purple" if tp == "d29" else "tab:orange"), label=("day 29" if tp == "d29" else "day 121/181"), zorder=3)
ax.set_yticks(np.arange(len(ORDER))[::-1]); ax.set_yticklabels(ORDER, fontsize=8)
ax.set_xscale("log", base=2); ax.axvline(1, color="k", lw=1)
ax.axhline(5.5, color="grey", ls=":", lw=.8)
ax.set_xlabel("neutralising titre ratio mRNA-1010 / Fluarix (participant-level, baseline-adjusted, 95% CI)")
ax.set_title("Arm effect by virus class: H1 ~2x at d29 but gone by d121/181;\nH3 (antigen-matched arms): no advantage vs own strain or 2022-24 drifted isolates", fontsize=9)
ax.legend(fontsize=8, loc="lower right")
plt.tight_layout(); plt.savefig(f"{FIG}/seqneut_category_forest.png", dpi=150); plt.close()

# ---- participant trajectories with clear labels
fig, axes = plt.subplots(1, 2, figsize=(13, 5), sharey=True)
for ax, cat in zip(axes, ["H3 2022-24 isolates", "H1 2023 isolates"]):
    g = ps[ps.category == cat]
    for i, arm in enumerate(["Fluarix", "mRNA-1010"]):
        for _, r in g[g.arm == arm].iterrows():
            ax.plot([i * 3, i * 3 + 1, i * 3 + 2], [2 ** r.d0, 2 ** r.d29, 2 ** r.late], "-o", ms=3, alpha=.55,
                    color="tab:blue" if arm == "Fluarix" else "tab:red")
    ax.set_yscale("log", base=2); ax.set_xticks(range(6))
    ax.set_xticklabels(["Fluarix\nd0", "Fluarix\nd29", "Fluarix\nd121/181", "mRNA-1010\nd0", "mRNA-1010\nd29", "mRNA-1010\nd121/181"], fontsize=8)
    ax.set_title(f"{cat}: each line = one participant's GMT across the class", fontsize=9)
axes[0].set_ylabel("neutralising titre")
plt.tight_layout(); plt.savefig(f"{FIG}/seqneut_participant_breadth.png", dpi=130); plt.close()
print(cf.round(3).to_string(index=False))
