"""10 - For strains present on both the bead-array binding panel and the
seq-neut panel, compare the mRNA-1010/Fluarix ratio for binding fold-rise vs
the baseline-adjusted d29 neutralisation ratio.
Outputs: tables/binding_vs_neut_by_strain.csv, figures/binding_vs_neut_by_strain.png
"""
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import TAB, FIG

bb = pd.read_csv(f"{TAB}/binding_breadth_by_strain.csv")
pv = pd.read_csv(f"{TAB}/seqneut_per_virus.csv")
MAP = {  # bead-array strain -> seq-neut virus (same strain; CA/04 vs CA/07 are antigenically equivalent pdm09 prototypes)
    "A/Darwin/6/2021": "A/Darwin/6/2021_H3N2", "A/Thailand/8/2022": "A/Thailand/8/2022_H3N2",
    "A/Cambodia/e0826360/2020": "A/Cambodia/e0826360/2020_H3N2", "A/Hong Kong/2671/2019": "A/HongKong/2671/2019_H3N2",
    "A/Singapore/INFIMH-16-0019/2016": "A/Singapore/INFIMH-16-0019/2016_H3N2", "A/Texas/50/2012": "A/Texas/50/2012_H3N2",
    "A/Wisconsin/588/2019": "A/Wisconsin/588/2019_H1N1", "A/Wisconsin/67/2022": "A/Wisconsin/67/2022_H1N1",
    "A/Michigan/45/2015": "A/Michigan/45/2015_H1N1", "A/Brisbane/2/2018": "A/Brisbane/02/2018_H1N1",
    "A/Hawaii/70/2019": "A/Hawaii/70/2019_H1N1", "A/California/04/2009": "A/California/07/2009_H1N1",
}
rows = []
for s, v in MAP.items():
    b = bb[bb.strain == s].iloc[0]; n = pv[pv.virus == v].iloc[0]
    rows.append(dict(strain=s, neut_virus=v, binding_ratio_mRNA_over_Flu=b.ratio_mRNA_over_Flu, binding_ci=b.ci95,
                     neut_d29_ratio_ANCOVA=round(n.ancova_ratio, 2), neut_ci=f"{n.ancova_lo:.2f}-{n.ancova_hi:.2f}",
                     neut_late_ratio=round(n.late_ancova_ratio, 2)))
t = pd.DataFrame(rows)
t.to_csv(f"{TAB}/binding_vs_neut_by_strain.csv", index=False)
print(t.to_string(index=False))
fig, ax = plt.subplots(figsize=(7, 6))
for _, r in t.iterrows():
    c = "tab:red" if "H3N2" in r.neut_virus else "tab:blue"
    ax.scatter(r.binding_ratio_mRNA_over_Flu, r.neut_d29_ratio_ANCOVA, color=c)
    ax.annotate(r.strain.replace("A/", ""), (r.binding_ratio_mRNA_over_Flu, r.neut_d29_ratio_ANCOVA), fontsize=6)
ax.set_xscale("log", base=2); ax.set_yscale("log", base=2)
ax.plot([0.5, 16], [0.5, 16], "k:", lw=.8); ax.axhline(1, color="grey", lw=.8); ax.axvline(1, color="grey", lw=.8)
ax.set_xlabel("binding fold-rise ratio, mRNA-1010 / Fluarix (bead array)")
ax.set_ylabel("d29 neutralisation ratio, mRNA-1010 / Fluarix (ANCOVA)")
ax.set_title("Same strains: binding advantage does not carry into neutralisation\n(red = H3N2, blue = H1N1; dotted = identity)")
plt.tight_layout(); plt.savefig(f"{FIG}/binding_vs_neut_by_strain.png", dpi=140)
