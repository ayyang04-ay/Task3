"""02 - Conventional serology: HAI, microneutralisation (MN), ELISA IgG, IgM.

Outputs
  tables/hai_summary.csv, tables/hai_arm_comparison.csv
  tables/mn_summary.csv,  tables/mn_arm_comparison.csv
  tables/elisa_summary.csv, tables/elisa_arm_comparison.csv
  tables/igm_summary.csv
Conventions
  * GMT / GMFR with t-based 95% CI on log scale.
  * Seroconversion (HAI): pre <10 and post >=40, or pre >=10 and >=4-fold rise.
  * Seroprotection-style threshold (HAI): >=40 (a population-level correlate
    for homologous strains only; not a protection threshold for drifted strains).
  * Arm effect = mRNA-1010 / Fluarix; ANCOVA on log2 post titre adjusted for
    log2 baseline. Fisher exact & Newcombe CI for proportions.
  * FDA non-inferiority criteria are shown for orientation only (study was
    not designed or powered for them).
"""
import numpy as np
import pandas as pd
from scipy import stats, optimize
from common import IN, TAB, pid, gm_ci, gm_ratio, newcombe_diff, ancova_arm_effect

pd.set_option("display.width", 250); pd.set_option("display.max_columns", 40); pd.set_option("display.max_rows", 400)


def tobit_ancova(post, base, trt, upper=None, lower=None):
    """Censored-normal regression of log2 post on trt + log2 base.
    upper/lower: log2 censoring limits for post (right/left censored)."""
    post = np.asarray(post, float); base = np.asarray(base, float); trt = np.asarray(trt, float)
    X = np.column_stack([np.ones_like(base), trt, base])
    rc = np.zeros(len(post), bool) if upper is None else post >= upper - 1e-9
    lc = np.zeros(len(post), bool) if lower is None else post <= lower + 1e-9
    def nll(th):
        b, ls = th[:3], th[3]; s = np.exp(ls); mu = X @ b
        ll = np.where(rc, stats.norm.logsf((post - mu) / s),
             np.where(lc, stats.norm.logcdf((post - mu) / s),
                      stats.norm.logpdf((post - mu) / s) - ls))
        return -ll.sum()
    b0 = np.linalg.lstsq(X, post, rcond=None)[0]
    r = optimize.minimize(nll, np.r_[b0, np.log(post.std() + 1e-3)], method="BFGS")
    cov = r.hess_inv
    se = np.sqrt(np.diag(cov))[1]
    est = r.x[1]
    return est, est - 1.96 * se, est + 1.96 * se, 2 * stats.norm.sf(abs(est / se)), int(rc.sum()), int(lc.sum())


# =============================================================== HAI
h = pd.read_csv(f"{IN}/hai_titers.csv", dtype={"participant": str})
h["pid"] = h.participant.map(pid)
h["late"] = h.timepoint.isin(["wk17", "wk26"])
hw = h.pivot_table(index=["antigen", "arm", "pid"], columns="timepoint", values="hai_titer")
hw["late"] = hw["wk26"].fillna(hw["wk17"])
hw = hw.reset_index()

rows, comp = [], []
for ag, g in hw.groupby("antigen"):
    for arm, a in g.groupby("arm"):
        pre, post, late = a.wk0, a.wk4, a.late
        ok = pre.notna() & post.notna()
        sc = ((pre[ok] < 10) & (post[ok] >= 40)) | ((pre[ok] >= 10) & (post[ok] / pre[ok] >= 4))
        rows.append(dict(antigen=ag, arm=arm, n=int(ok.sum()),
                         GMT_wk0="%.0f (%.0f-%.0f)" % gm_ci(pre)[:3],
                         GMT_wk4="%.0f (%.0f-%.0f)" % gm_ci(post)[:3],
                         GMT_late="%.0f (%.0f-%.0f)" % gm_ci(late)[:3],
                         GMFR_wk4="%.2f (%.2f-%.2f)" % gm_ci(post[ok] / pre[ok])[:3],
                         GMFR_late="%.2f (%.2f-%.2f)" % gm_ci((late / pre).dropna())[:3],
                         SCR_wk4=f"{int(sc.sum())}/{int(ok.sum())} ({100*sc.mean():.0f}%)",
                         pct_ge40_wk0=f"{100*(pre>=40).mean():.0f}%",
                         pct_ge40_wk4=f"{100*(post>=40).mean():.0f}%",
                         sc_x=int(sc.sum()), sc_n=int(ok.sum())))
    m = g[g.arm == "mRNA-1010"]; f = g[g.arm == "Fluarix"]
    base_r = gm_ratio(m.wk0, f.wk0)
    post_r = gm_ratio(m.wk4, f.wk4)
    d = g.assign(l_pre=np.log2(g.wk0), l_post=np.log2(g.wk4))
    anc = ancova_arm_effect(d, "l_post", "l_pre")
    d = d.assign(l_late=np.log2(g.late))
    ancL = ancova_arm_effect(d, "l_late", "l_pre")
    rm = [r for r in rows if r["antigen"] == ag and r["arm"] == "mRNA-1010"][0]
    rf = [r for r in rows if r["antigen"] == ag and r["arm"] == "Fluarix"][0]
    sd = newcombe_diff(rf["sc_x"], rf["sc_n"], rm["sc_x"], rm["sc_n"])  # Fluarix - mRNA (FDA orientation)
    p_sc = stats.fisher_exact([[rm["sc_x"], rm["sc_n"] - rm["sc_x"]], [rf["sc_x"], rf["sc_n"] - rf["sc_x"]]])[1]
    inv = 1 / np.array(post_r[:3])  # Fluarix/mRNA GMT ratio for the FDA NI check
    comp.append(dict(antigen=ag,
                     baseline_GMT_ratio_mRNA_vs_Flu="%.2f (%.2f-%.2f) p=%.2f" % base_r,
                     wk4_GMT_ratio_mRNA_vs_Flu="%.2f (%.2f-%.2f) p=%.2f" % post_r,
                     wk4_ANCOVA_ratio_mRNA_vs_Flu="%.2f (%.2f-%.2f) p=%.2f" % (2 ** anc[0], 2 ** anc[1], 2 ** anc[2], anc[3]),
                     late_ANCOVA_ratio_mRNA_vs_Flu="%.2f (%.2f-%.2f) p=%.2f" % (2 ** ancL[0], 2 ** ancL[1], 2 ** ancL[2], ancL[3]),
                     SCR_diff_Flu_minus_mRNA_pctpts="%.0f (%.0f to %.0f) Fisher p=%.2f" % (100 * sd[0], 100 * sd[1], 100 * sd[2], p_sc),
                     FDA_NI_GMT_upper_le_1p5=bool(inv[1] <= 1.5) if False else f"Flu/mRNA upper 95% = {1/post_r[1]:.2f} -> {'met' if 1/post_r[1] <= 1.5 else 'NOT met'}",
                     FDA_NI_SCR_upper_le_10=f"upper = {100*sd[2]:.0f} pts -> {'met' if 100*sd[2] <= 10 else 'NOT met'}"))
hs = pd.DataFrame(rows).drop(columns=["sc_x", "sc_n"]); hc = pd.DataFrame(comp)
hs.to_csv(f"{TAB}/hai_summary.csv", index=False); hc.to_csv(f"{TAB}/hai_arm_comparison.csv", index=False)
print("=== HAI ==="); print(hs.to_string(index=False)); print(hc.to_string(index=False))

# =============================================================== MN
mn = pd.read_csv(f"{IN}/microneutralization.csv")
mn["pid"] = mn.participant.map(pid)
t = mn[mn.measure == "titer"].pivot_table(index=["panel", "arm", "pid"], columns="timepoint", values="value")
t["late"] = t["wk26"].fillna(t["wk17"]); t = t.reset_index()
rows, comp = [], []
CEIL = 1280
for pnl, g in t.groupby("panel"):
    for arm, a in g.groupby("arm"):
        fr4 = a.wk4 / a.wk0; frl = a.late / a.wk0
        rows.append(dict(panel=pnl, arm=arm, n=len(a),
                         GMT_wk0="%.0f (%.0f-%.0f)" % gm_ci(a.wk0)[:3],
                         GMT_wk4="%.0f (%.0f-%.0f)" % gm_ci(a.wk4)[:3],
                         GMT_late="%.0f (%.0f-%.0f)" % gm_ci(a.late)[:3],
                         GMFR_wk4="%.2f (%.2f-%.2f)" % gm_ci(fr4)[:3],
                         GMFR_late="%.2f (%.2f-%.2f)" % gm_ci(frl)[:3],
                         ge4fold_wk4=f"{int((fr4>=4).sum())}/{len(a)}",
                         ge4fold_late=f"{int((frl>=4).sum())}/{len(a)}",
                         at_ceiling_wk0=int((a.wk0 >= CEIL).sum()), at_ceiling_wk4=int((a.wk4 >= CEIL).sum())))
    d = g.assign(l_pre=np.log2(g.wk0), l_post=np.log2(g.wk4), l_late=np.log2(g.late),
                 trt=(g.arm == "mRNA-1010").astype(int))
    m = d[d.arm == "mRNA-1010"]; f = d[d.arm == "Fluarix"]
    anc4 = ancova_arm_effect(d, "l_post", "l_pre"); ancl = ancova_arm_effect(d, "l_late", "l_pre")
    tb4 = tobit_ancova(d.l_post, d.l_pre, d.trt, upper=np.log2(CEIL))
    fx4 = (m.wk4 / m.wk0 >= 4).sum(), len(m), (f.wk4 / f.wk0 >= 4).sum(), len(f)
    dd = newcombe_diff(fx4[0], fx4[1], fx4[2], fx4[3])
    comp.append(dict(panel=pnl,
                     baseline_GMT_ratio="%.2f (%.2f-%.2f) p=%.2f" % gm_ratio(m.wk0, f.wk0),
                     wk4_GMT_ratio="%.2f (%.2f-%.2f) p=%.2f" % gm_ratio(m.wk4, f.wk4),
                     wk4_GMFR_ratio="%.2f (%.2f-%.2f) p=%.2f" % gm_ratio(m.wk4 / m.wk0, f.wk4 / f.wk0),
                     wk4_ANCOVA="%.2f (%.2f-%.2f) p=%.2f" % (2 ** anc4[0], 2 ** anc4[1], 2 ** anc4[2], anc4[3]),
                     wk4_ANCOVA_tobit_ceiling="%.2f (%.2f-%.2f) p=%.2f [%d censored]" % (2 ** tb4[0], 2 ** tb4[1], 2 ** tb4[2], tb4[3], tb4[4]),
                     late_ANCOVA="%.2f (%.2f-%.2f) p=%.2f" % (2 ** ancl[0], 2 ** ancl[1], 2 ** ancl[2], ancl[3]),
                     ge4fold_diff_mRNA_minus_Flu="%.0f (%.0f to %.0f) pts" % (100 * dd[0], 100 * dd[1], 100 * dd[2]),
                     MannWhitney_FR4_p="%.2f" % stats.mannwhitneyu(m.wk4 / m.wk0, f.wk4 / f.wk0).pvalue))
ms = pd.DataFrame(rows); mc = pd.DataFrame(comp)
ms.to_csv(f"{TAB}/mn_summary.csv", index=False); mc.to_csv(f"{TAB}/mn_arm_comparison.csv", index=False)
print("\n=== MN (arm effect = mRNA-1010 / Fluarix) ==="); print(ms.to_string(index=False)); print(mc.T.to_string())

# discordance check: HAI vs MN responders (participant level)
hai4 = hw.assign(fr=hw.wk4 / hw.wk0).pivot_table(index="pid", columns="antigen", values="fr")
mn4 = t.assign(fr=t.wk4 / t.wk0).pivot_table(index="pid", columns="panel", values="fr")
disc = hai4.join(mn4)
print("\nParticipant 014 (mRNA-1010) HAI vs MN fold-rise:\n", disc.loc[["014", "021"]].round(2))

# =============================================================== ELISA IgG
e = pd.read_csv(f"{IN}/elisa_igg_titers.csv")
e["pid"] = e.participant.map(pid)
ec = e[e.measure == "ec50"].pivot_table(index=["antigen", "arm", "pid"], columns="timepoint", values="value")
ec["late"] = ec["wk26"].fillna(ec["wk17"]); ec = ec.reset_index()
sero_ids = set(hw.pid)
rows, comp = [], []
for ag, g in ec.groupby("antigen"):
    for arm, a in g.groupby("arm"):
        rows.append(dict(antigen=ag, arm=arm, n=len(a),
                         GMT_wk0="%.0f (%.0f-%.0f)" % gm_ci(a.wk0)[:3],
                         GMT_wk4="%.0f (%.0f-%.0f)" % gm_ci(a.wk4)[:3],
                         GMFR_wk4="%.2f (%.2f-%.2f)" % gm_ci(a.wk4 / a.wk0)[:3],
                         GMFR_late="%.2f (%.2f-%.2f)" % gm_ci(a.late / a.wk0)[:3],
                         GMFR_wk4_HAIsubset="%.2f" % gm_ci((a.wk4 / a.wk0)[a.pid.isin(sero_ids)])[0],
                         GMFR_wk4_rest="%.2f" % gm_ci((a.wk4 / a.wk0)[~a.pid.isin(sero_ids)])[0],
                         ge4fold_wk4=f"{int(((a.wk4/a.wk0)>=4).sum())}/{len(a)}"))
    d = g.assign(l_pre=np.log2(g.wk0), l_post=np.log2(g.wk4), l_late=np.log2(g.late))
    m = d[d.arm == "mRNA-1010"]; f = d[d.arm == "Fluarix"]
    a4 = ancova_arm_effect(d, "l_post", "l_pre"); al = ancova_arm_effect(d, "l_late", "l_pre")
    comp.append(dict(antigen=ag,
                     baseline_ratio="%.2f (%.2f-%.2f) p=%.3f" % gm_ratio(m.wk0, f.wk0),
                     wk4_GMFR_ratio="%.2f (%.2f-%.2f) p=%.1e" % gm_ratio(m.wk4 / m.wk0, f.wk4 / f.wk0),
                     wk4_ANCOVA="%.2f (%.2f-%.2f) p=%.1e" % (2 ** a4[0], 2 ** a4[1], 2 ** a4[2], a4[3]),
                     late_ANCOVA="%.2f (%.2f-%.2f) p=%.1e" % (2 ** al[0], 2 ** al[1], 2 ** al[2], al[3])))
es = pd.DataFrame(rows); ecmp = pd.DataFrame(comp)
es.to_csv(f"{TAB}/elisa_summary.csv", index=False); ecmp.to_csv(f"{TAB}/elisa_arm_comparison.csv", index=False)
print("\n=== ELISA IgG (EC50) ==="); print(es.to_string(index=False)); print(ecmp.to_string(index=False))

# =============================================================== IgM
igm = pd.read_csv(f"{IN}/igm_fold_change.csv", dtype={"participant": str}); igm["pid"] = igm.participant.map(pid)
rows = []
for (ag, arm), a in igm.groupby(["antigen", "arm"]):
    rows.append(dict(antigen=ag, arm=arm, n=len(a), GMFR="%.2f (%.2f-%.2f)" % gm_ci(a.fold_change)[:3],
                     GMFR_excl_005="%.2f" % gm_ci(a.fold_change[a.pid != "005"])[0],
                     n_rise=f"{int((a.fold_change>1).sum())}/{len(a)}"))
igs = pd.DataFrame(rows)
for ag in igm.antigen.unique():
    a = igm[igm.antigen == ag]
    p = stats.mannwhitneyu(a[a.arm == "mRNA-1010"].fold_change, a[a.arm == "Fluarix"].fold_change).pvalue
    igs.loc[igs.antigen == ag, "MWU_p"] = round(p, 3)
igs.to_csv(f"{TAB}/igm_summary.csv", index=False)
print("\n=== IgM fold-change (timepoint not stated in file) ==="); print(igs.to_string(index=False))
