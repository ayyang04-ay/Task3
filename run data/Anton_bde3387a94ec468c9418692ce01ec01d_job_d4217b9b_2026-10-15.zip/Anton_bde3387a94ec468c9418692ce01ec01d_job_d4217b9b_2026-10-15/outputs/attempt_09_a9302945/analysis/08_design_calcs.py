"""08 - Sample-size / event calculations for the recommended studies, using
variance estimates observed in WU397 where available.

All formulas are standard normal-approximation calculations; they are
planning figures for the committee, not a statistical analysis plan.
Outputs: tables/design_calcs.csv
"""
import numpy as np
import pandas as pd
import statsmodels.formula.api as smf
from scipy import stats
from common import IN, TAB, pid

z = stats.norm.ppf
out = []

# ---------------------------------------------------------------- observed residual SDs (log2)
ps = pd.read_csv(f"{TAB}/seqneut_category_participant.csv", dtype={"pid": str})
sd = {}
for cat in ["H3 2022-24 isolates", "H1 2023 isolates", "H3 mRNA-1010 strain (Darwin/6)"]:
    g = ps[ps.category == cat].assign(trt=lambda d: (d.arm == "mRNA-1010").astype(int))
    for y in ["d29", "late"]:
        f = smf.ols(f"{y} ~ trt + d0", g.dropna(subset=[y])).fit()
        sd[(cat, y)] = np.sqrt(f.scale)
        se = f.bse.trt
        mde80 = 2 ** ((z(.975) + z(.8)) * se)
        out.append(dict(item="WU397 observed", quantity=f"residual SD log2 ({cat}, {y}, ANCOVA)", value=round(np.sqrt(f.scale), 3)))
        out.append(dict(item="WU397 observed", quantity=f"min. detectable GMT ratio at 80% power ({cat}, {y}) with n=13/14", value=round(mde80, 2)))

h = pd.read_csv(f"{IN}/hai_titers.csv", dtype={"participant": str})
hw = h.pivot_table(index=["antigen", "arm", "participant"], columns="timepoint", values="hai_titer").reset_index()
hsd = {}
for ag, g in hw.groupby("antigen"):
    g = g.assign(trt=(g.arm == "mRNA-1010").astype(int), l0=np.log2(g.wk0), l4=np.log2(g.wk4))
    f = smf.ols("l4 ~ trt + l0", g).fit()
    hsd[ag] = (np.sqrt(f.scale), g.l4.std(ddof=1))
    out.append(dict(item="WU397 observed", quantity=f"HAI {ag} wk4 log2 SD (residual | unadjusted)", value=f"{np.sqrt(f.scale):.2f} | {g.l4.std(ddof=1):.2f}"))


def n_gmt_sup(ratio, s, alpha=0.05, power=0.9):
    return int(np.ceil(2 * (z(1 - alpha / 2) + z(power)) ** 2 * s ** 2 / np.log2(ratio) ** 2))


def n_gmt_ni(margin, s, true_ratio=1.0, alpha=0.025, power=0.9):
    d = np.log2(margin) - np.log2(1 / true_ratio) if true_ratio != 1 else np.log2(margin)
    return int(np.ceil(2 * (z(1 - alpha) + z(power)) ** 2 * s ** 2 / d ** 2))


def n_prop_ni(p, delta, alpha=0.025, power=0.9):
    return int(np.ceil((z(1 - alpha) + z(power)) ** 2 * 2 * p * (1 - p) / delta ** 2))


# ---------------------------------------------------------------- Study 1: randomised antigen-matched breadth study
s_h3 = sd[("H3 2022-24 isolates", "d29")]; s_h3l = sd[("H3 2022-24 isolates", "late")]
inflate = 1.25  # allowance for multi-site assay variance / broader population (assumption)
for R in [1.3, 1.5, 2.0]:
    for (lab, s) in [("d29", s_h3), ("d181", s_h3l)]:
        n = n_gmt_sup(R, s * inflate, power=0.9)
        out.append(dict(item="Study 1 breadth co-primary", quantity=f"n/arm to show GMT ratio {R} vs panel of 2022-24-type H3 isolates at {lab} (90% power, 2-sided 0.05, SD x1.25)", value=n))
# HAI NI per strain (3 strains; per-strain power 0.965 gives ~0.9 joint)
s_hai = max(v[1] for v in hsd.values())
for true in [1.0, 0.9]:
    out.append(dict(item="Study 1 homologous NI", quantity=f"n/arm HAI GMT NI margin 1.5, true ratio {true}, SD {s_hai:.2f} (max observed), 3 strains jointly 90%", value=n_gmt_ni(1.5, s_hai, true_ratio=true, power=0.965)))
for p in [0.35, 0.5]:
    out.append(dict(item="Study 1 homologous NI", quantity=f"n/arm SCR NI margin 10 pts, SCR {p:.0%}, 3 strains jointly 90%", value=n_prop_ni(p, 0.10, power=0.965)))

# ---------------------------------------------------------------- Study 2: CHIM
def n_two_prop(p1, p2, alpha=0.05, power=0.8):
    pb = (p1 + p2) / 2
    num = (z(1 - alpha / 2) * np.sqrt(2 * pb * (1 - pb)) + z(power) * np.sqrt(p1 * (1 - p1) + p2 * (1 - p2))) ** 2
    return int(np.ceil(num / (p1 - p2) ** 2))
for pc, pv in [(0.6, 0.3), (0.5, 0.25), (0.6, 0.4)]:
    out.append(dict(item="Study 2 CHIM", quantity=f"n/arm: infection {pc:.0%} (comparator) vs {pv:.0%} (mRNA), 80% power, 2-sided 0.05", value=n_two_prop(pc, pv)))

# ---------------------------------------------------------------- Study 3: event-driven rVE trial
def events_needed(rve, alpha=0.05, power=0.9, lower_bound_rve=0.0):
    th = 1 - rve; th0 = 1 - lower_bound_rve
    p1 = th / (1 + th); p0 = th0 / (1 + th0)
    return int(np.ceil((z(1 - alpha / 2) * np.sqrt(p0 * (1 - p0)) + z(power) * np.sqrt(p1 * (1 - p1))) ** 2 / (p0 - p1) ** 2))
for rve in [0.2, 0.3, 0.4]:
    for lb in [0.0]:
        out.append(dict(item="Study 3 rVE", quantity=f"mismatched-strain cases needed: true rVE {rve:.0%}, show LB>0, 90% power, 1:1", value=events_needed(rve, lower_bound_rve=lb)))
# participants needed per season under attack-rate / mismatch-fraction scenarios (true rVE 30%)
E = events_needed(0.3)
for ar in [0.015, 0.03]:
    for mm in [0.2, 0.5]:
        rate = ar * mm * (1 + 0.7) / 2  # average per-participant rate of mismatched cases across arms
        out.append(dict(item="Study 3 rVE", quantity=f"participant-seasons for {E} mismatched cases: comparator attack rate {ar:.1%}, mismatched share {mm:.0%}", value=int(np.ceil(E / rate))))

dc = pd.DataFrame(out)
dc.to_csv(f"{TAB}/design_calcs.csv", index=False)
pd.set_option("display.width", 250); pd.set_option("display.max_colwidth", 140)
print(dc.to_string(index=False))
