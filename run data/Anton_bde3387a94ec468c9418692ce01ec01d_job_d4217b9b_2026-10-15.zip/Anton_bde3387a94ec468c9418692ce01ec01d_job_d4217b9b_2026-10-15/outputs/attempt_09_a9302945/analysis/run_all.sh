#!/usr/bin/env bash
# Reproduce every table and figure from the read-only inputs in /tmp/world/filesystem.
set -euo pipefail
cd "$(dirname "$0")"
for s in 01_integrity.py 02_serology.py 03_seqneut.py 04_binding_breadth.py 05_mab.py \
         06_cellular_repertoire.py 07_intercurrent_and_enrolment.py 08_design_calcs.py \
         09_interaction_models.py 10_binding_vs_neut_by_strain.py 11_figures.py; do
  echo "=== $s"; micromamba run -n core python "$s" > "../logs/${s%.py}.log" 2>&1
done
echo done
