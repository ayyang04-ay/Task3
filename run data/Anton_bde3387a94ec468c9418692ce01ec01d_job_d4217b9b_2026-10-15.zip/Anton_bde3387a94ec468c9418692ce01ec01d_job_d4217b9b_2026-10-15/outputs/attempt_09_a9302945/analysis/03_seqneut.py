"""03 - Sequencing-based neutralisation panel (96 H1N1/H3N2 viruses; 13 vs 14).

Key idea: 'heterologous' must be defined symmetrically against BOTH arms'
antigens. The arms are antigen-matched for H3 (A/Darwin/6/2021 cell-type vs
A/Darwin/9/2021-like egg-type, same genetic group) but NOT for H1
(A/Victoria/4897/2022, 5a.2a.1, vs A/Victoria/2570/2019-like, 5a.2), so the
H3 2022-24 isolates are the only clean test of platform-driven breadth.

Censoring: titer_bound=='upper' -> titre <= value (below LOD, ~40);
'lower' -> titre >= value (ceiling 17300/6291). Main analysis uses the bound
value; sensitivity sets sub-LOD values to 20 and uses Tobit per-virus models.

Outputs: tables/seqneut_virus_classes.csv, seqneut_per_virus.csv,
seqneut_category_participant.csv, seqneut_category_comparison.csv,
seqneut_egg_vs_wt.csv, figures/seqneut_*.png
"""
import numpy as np
import pandas as pd
from scipy import stats, optimize
import statsmodels.formula.api as smf
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import IN, TAB, FIG, pid

pd.set_option("display.width", 250); pd.set_option("display.max_columns", 40); pd.set_option("display.max_rows", 400)

sn = pd.read_csv(f"{IN}/neutralization_seqbased.csv")
x = sn.serum.str.extract(r"^(Fluarix|mRNA-1010)_397-(\d+)_d(\d+)$")
sn["arm"], sn["pid"], sn["day"] = x[0], x[1].map(pid), x[2].astype(int)
sn["tp"] = sn.day.map({0: "d0", 29: "d29", 121: "late", 181: "late"})
sn["subtype"] = sn.virus.str[-4:]

# ------------------------------------------------------------ classification
H1_HIST = ["A/California/07/2009_H1N1", "A/Michigan/45/2015_H1N1", "A/Brisbane/02/2018_H1N1", "A/Hawaii/70/2019_H1N1"]
H3_HIST_WT = ["A/Texas/50/2012_H3N2", "A/Switzerland/9715293/2013_H3N2", "A/HongKong/4801/2014_H3N2",
              "A/Singapore/INFIMH-16-0019/2016_H3N2", "A/Kansas/14/2017_H3N2", "A/HongKong/45/2019_H3N2",
              "A/HongKong/2671/2019_H3N2", "A/Cambodia/e0826360/2020_H3N2"]
EGG_PAIRS = {  # production reassortant / egg isolate -> wild-type counterpart on the panel
    "A/Texas/50/2012X-223A_H3N2": "A/Texas/50/2012_H3N2",
    "A/Switzerland/9715293/2013NIB-88_H3N2": "A/Switzerland/9715293/2013_H3N2",
    "A/HongKong/4801/2014egg_H3N2": "A/HongKong/4801/2014_H3N2",
    "A/Singapore/INFIMH-16-0019/2016X-307A_H3N2": "A/Singapore/INFIMH-16-0019/2016_H3N2",
    "A/Cambodia/e0826360/2020egg_H3N2": "A/Cambodia/e0826360/2020_H3N2",
}


def classify(v):
    if v == "A/Victoria/4897/2022_IVR-238_H1N1":
        return "H1 mRNA-1010 strain (egg reassortant only)"
    if v == "A/Wisconsin/67/2022_H1N1":
        return "H1 mRNA-1010 clade analogue (5a.2a.1, cell)"
    if v == "A/Wisconsin/588/2019_H1N1":
        return "H1 Fluarix clade analogue (5a.2, cell)"
    if v in H1_HIST:
        return "H1 historical (2009-2019)"
    if v.endswith("H1N1"):
        return "H1 2023 isolates"
    if v == "A/Darwin/6/2021_H3N2":
        return "H3 mRNA-1010 strain (Darwin/6)"
    if v == "A/Darwin/9/2021_H3N2":
        return "H3 Fluarix-like strain (Darwin/9)"
    if v in EGG_PAIRS:
        return "H3 egg/reassortant (historical)"
    if v in H3_HIST_WT:
        return "H3 historical (2012-2020)"
    if v in ("A/Massachusetts/18/2022_H3N2", "A/Thailand/8/2022_H3N2"):
        return "H3 later vaccine strains (2024-25 picks)"
    return "H3 2022-24 isolates"


classes = pd.DataFrame({"virus": sorted(sn.virus.unique())})
classes["category"] = classes.virus.map(classify)
classes["heterologous_to_mRNA1010"] = ~classes.category.str.contains("mRNA-1010")
classes["heterologous_to_Fluarix"] = ~classes.category.str.contains("Fluarix")
classes["note"] = ""
classes.loc[classes.virus.str.contains("202023"), "note"] = "malformed year '202023' in name"
classes.loc[classes.virus.str.contains("IVR-238"), "note"] = "only form of the mRNA-1010 H1 antigen on panel is an egg production reassortant"
classes.to_csv(f"{TAB}/seqneut_virus_classes.csv", index=False)
print(classes.category.value_counts())
sn = sn.merge(classes[["virus", "category"]], on="virus")

# ------------------------------------------------------------ censoring summary
cens = sn.groupby(["category", "titer_bound"]).size().unstack(fill_value=0)
print("\nCensoring by category:\n", cens)
cens.to_csv(f"{TAB}/seqneut_censoring_by_category.csv")

sn["l2"] = np.log2(sn.titer)
sn["l2_sens"] = np.where(sn.titer_bound == "upper", np.log2(20), sn.l2)   # sub-LOD -> 20

W = sn.pivot_table(index=["virus", "category", "arm", "pid"], columns="tp", values="l2").reset_index()
Ws = sn.pivot_table(index=["virus", "category", "arm", "pid"], columns="tp", values="l2_sens").reset_index()
B = sn.pivot_table(index=["virus", "arm", "pid"], columns="tp", values="titer_bound", aggfunc="first").reset_index()
W["fc29"] = W.d29 - W.d0; W["fcl"] = W.late - W.d0; W["dec"] = W.late - W.d29
Ws["fc29"] = Ws.d29 - Ws.d0


def tobit(y, X, lc, rc):
    def nll(th):
        b, ls = th[:-1], th[-1]; s = np.exp(ls); mu = X @ b
        z = (y - mu) / s
        return -np.where(rc, stats.norm.logsf(z), np.where(lc, stats.norm.logcdf(z), stats.norm.logpdf(z) - ls)).sum()
    b0 = np.linalg.lstsq(X, y, rcond=None)[0]
    r = optimize.minimize(nll, np.r_[b0, np.log(y.std() + 1e-3)], method="BFGS")
    return r.x[1], np.sqrt(np.diag(r.hess_inv))[1]


# ------------------------------------------------------------ per-virus
rows = []
for (v, cat), g in W.groupby(["virus", "category"]):
    g = g.dropna(subset=["d0", "d29"])
    gb = g.merge(B, on=["virus", "arm", "pid"], suffixes=("", "_b"))
    m, f = g[g.arm == "mRNA-1010"], g[g.arm == "Fluarix"]
    d = g.assign(trt=(g.arm == "mRNA-1010").astype(int))
    fit = smf.ols("d29 ~ trt + d0", d).fit()
    X = np.column_stack([np.ones(len(gb)), (gb.arm == "mRNA-1010").astype(float), gb.d0.values])
    te, tse = tobit(gb.d29.values, X, (gb.d29_b == "upper").values, (gb.d29_b == "lower").values)
    late = W[(W.virus == v)].dropna(subset=["late", "d0"])
    fl = smf.ols("late ~ trt + d0", late.assign(trt=(late.arm == "mRNA-1010").astype(int))).fit()
    rows.append(dict(virus=v, category=cat, n_m=len(m), n_f=len(f),
                     GMT_d0_m=2 ** m.d0.mean(), GMT_d0_f=2 ** f.d0.mean(),
                     GMT_d29_m=2 ** m.d29.mean(), GMT_d29_f=2 ** f.d29.mean(),
                     GMFR_m=2 ** m.fc29.mean(), GMFR_f=2 ** f.fc29.mean(),
                     pct4x_m=100 * (m.fc29 >= 2).mean(), pct4x_f=100 * (f.fc29 >= 2).mean(),
                     ancova_ratio=2 ** fit.params.trt, ancova_lo=2 ** fit.conf_int().loc["trt", 0],
                     ancova_hi=2 ** fit.conf_int().loc["trt", 1], ancova_p=fit.pvalues.trt,
                     tobit_ratio=2 ** te, tobit_p=2 * stats.norm.sf(abs(te / tse)),
                     late_ancova_ratio=2 ** fl.params.trt, late_ancova_p=fl.pvalues.trt))
pv = pd.DataFrame(rows).sort_values(["category", "virus"])
# Benjamini-Hochberg across the 96 viruses
from statsmodels.stats.multitest import multipletests
pv["ancova_q_BH"] = multipletests(pv.ancova_p, method="fdr_bh")[1]
pv.round(3).to_csv(f"{TAB}/seqneut_per_virus.csv", index=False)
print("\nPer-virus: viruses with nominal ANCOVA p<0.05:", (pv.ancova_p < 0.05).sum(), "of", len(pv),
      "| BH q<0.05:", (pv.ancova_q_BH < 0.05).sum(), "| direction mRNA>Flu:", (pv.ancova_ratio > 1).sum())
print(pv[pv.category.str.startswith("H1") | pv.category.str.contains("strain")][
    ["virus", "category", "GMT_d0_m", "GMT_d0_f", "GMT_d29_m", "GMT_d29_f", "GMFR_m", "GMFR_f", "ancova_ratio", "ancova_lo", "ancova_hi", "ancova_p"]].round(2).to_string(index=False))

# ------------------------------------------------------------ participant-level category scores
def part_scores(Wx):
    s = Wx.groupby(["category", "arm", "pid"]).agg(
        d0=("d0", "mean"), d29=("d29", "mean"), late=("late", "mean"), fc29=("fc29", "mean"),
        frac4x=("fc29", lambda z: np.mean(z >= 2)), nvir=("virus", "nunique")).reset_index()
    return s

ps = part_scores(W)
ps.to_csv(f"{TAB}/seqneut_category_participant.csv", index=False)
pss = part_scores(Ws)

ORDER = ["H1 mRNA-1010 strain (egg reassortant only)", "H1 mRNA-1010 clade analogue (5a.2a.1, cell)",
         "H1 Fluarix clade analogue (5a.2, cell)", "H1 2023 isolates", "H1 historical (2009-2019)",
         "H3 mRNA-1010 strain (Darwin/6)", "H3 Fluarix-like strain (Darwin/9)",
         "H3 later vaccine strains (2024-25 picks)", "H3 2022-24 isolates",
         "H3 historical (2012-2020)", "H3 egg/reassortant (historical)"]
rows = []
for cat in ORDER:
    g = ps[ps.category == cat].dropna(subset=["d0", "d29"]).copy(); gs = pss[pss.category == cat].dropna(subset=["d0", "d29"])
    g["trt"] = (g.arm == "mRNA-1010").astype(int); gs = gs.assign(trt=(gs.arm == "mRNA-1010").astype(int))
    m, f = g[g.trt == 1], g[g.trt == 0]
    fit = smf.ols("d29 ~ trt + d0", g).fit(); fits = smf.ols("d29 ~ trt + d0", gs).fit()
    gl = g.dropna(subset=["late"]); fl = smf.ols("late ~ trt + d0", gl).fit()
    mw = stats.mannwhitneyu(m.fc29, f.fc29).pvalue
    rows.append(dict(category=cat, n_viruses=int(g.nvir.max()), n_m=len(m), n_f=len(f),
                     GMT_d0_m=round(2 ** m.d0.mean()), GMT_d0_f=round(2 ** f.d0.mean()),
                     GMT_d29_m=round(2 ** m.d29.mean()), GMT_d29_f=round(2 ** f.d29.mean()),
                     GMFR_d29_m=round(2 ** m.fc29.mean(), 2), GMFR_d29_f=round(2 ** f.fc29.mean(), 2),
                     GMFR_ratio_unadj=round(2 ** (m.fc29.mean() - f.fc29.mean()), 2), MWU_p_fc=round(mw, 3),
                     d29_ratio_ANCOVA=f"{2**fit.params.trt:.2f} ({2**fit.conf_int().loc['trt',0]:.2f}-{2**fit.conf_int().loc['trt',1]:.2f}) p={fit.pvalues.trt:.3f}",
                     d29_ratio_ANCOVA_subLOD20=f"{2**fits.params.trt:.2f} p={fits.pvalues.trt:.3f}",
                     late_ratio_ANCOVA=f"{2**fl.params.trt:.2f} ({2**fl.conf_int().loc['trt',0]:.2f}-{2**fl.conf_int().loc['trt',1]:.2f}) p={fl.pvalues.trt:.3f}",
                     median_frac_viruses_4x_m=round(m.frac4x.median(), 2), median_frac_viruses_4x_f=round(f.frac4x.median(), 2)))
cc = pd.DataFrame(rows)
cc.to_csv(f"{TAB}/seqneut_category_comparison.csv", index=False)
print("\nParticipant-level category comparison (ratio = mRNA-1010 / Fluarix):")
print(cc.to_string(index=False))

# ------------------------------------------------------------ relative breadth: heterologous vs own-strain response
# within-participant: fold-rise to H3 2022-24 isolates minus fold-rise to the H3 vaccine strain (Darwin/6)
def rel(cat_het, cat_hom):
    a = ps[ps.category == cat_het].set_index(["arm", "pid"]).fc29
    b = ps[ps.category == cat_hom].set_index(["arm", "pid"]).fc29
    r = (a - b).dropna().reset_index(name="rel")
    m, f = r[r.arm == "mRNA-1010"].rel, r[r.arm == "Fluarix"].rel
    return 2 ** m.mean(), 2 ** f.mean(), stats.mannwhitneyu(m, f).pvalue, len(m), len(f)

print("\nRelative breadth (GMFR to heterologous / GMFR to own H3 strain), mRNA vs Fluarix:")
for het in ["H3 2022-24 isolates", "H3 later vaccine strains (2024-25 picks)", "H3 historical (2012-2020)"]:
    print(f"  {het} vs Darwin/6: mRNA {rel(het,'H3 mRNA-1010 strain (Darwin/6)')[0]:.2f}, Flu {rel(het,'H3 mRNA-1010 strain (Darwin/6)')[1]:.2f}, MWU p={rel(het,'H3 mRNA-1010 strain (Darwin/6)')[2]:.2f}")
print(f"  H1 2023 isolates vs Wisc/588 (5a.2): mRNA {rel('H1 2023 isolates','H1 Fluarix clade analogue (5a.2, cell)')[0]:.2f}, Flu {rel('H1 2023 isolates','H1 Fluarix clade analogue (5a.2, cell)')[1]:.2f}")

# ------------------------------------------------------------ H1 antigen check: which H1 shows the largest own-arm rise?
print("\nH1 GMFR (d29/d0) by virus and arm - a homologous antigen should give the largest rise in its own arm:")
h1 = pv[pv.virus.str.endswith("H1N1")][["virus", "GMFR_m", "GMFR_f", "GMT_d0_m", "GMT_d29_m"]].sort_values("GMFR_m", ascending=False)
print(h1.round(2).to_string(index=False))

# ------------------------------------------------------------ egg vs wild-type counterparts
rows = []
for egg, wt in EGG_PAIRS.items():
    a = W[W.virus == egg].set_index(["arm", "pid"]); b = W[W.virus == wt].set_index(["arm", "pid"])
    for arm in ["mRNA-1010", "Fluarix"]:
        r0 = (a.loc[arm].d0 - b.loc[arm].d0).dropna(); r29 = (a.loc[arm].d29 - b.loc[arm].d29).dropna()
        rows.append(dict(egg_virus=egg, wt_virus=wt, arm=arm, n=len(r29),
                         egg_over_wt_d0=round(2 ** r0.mean(), 2), egg_over_wt_d29=round(2 ** r29.mean(), 2),
                         GMFR_egg=round(2 ** a.loc[arm].fc29.mean(), 2), GMFR_wt=round(2 ** b.loc[arm].fc29.mean(), 2)))
eg = pd.DataFrame(rows)
eg.to_csv(f"{TAB}/seqneut_egg_vs_wt.csv", index=False)
print("\nEgg/reassortant vs wild-type (same strain):\n", eg.to_string(index=False))
# Victoria/4897 IVR-238 vs its cell-grown clade analogue Wisconsin/67/2022 at baseline
a = W[W.virus == "A/Victoria/4897/2022_IVR-238_H1N1"].set_index(["arm", "pid"]).d0
b = W[W.virus == "A/Wisconsin/67/2022_H1N1"].set_index(["arm", "pid"]).d0
print("Baseline titre ratio A/Victoria/4897/2022 IVR-238 vs A/Wisconsin/67/2022 (both 5a.2a.1): %.1f-fold" % 2 ** (a - b).mean())

# ------------------------------------------------------------ durability
dl = W.dropna(subset=["late", "d29"]).merge(sn[["pid", "day"]][sn.day > 29].drop_duplicates(), on="pid")
dur = dl.groupby(["category", "arm"]).dec.mean().unstack()
dur = 2 ** dur
dur.columns = [f"late_over_d29_{c}" for c in dur.columns]
dur181 = 2 ** dl[dl.day == 181].groupby(["category", "arm"]).dec.mean().unstack()
dur181.columns = [f"d181only_{c}" for c in dur181.columns]
dur = dur.join(dur181).loc[ORDER].round(2)
dur.to_csv(f"{TAB}/seqneut_durability.csv")
print("\nDurability (GM ratio late / d29):\n", dur)

# ------------------------------------------------------------ figures
fig, axes = plt.subplots(1, 2, figsize=(13, 5))
for ax, cat in zip(axes, ["H3 2022-24 isolates", "H1 2023 isolates"]):
    g = ps[ps.category == cat]
    for i, arm in enumerate(["Fluarix", "mRNA-1010"]):
        a = g[g.arm == arm]
        for _, r in a.iterrows():
            ax.plot([i * 3, i * 3 + 1, i * 3 + 2], [2 ** r.d0, 2 ** r.d29, 2 ** r.late], "-o", ms=3, alpha=.5,
                    color="tab:blue" if arm == "Fluarix" else "tab:red")
    ax.set_yscale("log", base=2); ax.set_xticks(range(6)); ax.set_xticklabels(["F d0", "F d29", "F late", "m d0", "m d29", "m late"])
    ax.set_title(f"{cat}: participant GMT across viruses"); ax.set_ylabel("neutralising titre (GMT across category)")
plt.tight_layout(); plt.savefig(f"{FIG}/seqneut_participant_breadth.png", dpi=130); plt.close()

fig, ax = plt.subplots(figsize=(8, 12))
p2 = pv.copy(); p2["lr"] = np.log2(p2.ancova_ratio)
p2 = p2.sort_values(["category", "lr"])
cols = {c: plt.cm.tab20(i) for i, c in enumerate(ORDER)}
ax.errorbar(p2.lr, range(len(p2)), xerr=[p2.lr - np.log2(p2.ancova_lo), np.log2(p2.ancova_hi) - p2.lr], fmt="none", ecolor="grey", alpha=.4)
ax.scatter(p2.lr, range(len(p2)), c=[cols[c] for c in p2.category], s=18)
ax.axvline(0, color="k"); ax.set_yticks(range(len(p2))); ax.set_yticklabels(p2.virus.str.replace("_H3N2", "").str.replace("_H1N1", ""), fontsize=5)
ax.set_xlabel("log2 d29 titre ratio mRNA-1010 / Fluarix (ANCOVA, baseline-adjusted)")
for c in ORDER:
    ax.scatter([], [], c=[cols[c]], label=c)
ax.legend(fontsize=6, loc="lower right")
plt.tight_layout(); plt.savefig(f"{FIG}/seqneut_per_virus_forest.png", dpi=150); plt.close()
print("figures written")
