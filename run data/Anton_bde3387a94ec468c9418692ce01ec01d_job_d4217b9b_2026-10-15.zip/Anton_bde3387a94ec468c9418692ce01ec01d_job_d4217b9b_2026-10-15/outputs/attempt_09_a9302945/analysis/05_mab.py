"""05 - Monoclonal antibody binding panels (group I = H1/H5, group II = H3/H7).

fold_over_control is normalised to SARS-CoV-2 RBD (=1 for every mAb).
Binder call: >=5-fold over control (bimodal gap at ~4-5; sensitivity 3 and 10).
Unit of inference = donor (4 mRNA-1010 vs 3 Fluarix); exact permutation test
over the C(7,3)=35 donor relabellings (smallest attainable p = 1/35 = 0.029).
Outputs: tables/mab_donor_binding.csv, tables/mab_arm_donor_level.csv
"""
import itertools
import numpy as np
import pandas as pd
from common import IN, TAB

pd.set_option("display.width", 250); pd.set_option("display.max_columns", 40)
mab = pd.read_csv(f"{IN}/mab_binding_panels.csv")
mab["donor"] = mab.mab_id.str.split(".").str[1]
mab = mab[mab.antigen != "SARS-CoV-2 RBD"]

VAX = {"group_I": {"mRNA-1010": "A/Victoria/4897/2022", "Fluarix": "A/Wisconsin/588/2019"},   # Fluarix H1 = A/Victoria/2570/2019-like (5a.2); Wisconsin/588 is the closest panel member
       "group_II": {"mRNA-1010": "A/Darwin/6/2021", "Fluarix": "A/Darwin/6/2021"}}           # Fluarix H3 = A/Darwin/9/2021-like (same clade)
DRIFT = {"group_I": "A/Netherlands/01317/2025", "group_II": "A/Croatia/10136RV/2023"}
STEM = {"group_I": "A/Hubei/1/2010 (H5)", "group_II": "A/Shanghai/1/2013 (H7)"}

out = []
for thr in [3, 5, 10]:
    b = mab.assign(bind=mab.fold_over_control >= thr)
    for (pnl, arm, donor), g in b.groupby(["panel", "arm", "donor"]):
        w = g.pivot_table(index="mab_id", columns="antigen", values="bind", aggfunc="first")
        n = len(w)
        vax = w[VAX[pnl][arm]]
        row = dict(threshold=thr, panel=pnl, arm=arm, donor=donor, n_mabs=n,
                   pct_bind_own_vaccine_strain=100 * vax.mean(),
                   pct_bind_drift_strain=100 * w[DRIFT[pnl]].mean(),
                   pct_bind_H5_or_H7=100 * w[STEM[pnl]].mean(),
                   mean_n_antigens_bound=w.sum(axis=1).mean(),
                   pct_bind_all_subtype_strains=100 * w.drop(columns=[STEM[pnl]]).all(axis=1).mean())
        for ag in w.columns:
            row[f"pct:{ag}"] = 100 * w[ag].mean()
        out.append(row)
db = pd.DataFrame(out)
db.round(1).to_csv(f"{TAB}/mab_donor_binding.csv", index=False)
main = db[db.threshold == 5]
cols = ["panel", "arm", "donor", "n_mabs", "pct_bind_own_vaccine_strain", "pct_bind_drift_strain", "pct_bind_H5_or_H7", "mean_n_antigens_bound"]
print(main[cols].round(1).to_string(index=False))
print("\nPer-antigen % of mAbs binding (threshold 5), by donor:")
pc = [c for c in main.columns if c.startswith("pct:")]
for pnl in ["group_I", "group_II"]:
    t = main[main.panel == pnl].set_index(["arm", "donor"])[pc].dropna(axis=1, how="all").round(0)
    t.columns = [c[4:] for c in t.columns]
    print(pnl); print(t.to_string())

# donor-level arm comparison, exact permutation test
res = []
for thr in [3, 5, 10]:
    for pnl in ["group_I", "group_II"]:
        d = db[(db.threshold == thr) & (db.panel == pnl)]
        for metric in ["pct_bind_drift_strain", "pct_bind_H5_or_H7", "mean_n_antigens_bound"]:
            vals = d.set_index("donor")[metric]; arms = d.set_index("donor").arm
            obs = vals[arms == "mRNA-1010"].mean() - vals[arms == "Fluarix"].mean()
            donors = list(vals.index); k = (arms == "Fluarix").sum()
            diffs = []
            for comb in itertools.combinations(donors, k):
                fl = vals[list(comb)].mean(); mr = vals[[x for x in donors if x not in comb]].mean()
                diffs.append(mr - fl)
            p = np.mean(np.abs(diffs) >= abs(obs) - 1e-12)
            # pooled (pseudo-replicated) estimate for contrast
            pooled_m = mab[(mab.panel == pnl) & (mab.arm == "mRNA-1010")]
            res.append(dict(threshold=thr, panel=pnl, metric=metric,
                            donor_mean_mRNA=round(vals[arms == "mRNA-1010"].mean(), 1),
                            donor_mean_Flu=round(vals[arms == "Fluarix"].mean(), 1),
                            donor_values_mRNA=vals[arms == "mRNA-1010"].round(1).to_dict(),
                            donor_values_Flu=vals[arms == "Fluarix"].round(1).to_dict(),
                            exact_perm_p=round(p, 3)))
rr = pd.DataFrame(res)
rr.to_csv(f"{TAB}/mab_arm_donor_level.csv", index=False)
print("\nDonor-level arm comparison (exact permutation, 35 relabellings):")
print(rr[rr.threshold == 5].to_string(index=False))
print("\nSensitivity (threshold 3 / 10) for drift & H5/H7:")
print(rr[(rr.threshold != 5) & (rr.metric != "mean_n_antigens_bound")][["threshold", "panel", "metric", "donor_mean_mRNA", "donor_mean_Flu", "exact_perm_p"]].to_string(index=False))

# share of all mAbs contributed by the single largest donor in each arm
sh = mab.drop_duplicates("mab_id").groupby(["arm", "donor"]).size()
print("\nmAbs per donor (unique IDs):\n", sh, "\nlargest-donor share:", (sh.groupby(level=0).max() / sh.groupby(level=0).sum()).round(2).to_dict())
