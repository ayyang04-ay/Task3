"""09 - Is the mRNA-1010 effect a uniform magnitude shift or a breadth
(specificity) shift?  Mixed models on virus-level log2 d29 titres with a
random intercept per participant:
    log2(d29) ~ arm * class + log2(d0)  + (1 | participant)
The arm x class interaction tests whether the arm effect differs between
virus classes. Also a paired check of which H1 virus gets the largest rise.
Outputs: tables/interaction_models.txt
"""
import numpy as np
import pandas as pd
import statsmodels.formula.api as smf
from scipy import stats
from common import IN, TAB, pid

sn = pd.read_csv(f"{IN}/neutralization_seqbased.csv")
x = sn.serum.str.extract(r"^(Fluarix|mRNA-1010)_397-(\d+)_d(\d+)$")
sn["arm"], sn["pid"], sn["day"] = x[0], x[1].map(pid), x[2].astype(int)
sn["tp"] = sn.day.map({0: "d0", 29: "d29", 121: "late", 181: "late"})
cls = pd.read_csv(f"{TAB}/seqneut_virus_classes.csv")
sn = sn.merge(cls[["virus", "category"]], on="virus")
sn["l2"] = np.log2(sn.titer)
W = sn.pivot_table(index=["virus", "category", "arm", "pid"], columns="tp", values="l2").reset_index().dropna(subset=["d0", "d29"])
W["trt"] = (W.arm == "mRNA-1010").astype(int)
lines = []

def fit(df, label, cmap):
    d = df.copy(); d["cls"] = d.category.map(cmap)
    d = d.dropna(subset=["cls"])
    m1 = smf.mixedlm("d29 ~ trt * C(cls) + d0", d, groups=d["pid"]).fit(reml=False)
    m0 = smf.mixedlm("d29 ~ trt + C(cls) + d0", d, groups=d["pid"]).fit(reml=False)
    lr = 2 * (m1.llf - m0.llf); dfree = len(m1.params) - len(m0.params)
    p = stats.chi2.sf(lr, dfree)
    lines.append(f"\n=== {label} ===\nclasses: {sorted(d.cls.unique())}  n obs={len(d)}")
    # class-specific arm effects
    ref = sorted(d.cls.unique())[0]
    for c in sorted(d.cls.unique()):
        est = m1.params["trt"] + (m1.params.get(f"trt:C(cls)[T.{c}]", 0.0))
        lines.append(f"  arm effect (mRNA/Flu, fold) in '{c}': {2**est:.2f}")
    lines.append(f"  LR test arm x class interaction: chi2={lr:.2f}, df={dfree}, p={p:.4f}")
    m0s = m0.params["trt"]; ci = m0.conf_int().loc["trt"]
    lines.append(f"  common arm effect (no interaction): {2**m0s:.2f} ({2**ci[0]:.2f}-{2**ci[1]:.2f}), p={m0.pvalues['trt']:.4f}")

fit(W[W.virus.str.endswith("H1N1")], "H1: does the mRNA-1010 advantage differ by H1 virus class?",
    {"H1 2023 isolates": "2023 isolates", "H1 historical (2009-2019)": "historical",
     "H1 Fluarix clade analogue (5a.2, cell)": "5a.2 (Fluarix clade)",
     "H1 mRNA-1010 clade analogue (5a.2a.1, cell)": "5a.2a.1 (stated mRNA clade)",
     "H1 mRNA-1010 strain (egg reassortant only)": "Vic4897 IVR-238 (egg)"})
fit(W[W.virus.str.endswith("H3N2")], "H3: does the mRNA-1010 effect differ between contemporary and historical/vaccine strains?",
    {"H3 2022-24 isolates": "c 2022-24 isolates", "H3 later vaccine strains (2024-25 picks)": "d 2024-25 picks",
     "H3 historical (2012-2020)": "b historical wt", "H3 egg/reassortant (historical)": "e historical egg",
     "H3 mRNA-1010 strain (Darwin/6)": "a vaccine clade (Darwin/6,9)", "H3 Fluarix-like strain (Darwin/9)": "a vaccine clade (Darwin/6,9)"})

# paired: within mRNA-1010 arm, rise to Wisconsin/588/2019 (5a.2) vs Wisconsin/67/2022 (5a.2a.1)
w = W[W.virus.isin(["A/Wisconsin/588/2019_H1N1", "A/Wisconsin/67/2022_H1N1"])].assign(fc=lambda d: d.d29 - d.d0)
pv = w.pivot_table(index=["arm", "pid"], columns="virus", values="fc")
for arm in ["mRNA-1010", "Fluarix"]:
    a = pv.loc[arm].dropna(); dlt = a["A/Wisconsin/588/2019_H1N1"] - a["A/Wisconsin/67/2022_H1N1"]
    wp = stats.wilcoxon(dlt).pvalue
    lines.append(f"\n{arm}: GMFR Wisconsin/588/2019 (5a.2) / GMFR Wisconsin/67/2022 (5a.2a.1) = {2**dlt.mean():.2f} "
                 f"(participants with larger rise to 5a.2: {(dlt>0).sum()}/{len(dlt)}; Wilcoxon p={wp:.3f})")
lines.append("\nNOTE: virus-level mixed-model LR p-values use a random intercept only and treat many viruses per "
             "participant as near-independent; they are anti-conservative. Use the participant-level contrasts below.")
txt = "\n".join(lines)
print(txt)
open(f"{TAB}/interaction_models.txt", "w").write(txt)

# ---- participant-level confirmation (one contrast value per person; avoids pseudo-replication)
ps = pd.read_csv(f"{TAB}/seqneut_category_participant.csv", dtype={"pid": str})
wide = ps.pivot_table(index=["arm", "pid"], columns="category", values=["d0", "d29"])
def contrast(a, b, label):
    c29 = wide[("d29", a)] - wide[("d29", b)]; c0 = wide[("d0", a)] - wide[("d0", b)]
    d = pd.DataFrame({"c29": c29, "c0": c0}).reset_index()
    d["trt"] = (d.arm == "mRNA-1010").astype(int)
    f = smf.ols("c29 ~ trt + c0", d).fit()
    est, (lo, hi) = f.params.trt, f.conf_int().loc["trt"]
    s = (f"\n[participant-level] {label}: arm difference in d29 contrast = {2**est:.2f}-fold "
         f"({2**lo:.2f}-{2**hi:.2f}), p={f.pvalues.trt:.4f}; n={len(d)}")
    print(s); return s
extra = [contrast("H3 historical (2012-2020)", "H3 2022-24 isolates",
                  "H3 historical minus 2022-24 isolates (positive = mRNA-1010 skews backward)"),
         contrast("H3 2022-24 isolates", "H3 mRNA-1010 strain (Darwin/6)",
                  "H3 2022-24 isolates minus Darwin/6 (positive = broader relative to own strain)"),
         contrast("H1 2023 isolates", "H1 historical (2009-2019)",
                  "H1 2023 isolates minus historical (positive = mRNA-1010 skews forward)")]
open(f"{TAB}/interaction_models.txt", "a").write("".join(extra))
