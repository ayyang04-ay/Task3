"""Shared helpers for the WU397 data-package review.

All inputs are read from the read-only mount; nothing is modified there.
"""
import os
import numpy as np
import pandas as pd
from scipy import stats

IN = "/tmp/world/filesystem"
OUT = "/tmp/outputs"
TAB = os.path.join(OUT, "tables")
FIG = os.path.join(OUT, "figures")
os.makedirs(TAB, exist_ok=True)
os.makedirs(FIG, exist_ok=True)

ARMS = ["mRNA-1010", "Fluarix"]


def pid(x):
    """Normalise the four participant-ID spellings used across files
    ('397-001', '001', '1', '20', '397-06') to a 3-digit string."""
    s = str(x).strip()
    if s.startswith("397-"):
        s = s[4:]
    return s.zfill(3)


def gmean(x):
    x = np.asarray(x, float)
    x = x[~np.isnan(x)]
    return float(np.exp(np.mean(np.log(x)))) if len(x) else np.nan


def gm_ci(x, alpha=0.05):
    """Geometric mean with t-based 95% CI on the log scale."""
    x = np.asarray(x, float)
    x = x[~np.isnan(x)]
    n = len(x)
    if n < 2:
        return (gmean(x), np.nan, np.nan, n)
    lx = np.log(x)
    m, se = lx.mean(), lx.std(ddof=1) / np.sqrt(n)
    t = stats.t.ppf(1 - alpha / 2, n - 1)
    return (np.exp(m), np.exp(m - t * se), np.exp(m + t * se), n)


def gm_ratio(a, b, alpha=0.05):
    """Ratio of geometric means a/b with Welch 95% CI and p-value."""
    a = np.log(np.asarray(a, float)); b = np.log(np.asarray(b, float))
    a = a[~np.isnan(a)]; b = b[~np.isnan(b)]
    d = a.mean() - b.mean()
    va, vb = a.var(ddof=1) / len(a), b.var(ddof=1) / len(b)
    se = np.sqrt(va + vb)
    df = (va + vb) ** 2 / (va ** 2 / (len(a) - 1) + vb ** 2 / (len(b) - 1))
    t = stats.t.ppf(1 - alpha / 2, df)
    p = 2 * stats.t.sf(abs(d / se), df)
    return np.exp(d), np.exp(d - t * se), np.exp(d + t * se), p


def newcombe_diff(x1, n1, x2, n2, z=1.959964):
    """Newcombe hybrid-score CI for p1 - p2 (method 10)."""
    def wilson(x, n):
        p = x / n
        den = 1 + z * z / n
        c = (p + z * z / (2 * n)) / den
        h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
        return c - h, c + h
    p1, p2 = x1 / n1, x2 / n2
    l1, u1 = wilson(x1, n1)
    l2, u2 = wilson(x2, n2)
    d = p1 - p2
    lo = d - np.sqrt((p1 - l1) ** 2 + (u2 - p2) ** 2)
    hi = d + np.sqrt((u1 - p1) ** 2 + (p2 - l2) ** 2)
    return d, lo, hi


def ancova_arm_effect(df, y, base, arm_col="arm", ref="Fluarix"):
    """OLS: y ~ arm + base (both log2). Returns arm effect (mRNA-1010 minus
    Fluarix) in log2 units with 95% CI and p."""
    import statsmodels.formula.api as smf
    d = df[[y, base, arm_col]].dropna().copy()
    d["trt"] = (d[arm_col] != ref).astype(int)
    fit = smf.ols(f"{y} ~ trt + {base}", data=d).fit()
    est = fit.params["trt"]; lo, hi = fit.conf_int().loc["trt"]
    return est, lo, hi, fit.pvalues["trt"], int(fit.nobs)


def fmt_ci(est, lo, hi, nd=2):
    return f"{est:.{nd}f} ({lo:.{nd}f}-{hi:.{nd}f})"
