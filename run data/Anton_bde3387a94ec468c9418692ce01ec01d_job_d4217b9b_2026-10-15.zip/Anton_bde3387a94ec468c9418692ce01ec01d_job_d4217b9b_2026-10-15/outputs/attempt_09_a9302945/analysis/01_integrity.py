"""01 - Data-package integrity review.

Reconciles every file against trial_summary.md (cohort sizes, sampling
schedule, identifiers) and checks internal arithmetic. Writes
tables/integrity_findings.csv and prints a log.
"""
import re
import numpy as np
import pandas as pd
from common import IN, TAB, pid

findings = []


def add(file, check, result, implication):
    findings.append(dict(file=file, check=check, result=result, implication=implication))
    print(f"[{file}] {check}: {result}")


# ---------------------------------------------------------------- cohorts
declared = {  # from trial_summary.md, 'Assay cohorts'
    "ELISA/IgM": (38, 37), "HAI": (14, 15), "bead-array/MN": (14, 15),
    "seq-neut": (13, 14), "FNA": (6, 11)}

def ids(file, col="participant", arm=None):
    d = pd.read_csv(f"{IN}/{file}", dtype={col: str})
    return {a: sorted({pid(x) for x in d.loc[d.arm == a, col]}) for a in ["mRNA-1010", "Fluarix"]}

obs = {
    "elisa_igg_titers.csv": ids("elisa_igg_titers.csv"),
    "igm_fold_change.csv": ids("igm_fold_change.csv"),
    "hai_titers.csv": ids("hai_titers.csv"),
    "microneutralization.csv": ids("microneutralization.csv"),
    "binding_breadth_h1.csv": ids("binding_breadth_h1.csv"),
    "binding_breadth_h3.csv": ids("binding_breadth_h3.csv"),
    "gc_frequencies.csv": ids("gc_frequencies.csv"),
    "plasmablast_frequencies.csv": ids("plasmablast_frequencies.csv"),
}
sn = pd.read_csv(f"{IN}/neutralization_seqbased.csv")
x = sn.serum.str.extract(r"^(Fluarix|mRNA-1010)_397-(\d+)_d(\d+)$")
obs["neutralization_seqbased.csv"] = {a: sorted(set(x.loc[x[0] == a, 1].map(pid))) for a in ["mRNA-1010", "Fluarix"]}
coh = pd.DataFrame({f: {a: len(v[a]) for a in v} for f, v in obs.items()}).T
print(coh)
coh.to_csv(f"{TAB}/cohort_sizes_observed.csv")

add("igm_fold_change.csv", "n per arm vs declared ELISA/IgM cohort (38/37)",
    f"{len(obs['igm_fold_change.csv']['mRNA-1010'])}/{len(obs['igm_fold_change.csv']['Fluarix'])} - IgM only in the HAI/MN subset",
    "IgM is reported for the 14/15 serology sub-cohort, not the 38/37 stated in the summary; no timepoint is given for the fold change.")
add("neutralization_seqbased.csv", "participants missing vs HAI/MN cohort",
    f"mRNA-1010 397-014 and Fluarix 397-019 absent",
    "397-014 is the only mRNA-1010 MN non-responder (15->10); its absence flatters no arm but must be reported.")
fna = obs["gc_frequencies.csv"]; pb = obs["plasmablast_frequencies.csv"]
extra = {a: sorted(set(pb[a]) - set(fna[a])) for a in pb}
add("plasmablast_frequencies.csv", "cohort vs FNA subset (6/11) and blood schedule",
    f"{len(pb['mRNA-1010'])}/{len(pb['Fluarix'])} participants; extra vs FNA: {extra}; timepoints wk0/2/8/17/26 match the FNA schedule, not the blood schedule (d0/7/29/121/181); extra participants' values carry 2-3 significant figures vs 6 dp for the rest",
    "Provenance of the plasmablast table is unclear (blood vs node; which cohort). Treat as descriptive only.")

# ---------------------------------------------------------------- schedule
gc = pd.read_csv(f"{IN}/gc_frequencies.csv", dtype={"participant": str})
dup = gc.duplicated(["timepoint", "arm", "participant"], keep=False)
add("gc_frequencies.csv", "duplicate keys (timepoint, arm, participant)",
    f"{dup.sum()} of {len(gc)} rows are duplicated keys: the file is two stacked blocks of {len(gc)//2} rows with the same column name and different values (2nd block mostly zeros)",
    "Cannot tell which block is the HA-specific GC readout; block 1 used descriptively with that caveat.")
add("gc_frequencies.csv", "timepoints vs FNA schedule (wk1,2,4,8,17,26)",
    f"present: {sorted(gc.timepoint.unique())}; wk0 present although no pre-dose FNA is scheduled; wk1 and wk4 absent",
    "Either labels are shifted or visits are missing; the GC kinetics cannot be mapped to the protocol schedule with confidence.")

h = pd.read_csv(f"{IN}/hai_titers.csv", dtype={"participant": str})
late = h[h.timepoint.isin(["wk17", "wk26"])]
lab = late.pivot_table(index=["arm", "participant"], columns="antigen", values="timepoint", aggfunc="first")
bad = lab[lab["B/Vic"].notna() & (lab["B/Vic"] != lab["A/H1N1"])]
add("hai_titers.csv", "late-visit label consistent across antigens within participant",
    f"B/Vic late visit differs from H1/H3/B-Yam for {len(bad)} participants: " + "; ".join(f"{a} {p}: B/Vic {r['B/Vic']} vs others {r['A/H1N1']}" for (a, p), r in bad.iterrows()),
    "Participants who only attended wk17 for three antigens have a 'wk26' B/Vic value and vice-versa -> probable label swap; B/Vic late data unreliable.")
miss = h[(h.antigen == "B/Vic") & (h.participant == "031")]
add("hai_titers.csv", "B/Vic rows for mRNA-1010 397-031", f"{len(miss)} rows (absent at every visit)", "B/Vic analysed on 13 mRNA-1010 participants.")
odd = h[~np.isclose(np.log2(h.hai_titer / 10 * 2) % 0.5, 0, atol=0.02) & ~np.isclose(np.log2(h.hai_titer / 10 * 2) % 0.5, 0.5, atol=0.02)]
add("hai_titers.csv", "values off the 2-fold / half-step grid",
    f"{len(odd)} rows e.g. {odd[['antigen','timepoint','arm','participant','hai_titer']].head(4).values.tolist()}",
    "288 is not a value a 2-fold series (or the geometric mean of duplicates) can produce; 226.27417 appears unrounded elsewhere. Query source records.")

sn["arm"] = x[0]; sn["pid"] = x[1]; sn["day"] = x[2].astype(int)
late_sn = sn[sn.day > 29].groupby(["arm", "day"]).pid.nunique()
add("neutralization_seqbased.csv", "late serum day by arm",
    late_sn.to_dict().__repr__() + "; Fluarix 397-007 and 397-011 use d121 here but wk26 in HAI/MN",
    "'Late' mixes d121 and d181 in different proportions by arm (Fluarix 4/14 at d121, mRNA-1010 2/13); late comparisons must be by actual day.")

# ---------------------------------------------------------------- arithmetic checks
mn = pd.read_csv(f"{IN}/microneutralization.csv")
t = mn[mn.measure == "titer"].copy()
t["tp2"] = t.timepoint.replace({"wk17": "wk17/26", "wk26": "wk17/26"})
tw = t.pivot_table(index=["panel", "arm", "participant"], columns="tp2", values="value")
fc = mn[mn.measure == "fold_change"].pivot_table(index=["panel", "arm", "participant"], columns="timepoint", values="value")
chk4 = np.allclose(tw["wk4"] / tw["wk0"], fc["wk4"], rtol=1e-3)
chkL = np.allclose(tw["wk17/26"] / tw["wk0"], fc["wk17/26"], rtol=1e-3)
add("microneutralization.csv", "reported fold-change = titer ratio", f"wk4: {chk4}; wk17/26: {chkL}", "Internally consistent.")
ceil = t[t.value >= 1280].groupby(["panel", "timepoint", "arm"]).size()
add("microneutralization.csv", "values at assay ceiling (1280)", ceil.to_dict().__repr__(),
    "Ceiling at 1:1280 truncates fold-rise in high-baseline participants and compresses between-arm differences; homologous Fluarix wk4 is 9/15 at ceiling.")
add("microneutralization.csv", "virus identity of 'homologous'/'heterologous' panels", "not given (no strain or subtype column)",
    "Panels are defined against mRNA-1010 antigens only; for Fluarix recipients the 'homologous' panel is not their vaccine strain set. Cannot be interpreted as a symmetric breadth comparison.")

e = pd.read_csv(f"{IN}/elisa_igg_titers.csv")
ec = e[e.measure == "ec50"].copy(); ec["tp2"] = ec.timepoint.replace({"wk17": "wk17/26", "wk26": "wk17/26"})
ew = ec.pivot_table(index=["antigen", "arm", "participant"], columns="tp2", values="value")
ef = e[e.measure == "fold_change"].pivot_table(index=["antigen", "arm", "participant"], columns="timepoint", values="value")
r4 = (ew["wk4"] / ew["wk0"]) / ef["wk4"]
rL = (ew["wk17/26"] / ew["wk0"]) / ef["wk17/26"]
add("elisa_igg_titers.csv", "reported fold-change = EC50 ratio",
    f"wk4 ratio median {r4.median():.3f} (range {r4.min():.3f}-{r4.max():.3f}); wk17/26 median {rL.median():.3f} (range {rL.min():.3f}-{rL.max():.3f})",
    "Consistent if ~1.")
add("elisa_igg_titers.csv", "participant ID format", "integers (1, 2, ... 102) vs '397-0NN' elsewhere", "Needs a controlled ID map before any pooled analysis.")

igm = pd.read_csv(f"{IN}/igm_fold_change.csv", dtype={"participant": str})
add("igm_fold_change.csv", "ID format", f"{sorted(set(igm.participant) - set(p.zfill(3) for p in igm.participant))} not zero-padded", "Minor; normalised.")
add("igm_fold_change.csv", "Fluarix 397-005 IgM", f"fold-change {igm[(igm.participant=='005')].fold_change.round(0).tolist()} (H1,H3,B/Yam,B/Vic)",
    "~170-210-fold for every antigen in one person - implausible as antigen-specific; outlier/assay artefact to query.")

mab = pd.read_csv(f"{IN}/mab_binding_panels.csv")
neg = (mab.fold_over_control < 0).sum()
add("mab_binding_panels.csv", "negative fold-over-control values", f"{neg} rows < 0 (min {mab.fold_over_control.min():.3f})",
    "A fold value cannot be negative -> background-subtracted ratio; positivity threshold must be pre-specified.")
mab["donor"] = mab.mab_id.str.split(".").str[1]
add("mab_binding_panels.csv", "mAbs per donor",
    mab.groupby(["arm", "donor"]).mab_id.nunique().to_dict().__repr__(),
    "4 mRNA-1010 donors vs 3 Fluarix donors; 589 vs 106 mAbs. The donor, not the mAb, is the unit of inference.")

bb1 = pd.read_csv(f"{IN}/binding_breadth_h1.csv"); bb3 = pd.read_csv(f"{IN}/binding_breadth_h3.csv")
add("binding_breadth_h1/h3.csv", "timepoint of log2 fold-change", "not stated", "Assumed post-vaccination vs day 0; cannot verify.")
add("binding_breadth_h1.csv", "vaccine antigens on panel",
    f"A/Victoria/4897/2022 (mRNA-1010 H1) absent; A/Victoria/2570/2019 (Fluarix 2022-23 H1) absent; strains: {sorted(bb1.strain.unique())}",
    "No homologous H1 reference for either arm on the bead array.")
add("binding_breadth_h3.csv", "vaccine antigens on panel",
    "A/Darwin/6/2021 present; A/Darwin/9/2021 (Fluarix 2022-23 H3, egg-based recommendation) absent", "Homologous H3 reference is the mRNA-1010 (cell-type) strain only.")

for f in ["cdrh3_diversity_index.csv", "serum_igg_clonotypes.csv", "repertoire_clonotype_counts.csv"]:
    d = pd.read_csv(f"{IN}/{f}")
    add(f, "participant identifiers", f"none; {len(d)} rows; per-arm n at each timepoint = {d.groupby([c for c in d.columns if c in ('timepoint','metric')] + ['arm']).size().to_dict()}",
        "Sub-cohort (8/arm) is not declared in the summary and cannot be linked to any other readout.")

add("trial_summary.md", "antigen composition vs season",
    "mRNA-1010 H1 = A/Victoria/4897/2022 (WHO NH 2023-24 egg-based H1 pick, clade 5a.2a.1); Fluarix 2022-23 NH H1 = A/Victoria/2570/2019-like (5a.2). H3: A/Darwin/6/2021 (cell-type) vs A/Darwin/9/2021-like (egg-type), same clade.",
    "Arms differ in H1 antigen by ~one drift step: any 'heterologous' H1 advantage toward 2022-23+ strains is confounded by antigen choice, not platform.")
add("trial_summary.md", "B/Yamagata component", "both arms include B/Phuket/3073/2013",
    "B/Yamagata has not been confirmed in circulation since March 2020 and WHO recommended removal from 2024-25; a B/Yam heterologous-protection claim is untestable clinically.")
add("trial_summary.md", "allocation", "non-randomised, by enrolment site; open-label",
    "Site (population, prior vaccination, assay batch) is fully confounded with arm.")

pd.DataFrame(findings).to_csv(f"{TAB}/integrity_findings.csv", index=False)
print(f"\n{len(findings)} findings written")
