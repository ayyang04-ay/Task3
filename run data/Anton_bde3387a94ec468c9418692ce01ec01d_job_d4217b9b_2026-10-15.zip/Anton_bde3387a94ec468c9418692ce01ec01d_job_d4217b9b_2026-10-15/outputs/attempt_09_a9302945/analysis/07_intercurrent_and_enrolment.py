"""07 - Screens for (a) possible intercurrent influenza infection between the
post-vaccination peak (wk4/d29) and the late visit, and (b) enrolment-order /
site structure by arm (allocation was by site, non-randomised).

A >=4-fold rise from wk4 to the late visit is not expected from vaccination
alone and flags possible infection (or sample/label error). No infection
surveillance (PCR, non-HA serology) exists in the package to adjudicate.
Outputs: tables/late_rise_flags.csv, tables/enrolment_blocks.csv
"""
import numpy as np
import pandas as pd
from scipy import stats
from common import IN, TAB, pid, gm_ci

flags = []
# HAI
h = pd.read_csv(f"{IN}/hai_titers.csv", dtype={"participant": str}); h["pid"] = h.participant.map(pid)
hw = h.pivot_table(index=["antigen", "arm", "pid"], columns="timepoint", values="hai_titer")
hw["late"] = hw["wk26"].fillna(hw["wk17"])
r = (hw.late / hw.wk4)
for (ag, arm, p), v in r[r >= 2].items():
    flags.append(dict(assay="HAI", readout=ag, arm=arm, pid=p, rise_wk4_to_late=round(v, 2),
                      values=f"{hw.loc[(ag,arm,p),'wk0']:.0f}->{hw.loc[(ag,arm,p),'wk4']:.0f}->{hw.loc[(ag,arm,p),'late']:.0f}"))
# MN
m = pd.read_csv(f"{IN}/microneutralization.csv"); m["pid"] = m.participant.map(pid)
mw = m[m.measure == "titer"].pivot_table(index=["panel", "arm", "pid"], columns="timepoint", values="value")
mw["late"] = mw["wk26"].fillna(mw["wk17"])
r = mw.late / mw.wk4
for (pn, arm, p), v in r[r >= 2].items():
    flags.append(dict(assay="MN", readout=pn, arm=arm, pid=p, rise_wk4_to_late=round(v, 2),
                      values=f"{mw.loc[(pn,arm,p),'wk0']:.0f}->{mw.loc[(pn,arm,p),'wk4']:.0f}->{mw.loc[(pn,arm,p),'late']:.0f}"))
# ELISA
e = pd.read_csv(f"{IN}/elisa_igg_titers.csv"); e["pid"] = e.participant.map(pid)
ew = e[e.measure == "ec50"].pivot_table(index=["antigen", "arm", "pid"], columns="timepoint", values="value")
ew["late"] = ew["wk26"].fillna(ew["wk17"])
r = ew.late / ew.wk4
for (ag, arm, p), v in r[r >= 2].items():
    flags.append(dict(assay="ELISA IgG", readout=ag, arm=arm, pid=p, rise_wk4_to_late=round(v, 2),
                      values=f"{ew.loc[(ag,arm,p),'wk0']:.0f}->{ew.loc[(ag,arm,p),'wk4']:.0f}->{ew.loc[(ag,arm,p),'late']:.0f}"))
# seq-neut, participant mean over category
ps = pd.read_csv(f"{TAB}/seqneut_category_participant.csv", dtype={"pid": str})
ps["rise"] = 2 ** (ps.late - ps.d29)
for _, row in ps[ps.rise >= 2].iterrows():
    flags.append(dict(assay="seq-neut", readout=row.category, arm=row.arm, pid=row.pid, rise_wk4_to_late=round(row.rise, 2),
                      values=f"GMT {2**row.d0:.0f}->{2**row.d29:.0f}->{2**row.late:.0f}"))
fl = pd.DataFrame(flags).sort_values(["pid", "assay"])
fl.to_csv(f"{TAB}/late_rise_flags.csv", index=False)
print(fl.to_string(index=False))
print("\n>=2-fold late rises by arm & assay:\n", fl.groupby(["assay", "arm"]).pid.nunique())
print("participants with >=4-fold late rise:", fl[fl.rise_wk4_to_late >= 4][["assay", "readout", "arm", "pid", "values"]].to_string(index=False))

# ---------------- enrolment blocks (ELISA cohort carries the full ID range)
ids = e[["pid", "arm"]].drop_duplicates(); ids["n"] = ids.pid.astype(int)
ids["block"] = pd.cut(ids.n, [0, 32, 62, 200], labels=["001-032 (interleaved)", "033-062", "063-102"])
eb = ids.groupby(["block", "arm"], observed=False).size().unstack(fill_value=0)
print("\nParticipant-ID blocks by arm (ELISA cohort):\n", eb)
eb.to_csv(f"{TAB}/enrolment_blocks.csv")
# baseline ELISA by block within arm
bw = ew.reset_index().merge(ids[["pid", "block"]], on="pid")
for ag in ["A/H1", "A/H3"]:
    a = bw[bw.antigen == ag]
    print(ag, "baseline EC50 GMT by arm x block:",
          {f"{arm}|{b}": round(gm_ci(g.wk0)[0]) for (arm, b), g in a.groupby(["arm", "block"], observed=True)})
    print(ag, "wk4/wk0 GMFR by arm x block:",
          {f"{arm}|{b}": round(gm_ci(g.wk4 / g.wk0)[0], 2) for (arm, b), g in a.groupby(["arm", "block"], observed=True)})
