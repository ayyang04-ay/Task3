"""04 - Bead-array binding breadth (log2 fold-change MFI; timepoint not stated).

Per-strain arm comparison + participant-level breadth scores, and a direct
participant-level comparison of binding breadth vs neutralisation breadth
(seq-neut) to test whether binding gains translate into function.
Outputs: tables/binding_breadth_by_strain.csv, tables/binding_vs_neut.csv
"""
import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests
from common import IN, TAB, pid

pd.set_option("display.width", 250); pd.set_option("display.max_columns", 40)

# strain context (year of isolation; relation to each arm's H1/H3 antigen)
CTX = {
    "A/Puerto Rico/8/1934": "H1 ancestral (1934)", "A/California/04/2009": "H1 pdm09 prototype",
    "A/Michigan/45/2015": "H1 historical vaccine", "A/Brisbane/2/2018": "H1 historical vaccine",
    "A/Guangdong-Maonan/SWL1536/2019": "H1 historical vaccine", "A/Hawaii/70/2019": "H1 historical vaccine",
    "A/Wisconsin/588/2019": "H1 Fluarix 2022-23 clade analogue (5a.2)",
    "A/Sydney/5/2021": "H1 5a.2a (post-vaccine drift)", "A/Wisconsin/67/2022": "H1 mRNA-1010 clade analogue (5a.2a.1)",
    "A/Hong Kong/1/1968": "H3 ancestral (1968)", "A/Brisbane/10/2007": "H3 historical vaccine",
    "A/Perth/16/2009": "H3 historical vaccine", "A/Victoria/361/2011": "H3 historical vaccine",
    "A/Texas/50/2012": "H3 historical vaccine", "A/Singapore/INFIMH-16-0019/2016": "H3 historical vaccine",
    "A/Switzerland/8060/2017": "H3 historical vaccine", "A/South Australia/34/2019": "H3 historical vaccine",
    "A/Hong Kong/2671/2019": "H3 historical vaccine", "A/Cambodia/e0826360/2020": "H3 historical vaccine",
    "A/Darwin/6/2021": "H3 vaccine strain (both arms' clade)", "A/Thailand/8/2022": "H3 forward drift (2a.3a.1)",
}
rows = []
allp = []
for f in ["binding_breadth_h1.csv", "binding_breadth_h3.csv"]:
    d = pd.read_csv(f"{IN}/{f}"); d["pid"] = d.participant.map(pid)
    for s, g in d.groupby("strain"):
        m = g[g.arm == "mRNA-1010"].log2_fold_change_mfi; fl = g[g.arm == "Fluarix"].log2_fold_change_mfi
        t = stats.ttest_ind(m, fl, equal_var=False)
        rows.append(dict(panel=f[-6:-4].upper(), strain=s, context=CTX.get(s, ""),
                         mean_FC_mRNA=round(2 ** m.mean(), 2), mean_FC_Fluarix=round(2 ** fl.mean(), 2),
                         ratio_mRNA_over_Flu=round(2 ** (m.mean() - fl.mean()), 2),
                         ci95=f"{2**(m.mean()-fl.mean()-stats.t.ppf(.975,t.df)*np.sqrt(m.var()/len(m)+fl.var()/len(fl))):.2f}-{2**(m.mean()-fl.mean()+stats.t.ppf(.975,t.df)*np.sqrt(m.var()/len(m)+fl.var()/len(fl))):.2f}",
                         welch_p=t.pvalue, n_m=len(m), n_f=len(fl)))
    allp.append(d)
bb = pd.DataFrame(rows)
bb["q_BH"] = multipletests(bb.welch_p, method="fdr_bh")[1]
bb = bb.sort_values(["panel", "ratio_mRNA_over_Flu"])
bb.round(4).to_csv(f"{TAB}/binding_breadth_by_strain.csv", index=False)
print(bb.round(4).to_string(index=False))

# participant-level binding breadth: mean log2FC across panel strains (H1, H3 separately)
ap = pd.concat(allp)
ap["sub"] = np.where(ap.strain.isin(pd.read_csv(f"{IN}/binding_breadth_h1.csv").strain.unique()), "H1", "H3")
pb = ap.groupby(["sub", "arm", "pid"]).log2_fold_change_mfi.mean().unstack("sub").reset_index()
pb.columns = ["arm", "pid", "bind_H1", "bind_H3"]

# neutralisation breadth from seq-neut (participant mean log2 d29/d0 over 2023 H1 isolates / 2022-24 H3 isolates)
ps = pd.read_csv(f"{TAB}/seqneut_category_participant.csv", dtype={"pid": str})
nh1 = ps[ps.category == "H1 2023 isolates"][["pid", "fc29"]].rename(columns={"fc29": "neut_H1_2023"})
nh3 = ps[ps.category == "H3 2022-24 isolates"][["pid", "fc29"]].rename(columns={"fc29": "neut_H3_2022_24"})
j = pb.merge(nh1, on="pid", how="left").merge(nh3, on="pid", how="left")
j.to_csv(f"{TAB}/binding_vs_neut.csv", index=False)
print("\nParticipant-level: binding breadth (mean log2FC) vs neutralisation breadth (mean log2 d29/d0)")
for arm in ["mRNA-1010", "Fluarix", "all"]:
    g = j if arm == "all" else j[j.arm == arm]
    g = g.dropna()
    r1 = stats.spearmanr(g.bind_H1, g.neut_H1_2023); r3 = stats.spearmanr(g.bind_H3, g.neut_H3_2022_24)
    print(f"  {arm:9s} n={len(g):2d}  H1 rho={r1.statistic:.2f} (p={r1.pvalue:.2f})  H3 rho={r3.statistic:.2f} (p={r3.pvalue:.2f})")
for arm in ["mRNA-1010", "Fluarix"]:
    g = j[j.arm == arm]
    print(f"  {arm}: mean binding FC H3 panel {2**g.bind_H3.mean():.2f}x; mean neut FC to 2022-24 H3 isolates {2**g.neut_H3_2022_24.mean():.2f}x")
