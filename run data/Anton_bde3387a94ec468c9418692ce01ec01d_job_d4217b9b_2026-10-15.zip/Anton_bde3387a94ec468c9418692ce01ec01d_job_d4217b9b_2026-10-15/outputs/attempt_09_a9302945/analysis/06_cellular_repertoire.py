"""06 - Lymph-node GC, plasmablast, clonal overlap and serum repertoire data.

All descriptive (n = 6 vs 11 FNA; 8 vs 8 unlinked repertoire samples).
gc_frequencies.csv contains two stacked blocks with identical keys; both are
summarised separately ('block1' = first 78 rows, 'block2' = last 78 rows).
Outputs: tables/gc_summary.csv, tables/pb_summary.csv, tables/repertoire_summary.csv
"""
import numpy as np
import pandas as pd
from scipy import stats
from common import IN, TAB, pid

pd.set_option("display.width", 250); pd.set_option("display.max_columns", 40)
ORD = ["wk0", "wk2", "wk4", "wk8", "wk17", "wk26"]

gc = pd.read_csv(f"{IN}/gc_frequencies.csv", dtype={"participant": str})
half = len(gc) // 2
gc["block"] = ["block1"] * half + ["block2"] * (len(gc) - half)
gs = gc.groupby(["block", "timepoint", "arm"]).pct_ha_specific_igg_gc.agg(
    n="count", median="median", q1=lambda s: s.quantile(.25), q3=lambda s: s.quantile(.75),
    n_zero=lambda s: int((s == 0).sum())).reset_index()
gs["tp_order"] = gs.timepoint.map({t: i for i, t in enumerate(ORD)})
gs = gs.sort_values(["block", "tp_order", "arm"]).drop(columns="tp_order")
gs.round(2).to_csv(f"{TAB}/gc_summary.csv", index=False)
print(gs.round(2).to_string(index=False))
b1 = gc[gc.block == "block1"]
for tp in ["wk2", "wk8", "wk17", "wk26"]:
    a = b1[b1.timepoint == tp]
    p = stats.mannwhitneyu(a[a.arm == "mRNA-1010"].pct_ha_specific_igg_gc, a[a.arm == "Fluarix"].pct_ha_specific_igg_gc).pvalue
    print(f"block1 {tp}: MWU p = {p:.3f}")

pb = pd.read_csv(f"{IN}/plasmablast_frequencies.csv", dtype={"participant": str})
pb["pid"] = pb.participant.map(pid)
fna = set(gc.participant.map(pid))
pb["in_FNA_subset"] = pb.pid.isin(fna)
ps = pb.groupby(["timepoint", "arm", "in_FNA_subset"]).pct_plasmablast.agg(n="count", median="median", max="max").reset_index()
ps["o"] = ps.timepoint.map({t: i for i, t in enumerate(ORD)}); ps = ps.sort_values(["o", "arm", "in_FNA_subset"]).drop(columns="o")
ps.round(3).to_csv(f"{TAB}/pb_summary.csv", index=False)
print("\nPlasmablast % (split by whether participant is in the declared FNA subset):\n", ps.round(3).to_string(index=False))

ov = pd.read_csv(f"{IN}/pb_gc_clonal_overlap.csv")
ov["arm"] = ov.Participant.map(lambda p: "mRNA-1010" if p in ("397-06", "397-17", "397-28", "397-29") else "Fluarix")
print("\nPB-GC clonal overlap:\n", ov[["Participant", "arm", "Number of GC B cell clones", "Percentage of overlapping clones out of GC B cell clones", "Percentage of overlapping clones out of wk1 PB clones"]].to_string(index=False))

rep = pd.read_csv(f"{IN}/repertoire_clonotype_counts.csv")
cd = pd.read_csv(f"{IN}/cdrh3_diversity_index.csv")
sc = pd.read_csv(f"{IN}/serum_igg_clonotypes.csv")
rows = []
for metric, g in rep.groupby("metric"):
    m, f = g[g.arm == "mRNA-1010"].value, g[g.arm == "Fluarix"].value
    rows.append(dict(source="repertoire_clonotype_counts", metric=metric, median_mRNA=m.median(), median_Flu=f.median(),
                     n=f"{len(m)}/{len(f)}", MWU_p=stats.mannwhitneyu(m, f).pvalue))
for tp in ["wk0", "wk4", "wk26"]:
    for name, d, col in [("cdrh3_diversity_index", cd, "diversity_index"), ("serum_igg_clonotypes", sc, "n_clonotypes")]:
        a = d[d.timepoint == tp]; m, f = a[a.arm == "mRNA-1010"][col], a[a.arm == "Fluarix"][col]
        rows.append(dict(source=name, metric=tp, median_mRNA=m.median(), median_Flu=f.median(), n=f"{len(m)}/{len(f)}",
                         MWU_p=stats.mannwhitneyu(m, f).pvalue))
rs = pd.DataFrame(rows)
rs.round(3).to_csv(f"{TAB}/repertoire_summary.csv", index=False)
print("\nSerum repertoire (no participant IDs; unlinked 8 vs 8):\n", rs.round(3).to_string(index=False))
# consistency: wk0 serum clonotypes equal 'pre-existing' counts?
print("wk0 serum clonotype counts == n_pre_existing_clonotypes (same order):",
      {a: list(sc[(sc.timepoint == "wk0") & (sc.arm == a)].n_clonotypes) == list(rep[(rep.metric == "n_pre_existing_clonotypes") & (rep.arm == a)].value.astype(int)) for a in ["mRNA-1010", "Fluarix"]})
