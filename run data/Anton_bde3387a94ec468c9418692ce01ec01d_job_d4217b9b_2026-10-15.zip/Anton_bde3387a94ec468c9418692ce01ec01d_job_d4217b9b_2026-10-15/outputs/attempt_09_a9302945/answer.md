**Recommendation: treat WU397 as hypothesis-generating only; before any heterologous-protection claim, take a randomised, antigen-matched breadth-and-durability trial to committee (mRNA vs sequence-matched recombinant HA vs egg-based IIV; co-primary neutralisation against a locked drifted-virus panel at day 29 and day 181), alongside a drifted-strain challenge study, with an event-driven trial on sequence-confirmed mismatched-strain influenza as the only route to the claim.**

---

## Bottom line for the committee

* **What WU397 shows.** mRNA-1010 made much more **binding** antibody and germinal-centre (GC) activity than Fluarix. For H3 the binding gain was 3.1–10×, and binding was also broader. It did **not** produce more **neutralising** antibody against drifted viruses on the one subtype where both arms got matched antigens (H3). It also did not hold its only functional advantage, a ~2× higher H1 neutralising titre at day 29, through the season.
* **What it cannot show.** The design cannot support a breadth or protection claim:
  * Allocation was non-randomised, by site.
  * The arms received different H1 antigens.
  * "Homologous/heterologous" is defined only against mRNA-1010's own antigens.
  * Functional cohorts are 13–15 per arm.
  * There are no clinical or infection endpoints.
* **What the claim needs.** HAI-based licensure criteria apply only to vaccine-homologous strains; there is no accepted immune surrogate for protection against drifted strains [external]. A heterologous-protection claim therefore has to rest on clinical efficacy against **sequence-confirmed, antigenically mismatched** influenza (Study 3). Studies 1 and 2 decide whether Study 3 is worth running.
* **Before the protocol goes in.** Close out the WU397 data issues (Study 0). Two items directly affect how "homologous" is labelled: which H1 was actually in the mRNA-1010 lot, and which viruses make up the MN panels.

---

## 1. What WU397 supports and what it doesn't

### 1.1 Binding and cellular readouts vs functional readouts

All ratios are mRNA-1010 ÷ Fluarix, adjusted for baseline (ANCOVA on log titre), with 95% CI. Here "late" means week 17/26 (day 121/181).

| Readout (n mRNA / Fluarix) | Early (wk4 / d29) | Late | Reading |
|---|---|---|---|
| ELISA IgG, H1 (38/37) | **2.66** (2.01–3.53) | 1.51 (1.19–1.91) | Strong binding gain, partly durable |
| ELISA IgG, H3 | **3.31** (2.47–4.43) | 2.06 (1.57–2.70) | Same |
| ELISA IgG, B/Vic; B/Yam | 1.35; 1.38 | 0.99; 1.06 | Small, gone by late |
| Bead-array binding fold-rise, 12 H3 strains 1968–2022 (14/15) | 3.07–10.07× (all q ≤0.002) | n/a | Broad **binding** |
| HA-specific GC B cells, wk2 (FNA 6/11) | median 24.2% vs 2.3% (p=0.037) | wk17: 16.0% vs 2.3% | More GC activity |
| HAI, H1 / H3 / B-Vic / B-Yam (14/15) | 1.54 (0.87–2.71) / 1.06 / 1.05 / 1.01 | H1 **0.83** (0.47–1.46) | No significant functional gain; H1 trend reverses |
| MN, "homologous" panel (mRNA-1010's antigens) | **0.68** (0.31–1.51); ceiling-censored model 0.47 | 0.64 | Fluarix numerically higher, even on mRNA-1010's own antigens |
| MN, "heterologous" panel | 1.17 (0.52–2.62) | 0.73 | No gain once baseline is adjusted |
| Seq-neut, H1 2023 isolates, 6 viruses (13/14) | **2.06** (1.23–3.46) | **1.17** (0.77–1.77) | ~2× at d29, not durable |
| Seq-neut, own H3 strain A/Darwin/6/2021 | **0.62** (0.34–1.12) | 0.72 | No gain |
| Seq-neut, H3 2024–25 vaccine picks (A/Thailand/8/2022, A/Massachusetts/18/2022) | 0.92 (0.44–1.92) | 0.85 | No gain |
| Seq-neut, **H3 2022–24 drifted isolates (66 viruses)** | **1.18 (0.65–2.13)** | 1.05 (0.66–1.68) | **No detectable forward breadth** |
| Seq-neut, H3 historical 2012–2020 | 1.63 (0.99–2.68) | 1.44 | Skews backward (back-boosting) |

### 1.2 Why these signals do not add up to heterologous protection

1. **Binding did not translate into neutralisation.** Take the same strains on both platforms (Fig. `figures/binding_vs_neut_by_strain.png`). For the six H3 strains on both panels, mRNA-1010's binding advantage of 3.8–10× became a neutralisation ratio of 0.62–2.06×. For the two H3 strains that matter most it fell below 1:
   * its own vaccine strain, A/Darwin/6/2021: binding 6.10×, neutralisation 0.62×;
   * the forward strain A/Thailand/8/2022: binding 9.45×, neutralisation 0.82×.

   Within participants, binding breadth tracked neutralisation breadth in Fluarix recipients (Spearman ρ 0.71 for H1 and 0.63 for H3) but not in mRNA-1010 recipients (ρ 0.30 and 0.29). Most of the extra antibody is therefore non-neutralising. Whether it protects, for example through Fc-mediated effects, is untested and can only be settled by outcome data.
2. **The H1 advantage is in magnitude, not breadth, and it fades.** The ~2× gain is consistent across every H1 class (1.6–2.4×), including 2009–2019 strains. There is no arm-by-class interaction (p=0.15); the common effect is 1.91× (1.19–3.05). The largest point estimate is against the Fluarix-clade virus (2.44×). mRNA-1010 H1 titres fell to 0.43× of their d29 level by day 121/181, against 0.78× for Fluarix, so by day 121/181 the advantage was no longer detectable (1.17×, 0.77–1.77). HAI shows the same: 1.54× at week 4, 0.83× late.
3. **H3 is the only antigen-matched subtype, and shows no forward breadth.** Both arms got an A/Darwin/2021 (3C.2a1b.2a.2) H3, so H3 is the cleanest platform test. Against 66 drifted 2022–24 isolates the effect was 1.18×. Per virus it ranged 0.82–1.52, with 0/66 nominally significant. The response skewed backward: historical-minus-contemporary contrast 1.53× (0.94–2.48, p=0.085), participant-level.
4. **The "relative breadth" ratio is an artefact.** The heterologous/homologous titre ratio favours mRNA-1010 by 1.66× (p=0.007). That is only because mRNA-1010's response to its own H3 strain was weaker (0.62×), not because its heterologous titres were higher. Do not present it as breadth.
5. **Fold-rise comparisons are biased by baseline and by the assay ceiling.**
   * Heterologous MN: ≥4-fold responders were 9/14 vs 6/15. But baseline GMT was 57 vs 121 (ratio 0.47, p=0.05), and after adjustment the effect is 1.17× (0.52–2.62).
   * MN "homologous": 9/15 Fluarix vs 4/14 mRNA-1010 week-4 values sat at the 1:1280 ceiling.
6. **Egg-adapted reference viruses inflate "homologous" titres.** On the seq-neut panel, the only form of the stated mRNA-1010 H1 antigen is the egg reassortant A/Victoria/4897/2022 IVR-238. Its baseline titres are 4.9× those of its cell-grown clade analogue, A/Wisconsin/67/2022. Across five H3 egg/wild-type pairs, the egg form read 1.4–10.9× higher at baseline.
7. **B lineages are effectively untested.**
   * HAI rises were negligible in both arms: GMFR 1.05–1.35, seroconversion 0–7%.
   * No B viruses are on the seq-neut or bead-array panels.
   * B/Yamagata (B/Phuket/3073/2013, in both arms) has not been confirmed circulating since 2020 and was dropped from WHO recommendations from 2024–25 [external]. A B/Yam protection claim cannot be tested.
8. **The mAb, GC and repertoire data are small and binding-only.**
   * **mAbs.** mRNA-1010 group II (H3/H7) mAbs bound the drift strain A/Croatia/10136RV/2023 more often (donor means 72% vs 25%, exact p=0.057) and bound H7 more often (11% vs 0%, p=0.086). But there are 4 vs 3 donors, 79% of Fluarix mAbs come from one donor, and there is no functional readout.
   * **Repertoire.** Pre-existing clonotypes made up ~87% vs ~89% of serum IgG in both arms, so responses are dominated by recall.
   * **IgM.** IgM rises were larger with Fluarix (H3 5.53× vs 1.83×, p=0.013).

**What WU397 does support:** mRNA-1010 induces larger GC and binding-antibody responses, plus a transient ~2× higher H1 neutralising response.

**What it does not support:** broader neutralisation, durability, heterologous protection, or any regulatory immunogenicity criterion. At n=14/15, the FDA non-inferiority (NI) criteria cannot be met; the upper bound on seroconversion difference reaches 17–30 points.

### 1.3 Design features that limit any claim from WU397

* **Allocation and enrolment.** Allocation was non-randomised by site, and the study was open-label. Participant-ID blocks show the structure:
  * IDs 001–032 are interleaved between arms (15 Fluarix, 14 mRNA). **Every functional assay comes from this block.**
  * IDs 033–062 are all Fluarix (22); IDs 063–102 are all mRNA-1010 (24).

  Arm is therefore confounded with site and, if IDs were issued in order, with enrolment period.
* **Antigen mismatch between arms** [external; confirm against lot documents]:
  * mRNA-1010's stated H1, A/Victoria/4897/2022 (clade 5a.2a.1), was the WHO's **2023–24** egg-based pick.
  * Fluarix 2022–23 NH carried an A/Victoria/2570/2019-like H1 (5a.2) and an A/Darwin/9/2021-like H3 (egg type). mRNA-1010's H3 was A/Darwin/6/2021 (cell type, same clade).
  * The data do not cleanly fit the stated H1. In the mRNA-1010 arm, 12/13 participants rose more against the 5a.2 virus A/Wisconsin/588/2019 than against the 5a.2a.1 analogue A/Wisconsin/67/2022 (GMFR 6.15 vs 3.51; p=0.003). That pattern fits either a 5a.2 immunogen or strong back-boosting of 5a.2 memory. The binding array leans slightly the other way.

  Either way, H1 cannot isolate a platform effect: either the arms were a drift step apart, or the H1 labels are wrong.
* **Asymmetric labels.** "Homologous/heterologous" is defined only against mRNA-1010's antigens, so for Fluarix recipients the "homologous" panel is not their own vaccine.
* **Power.** The minimum detectable ratio at 80% power is 2.0–2.2× for d29 neutralisation. A 1.5× effect could be neither shown nor excluded.
* **Infection surveillance.** There is none. I found no ≥4-fold rise between peak and late visits, but 13 readouts rose 2–3.6-fold (e.g., Fluarix 016 vs A/Darwin/9/2021 3.6×), and these cannot be adjudicated.

### 1.4 Data-integrity items to close before citing WU397 (full list: `tables/integrity_findings.csv`)

| Issue | Why it matters |
|---|---|
| Stated mRNA-1010 H1 vs data pattern (above); MN panel viruses not identified | Sets every homologous/heterologous label |
| `gc_frequencies.csv` is two stacked 78-row blocks with identical keys and different values. FNA data have a wk0 (not scheduled) but lack the scheduled wk1 and wk4 | The GC readout and its schedule are ambiguous |
| `plasmablast_frequencies.csv`: 13/15 participants vs the declared FNA subset of 6/11. Timepoints match the FNA schedule, not the blood schedule, and there is no wk1. Values for the 11 extra participants carry 1–3 significant figures vs 6 decimals for the rest | Provenance unclear |
| HAI B/Vic late-visit labels contradict the other three antigens for 8 participants (4 per arm); B/Vic missing for 397-031; off-grid HAI value 288 | B/Vic late data unreliable |
| 397-014 (mRNA-1010): HAI H1/H3 rose 5.6× and ELISA H1 rose 36×, yet MN went 15→10. This participant is also absent from seq-neut | Sample or assay discordance |
| Fluarix 397-005: IgM rose 166–212× for **every** antigen; IgM and bead-array fold-changes have no stated timepoint | Outlier or artefact |
| Seq-neut "late" mixes d121 and d181 in different proportions per arm (Fluarix 4/14 at d121, mRNA-1010 2/13); one virus name has year "202023" | Late readouts must be analysed by actual day |
| Repertoire files (8 per arm) have no participant IDs and no declared cohort; mAb `fold_over_control` has 17 negative values | Cannot be linked to anything else |

---

## 2. Recommended studies

### 2.0 Specifications that apply to every study

* **Antigen matching.** The mRNA vaccine and the platform comparator carry the **same WHO-recommended HA sequences for the same season**. Use the trivalent composition (H1N1pdm09, H3N2, B/Victoria), not sponsor-picked strains. If mRNA is later given a fresher strain than the comparator, that is a separate "better match" claim and must not be folded into "heterologous protection".
* **Definition of "heterologous".** This is set before unblinding and applied to **both** arms. A virus counts as heterologous if:
  * its HA subclade is not represented by any vaccine antigen in **either** arm; **and**
  * reference post-infection ferret antisera against each arm's vaccine virus show a ≥8-fold drop in HI titre against it (the WHO Collaborating Centre convention for antigenic distinctness [external]).

  Egg or reassortant versions never count as separate viruses.
* **Virus panels**, locked before unblinding, for each of H3N2, H1N1 and B/Victoria:
  * **Homologous references.** Each arm's vaccine viruses, in wild-type (cell-grown) sequence; the egg-type virus is an extra reference only for the egg comparator.
  * **Contemporary heterologous set.** Viruses from the subclades circulating in the study season, weighted by prevalence.
  * **Forward heterologous set.** Emerging subclades flagged at the next WHO strain-selection meeting.
  * **Historical set.** Reported separately as a back-boosting index; it never counts toward breadth.
* **Readout hierarchy.**
  * Primary and key secondary: functional antibody, i.e. neutralising titre and HAI.
  * Key secondary: anti-NA (NAI) titre. The egg comparator contains NA, and WU397 has no NA readout.
  * Exploratory only: binding breadth, stem antibody, Fc-effector function, GC, repertoire and mAbs. WU397 shows that binding breadth does not predict neutralising breadth for this platform.
* **Analysis.**
  * The participant is the unit; the panel endpoint is each participant's geometric mean titre (GMT) across the panel.
  * Use ANCOVA on log titre with baseline and strata as covariates. No comparisons based on fold-rise alone.
  * Pre-specify rules for the limit of detection and the ceiling; assay range must not truncate post-dose titres.
  * Use fixed-sequence multiplicity control. Labs are blinded to arm.
* **Intercurrent infection.** Run active ILI (influenza-like illness) surveillance with PCR through the season, and test non-HA serology at the late visit. Post-infection samples are handled by a pre-specified estimand (hypothetical strategy for immunogenicity); infection cases are sequenced.

### Study 0: Close out WU397 (before committee; banked samples and records only)

* **In whom.** The existing WU397 participants, using banked sera and mAbs.
* **What's measured.**
  * Confirm the encoded H1 (and other HAs) of the mRNA-1010 lot and the Fluarix 2022–23 lot composition. Re-label all panels symmetrically.
  * Identify the MN viruses; if they cannot be identified, drop MN from the dossier.
  * Resolve every item in §1.4.
  * Add these readouts on banked sera:
    * NAI titres against N1 and N2;
    * neutralisation of B/Victoria viruses;
    * neutralisation of cell-grown, wild-type versions of **both** arms' H1 vaccine viruses (5a.2 and 5a.2a.1);
    * non-HA serology at each visit, to flag intercurrent infection;
    * neutralisation and Fc-function for the cross-reactive mAbs.
* **Output.** Reissue WU397 with baseline-adjusted, participant-level analyses (this package's tables), explicitly labelled hypothesis-generating. It cannot be made confirmatory.

### Study 1: Randomised, observer-blind, antigen-matched breadth and durability trial (Phase 2b) — the protocol to take forward now

**Question.** Given identical HA antigens, does the mRNA platform induce more functional antibody against drifted viruses, and does that last through a season?

**In whom**
* **Cohort A:** adults 18–64, stratified 18–49 / 50–64; **250 per arm** (750 total).
* **Cohort B:** adults ≥65; **150 per arm** (450 total).
* Central randomisation, stratified by:
  * age band;
  * documented prior-season vaccination;
  * baseline HAI to the H3 vaccine virus (<40 / ≥40).
* Record birth year (an imprinting covariate) and 5-season vaccination history.
* Exclude anyone vaccinated in the current season.

**Against what: vaccines (1:1:1)**
1. mRNA, trivalent, with the season's cell/recombinant-type HA sequences.
2. **Recombinant HA vaccine (RIV)** with the same sequences. This is the platform contrast: both vaccines are HA-only, sequence-matched and egg-free. Cell-culture IIV is an acceptable alternative.
3. Egg-based standard-dose IIV (Fluarix, giving continuity with WU397) in Cohort A. In Cohort B, the age-appropriate high-dose or adjuvanted IIV. This is the standard-of-care and regulatory reference.

**Against what: viruses.** The §2.0 panels: ≥8 heterologous H3N2, ≥6 H1N1 and ≥4 B/Victoria, plus the homologous and historical references.

**What's measured**

*Primary:* participant-level neutralising GMT across the **H3N2 heterologous panel at day 29**, mRNA vs RIV.

*Co-primary:* the same endpoint at **day 181** (durability to season's end).

*Key secondary, in fixed sequence:*
* H1N1 and then B/Victoria heterologous panels at D29 and D181;
* the same contrasts vs egg-IIV;
* HAI against the heterologous panels;
* homologous HAI and neutralisation against each arm's own vaccine viruses: GMT and seroconversion rate (SCR), with the NI estimate vs egg-IIV (margins 1.5 and 10 points);
* NAI against vaccine and heterologous N1/N2;
* proportion of participants with a ≥4-fold rise against ≥50% of heterologous viruses.

*Exploratory:*
* multiplex binding breadth;
* stem antibody;
* Fc-effector function;
* nasal IgA;
* an optional GC/repertoire sub-study (~15–20 per arm), mechanistic only.

*Safety:*
* solicited reactions days 1–7;
* unsolicited AEs to day 28;
* medically attended AEs (MAAEs), SAEs and AESIs to day 181 (day 365).

*Surveillance:* as in §2.0.

**When.** Day 0, day 8 (optional), day 29, day 91, day 181 and day 365. Add a **year-2 extension**: revaccinate with the updated composition in the same arm and read out at D29, to check that annual mRNA dosing keeps its breadth.

**Size rationale.** The primary analysis is in Cohort A; Cohort B uses the same hierarchy, analysed separately. Using WU397 residual SDs inflated 1.25× (log2 SD 1.02 at D29, 0.81 at D181), 90% power and two-sided α 0.05, detecting a 1.3× GMT ratio needs 240 per arm at D29 and 151 at D181. A 1.5× ratio needs 101 and 64. Cohort B is sized for 1.5×.

**Go to Study 3 if all of the following hold:**
* mRNA/RIV H3-panel GMT ratio is **≥1.5 with lower 95% bound >1.0 at D29**, and the lower bound is >1.0 at D181;
* no meaningful deficit vs egg-IIV on homologous HAI or NAI (lower bound ≥0.67);
* an acceptable safety profile.

If mRNA beats egg-IIV but **not RIV**, the advantage comes from avoiding egg adaptation and is shared with licensed non-egg vaccines, so re-scope the claim. If it beats neither, stop pursuing the heterologous claim.

### Study 2: Drifted-strain controlled human infection study (Phase 2a, run in parallel with Study 1)

**Question.** Does mRNA vaccination protect against infection with a **drifted** virus better than a sequence-matched licensed vaccine?

**In whom.** Healthy adults 18–45 with low pre-existing titre against the challenge virus (HAI ≤1:20), stratified by prior vaccination.

**Against what: vaccines.** mRNA vs RIV vs placebo, 1:1:1, double-blind, **~60 per arm**. The placebo arm calibrates the attack rate.

**Against what: challenge virus.** A GMP wild-type **H3N2** virus that meets the §2.0 heterologous definition relative to the vaccine H3. H3 is WU397's weakest subtype and the usual driver of mismatch. Challenge 4–8 weeks after vaccination. Add an optional second cohort challenged ~6 months after vaccination, since the durability loss is WU397's clearest failure mode.

**What's measured**
* *Primary:* PCR-confirmed infection.
* *Key secondary:*
  * symptomatic infection (mild-to-moderate influenza disease);
  * viral-load AUC;
  * symptom-score AUC;
  * duration of shedding.
* *Correlates:* pre-challenge measurements, modelled against outcome to nominate correlate(s) of heterologous protection for validation in Study 3:
  * neutralising titre and HAI against the challenge virus;
  * NAI against the challenge virus's NA;
  * stem antibody;
  * Fc function;
  * nasal IgA.

**Size rationale.** 42–58 per arm gives 80% power to detect halving of infection (60%→30% or 50%→25%). A smaller effect (60%→40%) needs 97 per arm.

**Go criterion.** mRNA vs RIV infection risk ratio ≤0.6 with upper 95% bound <1.0, or a ≥50% reduction in viral-load AUC.

**Limits.** Young adults, one strain, artificial inoculation. This study supports a mechanism and a go/no-go decision; it cannot support a label claim.

### Study 3: Event-driven, observer-blind, active-controlled relative-efficacy trial (Phase 3) — the claim-bearing study

**In whom**
* Adults ≥50, stratified 50–64 / ≥65, community-dwelling.
* Northern- **and** Southern-hemisphere sites, enrolled over ≥2 seasons. Mismatch depends on the season, so it cannot be scheduled.

**Against what: vaccine.** The licensed, age-appropriate vaccine for the same season: SD-IIV or RIV at 50–64; high-dose or adjuvanted IIV, or RIV, at ≥65. Placebo is not acceptable where vaccination is recommended, so the claim is **relative**.

**Against what: viruses.** Every PCR-positive case is HA-sequenced and antigenically characterised by a blinded central lab. A blinded committee classifies each case as **matched** or **mismatched** under the §2.0 definition before unblinding.

**What's measured**
* *Primary:* relative vaccine efficacy (rVE) against RT-PCR-confirmed, protocol-defined ILI from any strain, from day 15 to season end. Test NI, then superiority.
* *Key secondary, the claim:* **rVE against PCR-confirmed ILI caused by mismatched viruses.** Success means a lower 95% bound >0%, and ideally >10%.
* *Also:*
  * rVE against matched strains (to separate breadth from simply more antibody);
  * rVE by subtype and lineage;
  * rVE more than 90 days after vaccination (durability);
  * medically attended and hospitalised influenza.
* *Case-cohort immunogenicity subset:* HAI, neutralisation and NAI against the homologous and heterologous panels at D29 and D181. This validates correlates for future immunobridging and hosts the formal HAI NI. At 3 strains jointly at 90% power, the seroconversion-rate NI needs ~650–710 per arm.
* *Safety:* standard, plus platform-relevant AESIs (e.g., myocarditis/pericarditis).

**Size rationale.**
* At 90% power with lower bound >0, the trial needs **334 mismatched-strain cases for a true rVE of 30%**; 847 at 20%; 164 at 40%.
* At comparator attack rates of 1.5–3% and a mismatched share of 20–50%, that means **~26,000–131,000 participant-seasons**.
* So plan multiple seasons, with blinded event monitoring and a pre-specified rule for pooling across seasons.

### Decision gates

| Outcome | Decision |
|---|---|
| Study 1 passes vs RIV **and** Study 2 passes | Run Study 3 with the mismatched-strain rVE as key secondary, using Study 2 correlates in the case-cohort |
| Study 1 passes vs egg-IIV only | The benefit is egg-adaptation avoidance, not the platform. Drop "heterologous protection" or claim it only vs egg vaccines |
| Study 1 passes at D29 but fails at D181 | WU397's failure mode repeats. Address durability (dose or schedule) before Study 3 |
| NAI clearly inferior to egg-IIV | The breadth claim carries an NA gap. Consider an HA+NA construct before Study 3 |
| Study 1 fails on H3 | Stop the heterologous claim. Pursue a conventional HAI-NI licensure claim only |

---

## 3. Every number relied on, and its source

Input files are in `/tmp/world/filesystem/`. Derived tables are in `/tmp/outputs/tables/`. Every ratio is mRNA-1010 ÷ Fluarix.

| Number(s) | Source file(s) → analysis output |
|---|---|
| Cohorts: ELISA 38/37; HAI, MN, bead array, IgM 14/15; seq-neut 13/14; FNA 6/11; plasmablast 13/15; repertoire 8/8 | `trial_summary.md`, all CSVs → `cohort_sizes_observed.csv`, `integrity_findings.csv` (01) |
| ID blocks: 001–032 = 15 Fluarix / 14 mRNA; 033–062 = 22/0; 063–102 = 0/24 | `elisa_igg_titers.csv` → `enrolment_blocks.csv` (07) |
| ELISA wk4 ANCOVA: H1 2.66 (2.01–3.53), H3 3.31 (2.47–4.43), B/Vic 1.35 (1.04–1.75), B/Yam 1.38 (1.11–1.71). Late: 1.51, 2.06, 0.99, 1.06. GMFR H1 5.07 vs 1.90; H3 7.60 vs 1.99 | `elisa_igg_titers.csv` → `elisa_arm_comparison.csv`, `elisa_summary.csv` (02) |
| HAI wk4 ANCOVA: H1 1.54 (0.87–2.71); H3 1.06 (0.67–1.65); B/Vic 1.05 (0.71–1.56); B/Yam 1.01 (0.73–1.40). H1 late 0.83 (0.47–1.46). SCR H1 50% vs 33%, H3 14% vs 13%, B/Vic 0% vs 7%, B/Yam 0% vs 7%. B GMFR 1.05–1.35. FDA NI: SCR upper bound 17–30 points; GMT upper bound (Fluarix ÷ mRNA) met only for H1 (1.09; H3 2.17, B/Vic 1.61, B/Yam 1.76) | `hai_titers.csv` → `hai_arm_comparison.csv`, `hai_summary.csv` (02) |
| MN homologous 0.68 (0.31–1.51), Tobit 0.47 (0.14–1.56), late 0.64. Heterologous 1.17 (0.52–2.62), late 0.73. Baseline heterologous GMT 57 vs 121 (ratio 0.47, p=0.05). ≥4-fold 9/14 vs 6/15. Ceiling 1:1280: 9/15 vs 4/14 at wk4 | `microneutralization.csv` → `mn_arm_comparison.csv`, `mn_summary.csv` (02) |
| Bead array: H3 ratios 3.07–10.07 (q ≤0.0017); H1 1.26–2.70. Darwin/6 6.10; Thailand/8 9.45. Mean H3-panel binding fold-rise 10.50× vs 1.83× | `binding_breadth_h1.csv`, `binding_breadth_h3.csv` → `binding_breadth_by_strain.csv`, log 04 |
| Binding–neutralisation ρ: mRNA-1010 0.30 / 0.29 (p=0.32 / 0.33); Fluarix 0.71 / 0.63 (p=0.005 / 0.017) | bead array + seq-neut → `binding_vs_neut.csv` (04) |
| Same-strain binding vs neutralisation ratios (e.g., Darwin/6 6.10 vs 0.62; Thailand/8 9.45 vs 0.82) | → `binding_vs_neut_by_strain.csv` (10) |
| Seq-neut category ANCOVA at d29 / late: H1 2023 2.06 (1.23–3.46) / 1.17 (0.77–1.77); 5a.2 2.44 (1.18–5.05); 5a.2a.1 2.07 (1.26–3.38); Darwin/6 0.62 (0.34–1.12) / 0.72; Darwin/9 0.81 (0.35–1.87); 2024–25 picks 0.92 (0.44–1.92); H3 2022–24 1.18 (0.65–2.13) / 1.05 (0.66–1.68); H3 historical 1.63 (0.99–2.68) / 1.44 | `neutralization_seqbased.csv` → `seqneut_category_comparison.csv`, `seqneut_category_forest.csv` (03, 11) |
| Per virus: 12/96 nominal p<0.05, 0/96 after BH, 79/96 point estimates >1; H3 2022–24 range 0.82–1.52, 0/66 significant | → `seqneut_per_virus.csv` (03) |
| Decay late/d29: H1 2023 0.43 (mRNA) vs 0.78 (Fluarix); H3 2022–24 0.64 vs 0.67 | → `seqneut_durability.csv` (03) |
| H1 common effect 1.91 (1.19–3.05), interaction p=0.15. H3 backward skew 1.53 (0.94–2.48), p=0.085. Relative breadth 1.66 (1.16–2.37), p=0.007. 5a.2 vs 5a.2a.1 rise: 6.15 vs 3.51, 12/13 participants, p=0.003 | → `interaction_models.txt` (09) |
| Egg/wild-type baseline ratio 1.44–10.88; IVR-238 vs Wisconsin/67/2022 4.9× | → `seqneut_egg_vs_wt.csv`, log 03 |
| GC (block 1) wk2 24.2% vs 2.3% (p=0.037); wk17 16.0% vs 2.3% | `gc_frequencies.csv` → `gc_summary.csv` (06) |
| Vaccine-elicited clonotypes 32 vs 17.5 (p=0.066); pre-existing abundance 87% vs 89% | `repertoire_clonotype_counts.csv` → `repertoire_summary.csv` (06) |
| IgM GMFR: H3 5.53 vs 1.83 (p=0.013); B/Vic 4.40 vs 1.55; B/Yam 5.77 vs 1.94; 397-005 166–212× | `igm_fold_change.csv` → `igm_summary.csv` (02), `integrity_findings.csv` |
| mAbs: group II drift 72% vs 25% (p=0.057); H7 11.3% vs 0% (p=0.086); antigens bound 4.7 vs 2.0 (p=0.029). Group I drift 93% vs 82%; H5 3.1% vs 2.2%. 589 vs 106 mAbs; 79% of Fluarix mAbs from donor 05 | `mab_binding_panels.csv` → `mab_arm_donor_level.csv`, `mab_donor_binding.csv` (05) |
| Late rises: none ≥4-fold; 13 readouts at 2–3.6× | → `late_rise_flags.csv` (07) |
| Minimum detectable ratio in WU397 (80% power): 2.24 (H3, d29), 2.02 (H1, d29). Residual SD 1.02 (d29), 0.81 (late). Sizes 240/151/101/64 per arm; HAI GMT NI 153–279; SCR NI 648–712; challenge study 42–58 (97); events 334/847/164; 26,197–130,981 participant-seasons | → `design_calcs.csv` (08) |
| **External, not in the package; verify.** WHO NH recommendations: 2022–23 egg-based H1 A/Victoria/2570/2019-like and H3 A/Darwin/9/2021-like; 2023–24 egg-based H1 A/Victoria/4897/2022; 2024–25 H3 A/Thailand/8/2022 / A/Massachusetts/18/2022. Clade labels. B/Yamagata removed from 2024–25. FDA 2007 immunogenicity NI criteria (GMT ratio upper bound ≤1.5; SCR difference upper bound ≤10 points). WHO CC ≥8-fold antigenic-distinctness convention | General regulatory and WHO knowledge; confirm the Fluarix lot against its label |

## 4. Caveats on this review

* The analyses are reproducible (`analysis/run_all.sh`) but exploratory. With n=13–15 per arm, every non-significant result here is inconclusive rather than a demonstrated absence of effect. The H3 drifted-isolate CI (0.65–2.13) still allows a 2× advantage, which is exactly why Study 1 is needed.
* The planning sizes rest on assumptions and WU397 variances, not on a statistical analysis plan. In particular: attack rates, mismatched share, the 1.25× SD inflation, and challenge-study infection rates.
* Figures are in `figures/`:
  * `seqneut_category_forest.png`: arm effect by virus class, d29 vs late.
  * `binding_vs_neut_by_strain.png`: same-strain binding vs neutralisation.
  * `seqneut_per_virus_forest.png`: all 96 viruses.
  * `seqneut_participant_breadth.png`: participant trajectories.
