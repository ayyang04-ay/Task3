# WU397 data-package review — outputs

* `answer.md` is the recommendation memo. Its first line is the one-line recommendation.
* `analysis/` holds the scripts. Run `analysis/run_all.sh` to regenerate every table, figure and log from the read-only inputs in `/tmp/world/filesystem`. It uses the `core` micromamba env.
* `tables/` holds every number quoted in `answer.md`, as CSV or TXT.
* `figures/` holds the four figures referenced in the memo.
* `logs/` holds stdout from each script.

| Script | What it does | Main outputs |
|---|---|---|
| 01_integrity.py | Checks each file against trial_summary.md: cohorts, schedule, IDs, arithmetic and label consistency | integrity_findings.csv, cohort_sizes_observed.csv |
| 02_serology.py | HAI, MN, ELISA IgG, IgM. Gives GMT, GMFR, SCR, baseline-adjusted ANCOVA, Tobit for the MN ceiling, and the FDA NI criteria for orientation | hai_*.csv, mn_*.csv, elisa_*.csv, igm_summary.csv |
| 03_seqneut.py | The 96-virus seq-neut panel. Classifies each virus against both arms' antigens and analyses per virus and at participant level, with censoring sensitivity, durability and egg-vs-wild-type comparisons | seqneut_*.csv, figures/seqneut_* |
| 04_binding_breadth.py | Bead-array breadth per strain, and binding vs neutralisation within each participant | binding_breadth_by_strain.csv, binding_vs_neut.csv |
| 05_mab.py | mAb panels analysed at donor level, with an exact permutation test and binder-threshold sensitivity | mab_donor_binding.csv, mab_arm_donor_level.csv |
| 06_cellular_repertoire.py | GC (both duplicated blocks), plasmablast, PB–GC overlap and serum repertoire | gc_summary.csv, pb_summary.csv, repertoire_summary.csv |
| 07_intercurrent_and_enrolment.py | Flags late titre rises (possible infection) and the arm-by-ID-block structure | late_rise_flags.csv, enrolment_blocks.csv |
| 08_design_calcs.py | Sample sizes and event counts for the recommended studies, using WU397 variances | design_calcs.csv |
| 09_interaction_models.py | Tests whether the arm effect is a uniform magnitude shift or a change in breadth, plus the H1 antigen-identity check | interaction_models.txt |
| 10_binding_vs_neut_by_strain.py | Binding ratio vs neutralisation ratio for the same strains | binding_vs_neut_by_strain.csv, figures/binding_vs_neut_by_strain.png |
| 11_figures.py | Presentation figures | figures/*.png, seqneut_category_forest.csv |
