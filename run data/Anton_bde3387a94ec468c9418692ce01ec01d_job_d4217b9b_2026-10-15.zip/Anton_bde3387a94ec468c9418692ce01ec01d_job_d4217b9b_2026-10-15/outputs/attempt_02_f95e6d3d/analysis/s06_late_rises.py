from common import *
from panel_classes import classify
# Signals of intercurrent infection: rises from wk4 (d29) to the late visit (wk17/26)
rows=[]
h=pd.read_csv(DATA+'hai_titers.csv',dtype={'participant':str}); h['pid']=h.participant.map(norm_pid)
hw=h.pivot_table(index=['antigen','arm','pid'],columns='timepoint',values='hai_titer').reset_index()
hw['late']=hw.wk26.fillna(hw.wk17); hw['late_tp']=np.where(hw.wk26.notna(),'wk26',np.where(hw.wk17.notna(),'wk17',None))
hw['r']=hw.late/hw.wk4
for _,x in hw[hw.r>=2].iterrows():
    rows.append(dict(assay='HAI',target=x.antigen,arm=x.arm,pid=x.pid,wk0=x.wk0,wk4=x.wk4,late=x.late,late_tp=x.late_tp,late_over_wk4=x.r))
m=pd.read_csv(DATA+'microneutralization.csv'); m['pid']=m.participant.map(norm_pid)
mw=m[m.measure=='titer'].pivot_table(index=['panel','arm','pid'],columns='timepoint',values='value').reset_index()
mw['late']=mw.wk26.fillna(mw.wk17); mw['late_tp']=np.where(mw.wk26.notna(),'wk26','wk17'); mw['r']=mw.late/mw.wk4
for _,x in mw[mw.r>=2].iterrows():
    rows.append(dict(assay='MN',target=x.panel,arm=x.arm,pid=x.pid,wk0=x.wk0,wk4=x.wk4,late=x.late,late_tp=x.late_tp,late_over_wk4=x.r))
e=pd.read_csv(DATA+'elisa_igg_titers.csv'); e['pid']=e.participant.map(norm_pid)
ew=e[e.measure=='ec50'].pivot_table(index=['antigen','arm','pid'],columns='timepoint',values='value').reset_index()
ew['late']=ew.wk26.fillna(ew.wk17); ew['late_tp']=np.where(ew.wk26.notna(),'wk26','wk17'); ew['r']=ew.late/ew.wk4
for _,x in ew[ew.r>=2].iterrows():
    rows.append(dict(assay='ELISA',target=x.antigen,arm=x.arm,pid=x.pid,wk0=x.wk0,wk4=x.wk4,late=x.late,late_tp=x.late_tp,late_over_wk4=x.r))
s=pd.read_csv(DATA+'neutralization_seqbased.csv'); s['arm']=s.serum.str.split('_').str[0]; s['pid']=s.serum.str.split('_').str[1].map(norm_pid); s['day']=s.serum.str.split('_').str[2]
s['cls']=s.virus.map(classify); s['l']=np.log2(s.titer)
s['late']=s.day.isin(['d121','d181'])
sw=s.assign(tp=np.where(s.late,'late',s.day)).pivot_table(index=['arm','pid','virus','cls'],columns='tp',values='l').reset_index()
sw['r']=sw['late']-sw['d29']
per=sw.groupby(['arm','pid']).agg(n=('r','count'),n_4fold_rise=('r',lambda v:(v>=2).sum()),mean_log2_late_minus_d29=('r','mean')).reset_index()
lt=s[s.late].groupby('pid').day.first()
per['late_day']=per.pid.map(lt)
print('Seq-neut: viruses with >=4-fold rise from d29 to late visit, per participant:')
print(per.sort_values('n_4fold_rise',ascending=False).round(2).to_string())
o=pd.DataFrame(rows).sort_values(['pid','assay'])
print(o.round(2).to_string())
o.to_csv('/tmp/outputs/tables/T06a_late_rises_ge2fold.csv',index=False); per.to_csv('/tmp/outputs/tables/T06b_seqneut_late_rises.csv',index=False)
# Durability: late/wk4 GMT ratio per arm per assay (caveat: mixed wk17/wk26)
rows=[]
for name,df,key in [('HAI',hw,'antigen'),('MN',mw,'panel'),('ELISA',ew,'antigen')]:
    for (k,arm),g in df.groupby([key,'arm']):
        g=g.dropna(subset=['late','wk4'])
        rows.append(dict(assay=name,target=k,arm=arm,n=len(g),n_wk17=int((g.late_tp=='wk17').sum()),GMT_wk4=gm(g.wk4),GMT_late=gm(g.late),late_over_wk4=gm(g.late/g.wk4),late_over_wk0=gm(g.late/g.wk0)))
d=pd.DataFrame(rows); print(d.round(2).to_string()); d.to_csv('/tmp/outputs/tables/T06c_durability.csv',index=False)
