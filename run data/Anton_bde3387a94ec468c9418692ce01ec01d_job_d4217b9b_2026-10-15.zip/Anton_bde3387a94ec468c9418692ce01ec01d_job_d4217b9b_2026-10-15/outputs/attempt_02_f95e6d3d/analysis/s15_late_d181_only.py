from common import *
from panel_classes import classify
import statsmodels.formula.api as smf
s=pd.read_csv(DATA+'neutralization_seqbased.csv'); s['arm']=s.serum.str.split('_').str[0]; s['pid']=s.serum.str.split('_').str[1].map(norm_pid); s['day']=s.serum.str.split('_').str[2]
s['cls']=s.virus.map(classify); s['l']=np.log2(s.titer)
ids181=set(s[s.day=='d181'].pid)
print('late visit composition: ', s[s.day.isin(['d121','d181'])].drop_duplicates('pid').groupby(['arm','day']).size().to_dict())
w=s[s.pid.isin(ids181)].pivot_table(index=['arm','pid','virus','cls'],columns='day',values='l').reset_index().dropna(subset=['d0','d181'])
pp=w.groupby(['cls','arm','pid']).agg(l0=('d0','mean'),l29=('d29','mean'),l181=('d181','mean')).reset_index()
rows=[]
for c,g in pp.groupby('cls'):
    g=g.assign(mrna=(g.arm=='mRNA-1010').astype(int)); f=smf.ols('l181~mrna+l0',data=g).fit()
    a=g[g.mrna==1]; b=g[g.mrna==0]
    rows.append(dict(cls=c,n_mRNA=len(a),n_Flu=len(b),adj_ratio_d181=2**f.params['mrna'],lo=2**f.conf_int().loc['mrna',0],hi=2**f.conf_int().loc['mrna',1],p=f.pvalues['mrna'],d181_over_d29_mRNA=2**(a.l181-a.l29).mean(),d181_over_d29_Flu=2**(b.l181-b.l29).mean()))
o=pd.DataFrame(rows); print(o.round(3).to_string()); o.to_csv('/tmp/outputs/tables/T15_seqneut_d181_only.csv',index=False)
