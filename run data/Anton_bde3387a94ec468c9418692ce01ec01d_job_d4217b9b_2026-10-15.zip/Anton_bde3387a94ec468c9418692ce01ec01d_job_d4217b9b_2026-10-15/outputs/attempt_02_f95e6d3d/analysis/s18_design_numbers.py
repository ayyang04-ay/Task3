from common import *
from scipy import stats
from math import ceil
rows=[]
# Phase 2 breadth superiority, 3 subtype-level co-primary/hierarchical tests; Bonferroni alpha 0.05/3 two-sided (conservative)
for sd in [1.0,1.5]:
    for gmr in [1.5]:
        for a in [0.05,0.05/3]:
            z=stats.norm.ppf(1-a/2)+stats.norm.ppf(0.9); n=ceil(2*(z*sd/np.log2(gmr))**2)
            rows.append(dict(design='Phase 2 breadth (ANCOVA GMT ratio superiority)',assumption=f'true GMR {gmr}, residual SD {sd} log2, two-sided alpha {a:.4f}, power 90%',n_evaluable_per_arm=n,n_enrolled_per_arm_15pct_attrition=ceil(n/0.85)))
# CHIM: binary endpoint (symptomatic lab-confirmed infection) comparator 40% vs mRNA 20%; two-sided 0.05, 80% power
def n2p(p1,p2,alpha=0.05,power=0.8):
    za=stats.norm.ppf(1-alpha/2); zb=stats.norm.ppf(power); pb=(p1+p2)/2
    return ceil((za*np.sqrt(2*pb*(1-pb))+zb*np.sqrt(p1*(1-p1)+p2*(1-p2)))**2/(p1-p2)**2)
for p1,p2 in [(0.4,0.2),(0.5,0.25)]:
    rows.append(dict(design='CHIM (symptomatic lab-confirmed infection), mRNA vs licensed comparator',assumption=f'{int(p1*100)}% vs {int(p2*100)}%, two-sided 0.05, 80% power',n_evaluable_per_arm=n2p(p1,p2)))
# Phase 3 events -> participants: attack rate of RT-PCR influenza in comparator arm & fraction mismatched
for ar in [0.015,0.025]:
    for fm in [0.3,0.5]:
        D=331  # mismatched events for rVE 30%
        # expected events ~ N/2*ar*fm*(1 + 0.7)  (comparator + mRNA arms)
        N=ceil(D/(ar*fm*(1+0.7)/2))
        rows.append(dict(design='Phase 3 rVE vs mismatched strains (rVE 30%, 90% power, 331 events)',assumption=f'comparator-arm attack rate {ar*100:.1f}%/season, {int(fm*100)}% of cases mismatched',total_participant_seasons=N))
o=pd.DataFrame(rows); print(o.to_string()); o.to_csv('/tmp/outputs/tables/T18_design_numbers.csv',index=False)
