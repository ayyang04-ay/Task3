from common import *
import statsmodels.formula.api as smf
from scipy import stats
e=pd.read_csv(DATA+'elisa_igg_titers.csv'); e['pid']=e.participant.map(norm_pid)
w=e[e.measure=='ec50'].pivot_table(index=['antigen','arm','pid'],columns='timepoint',values='value').reset_index()
w['late']=w.wk26.fillna(w.wk17)
rows=[]
for ag,g in w.groupby('antigen'):
    g=g.assign(l0=np.log2(g.wk0),l4=np.log2(g.wk4),lL=np.log2(g.late),mrna=(g.arm=='mRNA-1010').astype(int))
    a=g[g.mrna==1]; b=g[g.mrna==0]
    f4=smf.ols('l4~mrna+l0',data=g).fit(); fL=smf.ols('lL~mrna+l0',data=g).fit()
    rows.append(dict(antigen=ag,n_mRNA=len(a),n_Flu=len(b),GMT0_mRNA=2**a.l0.mean(),GMT0_Flu=2**b.l0.mean(),GMT4_mRNA=2**a.l4.mean(),GMT4_Flu=2**b.l4.mean(),
        GMFR4_mRNA=2**(a.l4-a.l0).mean(),GMFR4_Flu=2**(b.l4-b.l0).mean(),adj_ratio_wk4=2**f4.params['mrna'],lo4=2**f4.conf_int().loc['mrna',0],hi4=2**f4.conf_int().loc['mrna',1],p4=f4.pvalues['mrna'],
        pct_4fold_mRNA=100*((a.l4-a.l0)>=2).mean(),pct_4fold_Flu=100*((b.l4-b.l0)>=2).mean(),
        GMT_late_mRNA=2**a.lL.mean(),GMT_late_Flu=2**b.lL.mean(),adj_ratio_late=2**fL.params['mrna'],loL=2**fL.conf_int().loc['mrna',0],hiL=2**fL.conf_int().loc['mrna',1],pL=fL.pvalues['mrna'],
        strain_matched_between_products={'A/H1':'NO (A/Victoria/4897/2022 vs A/Victoria/2570/2019)','A/H3':'near (A/Darwin/6/2021 vs egg A/Darwin/9/2021)','B/Vic':'YES','B/Yam':'YES'}[ag]))
o=pd.DataFrame(rows); print(o.round(3).to_string()); o.to_csv('/tmp/outputs/tables/T11_elisa_ancova.csv',index=False)
# does fold-rise depend on baseline? (within-arm slope of log FC on log baseline)
for ag,g in w.groupby('antigen'):
    for arm in ['mRNA-1010','Fluarix']:
        x=g[g.arm==arm]; sl=stats.linregress(np.log2(x.wk0),np.log2(x.wk4/x.wk0))
        print(ag,arm,'slope log2FC~log2baseline = %.2f (p=%.3g)'%(sl.slope,sl.pvalue))
