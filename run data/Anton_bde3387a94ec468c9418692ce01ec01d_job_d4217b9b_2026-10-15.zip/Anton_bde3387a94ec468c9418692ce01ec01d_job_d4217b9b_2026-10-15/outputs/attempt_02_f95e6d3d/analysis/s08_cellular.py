from common import *
from scipy import stats
g=pd.read_csv(DATA+'gc_frequencies.csv',dtype={'participant':str}); g['pid']=g.participant.map(norm_pid)
g['block']=np.where(np.arange(len(g))<78,'A (rows 1-78)','B (rows 79-156)')
p=pd.read_csv(DATA+'plasmablast_frequencies.csv',dtype={'participant':str}); p['pid']=p.participant.map(norm_pid)
print('GC file: %d rows = 2 stacked blocks of 78 with identical (timepoint, arm, participant) keys and different values; no column distinguishes them'%len(g))
print('GC timepoints in file:',sorted(g.timepoint.unique()),' protocol FNA: wk1,wk2,wk4,wk8,wk17,wk26')
print('PB timepoints in file:',sorted(p.timepoint.unique()),' protocol blood: wk0(d0),wk1(d7),wk4(d29),wk17(d121),wk26(d181)')
ga=g[g.block.str.startswith('A')].set_index(['timepoint','arm','pid']).pct_ha_specific_igg_gc
gb=g[g.block.str.startswith('B')].set_index(['timepoint','arm','pid']).pct_ha_specific_igg_gc
cmp_=pd.concat([ga.rename('blockA'),gb.rename('blockB')],axis=1)
print('Spearman block A vs B: %.2f; identical values: %d/78'%(stats.spearmanr(cmp_.blockA,cmp_.blockB).correlation,(cmp_.blockA==cmp_.blockB).sum()))
rows=[]
for blk,df in [('GC block A',g[g.block.str.startswith('A')]),('GC block B',g[g.block.str.startswith('B')]),('PB',p.rename(columns={'pct_plasmablast':'pct_ha_specific_igg_gc'}))]:
    col='pct_ha_specific_igg_gc'
    for tp in ['wk0','wk2','wk8','wk17','wk26']:
        x=df[df.timepoint==tp]
        a=x[x.arm=='mRNA-1010'][col]; b=x[x.arm=='Fluarix'][col]
        if len(a)==0: continue
        rows.append(dict(measure=blk,timepoint_as_labelled=tp,n_mRNA=len(a),n_Flu=len(b),median_mRNA=a.median(),median_Flu=b.median(),max_mRNA=a.max(),max_Flu=b.max(),MW_p=stats.mannwhitneyu(a,b).pvalue))
    pk=df[df.timepoint!='wk0'].groupby(['arm','pid'])[col].max().reset_index()
    a=pk[pk.arm=='mRNA-1010'][col]; b=pk[pk.arm=='Fluarix'][col]
    rows.append(dict(measure=blk,timepoint_as_labelled='peak post-baseline',n_mRNA=len(a),n_Flu=len(b),median_mRNA=a.median(),median_Flu=b.median(),max_mRNA=a.max(),max_Flu=b.max(),MW_p=stats.mannwhitneyu(a,b).pvalue))
o=pd.DataFrame(rows); print(o.round(3).to_string()); o.to_csv('/tmp/outputs/tables/T08a_gc_pb.csv',index=False)
print(cmp_.unstack('timepoint').round(2).to_string())
late=p[p.timepoint.isin(['wk17','wk26'])]
print('PB >0.5% at wk17/26:'); print(late[late.pct_plasmablast>0.5].to_string())
