# Classification of sequencing-based neutralisation panel viruses relative to BOTH vaccines' actual antigens.
# mRNA-1010 (per trial_summary.md): H1 A/Victoria/4897/2022 ; H3 A/Darwin/6/2021 ; B/Austria/1359417/2021 ; B/Phuket/3073/2013
# Fluarix Quadrivalent 2022-23 NH (manufacturer labelling; egg-based WHO 2022-23 recommendation):
#   H1 A/Victoria/2570/2019 (IVR-215) ; H3 A/Darwin/9/2021 (egg reassortant) ; B/Austria/1359417/2021 ; B/Phuket/3073/2013
# WHO cell-based equivalents: A/Wisconsin/588/2019 ~ A/Victoria/2570/2019 (2021-22/2022-23); A/Wisconsin/67/2022 ~ A/Victoria/4897/2022 (2023-24)
import re
def year(v):
    m=re.search(r'/(\d{4,6})(?:[A-Za-z_\-]|$)',v.split('_')[0]+'_')
    y=re.findall(r'/(\d{4,6})',v)
    yy=y[-1] if y else None
    if yy and len(yy)>4: yy=yy[-4:]   # 'A/SOUTHAFRICA/R07876/202023' -> typo, take 2023
    return int(yy) if yy else None
REASSORTANT_TAGS=['egg','X-223A','X-307A','NIB-88','IVR-238']
def is_reassortant(v):
    return any(t in v for t in REASSORTANT_TAGS)
def classify(v):
    sub=v.split('_')[-1]
    if v=='A/Darwin/6/2021_H3N2': return 'H3: mRNA-1010 vaccine strain (A/Darwin/6/2021)'
    if v=='A/Darwin/9/2021_H3N2': return 'H3: Fluarix vaccine strain, wild-type (A/Darwin/9/2021)'
    if v=='A/Victoria/4897/2022_IVR-238_H1N1': return 'H1: mRNA-1010 vaccine strain as egg reassortant (IVR-238)'
    if v=='A/Wisconsin/67/2022_H1N1': return 'H1: cell-based equivalent of mRNA-1010 H1 (A/Wisconsin/67/2022)'
    if v=='A/Wisconsin/588/2019_H1N1': return 'H1: cell-based equivalent of Fluarix H1 (A/Wisconsin/588/2019)'
    y=year(v)
    if sub=='H3N2':
        if y>=2022: return 'H3: forward-drifted 2022-2024 isolates'
        return 'H3: historical egg/reassortant' if is_reassortant(v) else 'H3: historical wild-type 2012-2020'
    if sub=='H1N1':
        if y>=2023: return 'H1: forward-drifted 2023 isolates'
        return 'H1: historical 2009-2019'
    return 'other'
