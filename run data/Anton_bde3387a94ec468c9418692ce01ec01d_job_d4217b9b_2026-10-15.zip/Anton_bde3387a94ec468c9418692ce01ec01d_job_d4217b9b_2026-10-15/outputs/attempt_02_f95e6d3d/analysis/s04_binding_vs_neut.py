from common import *
from scipy import stats
import statsmodels.formula.api as smf
b=pd.concat([pd.read_csv(DATA+'binding_breadth_h1.csv').assign(sub='H1'),pd.read_csv(DATA+'binding_breadth_h3.csv').assign(sub='H3')])
b['pid']=b.participant.map(norm_pid)
# Bead-array per-strain arm comparison
rows=[]
for (sub,st),g in b.groupby(['sub','strain']):
    a=g[g.arm=='mRNA-1010'].log2_fold_change_mfi; f=g[g.arm=='Fluarix'].log2_fold_change_mfi
    t=stats.ttest_ind(a,f,equal_var=False); mw=stats.mannwhitneyu(a,f)
    rows.append(dict(sub=sub,strain=st,mean_log2FC_mRNA=a.mean(),mean_log2FC_Flu=f.mean(),fold_mRNA=2**a.mean(),fold_Flu=2**f.mean(),ratio=2**(a.mean()-f.mean()),p_welch=t.pvalue,p_MW=mw.pvalue,
                     pct_ge2fold_mRNA=100*(a>=1).mean(),pct_ge2fold_Flu=100*(f>=1).mean(),pct_ge4fold_mRNA=100*(a>=2).mean(),pct_ge4fold_Flu=100*(f>=2).mean()))
o=pd.DataFrame(rows).sort_values(['sub','ratio'])
print(o.round(3).to_string()); o.to_csv('/tmp/outputs/tables/T04a_beadarray_by_strain.csv',index=False)

# Matched strains between bead-array and seq-neut
s=pd.read_csv(DATA+'neutralization_seqbased.csv'); s['arm']=s.serum.str.split('_').str[0]; s['pid']=s.serum.str.split('_').str[1].map(norm_pid); s['day']=s.serum.str.split('_').str[2]
s['l']=np.log2(s.titer)
sw=s.pivot_table(index=['arm','pid','virus'],columns='day',values='l').reset_index(); sw['nfc']=sw.d29-sw.d0
match={'A/Darwin/6/2021':'A/Darwin/6/2021_H3N2','A/Thailand/8/2022':'A/Thailand/8/2022_H3N2','A/Cambodia/e0826360/2020':'A/Cambodia/e0826360/2020_H3N2',
       'A/Singapore/INFIMH-16-0019/2016':'A/Singapore/INFIMH-16-0019/2016_H3N2','A/Hong Kong/2671/2019':'A/HongKong/2671/2019_H3N2','A/Texas/50/2012':'A/Texas/50/2012_H3N2',
       'A/Wisconsin/588/2019':'A/Wisconsin/588/2019_H1N1','A/Wisconsin/67/2022':'A/Wisconsin/67/2022_H1N1','A/Hawaii/70/2019':'A/Hawaii/70/2019_H1N1',
       'A/Michigan/45/2015':'A/Michigan/45/2015_H1N1','A/Brisbane/2/2018':'A/Brisbane/02/2018_H1N1'}
rows=[]; allpairs=[]
for bs,sv in match.items():
    gb=b[b.strain==bs][['pid','arm','log2_fold_change_mfi']]
    gs=sw[sw.virus==sv][['pid','arm','nfc']]
    mm_=gb.merge(gs,on=['pid','arm'])
    allpairs.append(mm_.assign(strain=bs))
    r={}
    for arm in ['mRNA-1010','Fluarix']:
        x=mm_[mm_.arm==arm]
        r[arm]=(x.log2_fold_change_mfi.mean(),x.nfc.mean(),len(x))
    mm_=mm_.dropna(subset=["nfc"]); rho=stats.spearmanr(mm_.log2_fold_change_mfi,mm_.nfc)
    rows.append(dict(strain=bs,n_mRNA=r['mRNA-1010'][2],n_Flu=r['Fluarix'][2],
        binding_fold_mRNA=2**r['mRNA-1010'][0],binding_fold_Flu=2**r['Fluarix'][0],binding_ratio_mRNA_over_Flu=2**(r['mRNA-1010'][0]-r['Fluarix'][0]),
        neut_GMFR_mRNA=2**r['mRNA-1010'][1],neut_GMFR_Flu=2**r['Fluarix'][1],neut_GMFR_ratio_mRNA_over_Flu=2**(r['mRNA-1010'][1]-r['Fluarix'][1]),
        spearman_binding_vs_neut=rho.correlation,spearman_p=rho.pvalue))
o2=pd.DataFrame(rows)
print(o2.round(3).to_string()); o2.to_csv('/tmp/outputs/tables/T04b_binding_vs_neutralisation_matched_strains.csv',index=False)
ap=pd.concat(allpairs)
# ratio of binding fold to neut fold by arm (H3 strains)
ap['sub']=ap.strain.map(lambda x: 'H3' if x in ['A/Darwin/6/2021','A/Thailand/8/2022','A/Cambodia/e0826360/2020','A/Singapore/INFIMH-16-0019/2016','A/Hong Kong/2671/2019','A/Texas/50/2012'] else 'H1')
ap['excess']=ap.log2_fold_change_mfi-ap.nfc
pe=ap.groupby(['sub','arm','pid']).excess.mean().reset_index()
for sub,g in pe.groupby('sub'):
    a=g[g.arm=='mRNA-1010'].excess; f=g[g.arm=='Fluarix'].excess
    print(sub,'binding-minus-neut log2FC, participant mean: mRNA %.2f vs Flu %.2f (diff %.2f log2 = %.1f-fold), Welch p=%.4f, MW p=%.4f'%(a.mean(),f.mean(),a.mean()-f.mean(),2**(a.mean()-f.mean()),stats.ttest_ind(a,f,equal_var=False).pvalue,stats.mannwhitneyu(a,f).pvalue))
