from common import *
import statsmodels.formula.api as smf
m=pd.read_csv(DATA+'microneutralization.csv'); m['pid']=m.participant.map(norm_pid)
mw=m[m.measure=='titer'].pivot_table(index=['panel','arm','pid'],columns='timepoint',values='value').reset_index()
rows=[]
for label,excl in [('all',[]),('excl 014 (implausible MN vs HAI)',['014']),('excl 019',['019']),('excl 014 & 019 (= seq-neut cohort)',['014','019'])]:
    for pan,g in mw.groupby('panel'):
        g=g[~g.pid.isin(excl)]
        a=g[g.arm=='mRNA-1010']; b=g[g.arm=='Fluarix']
        r,lo,hi,p=gmr_ci(a.wk4/a.wk0,b.wk4/b.wk0)
        f=smf.ols('l4~mrna+l0',data=g.assign(l4=np.log2(g.wk4),l0=np.log2(g.wk0),mrna=(g.arm=='mRNA-1010').astype(int))).fit()
        rows.append(dict(set=label,panel=pan,n_mRNA=len(a),n_Flu=len(b),GMFR_mRNA=gm(a.wk4/a.wk0),GMFR_Flu=gm(b.wk4/b.wk0),GMFR_ratio=r,lo=lo,hi=hi,p=p,
                         ANCOVA_ratio=2**f.params['mrna'],a_lo=2**f.conf_int().loc['mrna',0],a_hi=2**f.conf_int().loc['mrna',1],a_p=f.pvalues['mrna']))
o=pd.DataFrame(rows); print(o.round(3).to_string()); o.to_csv('/tmp/outputs/tables/T17_MN_sensitivity_exclusions.csv',index=False)
