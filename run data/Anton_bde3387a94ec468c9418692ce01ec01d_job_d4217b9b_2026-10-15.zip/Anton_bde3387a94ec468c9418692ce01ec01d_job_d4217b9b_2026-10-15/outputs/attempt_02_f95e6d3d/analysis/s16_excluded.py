from common import *
h=pd.read_csv(DATA+'hai_titers.csv',dtype={'participant':str}); h['pid']=h.participant.map(norm_pid)
m=pd.read_csv(DATA+'microneutralization.csv'); m['pid']=m.participant.map(norm_pid)
e=pd.read_csv(DATA+'elisa_igg_titers.csv'); e['pid']=e.participant.map(norm_pid)
b=pd.concat([pd.read_csv(DATA+'binding_breadth_h1.csv').assign(sub='H1'),pd.read_csv(DATA+'binding_breadth_h3.csv').assign(sub='H3')]); b['pid']=b.participant.map(norm_pid)
for pid in ['014','019','021']:
    print('=== 397-'+pid)
    print(' HAI:', h[h.pid==pid].pivot_table(index='antigen',columns='timepoint',values='hai_titer').to_dict('index'))
    print(' MN :', m[(m.pid==pid)&(m.measure=='titer')].pivot_table(index='panel',columns='timepoint',values='value').to_dict('index'))
    print(' ELISA wk4 FC:', e[(e.pid==pid)&(e.measure=='fold_change')&(e.timepoint=='wk4')].set_index('antigen').value.round(2).to_dict())
    print(' bead mean log2FC:', b[b.pid==pid].groupby('sub').log2_fold_change_mfi.mean().round(2).to_dict())
# Rank of each participant's responses within arm (MN het wk4 FC, HAI H1 FC, ELISA H1 FC)
mw=m[(m.measure=='fold_change')&(m.timepoint=='wk4')].pivot_table(index=['arm','pid'],columns='panel',values='value')
print(mw.sort_values(['arm','heterologous']).to_string())
# HAI vs MN plausibility: wk4 HAI (max over A strains) vs MN homologous titre
hw=h[h.timepoint=='wk4'].pivot_table(index='pid',columns='antigen',values='hai_titer')
mt=m[(m.measure=='titer')&(m.timepoint=='wk4')].pivot_table(index='pid',columns='panel',values='value')
j=hw.join(mt); j['maxA_HAI']=j[['A/H1N1','A/H3N2']].max(axis=1); j['ratio_MNhom_over_HAI']=j.homologous/j.maxA_HAI
print(j.sort_values('ratio_MNhom_over_HAI').head(6).round(2).to_string())
