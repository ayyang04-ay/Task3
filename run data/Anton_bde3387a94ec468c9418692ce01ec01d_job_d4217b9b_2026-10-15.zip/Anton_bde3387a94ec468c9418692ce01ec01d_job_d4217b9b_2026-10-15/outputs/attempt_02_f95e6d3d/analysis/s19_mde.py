from common import *
import statsmodels.formula.api as smf
from scipy import stats
pp=pd.read_csv('/tmp/outputs/tables/T03c_seqneut_participant_class_means.csv')
rows=[]
for c in ['H3: forward-drifted 2022-2024 isolates','H1: forward-drifted 2023 isolates']:
    g=pp[pp.cls==c].assign(mrna=lambda d:(d.arm=='mRNA-1010').astype(int))
    f=smf.ols('l29~mrna+l0',data=g).fit(); se=f.bse['mrna']
    mde=(stats.norm.ppf(0.975)+stats.norm.ppf(0.8))*se
    rows.append(dict(endpoint=f'seq-neut d29 ANCOVA, {c}',n=len(g),SE_log2=se,MDE_fold_80pct_power=2**mde))
h=pd.read_csv(DATA+'hai_titers.csv',dtype={'participant':str})
w=h.pivot_table(index=['antigen','arm','participant'],columns='timepoint',values='hai_titer').reset_index()
for ag,g in w.groupby('antigen'):
    g=g.dropna(subset=['wk0','wk4']).assign(l4=lambda d:np.log2(d.wk4),l0=lambda d:np.log2(d.wk0),mrna=lambda d:(d.arm=='mRNA-1010').astype(int))
    f=smf.ols('l4~mrna+l0',data=g).fit(); se=f.bse['mrna']; mde=(stats.norm.ppf(0.975)+stats.norm.ppf(0.8))*se
    rows.append(dict(endpoint=f'HAI wk4 ANCOVA {ag}',n=len(g),SE_log2=se,MDE_fold_80pct_power=2**mde))
# SCR difference detectable with n=14/15 at p~0.3
p=0.3; se=np.sqrt(2*p*(1-p)/14.5); rows.append(dict(endpoint='HAI SCR difference (p~30%)',n=29,SE_log2=np.nan,MDE_fold_80pct_power=np.nan,MDE_pct_points=100*(stats.norm.ppf(0.975)+stats.norm.ppf(0.8))*se))
o=pd.DataFrame(rows); print(o.round(2).to_string()); o.to_csv('/tmp/outputs/tables/T19_wu397_detectable_effects.csv',index=False)
