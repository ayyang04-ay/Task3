import pandas as pd, numpy as np
DATA='/tmp/world/filesystem/'
pd.set_option('display.width',300); pd.set_option('display.max_rows',3000); pd.set_option('display.max_columns',80)

def norm_pid(x):
    """Normalise participant IDs: '397-006', '006', '6', '397-06', 20 -> '006'."""
    x=str(x).strip()
    if x.startswith('397-'): x=x[4:]
    return x.zfill(3)

def gm(x):
    x=np.asarray(x,dtype=float); x=x[~np.isnan(x)]
    return float(2**np.mean(np.log2(x))) if len(x) else np.nan

def gm_ci(x, alpha=0.05):
    from scipy import stats
    x=np.asarray(x,dtype=float); x=x[~np.isnan(x)]
    l=np.log2(x); n=len(l); m=l.mean(); se=l.std(ddof=1)/np.sqrt(n)
    t=stats.t.ppf(1-alpha/2,n-1)
    return 2**m, 2**(m-t*se), 2**(m+t*se), n

def gmr_ci(a,b,alpha=0.05):
    """Geometric mean ratio a/b with Welch t CI on log scale."""
    from scipy import stats
    a=np.log2(np.asarray(a,float)); b=np.log2(np.asarray(b,float))
    a=a[~np.isnan(a)]; b=b[~np.isnan(b)]
    d=a.mean()-b.mean(); va=a.var(ddof=1)/len(a); vb=b.var(ddof=1)/len(b)
    se=np.sqrt(va+vb); df=(va+vb)**2/(va**2/(len(a)-1)+vb**2/(len(b)-1))
    t=stats.t.ppf(1-alpha/2,df); p=2*(1-stats.t.cdf(abs(d/se),df))
    return 2**d, 2**(d-t*se), 2**(d+t*se), p

def newcombe_diff(x1,n1,x2,n2,z=1.959964):
    """Newcombe hybrid score CI for p1-p2 (Wilson intervals)."""
    def wilson(x,n):
        p=x/n; den=1+z*z/n; c=(p+z*z/(2*n))/den; h=z*np.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
        return c-h,c+h
    p1=x1/n1; p2=x2/n2; l1,u1=wilson(x1,n1); l2,u2=wilson(x2,n2)
    d=p1-p2
    lo=d-np.sqrt((p1-l1)**2+(u2-p2)**2); hi=d+np.sqrt((u1-p1)**2+(p2-l2)**2)
    return d,lo,hi

def wilson(x,n,z=1.959964):
    p=x/n; den=1+z*z/n; c=(p+z*z/(2*n))/den; h=z*np.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
    return p,c-h,c+h
