from common import *
from scipy import stats
rows=[]
r=pd.read_csv(DATA+'repertoire_clonotype_counts.csv')
for met,g in r.groupby('metric'):
    a=g[g.arm=='mRNA-1010'].value; b=g[g.arm=='Fluarix'].value
    rows.append(dict(source='repertoire_clonotype_counts.csv',measure=met,n_mRNA=len(a),n_Flu=len(b),median_mRNA=a.median(),median_Flu=b.median(),mean_mRNA=a.mean(),mean_Flu=b.mean(),MW_p=stats.mannwhitneyu(a,b).pvalue))
c=pd.read_csv(DATA+'serum_igg_clonotypes.csv')
for tp,g in c.groupby('timepoint'):
    a=g[g.arm=='mRNA-1010'].n_clonotypes; b=g[g.arm=='Fluarix'].n_clonotypes
    rows.append(dict(source='serum_igg_clonotypes.csv',measure='n_clonotypes '+tp,n_mRNA=len(a),n_Flu=len(b),median_mRNA=a.median(),median_Flu=b.median(),mean_mRNA=a.mean(),mean_Flu=b.mean(),MW_p=stats.mannwhitneyu(a,b).pvalue if len(a)>1 and len(b)>1 else np.nan))
h3=pd.read_csv(DATA+'cdrh3_diversity_index.csv')
for tp,g in h3.groupby('timepoint'):
    a=g[g.arm=='mRNA-1010'].diversity_index; b=g[g.arm=='Fluarix'].diversity_index
    rows.append(dict(source='cdrh3_diversity_index.csv',measure='diversity '+tp,n_mRNA=len(a),n_Flu=len(b),median_mRNA=a.median(),median_Flu=b.median(),mean_mRNA=a.mean(),mean_Flu=b.mean(),MW_p=stats.mannwhitneyu(a,b).pvalue if len(a)>1 and len(b)>1 else np.nan))
# IgM
i=pd.read_csv(DATA+'igm_fold_change.csv',dtype={'participant':str})
for ag,g in i.groupby('antigen'):
    a=g[g.arm=='mRNA-1010'].fold_change; b=g[g.arm=='Fluarix'].fold_change
    rows.append(dict(source='igm_fold_change.csv',measure='IgM FC '+ag+' (n>1 = any rise)',n_mRNA=len(a),n_Flu=len(b),median_mRNA=a.median(),median_Flu=b.median(),mean_mRNA=(a>1).sum(),mean_Flu=(b>1).sum(),MW_p=stats.mannwhitneyu(a,b).pvalue))
o=pd.DataFrame(rows); print(o.round(3).to_string()); o.to_csv('/tmp/outputs/tables/T10_repertoire_igm.csv',index=False)
# check: n_pre_existing_clonotypes == serum wk0 n_clonotypes (same participants, same order?)
pre=r[r.metric=='n_pre_existing_clonotypes'].groupby('arm').value.apply(list)
wk0=c[c.timepoint=='wk0'].groupby('arm').n_clonotypes.apply(list)
print('pre-existing clonotypes == wk0 serum clonotypes (same order):',{k:pre[k]==wk0[k] for k in pre.index})
