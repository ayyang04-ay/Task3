from common import *
out=[]
def add(assay,file,df,pidcol,armcol='arm',note=''):
    ids=df[[pidcol,armcol]].drop_duplicates()
    ids['pid']=ids[pidcol].map(norm_pid)
    c=ids.drop_duplicates('pid').groupby(armcol).pid.nunique()
    out.append(dict(assay=assay,file=file,mRNA_1010=int(c.get('mRNA-1010',0)),Fluarix=int(c.get('Fluarix',0)),note=note))
    return ids
e=pd.read_csv(DATA+'elisa_igg_titers.csv'); add('ELISA IgG','elisa_igg_titers.csv',e,'participant',note='IDs are bare integers, not 397-0NN')
i=pd.read_csv(DATA+'igm_fold_change.csv',dtype={'participant':str}); add('IgM fold-change','igm_fold_change.csv',i,'participant',note='summary says IgM cohort = ELISA cohort (38/37); file holds only the HAI cohort; one ID written "20"')
h=pd.read_csv(DATA+'hai_titers.csv',dtype={'participant':str}); add('HAI','hai_titers.csv',h,'participant')
b1=pd.read_csv(DATA+'binding_breadth_h1.csv'); add('Bead array H1','binding_breadth_h1.csv',b1,'participant',note='fold-change only; timepoint not stated')
b3=pd.read_csv(DATA+'binding_breadth_h3.csv'); add('Bead array H3','binding_breadth_h3.csv',b3,'participant',note='fold-change only; timepoint not stated')
m=pd.read_csv(DATA+'microneutralization.csv'); add('Microneutralisation','microneutralization.csv',m,'participant',note='virus identities of "homologous"/"heterologous" not given; titres capped at 1280')
s=pd.read_csv(DATA+'neutralization_seqbased.csv'); s['arm']=s.serum.str.split('_').str[0]; s['participant']=s.serum.str.split('_').str[1]
add('Sequencing-based neutralisation','neutralization_seqbased.csv',s,'participant',note='397-014 (mRNA) and 397-019 (Fluarix) absent vs HAI/MN cohort')
g=pd.read_csv(DATA+'gc_frequencies.csv',dtype={'participant':str}); add('LN GC B cells (FNA)','gc_frequencies.csv',g,'participant',note='timepoints wk0,2,8,17,26 vs protocol FNA wk1,2,4,8,17,26')
p=pd.read_csv(DATA+'plasmablast_frequencies.csv',dtype={'participant':str}); add('Plasmablasts','plasmablast_frequencies.csv',p,'participant',note='cohort not in summary table; timepoints wk2/wk8 are not blood-draw visits; no wk1')
mab=pd.read_csv(DATA+'mab_binding_panels.csv'); mab['participant']=mab.mab_id.str.split('.').str[1]; add('mAb binding (donors)','mab_binding_panels.csv',mab,'participant',note='donor = participant; 589 mAbs (mRNA) vs 106 (Fluarix)')
ov=pd.read_csv(DATA+'pb_gc_clonal_overlap.csv'); ov['arm']=ov.Participant.map(lambda x: 'mRNA-1010' if x.split('-')[1] in ('06','17','28','29') else 'Fluarix'); add('PB-GC clonal overlap','pb_gc_clonal_overlap.csv',ov,'Participant',note='arm not in file; inferred from mAb donor IDs')
for f in ['cdrh3_diversity_index.csv','serum_igg_clonotypes.csv','repertoire_clonotype_counts.csv']:
    x=pd.read_csv(DATA+f)
    c=x[x.columns[1]].value_counts() if 'arm' in x.columns else None
    if f=='repertoire_clonotype_counts.csv':
        c=x[x.metric=='n_pre_existing_clonotypes'].arm.value_counts()
    else:
        c=x[x.timepoint=='wk0'].arm.value_counts()
    out.append(dict(assay=f.replace('.csv',''),file=f,mRNA_1010=int(c.get('mRNA-1010',0)),Fluarix=int(c.get('Fluarix',0)),note='NO participant IDs - unpaired, cannot be linked to any other assay'))
o=pd.DataFrame(out)
summary={'ELISA IgG':(38,37),'IgM fold-change':(38,37),'HAI':(14,15),'Bead array H1':(14,15),'Bead array H3':(14,15),'Microneutralisation':(14,15),'Sequencing-based neutralisation':(13,14),'LN GC B cells (FNA)':(6,11)}
o['summary_mRNA']=o.assay.map(lambda a: summary.get(a,(None,None))[0]); o['summary_Fluarix']=o.assay.map(lambda a: summary.get(a,(None,None))[1])
print(o.to_string())
o.to_csv('/tmp/outputs/tables/T00_cohort_inventory.csv',index=False)

# overlap of IDs across assays
sets={}
for name,df,col in [('ELISA',e,'participant'),('HAI',h,'participant'),('MN',m,'participant'),('BEAD',b1,'participant'),('SEQNEUT',s,'participant'),('GC',g,'participant'),('PB',p,'participant'),('IgM',i,'participant')]:
    sets[name]=set(df[col].map(norm_pid))
print({k:len(v) for k,v in sets.items()})
print('HAI==MN==BEAD==IgM:', sets['HAI']==sets['MN']==sets['BEAD']==sets['IgM'])
print('HAI - SEQNEUT:', sorted(sets['HAI']-sets['SEQNEUT']))
print('GC subset of HAI:', sets['GC']<=sets['HAI'], ' PB - HAI:', sorted(sets['PB']-sets['HAI']))
print('PB subset of ELISA:', sets['PB']<=sets['ELISA'])
print('HAI subset of ELISA:', sets['HAI']<=sets['ELISA'])
# mAb donors
print('mAb donors:', sorted(mab.participant.unique()))
