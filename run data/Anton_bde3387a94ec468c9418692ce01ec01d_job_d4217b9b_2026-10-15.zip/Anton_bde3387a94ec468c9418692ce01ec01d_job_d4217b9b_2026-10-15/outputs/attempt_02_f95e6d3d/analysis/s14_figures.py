from common import *
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
FIG='/tmp/outputs/figures/'
# Fig1: class-level ANCOVA ratios d29 & late
c29=pd.read_csv('/tmp/outputs/tables/T03b_seqneut_by_class_participant_level.csv')
cl=pd.read_csv('/tmp/outputs/tables/T07_seqneut_late_visit.csv')
order=['H1: mRNA-1010 vaccine strain as egg reassortant (IVR-238)','H1: cell-based equivalent of mRNA-1010 H1 (A/Wisconsin/67/2022)','H1: cell-based equivalent of Fluarix H1 (A/Wisconsin/588/2019)','H1: forward-drifted 2023 isolates','H1: historical 2009-2019',
       'H3: mRNA-1010 vaccine strain (A/Darwin/6/2021)','H3: Fluarix vaccine strain, wild-type (A/Darwin/9/2021)','H3: forward-drifted 2022-2024 isolates','H3: historical wild-type 2012-2020','H3: historical egg/reassortant']
c29=c29.set_index('cls').loc[order]; cl=cl.set_index('cls').loc[order]
fig,ax=plt.subplots(figsize=(10,6.5))
y=np.arange(len(order))[::-1]
ax.errorbar(c29.ANCOVA_adj_ratio,y+0.15,xerr=[c29.ANCOVA_adj_ratio-c29.adj_lo,c29.adj_hi-c29.ANCOVA_adj_ratio],fmt='o',color='C0',label='Day 29 (baseline-adjusted)')
ax.errorbar(cl.adj_ratio_late,y-0.15,xerr=[cl.adj_ratio_late-cl.lo,cl.hi-cl.adj_ratio_late],fmt='s',color='C1',label='Day 121/181 (baseline-adjusted)')
ax.axvline(1,color='k',lw=0.8); ax.set_xscale('log',base=2)
ax.set_yticks(y); ax.set_yticklabels([f"{o}  (n={int(c29.loc[o,'n_viruses'])})" for o in order],fontsize=8)
ax.set_xlabel('mRNA-1010 / Fluarix neutralising GMT ratio (ANCOVA on log2 baseline), 95% CI')
ax.set_title('Seq-based neutralisation (13 vs 14): mRNA-1010/Fluarix by antigenic class',fontsize=10)
ax.legend(loc='upper center',bbox_to_anchor=(0.5,-0.09),ncol=2,fontsize=8); plt.tight_layout(); plt.savefig(FIG+'F1_seqneut_class_ratios.png',dpi=150); plt.close()
# Fig2: binding vs neutralisation
bn=pd.read_csv('/tmp/outputs/tables/T04b_binding_vs_neutralisation_matched_strains.csv')
fig,ax=plt.subplots(figsize=(9,5))
x=np.arange(len(bn)); ax.bar(x-0.2,bn.binding_ratio_mRNA_over_Flu,0.4,label='Binding (bead-array fold-rise ratio)')
ax.bar(x+0.2,bn.neut_GMFR_ratio_mRNA_over_Flu,0.4,label='Neutralisation (GMFR ratio, d29/d0)')
ax.axhline(1,color='k',lw=0.8); ax.set_yscale('log',base=2); ax.set_xticks(x); ax.set_xticklabels(bn.strain,rotation=45,ha='right',fontsize=8)
ax.set_ylabel('mRNA-1010 / Fluarix'); ax.set_title('Same participants, same strains: binding vs neutralisation advantage'); ax.legend(fontsize=8)
plt.tight_layout(); plt.savefig(FIG+'F2_binding_vs_neutralisation.png',dpi=150); plt.close()
# Fig3: per-virus adjusted ratio d29 vs year
pv=pd.read_csv('/tmp/outputs/tables/T13_seqneut_per_virus_ancova.csv')
fig,ax=plt.subplots(figsize=(9,5))
cols={'H1':'C3','H3':'C0'}
for c,g in pv.groupby('cls'):
    col='C3' if c.startswith('H1') else ('C2' if 'forward' in c else ('C7' if 'historical' in c else 'C1'))
    mk='o' if 'forward' in c else ('^' if 'historical' in c else '*')
    ax.scatter(g.year+np.random.uniform(-0.25,0.25,len(g)),g.adj_ratio_d29,c=col,marker=mk,s=40 if mk!='*' else 120,label=c,alpha=0.8)
ax.axhline(1,color='k',lw=0.8); ax.set_yscale('log',base=2); ax.set_xlabel('Isolation year'); ax.set_ylabel('Adjusted GMT ratio mRNA-1010/Fluarix, day 29')
ax.set_title('Per-virus baseline-adjusted ratio (96 viruses)'); ax.legend(fontsize=7,loc='center left',bbox_to_anchor=(1.01,0.5)); plt.tight_layout(); plt.savefig(FIG+'F3_per_virus_ratio_by_year.png',dpi=150); plt.close()
# Fig4: baseline imbalance
s=pd.read_csv(DATA+'neutralization_seqbased.csv'); s['arm']=s.serum.str.split('_').str[0]; s['day']=s.serum.str.split('_').str[2]
d0=s[s.day=='d0'].assign(l=lambda d:np.log2(d.titer)).groupby(['virus','arm']).l.mean().unstack(); r=2**(d0['mRNA-1010']-d0['Fluarix'])
fig,ax=plt.subplots(1,2,figsize=(10,4))
ax[0].hist(r,bins=20,color='C0'); ax[0].axvline(1,color='k'); ax[0].set_xlabel('Day-0 GMT ratio mRNA-1010/Fluarix'); ax[0].set_ylabel('# viruses'); ax[0].set_title('Baseline neutralisation: 94/96 viruses lower in mRNA arm',fontsize=9)
e=pd.read_csv(DATA+'elisa_igg_titers.csv'); w=e[e.measure=='ec50'].pivot_table(index=['antigen','arm','participant'],columns='timepoint',values='value').reset_index()
for arm,col in [('mRNA-1010','C1'),('Fluarix','C0')]:
    g=w[(w.antigen=='A/H3')&(w.arm==arm)]; ax[1].scatter(np.log2(g.wk0),np.log2(g.wk4/g.wk0),c=col,label=arm,s=15)
ax[1].set_xlabel('log2 baseline ELISA EC50 (H3)'); ax[1].set_ylabel('log2 fold-rise wk4'); ax[1].set_title('Fold-rise falls with baseline (ELISA H3)',fontsize=9); ax[1].legend(fontsize=8)
plt.tight_layout(); plt.savefig(FIG+'F4_baseline_imbalance.png',dpi=150); plt.close()
# Fig5: GC block A vs B
g=pd.read_csv(DATA+'gc_frequencies.csv',dtype={'participant':str}); g['block']=np.where(np.arange(len(g))<78,'A','B')
tpo={'wk0':0,'wk2':2,'wk8':8,'wk17':17,'wk26':26}
fig,ax=plt.subplots(1,2,figsize=(10,4),sharey=True)
for i,b in enumerate(['A','B']):
    for (arm,pid),x in g[g.block==b].groupby(['arm','participant']):
        x=x.assign(t=x.timepoint.map(tpo)).sort_values('t'); ax[i].plot(x.t,x.pct_ha_specific_igg_gc,'-o',ms=3,color='C1' if arm=='mRNA-1010' else 'C0',alpha=0.7)
    ax[i].set_title(f'gc_frequencies.csv block {b} (rows {"1-78" if b=="A" else "79-156"})',fontsize=9); ax[i].set_xlabel('timepoint label (weeks)')
ax[0].set_ylabel('% HA-specific IgG+ of GC B cells'); ax[0].plot([],[],color='C1',label='mRNA-1010'); ax[0].plot([],[],color='C0',label='Fluarix'); ax[0].legend(fontsize=8)
plt.tight_layout(); plt.savefig(FIG+'F5_gc_two_blocks.png',dpi=150); plt.close()
print('figures written')
