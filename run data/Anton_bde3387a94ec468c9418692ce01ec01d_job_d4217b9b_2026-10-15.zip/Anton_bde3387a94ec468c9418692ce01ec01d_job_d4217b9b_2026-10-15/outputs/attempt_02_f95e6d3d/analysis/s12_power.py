from common import *
import statsmodels.formula.api as smf
from scipy import stats
from math import log, ceil
pp=pd.read_csv('/tmp/outputs/tables/T03c_seqneut_participant_class_means.csv')
out=[]
print('Residual SD (log2) of participant-level mean d29 titre after ANCOVA on baseline:')
res_sd={}
for c in ['H3: forward-drifted 2022-2024 isolates','H1: forward-drifted 2023 isolates']:
    g=pp[pp.cls==c].assign(mrna=lambda d:(d.arm=='mRNA-1010').astype(int))
    f=smf.ols('l29~mrna+l0',data=g).fit(); sd=np.sqrt(f.mse_resid); res_sd[c]=sd
    print(f'  {c}: residual SD = {sd:.2f} log2; raw SD d29 = {g.l29.std():.2f}; r(d0,d29) = {np.corrcoef(g.l0,g.l29)[0,1]:.2f}')
def n_superiority(sd,gmr,alpha=0.05,power=0.9):
    z=stats.norm.ppf(1-alpha/2)+stats.norm.ppf(power); d=np.log2(gmr)
    return ceil(2*(z*sd/d)**2)
for c,sd in res_sd.items():
    for gmr in [1.3,1.5,2.0]:
        for sdx in [sd, 1.5]:
            out.append(dict(endpoint=f'ANCOVA-adjusted GMT ratio vs {c}',assumed_true_GMR=gmr,residual_SD_log2=round(sdx,2),alpha_2sided=0.05,power=0.9,n_evaluable_per_arm=n_superiority(sdx,gmr)))
# HAI NI: GMT ratio margin 1.5 (comparator/new), SCR margin 10 points
h=pd.read_csv(DATA+'hai_titers.csv',dtype={'participant':str})
w=h.pivot_table(index=['antigen','arm','participant'],columns='timepoint',values='hai_titer').reset_index()
for ag,g in w.groupby('antigen'):
    sd=np.log2(g.wk4).std()
    # NI on GMT ratio: H0: log2 ratio >= log2(1.5); assume true ratio 1.0; one-sided alpha 0.025, power 0.9
    z=stats.norm.ppf(0.975)+stats.norm.ppf(0.9); n=ceil(2*(z*sd/np.log2(1.5))**2)
    sc=(((g.wk0<10)&(g.wk4>=40))|((g.wk0>=10)&(g.wk4/g.wk0>=3.9))).mean()
    # NI on SCR difference margin 0.10, assume equal true SCR = pooled observed
    p=max(sc,0.05); nsc=ceil(z**2*2*p*(1-p)/0.10**2)
    out.append(dict(endpoint=f'HAI NI (GMT ratio margin 1.5) {ag}',assumed_true_GMR=1.0,residual_SD_log2=round(sd,2),alpha_2sided=0.05,power=0.9,n_evaluable_per_arm=n))
    out.append(dict(endpoint=f'HAI NI (SCR diff margin 10 pts) {ag}; pooled SCR observed {sc*100:.0f}%',assumed_true_GMR=np.nan,residual_SD_log2=np.nan,alpha_2sided=0.05,power=0.9,n_evaluable_per_arm=nsc))
# SCR NI at 50% SCR (worst case)
z=stats.norm.ppf(0.975)+stats.norm.ppf(0.9)
out.append(dict(endpoint='HAI NI (SCR diff margin 10 pts) at worst-case SCR 50%',n_evaluable_per_arm=ceil(z**2*2*0.25/0.01)))
# Event-driven rVE trial: events needed for superiority (LB of rVE CI > 0) with 1:1 allocation
def events_needed(rve,alpha=0.05,power=0.9,lb=0.0):
    # log HR target vs null log(1-lb); variance of log HR ~ 4/D for 1:1
    z=stats.norm.ppf(1-alpha/2)+stats.norm.ppf(power)
    return ceil(4*z**2/(np.log(1-rve)-np.log(1-lb))**2)
for rve in [0.2,0.3,0.4]:
    out.append(dict(endpoint=f'rVE superiority (LB>0%) vs mismatched-strain influenza, true rVE {int(rve*100)}%',n_evaluable_per_arm=np.nan,events_total=events_needed(rve)))
    out.append(dict(endpoint=f'rVE non-inferiority (LB>-10%) any-strain influenza, true rVE {int(rve*100)}%',n_evaluable_per_arm=np.nan,events_total=events_needed(rve,lb=-0.10)))
o=pd.DataFrame(out); print(o.to_string()); o.to_csv('/tmp/outputs/tables/T12_sample_size_inputs.csv',index=False)
