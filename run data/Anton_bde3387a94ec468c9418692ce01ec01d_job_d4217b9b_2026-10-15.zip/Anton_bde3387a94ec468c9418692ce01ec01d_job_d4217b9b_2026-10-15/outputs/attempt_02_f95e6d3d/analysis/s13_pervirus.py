from common import *
from panel_classes import classify, year
import statsmodels.formula.api as smf
from scipy import stats
s=pd.read_csv(DATA+'neutralization_seqbased.csv'); s['arm']=s.serum.str.split('_').str[0]; s['pid']=s.serum.str.split('_').str[1].map(norm_pid); s['day']=s.serum.str.split('_').str[2]
s['cls']=s.virus.map(classify); s['l']=np.log2(s.titer); s['tp']=np.where(s.day.isin(['d121','d181']),'late',s.day)
w=s.pivot_table(index=['arm','pid','virus','cls'],columns='tp',values='l').reset_index()
rows=[]
for (v,c),g in w.groupby(['virus','cls']):
    g=g.assign(mrna=(g.arm=='mRNA-1010').astype(int))
    r=dict(virus=v,cls=c,year=year(v))
    for ep,col in [('d29','d29'),('late','late')]:
        gg=g.dropna(subset=['d0',col])
        f=smf.ols(f'{col}~mrna+d0',data=gg).fit()
        r[f'adj_ratio_{ep}']=2**f.params['mrna']; r[f'lo_{ep}']=2**f.conf_int().loc['mrna',0]; r[f'hi_{ep}']=2**f.conf_int().loc['mrna',1]; r[f'p_{ep}']=f.pvalues['mrna']
    r['d0_GMT_Flu']=2**g[g.mrna==0].d0.mean(); r['d29_GMT_Flu']=2**g[g.mrna==0].d29.mean(); r['d0_ratio']=2**(g[g.mrna==1].d0.mean()-g[g.mrna==0].d0.mean())
    rows.append(r)
o=pd.DataFrame(rows)
o.to_csv('/tmp/outputs/tables/T13_seqneut_per_virus_ancova.csv',index=False)
print(o.groupby('cls').agg(n=('virus','count'),median_adj_d29=('adj_ratio_d29','median'),min_adj_d29=('adj_ratio_d29','min'),max_adj_d29=('adj_ratio_d29','max'),n_p05_d29=('p_d29',lambda x:(x<0.05).sum()),median_adj_late=('adj_ratio_late','median'),n_p05_late=('p_late',lambda x:(x<0.05).sum())).round(2).to_string())
# Within forward-drifted H3: does the adjusted advantage increase with antigenic advancement (lower Fluarix d29 titre = more drifted)?
fw=o[o.cls=='H3: forward-drifted 2022-2024 isolates']
rho=stats.spearmanr(np.log2(fw.d29_GMT_Flu),np.log2(fw.adj_ratio_d29))
print('Forward H3: Spearman(log Fluarix d29 GMT, log adj ratio) = %.2f p=%.3f  (negative would mean bigger mRNA advantage on more drifted strains)'%(rho.correlation,rho.pvalue))
rho2=stats.spearmanr(fw.year,np.log2(fw.adj_ratio_d29)); print('Forward H3: Spearman(year, log adj ratio) = %.2f p=%.3f'%(rho2.correlation,rho2.pvalue))
print(fw.sort_values('d29_GMT_Flu')[['virus','year','d29_GMT_Flu','adj_ratio_d29','lo_d29','hi_d29','p_d29']].head(8).round(2).to_string())
print('count of forward-drifted H3 viruses with adj ratio > 1 at d29: %d/%d ; late: %d/%d'%((fw.adj_ratio_d29>1).sum(),len(fw),(fw.adj_ratio_late>1).sum(),len(fw)))
# all-virus nominal significance
print('viruses with nominal p<0.05 favouring mRNA at d29: %d/96; favouring Fluarix: %d/96'%(((o.p_d29<0.05)&(o.adj_ratio_d29>1)).sum(),((o.p_d29<0.05)&(o.adj_ratio_d29<1)).sum()))
print('at late visit favouring mRNA: %d/96; favouring Fluarix: %d/96'%(((o.p_late<0.05)&(o.adj_ratio_late>1)).sum(),((o.p_late<0.05)&(o.adj_ratio_late<1)).sum()))
