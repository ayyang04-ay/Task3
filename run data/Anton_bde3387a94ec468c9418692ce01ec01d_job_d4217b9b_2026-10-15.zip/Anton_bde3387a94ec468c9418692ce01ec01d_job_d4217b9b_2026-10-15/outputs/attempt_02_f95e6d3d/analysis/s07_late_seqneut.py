from common import *
from panel_classes import classify
import statsmodels.formula.api as smf
from scipy import stats
s=pd.read_csv(DATA+'neutralization_seqbased.csv'); s['arm']=s.serum.str.split('_').str[0]; s['pid']=s.serum.str.split('_').str[1].map(norm_pid); s['day']=s.serum.str.split('_').str[2]
s['cls']=s.virus.map(classify); s['l']=np.log2(s.titer)
s['tp']=np.where(s.day.isin(['d121','d181']),'late',s.day)
w=s.pivot_table(index=['arm','pid','virus','cls'],columns='tp',values='l').reset_index().dropna(subset=['d0','late','d29'])
pp=w.groupby(['cls','arm','pid']).agg(l0=('d0','mean'),l29=('d29','mean'),lL=('late','mean')).reset_index()
rows=[]
for c,g in pp.groupby('cls'):
    a=g[g.arm=='mRNA-1010']; b=g[g.arm=='Fluarix']
    f=smf.ols('lL~mrna+l0',data=g.assign(mrna=(g.arm=='mRNA-1010').astype(int))).fit()
    rows.append(dict(cls=c,late_GMT_mRNA=2**a.lL.mean(),late_GMT_Flu=2**b.lL.mean(),late_GMT_ratio=2**(a.lL.mean()-b.lL.mean()),
        late_over_d0_mRNA=2**(a.lL-a.l0).mean(),late_over_d0_Flu=2**(b.lL-b.l0).mean(),
        late_over_d29_mRNA=2**(a.lL-a.l29).mean(),late_over_d29_Flu=2**(b.lL-b.l29).mean(),
        adj_ratio_late=2**f.params['mrna'],lo=2**f.conf_int().loc['mrna',0],hi=2**f.conf_int().loc['mrna',1],p=f.pvalues['mrna']))
o=pd.DataFrame(rows); print(o.round(3).to_string()); o.to_csv('/tmp/outputs/tables/T07_seqneut_late_visit.csv',index=False)
