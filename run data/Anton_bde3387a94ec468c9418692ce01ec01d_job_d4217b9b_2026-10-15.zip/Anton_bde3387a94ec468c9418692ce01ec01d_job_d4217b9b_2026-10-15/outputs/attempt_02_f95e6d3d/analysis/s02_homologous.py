from common import *
from scipy import stats
rows=[]
h=pd.read_csv(DATA+'hai_titers.csv',dtype={'participant':str}); h['pid']=h.participant.map(norm_pid)
w=h.pivot_table(index=['antigen','arm','pid'],columns='timepoint',values='hai_titer').reset_index()
w['late']=w['wk26'].fillna(w['wk17'])
for ag,g in w.groupby('antigen'):
    for arm in ['mRNA-1010','Fluarix']:
        x=g[(g.arm==arm)&g.wk0.notna()&g.wk4.notna()]
        n=len(x); gmt,lo,hi,_=gm_ci(x.wk4); gmfr,flo,fhi,_=gm_ci(x.wk4/x.wk0)
        # FDA seroconversion: pre <10 & post>=40, or pre>=10 and >=4-fold rise. Titres are GMs of duplicates -> use >=3.9 fold to allow rounding (e.g. 28->113)
        sc=((x.wk0<10)&(x.wk4>=40))|((x.wk0>=10)&(x.wk4/x.wk0>=3.9))
        sp=(x.wk4>=40)
        p_sc,sclo,schi=wilson(sc.sum(),n); p_sp,splo,sphi=wilson(sp.sum(),n)
        rows.append(dict(antigen=ag,arm=arm,n=n,GMT_wk0=gm(x.wk0),GMT_wk4=gmt,GMT_wk4_lo=lo,GMT_wk4_hi=hi,GMFR=gmfr,GMFR_lo=flo,GMFR_hi=fhi,
                         SCR_pct=100*p_sc,SCR_lo=100*sclo,SCR_hi=100*schi,n_sc=int(sc.sum()),SPR_pct=100*p_sp,SPR_lo=100*splo,SPR_hi=100*sphi,n_sp=int(sp.sum())))
o=pd.DataFrame(rows)
print(o.round(1).to_string())
o.to_csv('/tmp/outputs/tables/T02a_HAI_endpoints.csv',index=False)
# comparator-vs-new NI-style metrics (FDA 2007 guidance: UB of 95% CI of GMT ratio comparator/new <=1.5; UB of SCR difference comparator-new <=10%)
rows=[]
for ag,g in w.groupby('antigen'):
    a=g[(g.arm=='mRNA-1010')&g.wk0.notna()&g.wk4.notna()]; b=g[(g.arm=='Fluarix')&g.wk0.notna()&g.wk4.notna()]
    r,lo,hi,p=gmr_ci(b.wk4,a.wk4)
    sca=(((a.wk0<10)&(a.wk4>=40))|((a.wk0>=10)&(a.wk4/a.wk0>=3.9))).sum(); scb=(((b.wk0<10)&(b.wk4>=40))|((b.wk0>=10)&(b.wk4/b.wk0>=3.9))).sum()
    dd,dlo,dhi=newcombe_diff(scb,len(b),sca,len(a))
    # ANCOVA on log2 wk4 with log2 wk0
    import statsmodels.formula.api as smf
    gg=pd.concat([a,b]); gg=gg.assign(l4=np.log2(gg.wk4),l0=np.log2(gg.wk0),mrna=(gg.arm=='mRNA-1010').astype(int))
    f=smf.ols('l4~mrna+l0',data=gg).fit()
    rows.append(dict(antigen=ag,GMT_ratio_Flu_over_mRNA=r,lo=lo,hi=hi,p=p,NI_GMT_met=(hi<=1.5),SCR_Flu=scb/len(b)*100,SCR_mRNA=sca/len(a)*100,SCR_diff_Flu_minus_mRNA=dd*100,diff_lo=dlo*100,diff_hi=dhi*100,NI_SCR_met=(dhi<=0.10),
                     ANCOVA_adj_GMR_mRNA_over_Flu=2**f.params['mrna'],adj_lo=2**f.conf_int().loc['mrna',0],adj_hi=2**f.conf_int().loc['mrna',1],adj_p=f.pvalues['mrna']))
o2=pd.DataFrame(rows)
print(o2.round(3).to_string())
o2.to_csv('/tmp/outputs/tables/T02b_HAI_NI_style.csv',index=False)

# MN
m=pd.read_csv(DATA+'microneutralization.csv'); m['pid']=m.participant.map(norm_pid)
mw=m[m.measure=='titer'].pivot_table(index=['panel','arm','pid'],columns='timepoint',values='value').reset_index()
mw['late']=mw['wk26'].fillna(mw['wk17'])
rows=[]
import statsmodels.formula.api as smf
for pan,g in mw.groupby('panel'):
    for arm in ['mRNA-1010','Fluarix']:
        x=g[g.arm==arm]
        rows.append(dict(panel=pan,arm=arm,n=len(x),GMT_wk0=gm(x.wk0),GMT_wk4=gm(x.wk4),GMFR_wk4=gm(x.wk4/x.wk0),pct_4fold=100*(x.wk4/x.wk0>=4).mean(),n_4fold=int((x.wk4/x.wk0>=4).sum()),
                         n_wk4_at_cap=int((x.wk4>=1280).sum()),n_wk0_at_cap=int((x.wk0>=1280).sum()),GMT_late=gm(x.late),GMFR_late=gm(x.late/x.wk0)))
    a=g[g.arm=='mRNA-1010']; b=g[g.arm=='Fluarix']
    r,lo,hi,p=gmr_ci(a.wk4,b.wk4); rf,flo,fhi,fp=gmr_ci(a.wk4/a.wk0,b.wk4/b.wk0)
    gg=g.assign(l4=np.log2(g.wk4),l0=np.log2(g.wk0),mrna=(g.arm=='mRNA-1010').astype(int))
    f=smf.ols('l4~mrna+l0',data=gg).fit()
    rows.append(dict(panel=pan,arm='ratio mRNA/Flu',GMT_wk4=r,GMFR_wk4=rf,note=f'GMT ratio 95%CI {lo:.2f}-{hi:.2f} p={p:.3f}; GMFR ratio 95%CI {flo:.2f}-{fhi:.2f} p={fp:.3f}; ANCOVA adj GMR {2**f.params["mrna"]:.2f} ({2**f.conf_int().loc["mrna",0]:.2f}-{2**f.conf_int().loc["mrna",1]:.2f}) p={f.pvalues["mrna"]:.3f}'))
    # without 014 (mRNA) and 019 (Flu) to mimic seq-neut cohort
    g2=g[~g.pid.isin(['014','019'])]; a2=g2[g2.arm=='mRNA-1010']; b2=g2[g2.arm=='Fluarix']
    r2,lo2,hi2,p2=gmr_ci(a2.wk4/a2.wk0,b2.wk4/b2.wk0); r3,lo3,hi3,p3=gmr_ci(a2.wk4,b2.wk4)
    rows.append(dict(panel=pan,arm='ratio mRNA/Flu excl 014 & 019',GMT_wk4=r3,GMFR_wk4=r2,note=f'GMT ratio 95%CI {lo3:.2f}-{hi3:.2f} p={p3:.3f}; GMFR ratio 95%CI {lo2:.2f}-{hi2:.2f} p={p2:.3f}'))
o3=pd.DataFrame(rows)
print(o3.round(2).to_string())
o3.to_csv('/tmp/outputs/tables/T02c_MN_endpoints.csv',index=False)
print(mw.sort_values(['panel','arm','pid']).to_string())
