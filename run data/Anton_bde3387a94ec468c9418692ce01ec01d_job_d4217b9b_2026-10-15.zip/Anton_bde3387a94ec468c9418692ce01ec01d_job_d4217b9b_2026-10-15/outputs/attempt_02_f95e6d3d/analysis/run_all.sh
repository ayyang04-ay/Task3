#!/usr/bin/env bash
# Re-runs every analysis used in /tmp/outputs/answer.md. Requires the 'core' micromamba env (pandas, scipy, statsmodels, matplotlib).
set -euo pipefail
cd "$(dirname "$0")"
for s in s00_inventory s01_baseline s02_homologous s03_seqneut s04_binding_vs_neut s05_breadth_per_participant s06_late_rises s07_late_seqneut \
         s08_cellular s09_mabs s10_repertoire_igm s11_elisa s12_power s13_pervirus s14_figures s15_late_d181_only s16_excluded s17_mn_sensitivity s18_design_numbers s19_mde s20_late_visit_labels; do
  echo "=== $s"; micromamba run -n core python $s.py > ../logs/$s.log 2>&1 || { echo "FAILED $s"; exit 1; }
done
echo "all done"
