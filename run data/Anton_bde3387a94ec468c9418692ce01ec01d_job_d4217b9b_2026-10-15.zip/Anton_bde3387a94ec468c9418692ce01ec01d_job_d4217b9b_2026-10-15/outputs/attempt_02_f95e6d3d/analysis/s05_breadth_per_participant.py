from common import *
from panel_classes import classify
from scipy import stats
s=pd.read_csv(DATA+'neutralization_seqbased.csv'); s['arm']=s.serum.str.split('_').str[0]; s['pid']=s.serum.str.split('_').str[1].map(norm_pid); s['day']=s.serum.str.split('_').str[2]
s['cls']=s.virus.map(classify)
w=s.pivot_table(index=['arm','pid','virus','cls'],columns='day',values='titer').reset_index().dropna(subset=['d0','d29'])
w['fc']=w.d29/w.d0
rows=[]
for cls_group,sel in [('H3 forward-drifted 2022-2024',w.cls=='H3: forward-drifted 2022-2024 isolates'),('H1 forward-drifted 2023',w.cls=='H1: forward-drifted 2023 isolates'),('All 96 viruses',w.cls.notna())]:
    x=w[sel]
    per=x.groupby(['arm','pid']).agg(n=('virus','count'),n4=('fc',lambda f:(f>=4).sum()),n2=('fc',lambda f:(f>=2).sum()),
                                     frac_d29_ge160=('d29',lambda t:(t>=160).mean()),frac_d0_ge160=('d0',lambda t:(t>=160).mean())).reset_index()
    per['frac4']=per.n4/per.n; per['frac2']=per.n2/per.n
    for arm,g in per.groupby('arm'):
        rows.append(dict(panel=cls_group,arm=arm,n_participants=len(g),median_frac_viruses_4fold=g.frac4.median(),mean_frac_4fold=g.frac4.mean(),
            n_participants_with_any_4fold=(g.n4>0).sum(),n_participants_4fold_on_majority=(g.frac4>0.5).sum(),
            mean_frac_2fold=g.frac2.mean(),mean_frac_d29_ge160=g.frac_d29_ge160.mean(),mean_frac_d0_ge160=g.frac_d0_ge160.mean()))
    a=per[per.arm=='mRNA-1010']; f=per[per.arm=='Fluarix']
    rows.append(dict(panel=cls_group,arm='MW p (frac 4-fold / frac d29>=160)',median_frac_viruses_4fold=stats.mannwhitneyu(a.frac4,f.frac4).pvalue,mean_frac_d29_ge160=stats.mannwhitneyu(a.frac_d29_ge160,f.frac_d29_ge160).pvalue))
    if cls_group.startswith('H3 forward'):
        print(per.sort_values(['arm','frac4']).round(2).to_string())
o=pd.DataFrame(rows); print(o.round(3).to_string()); o.to_csv('/tmp/outputs/tables/T05_breadth_per_participant.csv',index=False)
