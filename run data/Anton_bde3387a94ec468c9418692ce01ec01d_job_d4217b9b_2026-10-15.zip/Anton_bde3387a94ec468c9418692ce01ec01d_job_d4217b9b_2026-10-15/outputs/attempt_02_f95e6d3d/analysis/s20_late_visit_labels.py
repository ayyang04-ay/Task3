from common import *
rows=[]
e=pd.read_csv(DATA+'elisa_igg_titers.csv'); e['pid']=e.participant.map(norm_pid)
h=pd.read_csv(DATA+'hai_titers.csv',dtype={'participant':str}); h['pid']=h.participant.map(norm_pid)
m=pd.read_csv(DATA+'microneutralization.csv'); m['pid']=m.participant.map(norm_pid)
s=pd.read_csv(DATA+'neutralization_seqbased.csv'); s['pid']=s.serum.str.split('_').str[1].map(norm_pid); s['day']=s.serum.str.split('_').str[2]
def late(tps): return 'wk17' if ('wk17' in tps or 'd121' in tps) else ('wk26' if ('wk26' in tps or 'd181' in tps) else '-')
for (pid,ag),g in e[e.measure=='ec50'].groupby(['pid','antigen']): rows.append(('ELISA '+ag,pid,late(set(g.timepoint))))
for (pid,ag),g in h.groupby(['pid','antigen']): rows.append(('HAI '+ag,pid,late(set(g.timepoint))))
for (pid,ag),g in m[m.measure=='titer'].groupby(['pid','panel']): rows.append(('MN '+ag,pid,late(set(g.timepoint))))
for pid,g in s.groupby('pid'): rows.append(('SeqNeut',pid,late(set(g.day))))
r=pd.DataFrame(rows,columns=['assay','pid','late_visit']).pivot(index='pid',columns='assay',values='late_visit')
r=r.loc[sorted(set(h.pid))]; r.insert(0,'arm',h.drop_duplicates('pid').set_index('pid').arm)
mode=r.drop(columns='arm').mode(axis=1)[0]
disc=r.drop(columns='arm').ne(mode,axis=0)&r.drop(columns='arm').notna()&(r.drop(columns='arm')!='-')
r['discordant_assays']=[', '.join(c for c in disc.columns if disc.loc[i,c]) for i in r.index]
print(r.to_string()); r.to_csv('/tmp/outputs/tables/T20_late_visit_label_concordance.csv')
both=0
for df,key in [(e[e.measure=='ec50'],'antigen'),(h,'antigen'),(m[m.measure=='titer'],'panel')]:
    g=df.groupby(['pid',key]).timepoint.apply(set); both+=sum(('wk17' in x and 'wk26' in x) for x in g)
g=s.groupby('pid').day.apply(set); both+=sum(('d121' in x and 'd181' in x) for x in g)
print('participant x antigen series with BOTH a wk17 and a wk26 value:',both)
