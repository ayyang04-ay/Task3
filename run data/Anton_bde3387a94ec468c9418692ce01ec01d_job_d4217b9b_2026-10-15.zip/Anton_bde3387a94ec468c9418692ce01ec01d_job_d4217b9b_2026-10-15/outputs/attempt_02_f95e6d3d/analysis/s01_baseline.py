from common import *
from scipy import stats
rows=[]
# ELISA
e=pd.read_csv(DATA+'elisa_igg_titers.csv'); e['pid']=e.participant.map(norm_pid)
for ag,g in e[(e.measure=='ec50')&(e.timepoint=='wk0')].groupby('antigen'):
    a=g[g.arm=='mRNA-1010'].value; b=g[g.arm=='Fluarix'].value
    r,lo,hi,p=gmr_ci(a,b); mw=stats.mannwhitneyu(a,b).pvalue
    rows.append(dict(assay='ELISA IgG EC50 (full cohort)',target=ag,n_mRNA=len(a),n_Flu=len(b),GM_mRNA=gm(a),GM_Flu=gm(b),ratio_mRNA_over_Flu=r,ci_lo=lo,ci_hi=hi,p_welch=p,p_MW=mw))
# ELISA restricted to HAI cohort
h=pd.read_csv(DATA+'hai_titers.csv',dtype={'participant':str}); h['pid']=h.participant.map(norm_pid)
hai_ids=set(h.pid)
for ag,g in e[(e.measure=='ec50')&(e.timepoint=='wk0')&(e.pid.isin(hai_ids))].groupby('antigen'):
    a=g[g.arm=='mRNA-1010'].value; b=g[g.arm=='Fluarix'].value
    r,lo,hi,p=gmr_ci(a,b); mw=stats.mannwhitneyu(a,b).pvalue
    rows.append(dict(assay='ELISA IgG EC50 (HAI/MN sub-cohort)',target=ag,n_mRNA=len(a),n_Flu=len(b),GM_mRNA=gm(a),GM_Flu=gm(b),ratio_mRNA_over_Flu=r,ci_lo=lo,ci_hi=hi,p_welch=p,p_MW=mw))
# HAI
for ag,g in h[h.timepoint=='wk0'].groupby('antigen'):
    a=g[g.arm=='mRNA-1010'].hai_titer; b=g[g.arm=='Fluarix'].hai_titer
    r,lo,hi,p=gmr_ci(a,b); mw=stats.mannwhitneyu(a,b).pvalue
    rows.append(dict(assay='HAI titre',target=ag,n_mRNA=len(a),n_Flu=len(b),GM_mRNA=gm(a),GM_Flu=gm(b),ratio_mRNA_over_Flu=r,ci_lo=lo,ci_hi=hi,p_welch=p,p_MW=mw,
        pct_ge40_mRNA=(a>=40).mean()*100,pct_ge40_Flu=(b>=40).mean()*100))
# MN
m=pd.read_csv(DATA+'microneutralization.csv')
for ag,g in m[(m.timepoint=='wk0')&(m.measure=='titer')].groupby('panel'):
    a=g[g.arm=='mRNA-1010'].value; b=g[g.arm=='Fluarix'].value
    r,lo,hi,p=gmr_ci(a,b); mw=stats.mannwhitneyu(a,b).pvalue
    rows.append(dict(assay='MN titre',target=ag,n_mRNA=len(a),n_Flu=len(b),GM_mRNA=gm(a),GM_Flu=gm(b),ratio_mRNA_over_Flu=r,ci_lo=lo,ci_hi=hi,p_welch=p,p_MW=mw,
        pct_at_cap_mRNA=(a>=1280).mean()*100,pct_at_cap_Flu=(b>=1280).mean()*100))
# Seq neut: participant-level mean log2 d0 titre by subtype
s=pd.read_csv(DATA+'neutralization_seqbased.csv'); s['arm']=s.serum.str.split('_').str[0]; s['pid']=s.serum.str.split('_').str[1].map(norm_pid); s['day']=s.serum.str.split('_').str[2]
s['sub']=s.virus.str.split('_').str[-1]
d0=s[s.day=='d0'].copy(); d0['l']=np.log2(d0.titer)
pp=d0.groupby(['arm','pid','sub']).l.mean().reset_index()
for sub,g in pp.groupby('sub'):
    a=2**g[g.arm=='mRNA-1010'].l; b=2**g[g.arm=='Fluarix'].l
    r,lo,hi,p=gmr_ci(a,b); mw=stats.mannwhitneyu(a,b).pvalue
    rows.append(dict(assay='Seq-neut d0 (participant mean over panel)',target=sub,n_mRNA=len(a),n_Flu=len(b),GM_mRNA=gm(a),GM_Flu=gm(b),ratio_mRNA_over_Flu=r,ci_lo=lo,ci_hi=hi,p_welch=p,p_MW=mw))
# count of viruses where d0 GMT lower in mRNA arm
v=d0.groupby(['virus','arm']).l.mean().unstack()
v['diff']=v['mRNA-1010']-v['Fluarix']
print('viruses with lower d0 GMT in mRNA arm: %d of %d; median ratio %.2f (IQR %.2f-%.2f)'%((v['diff']<0).sum(),len(v),2**v['diff'].median(),2**v['diff'].quantile(.25),2**v['diff'].quantile(.75)))
print('by subtype:'); v['sub']=[x.split('_')[-1] for x in v.index]; print(v.groupby('sub')['diff'].agg(lambda x: f"{(x<0).sum()}/{len(x)} lower; median ratio {2**x.median():.2f}"))
o=pd.DataFrame(rows)
print(o.round(3).to_string())
o.to_csv('/tmp/outputs/tables/T01_baseline_comparability.csv',index=False)
