from common import *
from panel_classes import classify, year
import statsmodels.formula.api as smf
from scipy import stats
s=pd.read_csv(DATA+'neutralization_seqbased.csv'); s['arm']=s.serum.str.split('_').str[0]; s['pid']=s.serum.str.split('_').str[1].map(norm_pid); s['day']=s.serum.str.split('_').str[2]
s['cls']=s.virus.map(classify)
print(s.drop_duplicates('virus').cls.value_counts().to_string())
pd.DataFrame({'virus':sorted(s.virus.unique())}).assign(cls=lambda d: d.virus.map(classify)).to_csv('/tmp/outputs/tables/T03a_seqneut_panel_classification.csv',index=False)
s['l']=np.log2(s.titer)
w=s.pivot_table(index=['arm','pid','virus','cls'],columns='day',values='l').reset_index()
# participant-level means per class (only viruses with both d0 and d29)
w2=w.dropna(subset=['d0','d29'])
pp=w2.groupby(['cls','arm','pid']).agg(l0=('d0','mean'),l29=('d29','mean'),nv=('virus','nunique')).reset_index()
pp['lfc']=pp.l29-pp.l0
rows=[]
for c,g in pp.groupby('cls'):
    a=g[g.arm=='mRNA-1010']; b=g[g.arm=='Fluarix']
    gg=g.assign(mrna=(g.arm=='mRNA-1010').astype(int))
    f=smf.ols('l29~mrna+l0',data=gg).fit()
    t=stats.ttest_ind(a.lfc,b.lfc,equal_var=False)
    t29=stats.ttest_ind(a.l29,b.l29,equal_var=False)
    rows.append(dict(cls=c,n_viruses=int(g.nv.max()),n_mRNA=len(a),n_Flu=len(b),
        d0_GMT_mRNA=2**a.l0.mean(),d0_GMT_Flu=2**b.l0.mean(),d29_GMT_mRNA=2**a.l29.mean(),d29_GMT_Flu=2**b.l29.mean(),
        d29_GMT_ratio=2**(a.l29.mean()-b.l29.mean()),p_d29=t29.pvalue,
        GMFR_mRNA=2**a.lfc.mean(),GMFR_Flu=2**b.lfc.mean(),GMFR_ratio=2**(a.lfc.mean()-b.lfc.mean()),p_GMFR=t.pvalue,
        ANCOVA_adj_ratio=2**f.params['mrna'],adj_lo=2**f.conf_int().loc['mrna',0],adj_hi=2**f.conf_int().loc['mrna',1],adj_p=f.pvalues['mrna'],
        baseline_slope=f.params['l0']))
o=pd.DataFrame(rows)
order=['H1: mRNA-1010 vaccine strain as egg reassortant (IVR-238)','H1: cell-based equivalent of mRNA-1010 H1 (A/Wisconsin/67/2022)','H1: cell-based equivalent of Fluarix H1 (A/Wisconsin/588/2019)','H1: forward-drifted 2023 isolates','H1: historical 2009-2019',
       'H3: mRNA-1010 vaccine strain (A/Darwin/6/2021)','H3: Fluarix vaccine strain, wild-type (A/Darwin/9/2021)','H3: forward-drifted 2022-2024 isolates','H3: historical wild-type 2012-2020','H3: historical egg/reassortant']
o['cls']=pd.Categorical(o.cls,order); o=o.sort_values('cls')
print(o.round(3).to_string())
o.to_csv('/tmp/outputs/tables/T03b_seqneut_by_class_participant_level.csv',index=False)

# Sensitivity: LOD handling (<=40 set to 20)
s2=s.copy(); s2.loc[s2.titer_bound=='upper','titer']=20; s2['l']=np.log2(s2.titer)
w=s2.pivot_table(index=['arm','pid','virus','cls'],columns='day',values='l').reset_index().dropna(subset=['d0','d29'])
pp2=w.groupby(['cls','arm','pid']).agg(l0=('d0','mean'),l29=('d29','mean')).reset_index()
print('\nSensitivity (values at LOD set to LOD/2):')
for c,g in pp2.groupby('cls'):
    f=smf.ols('l29~mrna+l0',data=g.assign(mrna=(g.arm=='mRNA-1010').astype(int))).fit()
    a=g[g.arm=='mRNA-1010']; b=g[g.arm=='Fluarix']
    print(f'{c:70s} GMFR ratio {2**((a.l29-a.l0).mean()-(b.l29-b.l0).mean()):.2f}  adj ratio {2**f.params["mrna"]:.2f} ({2**f.conf_int().loc["mrna",0]:.2f}-{2**f.conf_int().loc["mrna",1]:.2f}) p={f.pvalues["mrna"]:.3f}')
pp.to_csv('/tmp/outputs/tables/T03c_seqneut_participant_class_means.csv',index=False)
