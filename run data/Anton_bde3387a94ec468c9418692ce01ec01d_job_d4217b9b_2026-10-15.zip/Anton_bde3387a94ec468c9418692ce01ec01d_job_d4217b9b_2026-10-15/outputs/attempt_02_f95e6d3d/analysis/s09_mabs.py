from common import *
from scipy import stats
import itertools
d=pd.read_csv(DATA+'mab_binding_panels.csv'); d['donor']=d.mab_id.str.split('.').str[1]
THR=10  # fold over SARS-CoV-2 RBD control; sensitivity at 5 and 20 in T09b
vacc={'group_I':'A/Victoria/4897/2022','group_II':'A/Darwin/6/2021'}
rows=[]; donor_rows=[]
for thr in [5,10,20]:
    for panel,g in d.groupby('panel'):
        p=g.pivot_table(index=['arm','donor','mab_id'],columns='antigen',values='fold_over_control')
        b=(p>=thr)
        # restrict to mAbs binding at least one HA in the panel (exclude RBD)
        ha=[c for c in b.columns if 'SARS' not in c]
        anyha=b[ha].any(axis=1)
        vb=b[vacc[panel]]
        for ag in ha:
            x=b[ag]
            # per donor fraction among mAbs binding the mRNA-1010 vaccine antigen of that subtype
            fr=x[vb].groupby(level=['arm','donor']).mean()
            n=vb.groupby(level=['arm','donor']).sum()
            for (arm,don),v in fr.items():
                donor_rows.append(dict(thr=thr,panel=panel,antigen=ag,arm=arm,donor=don,n_vaccine_binders=int(n[(arm,don)]),frac=v))
            pooled=x[vb].groupby(level='arm').mean()
            dm=fr.groupby(level='arm').mean()
            # exact donor-level permutation test (4 vs 3 donors => 35 splits)
            vals=fr.reset_index(); vals.columns=['arm','donor','frac']
            obs=vals[vals.arm=='mRNA-1010'].frac.mean()-vals[vals.arm=='Fluarix'].frac.mean()
            dons=list(vals.donor); fr_=dict(zip(vals.donor,vals.frac)); cnt=0; tot=0
            for comb in itertools.combinations(dons,4):
                m1=np.mean([fr_[k] for k in comb]); m2=np.mean([fr_[k] for k in dons if k not in comb]); tot+=1
                if abs(m1-m2)>=abs(obs)-1e-12: cnt+=1
            rows.append(dict(thr=thr,panel=panel,antigen=ag,pooled_frac_mRNA=pooled.get('mRNA-1010'),pooled_frac_Flu=pooled.get('Fluarix'),
                donor_mean_frac_mRNA=dm.get('mRNA-1010'),donor_mean_frac_Flu=dm.get('Fluarix'),donor_perm_p_two_sided=cnt/tot,
                n_mabs_mRNA=int(vb.xs('mRNA-1010',level='arm').sum()),n_mabs_Flu=int(vb.xs('Fluarix',level='arm').sum())))
o=pd.DataFrame(rows); dr=pd.DataFrame(donor_rows)
print(o[o.thr==10].round(3).to_string())
o.to_csv('/tmp/outputs/tables/T09a_mab_crossreactivity_donor_level.csv',index=False); dr.to_csv('/tmp/outputs/tables/T09b_mab_by_donor.csv',index=False)
print(dr[dr.thr==10].pivot_table(index=['panel','antigen'],columns=['arm','donor'],values='frac').round(2).to_string())
print(dr[dr.thr==10].pivot_table(index=['panel'],columns=['arm','donor'],values='n_vaccine_binders',aggfunc='max').to_string())
# mAbs not binding the mRNA vaccine antigen
for panel,g in d.groupby('panel'):
    p=g.pivot_table(index=['arm','donor','mab_id'],columns='antigen',values='fold_over_control')
    nb=(p[vacc[panel]]<THR)
    print(panel,'mAbs NOT binding mRNA-1010 antigen (<%d-fold):'%THR, nb.groupby(level=['arm','donor']).sum().to_dict(), ' of ', nb.groupby(level=['arm','donor']).size().to_dict())
