# WU397 review — output index

- `answer.md` — recommendation (one line at top), reasoning, study specifications, number ledger with sources.
- `analysis/` — all analysis code. `run_all.sh` re-runs everything (needs the `core` micromamba env). Reads only `/tmp/world/filesystem`.
  - `common.py` — ID normalisation, geometric means, CIs.
  - `panel_classes.py` — classification of the 96 sequencing-neutralisation viruses relative to BOTH vaccines' antigens.
  - Scripts, each producing the table(s) named in brackets:

    | Script | Content | Output |
    |---|---|---|
    | s00 | Cohort inventory vs `trial_summary.md` | T00 |
    | s01 | Baseline comparability | T01 |
    | s02 | HAI and MN endpoints, non-inferiority-style metrics, ANCOVA | T02a–c |
    | s03 | Sequencing-based neutralisation by antigenic class, participant-level ANCOVA | T03a–c |
    | s04 | Binding vs neutralisation | T04a–b |
    | s05 | Breadth per participant | T05 |
    | s06 | Late-visit rises, durability | T06a–c |
    | s07 | Late-visit neutralisation | T07 |
    | s08 | GC / plasmablast (incl. duplicate-block detection) | T08a |
    | s09 | mAb cross-reactivity, donor-level permutation tests | T09a–b |
    | s10 | Repertoire and IgM | T10 |
    | s11 | ELISA ANCOVA | T11 |
    | s12 | Sample-size inputs | T12 |
    | s13 | Per-virus ANCOVA | T13 |
    | s14 | Figures | F1–F5 |
    | s15 | Day-181-only sensitivity | T15 |
    | s16 | Checks on 397-014 / 397-019 | log only |
    | s17 | MN exclusion sensitivity | T17 |
    | s18 | Design numbers | T18 |
    | s19 | Detectable effect sizes in WU397 | T19 |
    | s20 | Late-visit label concordance | T20 |

- `tables/` — CSV outputs.
- `figures/` — F1–F5:
  - F1: class-level adjusted ratios at day 29 and the late visit.
  - F2: binding vs neutralisation.
  - F3: per-virus ratio by isolation year.
  - F4: baseline imbalance.
  - F5: the two unlabeled blocks in the GC file.
- `logs/` — stdout of each script (several numbers in `answer.md` are quoted from these logs).
