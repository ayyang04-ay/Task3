**Recommendation (one line):** Don't take WU397 forward as evidence of heterologous protection; instead run a randomised, observer-blind, strain-matched Phase 2 (mRNA vs. a non-egg and an egg-based licensed vaccine, all with the same WHO strains, stratified by age and prior vaccination) whose go/no-go is baseline-adjusted day-29 and day-181 neutralisation against a locked panel of viruses heterologous to every arm, and only if it passes commit to an event-driven Phase 3 relative-efficacy trial whose claim-bearing endpoint is PCR-confirmed influenza caused by antigenically mismatched strains.

---

## 1. Summary of the reasoning

1. **WU397 can't separate the platform from the choice of strains.**
   - Allocation was by enrolment site (not randomised) and the study was open-label.
   - The mRNA arm received different H1 and H3 antigens from Fluarix:
     - H1: A/Victoria/4897/2022, the WHO strain for 2023–24, vs. Fluarix's A/Victoria/2570/2019.
     - H3: cell-type A/Darwin/6/2021 vs. Fluarix's egg-propagated A/Darwin/9/2021.
   - Every "homologous/heterologous" label is defined against mRNA-1010 only. Only the two B components were the same in both vaccines.
2. **The arms weren't comparable at baseline.**
   - The mRNA arm started with lower neutralising titres against 94 of the 96 panel viruses (median ratio 0.70).
   - Microneutralisation (MN) "heterologous" baseline titres were about half those of the Fluarix arm (GMT 57 vs. 121).
   - Fold-rise drops steeply as baseline rises. Raw fold-rise comparisons, which is how "breadth" is usually presented, therefore favour the mRNA arm mechanically.
3. **No advantage against drifted H3N2 after baseline adjustment.** For the viruses a heterologous claim is actually about — 68 H3N2 isolates from 2022–2024 — the mRNA/Fluarix ratio was:
   - day 29: 1.17 (95% CI 0.64–2.11);
   - day 121/181: 1.04 (0.65–1.67);
   - none of the 68 viruses was individually significant;
   - the advantage did not grow as viruses became more drifted.
   - Against its own H3 strain (A/Darwin/6/2021), the mRNA arm's day-29 GMT was half of Fluarix's (244 vs. 482).
4. **The one neutralising advantage is a short-lived H1 effect, not breadth.**
   - It was about 2× at day 29, and about equal across every H1 virus — including the strain like Fluarix's own H1 (2.44×). That makes it a size effect, not breadth.
   - mRNA-arm titres fell more steeply: to 43% of day-29 values, vs. 78% for Fluarix. By months 4–6 the ratio was 1.15 (0.75–1.76).
5. **The large "breadth" signal in the package is binding, not neutralisation.**
   - H3 bead-array rises were 3–10× higher in the mRNA arm (6–10× for the vaccine-like and recent strains), including against the 1968 H3 (9.5×).
   - In the same people against the same strains, neutralisation was 0.8–2.5×.
   - Against A/Darwin/6/2021, binding was 7.2× but neutralisation 0.82×.
   - The excess of binding over neutralisation is 4.5× in the mRNA arm (p<0.0001).
   - Together with more mAbs binding the 1968 H3 and H7, this fits antibodies to conserved, largely non-neutralising sites. Their protective value is untested.
6. **Homologous endpoints show no superiority, and non-inferiority can't be judged at this size.**
   - HAI seroconversion was low in both arms: H1N1 7/14 vs. 5/15, H3N2 2/14 vs. 3/15, B 0–1 per arm.
   - For the matched B strains, fold-rise was 1.0–1.3 in both arms.
   - Seroconversion-difference 95% CIs are 45–64 points wide (running from −46 to +33).
7. **The lymph-node, antibody-clone and repertoire signals come from very few people and have data problems.** They explain mechanism; they are not evidence of protection.
   - The one strong signal is germinal-centre (GC) frequency: 24.7% vs. 4.7% at peak.
   - That comes from 6 vs. 11 participants. The mAbs come from 4 vs. 3 donors, and the repertoire files have no participant IDs.
8. **WU397 was never powered to answer the question.** It could only detect differences of about 2.0–2.2×. The H3 result is therefore inconclusive rather than negative. That is why the next step is a properly powered randomised comparison, not an efficacy trial built on this package.

---

## 2. What the WU397 package shows

All analysis code is in `/tmp/outputs/analysis/`, output tables (Txx) in `/tmp/outputs/tables/`, figures (Fx) in `/tmp/outputs/figures/`.

### 2.1 Design problems

- **Different antigens in the two arms.**
  - mRNA-1010 (from `trial_summary.md`): A/Victoria/4897/2022 (H1), A/Darwin/6/2021 (H3), B/Austria/1359417/2021, B/Phuket/3073/2013.
  - Fluarix 2022–23 Northern Hemisphere (outside knowledge, to be checked against the lot labelling): the WHO egg-based strains A/Victoria/2570/2019 (H1), A/Darwin/9/2021 (H3, egg-propagated), and the same two B strains.
  - The mRNA H1 is a season ahead of Fluarix's (WHO 2023–24). Its H3 is the cell-based counterpart of Fluarix's egg strain.
  - Only the B components are matched.
  - Any H1 or H3 difference therefore mixes together: platform, strain choice, and egg adaptation.
  - The mRNA composition would also not have been a licensable composition for that season.
- **Panels are built around mRNA-1010.**
  - The summary says "homologous/heterologous" refers to mRNA-1010's antigens. If the "homologous" readouts use mRNA-1010's strains, as that convention implies, then for Fluarix the H1 "homologous" readout is against a strain it doesn't contain.
  - The HAI and MN files don't say which viruses were tested.
  - Sequencing-based neutralisation panel:
    - mRNA-1010's H1 appears only as its egg reassortant (A/Victoria/4897/2022 IVR-238).
    - Fluarix's H1 is absent.
    - 5 older H3 strains appear twice (as the wild-type virus and as an egg/production copy).
    - It contains 83 H3N2, 13 H1N1 and 0 B viruses (T03a).
  - The bead-array H1 panel contains neither vaccine's H1.
- **Non-randomised allocation, and no demographic or vaccination-history data**, so comparability can only be checked through pre-vaccination titres (T01). On those, the mRNA arm was lower:
  - sequencing-based neutralisation: lower for 94 of 96 viruses (median day-0 ratio 0.70, IQR 0.64–0.77);
  - average H3N2 baseline per participant: 185 vs. 278 (ratio 0.67, 95% CI 0.39–1.14);
  - MN heterologous: 57 vs. 121 (ratio 0.47, 0.22–1.00, p=0.05).
  - Fold-rise falls with baseline: the slope of log fold-rise on log baseline was −0.26 to −0.86 in ELISA (s11 log; Fig F4).
- **Underpowered.** Smallest difference detectable with 80% power:
  - neutralisation 2.0–2.2×;
  - HAI 1.6–2.2×;
  - about 48 percentage points for seroconversion rate (SCR) (T19).

### 2.2 Neutralisation by antigenic class

Sequencing-based neutralisation: 13 mRNA vs. 14 Fluarix participants. Analysis averages each person's titres within a virus class, then compares arms adjusting for baseline (ANCOVA). Sources: T03b, T07, T13, T15; Fig F1, F3.

| Virus class (n viruses) | d29 GMT mRNA / Flu | Adjusted ratio d29 (95% CI) | Adjusted ratio d121/181 (95% CI) |
|---|---|---|---|
| H3 mRNA-1010's own strain, A/Darwin/6/2021 (1) | 244 / 482 (raw ratio 0.51, p=0.035) | 0.62 (0.34–1.12) | 0.72 (0.40–1.31) |
| H3 Fluarix's strain, wild-type A/Darwin/9/2021 (1) | 1009 / 1539 | 0.81 (0.35–1.87) | 0.57 (0.25–1.27) |
| **H3 drifted 2022–24 isolates (68)** | 401 / 465 | **1.17 (0.64–2.11)** | **1.04 (0.65–1.67)** |
| H3 older wild-type 2012–20 (8) | 1520 / 1268 | 1.63 (0.99–2.69) | 1.46 (0.88–2.40) |
| H3 older egg/production copies (5) | 4635 / 3345 | 1.51 (1.03–2.22) | 1.34 (0.84–2.15) |
| H1 strain like Fluarix's H1, A/Wisconsin/588/2019 (1) | 1073 / 506 | 2.44 (1.18–5.05) | 1.17 (0.62–2.23) |
| H1 strain like mRNA's H1, A/Wisconsin/67/2022 (1) | 431 / 197 | 2.07 (1.26–3.39) | 1.23 (0.83–1.84) |
| **H1 drifted 2023 isolates (6)** | 478 / 257 | **2.06 (1.23–3.46)** | **1.15 (0.75–1.76)** |
| H1 older 2009–19 (4) | 2533 / 1687 | 1.69 (0.91–3.13) | 1.11 (0.61–2.03) |

- "Drifted" is a proxy based on isolation year, because the package has no antigenic data.
- Looking at the 68 drifted H3N2 viruses one by one (T13):
  - the adjusted ratio was 0.82–1.51 (median 1.15) and none had p<0.05;
  - the advantage did not get larger as viruses became more drifted (Spearman −0.13, p=0.28).
- Per participant, the average share of drifted-H3 viruses with a ≥4-fold rise was 27.5% (mRNA) vs. 23.9% (Fluarix), p=0.36 (T05).
- 12 of the 96 viruses were nominally significant at day 29, all favouring mRNA: 8 H1 and 4 older H3. At the late visit only 2 of 96 were (T13).
- Using only participants seen at day 181, no class differed:
  - drifted H3: 0.98 (0.58–1.66);
  - drifted H1: 1.14 (0.68–1.94) (T15).
- Decline from day 29 to the late visit, drifted H1: ×0.43 (mRNA) vs. ×0.78 (Fluarix) (T07).
- Across all viruses, results were unchanged when values at the detection limit were set to half the limit (s03 log).

### 2.3 Binding is not neutralisation

Sources: T04a, T04b; Fig F2.

- **Bead-array fold-rise, mRNA vs. Fluarix:**
  - H3 Darwin/6: 6.1×.
  - H3 Thailand/8/2022: 9.4×.
  - H3 Hong Kong/1/1968: 9.5× (log2 fold-rise 3.45 vs. 0.20).
  - H1 Puerto Rico/8/1934: 2.7×.
- **Same 27 people, same strains, binding vs. neutralisation advantage:**
  - Darwin/6: binding 7.2×, neutralisation 0.82×.
  - Thailand/8: binding 11.9×, neutralisation 0.89×.
  - Singapore/2016: binding 11.7×, neutralisation 2.5×.
- **Excess of binding over neutralisation in the mRNA arm:**
  - H3: 4.5× (Welch p<0.0001; Mann–Whitney p=0.0001).
  - H1: 1.0× (p=0.86). For H1, binding and neutralisation agree.
- **ELISA IgG (75 participants, baseline-adjusted)** (T11):
  - At week 4: H1 2.67× (2.01–3.53), H3 3.31× (2.47–4.44), B/Vic 1.35× (1.04–1.76), B/Yam 1.38× (1.11–1.71).
  - By week 17/26: H1 1.51×, H3 2.06×, B/Vic 0.99×, B/Yam 1.06×.
  - On the matched B antigens the advantage is small and temporary.
- **mAbs** (binding to the mRNA vaccine antigen ≥10-fold over the SARS-CoV-2 RBD control; compared at the donor level):
  - Cross-binding to Hong Kong/1968: 51% vs. 10% of mAbs (p=0.067). Cross-binding to H7: 10.5% vs. 0%.
  - With 4 vs. 3 donors, the smallest possible p-value is 0.057.
  - The Fluarix H3-binding mAbs come from only 2 donors (20 and 3 mAbs).
  - These are consistent with conserved (e.g. stalk) sites, but which sites they bind was not measured (T09a/b).

### 2.4 Homologous readouts and durability

- **HAI at week 4, mRNA vs. Fluarix** (14 vs. 15; which viruses were tested is not specified) (T02a/b):
  - H1N1: GMT 138 vs. 88. SCR 7/14 vs. 5/15. Adjusted ratio 1.54 (0.87–2.71).
  - H3N2: GMT 56 vs. 58. SCR 2/14 vs. 3/15. Seroprotection 64% vs. 87%.
  - B/Vic: GMT 57 vs. 52. SCR 0/13 vs. 1/15.
  - B/Yam: GMT 88 vs. 99. SCR 0/14 vs. 1/15.
  - CIs for the SCR difference run from −46 to +33 points, so FDA-style non-inferiority on seroconversion can't be assessed.
- **MN** (T02c, T17):
  - Homologous at week 4: GMT 325 vs. 588; adjusted ratio 0.68 (0.31–1.51).
  - Heterologous: fold-rise 4.12 vs. 3.03; adjusted ratio 1.17 (0.52–2.62).
  - Titres are capped at 1:1280. At week 4 on the homologous panel, 9/15 Fluarix vs. 4/14 mRNA participants were at the cap, so Fluarix responses are under-measured.
- **Durability, late value divided by week 4, mRNA vs. Fluarix** (T06c):
  - HAI H1N1: 0.53 vs. 0.93. Late GMT 73 vs. 82.
  - ELISA H1: 0.42 vs. 0.74.
  - MN heterologous: late GMT 126 vs. 320.
  - The early advantage doesn't last through the season.
- **No clear sign of infection during the season.**
  - No participant had a ≥4-fold neutralisation rise between day 29 and the late visit (T06b).
  - A few ≈2.8× HAI and ELISA rises (T06a) need source checking.

### 2.5 Lymph-node, repertoire and mAb data

These are useful for mechanism, not as evidence of protection.

- **GC B cells, file block A** (see data issues below): peak after vaccination, median 24.7% (6 participants) vs. 4.7% (11), p=0.001 (T08a).
- **Serum antibody repertoire:** pre-existing clonotypes make up about 84–86% of serum IgG in both arms. Vaccine-induced clonotypes: 32 vs. 17.5, p=0.066 (T10).
- **Overlap between GC clones and week-1 plasmablast clones:** 73–92% of GC clones in the mRNA donors (`pb_gc_clonal_overlap.csv`).

Together these suggest that in these adults the response mostly recalls existing memory. Any "breadth" will therefore depend on prior exposure. The next studies must record exposure history and stratify by it.

### 2.6 Data problems to fix before this package is cited

1. `gc_frequencies.csv` has 156 rows. It is two stacked blocks of 78 with the same timepoint/arm/participant keys but different values (Spearman 0.57; 13 of 78 identical), and nothing labels which is which.
2. GC labels are wk0/2/8/17/26, but the protocol FNA visits are weeks 1, 2, 4, 8, 17 and 26. No wk0 FNA is in the protocol, and wk1 and wk4 are missing.
3. The plasmablast file:
   - uses weeks 2 and 8, which are not blood-draw visits, and has no day-7 value (the overlap file refers to "wk1 PB");
   - reports 0.6–4.7% at weeks 17/26, implausible for circulating plasmablasts;
   - covers 13/15 participants, 11 of whom are outside the HAI and FNA sub-cohorts and not described anywhere.
4. Late-visit labels:
   - no participant has both a week-17 and a week-26 value for the same assay target, even though the summary implies some attended both;
   - HAI B/Vic late labels are swapped relative to every other assay for 8 participants;
   - sequencing-based neutralisation labels 397-007 and 397-011 as day 121, where every other assay has week 26 (T20).
5. 397-014 (mRNA) and 397-019 (Fluarix) are missing from the sequencing-based neutralisation set without explanation.
   - 397-014's MN titres (10–15 at every visit) don't fit its HAI (320) or its ELISA rise (36×): MN/HAI ratio 0.03 vs. ≥0.75 for everyone else.
   - 397-019 was a strong responder.
   - Dropping both moves the MN heterologous fold-rise ratio from 1.36 to 1.71 (T17).
6. The IgM file has 14/15 participants; the summary says 38/37.
7. IDs are inconsistent: bare integers in ELISA, "20" in IgM, and "397-06" with no arm column in the overlap file. The three repertoire files have no participant IDs at all.
8. Panel hygiene: one malformed virus name (A/SOUTHAFRICA/R07876/"202023") and 13 South-African 2023 isolates, so one sampling source carries extra weight. Censored values: 171 titres at or below the lower limit of 40, and 70 at or above the upper limits of 17,300 or 6,291.

---

## 3. Recommended next studies

The order of dependence: Study 0 → Study 1, which is the gate. Study 2 is optional and can run alongside Study 1. Study 3 is the study that would actually support the claim.

### Study 0 — Close out WU397 (no new enrolment; weeks)

- **Purpose:** establish what WU397 actually showed, and set the variance assumptions and panel for Study 1. It cannot fix the lack of randomisation.
- **Conditions:**
  - Fix the problems in §2.6.
  - Collect age, sex, site, documented vaccination over the last 3–5 seasons, and prior confirmed influenza for all 75 participants.
  - Pre-specify the analysis: ANCOVA on baseline, per-participant panel means, separate visits (no week-17/26 pooling).
- **Readouts** (existing sera, all 29 serology participants including 397-014 and 397-019):
  - Neutralising titres against both products' actual vaccine strains: A/Victoria/2570/2019-like, wild-type A/Victoria/4897/2022, and A/Darwin/9/2021 egg and wild-type.
  - A B/Victoria drifted panel.
  - N1 and N2 neuraminidase-inhibition (NAI) titres. mRNA-1010 as described encodes one antigen (HA) per strain, while split vaccines contain neuraminidase.
  - MN titres reported without an upper cap.
  - Where stored volume allows, extend neutralisation to all 75 participants with ELISA sera, not just the 29. This lowers the smallest detectable difference from about 2.2× to about 1.6× (T19 SE scaled by group size). The estimate is still non-randomised.
  - The HAI and MN test viruses named.
- **Decision:** if breadth against viruses heterologous to both vaccines is still ~1× after adjustment, the programme should weigh up whether to continue with the heterologous positioning before paying for Study 1.

### Study 1 — Phase 2, randomised, observer-blind, strain-matched breadth study (the gate)

**Conditions — in whom**
- Adults in two age strata, 18–64 (subdivided 18–49 / 50–64) and ≥65, at multiple sites.
- Randomisation within site, stratified by age and prior-season vaccination (yes/no).
- Record birth year (first-exposure cohort), vaccination history for 5 seasons, and prior PCR-confirmed influenza.
- Exclude: influenza vaccine or confirmed influenza within 6 months, immunosuppression, and prior investigational mRNA influenza vaccine.

**Conditions — against what** (all arms carry the regulator-selected strains for the season; trivalent H1/H3/B-Victoria, given that B/Yamagata has been removed from current compositions)

| Arm | Product | Question it answers |
|---|---|---|
| A | mRNA vaccine encoding the WHO cell/recombinant-based strains for the season | Test article |
| B (primary comparator) | Licensed non-egg vaccine with the same strains (cell-based standard dose for 18–64; recombinant or another preferentially recommended vaccine for ≥65) | Platform effect with strains and egg adaptation removed |
| C | Licensed egg-based vaccine of the same season (e.g. Fluarix for 18–64; high-dose or adjuvanted egg-based for ≥65) | Repeats the WU397 comparison properly; A vs. C minus A vs. B estimates the egg-adaptation share |
| D (optional, exploratory) | mRNA with sponsor-selected updated strains | Only if a separate "strain-agility" claim is wanted; it can't support the platform claim |

**Conditions — blinding, visits, infection surveillance**
- Observer-blind: participants, investigators and laboratories blinded to arm.
- Fixed visits: day 0, day 29 (primary), day 181 (key secondary, end of season), day 365 (exploratory). Visit windows are pre-defined, and no visits are pooled.
- Influenza-like illness surveillance with PCR through day 181.
- A serological marker of infection using an antigen absent from every vaccine. Infected participants are excluded from the per-protocol immunogenicity set; a sensitivity analysis includes them.

**Readouts**
- **Primary (superiority, A vs. B):** neutralising GMT at day 29 against a locked heterologous panel. Tested in fixed order: H3N2, then H1N1pdm09, then B/Victoria. Measured in all randomised participants. The endpoint is each person's average log titre across the panel, with each antigenic cluster weighted equally, compared by ANCOVA (baseline titre, age stratum, prior vaccination, site).
- **Panel specification:** the key departure from WU397 is that "heterologous" is defined against every arm's vaccine strain.
  - A virus qualifies only if it shows a pre-specified antigenic distance from all arms' vaccine strains, e.g. ≥4–8-fold lower reactivity with reference post-infection antisera, or ≥2 antigenic units.
  - Wild-type viruses only. Egg and production reassortants are reported separately and never counted towards breadth.
  - One representative per antigenic cluster.
  - Include the most advanced circulating or emerging clades.
  - At least 6–10 viruses per subtype.
  - Locked before unblinding. A second "follow-up season" panel is added using a selection rule fixed in advance: representatives of the clades that actually circulated during follow-up.
- **Key secondary (continuing the fixed order):**
  1. The same comparison at day 181, because protection has to last the season.
  2. A vs. C at day 29 and day 181.
  3. Breadth per participant: share of panel viruses with titre ≥ the pre-specified threshold, and share with ≥4-fold rise.
  4. HAI against the vaccine strains at day 29 vs. arm B, using FDA non-inferiority criteria: upper 95% bound of the comparator/test GMT ratio ≤1.5, and upper bound of the SCR difference ≤10 points.
- **Secondary:**
  - HAI and MN against the vaccine strains at day 181.
  - N1 and N2 NAI at days 0, 29 and 181 (all arms).
  - Stalk-directed IgG.
  - Reactogenicity (7 days) and safety (through day 181).
- **Exploratory (never used as breadth evidence):**
  - Multiplex binding breadth.
  - Fc-effector function.
  - A small, consented, randomised lymph-node sub-study (GC kinetics) at designated sites.
- **Historical ("back-boosting") panel:** exploratory only. Older strains no longer circulate and say nothing about protection against drift.

**Size**
- 178 evaluable (about 210 randomised) per arm per age stratum. Basis:
  - true ratio 1.5;
  - residual SD 1.5 on the log2 scale (conservative; WU397 gave 0.94–1.02);
  - sized conservatively as if the three subtype tests were Bonferroni-split (two-sided α = 0.05/3);
  - 90% power.
- With residual SD 1.0: 79 evaluable per arm.
- Total for 3 arms × 2 strata: about 1,260 participants (T18, T12).
- Non-inferiority on seroconversion for licensure needs about 526 per arm (T12). Confirm it in Study 3's immunogenicity subset or a dedicated study, not in this gate.

**Go/no-go**

| Outcome | Decision |
|---|---|
| A vs. B adjusted ratio ≥1.5 with lower 95% bound >1.0 at day 29 for H3N2 and H1N1; lower bound >1.0 at day 181 for at least H3N2; HAI non-inferiority met; no safety signal | **Go** to Study 3 |
| Passes vs. C only | The advantage is egg adaptation, not platform. The heterologous claim would be limited to egg-based vaccines. |
| Fails | Drop the heterologous-protection positioning for this construct. |

### Study 2 (optional, runs alongside Study 1) — randomised heterologous human-challenge study

This is an early proof-of-concept for protection. It can't support the claim on its own.

- **In whom:** healthy adults aged 18–50, screened for low pre-existing antibody to the challenge strain.
- **Against what:** randomised and double-blind to (i) mRNA with the WHO strains, (ii) a licensed vaccine with the same strains, or (iii) placebo. Challenge about 4–6 weeks after vaccination with a well-characterised challenge strain that is antigenically heterologous to all vaccine strains.
- **Readouts:**
  - Primary: laboratory-confirmed symptomatic influenza.
  - Secondary: infection (viral shedding), area under the viral-load curve, symptom-score area.
  - Pre-challenge neutralising and NAI titres against the challenge strain, as candidate correlates.
- **Size:** about 58–82 per arm, to detect a fall in symptomatic infection from 40–50% to 20–25% (80% power; T18). Viral-load area under the curve would need fewer.

### Study 3 — Phase 3 relative-efficacy trial (the study that would support the claim)

Start only after Study 1 says "Go". For a heterologous-protection label claim, clinical endpoints classified by antigenic match are required; there is no accepted immune correlate for heterologous strains. Agree the endpoint and claim wording with the agency.

- **In whom:**
  - Adults ≥50, stratified 50–64 / 65–74 / ≥75 and by prior vaccination (or whichever age group Study 1 supports).
  - Multiple countries, both hemispheres, at least 2 seasons, event-driven.
- **Against what:**
  - 1:1, observer-blind, against a licensed, age-appropriate vaccine with the same strains. For ≥65 this must be a preferentially recommended product, with non-egg preferred.
  - The mRNA arm encodes the same regulator-selected strains. Any benefit against mismatched strains then reflects breadth, not strain choice.
- **Readouts:**
  - **Case-finding:** active surveillance for influenza-like illness from day 14 to the end of each season; PCR on every episode; HA sequencing of every case.
  - **Match classification:** each case is classified as antigenically matched or mismatched to the vaccine strain by an algorithm fixed before unblinding. The algorithm uses genetic group plus antigenic data and is applied by a blinded committee. Unclassifiable cases get sensitivity analyses.
  - **Primary:** relative efficacy against PCR-confirmed, protocol-defined influenza-like illness from any strain. Non-inferiority first (lower bound > −10%), then superiority.
  - **Key secondary (the claim):** relative efficacy against PCR-confirmed influenza caused by antigenically mismatched strains; superiority with lower bound >0, inside the multiplicity-controlled hierarchy.
  - **Other secondary:** results by subtype and for matched strains; medically attended illness; hospitalisation and lower-respiratory disease.
  - **Correlates sub-study** (random subcohort plus all cases): day-29 HAI and neutralisation against vaccine strains and against viruses representing the case strains, plus NAI, to derive a correlate for heterologous protection.
- **Size:**
  - Mismatched-strain cases needed: 331 for a true relative efficacy of 30% (90% power); 162 for 40%; 845 for 20%.
  - That is roughly 31,000–87,000 participant-seasons, assuming a 1.5–2.5% attack rate and 30–50% of cases being mismatched (T12, T18).
  - Include a futility interim analysis.

### What not to do

- Don't take WU397 straight to efficacy.
- Don't use binding breadth or raw fold-rise as the breadth endpoint.
- Don't define "heterologous" against only one product's strains.
- Don't count egg/production copies of the same strain as extra breadth.
- Don't pool week-17 and week-26 visits.
- Don't draw conclusions from mAb counts without accounting for donor.
- Don't let the programme's own strain choice stand in for platform breadth.

---

## 4. Number ledger

All values come from `/tmp/world/filesystem` unless marked *external*. "Output" refers to `/tmp/outputs/tables/Txx` or the script logs in `/tmp/outputs/logs/`.

| # | Value | Meaning | Source file(s) → output |
|---|---|---|---|
| 1 | 38/37; 14/15; 14/15; 13/14; 6/11 | Cohort sizes (ELISA; HAI; bead array/MN; sequencing-based neutralisation; FNA) | trial_summary.md, all csv → T00 |
| 2 | IgM file 14/15 vs. stated 38/37; plasmablast file 13/15 (11 not in HAI/FNA cohorts) | Cohort discrepancies | igm_fold_change.csv, plasmablast_frequencies.csv → T00, s00 log |
| 3 | 589 mAbs / 4 donors vs. 106 / 3 (donor 05 = 84); H3 vaccine-binders 300 vs. 23 (2 donors) | mAb structure | mab_binding_panels.csv → T09a/b |
| 4 | 96 viruses = 83 H3N2 + 13 H1N1 + 0 B; 5 older H3 also tested as egg/production copies; IVR-238 | Panel composition | neutralization_seqbased.csv → T03a |
| 5 | 94/96 lower; median 0.70 (IQR 0.64–0.77) | Day-0 GMT ratio, mRNA/Flu | neutralization_seqbased.csv → s01 log, F4 |
| 6 | 185 vs. 278 (0.67, 0.39–1.14); MN heterologous 57 vs. 121 (0.47, 0.22–1.00, p=0.05) | Baseline imbalance | neutralization_seqbased.csv, microneutralization.csv → T01 |
| 7 | −0.26 to −0.86 | Slope of log2 fold-rise on log2 baseline (ELISA) | elisa_igg_titers.csv → s11 log |
| 8 | 138 vs. 88; 7/14 vs. 5/15; 1.54 (0.87–2.71) | HAI H1N1 week 4: GMT; SCR; adjusted ratio | hai_titers.csv → T02a/b |
| 9 | 56 vs. 58; 2/14 vs. 3/15; seroprotection 64% vs. 87% | HAI H3N2 week 4 | hai_titers.csv → T02a |
| 10 | B/Vic 57 vs. 52, SCR 0/13 vs. 1/15; B/Yam 88 vs. 99, SCR 0/14 vs. 1/15; fold-rise 1.0–1.3 | HAI B (matched strains) | hai_titers.csv → T02a |
| 11 | −46 to +33 points | Range of 95% CIs for SCR difference | hai_titers.csv → T02b |
| 12 | 325 vs. 588, adjusted 0.68 (0.31–1.51); fold-rise 4.12 vs. 3.03, adjusted 1.17 (0.52–2.62) | MN homologous; MN heterologous | microneutralization.csv → T02c |
| 13 | 9/15 vs. 4/14 | At 1:1280 cap, homologous week 4 | microneutralization.csv → T02c |
| 14 | 1.36 → 1.71; 0.75 → 0.93 | MN fold-rise ratio, heterologous/homologous, with and without 014 & 019 | microneutralization.csv → T17 |
| 15 | MN/HAI 0.03 vs. ≥0.75 | 397-014 inconsistency | hai_titers.csv, microneutralization.csv → s16 log |
| 16 | 244 vs. 482 (0.51, p=0.035); adjusted 0.62 (0.34–1.12) | A/Darwin/6/2021 day 29 | neutralization_seqbased.csv → T03b |
| 17 | 1.17 (0.64–2.11) / 1.04 (0.65–1.67) / 0.98 (0.58–1.66) | Drifted H3: adjusted ratio at day 29 / late / day 181 only | → T03b, T07, T15 |
| 18 | 2.06 (1.23–3.46) / 1.15 (0.75–1.76) / 1.14 (0.68–1.94) | Drifted H1: same three | → T03b, T07, T15 |
| 19 | 2.44 (1.18–5.05); 2.07 (1.26–3.39) | Adjusted ratio vs. Wisconsin/588/2019 (Fluarix-like) and Wisconsin/67/2022 (mRNA-like) | → T03b |
| 20 | 1.63 (0.99–2.69); 1.51 (1.03–2.22) | Older H3, wild-type; egg/production copies | → T03b |
| 21 | Median 1.15 (0.82–1.51), 0/68 significant; Spearman −0.13 (p=0.28) | Per-virus drifted H3 | → T13, s13 log |
| 22 | 12/96 at day 29 (8 H1 + 4 older H3), 0 favouring Fluarix; 2/96 late | Nominal per-virus hits | → s13 log |
| 23 | 27.5% vs. 23.9% (p=0.36); H1 52.6% vs. 12.9% (p=0.006) | Share of drifted viruses with ≥4-fold rise per participant | → T05 |
| 24 | ×0.43 vs. ×0.78; ×0.38 vs. ×0.80 | Late/day-29 decline: drifted H1; Wisconsin/588 | → T07 |
| 25 | 6.1×, 9.4×, 9.5×, 2.7× | Bead fold-rise ratio: Darwin/6, Thailand/8, Hong Kong/68, Puerto Rico/8 | binding_breadth_h1/h3.csv → T04a |
| 26 | 7.2× vs. 0.82×; 11.9× vs. 0.89×; 11.7× vs. 2.5× | Binding vs. neutralisation ratios on matched strains | bead + sequencing-based neutralisation → T04b, F2 |
| 27 | 4.5× (p<0.0001); H1 1.0× (p=0.86) | Excess of binding over neutralisation | → s04 log |
| 28 | 2.67, 3.31, 1.35, 1.38 → 1.51, 2.06, 0.99, 1.06 | ELISA adjusted ratio at week 4 → late (H1, H3, B/Vic, B/Yam) | elisa_igg_titers.csv → T11 |
| 29 | 0.53 vs. 0.93 (late GMT 73 vs. 82); ELISA H1 0.42 vs. 0.74; MN heterologous late 126 vs. 320 | Durability | hai, elisa, MN files → T06c |
| 30 | 0 participants with ≥4-fold rise from day 29 to late | Infection signal | neutralization_seqbased.csv → T06b |
| 31 | 24.7% vs. 4.7% (p=0.001); blocks Spearman 0.57, 13/78 identical | GC peak (block A); duplicate blocks | gc_frequencies.csv → T08a, F5 |
| 32 | Up to 4.7% at weeks 17/26 | Implausible late plasmablast frequency | plasmablast_frequencies.csv → T08a |
| 33 | 73–92% | GC clones overlapping week-1 plasmablast clones (mRNA donors) | pb_gc_clonal_overlap.csv |
| 34 | 51% vs. 10% (p=0.067); 10.5% vs. 0%; minimum p 0.057 | mAb cross-binding to Hong Kong/68; H7 | mab_binding_panels.csv → T09a |
| 35 | 84–86%; 32 vs. 17.5 (p=0.066) | Pre-existing share of serum IgG; vaccine-induced clonotypes | repertoire_clonotype_counts.csv → T10 |
| 36 | 8 swapped (HAI B/Vic) + 2 (sequencing-based neutralisation); 0 with both week-17 and week-26 values | Late-visit label conflicts | all serology files → T20 |
| 37 | 2.0–2.2×; ~48 points | Smallest difference WU397 could detect | → T19 |
| 38 | 1.02 / 0.94 | Residual SD (log2) for the drifted-panel ANCOVA | → s12 log |
| 39 | 178 (210); 79; ~1,260 total; 526 | Study 1 sizes; SCR non-inferiority size | → T18, T12 |
| 40 | 331 / 162 / 845 cases; 31k–87k participant-seasons | Study 3 size | → T12, T18 |
| 41 | 58–82 per arm | Study 2 size | → T18 |
| 42 | ~1.6× | Smallest detectable difference if neutralisation were extended to 75 participants (SE 0.41 × √[(1/38+1/37)/(1/13+1/14)]) | derived from T19 |
| E1 | Fluarix 2022–23: A/Victoria/2570/2019, A/Darwin/9/2021 (egg), B/Austria/1359417/2021, B/Phuket/3073/2013 | *External*: WHO 2022–23 Northern Hemisphere egg-based recommendation / US labelling; check against lot labelling | — |
| E2 | A/Victoria/4897/2022 = WHO 2023–24 egg-based H1; A/Wisconsin/67/2022 = its cell-based counterpart; A/Wisconsin/588/2019 = cell-based counterpart of A/Victoria/2570/2019; A/Darwin/6/2021 = cell-based counterpart of A/Darwin/9/2021 | *External*: WHO recommendations | — |
| E3 | Upper bound of GMT ratio ≤1.5; upper bound of SCR difference ≤10 points | *External*: FDA 2007 non-inferiority criteria for inactivated influenza vaccines | — |
| E4 | High-dose, adjuvanted or recombinant vaccines preferred for ≥65; B/Yamagata removed (trivalent) | *External*: US recommendations from 2022–23 and 2024–25 | — |

**Assumptions and limits:**
- Virus classes in §2.2 are based on isolation year and vaccine-strain relationships, because the package has no antigenic-distance data.
- The bead-array timepoint is not stated. It has no baseline values, so it cannot be adjusted for baseline.
- GC results use block A; block B points the same way.
- All p-values are unadjusted and descriptive.
- The sample-size figures are planning estimates, not a statistical analysis plan.

**Files:**
- `/tmp/outputs/analysis/` — scripts s00–s20; `run_all.sh` reproduces everything.
- `/tmp/outputs/tables/` — T00–T20.
- `/tmp/outputs/figures/` — F1–F5.
- `/tmp/outputs/logs/` — script logs.
