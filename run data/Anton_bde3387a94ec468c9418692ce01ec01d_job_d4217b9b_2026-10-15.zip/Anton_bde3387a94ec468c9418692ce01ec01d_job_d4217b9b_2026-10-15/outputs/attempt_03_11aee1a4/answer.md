**Recommendation:** Don't launch a heterologous-protection efficacy trial on these data — next run a randomised, observer-blind, strain-matched Phase 2 (mRNA-1010 vs licensed egg-based IIV vs recombinant-HA vaccine, adults 18–64 and ≥65) gated on Day-29 and Day-181 neutralisation of a locked panel of wild-type drifted strains, and go to an event-driven relative-efficacy trial with a mismatched-strain endpoint only if it passes.

---

## 1. Bottom line

**What WU397 shows.**
- mRNA-1010 produced more **binding** antibody than Fluarix:
  - ELISA IgG, baseline-adjusted geometric mean ratio (GMR): 2.67 for H1 and 3.31 for H3 (n = 38 vs 37).
  - Bead-array H3 binding breadth: 5.7× higher.
- It also produced larger germinal-centre responses, though in only 6 vs 11 people.

**What WU397 does not show: more *functional* antibody in the subtype where the two vaccines carried the same antigen.** That subtype is H3N2.
- HAI: no arm difference for any of the four antigens. GMRs range from 1.01 to 1.54 and every 95% CI includes 1.
- H3N2 neutralisation, baseline-adjusted:

| Target | GMR (95% CI) |
|---|---|
| 68 wild-type 2022–24 viruses | 1.17 (0.64–2.12) |
| The next-season H3 vaccine strains | 0.92 (0.44–1.92) |
| mRNA-1010's own H3 antigen | 0.62 (0.34–1.12) |

- Among people with the same rise in binding antibody, mRNA-1010 recipients had about 0.6× the H3 neutralising rise of Fluarix recipients (p = 0.075).

**The only functional advantage is confounded and short-lived.**
- H1N1 neutralisation was about 2× higher (GMR 2.06, 1.23–3.46).
- But H1 is the one subtype where the arms received **different** strains:
  - mRNA-1010: A/Victoria/4897/2022.
  - Fluarix 2022–23: an egg-derived A/Victoria/2570/2019-like strain.
- So the H1 advantage cannot be credited to the platform.
- It had faded by day 121/181 (GMR 1.17, 0.78–1.77). mRNA-1010 recipients kept 43% of their peak H1 titre versus 78% for Fluarix.

**Design limits.**
- Allocation was non-randomised (by site) and open-label.
- Every functional readout has only 13–15 people per arm.
- The package contains no demographics and no protection endpoint.
- There are several data-integrity defects (§2.5).

**So the claim is unsupported but not refuted.** The H3 confidence interval still allows up to a ~2-fold advantage. What's missing is a study that:
- separates the platform from strain choice and egg adaptation;
- reads functional breadth against forward-drifted wild-type viruses;
- reads it at both peak and end of season.

Study 1 below does this. It needs about 480 participants and gives a clean go/no-go before a trial of tens of thousands (Study 3).

---

## 2. Reading of the WU397 data package

### 2.1 Design facts that limit every inference

**Allocation.** Assignment was non-randomised and open-label, by enrolment site (`trial_summary.md`). No site, age, sex, prior-vaccination or vaccination-date fields exist in any file, so confounding can only be checked through baseline titres.

**The antigens differ between arms.** "Homologous/heterologous" is defined relative to mRNA-1010's antigens only (`trial_summary.md`). The comparison below uses public WHO recommendations, not anything in the package; please verify against the Fluarix lot labelling.

| Component | mRNA-1010 (WU397) | Fluarix 2022–23 NH |
|---|---|---|
| H1N1 | A/Victoria/4897/2022 (WHO's egg-based strain for the *following* season, 2023–24) | A/Victoria/2570/2019-like, egg-derived (cell-based equivalent: A/Wisconsin/588/2019) |
| H3N2 | A/Darwin/6/2021 (the cell/recombinant candidate) | A/Darwin/9/2021-like, egg-derived (same WHO antigenic target) |
| B/Victoria | B/Austria/1359417/2021 | Same |
| B/Yamagata | B/Phuket/3073/2013 | Same |

What this means for the comparisons:
- **H1** differs in strain generation *and* in egg adaptation, so it is confounded.
- **H3 and B** are antigen-matched. These are the nearest thing in the package to a platform-only comparison.
- The mRNA-1010 **H1** antigen appears in the neutralisation panel only as an egg reassortant, `A/Victoria/4897/2022_IVR-238`.

**Sample sizes** (per `00_participant_audit.txt`):
- ELISA: 38 / 37.
- HAI, microneutralisation (MN) and bead array: 14 / 15.
- Sequencing-based neutralisation: 13 / 14. Participants 397-014 and 397-019 are absent.
- Lymph-node aspiration (FNA): 6 / 11.
- mAbs: from 4 / 3 donors.

### 2.2 The evidence ladder: the advantage shrinks from binding to function to end of season

All ratios are mRNA-1010 : Fluarix with 95% CIs. Serology ratios are ANCOVA-adjusted: log₂(post) ~ arm + log₂(pre). The bead-array file contains only fold-changes, so those rows are a ratio of geometric-mean fold-rises. Source: `analysis/17_evidence_ladder.txt`; the figure is `figures/evidence_ladder_forest.png`.

| Tier | Readout | n | Ratio (95% CI) | Comment |
|---|---|---|---|---|
| Binding | ELISA IgG H1, wk4 | 38/37 | **2.67 (2.01–3.53)** | 22/38 vs 3/37 had a ≥4-fold rise |
| Binding | ELISA IgG H3, wk4 | 38/37 | **3.31 (2.47–4.43)** | 27/38 vs 5/37 had a ≥4-fold rise |
| Binding | ELISA IgG B/Vic, wk4 | 38/37 | 1.35 (1.04–1.75) | |
| Binding | ELISA IgG B/Yam, wk4 | 38/37 | 1.38 (1.11–1.71) | |
| Binding breadth | Bead array, 11 non-vaccine H3 strains | 14/15 | **5.72 (2.92–11.2)** | Largest on *historical* strains, e.g. A/Hong Kong/1/1968: 10.9× vs 1.15× |
| Binding breadth | Bead array, 7 non-vaccine H1 strains | 14/15 | 1.75 (1.00–3.07) | |
| Functional | HAI H1 | 14/15 | 1.54 (0.87–2.71) | Seroconversion 7/14 vs 5/15 |
| Functional | HAI H3 | 14/15 | 1.06 (0.67–1.66) | Seroconversion 2/14 vs 3/15 |
| Functional | HAI B/Vic | 13/15 | 1.05 (0.71–1.56) | Seroconversion 0/13 vs 1/15 |
| Functional | HAI B/Yam | 14/15 | 1.01 (0.73–1.40) | Seroconversion 0/14 vs 1/15 |
| Functional | MN "homologous" | 14/15 | 0.68 (0.31–1.51) | 9/15 Fluarix vs 4/14 mRNA sera hit the 1:1280 ceiling at wk4 |
| Functional | MN "heterologous" | 14/15 | 1.17 (0.52–2.62) | See note below the table |
| Neutralisation, d29 | H1: 6 wild-type 2023 viruses | 13/14 | **2.06 (1.23–3.46)** | Confounded by the H1 strain difference |
| Neutralisation, d29 | H1: A/Wisconsin/67/2022 (mRNA-1010-matched) | 13/14 | 2.07 (1.26–3.39) | |
| Neutralisation, d29 | H1: A/Wisconsin/588/2019 (Fluarix-matched) | 13/14 | 2.44 (1.18–5.05) | mRNA-1010 also led on Fluarix's own H1; see §2.3(b) |
| Neutralisation, d29 | **H3: 68 wild-type 2022–24 viruses** | 13/14 | **1.17 (0.64–2.12)** | None of the 68 reaches even nominal p < 0.05 (53 of 68 point estimates > 1) |
| Neutralisation, d29 | H3: next-season strains A/Thailand/8/2022 + A/Massachusetts/18/2022 | 13/14 | 0.92 (0.44–1.92) | |
| Neutralisation, d29 | H3: A/Darwin/6/2021 (mRNA-1010's own antigen) | 13/14 | 0.62 (0.34–1.12) | |
| Neutralisation, d29 | H3: 8 historical viruses | 13/14 | 1.63 (0.99–2.68) | Back-boosting of old responses, not forward breadth |
| End of season | H1 contemporary, d121/d181 | 13/14 | 1.17 (0.78–1.77) | Adjusted for late-visit day: 1.15 (0.74–1.78) |
| End of season | H3 contemporary, d121/d181 | 13/14 | 1.05 (0.65–1.68) | Adjusted for late-visit day: 1.01 (0.63–1.63) |

Note on the MN "heterologous" row: the unadjusted geometric-mean fold-rise (GMFR) is 4.12 vs 3.03. That gap is a baseline artefact, because baseline titres were 57 vs 121 (ratio 0.47, p = 0.05).

### 2.3 Four interpretive points

**(a) Binding is not function for H3.** This is the central finding for a breadth claim.
- Among the 27 participants with neutralisation data, mRNA-1010's advantage over Fluarix was:
  - 6.5× in bead-array H3 binding rise;
  - 3.6× in ELISA H3 rise;
  - 1.29× in neutralisation of contemporary H3;
  - 0.93× in HAI H3.
- Binding predicted neutralisation well for Fluarix recipients (Spearman ρ = 0.73) but poorly for mRNA-1010 recipients (ρ = 0.31).
- After adjusting for the ELISA H3 rise, the arm effect on H3 neutralisation was −0.75 log₂, i.e. ×0.60 (p = 0.075).
- So most of the extra H3 binding antibody from mRNA-1010 does not neutralise 2022–24 viruses. It may still have Fc-mediated activity, but nothing in the package measures that.
- HAI H3 did not track H3 neutralisation (ρ = 0.12, p = 0.54), whereas HAI H1 did (ρ = 0.59, p = 0.001). For H3N2, HAI is therefore a poor breadth readout.

**(b) The H1 signal is real in these data but cannot be attributed to the platform.** Three explanations are entangled:
- mRNA-1010's H1 is a newer strain, antigenically closer to the 2023 H1 viruses.
- Fluarix's H1 is egg-adapted.
- Allocation was by site.

mRNA-1010 also led on the Fluarix-matched A/Wisconsin/588/2019 (2.44×). That fits platform, dose, egg adaptation or site effects equally well. Only a strain-matched randomised design with a non-egg comparator can separate them.

**(c) Durability is the weak point for a seasonal protection claim.**
- Share of peak titre kept at the late visit:

| Readout | mRNA-1010 | Fluarix |
|---|---|---|
| ELISA (late ÷ wk4), four antigens | 0.42–0.55 | 0.68–0.76 |
| H1 neutralisation (late ÷ d29) | 43% | 78% |

- By d121/d181, no functional readout favours mRNA-1010.

**(d) The mechanistic data add support for immunogenicity, not for the claim.** They suggest mRNA-1010 is immunologically distinct, but none measures protection, and some point the other way.
- **Germinal centres:** HA-specific IgG GC B cells at wk2 had a median of 24.2% vs 2.3% (p = 0.037, 6 vs 11 people).
- **Repertoire:** about 84–86% of post-vaccination serum IgG came from *pre-existing* clonotypes in both arms (83.9% vs 86.2%, p = 0.72). mRNA-1010 added more new clonotypes (median 32 vs 17.5, p = 0.066; 8 per arm). Breadth will therefore depend heavily on each person's prior exposure history.
- **mAbs:** H3 mAbs from mRNA-1010 donors bound historical and H7 HAs more often, but:
  - the Fluarix side has only 34 group-II mAbs from 3 donors, 25 of them from one donor;
  - the donor-level comparison is p ≈ 0.1;
  - the mAbs were tested for binding only.
- **IgM:** IgM responses were more frequent with Fluarix (H3: 12/15 vs 4/14, p = 0.013).

### 2.4 Analysis traps that would produce a false "breadth" result

1. **Pseudo-replication.** Treating the 2,557 virus × serum pairs as independent gives p = 6×10⁻²⁶ for "broader". With the participant as the unit, the all-virus GMR is 1.27 (0.81–1.99), p = 0.28 (`14_naive_vs_correct.txt`). Likewise, "70 of 74 contemporary viruses favour mRNA-1010" is 13 vs 14 people, not 74 tests.
2. **Pooling across subtypes and historical strains.** Panel-wide averages borrow the confounded H1 signal and the H3 back-boost.
3. **Unadjusted fold-rise with baseline imbalance and ceilings.** See the MN rows in the table above.
4. **Including reassortant or egg-adapted viruses as "heterologous".** Six panel viruses are egg or reassortant variants.

### 2.5 Data-integrity issues to resolve before any of this is reused

1. **Late-visit labels.** Week-17 vs week-26 labels are inconsistent across assays for 9 participants. In the HAI file, the B/Vic late visit is flipped relative to the other three antigens for 8 participants: 007, 008, 009, 010, 016, 018, 021, 023 (`06_visit_label_audit.txt`). Pooling into "wk17/26" hides this.
2. **GC frequencies file.** It has **two unlabelled rows per participant per timepoint** (156 = 2 × 78). It also contains "wk0", which is not in the FNA schedule, while the scheduled wk1 and wk4 are missing.
3. **Plasmablast file.** It reports wk2 and wk8 values, but no blood was drawn then. 11 of its 28 participants had no FNA, so the source compartment is unresolved.
4. **IgM.** The cohort table says 38/37, but the file holds 14/15. No timepoint is given. Fold-change values are quantised in steps of 1.4815, consistent with baseline values at the limit of detection.
5. **Bead-array timepoint not stated.** It is most consistent with wk4: ρ with ELISA wk4 fold-change is 0.90, versus 0.84 with the late visit.
6. **Virus identities not stated for HAI and MN.** Both MN panels correlate only with H3N2 neutralisation. The "homologous" panel correlates best with egg-type A/Darwin/9/2021 (ρ = 0.68), which would favour Fluarix.
7. **Participant 397-014 (mRNA-1010) is discordant.** MN titres sit at the 10–15 floor, while HAI H1 rose from 57 to 320 and ELISA H1 rose 35.9×. This participant is absent from the neutralisation file.
8. **Participant ID formats vary.** Five formats are used: `1`, `001`, `397-001`, `397-06`, `06`. The IgM file also mixes `20` with `020`.
9. **Minor value problems.** One off-grid HAI value (288). One malformed virus name (`A/SOUTHAFRICA/R07876/202023`). 171 neutralisation titres are left-censored and 70 right-censored.
10. **mAb panels have no real negative control.** The SARS-CoV-2 RBD "control" equals exactly 1.0 for all 721 rows; it is the normaliser. The binding calls depend on threshold: H5 binding among H1 mAbs is 4.9% (mRNA-1010) vs 4.1% (Fluarix) at ≥10×, but 18.6% vs 40.5% at ≥3×.
11. **One possible intercurrent infection:** Fluarix participant 58, with a 2.8× rise in ELISA H1 between wk4 and wk26. There was no infection surveillance.

---

## 3. Recommended studies

### Study 1 — the protocol to take to committee now: randomised, observer-blind, strain-matched Phase 2 breadth study

**Claim component it supports.** Whether mRNA-1010 produces more *functional* neutralising breadth against forward-drifted wild-type strains than licensed vaccines when the antigens are matched, and whether that lasts to end of season. It also tests whether any advantage is due to the platform rather than egg adaptation, neuraminidase (NA) content or HA dose.

**Conditions**

| Item | Specification |
|---|---|
| Season and composition | Next available Northern Hemisphere season, trivalent (A/H1N1pdm09, A/H3N2, B/Victoria), per that season's WHO recommendation. No B/Yamagata. mRNA-1010 encodes the WHO cell/recombinant HA sequences, the same ones in the RIV arm. The egg-based comparator carries the WHO-equivalent egg strains. Composition is written into the protocol. |
| Randomisation | 1:1:1, central. Stratified by site, age band and prior-season influenza vaccination (yes/no). Observer-blind: participants, assessors and laboratories blinded, administrators unblinded. |
| Arm A | mRNA-1010 at the intended Phase 3 dose, single IM dose on Day 0. |
| Arm B: licensed egg-based IIV (standard of care) | Ages 18–64: standard-dose Fluarix. Ages ≥65: high-dose or adjuvanted IIV. |
| Arm C: recombinant HA vaccine (RIV) | HA-only, non-egg, sequence-identical to Arm A. This arm isolates the platform from egg adaptation, NA content and HA quantity. |
| Population | Cohort 1: ages 18–64 (stratified 18–49 / 50–64). Cohort 2: ages ≥65. Exclusions: influenza vaccine or lab-confirmed influenza within 6 months; immunosuppression. Recorded: birth year, 5-season vaccination history, vaccination date, comorbidities. |
| Size | 80 randomised per arm per cohort, 480 in total, giving ≥65 evaluable per arm per cohort. |
| Visits (fixed windows, no pooling) | Day 0 (pre-dose), Day 29 (±3), Day 91 (±7), Day 181 (±14), Day 365 (±14). |
| Intercurrent infection | Active ILI surveillance with RT-PCR, plus serological evidence of infection against non-vaccine antigens. Samples taken after an infection are removed from the per-protocol set. |

**Sample-size basis.** The residual SD of the participant-level H3 panel-mean log₂ titre in WU397 was 1.02.
- 65 evaluable per arm gives 90% power to detect a GMR of 1.5 (two-sided α = 0.05).
- The mRNA-1010 vs RIV comparison pooled across cohorts (~130 per arm) detects a GMR of about 1.33.
- If the true H3 effect is the 1.17 point estimate seen in WU397, 453 per arm would be needed. An effect that small is not worth a breadth claim, which is why the gate is set at 1.5.

**Readouts**

| # | What is measured | In whom | Against what | When | Role |
|---|---|---|---|---|---|
| P1 | Neutralising antibody titre, summarised per participant as the mean log titre across the **Tier-2 H3N2 panel** | Per-protocol immunogenicity set, both cohorts | Tier-2 panel (spec below). Comparisons: mRNA-1010 vs RIV and mRNA-1010 vs licensed egg-based IIV | Day 29 | **Primary.** Baseline-adjusted GMR. Both comparisons must succeed (intersection–union), so no alpha split is needed. |
| P2 | Same as P1 | Same | Same | **Day 181** | **Co-primary (durability).** |
| S1 | Same metric | Same | Tier-2 H1N1 and B/Victoria panels | Day 29, Day 181 | Key secondary, tested hierarchically after P1–P2. |
| S2 | Breadth-responder rate: ≥4-fold rise against ≥50% of Tier-2 viruses | Same | Tier-2 panels, each subtype | Day 29 | Key secondary. |
| S3 | HAI GMT ratio and seroconversion difference (regulatory backbone) | Same | Each arm's vaccine strains | Day 29 | Non-inferiority-style estimates with margins of 1.5 (GMT ratio) and 10 points (seroconversion), used to size Phase 3. |
| S4 | Neutralising titre | Same | Tier 1: each arm's own vaccine strains, cell *and* egg versions | Day 29, Day 181 | Checks that "homologous" performance is measured symmetrically for both arms. |
| S5 | Neuraminidase-inhibiting antibody titre | All participants | Vaccine-season N1 and N2, plus one drifted N2 | Day 0, 29, 181 | Fluarix (split virion) contains NA and RIV is HA-only. The package does not say whether mRNA-1010 encodes NA. Needed to interpret any relative protection result. |
| S6 | Neutralising titre | Same | Tier-2 panels | Day 91, Day 365 | Decay curve. |
| S7 | Reactogenicity and safety | All vaccinated | — | Days 1–7 solicited, 28 days unsolicited, serious/special-interest/medically attended AEs to Day 365 | Safety (not in the WU397 package). |
| E1 | Binding to HA stalk and to drifted/historical HAs; neutralising ÷ binding ratio | Randomised subset (~40 per arm) | Tier-2 and Tier-3 HAs | Day 0, 29 | Tests the binding–function gap seen in WU397. |
| E2 | Fc-effector (ADCC-type) activity | Same subset | Drifted H3 HA | Day 0, 29, 181 | Would any non-neutralising breadth be functionally active? |
| E3 | Heterosubtypic binding | Same subset | H5 and H7 HA | Day 0, 29 | Exploratory only; no claim. |
| E4 | Share of serum IgG from new vs pre-existing clonotypes | Same subset | Vaccine HAs | Day 0, 29, 181 | Imprinting context. |
| E5 | Neutralising titre | Per-protocol set | Tier-3 historical strains | Day 29 | Reported separately as back-boosting; never pooled into breadth. |

**Deliberately left out of Study 1.** Lymph-node aspiration, germinal-centre measures and mAb isolation are mechanistic and cannot support the claim. If kept, participants should be randomised into the sub-study with balanced arms (WU397 had 6 vs 11), and every measurement should be labelled with the antigen it used.

**Optional Year-2 extension.** At Day 365, revaccinate each arm with the next season's composition and repeat P1/P2. This tests whether any breadth advantage survives annual use, which is how the product would actually be given.

**Heterologous panel specification.** An independent virology committee, blinded to results, locks the panel before any Day-29 sample is unblinded.

- **Tier 1 (reference, not heterologous):** each arm's vaccine strains, cell and egg versions.
- **Tier 2 (primary heterologous):**
  - Wild-type viruses circulating in the vaccination season and up to 12 months after, covering each antigenically distinct co-circulating clade.
  - Each must be antigenically distinct from *every* arm's vaccine strain, for example ≥8-fold lower titre with reference ferret antiserum or a clade with changes at major antigenic sites.
  - The set must be balanced so its antigenic distance from each arm's strains is equal.
  - Minimum panel size: about 12 H3N2, 6 H1N1 and 4 B/Victoria viruses.
  - A pre-specified "forward extension" of viruses from the following season is tested on banked Day 0/29/181 sera as a secondary analysis.
- **Tier 3:** historical strains, reported separately.
- **Egg- or cell-adapted reassortants** are excluded from Tier 2.
- Titre ranges must not be capped. WU397's 1:1280 ceiling censored 9/15 Fluarix sera.

**Analysis principles.**
- The participant is the unit of analysis.
- ANCOVA on the Day 29 or Day 181 panel-mean, adjusting for the Day 0 panel-mean, age band and prior vaccination.
- Censored titres are handled with a pre-specified censored-data model.
- Sensitivity analysis: a mixed model with participant and virus random effects, with antigenic distance as a covariate.
- Pre-specified subgroups: age band, prior vaccination, baseline-titre tertile, birth cohort.

**Decision gate.** Thresholds are design choices.

| Phase 2 result | Meaning | Next step |
|---|---|---|
| P1 met vs **both** RIV and IIV (LB > 1.0 and point ≥ 1.5 for H3N2), **and** P2 met vs IIV (LB > 1.0) | Functional breadth that is attributable to the platform and lasts through the season | **GO:** Study 3, with Study 2 in parallel. |
| P1 met vs IIV but not vs RIV | Advantage comes from non-egg HA sequence or dose, not mRNA | A claim is possible only against egg-based IIV. Reconsider the Phase 3 comparator; committee decision. |
| P1 met, P2 not met | Peak-only advantage | No seasonal heterologous claim. Work on durability first. |
| P1 not met, but E1/E2 show stalk or Fc activity | Any benefit would be non-neutralising | Serology cannot support a claim. Only Study 2 or 3 can test it. |
| Nothing met | No breadth advantage | Drop the heterologous claim and pursue a standard seasonal claim (HAI non-inferiority plus relative efficacy). |

### Study 2 (conditional on GO; de-risking) — heterologous-challenge human challenge study

- **Conditions:** randomised and double-blind, three arms: mRNA-1010, RIV (or licensed IIV) and placebo. The challenge is given around Day 29–42 with a characterised challenge virus of the same subtype (H3N2 preferred) that is antigenically drifted from the vaccine H3 by ≥8-fold. The challenge strain must not be in the vaccine.
- **In whom:** healthy adults aged 18–50 with low pre-existing titres against the challenge strain.
- **Readouts:**
  - Primary: laboratory-confirmed infection (RT-PCR-confirmed shedding), mRNA-1010 vs placebo.
  - Key secondary: symptomatic laboratory-confirmed infection; viral-load and symptom-score AUC.
  - mRNA-1010 vs comparator: estimation only.
  - Immune readouts before challenge: neutralising titre against the challenge strain, NA-inhibiting titre, Fc activity and nasal IgA, to identify correlates of heterologous protection.
- **Size:** about 50–60 evaluable per arm. A 50% reduction versus placebo needs 42–58 per arm for 80% power, assuming 50–60% of placebo recipients are infected. A powered head-to-head comparison with the comparator would need 82–152 per arm.
- **Limits:** young adults only, and limited strain choice. This study supports mechanism and correlates but cannot support a label claim by itself.

### Study 3 (conditional on GO) — Phase 3 relative-efficacy trial with a mismatched-strain claim endpoint

**Conditions**
- Randomised 1:1, observer-blind and active-controlled, against the age-appropriate licensed comparator:
  - ages 50–64: standard-dose IIV or RIV;
  - ages ≥65: high-dose IIV, adjuvanted IIV or RIV.
- Same-season, strain-matched trivalent composition in both arms.
- Event-driven, over at least 2 seasons and both hemispheres.

**In whom:** adults aged ≥50, stratified 50–64 / ≥65 and by prior vaccination and region, including people with stable chronic conditions.

**Endpoints, tested hierarchically**
1. RT-PCR-confirmed, protocol-defined ILI caused by any influenza A or B strain, from ≥14 days after vaccination to end of season. Non-inferiority: relative vaccine efficacy (rVE) lower bound > −10%.
2. The same endpoint for superiority: rVE lower bound > 0.
3. **The claim endpoint:** RT-PCR-confirmed ILI caused by **antigenically mismatched** strains, for superiority (rVE lower bound > 0). Also analysed for mismatched H3N2 alone.
   - Every case isolate is characterised centrally, blinded to arm, by HA/NA sequencing and antigenic testing against the vaccine strains.
   - The definition of "mismatched" is locked before unblinding: for example, ≥8-fold reduced titre with reference antiserum, or membership of pre-designated antigenically distinct clades.

Other secondary endpoints: medically attended influenza, influenza-associated hospitalisation, and results by subtype and by season.

**Correlates sub-study (case–cohort)**
- Population: a random subcohort of about 5% of enrolment, plus all cases.
- Readouts on Day 0 and Day 29 sera:
  - neutralising titres against the vaccine strains and each season's circulating clades;
  - HAI and NA-inhibiting titres;
  - Fc activity.
- Purpose: identify which readout predicts protection against mismatched strains. No such correlate exists today, and one is needed for future strain-update bridging.
- If standard immunogenicity claims are also wanted, an HAI non-inferiority subset of about 530–830 per arm is needed, set by the seroconversion margin across 6 co-primary tests.

**Size (illustrative; attack rates are assumptions, not data)**
- Events needed for all-strain superiority at 90% power: 844 for rVE 20%, 508 for 25%, 330 for 30%. For non-inferiority: 414 (rVE 20%) and 287 (rVE 25%).
- Example: with a 2% comparator attack rate and rVE 25%, about 29,000 participants are needed for the all-strain endpoint.
- If mismatched strains are 40% of cases, the mismatched endpoint needs about 73,000. Hence multi-season accrual and the need for the Phase 2 gate first.

### Before the committee: work on the existing package (not a new trial)

1. **Resolve the §2.5 queries:**
   - late-visit labels;
   - the two GC blocks;
   - the plasmablast file's timepoints and compartment;
   - which viruses were used for HAI and MN;
   - participant 397-014;
   - demographics, site, vaccination dates and prior vaccination;
   - the Fluarix lot composition.
2. **Optional re-testing of banked WU397 sera** (cheap, and informs Study 1 endpoints; results are hypothesis-generating because allocation was non-randomised):
   - NA-inhibiting titres against N1 and N2;
   - Fc-effector activity against drifted H3;
   - neutralisation of wild-type A/Victoria/4897/2022 and A/Victoria/2570/2019;
   - neutralisation of drifted B/Victoria viruses (no B viruses were tested).

---

## 4. Numbers ledger: every number relied on, with source

All `analysis/` paths are under `/tmp/outputs/`. Input files are in `/tmp/world/filesystem/`.

| Number(s) | What | Source data | Output |
|---|---|---|---|
| 2022–23 NH season; non-randomised by site; open-label; day 0/7/29/121/181 blood; FNA wk1/2/4/8/17/26 | Design | trial_summary.md | — |
| 38/37, 14/15, 14/15, 13/14, 6/11 | Cohort sizes (summary table) | trial_summary.md | — |
| 75 (38/37); 29 (14/15); 27 (13/14); 17 (6/11); 7 donors (4/3) | Cohort sizes observed in the files | all files | 00_participant_audit.txt |
| 14/15 IgM vs 38/37 stated | IgM cohort discrepancy | igm_fold_change.csv; trial_summary.md | 00_participant_audit.txt |
| 11 of 28 | Plasmablast-file participants without FNA | plasmablast_frequencies.csv; gc_frequencies.csv | 00_participant_audit.txt |
| HAI GMT wk4: H1 137.9 vs 87.8; H3 56.6 vs 57.9; B/Vic 56.6 vs 51.6; B/Yam 88.3 vs 98.5 | HAI magnitude | hai_titers.csv | 01_hai.txt |
| HAI GMFR wk4: 2.76 vs 2.24; 1.72 vs 1.66; 1.08 vs 1.05; 1.35 vs 1.29 | HAI fold-rise | hai_titers.csv | 01_hai.txt |
| Seroconversion 7/14 vs 5/15; 2/14 vs 3/15; 0/13 vs 1/15; 0/14 vs 1/15 | HAI seroconversion (≥4-fold rise and ≥1:40) | hai_titers.csv | 01_hai.txt |
| HAI GMR 1.54 (0.87–2.71); 1.06 (0.67–1.66); 1.05 (0.71–1.56); 1.01 (0.73–1.40) | HAI ANCOVA | hai_titers.csv | 17_evidence_ladder.txt |
| mRNA-1010 seroconversion lower bound 4.0% (H3), 0.0% (B); Fluarix/mRNA GMT ratio for H3: 1.02 (0.49–2.16) | Regulatory-style illustration (invalid here: non-randomised) | hai_titers.csv | 16_hai_regulatory_style.txt |
| 288; 8 participants (007, 008, 009, 010, 016, 018, 021, 023) | Off-grid HAI value; flipped B/Vic late-visit labels | hai_titers.csv | 01_hai.txt; 06_visit_label_audit.txt |
| 9 participants | Late-visit labels inconsistent across assays | hai, MN, ELISA, seq-neut files | 06_visit_label_audit.txt |
| ELISA GMFR wk4: H1 5.07 vs 1.90; H3 7.60 vs 1.99; B/Vic 3.16 vs 2.30; B/Yam 2.67 vs 2.03 | ELISA fold-rise | elisa_igg_titers.csv | 02_elisa.txt |
| ELISA GMR 2.67 (2.01–3.53); 3.31 (2.47–4.43); 1.35 (1.04–1.75); 1.38 (1.11–1.71) | ELISA ANCOVA | elisa_igg_titers.csv | 17_evidence_ladder.txt |
| ≥4-fold: 22/38 vs 3/37 (H1); 27/38 vs 5/37 (H3) | ELISA responders | elisa_igg_titers.csv | 02_elisa.txt |
| Late ÷ wk4 retention: 0.42–0.55 vs 0.68–0.76 | ELISA durability | elisa_igg_titers.csv | 02_elisa.txt |
| MN baseline GMT 57 vs 121 (ratio 0.47, p = 0.05); GMFR 4.12 vs 3.03; GMR 1.17 (0.52–2.62) | MN heterologous | microneutralization.csv | 03_mn.txt; 17_evidence_ladder.txt |
| MN homologous GMR 0.68 (0.31–1.51); at ceiling wk4 9/15 vs 4/14 | MN homologous | microneutralization.csv | 03_mn.txt |
| MN vs H3N2 neutralisation mean ρ 0.33–0.37 at wk4 (H1N1 means −0.20 and −0.12); homologous MN best with A/Darwin/9/2021, ρ = 0.68 | MN virus-identity inference | microneutralization.csv; neutralization_seqbased.csv | 19_inference_checks.txt |
| 397-014: MN 10–15; HAI H1 57→320; ELISA H1 35.9× | Discordant participant | MN, HAI, ELISA files | 03_mn.txt; 01_hai.txt; 02_elisa.txt |
| Bead H3 5.72 (2.92–11.22); H1 1.75 (1.00–3.07); GMFR 9.66 vs 1.69 and 2.89 vs 1.65 | Bead-array breadth | binding_breadth_h3.csv / _h1.csv | 04_bead_breadth.txt; 17_evidence_ladder.txt |
| A/Hong Kong/1/1968 10.9× vs 1.15×; A/Darwin/6/2021 26.2× vs 4.3×; A/Thailand/8/2022 31.9× vs 3.4× | Bead-array, per strain | binding_breadth_h3.csv | 04_bead_breadth.txt |
| ρ = 0.90 (wk4) vs 0.84 (late) for H3; 0.82 vs 0.70 for H1 | Bead timepoint inference | bead files + elisa_igg_titers.csv | 19_inference_checks.txt |
| 7,719 titres; 81 sera; 96 viruses (13 H1N1, 83 H3N2, 0 B); 6 reassortant/egg; 171 left- / 70 right-censored | Neutralisation panel facts | neutralization_seqbased.csv | 05_seqneut_prep.txt; 18_chim_and_misc.txt |
| GMR d29: H1 contemporary 2.06 (1.23–3.46); Wisconsin/67 2.07 (1.26–3.39); Wisconsin/588 2.44 (1.18–5.05) | H1 neutralisation | neutralization_seqbased.csv | 17_evidence_ladder.txt |
| GMR d29: H3 contemporary 1.17 (0.64–2.12); Thailand+Massachusetts 0.92 (0.44–1.92); Darwin/6 0.62 (0.34–1.12); historical 1.63 (0.99–2.68) | H3 neutralisation | neutralization_seqbased.csv | 17_evidence_ladder.txt |
| GMFR d29: H1 contemporary 4.07 vs 1.95; H3 contemporary 2.80 vs 2.17 | Neutralisation fold-rise | neutralization_seqbased.csv | 07_seqneut_breadth.txt |
| 0 of 96 viruses with q < 0.05; H3 contemporary: 0 of 68 nominal p < 0.05, 53 of 68 GMR > 1; H1 contemporary: 6 of 6 nominal p < 0.05; 70 of 74 contemporary viruses with fold-rise ratio > 1 | Per-virus results | neutralization_seqbased.csv | 07_seqneut_breadth.txt |
| Late GMR: H1 1.17 (0.78–1.77) [1.15 adjusted for visit day]; H3 1.05 (0.65–1.68) [1.01] | End of season | neutralization_seqbased.csv | 17_evidence_ladder.txt; 08_seqneut_durability.txt |
| Retained late ÷ d29: H1 43% vs 78%; H3 64% vs 68% | Neutralisation durability | neutralization_seqbased.csv | 08_seqneut_durability.txt |
| p = 6.3×10⁻²⁶ (pairs) vs GMR 1.27 (0.81–1.99), p = 0.28 (participants) | Pseudo-replication | neutralization_seqbased.csv | 14_naive_vs_correct.txt |
| Fold advantage 6.50× (bead H3), 3.63× (ELISA H3), 1.29× (neut H3), 0.93× (HAI H3) | Binding → function | ELISA, bead, HAI, seq-neut files | 13_binding_vs_function.txt |
| ρ 0.31 vs 0.73; arm effect −0.75 log₂ (×0.60, p = 0.075); ρ(HAI H3, neut) 0.12 (p = 0.54); ρ(HAI H1, neut) 0.59 (p = 0.001) | Binding vs function | same | 13_binding_vs_function.txt |
| 695 mAbs (589/106); donors 200/162/53/174 vs 84/11/11; group-II Fluarix 34 (25/2/7); RBD control = 1.0 in all 721 rows | mAb panel facts | mab_binding_panels.csv | 09_mab_panels.txt; 18_chim_and_misc.txt |
| Group II at ≥10×: binds all historical H3 40.4% vs 11.8%; H7 9.5% vs 0% (donor-level p = 0.10). H5 (group I): 4.9% vs 4.1% at ≥10×; 18.6% vs 40.5% at ≥3× | mAb cross-reactivity | mab_binding_panels.csv | 09_mab_panels.txt |
| GC wk2 median 24.2% vs 2.3% (p = 0.037); wk26 18.9% vs 1.6% (p = 0.34); 156 = 2×78 rows | Germinal centres | gc_frequencies.csv | 10_cellular_repertoire.txt |
| Pre-existing abundance 83.9% vs 86.2% (p = 0.72); new clonotypes median 32 vs 17.5 (p = 0.066); n = 8/arm | Repertoire | repertoire_clonotype_counts.csv | 10_cellular_repertoire.txt |
| IgM H3 responders 4/14 vs 12/15 (p = 0.013); B/Vic 3/14 vs 9/15; B/Yam 5/14 vs 10/15; step 1.4815 | IgM | igm_fold_change.csv | 11_igm.txt; 18_chim_and_misc.txt |
| Fluarix participant 58: 2.76× ELISA H1 rise wk4→wk26 | Possible intercurrent infection | elisa_igg_titers.csv | 15_intercurrent_infection_screen.txt |
| Residual SD 1.02 (H3 panel), 0.94 (H1 panel); HAI raw SD 1.06/1.36/1.01/0.85 | Variance inputs | seq-neut; HAI | 12_sample_size.txt |
| n per arm: 65 (GMR 1.5), 22 (GMR 2.0), 130 (GMR 1.33), 453 (GMR 1.17); randomise 77–82 | Phase 2 sizing | derived | 12_sample_size.txt |
| Seroconversion NI: 465–526 per arm (1 test); 531–829 per arm (6 co-primary tests) | HAI non-inferiority sizing | derived | 12_sample_size.txt |
| Events: 844 / 508 / 330 (superiority, rVE 20/25/30%); 414 / 287 (NI); ~29,000 / ~73,000 participants (2% attack rate, rVE 25%) | Phase 3 sizing | derived + assumptions | 12_sample_size.txt |
| Human challenge: 42–58 per arm vs placebo; 82–152 per arm head-to-head | Study 2 sizing | derived + assumptions | 18_chim_and_misc.txt |

## 5. External facts and assumptions (not in the package; verify)

**External facts.** These come from my knowledge of WHO, FDA and ACIP sources. I had no internet access to re-check them.

- **Strain history.** Details appear in the §2.1 table. In brief:
  - 2022–23 NH: egg-based A/Victoria/2570/2019 (H1) and A/Darwin/9/2021 (H3); cell-based A/Wisconsin/588/2019 and A/Darwin/6/2021.
  - 2023–24 NH: egg-based A/Victoria/4897/2022 (H1); cell-based A/Wisconsin/67/2022.
  - 2024–25: H3 A/Thailand/8/2022 (egg) and A/Massachusetts/18/2022 (cell).
  - 2025–26: H3 A/Croatia/10136RV/2023 (egg) and A/District of Columbia/27/2023 (cell).
- **B/Yamagata** has not been detected since 2020, and trivalent vaccines have been recommended since 2024–25.
- **CBER 2007 immunogenicity criteria:**
  - Seroconversion lower bound ≥40% (<65 years) or ≥30% (≥65 years).
  - Seroprotection lower bound ≥70% or ≥60%.
  - Non-inferiority: GMT-ratio upper bound ≤1.5; seroconversion-difference upper bound ≤10 points.
- **ACIP** prefers high-dose IIV, RIV or adjuvanted IIV for people aged ≥65.

**Design choices and assumptions.**
- The gate thresholds (GMR ≥1.5 with lower bound >1.0) and the 15–20% non-evaluable allowance are my design choices.
- Attack rates (1–3%), the 40% mismatched share, rVE targets and human-challenge infection rates are planning assumptions, not data.
- The bead-array timepoint and the HAI/MN virus identities are inferred from the data, not documented. The IgM timepoint is unknown.

## 6. Files

- **`analysis/run_all.sh`:** re-runs scripts 00–19 in the `core` environment, each writing a matching `.txt`.
- **Derived tables:** `evidence_ladder.csv`, `seqneut_per_virus.csv`, `seqneut_category_comparisons.csv`, `seqneut_virus_annotation.csv`, `hai_summary.csv`, `elisa_summary.csv`, `mn_summary.csv`, `bead_breadth_per_strain.csv`, `binding_vs_function_correlations.csv`, `late_visit_label_audit.csv`, `participant_file_membership_matrix.csv`, `sample_size_inputs.csv`, `mn_panel_identity_correlations.csv`.
- **Figure:** `figures/evidence_ladder_forest.png`.
