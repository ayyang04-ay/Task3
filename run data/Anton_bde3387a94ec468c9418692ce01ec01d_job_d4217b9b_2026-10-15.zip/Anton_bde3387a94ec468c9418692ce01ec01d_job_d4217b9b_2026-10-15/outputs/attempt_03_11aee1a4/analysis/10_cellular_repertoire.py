"""GC B cell frequencies (two unlabeled blocks per participant-timepoint), lymph-node/blood plasmablasts,
PB-GC clonal overlap, serum IgG clonotype repertoire and CDR-H3 diversity. Descriptive + simple tests."""
import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width',250); pd.set_option('display.max_columns',60); pd.set_option('display.max_rows',500)
D='/tmp/world/filesystem/'
g=pd.read_csv(D+'gc_frequencies.csv',dtype={'participant':str})
g['block']=g.groupby(['timepoint','arm','participant']).cumcount()+1
print('== GC file: rows per (timepoint,arm,participant):',g.groupby(['timepoint','arm','participant']).size().value_counts().to_dict())
print('   block 1 rows:',(g.block==1).sum(),' block 2 rows:',(g.block==2).sum(),' -> two unlabeled measurements per sample (probe/antigen not identified)')
order=['wk0','wk2','wk8','wk17','wk26']
for b in [1,2]:
    p=g[g.block==b].pivot_table(index=['arm','participant'],columns='timepoint',values='pct_ha_specific_igg_gc')[order]
    print(f'\n== GC block {b}: median % by arm/timepoint'); print(p.groupby(level='arm').median().round(2))
    print('   n:'); print(p.groupby(level='arm').count())
    for t in ['wk2','wk8','wk17','wk26']:
        a=p.loc['mRNA-1010',t].dropna(); f=p.loc['Fluarix',t].dropna()
        print(f'   {t}: mRNA median {a.median():.2f} (n={len(a)}) vs Flu {f.median():.2f} (n={len(f)}); MWU p={stats.mannwhitneyu(a,f).pvalue:.3f}')
print('\n== GC file contains wk0, but trial_summary lists FNA at weeks 1,2,4,8,17,26 (no wk0; no wk1/wk4 in file)')
pb=pd.read_csv(D+'plasmablast_frequencies.csv',dtype={'participant':str})
p=pb.pivot_table(index=['arm','participant'],columns='timepoint',values='pct_plasmablast')[order]
print('\n== Plasmablast %: median by arm/timepoint'); print(p.groupby(level='arm').median().round(4)); print(p.groupby(level='arm').count())
for t in ['wk2','wk8','wk17','wk26']:
    a=p.loc['mRNA-1010',t].dropna(); f=p.loc['Fluarix',t].dropna()
    print(f'   {t}: mRNA median {a.median():.3f} vs Flu {f.median():.3f}; MWU p={stats.mannwhitneyu(a,f).pvalue:.3f}')
print('   NOTE: blood was drawn d0,d7,d29,d121,d181 and FNA at wk1,2,4,8,17,26 in 6 vs 11 participants; this file has wk0/2/8/17/26 for 13 vs 15 participants, 11 of whom had no FNA -> timepoint/compartment provenance unresolved.')
o=pd.read_csv(D+'pb_gc_clonal_overlap.csv')
o['arm']=o.Participant.map({'397-06':'mRNA-1010','397-17':'mRNA-1010','397-28':'mRNA-1010','397-29':'mRNA-1010','397-05':'Fluarix','397-09':'Fluarix','397-22':'Fluarix'})
o['pct_gc_clones_overlapping']=o.iloc[:,9].str.rstrip('%').astype(float)
o['pct_pb_clones_overlapping']=o.iloc[:,8].str.rstrip('%').astype(float)
print('\n== PB-GC clonal overlap'); print(o[['Participant','arm','Number of GC B cell clones','Number of wk1 PB clones','pct_pb_clones_overlapping','pct_gc_clones_overlapping']].to_string(index=False))
# recompute percentages
o['chk_pb']=100*o.iloc[:,5]/o.iloc[:,2]; o['chk_gc']=100*o.iloc[:,5]/o.iloc[:,4]
print('   recomputed % (overlap/PB clones, overlap/GC clones):',o[['Participant','chk_pb','chk_gc']].round(3).values.tolist())
# repertoire
r=pd.read_csv(D+'repertoire_clonotype_counts.csv')
r['i']=r.groupby(['metric','arm']).cumcount()
R=r.pivot_table(index=['arm','i'],columns='metric',values='value')
R['frac_new_clonotypes']=R.n_vaccine_elicited_clonotypes/(R.n_vaccine_elicited_clonotypes+R.n_pre_existing_clonotypes)
print('\n== Serum IgG repertoire (8 per arm; no participant IDs)'); print(R.groupby(level='arm').agg(['median','mean']).round(2).T)
for c in R.columns:
    a=R.loc['mRNA-1010',c]; f=R.loc['Fluarix',c]; print(f'   {c}: MWU p={stats.mannwhitneyu(a,f).pvalue:.3f}')
s=pd.read_csv(D+'serum_igg_clonotypes.csv'); print('\n== serum IgG clonotype counts: median by arm/timepoint'); print(s.groupby(['timepoint','arm']).n_clonotypes.agg(['size','median']).unstack())
print('   wk0 clonotype counts identical to n_pre_existing_clonotypes (same order):',
      list(s[(s.timepoint=='wk0')&(s.arm=='mRNA-1010')].n_clonotypes)==list(R.loc['mRNA-1010'].n_pre_existing_clonotypes.astype(int)),
      list(s[(s.timepoint=='wk0')&(s.arm=='Fluarix')].n_clonotypes)==list(R.loc['Fluarix'].n_pre_existing_clonotypes.astype(int)))
c=pd.read_csv(D+'cdrh3_diversity_index.csv'); print('\n== CDR-H3 diversity index: median by arm/timepoint'); print(c.groupby(['timepoint','arm']).diversity_index.agg(['size','median']).unstack().round(1))
