"""Parse sequencing-based neutralisation data; annotate viruses (subtype, isolation year,
reassortant / egg-adapted status, relationship to each arm's vaccine antigen); QC."""
import pandas as pd, numpy as np, re
pd.set_option('display.width',250); pd.set_option('display.max_columns',60); pd.set_option('display.max_rows',500)
d=pd.read_csv('/tmp/world/filesystem/neutralization_seqbased.csv')
s=d.serum.str.extract(r'^(?P<arm>.+?)_(?P<participant>397-\d+)_d(?P<day>\d+)$'); s['day']=s.day.astype(int)
d=pd.concat([d,s],axis=1)
d['subtype']=d.virus.str.extract(r'_(H\dN\d)$')[0]
REASS=['IVR-238','NIB-88','X-307A','X-223A','egg']
def reass(v):
    core=v.rsplit('_',1)[0]
    return any(core.endswith(t) or ('_'+t) in v for t in REASS)
d['reassortant_or_egg']=d.virus.apply(reass)
def year(v):
    core=v.rsplit('_',1)[0]
    core=re.sub(r'(IVR-238|NIB-88|X-307A|X-223A|egg)$','',core).rstrip('_')
    m=re.search(r'/(\d{4,6})$',core); return int(m.group(1)) if m else None
d['year_raw']=d.virus.apply(year)
print('== malformed years:', d[d.year_raw>2100].virus.unique())
d['year']=d.year_raw.where(d.year_raw<2100, 2023)  # A/SOUTHAFRICA/R07876/202023 -> treat as 2023 (flagged)
# relationship annotation (public WHO vaccine-strain history)
VAC={ # name -> note
 'A/Victoria/4897/2022_IVR-238_H1N1':'mRNA-1010 H1 antigen, but egg reassortant IVR-238 (not the wild-type sequence)',
 'A/Wisconsin/67/2022_H1N1':'cell/recombinant counterpart of A/Victoria/4897/2022 (mRNA-1010-matched H1; 2023-24+)',
 'A/Wisconsin/588/2019_H1N1':'cell/recombinant counterpart of A/Victoria/2570/2019 (Fluarix 2022-23 H1-matched)',
 'A/Darwin/6/2021_H3N2':'mRNA-1010 H3 antigen (cell/recombinant 2022-24 strain)',
 'A/Darwin/9/2021_H3N2':'Fluarix 2022-23 H3 (egg-based 2022-24 strain)',
 'A/Thailand/8/2022_H3N2':'2024-25 egg H3 vaccine strain (forward drift)',
 'A/Massachusetts/18/2022_H3N2':'2024-25 cell/rec H3 vaccine strain (forward drift)',
 'A/DistrictOfColumbia/27/2023_H3N2':'2025-26 cell/rec H3 vaccine strain (forward drift)',
}
d['vaccine_note']=d.virus.map(VAC).fillna('')
def category(r):
    v=r.virus
    if r.reassortant_or_egg: return 'reassortant/egg-adapted'
    if v in ['A/Wisconsin/67/2022_H1N1','A/Darwin/6/2021_H3N2']: return 'mRNA-1010-matched (wild-type/cell)'
    if v in ['A/Wisconsin/588/2019_H1N1','A/Darwin/9/2021_H3N2']: return 'Fluarix-matched'
    if r.year>=2022: return 'contemporary/forward (2022-2024 isolates)'
    return 'historical (<=2021)'
d['category']=d.apply(category,axis=1)
V=d.drop_duplicates('virus')[['virus','subtype','year_raw','year','reassortant_or_egg','category','vaccine_note']].sort_values(['subtype','category','year'])
print(V.to_string(index=False))
print(V.groupby(['subtype','category']).size())
# QC
print('\n== sera and days'); print(d.groupby(['arm','day']).participant.nunique())
print('\n== per-serum virus count < 96:'); c=d.groupby('serum').virus.nunique(); print(c[c<96])
print('\n== duplicates serum x virus:', d.duplicated(['serum','virus']).sum())
print('\n== censoring by arm/day'); print(pd.crosstab([d.arm,d.day],d.titer_bound))
print('\n== titer_sem NaN:', d.titer_sem.isna().sum(), ' n_replicates==1:', (d.n_replicates==1).sum())
d.to_csv('/tmp/outputs/analysis/seqneut_annotated.csv',index=False)
V.to_csv('/tmp/outputs/analysis/seqneut_virus_annotation.csv',index=False)
