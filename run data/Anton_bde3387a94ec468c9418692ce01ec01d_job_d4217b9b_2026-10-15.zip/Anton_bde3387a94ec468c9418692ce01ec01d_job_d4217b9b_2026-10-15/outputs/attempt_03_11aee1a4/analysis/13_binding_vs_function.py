"""Participant-level concordance between binding readouts (ELISA, bead array) and functional readouts
(HAI, MN, sequencing-based neutralisation), within subtype. Spearman rho, pooled and within arm.
Also: ratio of functional to binding fold-rise by arm (does extra binding come with function?)."""
import pandas as pd, numpy as np, re
from scipy import stats
import statsmodels.formula.api as smf
pd.set_option('display.width',250); pd.set_option('display.max_columns',60)
D='/tmp/world/filesystem/'
nid=lambda x:int(re.search(r'(\d+)$',str(x)).group(1))
# ELISA wk4 log2 FC
e=pd.read_csv(D+'elisa_igg_titers.csv'); e=e[(e.measure=='fold_change')&(e.timepoint=='wk4')]
e['pid']=e.participant.map(nid); E=e.pivot_table(index='pid',columns='antigen',values='value').apply(np.log2).rename(columns={'A/H1':'ELISA_H1','A/H3':'ELISA_H3','B/Vic':'ELISA_BVic','B/Yam':'ELISA_BYam'})
# HAI log2 FR wk4
h=pd.read_csv(D+'hai_titers.csv'); h['pid']=h.participant.map(nid)
hw=h.pivot_table(index=['pid','antigen'],columns='timepoint',values='hai_titer'); hw['fr']=np.log2(hw.wk4/hw.wk0)
H=hw.fr.unstack('antigen').rename(columns={'A/H1N1':'HAI_H1','A/H3N2':'HAI_H3','B/Vic':'HAI_BVic','B/Yam':'HAI_BYam'})
# Bead array mean log2FC (all strains)
b1=pd.read_csv(D+'binding_breadth_h1.csv'); b3=pd.read_csv(D+'binding_breadth_h3.csv')
B=pd.concat([b1.assign(s='Bead_H1'),b3.assign(s='Bead_H3')]); B['pid']=B.participant.map(nid)
B=B.groupby(['pid','s']).log2_fold_change_mfi.mean().unstack()
# seq-neut participant mean log2 FR, contemporary panel, by subtype
n=pd.read_csv('/tmp/outputs/analysis/seqneut_annotated.csv'); n['pid']=n.participant.map(nid); n['l']=np.log2(n.titer)
x=n[n.day.isin([0,29])].pivot_table(index=['pid','virus','subtype','category'],columns='day',values='l').dropna().reset_index()
x['fr']=x[29]-x[0]
S=x[x.category.str.startswith('contemporary')].groupby(['pid','subtype']).fr.mean().unstack().rename(columns={'H1N1':'Neut_H1_contemp','H3N2':'Neut_H3_contemp'})
# MN
m=pd.read_csv(D+'microneutralization.csv'); m=m[(m.measure=='fold_change')&(m.timepoint=='wk4')]; m['pid']=m.participant.map(nid)
M=m.pivot_table(index='pid',columns='panel',values='value').apply(np.log2).rename(columns={'homologous':'MN_hom','heterologous':'MN_het'})
arm=pd.concat([e[['pid','arm']],h[['pid','arm']]]).drop_duplicates().set_index('pid').arm
X=E.join([H,B,S,M],how='left'); X['arm']=arm
X=X[X.HAI_H3.notna()]
pairs=[('ELISA_H3','Neut_H3_contemp'),('Bead_H3','Neut_H3_contemp'),('HAI_H3','Neut_H3_contemp'),('ELISA_H3','HAI_H3'),('Bead_H3','HAI_H3'),
       ('ELISA_H1','Neut_H1_contemp'),('Bead_H1','Neut_H1_contemp'),('HAI_H1','Neut_H1_contemp'),('ELISA_H1','HAI_H1'),('Bead_H1','HAI_H1'),
       ('Bead_H3','MN_het'),('Neut_H3_contemp','MN_het'),('Neut_H1_contemp','MN_het')]
rows=[]
for a,b in pairs:
    y=X[[a,b,'arm']].dropna()
    r_all=stats.spearmanr(y[a],y[b]); rm=y[y.arm=='mRNA-1010']; rf=y[y.arm=='Fluarix']
    rows.append(dict(binding_or_x=a,functional_or_y=b,n=len(y),rho_all=r_all.correlation,p_all=r_all.pvalue,
      rho_mRNA=stats.spearmanr(rm[a],rm[b]).correlation,rho_Flu=stats.spearmanr(rf[a],rf[b]).correlation))
R=pd.DataFrame(rows); print(R.round(3).to_string(index=False)); R.to_csv('/tmp/outputs/analysis/binding_vs_function_correlations.csv',index=False)
# Functional yield per unit binding: regress neut FR on binding FR + arm
for bind,fun in [('Bead_H3','Neut_H3_contemp'),('ELISA_H3','Neut_H3_contemp'),('Bead_H1','Neut_H1_contemp'),('ELISA_H1','Neut_H1_contemp')]:
    y=X[[bind,fun,'arm']].dropna().assign(mrna=lambda q:(q.arm=='mRNA-1010').astype(int))
    y=y.rename(columns={bind:'bind',fun:'fun'})
    mod=smf.ols('fun ~ bind + mrna',data=y).fit()
    print(f'{fun} ~ {bind} + arm: slope={mod.params["bind"]:.3f} (p={mod.pvalues["bind"]:.3f}); arm effect (log2)={mod.params["mrna"]:.3f} (p={mod.pvalues["mrna"]:.3f}); n={len(y)}')
print('\nMean log2 fold-rise by arm (participants with seq-neut data):')
print(X[X.Neut_H3_contemp.notna()].groupby('arm')[['ELISA_H3','Bead_H3','HAI_H3','Neut_H3_contemp','ELISA_H1','Bead_H1','HAI_H1','Neut_H1_contemp']].mean().round(2).T.assign(**{'ratio(fold)':lambda q: (2**(q['mRNA-1010']-q['Fluarix'])).round(2)}))
X.to_csv('/tmp/outputs/analysis/participant_level_readouts.csv')
