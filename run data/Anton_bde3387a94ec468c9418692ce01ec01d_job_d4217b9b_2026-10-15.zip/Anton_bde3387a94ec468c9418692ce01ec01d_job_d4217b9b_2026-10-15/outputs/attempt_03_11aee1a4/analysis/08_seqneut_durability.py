"""Durability: late sera (d121 or d181) vs d0 and vs d29, by subtype/category; participant-level."""
import pandas as pd, numpy as np
from scipy import stats
import statsmodels.formula.api as smf
pd.set_option('display.width',250); pd.set_option('display.max_columns',60); pd.set_option('display.max_rows',500)
d=pd.read_csv('/tmp/outputs/analysis/seqneut_annotated.csv'); d['l']=np.log2(d.titer)
d['visit']=d.day.map({0:'d0',29:'d29',121:'late',181:'late'})
late_day=d[d.day.isin([121,181])].groupby('participant').day.first()
w=d.pivot_table(index=['arm','participant','virus','subtype','category'],columns='visit',values='l').reset_index().dropna(subset=['d0','d29','late'])
w['late_day']=w.participant.map(late_day)
w['cat2']=np.where(w.category.str.startswith('contemporary'),'contemporary',np.where(w.category.str.startswith('reassortant'),'reassortant','other'))
ps=w.groupby(['arm','participant','late_day','subtype','cat2']).agg(d0=('d0','mean'),d29=('d29','mean'),late=('late','mean')).reset_index()
ps['fr29']=ps.d29-ps.d0; ps['frL']=ps.late-ps.d0; ps['ret']=ps.late-ps.d29
rows=[]
for (st,c),g in ps.groupby(['subtype','cat2']):
    a=g[g.arm=='mRNA-1010']; b=g[g.arm=='Fluarix']
    g=g.assign(mrna=(g.arm=='mRNA-1010').astype(int)); m=smf.ols('late ~ mrna + d0 + C(late_day)',data=g).fit()
    rows.append(dict(subtype=st,cat=c,n_mRNA=len(a),n_Flu=len(b),n_d121_mRNA=(a.late_day==121).sum(),n_d121_Flu=(b.late_day==121).sum(),
        GMFR29_mRNA=2**a.fr29.mean(),GMFR29_Flu=2**b.fr29.mean(),GMFRlate_mRNA=2**a.frL.mean(),GMFRlate_Flu=2**b.frL.mean(),
        p_late=stats.ttest_ind(a.frL,b.frL,equal_var=False).pvalue,
        retained_late_vs_d29_mRNA=2**a.ret.mean(),retained_late_vs_d29_Flu=2**b.ret.mean(),
        ANCOVA_GMR_late=2**m.params['mrna'],ANCOVA_CI=np.round(2**m.conf_int().loc['mrna'].values,2),p_ANCOVA=m.pvalues['mrna']))
R=pd.DataFrame(rows); print(R.round(3).to_string(index=False)); R.to_csv('/tmp/outputs/analysis/seqneut_durability.csv',index=False)
