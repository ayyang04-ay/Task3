"""Screen for possible intercurrent infection: >=2-fold (ELISA, seq-neut) or >=4-fold (HAI) rise from wk4/d29 to the late visit.
No vaccination dates or infection surveillance are in the package, so these are flags, not diagnoses."""
import pandas as pd, numpy as np, re
pd.set_option('display.width',250)
D='/tmp/world/filesystem/'
e=pd.read_csv(D+'elisa_igg_titers.csv'); e=e[e.measure=='ec50']
w=e.pivot_table(index=['arm','participant','antigen'],columns='timepoint',values='value').reset_index()
w['late']=w.wk26.fillna(w.wk17); w['rise']=w.late/w.wk4
f=w[w.rise>=2]
print('ELISA: participant-antigen pairs with >=2-fold rise wk4->late:'); print(f[['arm','participant','antigen','wk0','wk4','late','rise']].round(2).to_string(index=False))
print('  participants flagged by arm:', f.groupby('arm').participant.nunique().to_dict(), 'of', w.groupby('arm').participant.nunique().to_dict())
h=pd.read_csv(D+'hai_titers.csv',dtype={'participant':str})
hw=h.pivot_table(index=['arm','participant','antigen'],columns='timepoint',values='hai_titer').reset_index(); hw['late']=hw.wk26.fillna(hw.wk17)
hf=hw[hw.late/hw.wk4>=3.9]
print('\nHAI >=4-fold rise wk4->late:'); print(hf[['arm','participant','antigen','wk0','wk4','late']].to_string(index=False))
n=pd.read_csv('/tmp/outputs/analysis/seqneut_annotated.csv'); n['l']=np.log2(n.titer); n['v']=n.day.map({0:'d0',29:'d29',121:'late',181:'late'})
x=n.pivot_table(index=['arm','participant','subtype'],columns='v',values='l',aggfunc='mean').reset_index()
x['late_vs_d29']=2**(x.late-x.d29)
print('\nSeq-neut: subtype-mean late/d29 ratio >= 1.5:'); print(x[x.late_vs_d29>=1.5][['arm','participant','subtype','late_vs_d29']].round(2).to_string(index=False))
