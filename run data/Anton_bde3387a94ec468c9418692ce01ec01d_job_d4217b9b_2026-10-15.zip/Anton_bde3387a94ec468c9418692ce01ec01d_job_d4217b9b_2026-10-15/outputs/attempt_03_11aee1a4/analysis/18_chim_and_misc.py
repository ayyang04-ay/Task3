"""CHIM sample-size scenarios (assumption-driven) and miscellaneous counts cited in answer.md."""
import numpy as np, pandas as pd
from scipy import stats
z=stats.norm.ppf
def n2p(p1,p2,alpha=0.05,power=0.8):
    pb=(p1+p2)/2
    return int(np.ceil((z(1-alpha/2)*np.sqrt(2*pb*(1-pb))+z(power)*np.sqrt(p1*(1-p1)+p2*(1-p2)))**2/(p1-p2)**2))
print('CHIM (two-sided alpha 0.05, 80% power), evaluable per arm:')
for p1,p2,lab in [(0.6,0.3,'placebo 60% infected vs vaccine 30% (50% reduction)'),(0.5,0.25,'placebo 50% vs vaccine 25%'),
                  (0.4,0.25,'comparator 40% vs mRNA 25% (head-to-head)'),(0.4,0.2,'comparator 40% vs mRNA 20%')]:
    print(f'  {lab}: n/arm = {n2p(p1,p2)}')
# misc counts
D='/tmp/world/filesystem/'
n=pd.read_csv(D+'neutralization_seqbased.csv'); print('\nseq-neut rows',len(n),'viruses',n.virus.nunique(),'sera',n.serum.nunique())
print(n.titer_bound.value_counts().to_dict())
m=pd.read_csv(D+'mab_binding_panels.csv'); m['donor']=m.mab_id.str.split('.').str[1]
print('mAbs',m.mab_id.nunique(),m.groupby('arm').mab_id.nunique().to_dict()); print(m.groupby(['arm','donor']).mab_id.nunique().to_dict())
print('group II Fluarix mAbs by donor',m[(m.panel=='group_II')&(m.arm=='Fluarix')].groupby('donor').mab_id.nunique().to_dict())
print('RBD fold_over_control unique values:',m[m.antigen=='SARS-CoV-2 RBD'].fold_over_control.unique())
r=pd.read_csv(D+'repertoire_clonotype_counts.csv'); print(r.groupby(['metric','arm']).value.agg(['mean','median']).round(2))
i=pd.read_csv(D+'igm_fold_change.csv'); print('IgM FC unit step ~', round(sorted(i.fold_change.unique())[1]/2,4))
