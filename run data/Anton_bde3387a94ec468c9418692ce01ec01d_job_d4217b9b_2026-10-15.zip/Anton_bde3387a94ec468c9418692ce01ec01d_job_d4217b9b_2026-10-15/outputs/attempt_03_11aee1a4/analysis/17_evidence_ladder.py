"""Consolidated mRNA-1010 : Fluarix ratios (participant = unit), from binding to functional to durable readouts.
Serology ratios are baseline-adjusted (ANCOVA on log2 post ~ arm + log2 pre) where pre/post titers exist;
bead-array file holds fold-changes only -> ratio of geometric mean fold-rise (Welch CI)."""
import pandas as pd, numpy as np, re
from scipy import stats
import statsmodels.formula.api as smf
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
D='/tmp/world/filesystem/'
rows=[]
def ancova(df,pre,post,label,group,source,n_note=''):
    g=df.dropna(subset=[pre,post]).copy(); g['l0']=np.log2(g[pre]); g['l1']=np.log2(g[post]); g['mrna']=(g.arm=='mRNA-1010').astype(int)
    m=smf.ols('l1 ~ mrna + l0',data=g).fit(); lo,hi=m.conf_int().loc['mrna']
    rows.append(dict(group=group,readout=label,ratio=2**m.params['mrna'],lo=2**lo,hi=2**hi,p=m.pvalues['mrna'],n_mRNA=int(g.mrna.sum()),n_Flu=int((1-g.mrna).sum()),source=source,method='ANCOVA (baseline-adjusted GMR)'))
def welch_fc(a,b,label,group,source):
    diff=a.mean()-b.mean(); va,vb=a.var()/len(a),b.var()/len(b); se=np.sqrt(va+vb); df=(va+vb)**2/(va**2/(len(a)-1)+vb**2/(len(b)-1)); t=stats.t.ppf(.975,df)
    rows.append(dict(group=group,readout=label,ratio=2**diff,lo=2**(diff-t*se),hi=2**(diff+t*se),p=stats.ttest_ind(a,b,equal_var=False).pvalue,n_mRNA=len(a),n_Flu=len(b),source=source,method='ratio of GM fold-rise (Welch)'))
# ELISA
e=pd.read_csv(D+'elisa_igg_titers.csv'); e=e[e.measure=='ec50']
ew=e.pivot_table(index=['arm','participant','antigen'],columns='timepoint',values='value').reset_index(); ew['late']=ew.wk26.fillna(ew.wk17)
for ag in ['A/H1','A/H3','B/Vic','B/Yam']:
    ancova(ew[ew.antigen==ag],'wk0','wk4',f'ELISA IgG {ag} wk4','1 Binding (vaccine antigen)','elisa_igg_titers.csv')
# Bead arrays (participant mean over strains excluding vaccine-matched)
for sub,f,excl in [('H1','binding_breadth_h1.csv',['A/Wisconsin/67/2022','A/Wisconsin/588/2019']),('H3','binding_breadth_h3.csv',['A/Darwin/6/2021'])]:
    b=pd.read_csv(D+f); p=b[~b.strain.isin(excl)].groupby(['arm','participant']).log2_fold_change_mfi.mean()
    welch_fc(p['mRNA-1010'],p['Fluarix'],f'Bead-array {sub} breadth (non-vaccine strains)','2 Binding breadth',f)
# HAI
h=pd.read_csv(D+'hai_titers.csv',dtype={'participant':str}); hw=h.pivot_table(index=['arm','participant','antigen'],columns='timepoint',values='hai_titer').reset_index()
for ag in ['A/H1N1','A/H3N2','B/Vic','B/Yam']:
    ancova(hw[hw.antigen==ag],'wk0','wk4',f'HAI {ag} wk4','3 Functional: HAI','hai_titers.csv')
# MN
m=pd.read_csv(D+'microneutralization.csv'); m=m[m.measure=='titer']; mw=m.pivot_table(index=['arm','participant','panel'],columns='timepoint',values='value').reset_index()
for pan in ['homologous','heterologous']:
    ancova(mw[mw.panel==pan],'wk0','wk4',f'MN "{pan}" panel wk4 (ceiling 1280)','4 Functional: MN','microneutralization.csv')
# Seq-neut
n=pd.read_csv('/tmp/outputs/analysis/seqneut_annotated.csv'); n['l']=np.log2(n.titer); n['v']=n.day.map({0:'d0',29:'d29',121:'late',181:'late'})
def sn(sel,label,group):
    x=n[sel].groupby(['arm','participant','v']).l.mean().unstack().reset_index()
    for c in ['d0','d29','late']: x[c]=2**x[c]
    return x
for lab,sel in [('Neut H1 mRNA-1010-matched wt (A/Wisconsin/67/2022) d29',n.virus=='A/Wisconsin/67/2022_H1N1'),
                ('Neut H1 Fluarix-matched (A/Wisconsin/588/2019) d29',n.virus=='A/Wisconsin/588/2019_H1N1'),
                ('Neut H1 contemporary 2023 wt panel (6) d29',(n.subtype=='H1N1')&n.category.str.startswith('contemporary')),
                ('Neut H3 mRNA-1010 antigen (A/Darwin/6/2021) d29',n.virus=='A/Darwin/6/2021_H3N2'),
                ('Neut H3 next-season strains (A/Thailand/8/2022, A/Massachusetts/18/2022) d29',n.virus.isin(['A/Thailand/8/2022_H3N2','A/Massachusetts/18/2022_H3N2'])),
                ('Neut H3 contemporary 2022-24 wt panel (68) d29',(n.subtype=='H3N2')&n.category.str.startswith('contemporary')),
                ('Neut H3 historical wt panel (8) d29 [back-boost]',(n.subtype=='H3N2')&(n.category=='historical (<=2021)'))]:
    grp='5 Functional: neutralisation (peak)' 
    ancova(sn(sel,lab,grp),'d0','d29',lab,grp,'neutralization_seqbased.csv')
for lab,sel in [('Neut H1 contemporary panel, late (d121/d181)',(n.subtype=='H1N1')&n.category.str.startswith('contemporary')),
                ('Neut H3 contemporary panel, late (d121/d181)',(n.subtype=='H3N2')&n.category.str.startswith('contemporary'))]:
    ancova(sn(sel,lab,'6'),'d0','late',lab,'6 Functional: neutralisation (end of season)','neutralization_seqbased.csv')
R=pd.DataFrame(rows); pd.set_option('display.width',250); pd.set_option('display.max_colwidth',80)
print(R[['group','readout','ratio','lo','hi','p','n_mRNA','n_Flu','method','source']].round(3).to_string(index=False))
R.to_csv('/tmp/outputs/analysis/evidence_ladder.csv',index=False)
# forest plot
fig,ax=plt.subplots(figsize=(13,11)); y=np.arange(len(R))[::-1]
cols={'1':'#1f77b4','2':'#1f77b4','3':'#d62728','4':'#d62728','5':'#2ca02c','6':'#9467bd'}
for yi,(_,r) in zip(y,R.iterrows()):
    c=cols[r.group[0]]; ax.plot([r.lo,r.hi],[yi,yi],color=c,lw=2); ax.plot(r.ratio,yi,'o',color=c,ms=6)
ax.axvline(1,color='k',lw=0.8); ax.axvline(1.5,color='grey',lw=0.6,ls='--')
ax.set_xscale('log'); ax.set_yticks(y); ax.set_yticklabels([f'{r.readout}  (n={r.n_mRNA}/{r.n_Flu})' for _,r in R.iterrows()],fontsize=8)
ax.set_xlabel('mRNA-1010 : Fluarix ratio, log scale, 95% CI\n(baseline-adjusted GMR where pre/post titres exist; ratio of GM fold-rise for bead array)',fontsize=9)
ax.set_title('WU397: advantage shrinks from binding (blue) to functional (red, green) to end of season (purple)\nH1 rows are confounded: the two arms received different H1 strains',fontsize=10)
ax.set_xticks([0.25,0.5,1,2,4,8]); ax.get_xaxis().set_major_formatter(matplotlib.ticker.ScalarFormatter())
plt.tight_layout(); plt.savefig('/tmp/outputs/figures/evidence_ladder_forest.png',dpi=150)
print('saved figure')
