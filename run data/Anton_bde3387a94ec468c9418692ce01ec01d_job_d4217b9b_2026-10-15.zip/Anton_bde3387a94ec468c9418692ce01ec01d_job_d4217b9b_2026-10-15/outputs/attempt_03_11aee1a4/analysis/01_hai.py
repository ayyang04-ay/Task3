"""HAI titers: baseline comparability, GMT, GMFR, seroconversion (>=4-fold rise AND post>=40),
seroprotection (>=40) at wk4 and wk17/26, by arm and antigen. Arm difference via Welch t-test on
log2 titers / log2 fold-rise and Fisher exact for proportions; ANCOVA on log2 wk4 adjusting for log2 wk0."""
import pandas as pd, numpy as np
from scipy import stats
import statsmodels.formula.api as smf
pd.set_option('display.width',250); pd.set_option('display.max_columns',60); pd.set_option('display.max_rows',500)
d=pd.read_csv('/tmp/world/filesystem/hai_titers.csv',dtype={'participant':str})
# Snap to the half-log2 dilution grid (10*2^(k/2)); source file mixes rounded (226) and exact (226.27417) values
# and one off-grid value (288, Fluarix 018 B/Yam wk17) which is kept as reported for GMT but flagged.
d['hai_raw']=d.hai_titer
d['k']=np.round(2*np.log2(d.hai_titer/10))
offgrid=d[(np.abs(2*np.log2(d.hai_titer/10)-d.k)>0.05)]
print('== Off-grid HAI values (kept as reported):'); print(offgrid[['antigen','timepoint','arm','participant','hai_raw']].to_string(index=False))
d.loc[~d.index.isin(offgrid.index),'hai_titer']=10*2**(d.k/2)
d['log2']=np.log2(d.hai_titer)
w=d.pivot_table(index=['arm','participant','antigen'],columns='timepoint',values='hai_titer').reset_index()
w['late']=w['wk26'].fillna(w['wk17'])
w['late_src']=np.where(w['wk26'].notna(),'wk26',np.where(w['wk17'].notna(),'wk17','none'))
rows=[]
def gm(x): x=np.asarray(x,float); x=x[~np.isnan(x)]; return np.exp(np.mean(np.log(x))) if len(x) else np.nan
def ci_gm(x):
    x=np.log(np.asarray(x,float)); x=x[~np.isnan(x)]; n=len(x); m=x.mean(); se=x.std(ddof=1)/np.sqrt(n); t=stats.t.ppf(.975,n-1)
    return np.exp(m-t*se), np.exp(m+t*se)
for ag in ['A/H1N1','A/H3N2','B/Vic','B/Yam']:
    for arm in ['mRNA-1010','Fluarix']:
        s=w[(w.antigen==ag)&(w.arm==arm)]
        s4=s.dropna(subset=['wk0','wk4'])
        fr=s4.wk4/s4.wk0
        scv=np.where(s4.wk0<10, s4.wk4>=40, (np.round(np.log2(fr),3)>=2)&(s4.wk4>=40)); sc=scv.mean(); scn=scv.sum()
        sl=s.dropna(subset=['wk0','late'])
        rows.append(dict(antigen=ag,arm=arm,n=len(s4),GMT_wk0=gm(s4.wk0),GMT_wk4=gm(s4.wk4),
            GMT_wk4_CI=f'{ci_gm(s4.wk4)[0]:.0f}-{ci_gm(s4.wk4)[1]:.0f}',
            GMFR_wk4=gm(fr), GMFR_wk4_CI=f'{ci_gm(fr)[0]:.2f}-{ci_gm(fr)[1]:.2f}',
            SCR_wk4=f'{scn}/{len(s4)} ({100*sc:.0f}%)',
            SP40_wk0=f'{(s4.wk0>=40).sum()}/{len(s4)}', SP40_wk4=f'{(s4.wk4>=40).sum()}/{len(s4)}',
            n_late=len(sl), GMT_late=gm(sl.late), GMFR_late=gm(sl.late/sl.wk0),
            late_from_wk17=(sl.late_src=='wk17').sum()))
T=pd.DataFrame(rows)
print('== HAI summary by antigen and arm'); print(T.round(2).to_string(index=False))
T.to_csv('/tmp/outputs/analysis/hai_summary.csv',index=False)

print('\n== Between-arm comparisons (mRNA-1010 vs Fluarix)')
out=[]
for ag in ['A/H1N1','A/H3N2','B/Vic','B/Yam']:
    s=w[w.antigen==ag].dropna(subset=['wk0','wk4']).copy()
    s['l0']=np.log2(s.wk0); s['l4']=np.log2(s.wk4); s['lfr']=s.l4-s.l0
    s['mrna']=(s.arm=='mRNA-1010').astype(int)
    a=s[s.mrna==1]; b=s[s.mrna==0]
    t0=stats.ttest_ind(a.l0,b.l0,equal_var=False); t4=stats.ttest_ind(a.l4,b.l4,equal_var=False); tf=stats.ttest_ind(a.lfr,b.lfr,equal_var=False)
    mw=stats.mannwhitneyu(a.lfr,b.lfr)
    sca=np.where(a.wk0<10,a.wk4>=40,(np.round(a.lfr,3)>=2)&(a.wk4>=40)); scb=np.where(b.wk0<10,b.wk4>=40,(np.round(b.lfr,3)>=2)&(b.wk4>=40))
    fe=stats.fisher_exact([[sca.sum(),len(a)-sca.sum()],[scb.sum(),len(b)-scb.sum()]])
    m=smf.ols('l4 ~ mrna + l0',data=s).fit()
    gmr=2**m.params['mrna']; lo,hi=2**m.conf_int().loc['mrna']
    out.append(dict(antigen=ag, baseline_GMT_ratio=2**(a.l0.mean()-b.l0.mean()), p_baseline=t0.pvalue,
        wk4_GMT_ratio_unadj=2**(a.l4.mean()-b.l4.mean()), p_wk4=t4.pvalue,
        GMFR_ratio=2**(a.lfr.mean()-b.lfr.mean()), p_GMFR_welch=tf.pvalue, p_GMFR_MWU=mw.pvalue,
        SCR_mRNA=f'{sca.sum()}/{len(a)}', SCR_Flu=f'{scb.sum()}/{len(b)}', p_SCR_fisher=fe[1],
        ANCOVA_GMR_wk4_adj_baseline=gmr, ANCOVA_95CI=f'{lo:.2f}-{hi:.2f}', p_ANCOVA=m.pvalues['mrna']))
C=pd.DataFrame(out); print(C.round(3).to_string(index=False))
C.to_csv('/tmp/outputs/analysis/hai_arm_comparisons.csv',index=False)

# Visit timing issue: which participants have wk17 instead of wk26
print('\n== Participants whose late sample is wk17 rather than wk26 (pooled as wk17/26 elsewhere)')
print(w[w.late_src=='wk17'][['arm','participant']].drop_duplicates().to_string(index=False))
print('\n== Missing values'); print(w[w.wk0.isna()|w.wk4.isna()][['arm','participant','antigen']])
# distinct titer values (dilution grid check)
print('\n== distinct HAI values', sorted(d.hai_titer.unique()))
