"""IgM fold-change (no timepoint stated in the file): responder rates and GMFR by arm."""
import pandas as pd, numpy as np
from scipy import stats
d=pd.read_csv('/tmp/world/filesystem/igm_fold_change.csv',dtype={'participant':str})
print('distinct FC values:',sorted(d.fold_change.round(3).unique()))
rows=[]
for ag,g in d.groupby('antigen'):
    a=g[g.arm=='mRNA-1010'].fold_change; f=g[g.arm=='Fluarix'].fold_change
    rows.append(dict(antigen=ag,n_mRNA=len(a),n_Flu=len(f),GMFR_mRNA=np.exp(np.log(a).mean()),GMFR_Flu=np.exp(np.log(f).mean()),
        resp_gt1_mRNA=f'{(a>1).sum()}/{len(a)}',resp_gt1_Flu=f'{(f>1).sum()}/{len(f)}',
        resp_ge4_mRNA=f'{(a>=4).sum()}/{len(a)}',resp_ge4_Flu=f'{(f>=4).sum()}/{len(f)}',p_MWU=stats.mannwhitneyu(a,f).pvalue))
R=pd.DataFrame(rows); print(R.round(3).to_string(index=False)); R.to_csv('/tmp/outputs/analysis/igm_summary.csv',index=False)
