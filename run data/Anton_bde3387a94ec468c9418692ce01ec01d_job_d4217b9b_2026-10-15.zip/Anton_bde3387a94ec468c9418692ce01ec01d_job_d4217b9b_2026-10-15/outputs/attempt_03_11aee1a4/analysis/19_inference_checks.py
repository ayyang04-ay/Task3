"""Two inference checks cited in answer.md:
(1) Which subtype/virus the unlabeled MN 'homologous'/'heterologous' panels track (Spearman of log2 MN titre vs
    log2 seq-neut titre per virus at the matching visit: wk0<->d0, wk4<->d29).
(2) Which timepoint the bead-array fold-changes most likely represent (Spearman vs ELISA log2 fold-change wk4 vs wk17/26)."""
import pandas as pd, numpy as np, re
from scipy import stats
pd.set_option('display.width',200)
D='/tmp/world/filesystem/'; nid=lambda x:int(re.search(r'(\d+)$',str(x)).group(1))
m=pd.read_csv(D+'microneutralization.csv'); m=m[m.measure=='titer']; m['pid']=m.participant.map(nid)
M=m.pivot_table(index='pid',columns=['panel','timepoint'],values='value')
n=pd.read_csv(D+'neutralization_seqbased.csv'); s=n.serum.str.extract(r'_(?P<pid>397-\d+)_d(?P<day>\d+)$'); n['pid']=s.pid.map(nid); n['day']=s.day.astype(int)
N=n.pivot_table(index='pid',columns=['virus','day'],values='titer')
res=[]
for pan in ['homologous','heterologous']:
    for tp,day in [('wk0',0),('wk4',29)]:
        a=np.log2(M[(pan,tp)])
        for v in n.virus.unique():
            if (v,day) not in N.columns: continue
            j=pd.concat([a,np.log2(N[(v,day)])],axis=1).dropna()
            res.append((pan,tp,v,v[-4:],stats.spearmanr(j.iloc[:,0],j.iloc[:,1]).correlation,len(j)))
R=pd.DataFrame(res,columns=['panel','tp','virus','subtype','rho','n'])
print('(1) Mean / max Spearman rho of MN panel titre with per-virus neutralisation titre, by subtype'); print(R.groupby(['panel','tp','subtype']).rho.agg(['mean','max']).round(2))
for pan in ['homologous','heterologous']:
    print(f'   top viruses for MN {pan} wk4:'); print(R[(R.panel==pan)&(R.tp=='wk4')].nlargest(3,'rho')[['virus','rho','n']].round(2).to_string(index=False))
R.to_csv('/tmp/outputs/analysis/mn_panel_identity_correlations.csv',index=False)
e=pd.read_csv(D+'elisa_igg_titers.csv'); e=e[e.measure=='fold_change']; e['pid']=e.participant.map(nid)
E=e.pivot_table(index='pid',columns=['antigen','timepoint'],values='value').apply(np.log2)
print('\n(2) Bead-array log2FC vs ELISA log2FC (Spearman)')
for f,ag,st in [('binding_breadth_h3.csv','A/H3','A/Darwin/6/2021'),('binding_breadth_h1.csv','A/H1','A/Wisconsin/67/2022')]:
    b=pd.read_csv(D+f); b['pid']=b.participant.map(nid); b=b[b.strain==st].set_index('pid').log2_fold_change_mfi
    for tp in ['wk4','wk17/26']:
        j=pd.concat([b,E[(ag,tp)]],axis=1).dropna()
        print(f'   {st} vs ELISA {ag} {tp}: rho={stats.spearmanr(j.iloc[:,0],j.iloc[:,1]).correlation:.2f} (n={len(j)})')
