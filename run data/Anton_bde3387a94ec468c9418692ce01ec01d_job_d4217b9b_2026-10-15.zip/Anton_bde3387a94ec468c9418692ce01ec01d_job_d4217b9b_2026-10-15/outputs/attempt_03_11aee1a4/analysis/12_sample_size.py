"""Variance components observed in WU397 -> sample sizes for the recommended randomised Phase 2.
All effect sizes/margins are design choices (stated); SDs are from the data."""
import pandas as pd, numpy as np
from scipy import stats
import statsmodels.formula.api as smf
pd.set_option('display.width',250)
z=stats.norm.ppf
def n_per_arm_superiority(sd, gmr, alpha=0.05, power=0.9):
    return int(np.ceil(2*(z(1-alpha/2)+z(power))**2*sd**2/np.log2(gmr)**2))
def n_per_arm_NI_gmt(sd, margin=1.5, true_ratio=1.0, alpha=0.025, power=0.9):
    return int(np.ceil(2*(z(1-alpha)+z(power))**2*sd**2/(np.log2(margin)-np.log2(true_ratio))**2))
def n_per_arm_NI_prop(p_c, p_t, margin=0.10, alpha=0.025, power=0.9):
    var=p_c*(1-p_c)+p_t*(1-p_t); d=margin-(p_c-p_t)
    return int(np.ceil((z(1-alpha)+z(power))**2*var/d**2))
out=[]
# HAI residual SD (ANCOVA log2 wk4 ~ arm + log2 wk0)
h=pd.read_csv('/tmp/world/filesystem/hai_titers.csv',dtype={'participant':str})
w=h.pivot_table(index=['arm','participant','antigen'],columns='timepoint',values='hai_titer').reset_index()
for ag,g in w.groupby('antigen'):
    g=g.dropna(subset=['wk0','wk4']).assign(l0=lambda x: np.log2(x.wk0),l4=lambda x: np.log2(x.wk4),mrna=lambda x:(x.arm=='mRNA-1010').astype(int))
    m=smf.ols('l4 ~ mrna + l0',data=g).fit(); sd=np.sqrt(m.scale)
    sd_raw=g.l4.std()
    out.append(dict(readout=f'HAI {ag} d29 (log2)',resid_SD=sd,raw_SD=sd_raw,
        n_NI_GMT_margin1p5=n_per_arm_NI_gmt(sd_raw), n_sup_GMR1p5=n_per_arm_superiority(sd,1.5), n_sup_GMR2=n_per_arm_superiority(sd,2.0)))
# seq-neut participant-level category means
d=pd.read_csv('/tmp/outputs/analysis/seqneut_annotated.csv'); d['l']=np.log2(d.titer)
x=d[d.day.isin([0,29])].pivot_table(index=['arm','participant','virus','subtype','category'],columns='day',values='l')
x.columns=['d0','d29']; x=x.dropna().reset_index()
x['cat2']=np.where(x.category.str.startswith('contemporary'),'contemporary',x.category)
for (st,c),g in x.groupby(['subtype','cat2']):
    if c not in ('contemporary','mRNA-1010-matched (wild-type/cell)'): continue
    ps=g.groupby(['arm','participant'])[['d0','d29']].mean().reset_index().assign(mrna=lambda q:(q.arm=='mRNA-1010').astype(int))
    m=smf.ols('d29 ~ mrna + d0',data=ps).fit(); sd=np.sqrt(m.scale)
    out.append(dict(readout=f'Neut {st} {c} panel-mean d29 (log2)',resid_SD=sd,raw_SD=ps.d29.std(),
        n_sup_GMR1p5=n_per_arm_superiority(sd,1.5),n_sup_GMR2=n_per_arm_superiority(sd,2.0),
        n_sup_at_observed_GMR=n_per_arm_superiority(sd,2**m.params['mrna']) if m.params['mrna']>0 else None, observed_GMR=2**m.params['mrna']))
R=pd.DataFrame(out); print(R.round(3).to_string(index=False)); R.to_csv('/tmp/outputs/analysis/sample_size_inputs.csv',index=False)
# SCR NI
print('\nSCR non-inferiority (margin 10 points, one-sided alpha 0.025, 90% power):')
for pc,pt in [(0.33,0.33),(0.5,0.5),(0.2,0.2),(0.4,0.4)]:
    print(f'  comparator SCR {pc:.0%}, test SCR {pt:.0%}: n/arm = {n_per_arm_NI_prop(pc,pt)}')
# multiplicity: 3 strains (trivalent) x GMT+SCR = 6 co-primary NI tests -> each must pass; power per test ~ 0.9^(1/6)
pw=0.9**(1/6); print(f'\nper-test power needed for 90% joint power across 6 co-primary NI tests (independence approx.): {pw:.3f}')
for pc in [0.2,0.33,0.5]:
    print(f'  SCR {pc:.0%} both arms: n/arm = {n_per_arm_NI_prop(pc,pc,power=pw)}')
# Efficacy: events needed (log-rank / Poisson approx, 1:1) for rVE superiority (LB>0) and NI (LB>-10%)
print('\nRelative VE event counts (1:1, two-sided alpha 0.05, 90% power):')
for rve in [0.15,0.20,0.25,0.30]:
    hr=1-rve
    D_sup=4*(z(0.975)+z(0.9))**2/np.log(hr)**2
    D_ni=4*(z(0.975)+z(0.9))**2/(np.log(hr)-np.log(1.10))**2
    print(f'  true rVE {rve:.0%}: events for superiority (LB>0) = {D_sup:.0f}; for NI (LB>-10%) = {D_ni:.0f}')
print('\nParticipants needed = events / (attack rate in comparator arm x (1+(1-rVE))/2) -- illustrative attack rates (assumptions, not from the data):')
for ar in [0.01,0.02,0.03]:
    for rve in [0.20,0.25]:
        D=4*(z(0.975)+z(0.9))**2/np.log(1-rve)**2
        N=D/(ar*(1+(1-rve))/2)
        print(f'  attack rate {ar:.0%}, rVE {rve:.0%}: events {D:.0f} -> total N ~ {N:,.0f} (all-strain); if mismatched strains are 40% of cases -> N ~ {N/0.4:,.0f}')
# Pooled-cohort comparison (mRNA-1010 vs RIV is common to both age cohorts): detectable GMR with ~130 evaluable/arm
sd=R.loc[R.readout.str.contains('H3N2 contemporary'),'resid_SD'].iloc[0]
for gmr in [1.25,1.33,1.4,1.5]:
    print(f'H3 contemporary panel (SD {sd:.2f}): n/arm for GMR {gmr}: {n_per_arm_superiority(sd,gmr)}')
print('Randomised per arm per cohort to keep >=65 evaluable at 15-20% non-evaluable:', int(np.ceil(65/0.85)),'-',int(np.ceil(65/0.80)))
