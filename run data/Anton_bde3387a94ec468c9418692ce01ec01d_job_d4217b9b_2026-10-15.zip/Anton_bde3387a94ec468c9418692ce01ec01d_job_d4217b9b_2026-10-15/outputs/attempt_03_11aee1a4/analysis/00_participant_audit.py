"""Audit participant identifiers, arm assignment and cohort sizes across every file
in the WU397 data package. Output: printed tables (captured to 00_participant_audit.txt)."""
import pandas as pd, numpy as np, re
pd.set_option('display.width',250); pd.set_option('display.max_columns',60); pd.set_option('display.max_rows',500)
D='/tmp/world/filesystem/'

def norm(pid):
    """normalise any participant id to integer NN"""
    s=str(pid)
    m=re.search(r'(\d+)$', s)
    return int(m.group(1))

rec=[]
def add(fname, df, pidcol, armcol='arm'):
    for (p,a) in df[[pidcol,armcol]].drop_duplicates().itertuples(index=False):
        rec.append(dict(file=fname, raw_id=str(p), pid=norm(p), arm=a))

add('elisa_igg_titers', pd.read_csv(D+'elisa_igg_titers.csv',dtype=str),'participant')
add('hai_titers', pd.read_csv(D+'hai_titers.csv',dtype=str),'participant')
add('microneutralization', pd.read_csv(D+'microneutralization.csv',dtype=str),'participant')
add('igm_fold_change', pd.read_csv(D+'igm_fold_change.csv',dtype=str),'participant')
add('binding_breadth_h1', pd.read_csv(D+'binding_breadth_h1.csv',dtype=str),'participant')
add('binding_breadth_h3', pd.read_csv(D+'binding_breadth_h3.csv',dtype=str),'participant')
add('gc_frequencies', pd.read_csv(D+'gc_frequencies.csv',dtype=str),'participant')
add('plasmablast_frequencies', pd.read_csv(D+'plasmablast_frequencies.csv',dtype=str),'participant')
n=pd.read_csv(D+'neutralization_seqbased.csv',dtype=str)
s=n.serum.str.extract(r'^(?P<arm>.+?)_(?P<participant>397-\d+)_d(?P<day>\d+)$')
add('neutralization_seqbased', s,'participant')
m=pd.read_csv(D+'mab_binding_panels.csv',dtype=str)
m['participant']=m.mab_id.str.split('.').str[1]
add('mab_binding_panels(donor)', m,'participant')
o=pd.read_csv(D+'pb_gc_clonal_overlap.csv',dtype=str)
o['arm']='?'
add('pb_gc_clonal_overlap', o,'Participant')

R=pd.DataFrame(rec)
# raw id formats per file
print('== Raw ID formats per file (examples)')
for f,g in R.groupby('file'):
    print(f'{f:28s}', sorted(set(g.raw_id), key=lambda x: norm(x))[:6], '... n=',g.pid.nunique())

# arm consistency across files
print('\n== Arm consistency: participants assigned to >1 arm across files')
arms=R[R.arm!='?'].groupby('pid').arm.unique()
conf=arms[arms.apply(len)>1]
print(conf if len(conf) else 'none')

# ID formatting anomalies
print('\n== ID formatting anomalies within files')
for f,g in R.groupby('file'):
    lens=g.raw_id.str.len().value_counts().to_dict()
    if len(lens)>1: print(f, lens, g[g.raw_id.str.len()!=g.raw_id.str.len().mode()[0]].raw_id.tolist())

# cohort sizes per file per arm
print('\n== Cohort size per file and arm')
tab=R.groupby(['file','arm']).pid.nunique().unstack(fill_value=0)
print(tab)

# arm lookup and membership matrix
armmap=R[R.arm!='?'].drop_duplicates('pid').set_index('pid').arm
M=R.assign(v=1).pivot_table(index='pid',columns='file',values='v',aggfunc='max',fill_value=0)
M.insert(0,'arm',armmap.reindex(M.index))
print('\n== Participant x file membership (1=present)')
print(M.sort_values(['arm']).to_string())

# specific cross-checks
hai=set(R[R.file=='hai_titers'].pid)
for f in ['microneutralization','igm_fold_change','binding_breadth_h1','binding_breadth_h3','neutralization_seqbased','gc_frequencies','plasmablast_frequencies','mab_binding_panels(donor)','pb_gc_clonal_overlap']:
    ids=set(R[R.file==f].pid)
    print(f'{f:28s} not-in-HAI-cohort:', sorted(ids-hai), ' HAI-cohort members missing:', sorted(hai-ids) if len(hai-ids)<10 else f'{len(hai-ids)} missing')
gc=set(R[R.file=='gc_frequencies'].pid)
print('\nplasmablast participants outside FNA (gc) subset:', sorted(set(R[R.file=='plasmablast_frequencies'].pid)-gc))
print('mAb donors:', sorted(set(R[R.file=='mab_binding_panels(donor)'].pid)), ' overlap table participants:', sorted(set(R[R.file=='pb_gc_clonal_overlap'].pid)))
print('overlap-table arms by lookup:', {p: armmap.get(p) for p in sorted(set(R[R.file=='pb_gc_clonal_overlap'].pid))})
R.to_csv('/tmp/outputs/analysis/participant_file_membership_long.csv',index=False)
M.to_csv('/tmp/outputs/analysis/participant_file_membership_matrix.csv')
