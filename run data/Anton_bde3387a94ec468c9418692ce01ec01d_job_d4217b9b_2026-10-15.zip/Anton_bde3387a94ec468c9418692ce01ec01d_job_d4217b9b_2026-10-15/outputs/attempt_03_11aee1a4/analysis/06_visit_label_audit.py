"""Cross-assay audit of the late visit (week 17 = day 121 vs week 26 = day 181) per participant."""
import pandas as pd, numpy as np, re
D='/tmp/world/filesystem/'
def nid(x): return int(re.search(r'(\d+)$',str(x)).group(1))
rows=[]
h=pd.read_csv(D+'hai_titers.csv',dtype=str); h=h[h.timepoint.isin(['wk17','wk26'])]
for (p,a,t) in h[['participant','arm','timepoint']].drop_duplicates().itertuples(index=False): rows.append(('HAI',nid(p),a,t))
m=pd.read_csv(D+'microneutralization.csv',dtype=str); m=m[(m.measure=='titer')&m.timepoint.isin(['wk17','wk26'])]
for (p,a,t) in m[['participant','arm','timepoint']].drop_duplicates().itertuples(index=False): rows.append(('MN',nid(p),a,t))
e=pd.read_csv(D+'elisa_igg_titers.csv',dtype=str); e=e[(e.measure=='ec50')&e.timepoint.isin(['wk17','wk26'])]
for (p,a,t) in e[['participant','arm','timepoint']].drop_duplicates().itertuples(index=False): rows.append(('ELISA',nid(p),a,t))
n=pd.read_csv(D+'neutralization_seqbased.csv',dtype=str)
s=n.serum.str.extract(r'^(?P<arm>.+?)_(?P<participant>397-\d+)_d(?P<day>\d+)$').drop_duplicates()
for (a,p,dd) in s.itertuples(index=False):
    if dd in ('121','181'): rows.append(('SeqNeut',nid(p),a,{'121':'wk17','181':'wk26'}[dd]))
for f in ['gc_frequencies.csv','plasmablast_frequencies.csv']:
    g=pd.read_csv(D+f,dtype=str)
    # participants with a wk17 but no wk26 record or vice versa
R=pd.DataFrame(rows,columns=['assay','pid','arm','late_visit'])
P=R.pivot_table(index=['arm','pid'],columns='assay',values='late_visit',aggfunc=lambda x: '/'.join(sorted(set(x))))
P=P[['HAI','MN','ELISA','SeqNeut']]
P['consistent']=P.apply(lambda r: len(set([v for v in r.values if isinstance(v,str)]))<=1,axis=1)
pd.set_option('display.width',200); pd.set_option('display.max_rows',200)
print(P[P.HAI.notna()|P.SeqNeut.notna()].to_string())
print('\nInconsistent participants:'); print(P[~P.consistent].to_string())
P.to_csv('/tmp/outputs/analysis/late_visit_label_audit.csv')
