"""Regulatory-style HAI quantities at wk4 (illustrative only: WU397 is non-randomised and unpowered).
GMT ratio Fluarix/mRNA-1010 (95% CI, Welch on log titers) vs NI margin 1.5; SCR difference Fluarix - mRNA-1010
(Newcombe hybrid score CI) vs NI margin 10 points; SCR/SP lower bounds vs CBER adult criteria (SCR LB>=40%, SP LB>=70%)."""
import pandas as pd, numpy as np
from scipy import stats
from statsmodels.stats.proportion import proportion_confint, confint_proportions_2indep
d=pd.read_csv('/tmp/world/filesystem/hai_titers.csv',dtype={'participant':str})
k=np.round(2*np.log2(d.hai_titer/10)); on=np.abs(2*np.log2(d.hai_titer/10)-k)<0.05
d.loc[on,'hai_titer']=10*2**(k[on]/2)
w=d.pivot_table(index=['arm','participant','antigen'],columns='timepoint',values='hai_titer').reset_index().dropna(subset=['wk0','wk4'])
w['sc']=np.where(w.wk0<10,w.wk4>=40,(np.round(np.log2(w.wk4/w.wk0),3)>=2)&(w.wk4>=40))
w['sp']=w.wk4>=40
rows=[]
for ag,g in w.groupby('antigen'):
    a=np.log(g[g.arm=='mRNA-1010'].wk4); f=np.log(g[g.arm=='Fluarix'].wk4)
    diff=f.mean()-a.mean(); se=np.sqrt(f.var()/len(f)+a.var()/len(a))
    dfw=se**4/((f.var()/len(f))**2/(len(f)-1)+(a.var()/len(a))**2/(len(a)-1)); t=stats.t.ppf(.975,dfw)
    sa=g[g.arm=='mRNA-1010'].sc; sf=g[g.arm=='Fluarix'].sc
    lo,hi=confint_proportions_2indep(sf.sum(),len(sf),sa.sum(),len(sa),method='newcomb')
    sc_lo=proportion_confint(sa.sum(),len(sa),method='wilson')[0]
    sp=g[g.arm=='mRNA-1010'].sp; sp_lo=proportion_confint(sp.sum(),len(sp),method='wilson')[0]
    rows.append(dict(antigen=ag,GMT_ratio_Flu_over_mRNA=np.exp(diff),CI=f'{np.exp(diff-t*se):.2f}-{np.exp(diff+t*se):.2f}',meets_GMT_NI_UB_le_1p5=np.exp(diff+t*se)<=1.5,
        SCR_mRNA=f'{sa.sum()}/{len(sa)}',SCR_Flu=f'{sf.sum()}/{len(sf)}',SCR_diff_Flu_minus_mRNA=f'{100*(sf.mean()-sa.mean()):.1f}',SCR_diff_CI=f'{100*lo:.1f} to {100*hi:.1f}',meets_SCR_NI_UB_le_10=100*hi<=10,
        mRNA_SCR_LB_wilson=round(100*sc_lo,1),mRNA_SP_LB_wilson=round(100*sp_lo,1)))
R=pd.DataFrame(rows); pd.set_option('display.width',250); print(R.round(2).to_string(index=False)); R.to_csv('/tmp/outputs/analysis/hai_regulatory_style.csv',index=False)
