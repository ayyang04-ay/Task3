"""Functional breadth from sequencing-based neutralisation (d0 vs d29).
Unit of analysis = participant. Censored values: 'upper' (<= value) and 'lower' (>= value) are
kept at the bound in the primary analysis (conservative for fold-change); sensitivity analyses
(i) drop censored pairs, (ii) impute upper-censored at bound/2.
Virus categories (see 05_seqneut_prep): mRNA-1010-matched wild-type/cell, Fluarix-matched,
historical (<=2021), contemporary/forward (2022-2024 isolates), reassortant/egg-adapted."""
import pandas as pd, numpy as np
from scipy import stats
import statsmodels.formula.api as smf
from statsmodels.stats.multitest import multipletests
pd.set_option('display.width',250); pd.set_option('display.max_columns',60); pd.set_option('display.max_rows',500)
d=pd.read_csv('/tmp/outputs/analysis/seqneut_annotated.csv')
d['l']=np.log2(d.titer)

def paired(d, days=(0,29), mode='bound'):
    x=d[d.day.isin(days)].copy()
    if mode=='half': x.loc[x.titer_bound=='upper','l']=np.log2(x.loc[x.titer_bound=='upper','titer']/2)
    w=x.pivot_table(index=['arm','participant','virus','subtype','category'],columns='day',values='l')
    w.columns=[int(c) for c in w.columns]; w=w.reset_index()
    b=x.pivot_table(index=['arm','participant','virus'],columns='day',values='titer_bound',aggfunc='first')
    b.columns=[f'b{int(c)}' for c in b.columns]; b=b.reset_index()
    w=w.merge(b,on=['arm','participant','virus'])
    w=w.dropna(subset=[days[0],days[1]])
    w['lfr']=w[days[1]]-w[days[0]]
    if mode=='drop':
        w=w[(w[f'b{days[0]}']=='interpolated')&(w[f'b{days[1]}']=='interpolated')]
    return w

def participant_summary(w, grp_cols, d1=29):
    return w.groupby(['arm','participant']+grp_cols).agg(l0=(0,'mean'),l1=(d1,'mean'),lfr=('lfr','mean'),nv=('virus','size')).reset_index()

def compare(ps, label):
    res=[]
    for key,g in ps.groupby([c for c in ps.columns if c not in ('arm','participant','l0','l1','lfr','nv')]):
        a=g[g.arm=='mRNA-1010']; b=g[g.arm=='Fluarix']
        if len(a)<3 or len(b)<3: continue
        g=g.assign(mrna=(g.arm=='mRNA-1010').astype(int))
        m=smf.ols('l1 ~ mrna + l0',data=g).fit()
        ci=2**m.conf_int().loc['mrna']
        res.append(dict(group=key if isinstance(key,str) else ' | '.join(map(str,key)), n_viruses=int(g.nv.max()), n_mRNA=len(a),n_Flu=len(b),
            GMT_d0_mRNA=2**a.l0.mean(),GMT_d0_Flu=2**b.l0.mean(),p_d0=stats.ttest_ind(a.l0,b.l0,equal_var=False).pvalue,
            GMT_d29_mRNA=2**a.l1.mean(),GMT_d29_Flu=2**b.l1.mean(),
            GMFR_mRNA=2**a.lfr.mean(),GMFR_Flu=2**b.lfr.mean(),GMFR_ratio=2**(a.lfr.mean()-b.lfr.mean()),
            p_GMFR=stats.ttest_ind(a.lfr,b.lfr,equal_var=False).pvalue, p_GMFR_MWU=stats.mannwhitneyu(a.lfr,b.lfr).pvalue,
            ANCOVA_GMR_d29=2**m.params['mrna'], ANCOVA_CI=f'{ci.iloc[0]:.2f}-{ci.iloc[1]:.2f}', p_ANCOVA=m.pvalues['mrna'],
            sd_lfr_pooled=np.sqrt((a.lfr.var()*(len(a)-1)+b.lfr.var()*(len(b)-1))/(len(a)+len(b)-2))))
    R=pd.DataFrame(res); print(f'\n===== {label}'); print(R.round(3).to_string(index=False)); return R

out={}
for mode in ['bound','drop','half']:
    w=paired(d, mode=mode)
    ps=participant_summary(w,['subtype','category'])
    out[mode]=compare(ps, f'[{mode}] by subtype x category (participant-level means over viruses; d29 vs d0)')
    if mode=='bound':
        ps2=participant_summary(w,['subtype'])
        out['bound_subtype']=compare(ps2,'[bound] by subtype, all viruses')
        wt=w[w.category!='reassortant/egg-adapted']
        ps3=participant_summary(wt,['subtype']); out['bound_subtype_noreass']=compare(ps3,'[bound] by subtype, excluding reassortant/egg-adapted')
        # per-virus
        rows=[]
        for (v,st,cat),g in w.groupby(['virus','subtype','category']):
            a=g[g.arm=='mRNA-1010']; b=g[g.arm=='Fluarix']
            g=g.assign(mrna=(g.arm=='mRNA-1010').astype(int), l0=g[0], l1=g[29])
            m=smf.ols('l1 ~ mrna + l0',data=g).fit()
            rows.append(dict(virus=v,subtype=st,category=cat,n_mRNA=len(a),n_Flu=len(b),
               GMT_d0_mRNA=2**a[0].mean(),GMT_d0_Flu=2**b[0].mean(),GMT_d29_mRNA=2**a[29].mean(),GMT_d29_Flu=2**b[29].mean(),
               GMFR_mRNA=2**a.lfr.mean(),GMFR_Flu=2**b.lfr.mean(),GMFR_ratio=2**(a.lfr.mean()-b.lfr.mean()),
               p_GMFR=stats.ttest_ind(a.lfr,b.lfr,equal_var=False).pvalue,
               ANCOVA_GMR=2**m.params['mrna'],p_ANCOVA=m.pvalues['mrna'],
               resp4x_mRNA=(a.lfr>=2).mean(),resp4x_Flu=(b.lfr>=2).mean()))
        PV=pd.DataFrame(rows)
        PV['q_GMFR']=multipletests(PV.p_GMFR,method='fdr_bh')[1]; PV['q_ANCOVA']=multipletests(PV.p_ANCOVA,method='fdr_bh')[1]
        PV=PV.sort_values(['subtype','category','GMFR_ratio'])
        PV.to_csv('/tmp/outputs/analysis/seqneut_per_virus.csv',index=False)
        print('\n===== per-virus (bound mode): key viruses')
        key=PV[PV.category!='contemporary/forward (2022-2024 isolates)']
        print(key.round(3).to_string(index=False))
        print('\nContemporary/forward viruses: number with GMFR_ratio>1:',(PV[PV.category.str.startswith('contemporary')].GMFR_ratio>1).sum(),'of',PV.category.str.startswith('contemporary').sum())
        print('Per-virus q<0.05 (GMFR):',(PV.q_GMFR<0.05).sum(),' (ANCOVA):',(PV.q_ANCOVA<0.05).sum())
        cont=PV[PV.category.str.startswith('contemporary')]
        print(cont.groupby('subtype')[['GMFR_mRNA','GMFR_Flu','GMFR_ratio','ANCOVA_GMR']].describe().T.round(2).to_string())
pd.concat(out,names=['analysis']).to_csv('/tmp/outputs/analysis/seqneut_category_comparisons.csv')
# Nominal significance counts per virus (baseline-adjusted ANCOVA), by subtype and category
print('\n===== per-virus nominal p<0.05 (ANCOVA) and direction, by subtype x category')
print(PV.assign(nominal=PV.p_ANCOVA<0.05, favours_mRNA=PV.ANCOVA_GMR>1).groupby(['subtype','category']).agg(
      n_viruses=('virus','size'), n_nominal_p05=('nominal','sum'), n_GMR_gt1=('favours_mRNA','sum')).to_string())
