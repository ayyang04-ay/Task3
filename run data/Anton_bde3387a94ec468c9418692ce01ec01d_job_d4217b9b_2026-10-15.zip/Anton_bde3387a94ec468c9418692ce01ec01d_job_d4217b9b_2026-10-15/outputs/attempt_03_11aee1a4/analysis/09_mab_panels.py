"""Monoclonal antibody binding panels. Binding call: fold_over_control >= 10 (sensitivity 5, 3).
Note: SARS-CoV-2 RBD column equals exactly 1.0 for every mAb (it is the normaliser), so it is not an
independent negative control. Unit of inference = donor (4 mRNA-1010 donors, 3 Fluarix donors)."""
import pandas as pd, numpy as np
from scipy import stats
import statsmodels.api as sm
import statsmodels.formula.api as smf
pd.set_option('display.width',250); pd.set_option('display.max_columns',60); pd.set_option('display.max_rows',500)
d=pd.read_csv('/tmp/world/filesystem/mab_binding_panels.csv')
d['donor']=d.mab_id.str.split('.').str[1]
d=d[d.antigen!='SARS-CoV-2 RBD']
VAC_H1='A/Victoria/4897/2022'; VAC_H3='A/Darwin/6/2021'
cls={'group_I':{'vaccine':[VAC_H1],'fluarix_matched':['A/Wisconsin/588/2019'],'forward':['A/Netherlands/01317/2025'],
                'historical':['A/California/04/2009','A/New Caledonia/20/1999','A/Puerto Rico/8/1934'],'heterosubtypic':['A/Hubei/1/2010 (H5)']},
     'group_II':{'vaccine':[VAC_H3],'fluarix_matched':[],'forward':['A/Thailand/8/2022','A/Croatia/10136RV/2023'],
                'historical':['A/Hong Kong/1/1968','A/Fujian/411/2002','A/Texas/50/2012'],'heterosubtypic':['A/Shanghai/1/2013 (H7)']}}
for THR in [10,5,3]:
    d['bind']=d.fold_over_control>=THR
    w=d.pivot_table(index=['panel','arm','donor','mab_id'],columns='antigen',values='bind',aggfunc='max')
    rows=[]
    for (pan,arm,don,mab),r in w.iterrows():
        c=cls[pan]; rr=r.dropna()
        vac=bool(rr[c['vaccine']].any())
        fw=bool(rr[c['forward']].all()); fw_any=bool(rr[c['forward']].any())
        hist_all=bool(rr[c['historical']].all())
        het=bool(rr[c['heterosubtypic']].any())
        n_sub=sum(bool(rr[a]) for a in rr.index if '(H5)' not in a and '(H7)' not in a)
        n_tot_sub=sum(1 for a in rr.index if '(H5)' not in a and '(H7)' not in a)
        rows.append(dict(panel=pan,arm=arm,donor=don,mab=mab,vaccine=vac,forward_all=fw,forward_any=fw_any,historical_all=hist_all,
                         heterosubtypic=het,any_bind=bool(rr.any()),n_intrasubtype=n_sub,frac_intrasubtype=n_sub/n_tot_sub))
    M=pd.DataFrame(rows)
    if THR==10: M.to_csv('/tmp/outputs/analysis/mab_calls_thr10.csv',index=False)
    print(f'\n######## threshold >= {THR}x')
    # mAb-level (pooled) and donor-level
    for pan in ['group_I','group_II']:
        m=M[M.panel==pan]
        print(f'\n== {pan}: pooled by arm (mAb-level; NOT independent)')
        print(m.groupby('arm')[['any_bind','vaccine','forward_all','forward_any','historical_all','heterosubtypic']].mean().round(3).assign(n=m.groupby('arm').size()))
        dl=m.groupby(['arm','donor'])[['any_bind','vaccine','forward_any','forward_all','historical_all','heterosubtypic','frac_intrasubtype']].mean().assign(n=m.groupby(['arm','donor']).size())
        print('== donor-level'); print(dl.round(3))
        # donor-level comparison among binders of vaccine strain
        b=m[m.vaccine]
        dlb=b.groupby(['arm','donor'])[['forward_all','forward_any','historical_all','heterosubtypic','frac_intrasubtype']].mean().assign(n=b.groupby(['arm','donor']).size())
        print('== donor-level, among vaccine-strain binders'); print(dlb.round(3))
        for col in ['forward_all','heterosubtypic','frac_intrasubtype']:
            a=dlb.loc['mRNA-1010',col]; f=dlb.loc['Fluarix',col] if 'Fluarix' in dlb.index.get_level_values(0) else pd.Series(dtype=float)
            if len(f)>=2:
                print(f'   {col}: donor means mRNA {a.round(3).tolist()} vs Fluarix {f.round(3).tolist()}; MWU p={stats.mannwhitneyu(a,f).pvalue:.3f}')
        # GEE-like: logistic with cluster-robust SE by donor
        if THR==10:
            for col in ['forward_all','heterosubtypic']:
                bb=b.assign(y=b[col].astype(int),mrna=(b.arm=='mRNA-1010').astype(int))
                try:
                    mod=smf.logit('y ~ mrna',data=bb).fit(disp=0,cov_type='cluster',cov_kwds={'groups':pd.factorize(bb.donor)[0]})
                    print(f'   logit {col} ~ arm (donor-clustered SE): OR={np.exp(mod.params["mrna"]):.2f} CI={np.round(np.exp(mod.conf_int().loc["mrna"].values),2)} p={mod.pvalues["mrna"]:.3f}  [only {bb.donor.nunique()} clusters]')
                except Exception as ex: print('   logit failed',ex)
