#!/usr/bin/env bash
# Re-run every analysis in order (inputs: /tmp/world/filesystem; outputs: this folder + ../figures)
set -euo pipefail
cd "$(dirname "$0")"
for s in 00_participant_audit 01_hai 02_elisa 03_mn 04_bead_breadth 05_seqneut_prep 06_visit_label_audit 07_seqneut_breadth \
         08_seqneut_durability 09_mab_panels 10_cellular_repertoire 11_igm 12_sample_size 13_binding_vs_function \
         14_naive_vs_correct 15_intercurrent_infection_screen 16_hai_regulatory_style 17_evidence_ladder 18_chim_and_misc 19_inference_checks; do
  echo "== $s"; micromamba run -n core python "$s.py" > "$s.txt" 2>&1
done
