"""How analytic choices change the apparent 'heterologous breadth' conclusion (seq-neut d29 vs d0)."""
import pandas as pd, numpy as np
from scipy import stats
import statsmodels.formula.api as smf
d=pd.read_csv('/tmp/outputs/analysis/seqneut_annotated.csv'); d['l']=np.log2(d.titer)
x=d[d.day.isin([0,29])].pivot_table(index=['arm','participant','virus','subtype','category'],columns='day',values='l')
x.columns=['d0','d29']; x=x.dropna().reset_index(); x['fr']=x.d29-x.d0; x['mrna']=(x.arm=='mRNA-1010').astype(int)
def part(sel,label):
    ps=x[sel].groupby(['arm','participant']).agg(d0=('d0','mean'),d29=('d29','mean'),fr=('fr','mean')).reset_index().assign(mrna=lambda q:(q.arm=='mRNA-1010').astype(int))
    m=smf.ols('d29 ~ mrna + d0',data=ps).fit(); a=ps[ps.mrna==1].fr; b=ps[ps.mrna==0].fr
    print(f'{label:70s} n_vir={x[sel].virus.nunique():3d} GMFR {2**a.mean():.2f} vs {2**b.mean():.2f} (ratio {2**(a.mean()-b.mean()):.2f}, p={stats.ttest_ind(a,b,equal_var=False).pvalue:.3f}) | ANCOVA GMR {2**m.params["mrna"]:.2f} [{2**m.conf_int().loc["mrna"][0]:.2f}-{2**m.conf_int().loc["mrna"][1]:.2f}] p={m.pvalues["mrna"]:.3f}')
print('--- participant as unit of analysis ---')
part(x.virus.notna(),'All 96 viruses pooled (naive)')
part(x.category!='reassortant/egg-adapted','All wild-type viruses (both subtypes)')
part(x.category.str.startswith('contemporary'),'Contemporary/forward wild-type, both subtypes')
part((x.subtype=='H3N2')&x.category.str.startswith('contemporary'),'Contemporary/forward wild-type H3N2 only (antigen-matched subtype)')
part((x.subtype=='H1N1')&x.category.str.startswith('contemporary'),'Contemporary/forward wild-type H1N1 only (antigen-MISmatched subtype)')
part((x.subtype=='H3N2')&(x.category=='historical (<=2021)'),'Historical H3N2 (back-boost)')
print('\n--- virus-serum pairs treated as independent (pseudo-replication; WRONG) ---')
for lab,sel in [('All 96 viruses',x.virus.notna()),('Contemporary H3N2',(x.subtype=='H3N2')&x.category.str.startswith('contemporary'))]:
    a=x[sel&(x.mrna==1)].fr; b=x[sel&(x.mrna==0)].fr
    print(f'{lab:30s} n_pairs={len(a)}+{len(b)} GMFR ratio {2**(a.mean()-b.mean()):.2f}, Welch p={stats.ttest_ind(a,b,equal_var=False).pvalue:.2e}')
