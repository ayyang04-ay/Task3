"""Microneutralisation (homologous / heterologous panels as designated relative to mRNA-1010 antigens).
Ceiling (1280) and floor (10) handling; GMT, GMFR, >=4-fold responders; censoring-aware sensitivity."""
import pandas as pd, numpy as np
from scipy import stats
import statsmodels.formula.api as smf
pd.set_option('display.width',250); pd.set_option('display.max_columns',60); pd.set_option('display.max_rows',500)
d=pd.read_csv('/tmp/world/filesystem/microneutralization.csv')
t=d[d.measure=='titer'].pivot_table(index=['arm','participant','panel'],columns='timepoint',values='value').reset_index()
t['late']=t.wk26.fillna(t.wk17)
print('distinct titers:',sorted(d[d.measure=="titer"].value.unique()))
CEIL=1280
out=[]
for pan in ['homologous','heterologous']:
    for arm in ['mRNA-1010','Fluarix']:
        s=t[(t.panel==pan)&(t.arm==arm)]
        f4=np.log2(s.wk4/s.wk0); fL=np.log2(s.late/s.wk0)
        out.append(dict(panel=pan,arm=arm,n=len(s),GMT0=2**np.log2(s.wk0).mean(),GMT4=2**np.log2(s.wk4).mean(),
           GMFR4=2**f4.mean(),resp4x_wk4=f'{(f4>=2).sum()}/{len(s)}',GMFRlate=2**fL.mean(),
           at_ceiling_wk0=f'{(s.wk0>=CEIL).sum()}/{len(s)}',at_ceiling_wk4=f'{(s.wk4>=CEIL).sum()}/{len(s)}',
           base_ge_320=f'{(s.wk0>=320).sum()}/{len(s)}',
           max_possible_GMFR=2**np.log2(CEIL/s.wk0).mean()))
T=pd.DataFrame(out); print(T.round(2).to_string(index=False)); T.to_csv('/tmp/outputs/analysis/mn_summary.csv',index=False)

print('\n== Arm comparisons')
for pan in ['homologous','heterologous']:
    s=t[t.panel==pan].copy(); s['l0']=np.log2(s.wk0); s['l4']=np.log2(s.wk4); s['f4']=s.l4-s.l0; s['mrna']=(s.arm=='mRNA-1010').astype(int)
    a=s[s.mrna==1]; b=s[s.mrna==0]
    m=smf.ols('l4 ~ mrna + l0',data=s).fit()
    print(pan,'baseline GMT ratio',round(2**(a.l0.mean()-b.l0.mean()),2),'p',round(stats.ttest_ind(a.l0,b.l0,equal_var=False).pvalue,3),
          '| GMFR ratio',round(2**(a.f4.mean()-b.f4.mean()),2),'p',round(stats.ttest_ind(a.f4,b.f4,equal_var=False).pvalue,3),
          '| MWU p',round(stats.mannwhitneyu(a.f4,b.f4).pvalue,3),
          '| ANCOVA GMR wk4',round(2**m.params['mrna'],2), 'CI',np.round(2**m.conf_int().loc['mrna'].values,2),'p',round(m.pvalues['mrna'],3))
# sensitivity: exclude participants at ceiling at baseline in either panel
print('\n== Sensitivity: drop participants with baseline >= ceiling (no room to rise)')
for pan in ['homologous','heterologous']:
    s=t[(t.panel==pan)&(t.wk0<CEIL)].copy(); s['f4']=np.log2(s.wk4/s.wk0)
    a=s[s.arm=='mRNA-1010']; b=s[s.arm=='Fluarix']
    print(pan,'n',len(a),len(b),'GMFR',round(2**a.f4.mean(),2),round(2**b.f4.mean(),2),'p',round(stats.ttest_ind(a.f4,b.f4,equal_var=False).pvalue,3))
# hetero/homologous ratio within person at wk4 (a within-person breadth index)
w=t.pivot_table(index=['arm','participant'],columns='panel',values=['wk0','wk4'])
r=pd.DataFrame({'het_hom_ratio_wk0':np.log2(w[('wk0','heterologous')]/w[('wk0','homologous')]),
                'het_hom_ratio_wk4':np.log2(w[('wk4','heterologous')]/w[('wk4','homologous')])})
g=r.groupby(level='arm').agg(lambda x: 2**x.mean())
print('\n== Geometric mean heterologous:homologous titer ratio'); print(g.round(2))
# individual anomalies
print('\n== Participants with MN titers at assay floor (<=15) at all timepoints'); print(t[(t[['wk0','wk4']].max(axis=1)<=15)][['arm','participant','panel','wk0','wk4','late']])
