"""ELISA IgG EC50: baseline comparability, GMT, GMFR at wk4 and late (wk17/26), arm comparisons
(Welch on log2, ANCOVA adjusting for baseline), and baseline-vs-fold-rise relationship."""
import pandas as pd, numpy as np
from scipy import stats
import statsmodels.formula.api as smf
pd.set_option('display.width',250); pd.set_option('display.max_columns',60); pd.set_option('display.max_rows',500)
d=pd.read_csv('/tmp/world/filesystem/elisa_igg_titers.csv',dtype={'participant':str})
e=d[d.measure=='ec50'].pivot_table(index=['arm','participant','antigen'],columns='timepoint',values='value').reset_index()
e['late']=e.wk26.fillna(e.wk17)
gm=lambda x: float(np.exp(np.mean(np.log(np.asarray(x,float)))))
out=[]
for ag in ['A/H1','A/H3','B/Vic','B/Yam']:
    s=e[e.antigen==ag].copy()
    s['l0']=np.log2(s.wk0); s['l4']=np.log2(s.wk4); s['lL']=np.log2(s.late); s['f4']=s.l4-s.l0; s['fL']=s.lL-s.l0
    s['mrna']=(s.arm=='mRNA-1010').astype(int)
    a=s[s.mrna==1]; b=s[s.mrna==0]
    m4=smf.ols('l4 ~ mrna + l0',data=s).fit(); mL=smf.ols('lL ~ mrna + l0',data=s).fit()
    ci4=2**m4.conf_int().loc['mrna']; ciL=2**mL.conf_int().loc['mrna']
    # proportion with >=4-fold rise
    out.append(dict(antigen=ag,n_mRNA=len(a),n_Flu=len(b),
        GMT0_mRNA=gm(a.wk0),GMT0_Flu=gm(b.wk0),p_base=stats.ttest_ind(a.l0,b.l0,equal_var=False).pvalue,
        GMFR4_mRNA=2**a.f4.mean(),GMFR4_Flu=2**b.f4.mean(),
        GMFR4_ratio=2**(a.f4.mean()-b.f4.mean()), p_GMFR4=stats.ttest_ind(a.f4,b.f4,equal_var=False).pvalue,
        ANCOVA_GMR4=2**m4.params['mrna'],ANCOVA_GMR4_CI=f'{ci4.iloc[0]:.2f}-{ci4.iloc[1]:.2f}',p_ANCOVA4=m4.pvalues['mrna'],
        pct4x_mRNA=f"{(a.f4>=2).sum()}/{len(a)}", pct4x_Flu=f"{(b.f4>=2).sum()}/{len(b)}",
        GMFRlate_mRNA=2**a.fL.mean(),GMFRlate_Flu=2**b.fL.mean(),p_GMFRlate=stats.ttest_ind(a.fL,b.fL,equal_var=False).pvalue,
        ANCOVA_GMRlate=2**mL.params['mrna'],ANCOVA_GMRlate_CI=f'{ciL.iloc[0]:.2f}-{ciL.iloc[1]:.2f}',
        retained_late_over_wk4_mRNA=2**(a.lL-a.l4).mean(), retained_late_over_wk4_Flu=2**(b.lL-b.l4).mean(),
        rho_base_vs_fold=stats.spearmanr(s.l0,s.f4).correlation))
T=pd.DataFrame(out)
print(T.round(3).T.to_string())
T.to_csv('/tmp/outputs/analysis/elisa_summary.csv',index=False)

# Subset restricted to HAI cohort (participants 1-32) vs the expansion cohort (33-102): is effect consistent?
print('\n== ELISA GMFR wk4 by enrolment block (IDs <=32 = serology sub-study cohort; >32 = additional ELISA-only participants)')
e['pid']=e.participant.astype(int); e['block']=np.where(e.pid<=32,'core(<=32)','extra(>32)')
e['f4']=np.log2(e.wk4/e.wk0)
print(e.groupby(['antigen','arm','block']).f4.agg(n='size',GMFR=lambda x: 2**x.mean()).round(2).unstack('block').to_string())
