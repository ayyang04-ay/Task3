"""Bead-array binding breadth (log2 fold-change MFI; timepoint not stated in file).
Per-strain arm comparison; strains annotated by relationship to each arm's vaccine antigen."""
import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width',250); pd.set_option('display.max_columns',60); pd.set_option('display.max_rows',500)
ann={ # relationship of each strain to the vaccine antigens (public WHO strain history; see answer.md)
 'A/Puerto Rico/8/1934':'historical (pre-1957 seasonal H1)',
 'A/California/04/2009':'historical pdm09 prototype',
 'A/Michigan/45/2015':'historical pdm09 (2017-19 vaccine strain)',
 'A/Brisbane/2/2018':'historical pdm09 (2019-20 vaccine strain)',
 'A/Hawaii/70/2019':'historical pdm09 (2020-21 cell/rec vaccine strain)',
 'A/Guangdong-Maonan/SWL1536/2019':'historical pdm09 (2020-21 egg vaccine strain)',
 'A/Wisconsin/588/2019':'Fluarix-matched H1 (2021-23 cell/rec counterpart of A/Victoria/2570/2019)',
 'A/Sydney/5/2021':'2022-23 era pdm09 (5a.2 lineage)',
 'A/Wisconsin/67/2022':'mRNA-1010-matched H1 (2023-24 cell/rec counterpart of A/Victoria/4897/2022)',
 'A/Hong Kong/1/1968':'historical H3 (1968 pandemic)',
 'A/Brisbane/10/2007':'historical H3 vaccine strain (2008-10)',
 'A/Perth/16/2009':'historical H3 vaccine strain (2010-12)',
 'A/Victoria/361/2011':'historical H3 vaccine strain (2012-13)',
 'A/Texas/50/2012':'historical H3 vaccine strain (2013-15)',
 'A/Switzerland/8060/2017':'historical H3 (2019-20 vaccine strain era)',
 'A/Singapore/INFIMH-16-0019/2016':'historical H3 vaccine strain (2018-19)',
 'A/South Australia/34/2019':'historical H3 (2019-20 era)',
 'A/Hong Kong/2671/2019':'historical H3 vaccine strain (2020-21 egg)',
 'A/Cambodia/e0826360/2020':'historical H3 vaccine strain (2021-22)',
 'A/Darwin/6/2021':'vaccine-matched H3 (mRNA-1010 antigen; Fluarix carries egg A/Darwin/9/2021)',
 'A/Thailand/8/2022':'forward-drifted H3 (2024-25 egg vaccine strain)'}
out=[]
for sub,f in [('H1','binding_breadth_h1.csv'),('H3','binding_breadth_h3.csv')]:
    d=pd.read_csv('/tmp/world/filesystem/'+f)
    for st,g in d.groupby('strain'):
        a=g[g.arm=='mRNA-1010'].log2_fold_change_mfi; b=g[g.arm=='Fluarix'].log2_fold_change_mfi
        out.append(dict(subtype=sub,strain=st,relationship=ann.get(st,'?'),n_mRNA=len(a),n_Flu=len(b),
            GMFR_mRNA=2**a.mean(),GMFR_Flu=2**b.mean(),ratio=2**(a.mean()-b.mean()),
            diff_log2=a.mean()-b.mean(),p_welch=stats.ttest_ind(a,b,equal_var=False).pvalue,p_MWU=stats.mannwhitneyu(a,b).pvalue,
            resp2x_mRNA=f'{(a>=1).sum()}/{len(a)}',resp2x_Flu=f'{(b>=1).sum()}/{len(b)}'))
T=pd.DataFrame(out)
# BH-FDR across all strains
from statsmodels.stats.multitest import multipletests
T['q_BH']=multipletests(T.p_welch,method='fdr_bh')[1]
print(T.round(3).to_string(index=False))
T.to_csv('/tmp/outputs/analysis/bead_breadth_per_strain.csv',index=False)
# participant-level breadth: mean log2FC across non-vaccine-matched strains
for sub,f,excl in [('H1','binding_breadth_h1.csv',['A/Wisconsin/67/2022','A/Wisconsin/588/2019']),('H3','binding_breadth_h3.csv',['A/Darwin/6/2021'])]:
    d=pd.read_csv('/tmp/world/filesystem/'+f)
    p=d[~d.strain.isin(excl)].groupby(['arm','participant']).log2_fold_change_mfi.mean()
    a=p['mRNA-1010']; b=p['Fluarix']
    print(f'\n{sub}: participant-level mean log2FC over strains excluding vaccine-matched {excl}: mRNA {a.mean():.2f} (GMFR {2**a.mean():.2f}) vs Flu {b.mean():.2f} (GMFR {2**b.mean():.2f}); Welch p={stats.ttest_ind(a,b,equal_var=False).pvalue:.4f}; MWU p={stats.mannwhitneyu(a,b).pvalue:.4f}')
