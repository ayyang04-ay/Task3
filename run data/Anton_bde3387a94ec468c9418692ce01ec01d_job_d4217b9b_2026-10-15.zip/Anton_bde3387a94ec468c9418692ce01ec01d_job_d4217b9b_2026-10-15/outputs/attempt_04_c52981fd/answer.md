**Recommendation:** Don't take a heterologous-protection claim forward on WU397 — next run a randomised, observer-blind, composition-matched immunogenicity study (mRNA-1010 vs same-season egg-based and non-egg licensed vaccines, stratified by age and prior vaccination) whose primary endpoint is the baseline-adjusted neutralising GMT ratio against a locked panel of wild-type strains heterologous to both vaccines (H3N2 first, durability to day 181), and gate an event-driven relative-efficacy trial against RT-PCR-confirmed, antigenically mismatched influenza on its result.

# WU397: what to do next, and why

**Scope.** This covers study design, endpoints, populations, comparators, readouts and interpretation of the WU397 data package. It contains no assay or bench procedures.

**How to read the sources.** Every number carries a source tag such as [HAI] or [SN-P]. §6 maps each tag to the input file, the analysis script and the output table under `/tmp/outputs/analysis/`. Facts that do not come from the data package are tagged [EXT-n] and listed in §7; check them against the lot documentation.

---

## 1. Bottom line

1. **The data show stronger immunogenicity, not broader protection.**
   - mRNA-1010 induces more binding antibody and larger germinal-centre responses than Fluarix.
   - The package does **not** show broader *functional* antibody against drifted strains.
   - Nothing in it measures protection.

2. **H3N2 is the only fair test in the package, and it is null.**
   - Both arms received a Darwin/2021-like H3: mRNA-1010 encodes A/Darwin/6/2021 [TS], and Fluarix 2022–23 contained an A/Darwin/9/2021-like H3 [EXT-1].
   - Across 68 contemporary (2022–24) H3N2 viruses, the baseline-adjusted day-29 neutralising GMT ratio (mRNA-1010/Fluarix) was **1.17 (95% CI 0.64–2.11)** [SN-P].
   - Against mRNA-1010's *own* H3 antigen, A/Darwin/6/2021, the ratio was **0.62 (0.34–1.12)** [SN-P].
   - Not one of the 68 contemporary H3 viruses had a CI excluding 1. Point estimates ranged from 0.82 to 1.51 [SN-V].

3. **The "heterologous" advantages that appear in the package are design artefacts.** There are four:
   - **Fold-rise from a lower starting point.** The mRNA arm started lower on 82 of 83 H3 viruses. Its fold-rise was therefore higher on 78 of 83, but its day-29 titre was higher on only 20 of 83 [BP].
     - The one assay labelled "heterologous", microneutralisation, shows the same pattern. Fold-rise was 4.12 vs 3.03 in mRNA-1010's favour. But baseline GMT was 57 vs 121 and day-29 GMT was 235 vs 368, both favouring Fluarix. The adjusted ratio was 1.17 (0.52–2.62) [MN].
   - **Binding is not function.** In the same 27 people, the H3 binding-IgG rise was 8.0× vs 2.2×, but the neutralising rise was only 2.8× vs 2.2×. Per unit of binding antibody, mRNA-1010 sera neutralised about 2.8-fold less (p = 0.0013) [BF].
   - **The two arms received different H1 strains.**
     - mRNA-1010's H1 was A/Victoria/4897/2022 [TS].
     - Fluarix 2022–23 carried an A/Victoria/2570/2019-like H1 [EXT-1].
     - The 2023 "heterologous" H1 viruses are closer to the mRNA antigen [EXT-7]. So the H1 lead (2.06×, 1.23–3.46) [SN-P] cannot be read as breadth.
   - **"Heterologous" was defined against mRNA-1010 only [TS].** As a result, egg-adapted reassortants, 2012–2019 strains and the comparator's own strains all counted as "heterologous".
     - The only 4 H3 viruses on which mRNA-1010 won significantly are exactly these: 2012–2019 strains or egg reassortants [SN-V].
     - That pattern is back-boosting of old responses, not forward breadth.

4. **The one functional lead did not last.**
   - The H1 neutralisation advantage fell from 2.06× at day 29 to **1.15× (0.75–1.76) at day 121–181** [SN-D].
   - Late HAI ratios were 0.83–1.06 and late microneutralisation ratios 0.64–0.73 [LATE].

5. **B-lineage responses were negligible, and the homologous basics are not yet secured.**
   - mRNA-1010 HAI seroconversion was 0 of 13 for B/Victoria and 0 of 14 for B/Yamagata (Fluarix 7% for each) [HAI].
   - Any breadth claim therefore has to clear homologous non-inferiority on B/Victoria first.

6. **WU397 could not have answered the question.**
   - With 13 vs 14 participants it could detect only about a **2.15-fold** difference on the H3 panel [BP].
   - It therefore neither shows nor excludes a 1.5-fold benefit.
   - That justifies one properly built randomised study before committing to an efficacy trial of roughly 60,000–100,000 participant-seasons [BP].

---

## 2. Recommended next studies

### 2.0 Before the protocol goes to committee (existing data, no new participants)

If these are not resolved, they carry straight into the new protocol and SAP. Details are in §5.

- **Confirm the composition actually administered.**
  - mRNA-1010: obtain the lot's encoded HA sequences and certificate of analysis.
  - Fluarix: check the lot's labelling.
  - Reason: the mRNA arm's H1 response peaked on the **2019-lineage** strain, not the stated 2022 antigen [H1C].
- **Name the viruses behind the HAI and microneutralisation labels.** The files say only "A/H1N1", "A/H3N2", "homologous" and "heterologous".
  - My exploratory inference: HAI-H1 tracks the egg reassortant A/Victoria/4897/2022 IVR-238, and both microneutralisation readouts are H3N2 [ID].
- **Fix the data files:**
  - label the two unlabelled value sets in the GC file;
  - state whether "plasmablast" was measured in blood or lymph node;
  - reconcile the visit labels across files;
  - correct the stated IgM cohort size [INT].

### 2.1 Study A — randomised, composition-matched functional-breadth study (go/no-go for the claim)

**Conditions**

| Item | Specification |
|---|---|
| **Design** | <ul><li>Randomised 1:1:1, observer-blind, active-controlled, multicentre.</li><li>Every site enrols **every arm concurrently**, within one compressed pre-season window.</li><li>Every arm receives a single intramuscular dose on D1, as in WU397.</li><li>Contrast with WU397, which allocated by site: IDs 33–59 were all Fluarix and IDs 64–102 all mRNA-1010 [INT].</li></ul> |
| **Arms (against what)** | <ul><li>**A:** mRNA-1010.</li><li>**B:** the licensed egg-based standard-dose inactivated vaccine of the same season (Fluarix), for continuity with WU397.</li><li>**C:** a licensed **non-egg** vaccine of the same season: cell-culture IIV in 18–64 y, recombinant HA in ≥65 y. Arm C separates a platform effect from the effect of simply avoiding egg adaptation.</li><li>In ≥65 y, arm B becomes the age-preferred enhanced egg-based vaccine (high-dose or adjuvanted).</li></ul> |
| **Composition** | <ul><li>All arms carry the WHO-recommended strains for the **same season and hemisphere**.</li><li>mRNA-1010 encodes the HA sequences of the cell/recombinant-recommended strains.</li><li>Trivalent: drop B/Yamagata [EXT-3]. In WU397 the B/Yamagata HAI response was negligible anyway (GMFR 1.35 vs 1.29) [HAI].</li></ul> |
| **Population (in whom)** | <ul><li>Healthy adults, stratified 18–49 / 50–64 / ≥65 y.</li><li>Also stratified by documented vaccination in the previous season.</li><li>Where feasible, also stratify by screening HAI to the H3 vaccine strain (<1:40 vs ≥1:40); otherwise adjust for it in the analysis.</li><li>Record birth year.</li><li>Exclude influenza vaccination in the past 6 months and confirmed influenza earlier in the current season.</li><li>Power the ≥65 stratum separately if the claim is meant to cover older adults.</li></ul> |
| **Conduct of readouts** | <ul><li>Laboratories are blinded to arm and visit; each participant's samples are tested together.</li><li>Functional readouts are run in **all** participants, or in a randomly pre-selected subset, never in convenience subsets. (WU397 ran functional assays in 29 of 75 participants, chosen by sample availability [TS].)</li></ul> |
| **Visits** | <ul><li>D1 (pre-dose), D29 (primary), D91, D181 (end of season; key secondary), optionally D366.</li><li>Fixed visit windows. Visits at different intervals are never pooled; WU397 pooled day 121 with day 181 [TS].</li></ul> |
| **Intercurrent infection** | <ul><li>Surveillance for RT-PCR-confirmed influenza-like illness throughout.</li><li>Infected participants are censored from later immunogenicity time points.</li></ul> |
| **Size** | <ul><li>Breadth endpoint: about 140–150 evaluable per arm, per age stratum that is to carry a claim (about 175 randomised per arm). Basis: GMT ratio 1.5, SD up to 1.5 log2, one-sided α = 0.025, 90% power [BP].</li><li>If Study A must also serve as the licensure-style HAI non-inferiority study (seroconversion margin −10 points), about 530 evaluable per arm [BP].</li></ul> |

**Readouts — what is measured, in whom, against what**

| Role | What is measured | In whom | Against what | When |
|---|---|---|---|---|
| **Primary** | Neutralising antibody: each participant's mean log titre across panel strains; baseline-adjusted GMT ratio, A vs B | All per-protocol participants | **Locked H3N2 panel of wild-type (non-egg-adapted) viruses heterologous to both products** (specification below) | D1, D29 |
| Key secondary 1–2 (fixed sequence) | Same endpoint | Same | Locked H1N1 panel, then locked B/Victoria panel | D1, D29 |
| Key secondary 3 | Same endpoint (durability) | Same | All three panels | D181 (and D91) |
| Key secondary 4 | Same endpoint, A vs C (platform vs egg adaptation) | Same | All three panels | D29, D181 |
| Breadth score | Per participant: share of panel strains with a ≥4-fold rise, and share above a pre-set titre | Same | All three panels | D29, D181 |
| Safeguard (non-inferiority) | HAI GMT ratio (lower bound ≥ 0.67) and seroconversion difference (lower bound ≥ −10 points) [EXT-4] | Same | Each **vaccine-matched wild-type** strain | D1, D29, D181 |
| Secondary | Neuraminidase-inhibition titres. mRNA-1010 is HA-only [TS, EXT-6], whereas inactivated comparators contain some NA, and anti-NA immunity contributes to cross-protection | All, or a random subset of ≥100 per arm | Contemporary N1 and N2 | D1, D29, D181 |
| Descriptive only, outside the heterologous endpoint | Neutralisation | Same | Egg-adapted forms of the vaccine strains; historical strains | D1, D29 |
| Forward panel | Neutralisation on banked sera | Same | Viruses emerging after vaccination, added by a pre-specified rule (each subsequent WHO vaccine strain; any clade above a set frequency) | D29 and D181 sera |
| Exploratory only | Binding IgG to full-length HA, HA head and HA stem | Subset | Same panels | D1, D29, D181 |
| Optional mechanistic | Plasmablast, memory B-cell and (optionally) lymph-node responses. Monoclonals tested for **neutralising** breadth. **Donor is the unit of analysis**, ≥15 donors per arm, identical selection rules in every arm | Randomised subset | Same panels | D8, D29, D181 |
| Safety | Solicited reactions D1–7; unsolicited AEs to D29; SAEs, AESIs and MAAEs to D181 | All | — | — |

**Panel specification**

- **Size and content:** for each subtype or lineage, at least 10–15 wild-type viruses.
- **Heterologous to both products:** each virus must be antigenically distinct from the vaccine strains of **both** products, i.e.
  - at least 8-fold reduced reactivity with reference antisera to the vaccine strain [EXT-5], **and**
  - a different genetic clade.
- **Weighting:** toward clades circulating at the time of vaccination and in the following season.
- **Lock date:** before the first vaccination.
- **Exclusions:** egg-adapted reassortants, historical strains and either product's own strains are excluded from the endpoint and reported separately.
  - In WU397, egg-adapted viruses read **1.4–7.5-fold higher** than their wild-type counterparts in both arms [SN-E].
- **Assay range:** the quantifiable range must cover post-vaccination titres.
  - In WU397, 9 of 15 Fluarix day-29 microneutralisation titres (homologous panel) sat at the 1:1280 ceiling [MN].

**Analysis**

- Use ANCOVA on log titres, adjusting for baseline titre to the same virus, age stratum, prior vaccination and site.
- Handle values outside the quantifiable range with a censored-data likelihood.
- Test in fixed sequence: H3 → H1 → B/Victoria → D181 → A vs C.
- Report fold-rise descriptively only.

**Pre-specified decision rules**

- **Go to Study B** only if all of the following hold:
  - on the H3 panel at D29, the A/B GMT ratio has a lower 95% bound >1.0. The study is powered for a true ratio of 1.5; at the planned precision, clearing this bound requires an observed ratio of about 1.2–1.3 or more [BP];
  - the D181 point estimate is ≥1.0;
  - HAI non-inferiority is met for every component, B/Victoria included. In WU397, 0 of 13 mRNA recipients seroconverted to B/Victoria [HAI];
  - A is not worse than C on the H3 panel.
- **Stop or re-scope the claim** if the upper 95% bound of the H3 D29 ratio is below 1.5.
  - A benefit confined to H1, or shared equally with arm C, supports a narrower "better match to wild-type virus" claim, not heterologous protection.
- **If timelines force overlap:** Study A can be embedded as the first-season randomised immunogenicity cohort of Study B, with the same decision rules applied as an interim futility gate.

### 2.2 Study B — relative-efficacy trial with a mismatched-strain endpoint (the study that can carry the claim)

No accepted immune correlate exists for protection against drifted strains. A *protection* claim therefore needs clinical endpoints.

**Conditions**

- Randomised 1:1, observer-blind, event-driven.
- Comparator: licensed, age-appropriate vaccine for the same season.
  - 50–64 y: standard-dose.
  - ≥65 y: the preferred enhanced vaccine.
- Multinational, covering both hemispheres. Run over ≥2 seasons if needed to accrue mismatched cases, because mismatch seasons cannot be predicted.
- Each season, the vaccine is given as a single dose with that season's composition, and results are analysed by season.
- **Both arms take the strain recommendation issued at the same time.** If mRNA-1010 were allowed a later strain update, the trial would test speed of update, not breadth. WU397's sponsor-selected newer H1 is exactly that confound.

**Population (in whom)**

- Adults ≥50 y, or the intended label population.
- Stratified by age (50–64 / ≥65), prior-season vaccination and region.
- Include people with chronic conditions.

**Readouts**

| Role | What is measured | In whom | Against what |
|---|---|---|---|
| Primary | First RT-PCR-confirmed, protocol-defined influenza-like illness from **any** strain, from D15 to end of season. Relative vaccine efficacy (rVE): non-inferiority (lower bound >−10%), then superiority | Per-protocol efficacy set | Licensed comparator |
| **Key secondary (carries the claim)** | RT-PCR-confirmed illness caused by strains **antigenically mismatched** to the vaccine strains. rVE superiority (lower bound >0). Tested first in the alpha-controlled hierarchy after the primary; pooled across seasons as pre-specified | Same | Same |
| Case classification rule | For every case virus: HA sequencing plus antigenic characterisation against the vaccine strains. A blinded committee assigns matched/mismatched using an algorithm locked before unblinding | All cases | Vaccine strains |
| Secondary | Mismatched cases by subtype/lineage; influenza hospitalisation and severe disease; medically attended influenza; rVE by month since vaccination (waning) | All | Comparator |
| Correlates sub-cohort | HAI and neutralising titres at D1, D29 and D181. Tests whether titre against the infecting strain predicts protection | Random sub-cohort plus all cases (case-cohort design) | Vaccine strains and representative case viruses |
| Safety | Standard safety follow-up | All | Comparator |

**Size**

- Superiority on mismatched cases at a true rVE of 25% (one-sided α = 0.025, 90% power) needs about **511 mismatched cases** [BP].
  - At a 2% seasonal attack rate, with 30–50% of cases mismatched, that means about **58,000–97,000 participant-seasons** [BP].
- Non-inferiority on any-strain cases needs about **287 cases** [BP].
- Plan the trial as event-driven and multi-season.

### 2.3 Optional supporting studies

- **Controlled human infection study.** A proof-of-concept; it does not replace Study B.
  - Design: randomised, double-blind; mRNA-1010 vs licensed comparator of the same composition (± placebo).
  - In whom: healthy adults aged 18–45 with low pre-existing titres to the challenge virus.
  - Against what: a GMP wild-type challenge virus that is antigenically heterologous to both vaccines.
  - Readouts: laboratory-confirmed infection; symptomatic infection; viral-load AUC; pre-challenge neutralising titre against the challenge virus.
  - Limits: the population is not representative, and challenge strains lag circulating strains.
- **Mechanistic sub-study** inside Study A (see the readouts table above).
  - It replaces WU397's unbalanced cellular data, in which **79%** of the comparator's monoclonals came from one donor [MAB].
  - Its results are explanatory, not evidence of protection.
- **Heterosubtypic (H5/H7) claims.** The H5/H7 binding seen in a few monoclonals falls outside a seasonal claim. Pursuing it would need separate studies.

### 2.4 What the new protocol must not carry over from WU397

- Allocation by site, or different strain compositions in the two arms.
- A "heterologous" label defined against one product only.
- Fold-rise or binding antibody used as primary evidence.
- Pooled day-121/day-181 visits.
- Egg-adapted or historical strains inside heterologous endpoints.
- Assay ceilings that fall within the response range.
- A B/Yamagata component.
- Cellular or monoclonal arm comparisons based on 3–6 donors per arm.

---

## 3. Reasoning: what WU397 does and does not show

### 3.1 Design and composition

- **Study design** [TS]:
  - Open-label and non-randomised; participants were allocated by site.
  - Assay cohort sizes (mRNA-1010/Fluarix):

    | Readout | mRNA-1010 | Fluarix |
    |---|---|---|
    | Binding | 38 | 37 |
    | HAI, microneutralisation, bead array | 14 | 15 |
    | Sequencing-based neutralisation | 13 | 14 |
    | Lymph-node aspiration | 6 | 11 |

- **Enrolment pattern** [INT]:
  - IDs 1–32 interleave the two arms.
  - IDs 33–59 are **all Fluarix**; IDs 64–102 are **all mRNA-1010**.
- **The enrolment block moves the results** [EL]:
  - Within the concurrently enrolled block (IDs 1–32), the B-strain binding advantage disappears: B/Vic 1.35 → 0.96; B/Yam 1.38 → 1.01.
  - The H1 and H3 binding advantages persist in that block (2.10 and 3.19).
- **The arms were not strain-matched:**
  - **H1.** mRNA-1010 used A/Victoria/4897/2022 [TS]; Fluarix used an A/Victoria/2570/2019-like strain [EXT-1]. The nearest wild-type analogues on the panels are A/Wisconsin/67/2022 and A/Wisconsin/588/2019 respectively [EXT-2].
  - **H3.** mRNA-1010 used A/Darwin/6/2021 [TS], the cell-based 2022–23 recommendation; Fluarix used the egg-based A/Darwin/9/2021 [EXT-1, EXT-2].
- **The mRNA arm's H1 response is skewed toward the 2019 lineage** [H1C]:
  - In mRNA-1010 recipients, the fold-rise was 6.15× against A/Wisconsin/588/2019 but 3.51× against A/Wisconsin/67/2022. This held in 12 of 13 participants (p = 0.003).
  - The skew was larger than in Fluarix recipients (1.38×; between-arm p = 0.049).
  - Among monoclonals, 70% from mRNA donors vs 55% from Fluarix donors bound A/Wisconsin/588/2019 at least 2× more strongly than A/Victoria/4897/2022.
  - Possible explanations are back-boosting of 2019-lineage memory or a documentation error. Either way, confirm the composition (§2.0).

### 3.2 Baseline imbalance and the fold-rise artefact

- **Across all 83 H3 viruses** [BP]:
  - The mRNA arm's day-0 GMT was lower on 82 of 83 (median ratio 0.69).
  - Its fold-rise was higher on 78 of 83.
  - Its day-29 GMT was higher on only 20 of 83.
- **Pooled over the 68 contemporary H3 viruses** [SN-P]:

  | Measure | mRNA-1010 | Fluarix |
  |---|---|---|
  | Baseline GMT | 143 | 214 |
  | Day-29 GMT | 401 | 465 |
  | Fold-rise | 2.80 | 2.17 |

  The unadjusted day-29 ratio is 0.86; the baseline-adjusted ratio is 1.17 (0.64–2.11; p = 0.60).
- **Microneutralisation, the only readout labelled heterologous**, follows the same pattern [MN]:
  - Baseline GMT 57 vs 121 (p = 0.057).
  - Fold-rise 4.12 vs 3.03, favouring mRNA-1010.
  - Day-29 GMT 235 vs 368, favouring Fluarix.
  - Adjusted ratio 1.17 (0.52–2.62).

### 3.3 Binding overstates function for H3

- **Binding readouts all favour mRNA-1010 strongly:**
  - ELISA IgG, full cohort (38 vs 37): adjusted ratio 2.66 (2.01–3.53) for H1 and 3.31 (2.47–4.43) for H3 [EL].
  - Bead-array breadth: on average, 11.2 vs 4.5 of 12 H3 strains and 6.8 vs 2.5 of 9 H1 strains showed a ≥2-fold rise [BB].
- **The same viruses show no neutralising advantage:**

  | Virus | Binding fold-rise, mRNA-1010 vs Fluarix | Neutralising GMT ratio (mRNA-1010/Fluarix) |
  |---|---|---|
  | A/Thailand/8/2022 | 31.9× vs 3.4× [BB] | 0.82 (0.35–1.91) [SN-V] |
  | A/Darwin/6/2021 | 26.2× vs 4.3× [BB] | 0.62 [SN-P] |

- **Same 27 people, H3** [BF]:

  | Readout | mRNA-1010 | Fluarix |
  |---|---|---|
  | Binding fold-rise | 8.0× | 2.2× |
  | Neutralising fold-rise, contemporary strains | 2.8× | 2.2× |
  | Neutralising fold-rise, A/Darwin/6/2021 | 2.2× | 2.7× |
  | HAI fold-rise | 1.6× | 1.7× |

  - Binding and neutralisation tracked each other in Fluarix recipients (ρ = 0.73) but not in mRNA recipients (ρ = 0.31).
- **H1 behaves differently:** the binding advantage does carry into function [BF].
  - Binding fold-rise 4.9× vs 2.1×; neutralising fold-rise 4.1× vs 1.9×.
  - The function-per-binding difference between arms was not significant (p = 0.34).

### 3.4 Functional results by subtype

- **HAI at day 29** [HAI]:

  | Subtype | Adjusted ratio (95% CI) | Seroconversion, mRNA-1010 | Seroconversion, Fluarix |
  |---|---|---|---|
  | H1 | 1.54 (0.87–2.71) | 50% | 33% |
  | H3 | 1.06 (0.67–1.66) | 14% | 13% |
  | B/Victoria | 1.05 (0.71–1.56) | 0% | 7% |
  | B/Yamagata | 1.01 (0.73–1.40) | 0% | 7% |

- **Sequencing-based neutralisation, H3** [SN-P, SN-V]:
  - 68 contemporary viruses: 1.17 (0.64–2.11).
  - The three 2024 isolates: 0.98 (0.41–2.32).
  - A/Darwin/6/2021: 0.62 (0.34–1.12). A censored-data (Tobit) sensitivity analysis gives 0.62 (0.37–1.05) [SN-T].
  - Only four H3 viruses had a CI above 1. All are 2012–2019 strains or egg reassortants:

    | Virus | Adjusted ratio (95% CI) |
    |---|---|
    | A/Texas/50/2012 | 1.83 (1.23–2.74) |
    | A/Hong Kong/2671/2019 | 2.06 (1.29–3.30) |
    | A/Cambodia/e0826360/2020-egg | 1.84 (1.04–3.25) |
    | A/Switzerland/9715293/2013 NIB-88 | 1.87 (1.07–3.26) |

  - The five egg-adapted reassortants pooled: 1.51 (1.03–2.22).
  - Share of contemporary strains with a ≥4-fold rise: 28% vs 24% (p = 0.36) [SN-B].
- **Sequencing-based neutralisation, H1** [SN-P, SN-V]:
  - Six 2023 viruses pooled: 2.06 (1.23–3.46). Every one of them had a CI excluding 1, with point estimates of 1.93–2.29.
  - A/Wisconsin/67/2022: 2.07 (1.26–3.39).
  - A/Wisconsin/588/2019, the comparator's own analogue: 2.44 (1.18–5.05).
  - Share with a ≥4-fold rise: 53% vs 13% (p = 0.006) [SN-B].
  - Because the lead also holds against the comparator's own strain, it looks like a larger H1 response overall rather than breadth. It is also confounded by the composition mismatch.
- **Microneutralisation** [MN, ID]. Both readouts appear, on exploratory correlation, to be H3N2:
  - homologous: 0.68 (0.31–1.51);
  - heterologous: 1.17 (0.52–2.62).

### 3.5 Durability

- **Sequencing-based neutralisation at day 121–181, adjusted** [SN-D]:
  - H1 contemporary: **1.15 (0.75–1.76)**. mRNA-1010 recipients kept 43% of their day-29 titre; Fluarix recipients kept 78%.
  - H3 contemporary: 1.04 (0.65–1.67).
- **HAI, late visit** [LATE]: H1 0.83 (0.47–1.46); H3 0.92; B/Victoria 1.06; B/Yamagata 0.91.
- **Microneutralisation, late visit** [LATE]: 0.64 (homologous) and 0.73 (heterologous).
- **ELISA IgG, share of week-4 level retained at the late visit** [EL]: 42–46% with mRNA-1010 vs 74–76% with Fluarix.

### 3.6 Cellular, repertoire and monoclonal data: mechanism, not claim

- **Germinal-centre B cells** (first value set in the GC file) [GC]:
  - Week 2: median 24.2% vs 2.3% (n = 6 vs 11; p = 0.037).
  - Week 26: 18.9% vs 1.6% (n = 5 vs 8; p = 0.34).
- **Serum IgG repertoire** (8 per arm; not linkable to participants) [GC]:
  - Vaccine-elicited clonotypes: 32 vs 17.5 (p = 0.066).
  - Week-4 CDRH3 diversity: 70.8 vs 24.5 (p = 0.010).
  - Pre-existing clonotypes still made up 87% vs 89% of serum abundance.
- **The GC response is largely recall** [GC]: in mRNA donors, 73–92% of GC clones overlapped week-1 plasmablast clones.
- **Monoclonals** [MAB]:
  - 589 vs 106 antibodies, from 4 vs 3 donors; one Fluarix donor supplied 84 of the 106.
  - Donor-level share binding A/Hong Kong/1/1968: 0.48 vs 0.05. The p-value of 0.029 is the smallest achievable with 4 vs 3 donors.
  - H7 binding: 0.11 vs 0.00.
  - A/California/04/2009 binding favoured Fluarix: 0.68 vs 0.42.
  - These are binding data only.

### 3.7 Power

- WU397's minimum detectable GMT ratio on the H3 pool was **2.15** (80% power) [BP].
- The residual SD on that pool, 1.02 log2 [SN-P], was used to size Study A [BP].

---

## 4. Figures

- `figures/seqneut_forest_by_strain.png`: baseline-adjusted day-29 GMT ratio for each of the 96 viruses, coloured by relationship to the two vaccines.
- `figures/seqneut_pooled_classes.png`: pooled participant-level contrasts by strain class.
- `figures/binding_vs_function.png`: binding vs neutralising vs HAI fold-rises in the same participants.

---

## 5. Data-integrity findings to resolve before reuse

1. **GC file.**
   - `gc_frequencies.csv` contains two **unlabelled** measurements for each of 78 participant-visit keys [INT].
   - It has a "wk0" label, although the FNA schedule is weeks 1, 2, 4, 8, 17 and 26 [TS].
   - Weeks 1 and 4 are absent [INT].
2. **Plasmablast file.** It is unclear whether `plasmablast_frequencies.csv` comes from blood or lymph node:
   - it uses FNA-type visits (weeks 2 and 8);
   - it covers 13/15 participants, more than the 6/11 FNA cohort;
   - values reach 4.7% at week 26 [INT, GC].
3. **Visit labels disagree across files and antigens.**
   - HAI late-visit labels for B/Victoria differ from the other three antigens for 8 participants: Fluarix 007, 009, 016, 018; mRNA-1010 008, 010, 021, 023.
   - Sequencing-based neutralisation places 397-007 and 397-011 at day 121; HAI and microneutralisation place them at week 26 [HAI, INT].
   - The "wk17/26" tables mix day 121 and day 181 [TS].
4. **IgM.**
   - The file holds 14/15 participants, not the 38/37 given in the summary table [TS, INT].
   - Fluarix participant 397-005 shows 166–212-fold rises to all four antigens [IGM].
5. **Unnamed antigens and missing metadata.**
   - HAI and microneutralisation do not name their viruses.
   - The bead-array file has no visit label and no baseline MFI [TS].
6. **Formatting.**
   - Participant IDs appear in three formats: `397-06`, `397-006` and `20`.
   - One virus name is malformed: `A/SOUTHAFRICA/R07876/202023` (treated here as 2023).
   - The repertoire files carry no participant IDs [INT].
7. **Arm assignment is consistent** across all files: 0 conflicts [INT].

---

## 6. Source key

All input files are in `/tmp/world/filesystem/`. All scripts and outputs are in `/tmp/outputs/analysis/`.

| Tag | Input file(s) | Script | Output tables |
|---|---|---|---|
| TS | trial_summary.md | — | — |
| INT | all files | 00_integrity.py | participant_map.csv, 00_integrity.out.txt |
| HAI | hai_titers.csv | 01_hai.py | hai_summary.csv, hai_ancova.csv |
| MN | microneutralization.csv | 02_mn.py | mn_summary.csv, mn_ancova.csv |
| EL | elisa_igg_titers.csv | 03_elisa_igm.py (block split: 08_site_block.py) | elisa_summary.csv, elisa_ancova.csv, 08_site_block.out.txt |
| IGM | igm_fold_change.csv | 03_elisa_igm.py | 03_elisa_igm.out.txt |
| BB | binding_breadth_h1.csv, binding_breadth_h3.csv | 04_binding_breadth.py | binding_breadth_by_strain.csv |
| GC | gc_frequencies.csv, plasmablast_frequencies.csv, pb_gc_clonal_overlap.csv, serum_igg_clonotypes.csv, cdrh3_diversity_index.csv, repertoire_clonotype_counts.csv | 05_cellular_repertoire.py | 05_cellular_repertoire.out.txt |
| SN-V | neutralization_seqbased.csv | 06_seqneut.py | seqneut_per_virus.csv, seqneut_virus_classification.csv |
| SN-P / SN-B / SN-E / SN-D / SN-T | neutralization_seqbased.csv | 07_seqneut_pooled.py | seqneut_pooled_by_class.csv / seqneut_breadth.csv / seqneut_egg_vs_wt_pairs.csv / seqneut_durability.csv / seqneut_tobit_sensitivity.csv |
| BF | elisa_igg_titers.csv, hai_titers.csv, neutralization_seqbased.csv | 09_binding_vs_function.py | binding_vs_function_same_people.csv |
| MAB | mab_binding_panels.csv | 10_mab.py | mab_donor_level.csv |
| H1C | neutralization_seqbased.csv, mab_binding_panels.csv, binding_breadth_h1.csv | 11_h1_composition_check.py | 11_h1_composition_check.out.txt |
| BP | outputs of 06/07, hai_titers.csv | 12_baseline_power.py | sample_size_immunogenicity.csv, sample_size_efficacy.csv, 12_baseline_power.out.txt |
| LATE | hai_titers.csv, microneutralization.csv | 13_late_durability.py | hai_mn_late_visit.csv |
| ID | hai_titers.csv, microneutralization.csv, neutralization_seqbased.csv | 14_identify_unlabelled_panels.py | 14_identify_unlabelled_panels.out.txt |

---

## 7. External facts (not in the package — verify)

- **EXT-1. Fluarix 2022–23 Northern Hemisphere composition.** This follows WHO's February 2022 egg-based recommendation:
  - A/Victoria/2570/2019 (H1N1)pdm09-like
  - A/Darwin/9/2021 (H3N2)-like
  - B/Austria/1359417/2021-like
  - B/Phuket/3073/2013-like
- **EXT-2. Cell-based counterparts on the panels.**
  - A/Wisconsin/588/2019 is the cell-based counterpart of A/Victoria/2570/2019.
  - A/Wisconsin/67/2022 is the cell-based counterpart of A/Victoria/4897/2022.
  - A/Darwin/6/2021 (cell) and A/Darwin/9/2021 (egg) are the 2022–23 H3 recommendations.
- **EXT-3. B/Yamagata.** WHO has recommended removing B/Yamagata from seasonal vaccines because the lineage has not been confirmed in circulation since 2020.
- **EXT-4. Non-inferiority criteria.** These are the conventional US criteria for seasonal inactivated vaccine immunogenicity: lower bound of the GMT ratio ≥ 0.67, and lower bound of the seroconversion difference ≥ −10 percentage points.
- **EXT-5. Antigenic distinctness threshold.** The conventional threshold for "antigenically distinct" in reference-antiserum testing is a reduction of 8-fold or more.
- **EXT-6. mRNA-1010 is HA-only.** Public descriptions state that mRNA-1010 encodes HA only. The package says only that it "encodes four antigens".
- **EXT-7. H1 lineages.** H1N1pdm09 viruses circulating in 2023 descend from the 6B.1A.5a.2a/5a.2a.1 lineage, which includes A/Victoria/4897/2022 (5a.2a.1). A/Victoria/2570/2019 and A/Wisconsin/588/2019 belong to the parental 5a.2 clade. In the data, Fluarix recipients' day-29 titres against the 2023 H1 viruses were about half their titre against A/Wisconsin/588/2019 (seqneut_per_virus.csv), which is consistent with this.

## 8. Method notes and limitations

- **Arm contrasts** use ANCOVA on log2 titres, adjusted for baseline titre.
  - Pooled sequencing-based neutralisation contrasts take each participant's mean titre across the strains in a class, so the participant is the unit of analysis.
  - P-values are descriptive: this is a post hoc re-analysis of a non-randomised study with 13–15 participants per arm in the functional cohorts.
- **Strain classes** (contemporary / historical / egg-adapted) are based on isolation year and the reassortant designations named in trial_summary.md.
- **Vaccine "analogues"** depend on EXT-1 and EXT-2.
- **Monoclonal binding** was called at ≥5-fold over control, which sits at the trough of a bimodal distribution. Thresholds of 3 and 10 were run as sensitivity analyses (mab_donor_level.csv).
- **Sample sizes are planning figures**, taken from the variances observed in WU397 and from assumed attack rates and mismatch shares (sample_size_*.csv). Final sizing should use the locked panel and current epidemiology.
