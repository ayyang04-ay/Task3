"""Does the serological fingerprint of the mRNA-1010 arm match its stated H1 (A/Victoria/4897/2022, clade 5a.2a.1)?
Compare per-participant fold-rise against A/Wisconsin/588/2019 (5a.2; cell analogue of the comparator's A/Victoria/2570/2019)
versus A/Wisconsin/67/2022 (5a.2a.1; cell analogue of A/Victoria/4897/2022)."""
import pandas as pd, numpy as np
from scipy import stats
sn=pd.read_csv('/tmp/world/filesystem/neutralization_seqbased.csv')
s=sn.serum.str.split('_',expand=True); sn['arm']=s[0]; sn['pid']=s[1]; sn['day']=s[2]; sn['lt']=np.log2(sn.titer)
w=sn.pivot_table(index=['arm','pid'],columns=['virus','day'],values='lt')
def fr(v): return w[(v,'d29')]-w[(v,'d0')]
x=pd.DataFrame({'FR_588':fr('A/Wisconsin/588/2019_H1N1'),'FR_67':fr('A/Wisconsin/67/2022_H1N1'),'FR_IVR238':fr('A/Victoria/4897/2022_IVR-238_H1N1'),
                'd29_588':w[('A/Wisconsin/588/2019_H1N1','d29')],'d29_67':w[('A/Wisconsin/67/2022_H1N1','d29')]})
x['FR588_minus_FR67']=x.FR_588-x.FR_67
x['d29_588_minus_67']=x.d29_588-x.d29_67
for arm,g in x.groupby(level='arm'):
    t=stats.wilcoxon(g.FR588_minus_FR67)
    print(f'{arm}: GMFR vs Wis/588/2019 = {2**g.FR_588.mean():.2f}; vs Wis/67/2022 = {2**g.FR_67.mean():.2f}; vs Vic/4897 IVR-238 = {2**g.FR_IVR238.mean():.2f}; '
          f'within-person ratio (588/67) = {2**g.FR588_minus_FR67.mean():.2f}, Wilcoxon p={t.pvalue:.3f}; n={len(g)}; '
          f'n with larger rise to 588 = {(g.FR588_minus_FR67>0).sum()}; d29 titre ratio 588/67 = {2**g.d29_588_minus_67.mean():.2f}')
a=x.loc['mRNA-1010'].FR588_minus_FR67; b=x.loc['Fluarix'].FR588_minus_FR67
print('Between-arm difference in (588 minus 67) fold-rise: mRNA %.2f vs Fluarix %.2f log2; MW p=%.3f'%(a.mean(),b.mean(),stats.mannwhitneyu(a,b).pvalue))
# mAb panel: binding magnitude to Vic/4897/2022 vs Wis/588/2019 among group-I mAbs
m=pd.read_csv('/tmp/world/filesystem/mab_binding_panels.csv')
m=m[m.antigen.isin(['A/Victoria/4897/2022','A/Wisconsin/588/2019'])].pivot_table(index=['arm','mab_id'],columns='antigen',values='fold_over_control')
m['log2_ratio_Vic4897_over_Wis588']=np.log2(m['A/Victoria/4897/2022'].clip(lower=0.5))-np.log2(m['A/Wisconsin/588/2019'].clip(lower=0.5))
print(m.groupby(level='arm')['log2_ratio_Vic4897_over_Wis588'].agg(['count','mean','median']).round(2))
print('mAbs binding Vic/4897 >=2x more strongly than Wis/588:',(m.log2_ratio_Vic4897_over_Wis588>=1).groupby(level='arm').mean().round(2).to_dict(),
      '  Wis/588 >=2x more than Vic/4897:',(m.log2_ratio_Vic4897_over_Wis588<=-1).groupby(level='arm').mean().round(2).to_dict())
# bead array
for f in ['binding_breadth_h1.csv']:
    b=pd.read_csv('/tmp/world/filesystem/'+f)
    bb=b[b.strain.isin(['A/Wisconsin/588/2019','A/Wisconsin/67/2022'])].pivot_table(index=['arm','participant'],columns='strain',values='log2_fold_change_mfi')
    bb['diff']=bb['A/Wisconsin/588/2019']-bb['A/Wisconsin/67/2022']
    print('bead array: mean log2FC(588) - log2FC(67):',bb.groupby(level='arm')['diff'].mean().round(2).to_dict())
