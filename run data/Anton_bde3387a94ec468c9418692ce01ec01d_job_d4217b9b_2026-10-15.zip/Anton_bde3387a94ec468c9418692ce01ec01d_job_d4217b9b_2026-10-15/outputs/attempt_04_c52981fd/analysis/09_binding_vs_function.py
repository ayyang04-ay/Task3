"""Within-person binding vs function: ELISA IgG fold-rise vs HAI / seq-neut fold-rise (same 27-29 people).
Shows how much of the binding advantage carries into neutralisation."""
import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width',250); pd.set_option('display.max_columns',40)
el=pd.read_csv('/tmp/world/filesystem/elisa_igg_titers.csv'); el=el[el.measure=='fold_change']
el=el[el.timepoint=='wk4'].assign(pid=lambda x:x.participant.astype(int)).pivot_table(index='pid',columns='antigen',values='value')
hai=pd.read_csv('/tmp/world/filesystem/hai_titers.csv',dtype={'participant':str}); hai['pid']=hai.participant.astype(int)
hw=hai.pivot_table(index=['pid','arm'],columns=['antigen','timepoint'],values='hai_titer')
hfr=pd.DataFrame({ag:hw[(ag,'wk4')]/hw[(ag,'wk0')] for ag in ['A/H1N1','A/H3N2','B/Vic','B/Yam']})
sn=pd.read_csv('/tmp/world/filesystem/neutralization_seqbased.csv')
s=sn.serum.str.split('_',expand=True); sn['arm']=s[0]; sn['pid']=s[1].str[-3:].astype(int); sn['day']=s[2]
sn['lt']=np.log2(sn.titer)
def fr(mask):
    x=sn[mask].pivot_table(index=['pid','virus'],columns='day',values='lt'); x=(x.d29-x.d0).groupby(level='pid').mean(); return 2**x
cls=pd.read_csv('/tmp/outputs/analysis/seqneut_virus_classification.csv')
h3c=set(cls[(cls.subtype=='H3N2')&(cls.cls=='contemporary drifted (2022-24)')].virus); h1c=set(cls[(cls.subtype=='H1N1')&(cls.cls=='contemporary drifted (2022-24)')].virus)
X=hfr.reset_index().set_index('pid')
X['ELISA_H1_FR']=el['A/H1']; X['ELISA_H3_FR']=el['A/H3']
X['SN_H3drift_FR']=fr(sn.virus.isin(h3c)); X['SN_H1drift_FR']=fr(sn.virus.isin(h1c)); X['SN_Darwin6_FR']=fr(sn.virus=='A/Darwin/6/2021_H3N2')
X=X.dropna(subset=['SN_H3drift_FR'])
G=X.groupby('arm')[['ELISA_H1_FR','SN_H1drift_FR','A/H1N1','ELISA_H3_FR','SN_H3drift_FR','SN_Darwin6_FR','A/H3N2']].agg(lambda v:np.exp(np.log(v).mean()))
print('Geometric-mean fold-rises, same participants (seq-neut cohort, n=13 mRNA / 14 Fluarix):'); print(G.round(2).to_string())
G.round(3).to_csv('/tmp/outputs/analysis/binding_vs_function_same_people.csv')
for arm,g in X.groupby('arm'):
    r1=stats.spearmanr(np.log2(g.ELISA_H3_FR),np.log2(g.SN_H3drift_FR)); r2=stats.spearmanr(np.log2(g.ELISA_H1_FR),np.log2(g.SN_H1drift_FR))
    print(arm,'Spearman ELISA-H3 FR vs seqneut H3 drift FR rho=%.2f p=%.3f ; H1 rho=%.2f p=%.3f'%(r1.correlation,r1.pvalue,r2.correlation,r2.pvalue))
# ratio of function to binding fold-rise
X['H3_func_per_binding']=np.log2(X.SN_H3drift_FR)-np.log2(X.ELISA_H3_FR)
X['H1_func_per_binding']=np.log2(X.SN_H1drift_FR)-np.log2(X.ELISA_H1_FR)
for c in ['H3_func_per_binding','H1_func_per_binding']:
    a=X[X.arm=='mRNA-1010'][c]; b=X[X.arm=='Fluarix'][c]
    print(c,'mRNA %.2f vs Flu %.2f (log2 units)  MW p=%.4f'%(a.mean(),b.mean(),stats.mannwhitneyu(a,b).pvalue))
