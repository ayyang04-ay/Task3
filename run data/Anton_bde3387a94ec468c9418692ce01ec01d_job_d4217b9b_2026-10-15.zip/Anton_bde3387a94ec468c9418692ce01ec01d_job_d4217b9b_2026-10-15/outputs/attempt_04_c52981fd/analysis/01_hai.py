"""HAI titres: GMT, GMFR, seroconversion, seroprotection, baseline-adjusted arm contrast.
Source: /tmp/world/filesystem/hai_titers.csv"""
import pandas as pd, numpy as np
from scipy import stats
import statsmodels.formula.api as smf
pd.set_option('display.width',250); pd.set_option('display.max_rows',500); pd.set_option('display.max_columns',50)
d=pd.read_csv('/tmp/world/filesystem/hai_titers.csv',dtype={'participant':str})
d['participant']=d.participant.str.zfill(3)
d['lt']=np.log2(d.hai_titer)
# pooled late visit as in the source tables
d['tp']=d.timepoint.replace({'wk17':'wk17/26','wk26':'wk17/26'})
w=d.pivot_table(index=['antigen','arm','participant'],columns='tp',values='lt')
out=[]
for (ag,arm),g in w.groupby(level=['antigen','arm']):
    b=g['wk0']; p=g['wk4']; late=g['wk17/26']
    fr=(p-b).dropna()
    row=dict(antigen=ag,arm=arm,n_wk0=b.notna().sum(),GMT_wk0=2**b.mean(),GMT_wk4=2**p.mean(),GMFR_wk4=2**fr.mean(),
             GMT_late=2**late.mean(), n_late=late.notna().sum(),
             SCR_wk4=np.mean(((p-b)>=2-1e-9)&(2**p>=40)), n_pair=fr.size,
             SPR_wk0=np.mean(2**b>=40), SPR_wk4=np.mean(2**p.dropna()>=40))
    out.append(row)
o=pd.DataFrame(out)
print(o.round(2).to_string())
o.round(3).to_csv('/tmp/outputs/analysis/hai_summary.csv',index=False)
# arm contrast: ANCOVA log2(wk4) ~ arm + log2(wk0)
res=[]
for ag,g in w.groupby(level='antigen'):
    gg=g.reset_index().dropna(subset=['wk0','wk4'])
    m=smf.ols('wk4 ~ C(arm, Treatment("Fluarix")) + wk0',data=gg).fit()
    k=[x for x in m.params.index if 'mRNA' in x][0]
    ci=m.conf_int().loc[k]
    # unadjusted wk0 difference
    t0=stats.ttest_ind(gg[gg.arm=='mRNA-1010'].wk0,gg[gg.arm=='Fluarix'].wk0)
    mw=stats.mannwhitneyu(gg[gg.arm=='mRNA-1010'].wk4-gg[gg.arm=='mRNA-1010'].wk0, gg[gg.arm=='Fluarix'].wk4-gg[gg.arm=='Fluarix'].wk0)
    res.append(dict(antigen=ag,adj_GMT_ratio_mRNA_vs_Flu=2**m.params[k],lo=2**ci[0],hi=2**ci[1],p=m.pvalues[k],
                    baseline_ratio=2**(gg[gg.arm=='mRNA-1010'].wk0.mean()-gg[gg.arm=='Fluarix'].wk0.mean()),p_baseline=t0.pvalue, p_MW_foldrise=mw.pvalue,n=len(gg)))
r=pd.DataFrame(res); print(r.round(3).to_string()); r.round(4).to_csv('/tmp/outputs/analysis/hai_ancova.csv',index=False)
# visit-label consistency check across antigens
v=d[d.timepoint.isin(['wk17','wk26'])].pivot_table(index=['arm','participant'],columns='antigen',values='timepoint',aggfunc='first')
print(v.to_string())
