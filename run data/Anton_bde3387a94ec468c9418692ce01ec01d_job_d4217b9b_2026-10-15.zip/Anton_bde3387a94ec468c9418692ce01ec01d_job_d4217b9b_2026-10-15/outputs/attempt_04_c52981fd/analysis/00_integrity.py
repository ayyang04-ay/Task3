"""Cross-file integrity checks: participant IDs, arm assignment consistency, visit labels, cohort sizes vs trial_summary.md"""
import pandas as pd, numpy as np, re
pd.set_option('display.width',250); pd.set_option('display.max_rows',500); pd.set_option('display.max_columns',60)
F='/tmp/world/filesystem/'
def norm(x):
    x=str(x)
    m=re.search(r'(\d+)$',x.split('-')[-1] if '-' in x else x)
    return int(m.group(1))
maps={}
def add(name,df,pcol,acol='arm'):
    for p,a in df[[pcol,acol]].drop_duplicates().itertuples(index=False):
        maps.setdefault(norm(p),{})[name]=a
hai=pd.read_csv(F+'hai_titers.csv',dtype=str); add('HAI',hai,'participant')
mn=pd.read_csv(F+'microneutralization.csv',dtype=str); add('MN',mn,'participant')
el=pd.read_csv(F+'elisa_igg_titers.csv',dtype=str); add('ELISA',el,'participant')
ig=pd.read_csv(F+'igm_fold_change.csv',dtype=str); add('IgM',ig,'participant')
b1=pd.read_csv(F+'binding_breadth_h1.csv',dtype=str); add('BeadH1',b1,'participant')
b3=pd.read_csv(F+'binding_breadth_h3.csv',dtype=str); add('BeadH3',b3,'participant')
gc=pd.read_csv(F+'gc_frequencies.csv',dtype=str); add('GC',gc,'participant')
pb=pd.read_csv(F+'plasmablast_frequencies.csv',dtype=str); add('PB/LNPC',pb,'participant')
sn=pd.read_csv(F+'neutralization_seqbased.csv',dtype=str)
sn['arm']=sn.serum.str.split('_').str[0]; sn['participant']=sn.serum.str.split('_').str[1]; add('SeqNeut',sn,'participant')
mab=pd.read_csv(F+'mab_binding_panels.csv',dtype=str); mab['participant']=mab.mab_id.str.split('.').str[1]; add('mAb',mab,'participant')
ov=pd.read_csv(F+'pb_gc_clonal_overlap.csv',dtype=str)
for p in ov.Participant: maps.setdefault(norm(p),{})['PB-GC overlap']='(no arm column)'
M=pd.DataFrame(maps).T.sort_index()
M['conflict']=M.apply(lambda r: len(set(v for v in r.dropna() if v!='(no arm column)'))>1,axis=1)
print(M.fillna('').to_string())
print('arm conflicts:',M.conflict.sum())
M.to_csv('/tmp/outputs/analysis/participant_map.csv')
# counts per assay and arm vs trial summary
cnt={k:M[k].value_counts().to_dict() for k in M.columns if k not in ('conflict','PB-GC overlap')}
print(pd.DataFrame(cnt).T)
# ID format anomalies
for name,df,col in [('IgM',ig,'participant'),('GC',gc,'participant'),('PB',pb,'participant'),('HAI',hai,'participant')]:
    bad=df[~df[col].str.fullmatch(r'\d{3}')][col].unique()
    print(name,'non-3-digit IDs:',bad)
print('PB-GC overlap IDs:',list(ov.Participant))
# visits
print('GC timepoints:',sorted(gc.timepoint.unique()),' PB timepoints:',sorted(pb.timepoint.unique()))
# duplicated keys in GC file
k=gc.groupby(['timepoint','arm','participant']).size()
print('GC rows per key:',k.value_counts().to_dict())
