"""Monoclonal antibody binding panels: donor-level cross-reactivity (unit = donor, not mAb)."""
import pandas as pd, numpy as np, itertools
from scipy import stats
pd.set_option('display.width',250); pd.set_option('display.max_rows',500); pd.set_option('display.max_columns',50)
d=pd.read_csv('/tmp/world/filesystem/mab_binding_panels.csv')
d['donor']=d.mab_id.str.split('.').str[1]
d=d[d.antigen!='SARS-CoV-2 RBD']
THR=5  # fold-over-control threshold; trough of bimodal distribution lies between ~3 and ~6; 3 and 10 as sensitivity
res=[]
for thr in [3,5,10]:
    b=d.assign(bind=d.fold_over_control>=thr).pivot_table(index=['panel','arm','donor','mab_id'],columns='antigen',values='bind')
    for p in ['group_I','group_II']:
        bb=b.loc[p].dropna(axis=1,how='all')
        don=bb.groupby(level=['arm','donor']).mean()
        n=bb.groupby(level=['arm','donor']).size()
        for ag in bb.columns:
            x=don[ag]
            mr=x.loc['mRNA-1010'].values; fl=x.loc['Fluarix'].values
            # exact permutation test on donor-level means (4 vs 3 donors -> 35 splits)
            allv=np.r_[mr,fl]; obs=mr.mean()-fl.mean(); cnt=0; tot=0
            for idx in itertools.combinations(range(len(allv)),len(mr)):
                m=allv[list(idx)].mean(); f=np.delete(allv,list(idx)).mean(); tot+=1; cnt+= (abs(m-f)>=abs(obs)-1e-12)
            res.append(dict(threshold=thr,panel=p,antigen=ag,mAb_level_mRNA=bb.loc['mRNA-1010'][ag].mean(),mAb_level_Flu=bb.loc['Fluarix'][ag].mean(),
                            donor_means_mRNA=';'.join(f'{v:.2f}' for v in mr),donor_means_Flu=';'.join(f'{v:.2f}' for v in fl),
                            donor_avg_mRNA=mr.mean(),donor_avg_Flu=fl.mean(),perm_p_two_sided=cnt/tot,
                            n_mabs_mRNA=int(n.loc['mRNA-1010'].sum()),n_mabs_Flu=int(n.loc['Fluarix'].sum())))
R=pd.DataFrame(res); R.round(3).to_csv('/tmp/outputs/analysis/mab_donor_level.csv',index=False)
print(R[R.threshold==5].round(2).to_string())
# donor contributions
print(d.drop_duplicates('mab_id').groupby(['arm','donor']).size())
# breadth per mAb: number of antigens bound within panel (threshold 5)
b=d.assign(bind=d.fold_over_control>=THR).pivot_table(index=['panel','arm','donor','mab_id'],columns='antigen',values='bind')
for p in ['group_I','group_II']:
    bb=b.loc[p].dropna(axis=1,how='all'); nb=bb.sum(axis=1)
    print(p,'antigens bound per mAb (of %d): '%bb.shape[1]); print(nb.groupby(level=['arm','donor']).agg(['mean','median']).round(2))
    # heterosubtypic binders (H5 or H7)
    het=[c for c in bb.columns if '(H5)' in c or '(H7)' in c][0]
    print(' heterosubtypic',het, bb[het].groupby(level=['arm','donor']).agg(['sum','count']).T.to_string())
# mAbs in both panels
both=set(d[d.panel=='group_I'].mab_id)&set(d[d.panel=='group_II'].mab_id)
x=d[d.mab_id.isin(both)].pivot_table(index=['arm','mab_id'],columns='antigen',values='fold_over_control')
print('mAbs tested on both panels:',len(both)); print(x.round(1).to_string())
