"""Cellular / repertoire readouts: GC, PB/LNPC, clonal overlap, serum IgG clonotypes, CDRH3 diversity, pre-existing vs vaccine-elicited.
Sources: gc_frequencies.csv, plasmablast_frequencies.csv, pb_gc_clonal_overlap.csv, serum_igg_clonotypes.csv, cdrh3_diversity_index.csv, repertoire_clonotype_counts.csv"""
import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width',250); pd.set_option('display.max_rows',500); pd.set_option('display.max_columns',50)
F='/tmp/world/filesystem/'
gc=pd.read_csv(F+'gc_frequencies.csv',dtype={'participant':str})
gc['block']=np.where(gc.index<gc.shape[0]//2,'block1(rows 2-79)','block2(rows 80-157)')
print(gc.groupby(['block','timepoint','arm']).pct_ha_specific_igg_gc.agg(['count','median','mean','max']).round(2).to_string())
for blk,g in gc.groupby('block'):
    for tp in ['wk2','wk8','wk17','wk26']:
        a=g[(g.timepoint==tp)&(g.arm=='mRNA-1010')].pct_ha_specific_igg_gc; b=g[(g.timepoint==tp)&(g.arm=='Fluarix')].pct_ha_specific_igg_gc
        print(blk,tp,'median mRNA %.2f (n=%d) vs Flu %.2f (n=%d)  MW p=%.3f'%(a.median(),len(a),b.median(),len(b),stats.mannwhitneyu(a,b).pvalue))
pb=pd.read_csv(F+'plasmablast_frequencies.csv',dtype={'participant':str})
print(pb.groupby(['timepoint','arm']).pct_plasmablast.agg(['count','median','mean','max']).round(3).to_string())
for tp in ['wk2','wk8','wk17','wk26']:
    a=pb[(pb.timepoint==tp)&(pb.arm=='mRNA-1010')].pct_plasmablast; b=pb[(pb.timepoint==tp)&(pb.arm=='Fluarix')].pct_plasmablast
    print('PB',tp,'median mRNA %.3f (n=%d) vs Flu %.3f (n=%d) MW p=%.3f'%(a.median(),len(a),b.median(),len(b),stats.mannwhitneyu(a,b).pvalue))
ov=pd.read_csv(F+'pb_gc_clonal_overlap.csv')
print(ov.iloc[:,[0,2,4,5,8,9]].to_string())
sc=pd.read_csv(F+'serum_igg_clonotypes.csv'); cd=pd.read_csv(F+'cdrh3_diversity_index.csv')
print(sc.groupby(['timepoint','arm']).n_clonotypes.agg(['count','median','mean']).round(1))
print(cd.groupby(['timepoint','arm']).diversity_index.agg(['count','median','mean']).round(1))
for tp in ['wk0','wk4','wk26']:
    for nm,df,col in [('clonotypes',sc,'n_clonotypes'),('CDRH3 div',cd,'diversity_index')]:
        a=df[(df.timepoint==tp)&(df.arm=='mRNA-1010')][col]; b=df[(df.timepoint==tp)&(df.arm=='Fluarix')][col]
        print(nm,tp,'mRNA median %.1f vs Flu %.1f MW p=%.3f'%(a.median(),b.median(),stats.mannwhitneyu(a,b).pvalue))
rc=pd.read_csv(F+'repertoire_clonotype_counts.csv')
for met,g in rc.groupby('metric'):
    a=g[g.arm=='mRNA-1010'].value; b=g[g.arm=='Fluarix'].value
    print(met,'mRNA median %.1f (n=%d) vs Flu median %.1f (n=%d) MW p=%.3f'%(a.median(),len(a),b.median(),len(b),stats.mannwhitneyu(a,b).pvalue))
# link: n_pre_existing_clonotypes equals wk0 serum clonotype counts?
pre=rc[rc.metric=='n_pre_existing_clonotypes']
for arm in ['mRNA-1010','Fluarix']:
    print(arm,'pre-existing:',list(pre[pre.arm==arm].value.astype(int)),' wk0 serum clonotypes:',list(sc[(sc.timepoint=='wk0')&(sc.arm==arm)].n_clonotypes))
    print(arm,'vaccine-elicited:',list(rc[(rc.metric=='n_vaccine_elicited_clonotypes')&(rc.arm==arm)].value.astype(int)))
    print(arm,'wk4 serum clonotypes:',list(sc[(sc.timepoint=='wk4')&(sc.arm==arm)].n_clonotypes))
