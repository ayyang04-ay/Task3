"""Pooled (participant-level) seq-neut contrasts by strain class; breadth; egg-vs-wild-type pairs; durability; Tobit sensitivity.
Unit of analysis = participant (per-participant mean log2 titre across the strains in a class) to avoid pseudo-replication."""
import pandas as pd, numpy as np, re
from scipy import stats, optimize
import statsmodels.formula.api as smf
pd.set_option('display.width',250); pd.set_option('display.max_rows',500); pd.set_option('display.max_columns',50)
exec(open('/tmp/outputs/analysis/06_seqneut.py').read().split('# per-virus ANCOVA')[0].replace("print(","(lambda *a,**k:None)("))
LOD=np.log2(40)
# ---- participant-level class means
def classmean(sub, col):
    return sub.groupby(['arm','pid'])[col].mean()
classes={
 'H1 contemporary drifted (6 strains, 2023)':(w.subtype=='H1N1')&(w.cls=='contemporary drifted (2022-24)'),
 'H1 mRNA-1010 analogue A/Wisconsin/67/2022':(w.virus=='A/Wisconsin/67/2022_H1N1'),
 'H1 Fluarix analogue A/Wisconsin/588/2019':(w.virus=='A/Wisconsin/588/2019_H1N1'),
 'H1 historical (4)':(w.subtype=='H1N1')&(w.cls=='historical (<=2020)'),
 'H3 contemporary drifted (68 strains, 2022-24)':(w.subtype=='H3N2')&(w.cls=='contemporary drifted (2022-24)'),
 'H3 2024 isolates only (3)':w.virus.str.contains('/2024_'),
 'H3 mRNA-1010 antigen A/Darwin/6/2021':(w.virus=='A/Darwin/6/2021_H3N2'),
 'H3 Fluarix antigen A/Darwin/9/2021 (egg)':(w.virus=='A/Darwin/9/2021_H3N2'),
 'H3 historical wild-type (8)':(w.subtype=='H3N2')&(w.cls=='historical (<=2020)'),
 'H3 egg-adapted reassortants (5)':(w.subtype=='H3N2')&(w.cls=='egg-adapted reassortant'),
 'ALL non-egg strains except both vaccine analogues (naive "heterologous" pool)':(w.cls.isin(['contemporary drifted (2022-24)','historical (<=2020)'])),
 'Sponsor-style "heterologous" = everything not an mRNA-1010 antigen (incl. egg + Fluarix strains)':~w.virus.isin(['A/Darwin/6/2021_H3N2','A/Wisconsin/67/2022_H1N1','A/Victoria/4897/2022_IVR-238_H1N1']),
}
rows=[]
for name,mask in classes.items():
    sub=w[mask]
    # require d0 & d29 per strain
    sub=sub.dropna(subset=['d0','d29'])
    P=pd.DataFrame({'d0':classmean(sub,'d0'),'d29':classmean(sub,'d29'),'fr':classmean(sub.assign(fr=sub.d29-sub.d0),'fr')}).reset_index()
    P['mRNA']=(P.arm=='mRNA-1010').astype(int)
    m=smf.ols('d29 ~ mRNA + d0',data=P).fit(); ci=m.conf_int().loc['mRNA']
    a=P[P.mRNA==1]; b=P[P.mRNA==0]
    rows.append(dict(strain_class=name,n_strains=sub.virus.nunique(),n_m=len(a),n_f=len(b),
        GMT0_m=2**a.d0.mean(),GMT0_f=2**b.d0.mean(),baseline_ratio=2**(a.d0.mean()-b.d0.mean()),p_baseline=stats.ttest_ind(a.d0,b.d0).pvalue,
        GMT29_m=2**a.d29.mean(),GMT29_f=2**b.d29.mean(),unadj_ratio=2**(a.d29.mean()-b.d29.mean()),
        GMFR_m=2**a.fr.mean(),GMFR_f=2**b.fr.mean(),GMFR_ratio=2**(a.fr.mean()-b.fr.mean()),p_GMFR=stats.ttest_ind(a.fr,b.fr).pvalue,
        adj_ratio=2**m.params['mRNA'],adj_lo=2**ci[0],adj_hi=2**ci[1],adj_p=m.pvalues['mRNA'],
        resid_sd_log2=np.sqrt(m.scale), corr_d0_d29=np.corrcoef(P.d0,P.d29)[0,1]))
R=pd.DataFrame(rows); print(R.round(3).to_string()); R.round(4).to_csv('/tmp/outputs/analysis/seqneut_pooled_by_class.csv',index=False)

# ---- breadth: per participant, fraction of contemporary H3 (and H1) strains with >=4-fold rise, and d29 titre >= 4x LOD (160)
out=[]
for st in ['H1N1','H3N2']:
    sub=w[(w.subtype==st)&(w.cls=='contemporary drifted (2022-24)')].dropna(subset=['d0','d29'])
    g=sub.groupby(['arm','pid'])
    B=pd.DataFrame({'frac_4fold':g.apply(lambda x:((x.d29-x.d0)>=2).mean()),
                    'frac_ge160_d29':g.apply(lambda x:(x.d29>=np.log2(160)).mean()),
                    'frac_ge160_d0':g.apply(lambda x:(x.d0>=np.log2(160)).mean())}).reset_index()
    for col in ['frac_4fold','frac_ge160_d0','frac_ge160_d29']:
        a=B[B.arm=='mRNA-1010'][col]; b=B[B.arm=='Fluarix'][col]
        out.append(dict(subtype=st,metric=col,mean_m=a.mean(),median_m=a.median(),mean_f=b.mean(),median_f=b.median(),p_MW=stats.mannwhitneyu(a,b).pvalue))
O=pd.DataFrame(out); print(O.round(3).to_string()); O.round(4).to_csv('/tmp/outputs/analysis/seqneut_breadth.csv',index=False)

# ---- egg vs wild-type pairs: does the egg-based comparator skew toward egg-adapted HA?
pairs=[('A/Cambodia/e0826360/2020egg_H3N2','A/Cambodia/e0826360/2020_H3N2'),('A/HongKong/4801/2014egg_H3N2','A/HongKong/4801/2014_H3N2'),
       ('A/Singapore/INFIMH-16-0019/2016X-307A_H3N2','A/Singapore/INFIMH-16-0019/2016_H3N2'),('A/Switzerland/9715293/2013NIB-88_H3N2','A/Switzerland/9715293/2013_H3N2'),
       ('A/Texas/50/2012X-223A_H3N2','A/Texas/50/2012_H3N2'),('A/Darwin/9/2021_H3N2','A/Darwin/6/2021_H3N2'),('A/Victoria/4897/2022_IVR-238_H1N1','A/Wisconsin/67/2022_H1N1')]
ep=[]
for egg,wt in pairs:
    x=w[w.virus==egg].set_index(['arm','pid'])[['d0','d29']]; y=w[w.virus==wt].set_index(['arm','pid'])[['d0','d29']]
    j=x.join(y,lsuffix='_egg',rsuffix='_wt').dropna()
    for arm,g in j.groupby(level='arm'):
        ep.append(dict(egg=egg,wt=wt,arm=arm,n=len(g),egg_over_wt_d0=2**(g.d0_egg-g.d0_wt).mean(),egg_over_wt_d29=2**(g.d29_egg-g.d29_wt).mean(),
                       FR_egg=2**(g.d29_egg-g.d0_egg).mean(),FR_wt=2**(g.d29_wt-g.d0_wt).mean()))
E=pd.DataFrame(ep); print(E.round(2).to_string()); E.round(3).to_csv('/tmp/outputs/analysis/seqneut_egg_vs_wt_pairs.csv',index=False)

# ---- durability (late visit: d121 or d181), baseline-adjusted; note d121/d181 mixing
dur=[]
for name in ['H1 contemporary drifted (6 strains, 2023)','H3 contemporary drifted (68 strains, 2022-24)','H3 mRNA-1010 antigen A/Darwin/6/2021','H1 mRNA-1010 analogue A/Wisconsin/67/2022']:
    sub=w[classes[name]].dropna(subset=['d0','d29','late'])
    P=sub.groupby(['arm','pid']).agg(d0=('d0','mean'),d29=('d29','mean'),late=('late','mean'),late_day=('late_day','first')).reset_index()
    P['mRNA']=(P.arm=='mRNA-1010').astype(int)
    m=smf.ols('late ~ mRNA + d0',data=P).fit(); ci=m.conf_int().loc['mRNA']
    for arm,g in P.groupby('arm'):
        dur.append(dict(strain_class=name,arm=arm,n=len(g),n_d121=(g.late_day=='d121').sum(),GMT_late=2**g.late.mean(),late_over_d0=2**(g.late-g.d0).mean(),late_over_d29=2**(g.late-g.d29).mean(),
                        adj_ratio_late=2**m.params['mRNA'],lo=2**ci[0],hi=2**ci[1],p=m.pvalues['mRNA']))
D=pd.DataFrame(dur); print(D.round(3).to_string()); D.round(4).to_csv('/tmp/outputs/analysis/seqneut_durability.csv',index=False)

# ---- Tobit (censored normal) sensitivity on key single viruses: d29 ~ mRNA + d0 with left-censoring at LOD and right-censoring at ULOQ
def tobit(y,X,lc,rc):
    def nll(th):
        beta=th[:-1]; s=np.exp(th[-1]); mu=X@beta
        ll=np.where(lc,stats.norm.logcdf((y-mu)/s),np.where(rc,stats.norm.logsf((y-mu)/s),stats.norm.logpdf((y-mu)/s)-np.log(s)))
        return -ll.sum()
    b0=np.linalg.lstsq(X,y,rcond=None)[0]; th0=np.r_[b0,np.log(np.std(y-X@b0)+1e-3)]
    r=optimize.minimize(nll,th0,method='BFGS'); se=np.sqrt(np.diag(r.hess_inv))
    return r.x,se
tb=[]
for v in ['A/Darwin/6/2021_H3N2','A/Darwin/9/2021_H3N2','A/Wisconsin/67/2022_H1N1','A/Wisconsin/588/2019_H1N1','A/Lisboa/124/2024_H3N2','A/Shaanxi-Yuyang/1204/2024_H3N2','A/Texas/50/2012X-223A_H3N2']:
    g=w[w.virus==v].dropna(subset=['d0','d29'])
    X=np.c_[np.ones(len(g)),g.mRNA,g.d0]; y=g.d29.values
    lc=(g.d29_bound=='upper').values; rc=(g.d29_bound=='lower').values
    th,se=tobit(y,X,lc,rc)
    tb.append(dict(virus=v,n_left=lc.sum(),n_right=rc.sum(),tobit_ratio=2**th[1],lo=2**(th[1]-1.96*se[1]),hi=2**(th[1]+1.96*se[1])))
T=pd.DataFrame(tb); print(T.round(3).to_string()); T.round(4).to_csv('/tmp/outputs/analysis/seqneut_tobit_sensitivity.csv',index=False)
