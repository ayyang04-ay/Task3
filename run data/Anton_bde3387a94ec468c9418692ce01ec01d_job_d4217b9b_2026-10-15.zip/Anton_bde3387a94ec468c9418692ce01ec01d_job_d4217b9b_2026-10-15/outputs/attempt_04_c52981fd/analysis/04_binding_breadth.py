"""Bead-array binding breadth (log2 fold-change MFI, post/pre) by strain and arm.
Sources: binding_breadth_h1.csv, binding_breadth_h3.csv"""
import pandas as pd, numpy as np
from scipy import stats
import statsmodels.formula.api as smf
pd.set_option('display.width',250); pd.set_option('display.max_rows',500); pd.set_option('display.max_columns',50)
# Relationship of each panel strain to the two vaccines (per trial_summary + WHO 2022-23 NH composition for Fluarix)
rel={
 # H1
 'A/Wisconsin/67/2022':'mRNA-1010 H1 analogue (cell counterpart of A/Victoria/4897/2022; external knowledge)',
 'A/Wisconsin/588/2019':'Fluarix 2022-23 H1 analogue (cell counterpart of A/Victoria/2570/2019; external knowledge)',
 'A/Sydney/5/2021':'2021 strain, heterologous to both H1 components',
 'A/Guangdong-Maonan/SWL1536/2019':'historical 5a.1',
 'A/Hawaii/70/2019':'historical 5a.1',
 'A/Brisbane/2/2018':'historical',
 'A/Michigan/45/2015':'historical',
 'A/California/04/2009':'historical (pdm09 ancestor)',
 'A/Puerto Rico/8/1934':'historical (lab-adapted)',
 # H3
 'A/Darwin/6/2021':'mRNA-1010 H3 (Fluarix: egg A/Darwin/9/2021)',
 'A/Thailand/8/2022':'drifted, post-vaccine (2a.3a.1)',
 'A/Cambodia/e0826360/2020':'historical',
 'A/Hong Kong/2671/2019':'historical','A/South Australia/34/2019':'historical','A/Switzerland/8060/2017':'historical',
 'A/Singapore/INFIMH-16-0019/2016':'historical','A/Texas/50/2012':'historical','A/Victoria/361/2011':'historical',
 'A/Perth/16/2009':'historical','A/Brisbane/10/2007':'historical','A/Hong Kong/1/1968':'historical (ancestral H3)'}
rows=[]
for f,sub in [('binding_breadth_h1.csv','H1'),('binding_breadth_h3.csv','H3')]:
    d=pd.read_csv('/tmp/world/filesystem/'+f)
    for s,g in d.groupby('strain'):
        a=g[g.arm=='mRNA-1010'].log2_fold_change_mfi; b=g[g.arm=='Fluarix'].log2_fold_change_mfi
        t=stats.ttest_ind(a,b,equal_var=False)
        rows.append(dict(subtype=sub,strain=s,relation=rel.get(s,'?'),n_mRNA=len(a),n_Flu=len(b),
                         GMFR_mRNA=2**a.mean(),GMFR_Flu=2**b.mean(),ratio=2**(a.mean()-b.mean()),
                         pct_ge2fold_mRNA=(a>=1).mean(),pct_ge2fold_Flu=(b>=1).mean(),p_welch=t.pvalue))
r=pd.DataFrame(rows); print(r.round(3).to_string()); r.round(4).to_csv('/tmp/outputs/analysis/binding_breadth_by_strain.csv',index=False)
# participant-level breadth: n strains with >=2-fold rise
for f,sub in [('binding_breadth_h1.csv','H1'),('binding_breadth_h3.csv','H3')]:
    d=pd.read_csv('/tmp/world/filesystem/'+f)
    w=d.pivot_table(index=['arm','participant'],columns='strain',values='log2_fold_change_mfi')
    br=(w>=1).sum(axis=1); mean=w.mean(axis=1)
    x=pd.DataFrame({'n_strains_ge2fold':br,'mean_log2FC':mean,'n':w.notna().sum(axis=1)})
    print(sub); print(x.groupby(level='arm').agg(['mean','median']).round(2))
    print('MW breadth p=',stats.mannwhitneyu(br.loc['mRNA-1010'],br.loc['Fluarix']).pvalue,'  mean log2FC p=',stats.mannwhitneyu(mean.loc['mRNA-1010'],mean.loc['Fluarix']).pvalue)
    # excluding each vaccine-matched strain
    vs=['A/Wisconsin/67/2022','A/Wisconsin/588/2019','A/Darwin/6/2021']
    w2=w[[c for c in w.columns if c not in vs]]
    m2=w2.mean(axis=1); print(' mean log2FC over strains heterologous to both vaccines: mRNA %.2f vs Flu %.2f p=%.3f'%(m2.loc['mRNA-1010'].mean(),m2.loc['Fluarix'].mean(),stats.mannwhitneyu(m2.loc['mRNA-1010'],m2.loc['Fluarix']).pvalue))
    print(' participants:',sorted(set(d.participant)))
