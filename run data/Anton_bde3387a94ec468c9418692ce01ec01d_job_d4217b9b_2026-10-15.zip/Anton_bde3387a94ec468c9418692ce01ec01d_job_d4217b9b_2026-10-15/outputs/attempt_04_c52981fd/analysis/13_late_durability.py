"""Late-visit (wk17/26) baseline-adjusted contrasts for HAI and MN, and sensitivity restricted to wk26 only (no pooling)."""
import pandas as pd, numpy as np
import statsmodels.formula.api as smf
pd.set_option('display.width',250)
rows=[]
h=pd.read_csv('/tmp/world/filesystem/hai_titers.csv',dtype={'participant':str}); h['lt']=np.log2(h.hai_titer)
for ag,g in h.groupby('antigen'):
    w=g.pivot_table(index=['arm','participant'],columns='timepoint',values='lt').reset_index()
    w['late']=w['wk26'].fillna(w['wk17'])
    for lab,col in [('wk17/26 pooled','late'),('wk26 only','wk26')]:
        gg=w.dropna(subset=['wk0',col])
        m=smf.ols(f'{col} ~ C(arm, Treatment("Fluarix")) + wk0',data=gg).fit(); k=[x for x in m.params.index if 'mRNA' in x][0]; ci=m.conf_int().loc[k]
        rows.append(dict(assay='HAI',antigen=ag,visit=lab,n=len(gg),GMT_m=2**gg[gg.arm=='mRNA-1010'][col].mean(),GMT_f=2**gg[gg.arm=='Fluarix'][col].mean(),adj_ratio=2**m.params[k],lo=2**ci[0],hi=2**ci[1],p=m.pvalues[k]))
mn=pd.read_csv('/tmp/world/filesystem/microneutralization.csv'); mn=mn[mn.measure=='titer']; mn['lt']=np.log2(mn.value)
for pn,g in mn.groupby('panel'):
    w=g.pivot_table(index=['arm','participant'],columns='timepoint',values='lt').reset_index()
    w['late']=w['wk26'].fillna(w['wk17'])
    for lab,col in [('wk17/26 pooled','late'),('wk26 only','wk26')]:
        gg=w.dropna(subset=['wk0',col])
        m=smf.ols(f'{col} ~ C(arm, Treatment("Fluarix")) + wk0',data=gg).fit(); k=[x for x in m.params.index if 'mRNA' in x][0]; ci=m.conf_int().loc[k]
        rows.append(dict(assay='MN',antigen=pn,visit=lab,n=len(gg),GMT_m=2**gg[gg.arm=='mRNA-1010'][col].mean(),GMT_f=2**gg[gg.arm=='Fluarix'][col].mean(),adj_ratio=2**m.params[k],lo=2**ci[0],hi=2**ci[1],p=m.pvalues[k]))
R=pd.DataFrame(rows); print(R.round(3).to_string()); R.round(4).to_csv('/tmp/outputs/analysis/hai_mn_late_visit.csv',index=False)
