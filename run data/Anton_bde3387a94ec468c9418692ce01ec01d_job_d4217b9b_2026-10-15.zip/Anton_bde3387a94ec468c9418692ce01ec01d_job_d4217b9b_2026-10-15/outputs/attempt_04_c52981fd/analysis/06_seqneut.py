"""Sequencing-based neutralisation (96 viruses x 81 sera): strain classification, baseline-adjusted arm contrasts,
censoring-aware (Tobit) sensitivity, pooled mixed models by strain class, durability.
Source: /tmp/world/filesystem/neutralization_seqbased.csv"""
import pandas as pd, numpy as np, re
from scipy import stats
import statsmodels.formula.api as smf
pd.set_option('display.width',250); pd.set_option('display.max_rows',500); pd.set_option('display.max_columns',50)
d=pd.read_csv('/tmp/world/filesystem/neutralization_seqbased.csv')
s=d.serum.str.split('_',expand=True); d['arm']=s[0]; d['pid']=s[1]; d['day']=s[2]
d['subtype']=d.virus.str.extract(r'_(H\dN\d)$')[0]
d['lt']=np.log2(d.titer)
def year(v):
    # NB: 'A/SOUTHAFRICA/R07876/202023' carries a malformed year; treated as 2023 (contemporary South African series R05384..R07188)
    m=re.match(r'A/[^/]+/[^/]+/(\d+)',v)
    if not m: return None
    y=m.group(1)
    if y=='202023': return 2023
    return int(y[:4])
EGG=r'egg|X-307A|X-223A|NIB-88|IVR-238'
def classify(v):
    name=v.rsplit('_',1)[0]
    if re.search(EGG,v): return 'egg-adapted reassortant'
    if name=='A/Darwin/6/2021': return 'mRNA-1010 H3 antigen (cell)'
    if name=='A/Darwin/9/2021': return 'Fluarix H3 antigen (egg CVV)'
    if name=='A/Wisconsin/67/2022': return 'mRNA-1010 H1 analogue (cell)'
    if name=='A/Wisconsin/588/2019': return 'Fluarix H1 analogue (cell)'
    y=year(v)
    if y is None: return 'unparsed'
    if y>=2022: return 'contemporary drifted (2022-24)'
    return 'historical (<=2020)'
d['cls']=d.virus.map(classify)
# year typo
print('malformed virus years:',[v for v in d.virus.unique() if re.match(r'A/[^/]+/[^/]+/(\d+)',v) and len(re.match(r'A/[^/]+/[^/]+/(\d+)',v).group(1))!=4])
vc=d.drop_duplicates('virus')[['virus','subtype','cls']].sort_values(['subtype','cls','virus'])
vc.to_csv('/tmp/outputs/analysis/seqneut_virus_classification.csv',index=False)
print(vc.groupby(['subtype','cls']).size())
# pivot
w=d.pivot_table(index=['virus','subtype','cls','arm','pid'],columns='day',values='lt').reset_index()
bnd=d.pivot_table(index=['virus','arm','pid'],columns='day',values='titer_bound',aggfunc='first').reset_index()
w=w.merge(bnd,on=['virus','arm','pid'],suffixes=('','_bound'))
w['late']=w['d181'].fillna(w['d121'])
w['late_day']=np.where(w['d181'].notna(),'d181',np.where(w['d121'].notna(),'d121',None))
w['mRNA']=(w.arm=='mRNA-1010').astype(int)
# per-virus ANCOVA
rows=[]
for (v,st,c),g in w.groupby(['virus','subtype','cls']):
    gg=g.dropna(subset=['d0','d29'])
    m=smf.ols('d29 ~ mRNA + d0',data=gg).fit()
    ci=m.conf_int().loc['mRNA']
    a=gg[gg.mRNA==1]; b=gg[gg.mRNA==0]
    cens=((gg.d29_bound!='interpolated')|(gg.d0_bound!='interpolated')).mean()
    rows.append(dict(virus=v,subtype=st,cls=c,n_m=len(a),n_f=len(b),GMT0_m=2**a.d0.mean(),GMT0_f=2**b.d0.mean(),
        GMT29_m=2**a.d29.mean(),GMT29_f=2**b.d29.mean(),GMFR_m=2**(a.d29-a.d0).mean(),GMFR_f=2**(b.d29-b.d0).mean(),
        pct4x_m=((a.d29-a.d0)>=2).mean(),pct4x_f=((b.d29-b.d0)>=2).mean(),
        unadj_ratio=2**(a.d29.mean()-b.d29.mean()),adj_ratio=2**m.params['mRNA'],adj_lo=2**ci[0],adj_hi=2**ci[1],p=m.pvalues['mRNA'],frac_censored=cens))
r=pd.DataFrame(rows).sort_values(['subtype','cls','adj_ratio'])
r.round(3).to_csv('/tmp/outputs/analysis/seqneut_per_virus.csv',index=False)
print(r.round(2).to_string())
