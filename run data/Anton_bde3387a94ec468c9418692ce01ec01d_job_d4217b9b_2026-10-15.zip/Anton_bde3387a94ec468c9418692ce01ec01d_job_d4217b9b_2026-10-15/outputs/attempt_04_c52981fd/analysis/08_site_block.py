"""Allocation-by-site check: do ELISA responses differ between enrolment-ID blocks within arm? (IDs 1-32 interleaved arms; 33-59 Fluarix only; 64-102 mRNA only)"""
import pandas as pd, numpy as np
from scipy import stats
import statsmodels.formula.api as smf
pd.set_option('display.width',250)
d=pd.read_csv('/tmp/world/filesystem/elisa_igg_titers.csv')
e=d[d.measure=='ec50'].copy(); e['lt']=np.log2(e.value)
w=e.pivot_table(index=['antigen','arm','participant'],columns='timepoint',values='lt').reset_index()
w['block']=np.where(w.participant<=32,'IDs 1-32 (interleaved)',np.where(w.arm=='Fluarix','IDs 33-59 (Flu only)','IDs 64-102 (mRNA only)'))
w['fr']=w.wk4-w.wk0
g=w.groupby(['antigen','arm','block']).agg(n=('fr','size'),GMT0=('wk0',lambda x:2**x.mean()),GMT4=('wk4',lambda x:2**x.mean()),GMFR=('fr',lambda x:2**x.mean()))
print(g.round(2).to_string())
for (ag,arm),gg in w.groupby(['antigen','arm']):
    b=gg.block.unique()
    x=gg[gg.block==b[0]].fr; y=gg[gg.block==b[1]].fr
    print(ag,arm,'block FR p=%.3f'%stats.mannwhitneyu(x,y).pvalue)
# arm effect restricted to the interleaved ID block (closest to concurrent enrolment)
for ag,gg in w[w.block=='IDs 1-32 (interleaved)'].groupby('antigen'):
    m=smf.ols('wk4 ~ C(arm, Treatment("Fluarix")) + wk0',data=gg).fit()
    k=[x for x in m.params.index if 'mRNA' in x][0]; ci=m.conf_int().loc[k]
    print(ag,'interleaved-block adj ratio %.2f (%.2f-%.2f) n=%d'%(2**m.params[k],2**ci[0],2**ci[1],len(gg)))
