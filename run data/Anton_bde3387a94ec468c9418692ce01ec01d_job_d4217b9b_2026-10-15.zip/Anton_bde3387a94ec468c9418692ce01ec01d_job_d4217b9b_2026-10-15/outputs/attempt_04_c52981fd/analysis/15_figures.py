import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
r=pd.read_csv('/tmp/outputs/analysis/seqneut_per_virus.csv')
order=['mRNA-1010 H1 analogue (cell)','Fluarix H1 analogue (cell)','contemporary drifted (2022-24)','historical (<=2020)','egg-adapted reassortant',
       'mRNA-1010 H3 antigen (cell)','Fluarix H3 antigen (egg CVV)']
col={'mRNA-1010 H1 analogue (cell)':'tab:blue','Fluarix H1 analogue (cell)':'tab:orange','contemporary drifted (2022-24)':'k','historical (<=2020)':'tab:gray',
     'egg-adapted reassortant':'tab:red','mRNA-1010 H3 antigen (cell)':'tab:blue','Fluarix H3 antigen (egg CVV)':'tab:orange'}
fig,axes=plt.subplots(1,2,figsize=(14,16),gridspec_kw={'width_ratios':[1,2.2]})
for ax,st in zip(axes,['H1N1','H3N2']):
    x=r[r.subtype==st].copy(); x['o']=x.cls.map({c:i for i,c in enumerate(order)}); x=x.sort_values(['o','adj_ratio'],ascending=[False,True]).reset_index(drop=True)
    for i,row in x.iterrows():
        ax.plot([row.adj_lo,row.adj_hi],[i,i],color=col[row.cls],lw=1.2); ax.plot(row.adj_ratio,i,'o',color=col[row.cls],ms=4)
    ax.axvline(1,color='k',lw=0.8,ls='--'); ax.set_xscale('log'); ax.set_xticks([0.25,0.5,1,2,4]); ax.set_xticklabels(['0.25','0.5','1','2','4']); ax.minorticks_off(); ax.set_yticks(range(len(x))); ax.set_yticklabels(x.virus.str.replace('_'+st,''),fontsize=6)
    ax.set_xlabel('Baseline-adjusted D29 GMT ratio, mRNA-1010 / Fluarix (95% CI)'); ax.set_title(st+' (seq-based neutralisation, n=13 vs 14)')
from matplotlib.lines import Line2D
fig.legend([Line2D([0],[0],color=col[c],marker='o') for c in order[:5]],['mRNA-1010 antigen analogue','Fluarix antigen analogue','contemporary 2022-24 (heterologous to both)','historical <=2020','egg-adapted reassortant'],loc='lower center',ncol=5,fontsize=9)
plt.tight_layout(rect=(0,0.03,1,1)); plt.savefig('/tmp/outputs/figures/seqneut_forest_by_strain.png',dpi=130)
# pooled class plot
p=pd.read_csv('/tmp/outputs/analysis/seqneut_pooled_by_class.csv')
fig,ax=plt.subplots(figsize=(12,5.5))
for i,row in p.iloc[::-1].reset_index(drop=True).iterrows():
    ax.plot([row.adj_lo,row.adj_hi],[i,i],'k-'); ax.plot(row.adj_ratio,i,'ko')
lab=p.strain_class.str.replace(r'ALL non-egg strains except both vaccine analogues.*','All non-egg H1+H3 strains except vaccine analogues (86)',regex=True).str.replace(r'Sponsor-style.*','"Heterologous" as defined vs mRNA-1010 only (93, incl. egg/Fluarix strains)',regex=True)
ax.set_yticks(range(len(p))); ax.set_yticklabels(lab.iloc[::-1],fontsize=7); ax.axvline(1,ls='--',color='gray'); ax.set_xscale('log'); ax.set_xticks([0.25,0.5,1,2,4]); ax.set_xticklabels(['0.25','0.5','1','2','4']); ax.minorticks_off()
ax.set_xlabel('Baseline-adjusted D29 GMT ratio, mRNA-1010/Fluarix (95% CI), participant-level'); plt.tight_layout(); plt.savefig('/tmp/outputs/figures/seqneut_pooled_classes.png',dpi=130)
# binding vs function
b=pd.read_csv('/tmp/outputs/analysis/binding_vs_function_same_people.csv',index_col=0)
cols=['ELISA_H3_FR','SN_H3drift_FR','SN_Darwin6_FR','A/H3N2','ELISA_H1_FR','SN_H1drift_FR','A/H1N1']
lab=['H3 binding IgG\n(ELISA)','H3 neut, 68\ncontemporary','H3 neut,\nDarwin/6/2021','H3 HAI','H1 binding IgG\n(ELISA)','H1 neut, 6\ncontemporary','H1 HAI']
fig,ax=plt.subplots(figsize=(10,4)); xx=np.arange(len(cols))
ax.bar(xx-0.2,b.loc['mRNA-1010',cols],0.4,label='mRNA-1010 (n=13)'); ax.bar(xx+0.2,b.loc['Fluarix',cols],0.4,label='Fluarix (n=14)')
ax.set_xticks(xx); ax.set_xticklabels(lab,fontsize=8); ax.set_ylabel('Geometric mean fold-rise, D29/D0'); ax.legend(); ax.set_title('Same participants: binding rises do not translate into neutralisation for H3')
plt.tight_layout(); plt.savefig('/tmp/outputs/figures/binding_vs_function.png',dpi=130)
print('ok')
