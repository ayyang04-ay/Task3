"""ELISA IgG EC50 (n=38 vs 37) and IgM fold change.
Sources: /tmp/world/filesystem/elisa_igg_titers.csv, igm_fold_change.csv"""
import pandas as pd, numpy as np
from scipy import stats
import statsmodels.formula.api as smf
pd.set_option('display.width',250); pd.set_option('display.max_rows',500); pd.set_option('display.max_columns',50)
d=pd.read_csv('/tmp/world/filesystem/elisa_igg_titers.csv')
e=d[d.measure=='ec50'].copy(); e['lt']=np.log2(e.value)
e['tp']=e.timepoint.replace({'wk17':'wk17/26','wk26':'wk17/26'})
w=e.pivot_table(index=['antigen','arm','participant'],columns='tp',values='lt')
out=[];res=[]
for (ag,arm),g in w.groupby(level=['antigen','arm']):
    b,p,l=g['wk0'],g['wk4'],g['wk17/26']
    out.append(dict(antigen=ag,arm=arm,n=len(g),n_late=l.notna().sum(),GMT_wk0=2**b.mean(),GMT_wk4=2**p.mean(),GMFR_wk4=2**(p-b).mean(),
                    GMT_late=2**l.mean(),GMFR_late=2**(l-b).mean(),pct_ge4fold_wk4=np.mean((p-b)>=2),
                    retained_late_vs_wk4=2**(l-p).mean()))
o=pd.DataFrame(out); print(o.round(2).to_string()); o.round(3).to_csv('/tmp/outputs/analysis/elisa_summary.csv',index=False)
for ag,g in w.groupby(level='antigen'):
    gg=g.reset_index()
    m=smf.ols('wk4 ~ C(arm, Treatment("Fluarix")) + wk0',data=gg).fit()
    k=[x for x in m.params.index if 'mRNA' in x][0]; ci=m.conf_int().loc[k]
    g2=gg.dropna(subset=['wk17/26'])
    m2=smf.ols('Q("wk17/26") ~ C(arm, Treatment("Fluarix")) + wk0',data=g2).fit()
    ci2=m2.conf_int().loc[k]
    res.append(dict(antigen=ag,wk4_adj_ratio=2**m.params[k],lo=2**ci[0],hi=2**ci[1],p=m.pvalues[k],
                    late_adj_ratio=2**m2.params[k],late_lo=2**ci2[0],late_hi=2**ci2[1],late_p=m2.pvalues[k],
                    baseline_ratio=2**(gg[gg.arm=='mRNA-1010'].wk0.mean()-gg[gg.arm=='Fluarix'].wk0.mean()),
                    p_baseline=stats.ttest_ind(gg[gg.arm=='mRNA-1010'].wk0,gg[gg.arm=='Fluarix'].wk0).pvalue))
r=pd.DataFrame(res); print(r.round(4).to_string()); r.round(5).to_csv('/tmp/outputs/analysis/elisa_ancova.csv',index=False)
# check reported fold changes
fc=d[d.measure=='fold_change'].pivot_table(index=['antigen','arm','participant'],columns='timepoint',values='value')
c4=2**(w['wk4']-w['wk0']); cl=2**(w['wk17/26']-w['wk0'])
print('wk4 FC consistent:',np.isclose(fc['wk4'],c4.reindex(fc.index),rtol=2e-3).mean())
ok=np.isclose(fc['wk17/26'],cl.reindex(fc.index),rtol=2e-3)
print('late FC consistent:',np.nanmean(ok), ' late FC rows with no late titre:', cl.reindex(fc.index).isna().sum())
bad=fc[~ok].join(cl.rename('calc'))
print(bad.head(30))
# IgM
m=pd.read_csv('/tmp/world/filesystem/igm_fold_change.csv',dtype={'participant':str})
m['participant']=m.participant.str.zfill(3)
print(m.groupby(['antigen','arm']).fold_change.agg(['count',lambda x: np.exp(np.log(x).mean()),'median',lambda x:(x>1).mean(),lambda x:(x>=4).mean()]).round(2))
for ag,g in m.groupby('antigen'):
    a=g[g.arm=='mRNA-1010'].fold_change; b=g[g.arm=='Fluarix'].fold_change
    print(ag, 'MW p=%.3f'%stats.mannwhitneyu(a,b).pvalue)
print(m[m.participant=='005'])
# sensitivity: IgM excluding Fluarix participant 005 (166-212-fold rises to all four antigens)
m2=m[m.participant!='005']
for ag,g in m2.groupby('antigen'):
    a=g[g.arm=='mRNA-1010'].fold_change; b=g[g.arm=='Fluarix'].fold_change
    print(ag,'IgM excl 005: GM mRNA %.2f vs Flu %.2f; MW p=%.3f'%(np.exp(np.log(a).mean()),np.exp(np.log(b).mean()),stats.mannwhitneyu(a,b).pvalue))
