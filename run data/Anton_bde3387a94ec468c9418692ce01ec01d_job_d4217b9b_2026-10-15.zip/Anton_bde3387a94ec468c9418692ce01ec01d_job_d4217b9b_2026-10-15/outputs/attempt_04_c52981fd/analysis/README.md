# Analysis scripts for the WU397 re-analysis

Inputs are read read-only from `/tmp/world/filesystem`. To run any script: `mm core python <script>.py`. Each script's console output is saved next to it as `<script>.out.txt`.

| Script | What it does | Main outputs |
|---|---|---|
| 00_integrity.py | Checks participant/arm consistency across all files, cohort sizes against trial_summary.md, ID formats, visit labels, and the duplicated keys in the GC file | participant_map.csv |
| 01_hai.py | HAI: GMT, GMFR, seroconversion (SCR), seroprotection (SPR), and a baseline-adjusted ANCOVA arm contrast | hai_summary.csv, hai_ancova.csv |
| 02_mn.py | Microneutralisation: GMTs, ceiling (1:1280) counts, a fold-change consistency check, and ANCOVA | mn_summary.csv, mn_ancova.csv |
| 03_elisa_igm.py | ELISA IgG: GMTs, fold-rise, late retention, ANCOVA. Also IgM fold-change, with and without 397-005 | elisa_summary.csv, elisa_ancova.csv |
| 04_binding_breadth.py | Bead-array binding breadth, by strain and by participant | binding_breadth_by_strain.csv |
| 05_cellular_repertoire.py | GC, PB/LNPC, PB–GC clonal overlap, serum IgG clonotypes, CDRH3 diversity | console output |
| 06_seqneut.py | Sequencing-based neutralisation: strain classification and per-virus ANCOVA | seqneut_virus_classification.csv, seqneut_per_virus.csv |
| 07_seqneut_pooled.py | Participant-level pooled contrasts by strain class, plus: breadth, egg vs wild-type pairs, durability, Tobit sensitivity | seqneut_pooled_by_class.csv, seqneut_breadth.csv, seqneut_egg_vs_wt_pairs.csv, seqneut_durability.csv, seqneut_tobit_sensitivity.csv |
| 08_site_block.py | ELISA results by enrolment-ID block (a check on allocation by site) | console output |
| 09_binding_vs_function.py | Binding fold-rise vs functional fold-rise in the same participants | binding_vs_function_same_people.csv |
| 10_mab.py | Monoclonal binding panels: donor-level cross-reactivity with an exact permutation test | mab_donor_level.csv |
| 11_h1_composition_check.py | Compares the H1 serological fingerprint with the stated H1 composition | console output |
| 12_baseline_power.py | Baseline imbalance across strains, minimum detectable effect, sample sizes for the next studies | sample_size_immunogenicity.csv, sample_size_efficacy.csv |
| 13_late_durability.py | Late-visit HAI/MN contrasts, pooled and week-26-only | hai_mn_late_visit.csv |
| 14_identify_unlabelled_panels.py | Exploratory: which viruses the unnamed HAI and MN readouts correlate with | console output |
| 15_figures.py | Figures | ../figures/*.png |

## Conventions

- All titres are analysed on the log2 scale.
- Arm contrasts use ANCOVA: post-vaccination log titre ~ arm + baseline log titre. They are reported as an mRNA-1010/Fluarix GMT ratio with a 95% CI.
- P-values come from a post hoc re-analysis of a small, non-randomised study and should be read as descriptive.
