"""Microneutralisation: homologous vs heterologous panel. GMT, GMFR, ceiling (1280) effects.
Source: /tmp/world/filesystem/microneutralization.csv"""
import pandas as pd, numpy as np
from scipy import stats
import statsmodels.formula.api as smf
pd.set_option('display.width',250); pd.set_option('display.max_rows',500); pd.set_option('display.max_columns',50)
d=pd.read_csv('/tmp/world/filesystem/microneutralization.csv')
t=d[d.measure=='titer'].copy(); t['lt']=np.log2(t.value)
t['tp']=t.timepoint.replace({'wk17':'wk17/26','wk26':'wk17/26'})
w=t.pivot_table(index=['panel','arm','participant'],columns='tp',values='lt')
CEIL=np.log2(1280)
out=[]
for (pn,arm),g in w.groupby(level=['panel','arm']):
    b,p,l=g['wk0'],g['wk4'],g['wk17/26']
    out.append(dict(panel=pn,arm=arm,n=len(g),GMT_wk0=2**b.mean(),GMT_wk4=2**p.mean(),GMFR_wk4=2**(p-b).mean(),GMT_late=2**l.mean(),
        pct_4fold_wk4=np.mean((p-b)>=2),n_at_ceiling_wk0=int((b>=CEIL).sum()),n_at_ceiling_wk4=int((p>=CEIL).sum()),n_at_ceiling_late=int((l>=CEIL).sum())))
o=pd.DataFrame(out); print(o.round(2).to_string()); o.round(3).to_csv('/tmp/outputs/analysis/mn_summary.csv',index=False)
# check reported fold-change vs titres
fc=d[d.measure=='fold_change'].pivot_table(index=['panel','arm','participant'],columns='timepoint',values='value')
calc4=2**(w['wk4']-w['wk0']); calcL=2**(w['wk17/26']-w['wk0'])
chk=pd.concat([fc['wk4'],calc4.rename('calc4'),fc['wk17/26'],calcL.rename('calcL')],axis=1)
chk['ok4']=np.isclose(chk['wk4'],chk['calc4'],rtol=1e-3); chk['okL']=np.isclose(chk['wk17/26'],chk['calcL'],rtol=1e-3)
print('fold-change consistency wk4:',chk.ok4.mean(),' late:',chk.okL.mean())
print(chk[~(chk.ok4&chk.okL)])
res=[]
for pn,g in w.groupby(level='panel'):
    gg=g.reset_index()
    m=smf.ols('wk4 ~ C(arm, Treatment("Fluarix")) + wk0',data=gg).fit()
    k=[x for x in m.params.index if 'mRNA' in x][0]; ci=m.conf_int().loc[k]
    # tobit-like check: exclude participants at ceiling at baseline
    g2=gg[gg.wk0<CEIL]
    m2=smf.ols('wk4 ~ C(arm, Treatment("Fluarix")) + wk0',data=g2).fit()
    res.append(dict(panel=pn,adj_ratio=2**m.params[k],lo=2**ci[0],hi=2**ci[1],p=m.pvalues[k],
                    adj_ratio_excl_ceiling=2**m2.params[k],p_excl=m2.pvalues[k],n_excl=len(g2),
                    baseline_ratio=2**(gg[gg.arm=='mRNA-1010'].wk0.mean()-gg[gg.arm=='Fluarix'].wk0.mean()),
                    p_baseline=stats.mannwhitneyu(gg[gg.arm=='mRNA-1010'].wk0,gg[gg.arm=='Fluarix'].wk0).pvalue))
r=pd.DataFrame(res); print(r.round(3).to_string()); r.round(4).to_csv('/tmp/outputs/analysis/mn_ancova.csv',index=False)
