"""Which viruses do the unlabelled HAI 'A/H1N1'/'A/H3N2' and MN 'homologous'/'heterologous' readouts track?
Correlate each with seq-neut titres against every virus in the same sera (visit-matched: wk0~d0, wk4~d29). Exploratory only."""
import pandas as pd, numpy as np
pd.set_option('display.width',250)
sn=pd.read_csv('/tmp/world/filesystem/neutralization_seqbased.csv')
s=sn.serum.str.split('_',expand=True); sn['pid']=s[1].str[-3:].astype(int); sn['day']=s[2]; sn['lt']=np.log2(sn.titer)
sn=sn[sn.day.isin(['d0','d29'])]; sn['tp']=sn.day.map({'d0':'wk0','d29':'wk4'})
S=sn.pivot_table(index=['pid','tp'],columns='virus',values='lt')
def track(df,label):
    x=df.set_index(['pid','tp'])['lt']
    j=S.join(x.rename('y'),how='inner')
    c=j.drop(columns='y').corrwith(j['y'],method='spearman').sort_values(ascending=False)
    # also fold-rise correlation
    w=j.reset_index().pivot_table(index='pid',columns='tp')
    fr=(w.xs('wk4',axis=1,level=1)-w.xs('wk0',axis=1,level=1))
    cf=fr.drop(columns='y').corrwith(fr['y'],method='spearman').sort_values(ascending=False)
    print(f'--- {label}: n pairs={len(j)}; top level-correlations:'); print(c.head(6).round(2).to_string())
    print(' top fold-rise correlations:'); print(cf.head(6).round(2).to_string())
    sub=pd.Series({'H1N1 mean rho (levels)':c[c.index.str.endswith('H1N1')].mean(),'H3N2 mean rho (levels)':c[c.index.str.endswith('H3N2')].mean(),
                   'H1N1 mean rho (fold-rise)':cf[cf.index.str.endswith('H1N1')].mean(),'H3N2 mean rho (fold-rise)':cf[cf.index.str.endswith('H3N2')].mean()})
    print(sub.round(2).to_string())
h=pd.read_csv('/tmp/world/filesystem/hai_titers.csv'); h['pid']=h.participant.astype(int); h['lt']=np.log2(h.hai_titer); h['tp']=h.timepoint
for ag in ['A/H1N1','A/H3N2']:
    track(h[(h.antigen==ag)&h.tp.isin(['wk0','wk4'])],'HAI '+ag)
m=pd.read_csv('/tmp/world/filesystem/microneutralization.csv'); m=m[m.measure=='titer']; m['pid']=m.participant.str[-3:].astype(int); m['lt']=np.log2(m.value); m['tp']=m.timepoint
for pn in ['homologous','heterologous']:
    track(m[(m.panel==pn)&m.tp.isin(['wk0','wk4'])],'MN '+pn)
