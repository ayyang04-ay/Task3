"""(a) Systematic baseline imbalance across strains; (b) baseline-dependence of fold-rise (why GMFR comparisons mislead);
(c) what WU397 could and could not detect; (d) sample sizes for the recommended studies, from observed variances."""
import pandas as pd, numpy as np
from scipy import stats
import statsmodels.formula.api as smf
pd.set_option('display.width',250)
r=pd.read_csv('/tmp/outputs/analysis/seqneut_per_virus.csv')
for st in ['H1N1','H3N2']:
    x=r[r.subtype==st]
    print(st,'strains with lower d0 GMT in mRNA arm: %d/%d'%((x.GMT0_m<x.GMT0_f).sum(),len(x)),
          ' median d0 ratio mRNA/Flu = %.2f'%np.median(x.GMT0_m/x.GMT0_f),
          ' strains with higher GMFR in mRNA: %d/%d'%((x.GMFR_m>x.GMFR_f).sum(),len(x)),
          ' strains with higher d29 GMT in mRNA: %d/%d'%((x.GMT29_m>x.GMT29_f).sum(),len(x)),
          ' adj ratio >1: %d/%d; adj CI excludes 1 (favouring mRNA): %d, (favouring Fluarix): %d'%((x.adj_ratio>1).sum(),len(x),(x.adj_lo>1).sum(),(x.adj_hi<1).sum()))
# (b) slope of log2 fold-rise on log2 baseline, within arm, pooled contemporary H3
exec(open('/tmp/outputs/analysis/06_seqneut.py').read().split('# per-virus ANCOVA')[0].replace("print(","(lambda *a,**k:None)("))
sub=w[(w.subtype=='H3N2')&(w.cls=='contemporary drifted (2022-24)')].dropna(subset=['d0','d29'])
P=sub.groupby(['arm','pid']).agg(d0=('d0','mean'),d29=('d29','mean')).reset_index(); P['fr']=P.d29-P.d0
for arm,g in P.groupby('arm'):
    m=smf.ols('fr ~ d0',data=g).fit()
    print(arm,'H3 drifted pool: slope of log2 fold-rise on log2 baseline = %.2f (95%% CI %.2f to %.2f), p=%.3f'%(m.params['d0'],*m.conf_int().loc['d0'],m.pvalues['d0']))
# (c) detectable effect in WU397 for H3 drifted pool: residual SD ~1.02 log2, n=13/14
sd=1.023; n1,n2=13,14
se=sd*np.sqrt(1/n1+1/n2)
mde=2**((1.96+0.8416)*se)
print('WU397 minimum detectable GMT ratio (80%% power, 2-sided 0.05) for H3 drifted pool: %.2f'%mde)
# (d) sample sizes
def n_gmt_superiority(sd,ratio,alpha=0.025,power=0.9):
    za=stats.norm.ppf(1-alpha); zb=stats.norm.ppf(power); d=np.log2(ratio)
    return int(np.ceil(2*(za+zb)**2*sd**2/d**2))
def n_gmt_NI(sd,true_ratio=1.0,margin=0.67,alpha=0.025,power=0.9):
    za=stats.norm.ppf(1-alpha); zb=stats.norm.ppf(power); d=np.log2(true_ratio)-np.log2(margin)
    return int(np.ceil(2*(za+zb)**2*sd**2/d**2))
def n_scr_NI(p,margin=0.10,alpha=0.025,power=0.9,true_diff=0.0):
    za=stats.norm.ppf(1-alpha); zb=stats.norm.ppf(power)
    return int(np.ceil((za+zb)**2*(2*p*(1-p))/(margin+true_diff)**2))
rows=[]
for sd_lab,sd in [('ANCOVA residual SD, H3 drifted pool (1.02)',1.023),('ANCOVA residual SD, single strain upper range (1.5)',1.5),('HAI H1 ANCOVA residual SD',None)]:
    if sd is None:
        h=pd.read_csv('/tmp/world/filesystem/hai_titers.csv',dtype={'participant':str}); h['lt']=np.log2(h.hai_titer)
        hw=h[h.antigen=='A/H1N1'].pivot_table(index=['arm','participant'],columns='timepoint',values='lt').reset_index()
        sd=np.sqrt(smf.ols('wk4 ~ arm + wk0',data=hw).fit().scale); sd_lab+=' (%.2f)'%sd
    for ratio in [1.5,2.0]:
        rows.append(dict(variance_source=sd_lab,target='superiority GMT ratio %.1f, 1-sided 0.025, 90%% power'%ratio,n_per_arm_evaluable=n_gmt_superiority(sd,ratio)))
    rows.append(dict(variance_source=sd_lab,target='non-inferiority GMT ratio margin 0.67, true ratio 1.0, 90% power',n_per_arm_evaluable=n_gmt_NI(sd)))
for p in [0.3,0.5]:
    rows.append(dict(variance_source='SCR (binomial), p=%.1f'%p,target='non-inferiority SCR difference margin -10%, 90% power',n_per_arm_evaluable=n_scr_NI(p)))
S=pd.DataFrame(rows); print(S.to_string()); S.to_csv('/tmp/outputs/analysis/sample_size_immunogenicity.csv',index=False)
# Efficacy: events for rVE (1:1), H0 rVE<=LB, exact-ish via conditional binomial normal approx
def events(rve,lb=0.0,alpha=0.025,power=0.9):
    th1=(1-rve)/(2-rve); th0=(1-lb)/(2-lb)
    za=stats.norm.ppf(1-alpha); zb=stats.norm.ppf(power)
    return int(np.ceil(((za*np.sqrt(th0*(1-th0))+zb*np.sqrt(th1*(1-th1)))/(th0-th1))**2))
E=[]
for rve in [0.15,0.20,0.25,0.30]:
    for lb,lab in [(0.0,'superiority (LB>0)'),(-0.10,'non-inferiority (LB>-10%)')]:
        ev=events(rve,lb)
        for ar,share in [(0.02,0.5),(0.02,0.3)]:
            # total N such that expected mismatched events reach ev: N * attack * share * (1 + (1-rve))/2
            N=int(np.ceil(ev/(ar*share*(1+(1-rve))/2)))
            E.append(dict(true_rVE=rve,test=lab,events_needed=ev,comparator_attack_rate=ar,share_of_cases_mismatched=share,total_N_if_endpoint_is_mismatched_cases=N))
E=pd.DataFrame(E); print(E.to_string()); E.to_csv('/tmp/outputs/analysis/sample_size_efficacy.csv',index=False)
# (e) observed GMT ratio needed to clear a lower 95% bound of 1.0 at the planned size (139 evaluable/arm)
for sd in [1.023,1.5]:
    se=sd*np.sqrt(2/139)
    print('SD %.2f log2, n=139/arm: observed ratio needed for LB>1.0 = %.2f'%(sd,2**(1.96*se)))
