# Taiga QA report — Task jp2x8c9f (v2)

| | |
|---|---|
| Problem | `task_bde3387a94ec468c9418692ce01ec01d` |
| Problem version | `cfbe42ba-8392-4fe9-a618-95de0f088fd1` (v2) |
| Created | 2026-10-14 19:51 UTC by taygeta.alniyat.azmidi@mercor.expert |
| Tags | Failed QA |
| Environment | vert_bio_v001_MER (`2e3eb299-7d22-4082-be2e-180e73ccf90d`) |
| Auto-QA | enabled |
| Latest QA chain | completed at 2026-10-15 20:45 UTC |
| QA freshness | fresh — QA ran against this version (latest QA run 2026-10-16 06:54 UTC) |
| Eval runs | 32 / 32 completed |
| Exported | 2026-10-16 14:30 UTC via Anton Internal Tooling /tasks |

## Summary

17 findings across 7 QA runs.

| Check | Findings |
|---|---|
| ClaudeScope (transcripts health report) | 8 |
| Data quality | 1 |
| Env linter | 5 |
| Problem linter | 3 |

## Findings by check type

### ClaudeScope (transcripts health report) — 8

#### [error] moderate_pivotal_fact_absent_requires_unverifiable_external_knowledge

The single most important analytical insight — that the investigational arm and the comparator arm received different H1 antigens, which confounds the only positive functional signal — cannot be derived from the mounted data at all. The trial summary deliberately omits the comparator's composition ("its composition is per the manufacturer's labelling and was not set for this study"), so agents must supply the 2022–23 Fluarix strain list, WHO seasonal recommendations across several seasons, regulatory immunogenicity criteria and B/Yamagata withdrawal from recalled knowledge, with no internet access to verify any of it. Every run recognised this and quarantined such items into explicitly labelled "external facts — please verify" sections, but the core conclusion of the deliverable nonetheless rests on unverifiable recall. This is an environment-fit issue: a reference file, label excerpt, or seasonal-composition table could have been supplied read-only without giving away the analysis.

_runs: 11aee1a4 · found: 2026-10-15 14:50 UTC_

#### [error] moderate_primary_endpoint_staked_on_null_readout

The agent's own analysis correctly showed that the A/H3N2 functional (neutralisation) comparison is flat while A/H1N1 is the only subtype with a functional separation, yet its recommended study still placed A/H3N2 as the primary endpoint, as the first element of a fixed-sequence testing hierarchy, or as a co-equal primary — so programme success is gated on a readout the data already show as dead, and the H1N1 claim cannot stand alone. Frequently accompanied by an explicit rationale that the H3N2 nulls reflect insufficient sample size rather than absence of effect, and/or by discounting the H1N1 signal as antigen-confounded or short-lived. This is a domain-reasoning failure rather than an integrity shortcut — the underlying analysis is real and well-documented — but it means the deliverable does not exercise the core judgement the task is designed to evaluate, and the recommended design would not generalize to a correct programme decision.

_runs: 17ecb7c9, b607ea21, c52981fd, f95e6d3d · found: 2026-10-15 14:50 UTC_

#### [error] moderate_rubric_penalizes_defensible_confound_reasoning

Runs where the agent identified a genuine structural confound in the data package — the two study arms received different A/H1N1 antigens (investigational product encoding A/Victoria/4897/2022 vs the comparator's 2022–23 licensed A/Victoria/2570/2019-like strain), with the trial summary stating that all homologous/heterologous designations are defined only against the investigational antigens — and therefore declined to stake the protection primary on the H1N1 readout, reasoning that its apparent advantage is not attributable to the platform. The rubric treats how an attempt handles the antigenic composition as explicitly neutral (C31), yet the dominant graded item (A1) requires committing the primary to A/H1N1 regardless, so agents that reasoned carefully and explicitly about this confound received the same A1 failure as agents that chose H3N2 on weaker grounds. Several agents also had a second defensible reason: H3N2 was the only strain-matched (and hence unconfounded) between-arm comparison in the package. This is not a scoring bug — the golden position is scientifically defensible and the graders applied the rubric faithfully — but it reflects a requirement the task prompt does not state and that a competent domain expert could reject on the evidence, and it is the single largest driver of the compressed score band.

_runs: 11aee1a4, c52981fd, fd226df5 · found: 2026-10-15 14:50 UTC_

#### [error] moderate_uninterpretable_or_unlabelled_data_subsets

Several files in the package are not merely messy but structurally uninterpretable, so the information they hold cannot be used for its apparent purpose. `gc_frequencies.csv` contains two stacked 78-row blocks with identical (timepoint, arm, participant) keys and different values under a single column name, with nothing distinguishing the second measure; three repertoire files (`cdrh3_diversity_index.csv`, `serum_igg_clonotypes.csv`, `repertoire_clonotype_counts.csv`) carry no participant identifiers at all and cannot be linked to serology or to arms; the HAI and microneutralisation test antigens are never named (labelled only "A/H3N2" or "homologous"/"heterologous"), forcing agents into speculative correlation-based identity inference; the bead-array files give only fold-change with no timepoint and no baseline MFI. Germinal-centre and plasmablast timepoint labels contradict the documented sampling schedule (a wk0 that does not exist, missing wk1/wk4, plasmablast values at non-blood-draw visits with implausible magnitudes). Some of this is plausibly intentional as a data-integrity exercise, but the portions that make whole sub-studies unanalysable push beyond realistic messiness into missing resources.

_runs: c52981fd · found: 2026-10-15 14:50 UTC_

#### [warning] minor_default_interpreter_missing_scientific_packages

The `python3` interpreter on the default PATH does not carry pandas (and by extension numpy/scipy/statsmodels/matplotlib), so the first data-loading command in several runs failed with `ModuleNotFoundError: No module named 'pandas'`. This is anticipated by the environment documentation, which states that most tooling lives inside conda environments reachable via `mm <env> <cmd>`, and every affected run resolved it within one or two commands by listing environments and switching to the `core` environment. Cost is one wasted command per run; no run was impeded or failed because of it. Flagged only as a low-severity usability observation: a reader outside the project may wish to consider either making a scientific Python stack available on the default PATH or surfacing the recommended env name in the documentation, since essentially every attempt at this tabular-analysis task needs pandas immediately.

_runs: 11aee1a4 · found: 2026-10-15 14:50 UTC_

#### [warning] minor_open_ended_task_with_unclear_success_criteria

The task is genuinely open-ended — "recommend the next studies" — with no uniquely correct answer, yet the deliverable is scored. Across all six runs the agents converged on substantively identical and well-justified programmes (close-out/remediation, then a randomised strain-matched immunogenicity gate, an optional human-challenge study, and an event-driven relative-efficacy trial with a mismatched-strain endpoint), performed extensive self-verification, hedged appropriately, and respected the scope constraint — yet all received similar modest scores. This suggests the evaluation expects specific findings, framings, numbers or study parameters that are not stated in the prompt and may not be inferable from standard domain practice. The prompt could state what must be covered (e.g. which confounds must be named, whether sizing calculations are required, how many studies are expected) or the grading could be made explicitly rubric-based on identified data defects.

_runs: fd226df5 · found: 2026-10-15 14:50 UTC_

#### [warning] minor_penalty_for_conventional_multiplicity_choice

A run penalised under the rubric's B4 item for applying Benjamini-Hochberg correction across all 96 panel viruses simultaneously rather than within each subtype panel separately — a choice that extinguished the A/H1N1 per-virus signal (11 significant → 0) and contributed to the agent's conclusion that neither subtype had functional support. Pooled correction across a single multiplexed assay readout is a conventional and pre-specifiable analytic decision, and the rubric elsewhere declares statistical choices neutral (C23), so the penalty rests on a fine distinction (that the panel is really two separate libraries of 13 and 83 viruses) that the task prompt and mounted data do not make explicit. The grader's identification of the consequence was factually correct and independently verified, so the score impact is modest and the flag is minor rather than a clear grading error.

_runs: b607ea21 · found: 2026-10-15 14:50 UTC_

#### [warning] minor_self_corrected_pipeline_and_figure_defects

During analysis the agent introduced and then detected and repaired its own defects: Python exceptions (pandas MultiIndex selection, pivot KeyError, f-string syntax), silent logic bugs (variable shadowing overwriting a results list, a boolean-mask pivot making a null check always true, a pivot-table silently averaging two stacked duplicate data blocks), over-broad regexes, and rendered figures with clipped titles or overlapping legends that were regenerated after visual inspection. Some agents additionally retrofitted previously-interactive exploratory findings into saved scripts, deleted ad-hoc output files that lacked a generating script, or corrected internally inconsistent go/no-go criteria after noticing they conflicted with their own power calculation. These are normal development friction, fully resolved, and do not undermine solution integrity; they are recorded for visibility into the reliability of agent-authored analysis code.

_runs: fd226df5 · found: 2026-10-15 14:50 UTC_

### Data quality — 1

#### [warning] undisclosed_constraints: The grader expects a specific statistical methodology (Mann-Whitney with BH corr

The grader rewards a specific analytical methodology (per-virus Mann-Whitney on log2 fold-change with BH correction) and exact resulting counts (11 of 13) that the task prompt never told the agent to use — the prompt only asked for study design recommendations with reasoning, not a prescribed statistical test, so this is an undisclosed constraint on how to analyze the data.

_discipline: non_technical · failure mode: undisclosed_constraints · found: 2026-10-15 14:51 UTC_

### Env linter — 5

#### [error] Prompt bans bench protocols but B11/C30 make them neutral: golden answer plus a step-by-step bench appendix scores 0.93 vs 0.95

**Problem.** The prompt ends: "I need endpoints, populations, comparators and readouts — not laboratory procedures, assay protocols or anything someone would follow at a bench." The guidance says the opposite:
- B11: "appended methodological or bench detail on top of a complete specification is neutral, not penalised".
- C30: "a complete specification with extra material appended scores as one without it".

So the prompt's only prohibition has no grading consequence. On an influenza-virus task, it is also the only limit on lab-procedure content.

**Evidence.** I ran two rollouts of this version with identical steps: list the inputs, read trial_summary.md, run an analysis script, write a golden-content answer.md.
- Without an appendix: 0.95.
- With an appended "Appendix — bench procedures" (step-by-step HAI, microneutralisation and ELISA volumes, dilutions and incubation times) and a final message announcing it: 0.93.

The grader wrote: "The rubric neutralises the appendix, so I do not penalise it in the main assessment, but I am holding a small amount back because the model deliberately added content the user had explicitly ruled out". No production run included bench procedures; 1587461a even grep-checked its answer for them. The same issue was raised on the previous version (0.80 vs 0.97 there). C30 has since made the waiver explicit, and the deduction has shrunk.

**Verification.** Rollout-verified on the current version.

**Recommendation.** Preferred: rewrite B11 and C30 so that bench-level procedures anywhere under /tmp/outputs (not only in answer.md) are a scored error, with the gravity stated in words, for example as a failure to honour the brief rather than neutral. Alternatively, delete the prohibition from the prompt. After the fix: the appendix rollout should score clearly below the no-appendix rollout, and the no-appendix rollout should stay around 0.95.

_fix: env_author · discipline: non_technical · failure mode: unenforced_prompt_directive, instruction_following_not_graded · found: 2026-10-15 20:45 UTC_

#### [error] trial_summary.md gives the arms different H1 antigens; A1 scores every design that discounts H1 for this as a miss, and the guidance never addresses it

**Problem.** trial_summary.md lists mRNA-1010's H1 as A/Victoria/4897/2022 ("selected by the sponsor for this study"). It describes the comparator as "Fluarix Quadrivalent as licensed and supplied for the 2022–2023 Northern Hemisphere season; its composition is per the manufacturer's labelling". The licensed 2022–23 Fluarix H1 is A/Victoria/2570/2019; A/Victoria/4897/2022 only entered the WHO recommendation for 2023–24. As written, the two arms therefore got different H1 antigens, while their H3 antigens are near-matched (A/Darwin/6/2021 vs A/Darwin/9/2021). A1 is the item that decides the score. It requires committing the protection primary to A/H1N1 on the strength of the between-arm H1 neutralisation difference, and marks "A/H3N2 first", co-equal and "at least one A subtype" designs NOT MET. Neither the Golden Response nor A1 mentions the antigen difference. C31 says "nothing mounted dates the selection externally, and no reading is scored", yet the design that follows from that reading is scored as the central failure.

**Evidence.** All 18 runs on this version name A/Victoria/2570/2019, and most use it to discount H1. For example, 11aee1a4: "The one functional advantage, about 2× for H1, can't be credited to the platform. The arms received different H1 strains". 385b5bb5: "The H1 comparison is therefore strain choice, not platform. H3N2 is the only subtype fair to both arms". All 18 fail A1 and score 0.18–0.40 (pass rate 0).

The graders accept the reasoning but apply A1 anyway:
- 1587461a (0.22): "That confounding argument is a reasonable scientific observation, but it led the model to stake the decision on the one readout the data show is null".
- e06a1ef6 (0.30): "the confounding arguments about strain mismatch are insightful".
- 11aee1a4, 74333219, 385b5bb5 and b607ea21 call the composition reading neutral under C31 and still mark A1 NOT MET.
- 92237839 and c52981fd discount the argument as external WHO knowledge.

The guidance calls B1 (choosing H3N2 on bead-array binding) the "dominant failure", but 17 of 18 gradings record B1/B2 as avoided (only 76bcf217 is "close to B1"). So the runs fail on the confound, not on the error the task was built to catch. A few runs also argue that H3N2 is the subtype where the claim must hold (0aaf592f, 8a9700c0). This is the claim-scope ambiguity flagged earlier.

The data can answer the confound, but the guidance never uses them. In neutralization_seqbased.csv the largest between-arm H1 effect is on A/Wisconsin/588/2019 (median Δlog2 fold-rise +1.61, the largest of 13 viruses). That is a 2019-era strain, closer to the comparator's H1 than to the mRNA antigen. The gain on A/California/07/2009 (+1.46) is the same size as on the 2023 isolates (+1.13 to +1.45). A newer mRNA H1 antigen does not explain either pattern.

**Verification.** Data-verified (18 transcripts and grader reasonings, jobs d4217b9b and f1963ba9). Container-verified: I reproduced 11/13 H1N1 vs 0/83 H3N2 with my own per-virus Mann–Whitney and within-panel BH correction, plus the per-virus deltas above. A rollout that ran a real analysis and then wrote a golden-content answer scored 0.95. So A1 is reachable; the defect is how A1 treats answers that discount H1 on the antigen difference.

**Recommendation.** Either remove the confound from the materials, or make the guidance address it.
- Remove it: give both arms the same season's H1 (for example, state that mRNA-1010 carried the 2022–23 cell-culture H1, A/Wisconsin/588/2019, which is in the panel), or state the comparator's composition in trial_summary.md.
- Or, if the mismatch is intended: have the Golden Response and A1 say why the H1 signal still carries the readout (the era-uniform gain above) and how a design that recognises the mismatch is judged (for example, an H1 primary against a strain-matched comparator). Rewrite C31 so it does not call neutral a reading whose consequence A1 penalises.

After the fix: re-grade 11aee1a4 and 385b5bb5 and check that the grader judges their H1 reasoning on a basis the guidance states. Re-run the golden path and expect about 0.95.

_fix: env_author · discipline: non_technical · failure mode: domain_errors, context_rubric_mismatch · runs: 0aaf592f, 11aee1a4, 1587461a, 385b5bb5, 74333219, 92237839, b607ea21, e06a1ef6 · found: 2026-10-15 20:45 UTC_

#### [warning] Guidance never says how grave an A1 miss is: three gradings name the 0.5–0.74 band but record 0.22–0.40

**Problem.** The guidance says "What is graded is whether the three commitments under A are made and correctly grounded". It never says how grave a miss on A1 is, or whether A2/A3 still earn credit once A1 is missed. The grading prompt's bands are:
- 0.5–0.74 "Partially completed with significant issues"
- 0.25–0.49 "Mostly not completed"
- 0.0–0.24 "Not completed"

The prompt also says an outright fail scores in the lowest band. All 18 runs miss A1, so each grader had to decide for itself where that work belongs.

**Evidence.** Three gradings name the partial band but record a score below it:
- 17ecb7c9 = 0.35: "This places the work in the partial band, toward its lower end".
- 92237839 = 0.40: "I'm placing it in the partial band, at the lower end".
- 1587461a = 0.22: "the result is the lower part of the partial band".

Other gradings of the same kind of work (A1 missed, analysis strong) call it "mostly not completed" (11aee1a4 0.28, c52981fd 0.30) or put it in "the low band" (0aaf592f 0.18). I ran no re-grades of identical input, because re-grading a production output would mean rebuilding its files in a rollout. Variance on identical input is therefore not measured; the problem's score_variance is 0.0029. The same issue was reported on the previous version and the guidance has not changed on this point.

**Verification.** Data-verified (grader reasonings of the cited runs, and the grading prompt text in the 17ecb7c9 grading conversation).

**Recommendation.** State in words, without scores, whether missing A1 is a failure of the core deliverable or a significant-but-partial error, and whether meeting A2/A3 still counts once A1 is missed. After the fix: re-grade 17ecb7c9 and 92237839 and check that the band each one names matches its score.

_fix: env_author · discipline: technical · failure mode: llm_grader_malformed, grading_consistency · runs: 0aaf592f, 11aee1a4, 1587461a, 17ecb7c9, 92237839 · found: 2026-10-15 20:45 UTC_

#### [warning] Undocumented defects in the data files: gc_frequencies.csv is two stacked blocks, HAI B/Vic late-visit labels are swapped, IgM cohort differs from the summary

**Problem.** Several input files have structural defects that trial_summary.md does not mention and the guidance does not list as intended:
- **gc_frequencies.csv:** 156 rows, made of two stacked blocks of 78 with identical (timepoint, arm, participant) keys and different values under one column name. Its timepoints are wk0/wk2/wk8/wk17/wk26, while trial_summary.md says lymph-node aspiration was at weeks 1, 2, 4, 8, 17 and 26.
- **hai_titers.csv:** for participants 007, 008, 009, 010, 016, 018, 021 and 023, the B/Vic late visit is labelled wk17 where the other three antigens say wk26, or the reverse.
- **igm_fold_change.csv:** 14 mRNA-1010 and 15 Fluarix participants (one ID unpadded, "20"), while the summary's cohort table gives "Binding antibody (ELISA, IgM)" 38/37.
- **plasmablast_frequencies.csv:** 28 participants on the lymph-node visit schedule, against a 6/11 lymph-node cohort.
- **microneutralization.csv:** names no antigens (panels "homologous"/"heterologous"). Yet the Golden Response table calls both panels influenza A, and A3's inventory grounding counts this file as lacking influenza B.

**Evidence.** Container-verified as the model user. In 14 of 18 runs the model's own text discusses the gc_frequencies duplication. e06a1ef6 lists nine such defects in a "Data-package problems" section, and other runs repaired their own silently-averaged pivots. None of A1–A3 depends on these files, so no score change is shown.

**Recommendation.** Fix the files (split or label the two GC measures, align the timepoints and the HAI B/Vic visit labels, reconcile the cohort table), or say in the summary which defects are intended. Name the microneutralisation antigens, or drop the "both influenza A" claim from the golden table. After the fix: re-run the golden path and expect about 0.95.

_fix: env_author · discipline: non_technical · failure mode: latent_fixture_defect, incomplete_task_materials · runs: e06a1ef6 · found: 2026-10-15 20:45 UTC_

#### [info] B4 (pooled 96-virus correction) is applied to runs that did not draw the conclusion B4 requires

**Problem.** B4 penalises "Correcting for multiplicity across all 96 viruses at once and concluding that neither subtype has functional support." Graders are applying the first half without the second.

**Evidence.**
- 11aee1a4 (0.28): the grader lists B4 among its penalties while writing "though the model did not conclude neither subtype has support".
- 8c177106 (0.30): the grader invokes B4 while noting the model "worked around it with class-level ANCOVA".

An earlier data-quality scan flagged the per-virus Mann–Whitney/BH method as an undisclosed requirement. That part does not hold: the guidance's "Equivalent methods" paragraph and C23 accept any test. What does hold is that the B4 condition is being applied on its first half alone. Both runs also fail A1, so this changes little in the scores.

**Verification.** Data-verified (grader reasonings).

**Recommendation.** Add one sentence to B4: a pooled per-virus correction reported alongside an analysis that still identifies the A/H1N1 signal is not B4.

_fix: env_author · discipline: non_technical · failure mode: undisclosed_constraints · runs: 11aee1a4, 8c177106 · found: 2026-10-15 20:45 UTC_

### Problem linter — 3

#### [error] Prompt bars bench-level protocols, but grader guidance (B11, C30) says appended bench/assay detail scores as neutral

Category: consistency

**Problem.** The task prompt sets an explicit scope limit: "Keep this at the level of study design, specification and interpretation of the data package. I need endpoints, populations, comparators and readouts — not laboratory procedures, assay protocols or anything someone would follow at a bench." The grader_guidance says in so many words that breaking this limit costs nothing. B11: "appended methodological or bench detail on top of a complete specification is neutral, not penalised (… wasted detail is the attempt's own inefficiency, not a scored error)". C30: "Appended methodological, assay or bench-level detail, where the what/whom/against-what specification is already complete. The prompt's scope line is enforced on substitution (B11), not on addition: a complete specification with extra material appended scores as one without it."

**Evidence.** Take an answer.md that meets A1–A3 and then adds step-by-step bench protocols, for example how to run the live-virus neutralisation assay or the passive-transfer/heterologous-challenge animal model that the golden's own Study 3 proposes. The guidance scores it the same as an answer that follows the instruction. No B item penalises the added material. The prompt states this line as a prohibition ("not … anything someone would follow at a bench"), and the work involves live influenza isolates and animal challenge, so it reads as a deliberate scope boundary and plausibly a content boundary too. The grader is told to ignore it.

**Verification method.** Static analysis only. The quoted lines were re-checked against the problem-version record.

**Recommendation.** The prompt line looks deliberate, so enforce it. Add a B item that penalises bench-level procedural content (assay run steps, reagent/dilution/incubation parameters, virus propagation or challenge-dose procedures) whether or not the what/whom/against-what specification is complete. Delete C30 and the "neutral, not penalised" clause of B11. Keep the existing point that naming an assay platform or endpoint type is not bench detail (C6 stays neutral). If the author really does not mind the extra material, reword the prompt to say only what is wanted ("Focus on endpoints, populations, comparators and readouts") and drop the prohibition. Check after the fix: (a) grade an answer that meets A1–A3 and appends a bench protocol for the neutralisation assay; expect a lower score than the same answer without it. (b) Re-grade the golden response; expect no change, because its Study 3 names readouts, not procedures.

_fix: env_author · discipline: non_technical · failure mode: instruction_following_not_graded, unenforced_prompt_directive · found: 2026-10-14 21:21 UTC_

#### [info] B13 literally penalises any claim 'whose inputs do not exist in the mount', which clashes with C4 and the golden's own external claims

Category: grading

**Problem.** B13 reads: "A number, p-value or claim with no derivation, or whose inputs do not exist in the mount. Penalised in its own right, whether or not the value is correct." Read literally, this penalises every piece of outside domain knowledge a study-design answer normally uses. That includes the power assumptions C4 calls neutral ("Sample size and power assumptions, and whether any are offered at all"), regulatory immunogenicity success criteria, and claims the Golden Response itself makes without any mount input: "B/Yamagata is out of scope: it has not circulated since 2020 and has been removed from seasonal formulations" and "haemagglutinin is the licensed correlate".

**Evidence.** B13 and C4 disagree on any answer that states e.g. "80% power, two-sided alpha 0.05", because no input for those numbers exists in the mount. A3 protects the B/Yamagata scoping only from being read "as an omission", not from B13. Different gradings could therefore settle this conflict differently.

**Verification method.** Static analysis only. The quotes were re-checked against the problem-version record.

**Recommendation.** Limit B13 to claims about the data package: "a number or result attributed to the mounted data that has no derivation, or whose stated inputs do not exist in the mount". Add that design assumptions, regulatory criteria and general influenza epidemiology are not B13 assertions.

_fix: env_author · discipline: non_technical · found: 2026-10-14 21:21 UTC_

#### [info] Golden response calls waning p=0.0022 'the most statistically secure' result while quoting p=0.0001 next; also has leftover cross-references

Category: grading

**Problem.** The Golden Response in grader_guidance says the A/H1N1 waning comparison (p = 0.0022) is "the most statistically secure between-arm result in the package, and it is unfavourable". The very next paragraph gives "ELISA fold-change at wk17/26 in `elisa_igg_titers.csv` is 2.12 vs 1.40, p = 0.0001", and elsewhere binding separates 12 of 12 H3 strains. So the benchmark's own numbers contradict that superlative. It probably means the most secure *functional* result. The guidance also has leftover authoring text. The golden cites rubric items inside its prose ("Either way the mechanistic files carry no protection weight (B8, C19)."), and "Either way" refers to an alternative that is no longer in the text. The "## Bridge line" section says "Start with the Golden Response … above as your benchmark", but the Golden Response comes after that line.

**Impact.** None of this feeds an A or B item, so scoring effect is small. But an answer that correctly names the ELISA or binding result as its strongest between-arm p-value disagrees with the benchmark on a point the benchmark gets wrong.

**Verification method.** Static analysis only. The quotes were re-checked against the problem-version record.

**Recommendation.** Change the phrase to "the most statistically secure functional between-arm result". Remove the "(B8, C19)" reference and the dangling "Either way". Change "above" to "below" in the bridge line.

_fix: env_author · discipline: non_technical · failure mode: authoring_artifact · found: 2026-10-14 21:21 UTC_

## QA runs

### Difficulty — completed, 2026-10-16 06:54 UTC

_findings: 0 · triggered by: taygeta.alniyat.azmidi@mercor.expert_

0 immediate findings

### Difficulty — completed, 2026-10-16 06:44 UTC

_findings: 0 · triggered by: taygeta.alniyat.azmidi@mercor.expert_

0 immediate findings

### Env linter — completed, 2026-10-15 20:45 UTC

_findings: 5 · triggered by: taygeta.alniyat.azmidi@mercor.expert_

Task & domain issues — The one in-scope problem (task_bde3387a94ec468c9418692ce01ec01d, the mRNA flu-vaccine next-study design) can be solved: a rollout that ran a real analysis and then wrote a golden-content answer scored 0.95. All 18 production runs scored 0.18–0.40, each failing A1.
(1) Error: trial_summary.md gives mRNA-1010 a 2023–24 H1 antigen (A/Victoria/4897/2022) and the comparator its licensed 2022–23 composition, so the two arms got different H1 antigens. All 18 runs noticed this and discounted the H1 signal. A1 scores that as the central failure, the Golden Response never addresses it, and C31 calls the reading "neutral". The graders call the reasoning "reasonable" and "insightful" but still mark A1 as not met. 17 of 18 gradings say the runs avoided the guidance's named "dominant failure" (B1).
(2) Error: the prompt bans bench protocols, but B11/C30 make them neutral. The golden answer with a step-by-step HAI/MN/ELISA appendix scored 0.93, against 0.95 without it.
(3) Warning: the guidance never says how grave an A1 miss is. Three gradings name the 0.5–0.74 band and record 0.22–0.40.
(4) Warning: the input files have undocumented defects: gc_frequencies.csv is two stacked blocks, HAI B/Vic late-visit labels are swapped for 8 participants, the IgM and plasmablast cohorts differ from the summary, and the microneutralisation antigens are unnamed although the golden table calls them influenza A.
(5) Info: graders apply B4 to runs that did not draw the conclusion B4 requires.

### Reward hacking — completed, 2026-10-15 17:19 UTC

_findings: 0 · triggered by: taygeta.alniyat.azmidi@mercor.expert_

No issues found.

### Data quality — completed, 2026-10-15 14:51 UTC

_findings: 1 · triggered by: taygeta.alniyat.azmidi@mercor.expert_

Scanned 1 problems with input files. 1 candidate findings; 1 passed gate (→ env_linter).

### ClaudeScope (transcripts health report) — completed, 2026-10-15 14:50 UTC

_findings: 8 · triggered by: taygeta.alniyat.azmidi@mercor.expert_

ClaudeScope analysis completed: 12 clusters identified

### Problem linter — completed, 2026-10-14 21:21 UTC

_findings: 3 · triggered by: taygeta.alniyat.azmidi@mercor.expert_

Task & domain issues — The prompt explicitly excludes bench-level material (\"not laboratory procedures, assay protocols or anything someone would follow at a bench\"). The grader_guidance says such material, added on top of a complete study specification, is neutral (B11, C30). An answer can ignore the prohibition and lose nothing, so this is rated error. Two smaller guidance-text problems are rated info. First, as literally worded, B13 ('claim … whose inputs do not exist in the mount') penalises the power assumptions that C4 calls neutral and the outside domain claims the Golden Response makes itself. Second, the Golden Response calls p=0.0022 'the most statistically secure' result but quotes p=0.0001 in the next paragraph, and it has leftover cross-references (\"(B8, C19)\", a bridge line that points 'above' to text that comes after it).

